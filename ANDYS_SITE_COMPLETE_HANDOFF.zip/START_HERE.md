# Builder handoff — Louisiana Commercial Janitor

## Owner's direction and purpose

This archive is a **snapshot of the current working files**, including uncommitted work, for the owner to use as the starting point of a separate repository and deployment for Andy's site/app. The owner wants everything developed for this build together: the Louisiana business site, QR scanning, the Bench, hiring, onboarding, Bubbles, the supporting foundation, and a clear plan. Do not merge or deploy this archive automatically. The owner explicitly chose a separate deploy for Andy. Do not confuse this business with the separate Goodwork/platform project.

The owner's accepted site colors are the current navy/sky-blue/white preview. The business name is **Louisiana Commercial Janitor**, tagline **Our People Are Our Assets**. Preserve these while developing the other discussed functionality. No approved logo file, final legal/DBA name, owner-approved services, service towns, hours, contact information, domain, or owner-approved story were supplied. Do not make them up or redraw the logo; request the original. Photos in this snapshot are illustrative, not real crew or client sites. Do not use Jani-King trademarks or imply affiliation without explicit franchisor approval. Do not store Andy's private personal information in site copy or prompts.

## How the build evolved

1. The existing repository began as a fictional Goodwork/Clean King demo and security-conscious foundation, not a running business operation. The earlier name is historical, not Andy's public brand.
2. A pitch page and recording were added. They remain in this snapshot for completeness, **not** as approved site copy or evidence of current production readiness; their numbers and claims are historical and must be independently checked. The written pitch/audio mention the old name. Do not assume it is consistent with the new site.
3. A first brand configuration, shared styling changes, and a Louisiana Commercial Janitor public homepage were added. The owner approved its colors and name and said to continue everything discussed. The public site is now `/`; the fictional operational workspace was moved to `/workspace`. The current working tree is the source included here, not just the older commit.
4. This is a handoff, not a completed launch. Some README sections still describe `/` as the demo, say no deployment exists, or describe older assistant behavior. Read the code and this handoff alongside the README, and verify actual deployment/configuration rather than assuming those historical statements are current.

## Start locally

```sh
node --version                 # Node 22 or newer
npm ci
npm run dev                    # local preview on port 3000
# visit / and /workspace; both use synthetic / preview content
npm test
npm run build
npm run test:production        # run after build
npm run audit:secrets
npx playwright install --with-deps chromium
npm run test:e2e
```

Copy `.env.example` to a local ignored `.env.local` only if needed for an isolated synthetic-data test. Use a dedicated approved test project, **never the existing live project by default**. No real credentials or `.env.local` are included. Do not enter real personal, customer, crew, patient or student data. A ZIP is not a git repository: after unpacking, initialize the new repo and configure its own secret store and origin. This snapshot contains no `.git`, dependencies, build outputs or Forge-Load archives. See the included manifest for file checksums.

## Where the pieces are

| Area | Files / entry point | Current reality |
|---|---|---|
| Andy's public site | `app/page.js`, `app/public/header.js`, `app/globals.css`, `lib/brand.mjs`, `lib/brand-palette.mjs` | Name, approved provisional colors and tagline; English/Spanish homepage; illustrative images and preview warnings. Services, hours, contact, logo and story await approval. |
| Quote and apply | `app/quote/page.js`, `app/apply/page.js`, `app/public/intake-form.js`, `app/api/intake/route.js`, `lib/intake.mjs`, `lib/server/` | Forms and server-side foundation exist; intake fails closed in production. Do not describe this as live collection. |
| Fictional workspace / hiring | `/workspace`, `app/workspace/page.js`, `app/ui.js`, `lib/demo-copy.mjs`, `lib/demo.mjs`; protected foundation `app/owner/`, `app/owner/actions.js` | Demo applicant decisions live in browser memory and reset. Separate owner inbox/onboarding code exists behind development-only access and RLS/security gates. No actual hiring or messages in demo. |
| The Bench / coverage | `lib/demo.mjs` (`eligible`, `simulateCoverage`), `app/ui.js` | Fictional candidate checks for availability, example training/clearances and hour caps. The first eligible person is assumed to accept; nobody is contacted. **Not** a real scheduling, offer, reservation or shift-claim system. |
| QR scanning | `/crew/scan`, `app/crew/scan/scanner-client.js`, `app/crew/scan/page.js` | Experimental browser camera/`BarcodeDetector` and manual-entry UI. It reports a code, not a verified site check-in or integration. Audit and test before use: current `next.config.mjs` permissions policy disables camera, and the video element/camera start lifecycle and browser support need verification. Do not weaken headers globally without a reviewed scoped solution. |
| Referrals | `/crew/referrals`, `lib/referrals.mjs`, associated server handlers and migrations | Experimental, default-off test foundation for single-use referral codes; not production employee auth or a complete worker portal. |
| Bubbles / assistant | `app/public/bubbles-widget.js`, `app/owner/assistant/`, `app/api/owner/assistant/`, `app/api/owner/assistant/actions/`, `lib/bubbles-persona.mjs`, `lib/assistant-prompt.mjs`, `lib/server/bubbles-handler.mjs`, `lib/server/bubbles-actions.mjs` | Bubbles widget is mounted in `/workspace`; owner assistant and action code are separate. The owner's read-only assistant has default-off and development gates. **Action endpoint code exists**, so audit its authentication, active organization selection, permissions and explicit approval requirements independently; do not assume all paths are read-only or production-safe. Never claim an action happened unless it actually did. |
| Public assistant | `app/public/public-assistant.js`, `lib/public-assistant/` | Bounded, rule-based public assistant, no private-data access; mounted on the public homepage. |
| Training | `app/training-player.js`, `app/ui.js`, `lib/server/training.mjs`, training migration | Sample lessons and training-record foundation; viewing demo content does not verify training or grant credentials. |
| Security and infrastructure | `proxy.js`, `next.config.mjs`, `lib/server/`, `supabase/migrations/`, `test/` | RLS, vault, access and audit groundwork. Preserve existing protections; verify against dedicated live test infrastructure before any real use. |
| Prior pitch | `/pitch`, `lib/pitch/`, `public/pitch/audio/`, `INVESTOR_PITCH.md` | Historical optional materials included for completeness; not verified as current and not Andy's approved marketing. |

## Design / data flow sketch

```text
Customer / applicant --(EN or ES)--> public site / quote / apply
                              |              |
                       public FAQ       server validation + anti-abuse
                       (no private data)  + idempotency (OFF in production)
                                             |
                                     dedicated test Supabase
                                      RLS-scoped records
                                             |
                         authenticated, authorized owner inbox + audit
                                      |              |
                           onboarding preparation   Bubbles owner assistant

Crew --> /workspace synthetic Bench  [simulation only; no offers]
     --> /crew/scan experimental UI  [no verified check-in integration]
     --> /crew/referrals test code  [off by default]
```

This sketch describes the current architecture and intentions, **not** a promise that every arrow is operational in production. The demo, public site and gated database-backed flows are distinct. CSS colors are partly represented by a large generated `lib/brand-palette.mjs` and partly by direct provisional site colors in `app/globals.css`; brand parameterization is unfinished. The brand-name guard currently covers selected source extensions under `app/` and `lib/`, with the brand config as the central source; it is not a complete trademark/security audit. Maintain the legacy intake storage prefix unless a backward-compatible migration is designed.

## Next AI builder: practical order

1. Run the checks above on the unpacked snapshot. Review browser/axe results, fix regressions, and record actual results; do not claim Playwright passed until it has. The last local check here reported 186 node tests passing and a successful build. Production smoke and secret scan passed on the preceding iteration; Playwright did not run successfully locally because the browser was absent, and **no CI result has been obtained**. Repeat all checks on the final code.
2. Get the owner's original logo and approved legal name, services, service areas, contact details, hours, story, domain and permission for any franchisor content. Preserve the accepted colors and name. Use only approved business facts. Review English/Spanish copy and accessibility with the owner.
3. Review QR capture as an isolated, permission-scoped feature; fix permissions, stream lifecycle, unsupported-browser behavior and validation; define what codes mean and the server-side authorization for check-in or inventory before building real actions. Test on real devices with synthetic data.
4. Define the Bench workflow with the owner: availability, eligibility, offer ordering/timeouts, escalation, overlapping shifts, concurrency and approved notification/consent rules. Implement atomic claims and tests before calling it scheduling. Nothing in the existing simulator sends offers.
5. Complete hiring, intake and onboarding only after owner-approved workflow, secure authentication and live integration tests on a dedicated project. Review anti-abuse, idempotency, authorization, accessibility, privacy, retention, audit and consent. No production login/intake by merely flipping flags.
6. Review Bubbles' exact supported capabilities and permission boundaries. Keep public help separate from private owner functions. Ensure no external action without explicit authorization and confirmation. The Meta AI asset request was explicitly dropped; no verified original Meta asset is in the snapshot, and no repo-native component should be represented as that original asset.
7. Launch gates: approved privacy/terms and data retention; passkeys/device approval and session/step-up controls; test RLS on a dedicated deployed schema; Turnstile/Supabase integration; SMS registration/consent and opt-out before any texts; notification scheduler and alerting; WAF/rate limits, monitoring/backups, legal/franchise review and accessibility. Keep banners and disabled gates until conditions are truly met.

## Database safety / migration history

The archive has 20 local versioned migration files. An earlier connected-project inspection observed 21 remote applied migrations, including a `bubbles_memory_passport` entry not present in these local files; do **not** infer parity or apply this chain to an existing database. The multi-franchise migration explicitly requires a designed and approved backfill before applying its NOT NULL organization changes to populated tables. Assistant tables are not all organization-scoped; audit isolation before multi-org use. Do not create or change any remote project without the owner's approval. Do not put service role keys, encryption keys, API keys or personal data in the new repo.

## Verification and snapshot provenance

Source base commit: `f126acdaccb2d1f2308c62a4095ca8edeaa2dd5f` on the original repo's `main`; snapshot also includes the current branch's uncommitted file changes and new files. The owner has **not** asked for a merge or deployment. Automated checks are point-in-time, not proof of production readiness. The ZIP includes the complete nonignored working source and test files that were available in this checkout; it cannot contain conversations, requirements, approved artwork or assets that were never provided to this workspace. Ask the owner for any missing specifications instead of inventing them.
