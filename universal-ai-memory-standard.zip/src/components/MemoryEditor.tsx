"use client";

import { useState } from "react";
import type { Memory, MemoryType } from "@/lib/types";
import { MEMORY_TYPES } from "@/lib/types";
import { X, Save } from "lucide-react";

interface Props {
  passportId: string;
  memory?: Memory | null;
  onClose: () => void;
  onSaved: (m: Memory) => void;
}

export function MemoryEditor({ passportId, memory, onClose, onSaved }: Props) {
  const [type, setType] = useState<MemoryType>(
    (memory?.type as MemoryType) || "knowledge"
  );
  const [title, setTitle] = useState(memory?.title || "");
  const [content, setContent] = useState(memory?.content || "");
  const [confidence, setConfidence] = useState(
    memory?.confidence ?? 1.0
  );
  const [tagsInput, setTagsInput] = useState(
    (memory?.tags || []).join(", ")
  );
  const [saving, setSaving] = useState(false);

  const isEdit = !!memory;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);

    const tags = tagsInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    const payload = { type, title: title.trim(), content, confidence, tags };

    let res: Response;
    if (isEdit) {
      res = await fetch(`/api/memories/${memory.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      res = await fetch(`/api/passports/${passportId}/memories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    const data = await res.json();
    onSaved(data);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1a1f3a] border border-white/10 shadow-2xl animate-fade-in overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
          <h2 className="text-lg font-bold text-white">
            {isEdit ? "Edit Memory" : "Add Memory"}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Type selector */}
          <div>
            <label className="block text-xs text-slate-400 mb-2">
              Memory Type
            </label>
            <div className="flex flex-wrap gap-2">
              {MEMORY_TYPES.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setType(t.value)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition border"
                  style={{
                    backgroundColor:
                      type === t.value ? `${t.color}20` : "transparent",
                    borderColor:
                      type === t.value ? `${t.color}40` : "rgba(255,255,255,0.06)",
                    color: type === t.value ? t.color : "#94a3b8",
                  }}
                >
                  <span>{t.icon}</span>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Forge Mode project context"
              required
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
            />
          </div>

          {/* Content */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Content
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Describe this memory in detail..."
              rows={5}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition resize-none"
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="forge, project, active"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
            />
          </div>

          {/* Confidence */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Confidence: {Math.round(confidence * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={confidence}
              onChange={(e) => setConfidence(parseFloat(e.target.value))}
              className="w-full accent-passport-500"
            />
          </div>

          <button
            type="submit"
            disabled={saving || !title.trim()}
            className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-passport-600 to-passport-500 hover:from-passport-500 hover:to-passport-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-passport-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="h-4 w-4" />
            {saving ? "Saving…" : isEdit ? "Update Memory" : "Add Memory"}
          </button>
        </form>
      </div>
    </div>
  );
}
