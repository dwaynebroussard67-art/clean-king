"use client";

import { useState, useEffect, useCallback } from "react";
import type { Passport, Memory, PassportStats, MemoryType } from "@/lib/types";
import { MEMORY_TYPES } from "@/lib/types";
import { MemoryCard } from "@/components/MemoryCard";
import { MemoryEditor } from "@/components/MemoryEditor";
import {
  Shield,
  Download,
  Trash2,
  Plus,
  Search,
  Globe,
  Clock,
  Hash,
  Edit3,
  X,
  Save,
} from "lucide-react";

interface Props {
  passport: Passport;
  onDeleted: (id: string) => void;
  onUpdated: (p: Passport) => void;
}

export function PassportDashboard({ passport, onDeleted, onUpdated }: Props) {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [stats, setStats] = useState<PassportStats | null>(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [editingMemory, setEditingMemory] = useState<Memory | null>(null);
  const [showAddMemory, setShowAddMemory] = useState(false);
  const [editingPassport, setEditingPassport] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [loadingMemories, setLoadingMemories] = useState(true);

  // Passport edit state
  const [editName, setEditName] = useState(passport.name);
  const [editPreferredName, setEditPreferredName] = useState(
    passport.preferredName || ""
  );
  const [editTimezone, setEditTimezone] = useState(passport.timezone || "UTC");
  const [editResponseStyle, setEditResponseStyle] = useState(
    passport.responseStyle || "balanced"
  );
  const [editVerbosity, setEditVerbosity] = useState(
    passport.verbosity || "medium"
  );

  const loadMemories = useCallback(async () => {
    setLoadingMemories(true);
    const params = new URLSearchParams();
    if (filter !== "all") params.set("type", filter);
    if (search.trim()) params.set("search", search.trim());
    const res = await fetch(
      `/api/passports/${passport.id}/memories?${params}`
    );
    const data = await res.json();
    setMemories(data);
    setLoadingMemories(false);
  }, [passport.id, filter, search]);

  const loadStats = useCallback(async () => {
    const res = await fetch(`/api/passports/${passport.id}/stats`);
    const data = await res.json();
    setStats(data);
  }, [passport.id]);

  useEffect(() => {
    loadMemories();
    loadStats();
  }, [loadMemories, loadStats]);

  const handleDeleteMemory = async (id: string) => {
    await fetch(`/api/memories/${id}`, { method: "DELETE" });
    setMemories((prev) => prev.filter((m) => m.id !== id));
    loadStats();
  };

  const handleTogglePin = async (m: Memory) => {
    const res = await fetch(`/api/memories/${m.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pinned: !m.pinned }),
    });
    const updated = await res.json();
    setMemories((prev) => prev.map((x) => (x.id === m.id ? updated : x)));
  };

  const handleMemorySaved = (m: Memory) => {
    if (editingMemory) {
      setMemories((prev) => prev.map((x) => (x.id === m.id ? m : x)));
    } else {
      setMemories((prev) => [m, ...prev]);
    }
    setEditingMemory(null);
    setShowAddMemory(false);
    loadStats();
  };

  const handleExport = () => {
    window.open(`/api/passports/${passport.id}/export`, "_blank");
  };

  const handleDeletePassport = async () => {
    await fetch(`/api/passports/${passport.id}`, { method: "DELETE" });
    onDeleted(passport.id);
  };

  const handleSavePassport = async () => {
    const res = await fetch(`/api/passports/${passport.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName,
        preferredName: editPreferredName || null,
        timezone: editTimezone,
        responseStyle: editResponseStyle,
        verbosity: editVerbosity,
      }),
    });
    const updated = await res.json();
    onUpdated(updated);
    setEditingPassport(false);
  };

  return (
    <div className="animate-fade-in">
      {/* Passport Header Card */}
      <div className="rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden mb-6 glow-card">
        <div className="p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-passport-500 to-passport-700 flex items-center justify-center shadow-xl shadow-passport-500/25 shrink-0">
                <Shield className="h-7 w-7 text-white" />
              </div>
              <div>
                {editingPassport ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-white text-lg font-bold focus:border-passport-500 focus:outline-none transition w-full"
                    />
                    <input
                      type="text"
                      value={editPreferredName}
                      onChange={(e) => setEditPreferredName(e.target.value)}
                      placeholder="Preferred name"
                      className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none transition w-full"
                    />
                    <div className="flex gap-2">
                      <select
                        value={editResponseStyle}
                        onChange={(e) => setEditResponseStyle(e.target.value)}
                        className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none transition"
                      >
                        {["balanced","technical","conversational","concise","detailed"].map(s => (
                          <option key={s} value={s} className="bg-[#1a1f3a]">{s}</option>
                        ))}
                      </select>
                      <select
                        value={editVerbosity}
                        onChange={(e) => setEditVerbosity(e.target.value)}
                        className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none transition"
                      >
                        {["low","medium","high"].map(v => (
                          <option key={v} value={v} className="bg-[#1a1f3a]">{v}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={handleSavePassport}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-passport-600 hover:bg-passport-500 text-white text-sm rounded-lg transition"
                      >
                        <Save className="h-3.5 w-3.5" />
                        Save
                      </button>
                      <button
                        onClick={() => setEditingPassport(false)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 text-sm rounded-lg transition"
                      >
                        <X className="h-3.5 w-3.5" />
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h2 className="text-2xl font-bold text-white">
                      {passport.name}
                    </h2>
                    {passport.preferredName && (
                      <p className="text-sm text-slate-400 mt-0.5">
                        aka &ldquo;{passport.preferredName}&rdquo;
                      </p>
                    )}
                    <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Globe className="h-3 w-3" />
                        {passport.timezone || "UTC"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        Created{" "}
                        {new Date(passport.createdAt).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1 text-passport-400">
                        <Hash className="h-3 w-3" />
                        {passport.responseStyle} · {passport.verbosity}
                      </span>
                    </div>
                    {passport.codingLanguages &&
                      passport.codingLanguages.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {passport.codingLanguages.map((lang) => (
                            <span
                              key={lang}
                              className="px-2 py-0.5 rounded-md bg-passport-500/10 text-passport-300 text-xs font-mono"
                            >
                              {lang}
                            </span>
                          ))}
                        </div>
                      )}
                  </>
                )}
              </div>
            </div>

            {/* Actions */}
            {!editingPassport && (
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setEditingPassport(true)}
                  className="p-2 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
                  title="Edit passport"
                >
                  <Edit3 className="h-4 w-4" />
                </button>
                <button
                  onClick={handleExport}
                  className="flex items-center gap-2 px-3 py-2 bg-green-500/10 hover:bg-green-500/20 text-green-400 text-sm font-medium rounded-lg transition border border-green-500/20"
                >
                  <Download className="h-4 w-4" />
                  Export .mpx
                </button>
                {confirmDelete ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleDeletePassport}
                      className="px-3 py-2 bg-red-600 hover:bg-red-500 text-white text-sm rounded-lg transition"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setConfirmDelete(false)}
                      className="px-3 py-2 bg-white/5 hover:bg-white/10 text-slate-300 text-sm rounded-lg transition"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDelete(true)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-slate-400 hover:text-red-400 transition"
                    title="Delete passport"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Stats bar */}
        {stats && (
          <div className="border-t border-white/[0.04] px-6 sm:px-8 py-4">
            <div className="flex flex-wrap gap-4">
              <div className="text-center min-w-[60px]">
                <p className="text-xl font-bold text-white">
                  {stats.totalMemories}
                </p>
                <p className="text-[10px] uppercase tracking-wider text-slate-500">
                  Memories
                </p>
              </div>
              <div className="text-center min-w-[60px]">
                <p className="text-xl font-bold text-yellow-400">
                  {stats.pinnedMemories}
                </p>
                <p className="text-[10px] uppercase tracking-wider text-slate-500">
                  Pinned
                </p>
              </div>
              {MEMORY_TYPES.map((t) => {
                const count = stats.byType[t.value] || 0;
                if (count === 0) return null;
                return (
                  <div key={t.value} className="text-center min-w-[60px]">
                    <p className="text-xl font-bold" style={{ color: t.color }}>
                      {count}
                    </p>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      {t.icon} {t.label}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search memories…"
            className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setFilter("all")}
            className={`px-3 py-2 rounded-lg text-sm whitespace-nowrap transition border ${
              filter === "all"
                ? "bg-white/10 text-white border-white/20"
                : "bg-transparent text-slate-400 border-transparent hover:bg-white/5"
            }`}
          >
            All
          </button>
          {MEMORY_TYPES.map((t) => (
            <button
              key={t.value}
              onClick={() => setFilter(t.value)}
              className="px-3 py-2 rounded-lg text-sm whitespace-nowrap transition border"
              style={{
                backgroundColor:
                  filter === t.value ? `${t.color}15` : "transparent",
                color: filter === t.value ? t.color : "#94a3b8",
                borderColor:
                  filter === t.value ? `${t.color}30` : "transparent",
              }}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Add memory */}
        <button
          onClick={() => setShowAddMemory(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-passport-600 hover:bg-passport-500 text-white text-sm font-medium rounded-xl transition shadow-lg shadow-passport-600/20 whitespace-nowrap"
        >
          <Plus className="h-4 w-4" />
          Add Memory
        </button>
      </div>

      {/* Memories grid */}
      {loadingMemories ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="h-40 rounded-xl bg-white/[0.03] border border-white/[0.06] animate-pulse"
            />
          ))}
        </div>
      ) : memories.length === 0 ? (
        <div className="text-center py-16">
          <div className="h-16 w-16 rounded-2xl bg-white/[0.03] flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">🧠</span>
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">
            {search ? "No memories found" : "No memories yet"}
          </h3>
          <p className="text-sm text-slate-400 mb-4">
            {search
              ? "Try a different search term or filter."
              : "Add your first memory to start building your passport."}
          </p>
          {!search && (
            <button
              onClick={() => setShowAddMemory(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-passport-600 hover:bg-passport-500 text-white text-sm font-medium rounded-xl transition"
            >
              <Plus className="h-4 w-4" />
              Add Memory
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {memories.map((m) => (
            <MemoryCard
              key={m.id}
              memory={m}
              onEdit={setEditingMemory}
              onDelete={handleDeleteMemory}
              onTogglePin={handleTogglePin}
            />
          ))}
        </div>
      )}

      {/* Memory editor modals */}
      {(showAddMemory || editingMemory) && (
        <MemoryEditor
          passportId={passport.id}
          memory={editingMemory}
          onClose={() => {
            setShowAddMemory(false);
            setEditingMemory(null);
          }}
          onSaved={handleMemorySaved}
        />
      )}
    </div>
  );
}
