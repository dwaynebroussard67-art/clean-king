import {
  pgTable,
  uuid,
  text,
  timestamp,
  real,
  jsonb,
  varchar,
  boolean,
} from "drizzle-orm/pg-core";

// ── Passports ──────────────────────────────────────────────────────
export const passports = pgTable("passports", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  preferredName: varchar("preferred_name", { length: 255 }),
  timezone: varchar("timezone", { length: 100 }).default("UTC"),
  language: varchar("language", { length: 50 }).default("English"),
  responseStyle: varchar("response_style", { length: 50 }).default("balanced"),
  verbosity: varchar("verbosity", { length: 20 }).default("medium"),
  codingLanguages: jsonb("coding_languages").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ── Memory Entries ─────────────────────────────────────────────────
export const memories = pgTable("memories", {
  id: uuid("id").defaultRandom().primaryKey(),
  passportId: uuid("passport_id")
    .references(() => passports.id, { onDelete: "cascade" })
    .notNull(),
  type: varchar("type", { length: 50 }).notNull(), // identity | preference | project | knowledge | workflow
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  confidence: real("confidence").default(1.0),
  tags: jsonb("tags").$type<string[]>().default([]),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  pinned: boolean("pinned").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
