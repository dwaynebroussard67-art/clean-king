"use client";

import { useState, useEffect, useCallback } from "react";
import type { Passport } from "@/lib/types";
import { PassportList } from "@/components/PassportList";
import { PassportDashboard } from "@/components/PassportDashboard";
import { LandingHero } from "@/components/LandingHero";
import { CreatePassportModal } from "@/components/CreatePassportModal";
import { ImportModal } from "@/components/ImportModal";
import {
  Shield,
  Plus,
  Upload,
  ChevronLeft,
} from "lucide-react";

export default function HomePage() {
  const [passports, setPassports] = useState<Passport[]>([]);
  const [selected, setSelected] = useState<Passport | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadPassports = useCallback(async () => {
    const res = await fetch("/api/passports");
    const data = await res.json();
    setPassports(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadPassports();
  }, [loadPassports]);

  const handleCreated = (p: Passport) => {
    setPassports((prev) => [p, ...prev]);
    setSelected(p);
    setShowCreate(false);
  };

  const handleImported = (p: Passport) => {
    setPassports((prev) => [p, ...prev]);
    setSelected(p);
    setShowImport(false);
  };

  const handleDeleted = (id: string) => {
    setPassports((prev) => prev.filter((p) => p.id !== id));
    if (selected?.id === id) setSelected(null);
  };

  const handleUpdated = (p: Passport) => {
    setPassports((prev) => prev.map((x) => (x.id === p.id ? p : x)));
    setSelected(p);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-passport-600/20 flex items-center justify-center animate-pulse">
            <Shield className="h-6 w-6 text-passport-400" />
          </div>
          <p className="text-slate-400 text-sm">Loading Memory Passport…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Top navigation */}
      <nav className="sticky top-0 z-50 border-b border-white/5 bg-[#0f1729]/80 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <button
              onClick={() => setSelected(null)}
              className="flex items-center gap-3 hover:opacity-80 transition"
            >
              <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-passport-500 to-passport-700 flex items-center justify-center shadow-lg shadow-passport-500/20">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div>
                <span className="font-bold text-white tracking-tight">
                  Memory Passport
                </span>
                <span className="ml-2 text-[10px] font-mono text-passport-400 bg-passport-400/10 px-1.5 py-0.5 rounded">
                  .mpx
                </span>
              </div>
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowImport(true)}
                className="flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition"
              >
                <Upload className="h-4 w-4" />
                <span className="hidden sm:inline">Import</span>
              </button>
              <button
                onClick={() => setShowCreate(true)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-passport-600 hover:bg-passport-500 rounded-lg transition shadow-lg shadow-passport-600/20"
              >
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">New Passport</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        {selected ? (
          <div>
            <button
              onClick={() => setSelected(null)}
              className="flex items-center gap-1.5 text-sm text-slate-400 hover:text-white mb-4 transition"
            >
              <ChevronLeft className="h-4 w-4" />
              All Passports
            </button>
            <PassportDashboard
              passport={selected}
              onDeleted={handleDeleted}
              onUpdated={handleUpdated}
            />
          </div>
        ) : passports.length === 0 ? (
          <LandingHero
            onCreateClick={() => setShowCreate(true)}
            onImportClick={() => setShowImport(true)}
          />
        ) : (
          <PassportList
            passports={passports}
            onSelect={setSelected}
            onCreateClick={() => setShowCreate(true)}
          />
        )}
      </main>

      {/* Modals */}
      {showCreate && (
        <CreatePassportModal
          onClose={() => setShowCreate(false)}
          onCreated={handleCreated}
        />
      )}
      {showImport && (
        <ImportModal
          onClose={() => setShowImport(false)}
          onImported={handleImported}
        />
      )}
    </div>
  );
}
