import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ memoryId: string }> }
) {
  const { memoryId } = await params;
  const body = await req.json();
  const [row] = await db
    .update(memories)
    .set({ ...body, updatedAt: new Date() })
    .where(eq(memories.id, memoryId))
    .returning();
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(row);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ memoryId: string }> }
) {
  const { memoryId } = await params;
  await db.delete(memories).where(eq(memories.id, memoryId));
  return NextResponse.json({ ok: true });
}
