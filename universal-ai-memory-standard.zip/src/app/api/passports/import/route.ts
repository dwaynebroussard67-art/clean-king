import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports, memories } from "@/db/schema";

interface MpxMemory {
  type?: string;
  title?: string;
  content?: string;
  confidence?: number;
  tags?: string[];
  metadata?: Record<string, unknown>;
  pinned?: boolean;
}

interface MpxData {
  format?: string;
  version?: string;
  passport?: {
    identity?: {
      name?: string;
      preferredName?: string;
      timezone?: string;
      language?: string;
    };
    preferences?: {
      responseStyle?: string;
      verbosity?: string;
      codingLanguages?: string[];
    };
  };
  memories?: MpxMemory[];
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as MpxData;

  if (!body.format || body.format !== "memory-passport-exchange") {
    return NextResponse.json(
      { error: "Invalid .mpx format" },
      { status: 400 }
    );
  }

  const identity = body.passport?.identity || {};
  const prefs = body.passport?.preferences || {};

  const [passport] = await db
    .insert(passports)
    .values({
      name: identity.name || "Imported Passport",
      preferredName: identity.preferredName || null,
      timezone: identity.timezone || "UTC",
      language: identity.language || "English",
      responseStyle: prefs.responseStyle || "balanced",
      verbosity: prefs.verbosity || "medium",
      codingLanguages: prefs.codingLanguages || [],
    })
    .returning();

  const memoryList = body.memories || [];
  if (memoryList.length > 0) {
    await db.insert(memories).values(
      memoryList.map((m) => ({
        passportId: passport.id,
        type: m.type || "knowledge",
        title: m.title || "Untitled",
        content: m.content || "",
        confidence: m.confidence ?? 1.0,
        tags: m.tags || [],
        metadata: m.metadata || {},
        pinned: m.pinned ?? false,
      }))
    );
  }

  return NextResponse.json(
    {
      passport,
      importedMemories: memoryList.length,
    },
    { status: 201 }
  );
}
