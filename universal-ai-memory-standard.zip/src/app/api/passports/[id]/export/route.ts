import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports, memories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const [passport] = await db
    .select()
    .from(passports)
    .where(eq(passports.id, id));
  if (!passport) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const memoryRows = await db
    .select()
    .from(memories)
    .where(eq(memories.passportId, id));

  const mpx = {
    format: "memory-passport-exchange",
    version: "1.0.0",
    exportedAt: new Date().toISOString(),
    passport: {
      id: passport.id,
      identity: {
        name: passport.name,
        preferredName: passport.preferredName,
        timezone: passport.timezone,
        language: passport.language,
      },
      preferences: {
        responseStyle: passport.responseStyle,
        verbosity: passport.verbosity,
        codingLanguages: passport.codingLanguages,
      },
    },
    memories: memoryRows.map((m) => ({
      id: m.id,
      type: m.type,
      title: m.title,
      content: m.content,
      confidence: m.confidence,
      tags: m.tags,
      metadata: m.metadata,
      pinned: m.pinned,
      createdAt: m.createdAt,
      updatedAt: m.updatedAt,
    })),
    stats: {
      totalMemories: memoryRows.length,
      byType: memoryRows.reduce(
        (acc, m) => {
          acc[m.type] = (acc[m.type] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      ),
    },
  };

  const json = JSON.stringify(mpx, null, 2);

  return new NextResponse(json, {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="passport-${passport.name.toLowerCase().replace(/\s+/g, "-")}.mpx"`,
    },
  });
}
