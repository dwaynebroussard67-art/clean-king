import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { eq, desc, and, ilike, or } from "drizzle-orm";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const search = url.searchParams.get("search");

  const conditions = [eq(memories.passportId, id)];

  if (type && type !== "all") {
    conditions.push(eq(memories.type, type));
  }

  let rows;
  if (search) {
    rows = await db
      .select()
      .from(memories)
      .where(
        and(
          ...conditions,
          or(
            ilike(memories.title, `%${search}%`),
            ilike(memories.content, `%${search}%`)
          )
        )
      )
      .orderBy(desc(memories.pinned), desc(memories.updatedAt));
  } else {
    rows = await db
      .select()
      .from(memories)
      .where(and(...conditions))
      .orderBy(desc(memories.pinned), desc(memories.updatedAt));
  }

  return NextResponse.json(rows);
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const [row] = await db
    .insert(memories)
    .values({
      passportId: id,
      type: body.type || "knowledge",
      title: body.title || "Untitled",
      content: body.content || "",
      confidence: body.confidence ?? 1.0,
      tags: body.tags || [],
      metadata: body.metadata || {},
      pinned: body.pinned ?? false,
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
