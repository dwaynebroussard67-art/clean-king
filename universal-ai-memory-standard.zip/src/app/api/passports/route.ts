import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(passports).orderBy(desc(passports.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const [row] = await db
    .insert(passports)
    .values({
      name: body.name || "Unnamed",
      preferredName: body.preferredName || null,
      timezone: body.timezone || "UTC",
      language: body.language || "English",
      responseStyle: body.responseStyle || "balanced",
      verbosity: body.verbosity || "medium",
      codingLanguages: body.codingLanguages || [],
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
