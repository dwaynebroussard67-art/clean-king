import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Memory Passport — Own Your AI Memory",
  description:
    "The universal, user-controlled memory standard. One format. Any platform. Move your AI context between systems without starting over.",
  openGraph: {
    title: "Memory Passport — Own Your AI Memory",
    description:
      "One format. Any platform. Move your AI context between systems without starting over.",
    images: ["/images/og-image.png"],
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="text-white antialiased">{children}</body>
    </html>
  );
}
