export interface Passport {
  id: string;
  name: string;
  preferredName: string | null;
  timezone: string | null;
  language: string | null;
  responseStyle: string | null;
  verbosity: string | null;
  codingLanguages: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Memory {
  id: string;
  passportId: string;
  type: string;
  title: string;
  content: string;
  confidence: number | null;
  tags: string[];
  metadata: Record<string, unknown>;
  pinned: boolean | null;
  createdAt: string;
  updatedAt: string;
}

export type MemoryType =
  | "project"
  | "knowledge"
  | "workflow"
  | "preference"
  | "identity";

export const MEMORY_TYPES: {
  value: MemoryType;
  label: string;
  color: string;
  icon: string;
}[] = [
  { value: "project", label: "Project", color: "#4c6ef5", icon: "📁" },
  { value: "knowledge", label: "Knowledge", color: "#37b24d", icon: "🧠" },
  { value: "workflow", label: "Workflow", color: "#f59f00", icon: "⚡" },
  { value: "preference", label: "Preference", color: "#ae3ec9", icon: "⚙️" },
  { value: "identity", label: "Identity", color: "#1098ad", icon: "👤" },
];

export interface PassportStats {
  totalMemories: number;
  pinnedMemories: number;
  byType: Record<string, number>;
}
