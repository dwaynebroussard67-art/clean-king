import { pgTable, uuid, text, timestamp, boolean, integer, jsonb, pgEnum } from 'drizzle-orm/pg-core';

export const applicantStatusEnum = pgEnum('applicant_status', ['pending', 'hired', 'passed']);

export const applicants = pgTable('applicants', {
  id: uuid('id').primaryKey().defaultRandom(),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  phone: text('phone').notNull(),
  email: text('email'),
  area: text('area').notNull(),
  availability: text('availability').notNull(),
  transportation: text('transportation').notNull(),
  languages: text('languages').notNull(),
  referralSource: text('referral_source'),
  status: text('status').$type<'pending' | 'hired' | 'passed'>().default('pending').notNull(),
  experienceQuestions: jsonb('experience_questions'),
  smsConsent: boolean('sms_consent').default(false),
  smsConsentTimestamp: timestamp('sms_consent_timestamp'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const quotes = pgTable('quotes', {
  id: uuid('id').primaryKey().defaultRandom(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  phone: text('phone').notNull(),
  serviceType: text('service_type').notNull(),
  area: text('area').notNull(),
  details: text('details'),
  status: text('status').default('new').notNull(), // new, contacted, quoted, closed
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const employees = pgTable('employees', {
  id: uuid('id').primaryKey().defaultRandom(),
  applicantId: uuid('applicant_id').references(() => applicants.id),
  firstName: text('first_name').notNull(),
  lastName: text('last_name').notNull(),
  email: text('email').unique(),
  phone: text('phone'),
  role: text('role').default('worker').notNull(), // worker, owner
  isActive: boolean('is_active').default(true).notNull(),
  hasRookieRun: boolean('has_rookie_run').default(false).notNull(),
  hasHealthTrack: boolean('has_health_track').default(false).notNull(),
  hasSchoolClearance: boolean('has_school_clearance').default(false).notNull(),
  weeklyHours: integer('weekly_hours').default(0).notNull(),
  hourCap: integer('hour_cap').default(40).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const onboardingRecords = pgTable('onboarding_records', {
  id: uuid('id').primaryKey().defaultRandom(),
  applicantId: uuid('applicant_id').references(() => applicants.id).notNull(),
  employeeId: uuid('employee_id').references(() => employees.id),
  status: text('status').default('in_progress').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const onboardingTasks = pgTable('onboarding_tasks', {
  id: uuid('id').primaryKey().defaultRandom(),
  onboardingRecordId: uuid('onboarding_record_id').references(() => onboardingRecords.id).notNull(),
  title: text('title').notNull(),
  description: text('description'),
  isCompleted: boolean('is_completed').default(false).notNull(),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').primaryKey().defaultRandom(),
  actorId: uuid('actor_id'), // Reference to employee or owner
  action: text('action').notNull(),
  entityType: text('entity_type').notNull(),
  entityId: uuid('entity_id').notNull(),
  details: jsonb('details'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const referralInvitations = pgTable('referral_invitations', {
  id: uuid('id').primaryKey().defaultRandom(),
  referrerId: uuid('referrer_id').references(() => employees.id).notNull(),
  codeHash: text('code_hash').notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  isConsumed: boolean('is_consumed').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});
