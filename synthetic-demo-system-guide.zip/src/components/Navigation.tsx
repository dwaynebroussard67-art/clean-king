'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Menu, X, Crown } from 'lucide-react';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';

export function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  const links = [
    { href: '/services', label: 'Services' },
    { href: '/quote', label: 'Get a Quote' },
    { href: '/apply', label: 'Join Our Team' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <div className="w-8 h-8 bg-[#800000] rounded-lg flex items-center justify-center group-hover:bg-[#6a0505] transition-colors">
              <Crown className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-extrabold tracking-tight text-gray-900">
              Clean<span className="text-[#800000]">King</span>
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center space-x-1">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={cn(
                  'px-4 py-2 rounded-md text-sm font-medium transition-colors',
                  pathname === l.href
                    ? 'bg-[#800000]/10 text-[#800000]'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                )}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-3">
            <Link
              href="/owner"
              className="text-sm font-medium text-gray-500 hover:text-gray-900 transition-colors px-3 py-2"
            >
              Owner Portal
            </Link>
            <Link
              href="/quote"
              className="bg-[#800000] hover:bg-[#6a0505] text-white text-sm font-semibold px-5 py-2 rounded-lg transition-colors shadow-sm"
            >
              Get a Quote
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 rounded-md text-gray-500 hover:text-gray-900 hover:bg-gray-50"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-gray-100 bg-white px-4 py-4 space-y-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              {l.label}
            </Link>
          ))}
          <div className="pt-3 border-t border-gray-100 space-y-2">
            <Link
              href="/owner"
              onClick={() => setOpen(false)}
              className="block px-3 py-2 rounded-md text-sm font-medium text-gray-500 hover:bg-gray-50"
            >
              Owner Portal
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
