'use client';

import { useState } from 'react';
import { MapPin, Phone, Clock, FileText, ChevronRight, CheckCircle, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

const content = {
  en: {
    title: 'My Site Guide',
    siteName: "St. Jude's Medical Center",
    address: '123 Healthcare Ave, Westside',
    supervisor: 'Sarah Miller',
    shift: '6:00 PM – 10:00 PM',
    clearanceLabel: 'Health Track Required',
    instructions: [
      'Check in at the Security Desk (Entrance B).',
      'Use your badge for elevator access to the 4th floor.',
      'Mask and gloves are required at all times in patient areas.',
      'Biohazard bins are marked in red — do not use for general waste.',
      'Sign the cleaning log outside each room before moving on.',
    ],
    getDirections: 'Get Directions',
    viewTraining: 'Training Modules',
    langLabel: 'English',
  },
  es: {
    title: 'Mi Guía de Sitio',
    siteName: 'Centro Médico St. Jude',
    address: '123 Healthcare Ave, Westside',
    supervisor: 'Sarah Miller',
    shift: '6:00 PM – 10:00 PM',
    clearanceLabel: 'Requiere Vía de Salud',
    instructions: [
      'Regístrese en el mostrador de seguridad (Entrada B).',
      'Use su credencial para acceder al ascensor del piso 4.',
      'Se requiere mascarilla y guantes en todo momento en áreas de pacientes.',
      'Los contenedores de riesgo biológico están marcados en rojo — no use para residuos generales.',
      'Firme el registro de limpieza fuera de cada habitación antes de continuar.',
    ],
    getDirections: 'Obtener Direcciones',
    viewTraining: 'Módulos de Entrenamiento',
    langLabel: 'Español',
  },
};

export default function SiteGuidePage() {
  const [lang, setLang] = useState<'en' | 'es'>('en');
  const t = content[lang];

  return (
    <div className="max-w-sm mx-auto min-h-screen bg-gray-50 pb-10">
      {/* Header */}
      <div className="bg-[#800000] text-white px-5 pt-5 pb-10 rounded-b-3xl">
        <div className="flex justify-between items-center mb-5">
          <Link href="/" className="text-white/70 hover:text-white p-1">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex space-x-1 bg-[#6a0505] rounded-full p-1">
            {(['en', 'es'] as const).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`text-xs font-bold px-3 py-1 rounded-full transition-all ${lang === l ? 'bg-white text-[#800000]' : 'text-white/70 hover:text-white'}`}
              >
                {l === 'en' ? 'EN' : 'ES'}
              </button>
            ))}
          </div>
        </div>
        <p className="text-white/70 text-xs font-semibold uppercase tracking-widest">Clean King</p>
        <h1 className="text-2xl font-extrabold mt-1">{t.title}</h1>
      </div>

      <div className="px-4 -mt-5 space-y-4">
        {/* Site card */}
        <div className="bg-white rounded-2xl shadow-md border border-gray-100 p-5">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-lg font-bold text-gray-900">{t.siteName}</h2>
              <div className="flex items-center text-gray-500 text-sm mt-1 space-x-1">
                <MapPin className="w-3.5 h-3.5" />
                <span>{t.address}</span>
              </div>
            </div>
            <span className="text-[11px] font-bold bg-green-50 text-green-700 border border-green-200 px-2 py-1 rounded-full">
              {t.clearanceLabel}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4 border-t border-gray-100">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-50 text-blue-600 p-1.5 rounded-lg">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] text-gray-400 font-semibold uppercase">Shift</p>
                <p className="text-sm font-semibold text-gray-900">{t.shift}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="bg-purple-50 text-purple-600 p-1.5 rounded-lg">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[10px] text-gray-400 font-semibold uppercase">Supervisor</p>
                <p className="text-sm font-semibold text-gray-900">{t.supervisor}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Directions */}
        <button
          onClick={() => alert('Demo: directions are not connected to a real address.')}
          className="w-full bg-[#800000] hover:bg-[#6a0505] text-white font-bold py-4 rounded-2xl shadow-md flex items-center justify-center space-x-2 transition-all active:scale-95"
        >
          <MapPin className="w-5 h-5" />
          <span>{t.getDirections}</span>
        </button>

        {/* Instructions */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-gray-100 flex items-center space-x-2">
            <FileText className="w-4 h-4 text-[#800000]" />
            <h3 className="font-bold text-gray-900 text-sm">Site Instructions</h3>
          </div>
          <ul className="p-4 space-y-3">
            {t.instructions.map((inst, i) => (
              <li key={i} className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-[#800000]/10 text-[#800000] rounded-full flex items-center justify-center flex-shrink-0 text-xs font-extrabold mt-0.5">
                  {i + 1}
                </div>
                <p className="text-sm text-gray-700 leading-relaxed">{inst}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Training link */}
        <Link
          href="/crew/training"
          className="bg-white rounded-2xl border border-gray-200 shadow-sm p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center space-x-3">
            <div className="bg-[#800000]/10 text-[#800000] p-2 rounded-lg">
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-gray-900 text-sm">{t.viewTraining}</p>
              <p className="text-xs text-gray-500">3-module certification track</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </Link>
      </div>
    </div>
  );
}
