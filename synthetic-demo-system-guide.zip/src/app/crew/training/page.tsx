'use client';

import { useState } from 'react';
import { Play, CheckCircle, Lock, ArrowLeft, Award, Clock } from 'lucide-react';
import Link from 'next/link';

const lessons = [
  {
    title: 'Safety & Hygiene Fundamentals',
    duration: '12 min',
    description: 'PPE requirements, chemical safety, and MSDS basics. Required for all crew members.',
    topics: ['PPE selection & usage', 'Chemical labeling (GHS)', 'Spill response', 'Cross-contamination prevention'],
  },
  {
    title: 'Healthcare Environment Protocols',
    duration: '18 min',
    description: 'Sterile environment maintenance, biohazard handling, and infection control compliance.',
    topics: ['Sterile technique basics', 'Biohazard disposal', 'Infection control', 'Patient area restrictions'],
  },
  {
    title: 'Professional Standards & Communication',
    duration: '10 min',
    description: 'Site behavior, supervisor communication, and client interaction best practices.',
    topics: ['Professional conduct', 'Supervisor check-in protocol', 'Incident reporting', 'Time & log management'],
  },
];

export default function TrainingPage() {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [expanded, setExpanded] = useState<number | null>(0);
  const allDone = completedSteps.length === lessons.length;

  const handleComplete = (index: number) => {
    if (!completedSteps.includes(index)) {
      setCompletedSteps(prev => [...prev, index]);
      if (index < lessons.length - 1) setExpanded(index + 1);
    }
  };

  return (
    <div className="max-w-sm mx-auto min-h-screen bg-gray-50 pb-10">
      {/* Header */}
      <div className="bg-gray-900 text-white px-5 pt-5 pb-10 rounded-b-3xl">
        <div className="flex items-center justify-between mb-5">
          <Link href="/crew/guide" className="text-white/60 hover:text-white p-1">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <span className="text-xs font-semibold text-white/50">{completedSteps.length}/{lessons.length} complete</span>
        </div>
        <p className="text-white/60 text-xs font-semibold uppercase tracking-widest">Clean King</p>
        <h1 className="text-2xl font-extrabold mt-1">Training Modules</h1>

        {/* Progress bar */}
        <div className="mt-5">
          <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-white rounded-full transition-all duration-700"
              style={{ width: `${(completedSteps.length / lessons.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="px-4 -mt-5 space-y-3">
        {/* Completion banner */}
        {allDone && (
          <div className="bg-green-600 text-white rounded-2xl p-5 shadow-lg flex items-center space-x-4">
            <div className="bg-white/20 p-2 rounded-xl">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <p className="font-extrabold text-lg">Rookie Run Earned!</p>
              <p className="text-green-100 text-sm">All 3 modules complete. Contact your supervisor.</p>
            </div>
          </div>
        )}

        {lessons.map((lesson, index) => {
          const isCompleted = completedSteps.includes(index);
          const isLocked = index > 0 && !completedSteps.includes(index - 1);
          const isExpanded = expanded === index && !isLocked;

          return (
            <div
              key={index}
              className={`bg-white rounded-2xl border shadow-sm overflow-hidden transition-all ${
                isLocked ? 'opacity-60 border-gray-100' : 'border-gray-200 hover:shadow-md'
              }`}
            >
              <button
                className="w-full p-5 text-left flex items-center justify-between"
                onClick={() => !isLocked && setExpanded(isExpanded ? null : index)}
                disabled={isLocked}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    isCompleted ? 'bg-green-100 text-green-600' :
                    isLocked ? 'bg-gray-100 text-gray-400' :
                    'bg-[#800000]/10 text-[#800000]'
                  }`}>
                    {isCompleted ? <CheckCircle className="w-5 h-5" /> :
                     isLocked ? <Lock className="w-4 h-4" /> :
                     <span className="text-sm font-extrabold">{index + 1}</span>}
                  </div>
                  <div className="text-left">
                    <p className={`font-bold text-sm ${isLocked ? 'text-gray-400' : 'text-gray-900'}`}>
                      {lesson.title}
                    </p>
                    <div className="flex items-center space-x-1 text-xs text-gray-400 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{lesson.duration}</span>
                    </div>
                  </div>
                </div>
                {isCompleted && (
                  <span className="text-[11px] font-bold text-green-600 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full">Done</span>
                )}
              </button>

              {isExpanded && (
                <div className="px-5 pb-5 border-t border-gray-100">
                  <p className="text-sm text-gray-600 mt-4 mb-3 leading-relaxed">{lesson.description}</p>
                  <ul className="space-y-1.5 mb-5">
                    {lesson.topics.map((topic) => (
                      <li key={topic} className="flex items-center space-x-2 text-sm text-gray-700">
                        <div className="w-1.5 h-1.5 bg-[#800000] rounded-full" />
                        <span>{topic}</span>
                      </li>
                    ))}
                  </ul>
                  {!isCompleted && (
                    <button
                      onClick={() => handleComplete(index)}
                      className="w-full bg-[#800000] hover:bg-[#6a0505] text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center space-x-2 active:scale-95"
                    >
                      <Play className="w-4 h-4" />
                      <span>Mark Complete</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <p className="text-center text-xs text-gray-400 italic mt-8 px-4">
        No watch-time tracking or certificates are issued in this demonstration.
      </p>
    </div>
  );
}
