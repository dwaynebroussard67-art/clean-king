'use server';

import { db } from '@/db';
import { applicants } from '@/db/schema';

export async function submitApplication(formData: FormData) {
  const firstName = formData.get('firstName') as string;
  const lastName = formData.get('lastName') as string;
  const phone = formData.get('phone') as string;
  const email = formData.get('email') as string | null;
  const area = formData.get('area') as string;
  const availability = formData.get('availability') as string;
  const transportation = formData.get('transportation') as string;
  const languages = formData.get('languages') as string;
  const referralSource = formData.get('referralSource') as string | null;
  const smsConsent = formData.get('smsConsent') === 'on';

  if (!firstName || !lastName || !phone || !area || !availability || !transportation || !languages) {
    return { success: false, error: 'All required fields must be filled in.' };
  }

  try {
    await db.insert(applicants).values({
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      phone: phone.trim(),
      email: email ? email.trim().toLowerCase() : null,
      area: area.trim(),
      availability: availability.trim(),
      transportation,
      languages: languages.trim(),
      referralSource: referralSource ? referralSource.trim() : null,
      smsConsent,
      smsConsentTimestamp: smsConsent ? new Date() : null,
      status: 'pending',
    });

    return { success: true };
  } catch (error) {
    console.error('Failed to submit application:', error);
    return { success: false, error: 'Could not save your application. Please try again.' };
  }
}
