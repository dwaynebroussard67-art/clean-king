import type { Metadata } from 'next';
import { ApplyForm } from './ApplyForm';
import { CheckCircle, Clock, Star, Users } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Join Our Team',
  description: 'Apply to join the Clean King crew. Flexible hours, competitive pay, and specialized training.',
};

export default function ApplyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Left: Info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <span className="text-sm font-bold text-[#800000] uppercase tracking-widest">Join the Team</span>
              <h1 className="mt-3 text-3xl sm:text-4xl font-extrabold text-gray-900 leading-tight">
                Build a career in professional cleaning
              </h1>
              <p className="mt-4 text-gray-500 leading-relaxed">
                Clean King crew members are the best in the business. We invest in training, pay competitively, and treat every team member with respect.
              </p>
            </div>

            <div className="space-y-4">
              {[
                { icon: Clock, title: 'Flexible Schedules', desc: 'Morning, evening, and weekend shifts available.' },
                { icon: Star, title: 'Specialized Training', desc: 'Earn certifications for school and healthcare sites — and higher pay.' },
                { icon: Users, title: 'Bilingual Teams', desc: 'English and Spanish speaking supervisors.' },
                { icon: CheckCircle, title: 'Referral Bonuses', desc: 'Bring in someone great and get rewarded.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start space-x-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                  <div className="w-9 h-9 bg-[#800000]/10 text-[#800000] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                    <item.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{item.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#800000] rounded-2xl p-6 text-white">
              <p className="text-sm font-medium text-white/80 mb-1">Questions?</p>
              <p className="font-bold text-lg">careers@cleanking.com</p>
              <p className="text-sm text-white/70 mt-1">We respond within 1 business day.</p>
            </div>
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-3">
            <ApplyForm />
          </div>
        </div>
      </div>
    </div>
  );
}
