'use client';

import { useState } from 'react';
import { submitApplication } from './actions';
import { CheckCircle, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const areas = ['Downtown', 'Northside', 'Southside', 'Eastside', 'Westside', 'Suburbs'];
const transportOptions = [
  { value: 'own_vehicle', label: 'Own vehicle' },
  { value: 'public_transit', label: 'Public transit' },
  { value: 'rideshare', label: 'Rideshare (Uber/Lyft)' },
  { value: 'no_reliable', label: 'No reliable transportation' },
];

export function ApplyForm() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus('submitting');
    setError(null);
    try {
      const formData = new FormData(e.currentTarget);
      const result = await submitApplication(formData);
      if (result.success) {
        setStatus('success');
      } else {
        setStatus('error');
        setError(result.error || 'Something went wrong. Please try again.');
      }
    } catch {
      setStatus('error');
      setError('An unexpected error occurred. Please try again.');
    }
  }

  if (status === 'success') {
    return (
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 text-center">
        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-9 h-9" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-3">Application Received!</h2>
        <p className="text-gray-500 mb-8 max-w-sm mx-auto">
          Thank you for applying to Clean King. Our team will review your application and reach out within 3–5 business days.
        </p>
        <Link
          href="/"
          className="inline-flex items-center bg-[#800000] hover:bg-[#6a0505] text-white px-7 py-3 rounded-xl font-bold transition-all"
        >
          Back to Home <ArrowRight className="ml-2 w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-8 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-900">Your Application</h2>
        <p className="text-sm text-gray-500 mt-1">All fields marked * are required.</p>
      </div>

      <div className="p-8 space-y-6">
        {/* Name row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">First Name *</label>
            <input
              name="firstName"
              required
              autoComplete="given-name"
              placeholder="Maria"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Last Name *</label>
            <input
              name="lastName"
              required
              autoComplete="family-name"
              placeholder="Gonzalez"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
        </div>

        {/* Contact row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Phone Number *</label>
            <input
              name="phone"
              type="tel"
              required
              autoComplete="tel"
              placeholder="(555) 000-0000"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Email Address</label>
            <input
              name="email"
              type="email"
              autoComplete="email"
              placeholder="maria@example.com"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
        </div>

        {/* Area */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Preferred Work Area *</label>
          <select
            name="area"
            required
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
          >
            <option value="">Select an area…</option>
            {areas.map((a) => <option key={a} value={a.toLowerCase()}>{a}</option>)}
          </select>
        </div>

        {/* Availability */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">General Availability *</label>
          <textarea
            name="availability"
            required
            rows={3}
            placeholder="e.g. Weekday mornings, all day weekends, evenings after 5pm…"
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors resize-none"
          />
        </div>

        {/* Transportation + Languages */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Transportation *</label>
            <select
              name="transportation"
              required
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            >
              {transportOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Languages Spoken *</label>
            <input
              name="languages"
              required
              placeholder="e.g. English, Spanish"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
        </div>

        {/* Referral */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">How did you hear about us?</label>
          <input
            name="referralSource"
            placeholder="Indeed, a friend, Google…"
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
          />
        </div>

        {/* SMS Consent */}
        <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
          <input
            type="checkbox"
            name="smsConsent"
            id="smsConsent"
            className="mt-0.5 h-4 w-4 rounded border-gray-300 text-[#800000] focus:ring-[#800000]"
          />
          <label htmlFor="smsConsent" className="text-sm text-gray-600 leading-relaxed">
            I consent to receive SMS notifications about my application status and scheduling updates from Clean King. Message and data rates may apply. Reply STOP to opt out.
          </label>
        </div>

        {/* Error */}
        {status === 'error' && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={status === 'submitting'}
          className="w-full bg-[#800000] hover:bg-[#6a0505] disabled:opacity-60 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded-xl transition-all shadow-sm flex items-center justify-center text-sm"
        >
          {status === 'submitting' ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Submitting…
            </>
          ) : (
            <>
              Submit Application
              <ArrowRight className="ml-2 w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </form>
  );
}
