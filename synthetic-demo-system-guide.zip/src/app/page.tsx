import Link from 'next/link';
import Image from 'next/image';
import { CheckCircle, Shield, Clock, Languages, Star, ArrowRight, Building2, Heart, GraduationCap, Sparkles } from 'lucide-react';

const services = [
  {
    icon: GraduationCap,
    title: 'Educational Facilities',
    description: 'School-cleared crews trained in safe chemical handling around students. Daily, weekly, and deep-clean programs.',
    color: 'bg-blue-50 text-blue-700',
  },
  {
    icon: Heart,
    title: 'Healthcare Facilities',
    description: 'Health-track certified staff with biohazard protocols, sterile environment maintenance, and infection control compliance.',
    color: 'bg-red-50 text-red-700',
  },
  {
    icon: Building2,
    title: 'Commercial Offices',
    description: 'Flexible programs for offices, retail, and mixed-use spaces — before-hours, after-hours, or on-demand.',
    color: 'bg-purple-50 text-purple-700',
  },
  {
    icon: Sparkles,
    title: 'Specialty Deep Cleans',
    description: 'Post-construction, event, and move-in/move-out deep cleaning with industry-grade equipment.',
    color: 'bg-amber-50 text-amber-700',
  },
];

const stats = [
  { value: '500+', label: 'Facilities Served' },
  { value: '98%', label: 'Client Retention' },
  { value: '24h', label: 'Response Time' },
  { value: '100%', label: 'Background Checked' },
];

const testimonials = [
  {
    quote: "Our school has never been cleaner. The crew is professional, reliable, and always respectful of our students and staff.",
    author: "Maria T.",
    role: "Facilities Director, Roosevelt Elementary",
    rating: 5,
  },
  {
    quote: "Switching to Clean King was the best operational decision we made this year. Consistent quality every single visit.",
    author: "James P.",
    role: "Office Manager, Westside Medical Group",
    rating: 5,
  },
  {
    quote: "The team is fast, thorough, and they communicate proactively. I never have to follow up.",
    author: "Sandra K.",
    role: "Property Manager, Northside Commercial",
    rating: 5,
  },
];

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden bg-gray-900">
        <Image
          src="/hero-cleaning.jpg"
          alt="Clean King professional crew in a modern facility"
          fill
          className="object-cover opacity-40"
          priority
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/80 via-gray-900/50 to-transparent" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 w-full">
          <div className="max-w-2xl">
            <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-1.5 mb-6">
              <Shield className="w-4 h-4 text-[#f0a0a0]" />
              <span className="text-sm font-medium text-white/90">Background-verified crews · Health & school certified</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
              Commercial Cleaning<br />
              <span className="text-[#f0a0a0]">Done Right.</span>
            </h1>
            <p className="text-lg sm:text-xl text-white/80 mb-10 leading-relaxed">
              Vetted, trained, and certified crews for schools, hospitals, and high-standards facilities. Reliable service you can count on every shift.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/quote"
                className="inline-flex items-center justify-center bg-[#800000] hover:bg-[#6a0505] text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5"
              >
                Get a Free Quote
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link
                href="/services"
                className="inline-flex items-center justify-center bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all"
              >
                View Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-[#800000] py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-3xl font-extrabold text-white">{s.value}</div>
                <div className="text-sm font-medium text-white/70 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Clean King */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sm font-bold text-[#800000] uppercase tracking-widest">Why Choose Us</span>
            <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-gray-900">Built for high-stakes environments</h2>
            <p className="mt-4 text-xl text-gray-500 max-w-2xl mx-auto">
              We don't just clean — we maintain the standards your facility requires.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Shield, title: 'Fully Vetted', desc: 'Every crew member passes a background check and site-specific clearance before their first shift.', color: 'bg-[#800000]/10 text-[#800000]' },
              { icon: CheckCircle, title: 'Quality Assured', desc: 'Post-service inspections and supervisor sign-offs ensure consistent results every visit.', color: 'bg-green-100 text-green-700' },
              { icon: Clock, title: 'Always On Time', desc: 'Bench management keeps backup-ready crews available so you are never left without coverage.', color: 'bg-blue-100 text-blue-700' },
              { icon: Languages, title: 'Bilingual Crews', desc: 'English and Spanish speaking teams ready to communicate clearly with your staff.', color: 'bg-amber-100 text-amber-700' },
            ].map((item) => (
              <div key={item.title} className="group bg-white border border-gray-100 rounded-2xl p-7 hover:shadow-lg hover:border-gray-200 transition-all">
                <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center mb-5`}>
                  <item.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16">
            <div>
              <span className="text-sm font-bold text-[#800000] uppercase tracking-widest">Our Services</span>
              <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-gray-900">What we clean</h2>
            </div>
            <Link href="/services" className="mt-4 md:mt-0 inline-flex items-center text-sm font-semibold text-[#800000] hover:text-[#6a0505]">
              View all services <ArrowRight className="ml-1 w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((s) => (
              <div key={s.title} className="bg-white rounded-2xl p-8 border border-gray-100 hover:shadow-md transition-all group">
                <div className={`w-12 h-12 ${s.color} rounded-xl flex items-center justify-center mb-5`}>
                  <s.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{s.title}</h3>
                <p className="text-gray-500 leading-relaxed">{s.description}</p>
                <Link href="/quote" className="mt-4 inline-flex items-center text-sm font-semibold text-[#800000] hover:text-[#6a0505] group-hover:underline">
                  Request this service <ArrowRight className="ml-1 w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sm font-bold text-[#800000] uppercase tracking-widest">Client Reviews</span>
            <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-gray-900">Trusted by facilities managers</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.author} className="bg-gray-50 rounded-2xl p-8 border border-gray-100">
                <div className="flex mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-gray-700 leading-relaxed mb-6 italic">&ldquo;{t.quote}&rdquo;</p>
                <div>
                  <p className="font-bold text-gray-900">{t.author}</p>
                  <p className="text-sm text-gray-500">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Split */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Client CTA */}
            <div className="bg-[#800000] rounded-3xl p-10 text-white flex flex-col justify-between min-h-[280px]">
              <div>
                <h3 className="text-2xl font-extrabold mb-3">Need a cleaning crew?</h3>
                <p className="text-white/80 leading-relaxed mb-8">
                  Tell us about your facility and we'll put together a custom quote — usually within one business day.
                </p>
              </div>
              <Link
                href="/quote"
                className="self-start inline-flex items-center bg-white text-[#800000] hover:bg-gray-100 px-7 py-3 rounded-xl font-bold transition-all shadow-lg"
              >
                Request a Quote <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>

            {/* Worker CTA */}
            <div className="bg-white border border-gray-200 rounded-3xl p-10 flex flex-col justify-between min-h-[280px]">
              <div>
                <h3 className="text-2xl font-extrabold text-gray-900 mb-3">Looking for work?</h3>
                <p className="text-gray-500 leading-relaxed mb-6">
                  Join the Clean King crew. Flexible schedules, competitive pay, and specialized training for school and healthcare sites.
                </p>
                <ul className="space-y-2 mb-8">
                  {['Flexible shifts', 'Specialized certifications', 'Bilingual teams welcome', 'Referral bonuses'].map((item) => (
                    <li key={item} className="flex items-center text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <Link
                href="/apply"
                className="self-start inline-flex items-center border-2 border-[#800000] text-[#800000] hover:bg-[#800000] hover:text-white px-7 py-3 rounded-xl font-bold transition-all"
              >
                Apply Now <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-gray-800">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-[#800000] rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">CK</span>
                </div>
                <span className="text-xl font-extrabold">Clean<span className="text-[#f0a0a0]">King</span></span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
                Professional commercial cleaning for schools, hospitals, offices, and high-standards facilities. Vetted crews. Guaranteed quality.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-widest">Company</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><Link href="/services" className="hover:text-white transition-colors">Services</Link></li>
                <li><Link href="/quote" className="hover:text-white transition-colors">Get a Quote</Link></li>
                <li><Link href="/apply" className="hover:text-white transition-colors">Join Our Team</Link></li>
                <li><Link href="/owner" className="hover:text-white transition-colors">Owner Portal</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-widest">Contact</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li>info@cleanking.com</li>
                <li>1 (800) 255-3264</li>
                <li>Mon–Fri 7am – 6pm</li>
              </ul>
            </div>
          </div>
          <div className="pt-8 flex flex-col sm:flex-row justify-between items-center text-sm text-gray-500">
            <p>© {new Date().getFullYear()} Clean King. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 sm:mt-0">
              <Link href="/privacy" className="hover:text-gray-300 transition-colors">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-gray-300 transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
