'use client';

import { useState } from 'react';
import { Zap, X, CheckCircle, AlertCircle } from 'lucide-react';

type Employee = {
  id: string;
  firstName: string;
  lastName: string;
  hasRookieRun: boolean;
  hasHealthTrack: boolean;
  hasSchoolClearance: boolean;
  weeklyHours: number;
  hourCap: number;
};

export function CalloutSimulation({ employees }: { employees: Employee[] }) {
  const [isOpen, setIsOpen] = useState(false);
  const [type, setType] = useState<'school' | 'hospital'>('school');
  const [result, setResult] = useState<any>(null);

  function simulate() {
    const eligible = employees.filter(e => {
      // Basic checks
      if (!e.hasRookieRun) return false;
      if (e.weeklyHours >= e.hourCap) return false;
      
      // Type specific
      if (type === 'school' && !e.hasSchoolClearance) return false;
      if (type === 'hospital' && !e.hasHealthTrack) return false;
      
      return true;
    });

    if (eligible.length > 0) {
      setResult({
        success: true,
        worker: eligible[0],
        message: `Found eligible worker: ${eligible[0].firstName} ${eligible[0].lastName}`,
      });
    } else {
      setResult({
        success: false,
        message: 'No eligible workers found for this call-out.',
      });
    }
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="bg-maroon-700 hover:bg-maroon-800 text-white font-bold py-2 px-4 rounded-md transition flex items-center shadow-md"
      >
        <Zap className="w-4 h-4 mr-2" />
        Simulate Call-out
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-900 flex items-center">
                <Zap className="w-4 h-4 mr-2 text-maroon-700" />
                Call-out Simulator
              </h3>
              <button onClick={() => { setIsOpen(false); setResult(null); }} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {!result ? (
                <>
                  <p className="text-sm text-gray-600">
                    Test the call-out logic for schools or hospitals. The system will find the first eligible worker who meets all requirements.
                  </p>
                  
                  <div className="space-y-3">
                    <label className="block text-sm font-bold text-gray-700">Facility Type</label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        onClick={() => setType('school')}
                        className={`py-2 px-4 rounded-md border-2 transition font-medium ${
                          type === 'school' ? 'border-maroon-700 bg-maroon-50 text-maroon-700' : 'border-gray-200 text-gray-500 hover:border-gray-300'
                        }`}
                      >
                        School
                      </button>
                      <button
                        onClick={() => setType('hospital')}
                        className={`py-2 px-4 rounded-md border-2 transition font-medium ${
                          type === 'hospital' ? 'border-maroon-700 bg-maroon-50 text-maroon-700' : 'border-gray-200 text-gray-500 hover:border-gray-300'
                        }`}
                      >
                        Hospital
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={simulate}
                    className="w-full bg-maroon-700 hover:bg-maroon-800 text-white font-bold py-3 rounded-md transition"
                  >
                    Run Simulation
                  </button>
                </>
              ) : (
                <div className="text-center space-y-4">
                  {result.success ? (
                    <>
                      <div className="bg-green-100 text-green-700 w-12 h-12 rounded-full flex items-center justify-center mx-auto">
                        <CheckCircle className="w-8 h-8" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900">Success!</h4>
                      <p className="text-gray-600">{result.message}</p>
                      <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-left">
                        <p className="text-xs text-gray-500 uppercase font-bold mb-2">Worker Details</p>
                        <p className="font-bold">{result.worker.firstName} {result.worker.lastName}</p>
                        <div className="flex gap-2 mt-2">
                          <span className="text-[10px] bg-blue-100 text-blue-700 px-1 py-0.5 rounded">Rookie Run</span>
                          {type === 'school' && <span className="text-[10px] bg-amber-100 text-amber-700 px-1 py-0.5 rounded">School Clearance</span>}
                          {type === 'hospital' && <span className="text-[10px] bg-green-100 text-green-700 px-1 py-0.5 rounded">Health Track</span>}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-red-100 text-red-700 w-12 h-12 rounded-full flex items-center justify-center mx-auto">
                        <AlertCircle className="w-8 h-8" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900">No Match</h4>
                      <p className="text-gray-600">{result.message}</p>
                    </>
                  )}
                  
                  <button
                    onClick={() => setResult(null)}
                    className="w-full border-2 border-gray-200 hover:border-gray-300 text-gray-700 font-bold py-3 rounded-md transition"
                  >
                    Try Another
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
