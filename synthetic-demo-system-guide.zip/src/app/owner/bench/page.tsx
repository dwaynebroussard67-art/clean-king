import type { Metadata } from 'next';
import { db } from '@/db';
import { employees } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { CalloutSimulation } from './CalloutSimulation';
import { Zap, Users } from 'lucide-react';

export const metadata: Metadata = { title: 'The Bench' };

export default async function BenchPage() {
  const allEmployees = await db.query.employees.findMany({
    where: eq(employees.isActive, true),
    orderBy: (employees, { asc }) => [asc(employees.firstName)],
  });

  const atCap = allEmployees.filter(e => e.weeklyHours >= e.hourCap).length;
  const withRookieRun = allEmployees.filter(e => e.hasRookieRun).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">The Bench</h1>
          <p className="text-sm text-gray-500 mt-1">Active crew members and their clearances. Hire applicants to populate the bench.</p>
        </div>
        {allEmployees.length > 0 && <CalloutSimulation employees={allEmployees} />}
      </div>

      {/* Quick stats */}
      {allEmployees.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
            <p className="text-2xl font-extrabold text-gray-900">{allEmployees.length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Active Workers</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
            <p className="text-2xl font-extrabold text-gray-900">{withRookieRun}</p>
            <p className="text-xs text-gray-500 mt-0.5">Rookie Run Certified</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
            <p className={`text-2xl font-extrabold ${atCap > 0 ? 'text-red-600' : 'text-gray-900'}`}>{atCap}</p>
            <p className="text-xs text-gray-500 mt-0.5">At Hour Cap</p>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {allEmployees.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-12 h-12 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-6 h-6" />
            </div>
            <p className="text-gray-900 font-semibold">Bench is empty</p>
            <p className="text-sm text-gray-500 mt-1">Hire applicants from the Applicants page to populate the bench.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  <th className="px-6 py-3 text-left">Worker</th>
                  <th className="px-6 py-3 text-left">Certifications</th>
                  <th className="px-6 py-3 text-left">Hours / Cap</th>
                  <th className="px-6 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {allEmployees.map((e) => (
                  <tr key={e.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-semibold text-gray-900">{e.firstName} {e.lastName}</p>
                      <p className="text-xs text-gray-400 mt-0.5 capitalize">{e.role}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1.5">
                        {e.hasRookieRun && (
                          <span className="text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded-full">Rookie Run</span>
                        )}
                        {e.hasHealthTrack && (
                          <span className="text-[11px] font-semibold bg-green-50 text-green-700 border border-green-200 px-2 py-0.5 rounded-full">Health Track</span>
                        )}
                        {e.hasSchoolClearance && (
                          <span className="text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">School Clearance</span>
                        )}
                        {!e.hasRookieRun && !e.hasHealthTrack && !e.hasSchoolClearance && (
                          <span className="text-xs text-gray-400">None yet</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <span className={`font-semibold ${e.weeklyHours >= e.hourCap ? 'text-red-600' : 'text-gray-900'}`}>
                          {e.weeklyHours} / {e.hourCap}
                        </span>
                        <div className="w-20 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${e.weeklyHours >= e.hourCap ? 'bg-red-500' : 'bg-green-500'}`}
                            style={{ width: `${Math.min((e.weeklyHours / e.hourCap) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border bg-green-50 text-green-700 border-green-200">
                        Active
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
