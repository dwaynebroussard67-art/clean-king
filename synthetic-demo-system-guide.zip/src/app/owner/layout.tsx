import { Crown } from 'lucide-react';
import { OwnerSidebarClient } from './OwnerSidebarClient';
import Link from 'next/link';

export default function OwnerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-[calc(100vh-64px)]">
      {/* Sidebar */}
      <aside className="w-60 bg-gray-900 text-white hidden md:flex flex-col flex-shrink-0">
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 bg-[#800000] rounded-md flex items-center justify-center">
              <Crown className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-xs font-bold text-white">Clean King</p>
              <p className="text-[10px] text-gray-400">Owner Portal</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-0.5">
          <OwnerSidebarClient />
        </nav>

        <div className="p-4 border-t border-white/10">
          <Link href="/" className="text-xs text-gray-500 hover:text-gray-300 transition-colors">
            ← Back to main site
          </Link>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 bg-gray-50 overflow-auto">
        <div className="max-w-6xl mx-auto p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
