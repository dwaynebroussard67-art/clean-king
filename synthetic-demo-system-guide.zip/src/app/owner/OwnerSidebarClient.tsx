'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Users, MessageSquare, Zap, ShieldCheck, Bot } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { name: 'Dashboard', href: '/owner', icon: LayoutDashboard },
  { name: 'Applicants', href: '/owner/applicants', icon: Users },
  { name: 'Quotes', href: '/owner/quotes', icon: MessageSquare },
  { name: 'Bench', href: '/owner/bench', icon: Zap },
  { name: 'Audit Log', href: '/owner/audit', icon: ShieldCheck },
  { name: 'Assistant', href: '/owner/assistant', icon: Bot },
];

export function OwnerSidebarClient() {
  const pathname = usePathname();

  return (
    <>
      {navItems.map((item) => {
        const isActive = pathname === item.href || (item.href !== '/owner' && pathname.startsWith(item.href));
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-all',
              isActive
                ? 'bg-[#800000] text-white'
                : 'text-gray-400 hover:bg-white/10 hover:text-white'
            )}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <span>{item.name}</span>
          </Link>
        );
      })}
    </>
  );
}
