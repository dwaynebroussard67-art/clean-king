import type { Metadata } from 'next';
import { db } from '@/db';
import { auditLogs } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { ShieldCheck } from 'lucide-react';

export const metadata: Metadata = { title: 'Audit Log' };

const entityColors: Record<string, string> = {
  applicant: 'bg-blue-50 text-blue-700 border-blue-200',
  quote: 'bg-purple-50 text-purple-700 border-purple-200',
  employee: 'bg-green-50 text-green-700 border-green-200',
};

export default async function AuditPage() {
  const allLogs = await db.query.auditLogs.findMany({
    orderBy: [desc(auditLogs.createdAt)],
    limit: 200,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Audit Log</h1>
        <p className="text-sm text-gray-500 mt-1">
          Immutable record of all owner actions. Showing the {Math.min(allLogs.length, 200)} most recent events.
        </p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {allLogs.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-12 h-12 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <p className="text-gray-900 font-semibold">No activity yet</p>
            <p className="text-sm text-gray-500 mt-1">Events will appear here when you take actions in the portal.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  <th className="px-6 py-3 text-left">Timestamp</th>
                  <th className="px-6 py-3 text-left">Entity</th>
                  <th className="px-6 py-3 text-left">Action</th>
                  <th className="px-6 py-3 text-left">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {allLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3.5 whitespace-nowrap text-gray-500 font-mono text-xs">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="px-6 py-3.5">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border capitalize ${entityColors[log.entityType] ?? 'bg-gray-50 text-gray-600 border-gray-200'}`}>
                        {log.entityType}
                      </span>
                      <p className="text-[11px] text-gray-400 mt-0.5 font-mono">{log.entityId.substring(0, 12)}…</p>
                    </td>
                    <td className="px-6 py-3.5 font-medium text-gray-900">{log.action}</td>
                    <td className="px-6 py-3.5">
                      {log.details ? (
                        <code className="text-xs text-gray-500 bg-gray-50 px-2 py-1 rounded border border-gray-200 block max-w-xs overflow-hidden whitespace-nowrap text-ellipsis">
                          {JSON.stringify(log.details)}
                        </code>
                      ) : (
                        <span className="text-xs text-gray-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
