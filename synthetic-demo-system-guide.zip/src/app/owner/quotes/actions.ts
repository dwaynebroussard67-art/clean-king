'use server';

import { db } from '@/db';
import { quotes, auditLogs } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function updateQuoteStatus(quoteId: string, status: string) {
  const [existing] = await db.select().from(quotes).where(eq(quotes.id, quoteId));
  if (!existing) throw new Error('Quote not found');

  await db.update(quotes).set({ status }).where(eq(quotes.id, quoteId));

  await db.insert(auditLogs).values({
    action: `Quote status changed to ${status}`,
    entityType: 'quote',
    entityId: quoteId,
    details: { oldStatus: existing.status, newStatus: status },
  });

  return { success: true };
}
