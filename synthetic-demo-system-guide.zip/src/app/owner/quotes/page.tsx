import type { Metadata } from 'next';
import { db } from '@/db';
import { quotes } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { MessageSquare } from 'lucide-react';
import { QuoteStatusSelect } from './QuoteStatusSelect';

export const metadata: Metadata = { title: 'Quotes' };

const serviceLabels: Record<string, string> = {
  school: 'School / Educational',
  medical: 'Medical / Hospital',
  commercial: 'Commercial Office',
  retail: 'Retail / Mixed-use',
  specialty: 'Specialty Deep Clean',
  other: 'Other',
};

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    new: 'bg-amber-50 text-amber-700 border-amber-200',
    contacted: 'bg-blue-50 text-blue-700 border-blue-200',
    quoted: 'bg-purple-50 text-purple-700 border-purple-200',
    closed: 'bg-gray-50 text-gray-600 border-gray-200',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border capitalize ${styles[status] ?? 'bg-gray-50 text-gray-600'}`}>
      {status}
    </span>
  );
}

export default async function QuotesPage() {
  const allQuotes = await db.query.quotes.findMany({
    orderBy: [desc(quotes.createdAt)],
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Quotes</h1>
        <p className="text-sm text-gray-500 mt-1">Service requests from potential clients. Update status as you work each lead.</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {allQuotes.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-12 h-12 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6" />
            </div>
            <p className="text-gray-900 font-semibold">No quote requests yet</p>
            <p className="text-sm text-gray-500 mt-1">Requests submitted through /quote will appear here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  <th className="px-6 py-3 text-left">Client</th>
                  <th className="px-6 py-3 text-left">Service Type</th>
                  <th className="px-6 py-3 text-left">Location</th>
                  <th className="px-6 py-3 text-left">Details</th>
                  <th className="px-6 py-3 text-left">Requested</th>
                  <th className="px-6 py-3 text-left">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {allQuotes.map((q) => (
                  <tr key={q.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-semibold text-gray-900">{q.name}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{q.email}</p>
                      <p className="text-xs text-gray-400">{q.phone}</p>
                    </td>
                    <td className="px-6 py-4 text-gray-600">
                      {serviceLabels[q.serviceType] ?? q.serviceType}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{q.area}</td>
                    <td className="px-6 py-4">
                      <p className="text-gray-600 text-xs max-w-xs line-clamp-2">{q.details}</p>
                    </td>
                    <td className="px-6 py-4 text-gray-500 whitespace-nowrap">
                      {new Date(q.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <QuoteStatusSelect quoteId={q.id} currentStatus={q.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
