'use client';

import { updateQuoteStatus } from './actions';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

const statuses = [
  { value: 'new', label: 'New' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'quoted', label: 'Quoted' },
  { value: 'closed', label: 'Closed' },
];

export function QuoteStatusSelect({ quoteId, currentStatus }: { quoteId: string; currentStatus: string }) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const newStatus = e.target.value;
    if (newStatus === currentStatus) return;
    setLoading(true);
    try {
      await updateQuoteStatus(quoteId, newStatus);
      router.refresh();
    } catch {
      alert('Failed to update status.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <select
      defaultValue={currentStatus}
      onChange={handleChange}
      disabled={loading}
      className="text-xs border border-gray-300 rounded-lg px-2.5 py-1.5 bg-white focus:outline-none focus:ring-2 focus:ring-[#800000]/30 disabled:opacity-50 cursor-pointer"
    >
      {statuses.map((s) => (
        <option key={s.value} value={s.value}>{s.label}</option>
      ))}
    </select>
  );
}
