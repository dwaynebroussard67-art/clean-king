import { db } from '@/db';
import { applicants, quotes, auditLogs, employees } from '@/db/schema';
import { count, desc, eq } from 'drizzle-orm';
import { Users, MessageSquare, ShieldCheck, UserCheck, ArrowRight, Clock } from 'lucide-react';
import Link from 'next/link';

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending: 'bg-blue-50 text-blue-700 border-blue-200',
    hired: 'bg-green-50 text-green-700 border-green-200',
    passed: 'bg-red-50 text-red-700 border-red-200',
    new: 'bg-amber-50 text-amber-700 border-amber-200',
    contacted: 'bg-blue-50 text-blue-700 border-blue-200',
    quoted: 'bg-purple-50 text-purple-700 border-purple-200',
    closed: 'bg-gray-50 text-gray-600 border-gray-200',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border capitalize ${styles[status] ?? 'bg-gray-50 text-gray-600 border-gray-200'}`}>
      {status}
    </span>
  );
}

export default async function OwnerDashboard() {
  const [[applicantCount], [quoteCount], [auditCount], [employeeCount]] = await Promise.all([
    db.select({ value: count() }).from(applicants),
    db.select({ value: count() }).from(quotes),
    db.select({ value: count() }).from(auditLogs),
    db.select({ value: count() }).from(employees).where(eq(employees.isActive, true)),
  ]);

  const [recentApplicants, recentQuotes] = await Promise.all([
    db.query.applicants.findMany({ limit: 6, orderBy: [desc(applicants.createdAt)] }),
    db.query.quotes.findMany({ limit: 6, orderBy: [desc(quotes.createdAt)] }),
  ]);

  const pendingCount = recentApplicants.filter(a => a.status === 'pending').length;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        {pendingCount > 0 && (
          <Link
            href="/owner/applicants"
            className="inline-flex items-center space-x-2 bg-amber-50 border border-amber-200 text-amber-800 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-amber-100 transition-colors"
          >
            <Clock className="w-4 h-4" />
            <span>{pendingCount} applicant{pendingCount > 1 ? 's' : ''} awaiting review</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Applicants', value: applicantCount.value, icon: Users, color: 'bg-blue-50 text-blue-600', href: '/owner/applicants' },
          { label: 'Active Workers', value: employeeCount.value, icon: UserCheck, color: 'bg-green-50 text-green-600', href: '/owner/bench' },
          { label: 'Open Quotes', value: quoteCount.value, icon: MessageSquare, color: 'bg-purple-50 text-purple-600', href: '/owner/quotes' },
          { label: 'Audit Events', value: auditCount.value, icon: ShieldCheck, color: 'bg-gray-50 text-gray-600', href: '/owner/audit' },
        ].map((stat) => (
          <Link
            key={stat.label}
            href={stat.href}
            className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all group"
          >
            <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center mb-4`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <p className="text-2xl font-extrabold text-gray-900">{stat.value.toLocaleString()}</p>
            <p className="text-xs font-medium text-gray-500 mt-1">{stat.label}</p>
          </Link>
        ))}
      </div>

      {/* Recent activity */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Recent Applicants */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex justify-between items-center">
            <h2 className="font-bold text-gray-900">Recent Applicants</h2>
            <Link href="/owner/applicants" className="text-xs font-semibold text-[#800000] hover:text-[#6a0505] flex items-center">
              View all <ArrowRight className="ml-1 w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {recentApplicants.length === 0 ? (
              <div className="p-10 text-center text-gray-400 text-sm">No applicants yet. Share your <Link href="/apply" className="text-[#800000] hover:underline">application link</Link>.</div>
            ) : (
              recentApplicants.map((a) => (
                <div key={a.id} className="px-5 py-3.5 flex items-center justify-between hover:bg-gray-50 transition-colors">
                  <div className="min-w-0">
                    <p className="font-semibold text-gray-900 text-sm truncate">{a.firstName} {a.lastName}</p>
                    <p className="text-xs text-gray-500 truncate">{a.area} · {new Date(a.createdAt).toLocaleDateString()}</p>
                  </div>
                  <StatusBadge status={a.status} />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Quotes */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex justify-between items-center">
            <h2 className="font-bold text-gray-900">Recent Quotes</h2>
            <Link href="/owner/quotes" className="text-xs font-semibold text-[#800000] hover:text-[#6a0505] flex items-center">
              View all <ArrowRight className="ml-1 w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {recentQuotes.length === 0 ? (
              <div className="p-10 text-center text-gray-400 text-sm">No quote requests yet.</div>
            ) : (
              recentQuotes.map((q) => (
                <div key={q.id} className="px-5 py-3.5 flex items-center justify-between hover:bg-gray-50 transition-colors">
                  <div className="min-w-0">
                    <p className="font-semibold text-gray-900 text-sm truncate">{q.name}</p>
                    <p className="text-xs text-gray-500 truncate">{q.area} · {q.serviceType} · {new Date(q.createdAt).toLocaleDateString()}</p>
                  </div>
                  <StatusBadge status={q.status} />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
