import type { Metadata } from 'next';
import { db } from '@/db';
import { applicants } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { StatusActions } from './StatusActions';
import { Users } from 'lucide-react';

export const metadata: Metadata = { title: 'Applicants' };

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending: 'bg-blue-50 text-blue-700 border-blue-200',
    hired: 'bg-green-50 text-green-700 border-green-200',
    passed: 'bg-red-50 text-red-700 border-red-200',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border capitalize ${styles[status] ?? 'bg-gray-50 text-gray-600'}`}>
      {status}
    </span>
  );
}

export default async function ApplicantsPage() {
  const allApplicants = await db.query.applicants.findMany({
    orderBy: [desc(applicants.createdAt)],
  });

  const pending = allApplicants.filter(a => a.status === 'pending').length;
  const hired = allApplicants.filter(a => a.status === 'hired').length;
  const passed = allApplicants.filter(a => a.status === 'passed').length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Applicants</h1>
          <p className="text-sm text-gray-500 mt-1">Review and action incoming job applications.</p>
        </div>
        <div className="flex items-center space-x-3 text-sm">
          <span className="px-3 py-1.5 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg font-semibold">{pending} pending</span>
          <span className="px-3 py-1.5 bg-green-50 border border-green-200 text-green-700 rounded-lg font-semibold">{hired} hired</span>
          <span className="px-3 py-1.5 bg-red-50 border border-red-200 text-red-700 rounded-lg font-semibold">{passed} passed</span>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {allApplicants.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-12 h-12 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-6 h-6" />
            </div>
            <p className="text-gray-900 font-semibold">No applicants yet</p>
            <p className="text-sm text-gray-500 mt-1">Applications submitted through /apply will appear here.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  <th className="px-6 py-3 text-left">Applicant</th>
                  <th className="px-6 py-3 text-left">Contact</th>
                  <th className="px-6 py-3 text-left">Area</th>
                  <th className="px-6 py-3 text-left">Transportation</th>
                  <th className="px-6 py-3 text-left">Applied</th>
                  <th className="px-6 py-3 text-left">Status</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {allApplicants.map((a) => (
                  <tr key={a.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-semibold text-gray-900">{a.firstName} {a.lastName}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{a.languages}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-gray-700">{a.email ?? '—'}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{a.phone}</p>
                    </td>
                    <td className="px-6 py-4 text-gray-600 capitalize">{a.area}</td>
                    <td className="px-6 py-4 text-gray-600 capitalize">{a.transportation.replace('_', ' ')}</td>
                    <td className="px-6 py-4 text-gray-500 whitespace-nowrap">
                      {new Date(a.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={a.status} />
                    </td>
                    <td className="px-6 py-4 text-right">
                      <StatusActions applicantId={a.id} currentStatus={a.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
