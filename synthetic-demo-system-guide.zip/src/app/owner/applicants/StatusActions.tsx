'use client';

import { updateApplicantStatus } from './actions';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Loader2, UserCheck, XCircle } from 'lucide-react';

export function StatusActions({ applicantId, currentStatus }: { applicantId: string; currentStatus: string }) {
  const [loading, setLoading] = useState<string | null>(null);
  const router = useRouter();

  async function handleChange(status: 'hired' | 'passed') {
    if (!confirm(`Mark this applicant as ${status}?`)) return;
    setLoading(status);
    try {
      await updateApplicantStatus(applicantId, status);
      router.refresh();
    } catch {
      alert('Failed to update status. Please try again.');
    } finally {
      setLoading(null);
    }
  }

  if (currentStatus !== 'pending') {
    return <span className="text-xs text-gray-400 italic">No actions</span>;
  }

  return (
    <div className="flex items-center justify-end space-x-2">
      <button
        onClick={() => handleChange('hired')}
        disabled={loading !== null}
        title="Hire this applicant"
        className="inline-flex items-center space-x-1.5 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-xs font-semibold py-1.5 px-3 rounded-lg transition-colors"
      >
        {loading === 'hired' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UserCheck className="w-3.5 h-3.5" />}
        <span>Hire</span>
      </button>
      <button
        onClick={() => handleChange('passed')}
        disabled={loading !== null}
        title="Pass on this applicant"
        className="inline-flex items-center space-x-1.5 bg-white hover:bg-red-50 disabled:opacity-50 text-red-600 border border-red-200 text-xs font-semibold py-1.5 px-3 rounded-lg transition-colors"
      >
        {loading === 'passed' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
        <span>Pass</span>
      </button>
    </div>
  );
}
