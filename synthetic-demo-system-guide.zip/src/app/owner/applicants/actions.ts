'use server';

import { db } from '@/db';
import { applicants, auditLogs, employees, onboardingRecords, onboardingTasks } from '@/db/schema';
import { eq } from 'drizzle-orm';

export async function updateApplicantStatus(applicantId: string, status: 'hired' | 'passed') {
  try {
    const [applicant] = await db.select().from(applicants).where(eq(applicants.id, applicantId));
    
    if (!applicant) throw new Error('Applicant not found');

    await db.update(applicants)
      .set({ status, updatedAt: new Date() })
      .where(eq(applicants.id, applicantId));

    // Log the audit event
    await db.insert(auditLogs).values({
      action: `Status changed to ${status}`,
      entityType: 'applicant',
      entityId: applicantId,
      details: { oldStatus: applicant.status, newStatus: status },
    });

    if (status === 'hired') {
      // Create employee record
      const [newEmployee] = await db.insert(employees).values({
        applicantId,
        firstName: applicant.firstName,
        lastName: applicant.lastName,
        email: applicant.email,
        phone: applicant.phone,
        role: 'worker',
      }).returning();

      // Start onboarding
      const [onboarding] = await db.insert(onboardingRecords).values({
        applicantId,
        employeeId: newEmployee.id,
        status: 'in_progress',
      }).returning();

      // Create default tasks
      await db.insert(onboardingTasks).values([
        { onboardingRecordId: onboarding.id, title: 'Review employment documents', description: 'Owner must verify ID and tax forms.' },
        { onboardingRecordId: onboarding.id, title: 'Plan training sequence', description: 'Assign the 3-lesson training module.' },
        { onboardingRecordId: onboarding.id, title: 'Plan first shift', description: 'Assign to a supervisor for initial site visit.' },
      ]);
    }

    return { success: true };
  } catch (error) {
    console.error('Failed to update status:', error);
    throw error;
  }
}
