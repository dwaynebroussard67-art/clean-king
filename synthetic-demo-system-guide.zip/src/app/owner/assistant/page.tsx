import type { Metadata } from 'next';
import { db } from '@/db';
import { applicants, employees, quotes } from '@/db/schema';
import { count, eq } from 'drizzle-orm';
import { Bot, Lock } from 'lucide-react';

export const metadata: Metadata = { title: 'Assistant' };

export default async function AssistantPage() {
  const [[totalApplicants], [pendingApplicants], [activeWorkers], [openQuotes]] = await Promise.all([
    db.select({ value: count() }).from(applicants),
    db.select({ value: count() }).from(applicants).where(eq(applicants.status, 'pending')),
    db.select({ value: count() }).from(employees).where(eq(employees.isActive, true)),
    db.select({ value: count() }).from(quotes).where(eq(quotes.status, 'new')),
  ]);

  const snapshot = {
    total_applicants: totalApplicants.value,
    pending_review: pendingApplicants.value,
    active_workers: activeWorkers.value,
    open_quotes: openQuotes.value,
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Owner Assistant</h1>
          <p className="text-sm text-gray-500 mt-1">AI-powered helper for your business data. Requires configuration to activate.</p>
        </div>
        <span className="inline-flex items-center space-x-1.5 bg-gray-100 text-gray-500 text-xs font-semibold px-3 py-1.5 rounded-full border border-gray-200">
          <Lock className="w-3.5 h-3.5" />
          <span>Requires OWNER_ASSISTANT_ENABLED</span>
        </span>
      </div>

      {/* Snapshot */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-5">
          <Bot className="w-5 h-5 text-[#800000]" />
          <h2 className="font-bold text-gray-900">Current Snapshot</h2>
          <span className="text-xs text-gray-400">(available to assistant)</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {Object.entries(snapshot).map(([key, val]) => (
            <div key={key} className="bg-gray-50 rounded-xl p-4 border border-gray-100 text-center">
              <p className="text-2xl font-extrabold text-gray-900">{val}</p>
              <p className="text-xs text-gray-500 mt-1 capitalize">{key.replace(/_/g, ' ')}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Chat placeholder */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center space-x-3">
          <div className="w-8 h-8 bg-[#800000] rounded-lg flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-bold text-gray-900 text-sm">Clean King Assistant</p>
            <p className="text-[11px] text-gray-400">Read-only · No external tools · Aggregate data only</p>
          </div>
        </div>

        <div className="p-6 bg-gray-50/50 min-h-[220px] flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6" />
            </div>
            <p className="font-semibold text-gray-700">Assistant not enabled</p>
            <p className="text-sm text-gray-400 mt-1 max-w-xs">
              Set <code className="font-mono bg-gray-100 px-1 rounded text-xs">OWNER_ASSISTANT_ENABLED=true</code> and configure a provider key in settings to activate.
            </p>
          </div>
        </div>

        <div className="p-4 border-t border-gray-100">
          <div className="flex space-x-3">
            <input
              disabled
              placeholder="Assistant is not configured…"
              className="flex-1 border border-gray-200 rounded-lg px-4 py-2.5 text-sm bg-gray-50 cursor-not-allowed text-gray-400"
            />
            <button disabled className="bg-gray-100 text-gray-400 px-5 py-2.5 rounded-lg cursor-not-allowed text-sm font-semibold">
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
