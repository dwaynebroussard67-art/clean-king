import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Terms of Service',
  description: 'Clean King terms of service.',
};

export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <div className="mb-10">
        <Link href="/" className="text-sm text-[#800000] hover:underline">← Back to home</Link>
        <h1 className="mt-4 text-3xl font-extrabold text-gray-900">Terms of Service</h1>
        <p className="mt-2 text-sm text-gray-500">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      <div className="prose prose-gray max-w-none space-y-8 text-gray-700 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">1. Services</h2>
          <p>Clean King provides commercial cleaning services for schools, healthcare facilities, offices, and other commercial properties. All services are subject to a written service agreement executed between Clean King and the client prior to commencement of work.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">2. Quote Requests</h2>
          <p>Submitting a quote request through this website does not constitute a binding agreement. Quotes are provided in writing and are valid for 30 days unless otherwise stated. Final pricing is subject to site assessment.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">3. Employment Applications</h2>
          <p>Submission of an application does not guarantee employment. All employment decisions are made in accordance with applicable law. Background checks are required for all positions. Clearances for school and healthcare environments are subject to separate verification processes.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">4. Limitation of Liability</h2>
          <p>Clean King's liability for any claim arising from services provided shall not exceed the total amount paid for those services in the 30 days preceding the claim. We are not liable for indirect, incidental, or consequential damages.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">5. Governing Law</h2>
          <p>These terms are governed by the laws of the jurisdiction in which the applicable service agreement is executed.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">6. Contact</h2>
          <p>For questions about these terms, contact us at <a href="mailto:info@cleanking.com" className="text-[#800000] hover:underline">info@cleanking.com</a>.</p>
        </section>
      </div>
    </div>
  );
}
