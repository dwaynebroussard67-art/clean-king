import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, GraduationCap, Heart, Building2, Sparkles, CheckCircle, Shield } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Services',
  description: 'Professional cleaning services for schools, hospitals, offices, and specialty facilities.',
};

const services = [
  {
    icon: GraduationCap,
    title: 'Educational Facilities',
    subtitle: 'Schools, Daycares & Universities',
    color: 'bg-blue-50 text-blue-700 border-blue-100',
    iconBg: 'bg-blue-100 text-blue-700',
    features: [
      'School-clearance verified crew members',
      'Child-safe, low-VOC cleaning products',
      'Classroom, cafeteria, restroom, and gym programs',
      'Before- and after-school scheduling',
      'Summer deep-clean packages',
      'Allergen and illness-prevention protocols',
    ],
    description: 'We understand that schools require a higher standard of care. Every crew member assigned to educational facilities holds a current school clearance and is trained on child-safe chemical protocols.',
  },
  {
    icon: Heart,
    title: 'Healthcare Facilities',
    subtitle: 'Hospitals, Clinics & Medical Offices',
    color: 'bg-red-50 text-red-700 border-red-100',
    iconBg: 'bg-red-100 text-red-700',
    features: [
      'Health-track certified crew members',
      'Biohazard and sharps-adjacent area protocols',
      'Sterile environment maintenance',
      'Infection-control compliant procedures',
      'HIPAA-aware staff — no access to patient information',
      'After-hours and weekend availability',
    ],
    description: 'Healthcare environments demand rigorous infection control. Our health-track certified crews follow strict sterilization protocols to protect patients, staff, and visitors.',
  },
  {
    icon: Building2,
    title: 'Commercial Offices',
    subtitle: 'Offices, Co-working & Retail',
    color: 'bg-purple-50 text-purple-700 border-purple-100',
    iconBg: 'bg-purple-100 text-purple-700',
    features: [
      'Nightly and weekly maintenance programs',
      'Open-plan, private office, and common area coverage',
      'Kitchen, breakroom, and restroom service',
      'Secure after-hours access coordination',
      'Transparent supervisor sign-off reports',
      'Flexible contract terms',
    ],
    description: 'Keep your workplace spotless and professional. We work around your team\'s schedule with quiet, efficient crews that treat your space with respect.',
  },
  {
    icon: Sparkles,
    title: 'Specialty Deep Cleans',
    subtitle: 'Post-construction, Events & Move-in/out',
    color: 'bg-amber-50 text-amber-700 border-amber-100',
    iconBg: 'bg-amber-100 text-amber-700',
    features: [
      'Post-construction debris removal and surface clean',
      'Event setup and breakdown cleaning',
      'Move-in / move-out detailed cleaning',
      'Industrial equipment and floor restoration',
      'Odor treatment and sanitization',
      'Single-event and recurring options',
    ],
    description: 'Some jobs need more than a standard clean. Our specialty deep-clean crews are equipped with professional-grade tools and products for the toughest assignments.',
  },
];

export default function ServicesPage() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gray-900 py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-sm font-bold text-[#f0a0a0] uppercase tracking-widest">Our Services</span>
          <h1 className="mt-3 text-4xl sm:text-5xl font-extrabold text-white">
            Cleaning programs built for every facility
          </h1>
          <p className="mt-5 text-xl text-gray-400 max-w-2xl mx-auto">
            From daily maintenance to specialized environments — we bring vetted, trained crews with the right clearances for your site.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/quote"
              className="inline-flex items-center justify-center bg-[#800000] hover:bg-[#6a0505] text-white px-8 py-4 rounded-xl font-bold text-lg transition-all shadow-lg"
            >
              Get a Free Quote <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Service Cards */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {services.map((s, i) => (
            <div
              key={s.title}
              className={`flex flex-col ${i % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-10 items-start`}
            >
              {/* Text */}
              <div className="flex-1">
                <div className={`inline-flex items-center space-x-2 px-3 py-1.5 rounded-full border ${s.color} text-sm font-semibold mb-5`}>
                  <s.icon className="w-4 h-4" />
                  <span>{s.subtitle}</span>
                </div>
                <h2 className="text-3xl font-extrabold text-gray-900 mb-4">{s.title}</h2>
                <p className="text-gray-500 leading-relaxed mb-7">{s.description}</p>
                <ul className="space-y-3">
                  {s.features.map((f) => (
                    <li key={f} className="flex items-start text-sm text-gray-700">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link
                  href="/quote"
                  className="mt-8 inline-flex items-center bg-[#800000] hover:bg-[#6a0505] text-white px-7 py-3 rounded-xl font-bold transition-all shadow-sm"
                >
                  Request this service <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </div>

              {/* Visual panel */}
              <div className={`flex-1 ${s.color.split(' ')[0]} border ${s.color.split(' ')[2]} rounded-3xl p-10 flex flex-col justify-center min-h-[320px]`}>
                <div className={`w-16 h-16 ${s.iconBg} rounded-2xl flex items-center justify-center mb-6`}>
                  <s.icon className="w-9 h-9" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 opacity-70" />
                    <span className="text-sm font-semibold opacity-80">Clearance-verified crew</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 opacity-70" />
                    <span className="text-sm font-semibold opacity-80">Supervisor sign-off every visit</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 opacity-70" />
                    <span className="text-sm font-semibold opacity-80">Flexible scheduling</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-50 py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 mb-5">Ready to get started?</h2>
          <p className="text-gray-500 text-lg mb-8">
            Tell us about your facility and we&apos;ll match you with the right crew and program within one business day.
          </p>
          <Link
            href="/quote"
            className="inline-flex items-center bg-[#800000] hover:bg-[#6a0505] text-white px-10 py-4 rounded-xl font-bold text-lg transition-all shadow-lg"
          >
            Request a Free Quote <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
