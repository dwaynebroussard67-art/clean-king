'use client';

import { useState } from 'react';
import { submitQuote } from './actions';
import { CheckCircle, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const serviceTypes = [
  { value: 'school', label: 'School / Educational Facility' },
  { value: 'medical', label: 'Medical Facility / Hospital' },
  { value: 'commercial', label: 'Commercial Office' },
  { value: 'retail', label: 'Retail / Mixed-use' },
  { value: 'specialty', label: 'Specialty Deep Clean' },
  { value: 'other', label: 'Other' },
];

const frequencies = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly' },
  { value: 'monthly', label: 'Monthly' },
  { value: 'one_time', label: 'One-time' },
];

export function QuoteForm() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus('submitting');
    setError(null);
    try {
      const formData = new FormData(e.currentTarget);
      const result = await submitQuote(formData);
      if (result.success) {
        setStatus('success');
      } else {
        setStatus('error');
        setError(result.error || 'Something went wrong. Please try again.');
      }
    } catch {
      setStatus('error');
      setError('An unexpected error occurred. Please try again.');
    }
  }

  if (status === 'success') {
    return (
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 text-center">
        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-9 h-9" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-3">Request Received!</h2>
        <p className="text-gray-500 mb-8 max-w-sm mx-auto">
          Thank you for reaching out. We&apos;ll review your request and get back to you with a custom proposal within one business day.
        </p>
        <Link
          href="/"
          className="inline-flex items-center bg-[#800000] hover:bg-[#6a0505] text-white px-7 py-3 rounded-xl font-bold transition-all"
        >
          Back to Home <ArrowRight className="ml-2 w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      <div className="p-8 border-b border-gray-100">
        <h2 className="text-xl font-bold text-gray-900">Your Quote Request</h2>
        <p className="text-sm text-gray-500 mt-1">All fields marked * are required.</p>
      </div>

      <div className="p-8 space-y-6">
        {/* Contact */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Your Name *</label>
          <input
            name="name"
            required
            autoComplete="name"
            placeholder="James Patel"
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Work Email *</label>
            <input
              name="email"
              type="email"
              required
              autoComplete="email"
              placeholder="james@facility.org"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Phone Number *</label>
            <input
              name="phone"
              type="tel"
              required
              autoComplete="tel"
              placeholder="(555) 000-0000"
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            />
          </div>
        </div>

        {/* Service */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Facility Type *</label>
            <select
              name="serviceType"
              required
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            >
              <option value="">Select type…</option>
              {serviceTypes.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Cleaning Frequency *</label>
            <select
              name="frequency"
              required
              className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
            >
              <option value="">Select frequency…</option>
              {frequencies.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
            </select>
          </div>
        </div>

        {/* Area */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Facility Location / Area *</label>
          <input
            name="area"
            required
            placeholder="City, neighborhood, or zip code"
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors"
          />
        </div>

        {/* Details */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Project Details *</label>
          <textarea
            name="details"
            required
            rows={4}
            placeholder="Describe your facility — approximate size (sq ft), number of floors, areas to be cleaned, any special requirements or certifications needed…"
            className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#800000]/30 focus:border-[#800000] transition-colors resize-none"
          />
        </div>

        {/* Error */}
        {status === 'error' && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={status === 'submitting'}
          className="w-full bg-[#800000] hover:bg-[#6a0505] disabled:opacity-60 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded-xl transition-all shadow-sm flex items-center justify-center text-sm"
        >
          {status === 'submitting' ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Sending Request…
            </>
          ) : (
            <>
              Submit Quote Request
              <ArrowRight className="ml-2 w-4 h-4" />
            </>
          )}
        </button>

        <p className="text-center text-xs text-gray-400">
          We&apos;ll never share your information. No spam, ever.
        </p>
      </div>
    </form>
  );
}
