import type { Metadata } from 'next';
import { QuoteForm } from './QuoteForm';
import { Clock, CheckCircle, Phone } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Request a Quote',
  description: 'Get a custom cleaning quote for your school, hospital, office, or specialty facility.',
};

export default function QuotePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Left */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <span className="text-sm font-bold text-[#800000] uppercase tracking-widest">Get a Quote</span>
              <h1 className="mt-3 text-3xl sm:text-4xl font-extrabold text-gray-900 leading-tight">
                Let&apos;s build the right program for your facility
              </h1>
              <p className="mt-4 text-gray-500 leading-relaxed">
                Share your needs and we&apos;ll respond with a custom proposal — typically within one business day.
              </p>
            </div>

            <div className="space-y-4">
              {[
                { icon: Clock, title: 'Fast Response', desc: 'Most quotes delivered within 24 hours.' },
                { icon: CheckCircle, title: 'No Obligation', desc: 'Review the proposal before committing to anything.' },
                { icon: Phone, title: 'Direct Contact', desc: 'You\'ll speak with an owner, not a call center.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start space-x-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                  <div className="w-9 h-9 bg-[#800000]/10 text-[#800000] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                    <item.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">{item.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 rounded-2xl p-6 text-white">
              <p className="text-sm font-medium text-gray-400 mb-1">Prefer to call?</p>
              <p className="font-bold text-xl">1 (800) 255-3264</p>
              <p className="text-sm text-gray-400 mt-1">Mon–Fri, 7am – 6pm</p>
            </div>
          </div>

          {/* Right */}
          <div className="lg:col-span-3">
            <QuoteForm />
          </div>
        </div>
      </div>
    </div>
  );
}
