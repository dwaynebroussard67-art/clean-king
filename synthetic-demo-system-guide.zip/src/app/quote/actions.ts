'use server';

import { db } from '@/db';
import { quotes } from '@/db/schema';

export async function submitQuote(formData: FormData) {
  const name = formData.get('name') as string;
  const email = formData.get('email') as string;
  const phone = formData.get('phone') as string;
  const serviceType = formData.get('serviceType') as string;
  const area = formData.get('area') as string;
  const details = formData.get('details') as string;

  if (!name || !email || !phone || !serviceType || !area || !details) {
    return { success: false, error: 'All required fields must be filled in.' };
  }

  try {
    await db.insert(quotes).values({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      serviceType,
      area: area.trim(),
      details: details.trim(),
      status: 'new',
    });

    return { success: true };
  } catch (error) {
    console.error('Failed to submit quote:', error);
    return { success: false, error: 'Could not save your request. Please try again.' };
  }
}
