import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Clean King privacy policy and data handling practices.',
};

export default function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <div className="mb-10">
        <Link href="/" className="text-sm text-[#800000] hover:underline">← Back to home</Link>
        <h1 className="mt-4 text-3xl font-extrabold text-gray-900">Privacy Policy</h1>
        <p className="mt-2 text-sm text-gray-500">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
      </div>

      <div className="prose prose-gray max-w-none space-y-8 text-gray-700 leading-relaxed">
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">1. Information We Collect</h2>
          <p>When you request a quote, we collect your name, email address, phone number, facility type, and service requirements. When you apply for a position, we collect your name, contact information, work area preferences, availability, transportation status, and languages spoken. You may optionally consent to SMS notifications.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">2. How We Use Your Information</h2>
          <p>We use the information you provide solely to respond to your request or application. We do not sell your personal data to third parties. Quote request information is used to prepare and deliver a service proposal. Application information is used to evaluate your suitability for open positions.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">3. SMS Communications</h2>
          <p>If you opt in to SMS notifications during the application process, we may contact you about your application status and scheduling. You can opt out at any time by replying STOP. Message and data rates may apply.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">4. Data Retention</h2>
          <p>Application and quote data is retained for the duration necessary to fulfill the purpose for which it was collected, or as required by applicable law. You may request deletion of your personal data by contacting us at privacy@cleanking.com.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">5. Security</h2>
          <p>We implement reasonable technical and organizational measures to protect your personal data. However, no method of transmission over the internet is 100% secure.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-3">6. Contact</h2>
          <p>For privacy-related questions or requests, contact us at <a href="mailto:privacy@cleanking.com" className="text-[#800000] hover:underline">privacy@cleanking.com</a>.</p>
        </section>
      </div>
    </div>
  );
}
