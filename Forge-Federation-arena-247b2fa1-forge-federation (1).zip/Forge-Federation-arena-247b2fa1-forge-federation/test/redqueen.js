'use strict';

/**
 * redqueen.js — attack the carrier separation and the repair memory.
 *
 * Not a test suite. A Hornet. Every attack below is a real attempt to make the
 * system assert something false, and each one reports LANDED or BLOCKED with the
 * evidence. An attack that is blocked is not deleted: knowing which doors are
 * locked is half the value, and a lock nobody tests is a lock nobody trusts.
 *
 *   node test/redqueen.js
 *
 * The standard being attacked is the one docs/DIAMOND.md sets: no `X` anywhere
 * in scope. A landed attack is an exposure.
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const { Federation, NodeRegistry } = require(path.join(ROOT, 'src/federation/index.js'));
const { canonicalJson, verifyLedger, sha256Bytes, ZERO } = require(path.join(ROOT, 'src/forge/ledger.js'));
const { readCycle, landLesson, ingestCycle } = require(path.join(ROOT, 'src/forge/lessons.js'));
const { transfer } = require(path.join(ROOT, 'src/federation/bridge.js'));
const { repoRealm } = require(path.join(ROOT, 'src/federation/realm.js'));

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'ff-redqueen-'));
const results = [];

// A thrown exception is NOT a defense. Counting a crash as a block is how a
// harness reports a green it did not earn — the same "unreadable failure" the
// DIAMOND standard calls the real defect. So a throw is its own verdict, and it
// fails the run exactly like a landed attack does.
function attack(id, name, fn) {
  let verdict;
  try {
    verdict = fn();
  } catch (e) {
    verdict = { landed: false, inconclusive: true, how: `INCONCLUSIVE — threw ${e.constructor.name}: ${e.message}` };
  }
  results.push({ id, name, ...verdict });
  const tag = verdict.landed
    ? '\x1b[41m LANDED \x1b[0m'
    : verdict.inconclusive
      ? '\x1b[43m UNPROVEN \x1b[0m'
      : '\x1b[42m BLOCKED \x1b[0m';
  console.log(`${tag} ${id}  ${name}`);
  console.log(`         ${verdict.how || ''}`);
  if (verdict.fix) console.log(`         fix: ${verdict.fix}`);
}

const blob = (dir, value) => {
  const bytes = Buffer.from(canonicalJson(value), 'utf8');
  const id = sha256Bytes(bytes);
  fs.writeFileSync(path.join(dir, 'blobs', id), bytes);
  return { id, bytes: bytes.length, mediaType: 'application/json' };
};

/** A genuine, fully verified cycle. The attacks mutate it afterwards. */
function buildCycle(dir, opts = {}) {
  const ledgerDir = path.join(dir, 'ledger');
  fs.mkdirSync(path.join(ledgerDir, 'blobs'), { recursive: true });
  const runId = 'run-rq-1';
  const lines = [];
  let previous = ZERO;
  const append = (type, data, o = {}) => {
    const body = {
      schemaVersion: 1, runId, sequence: lines.length + 1, previous, type,
      timestamp: new Date(Date.UTC(2026, 9, 17, 12, 0, lines.length)).toISOString(),
      elapsedNs: String(1e6 * (lines.length + 1)),
      parents: o.parents || [], artifacts: o.artifacts || [], rationale: null, data,
    };
    const id = sha256Bytes(Buffer.from(canonicalJson(body), 'utf8'));
    lines.push(canonicalJson({ ...body, id }));
    previous = id;
    return id;
  };
  const failures = [{ caseId: 'probe-1', expected: 'a.js', got: 'b.js' }];
  const changed = opts.changedPaths || ['src/session/auth.js'];
  const contract = append('repository.contract', { specs: ['discovery'] });
  const bm = blob(ledgerDir, { files: [{ path: changed[0], sha256: sha256Bytes(Buffer.from('o\n')), bytes: 2 }] });
  const base = append('repository.baseline', { manifestId: bm.id }, { parents: [contract], artifacts: [bm] });
  const dr = blob(ledgerDir, { failures });
  const disc = append('repository.evaluated', { targetId: bm.id, specName: 'discovery', passed: false, resultId: dr.id }, { parents: [base], artifacts: [dr] });
  const cm = blob(ledgerDir, { files: [] });
  const patch = blob(ledgerDir, { parentId: bm.id, edits: changed.map((p) => ({ path: p })) });
  const cand = append('repository.candidate', { parentId: bm.id, manifestId: cm.id, patchId: patch.id, changedPaths: changed }, { parents: [disc, contract], artifacts: [cm, patch] });
  const gates = [];
  for (const n of opts.gateNames || ['native', 'locked', 'fresh']) {
    const g = blob(ledgerDir, { passed: true });
    gates.push(append('repository.evaluated', { targetId: cm.id, specName: n, passed: true, resultId: g.id }, { parents: [cand], artifacts: [g] }));
  }
  const prom = append('repository.promoted', { targetId: cm.id, gateIds: gates, status: opts.promotedStatus || 'local-exact-source-promotion-not-release' }, { parents: gates });
  const lesson = {
    status: 'bounded-historical-observation-not-universal-rule', project: opts.project || 'clearcut',
    failures, patchId: patch.id, baselineId: bm.id, candidateId: cm.id, evidence: [disc, ...gates],
    limits: opts.limits || ['same case families with fresh parameters', 'no prediction of future code correctness'],
  };
  const la = blob(ledgerDir, lesson);
  const le = append('repository.lesson', { lessonId: la.id }, { parents: [prom], artifacts: [la] });
  const summary = {
    schemaVersion: 1, project: opts.project || 'clearcut', baselineId: bm.id, promotedId: cm.id,
    reproducedFailingCases: failures.length, registeredCases: 5, changedPaths: changed,
    passedGates: opts.passedGates == null ? gates.length : opts.passedGates,
    nextTargetId: cm.id, lessonId: le,
    claim: 'real uploaded source changed and passed the specified frozen checks; not a diamond/perfection certificate',
  };
  const sa = blob(ledgerDir, summary);
  append('repository.completed', summary, { parents: [prom, le], artifacts: [sa] });
  fs.writeFileSync(path.join(ledgerDir, 'events.jsonl'), lines.join('\n') + '\n');
  fs.writeFileSync(path.join(dir, 'receipt.json'), canonicalJson({ runId, events: lines.length, head: previous, failed: false, status: 'completed' }) + '\n');
  fs.writeFileSync(path.join(dir, 'summary.json'), canonicalJson(summary) + '\n');
  return { head: previous, summary, ledgerDir, receiptPath: path.join(dir, 'receipt.json'), summaryPath: path.join(dir, 'summary.json') };
}

function fedWith(...slugs) {
  const dir = tmp();
  const nodes = new NodeRegistry(dir, { gitRemote: () => null }).load();
  for (const s of slugs) nodes.register({ remote: `https://github.com/me/${s}`, localPath: `/tmp/${s}` });
  return new Federation(dir, { nodes }).load();
}

console.log('\n' + '='.repeat(78));
console.log('RED QUEEN — attacking the carrier separation and the repair memory');
console.log('='.repeat(78) + '\n');

// ============================================================ CARRIER SEPARATION

attack('A1', 'read a browser fact through a repair briefing', () => {
  const fed = fedWith('twin-labs');
  fed.land({ shelf: 'operational', carrier: 'browser', equation: { subject: 'repo:t', predicate: 'test', object: 'x' }, witness: 'structural', nodeId: 'twin-labs', reference: 'r', target: 'repo:t' });
  const b = fed.briefing({ carrier: 'repair', viewer: 'twin-labs' });
  return b.facts.length === 0
    ? { landed: false, how: `briefing returned ${b.facts.length} facts; otherCarriers=${JSON.stringify(b.otherCarriers)}` }
    : { landed: true, how: `${b.facts.length} browser fact(s) reached a repair briefing` };
});

attack('A2', 'promote a repair fact using arrived witnesses only', () => {
  const browser = fedWith('cockpit');
  const repair = fedWith('r1', 'r2', 'r3', 'r4', 'r5');
  const eq = { subject: 'capital', predicate: 'of', object: 'paris' };
  for (let i = 0; i < 5; i++) browser.land({ shelf: 'world', carrier: 'browser', equation: eq, witness: 'structural', nodeId: 'cockpit', reference: `r${i}` });
  const sig = browser.live()[0].signature;
  for (let i = 0; i < 5; i++) transfer(browser, repair, { from: 'browser', to: 'repair', nodeId: `r${i + 1}`, signatures: [sig] });
  const f = repair.live()[0];
  return f.status === 'established'
    ? { landed: true, how: `established on ${f.arrived} arrived witnesses, ${f.observed} observed` }
    : { landed: false, how: `status=${f.status}, distinct=${f.distinct}, arrived=${f.arrived}, observed=${f.observed}` };
});

attack('A3', 'mint witnesses by re-transferring through rotating node ids', () => {
  const browser = fedWith('cockpit');
  const repair = fedWith(...Array.from({ length: 12 }, (_, i) => `n${i}`));
  const src = browser.land({ shelf: 'operational', carrier: 'browser', equation: { subject: 's', predicate: 'p', object: 'o' }, witness: 'structural', nodeId: 'cockpit', reference: 'r', target: 's' }).fact;
  for (let i = 0; i < 12; i++) transfer(browser, repair, { from: 'browser', to: 'repair', nodeId: `n${i}`, signatures: [src.signature] });
  const f = repair.live()[0];
  return f.observed > 0
    ? { landed: true, how: `${f.observed} of ${f.distinct} witnesses counted as observed` }
    : { landed: false, how: `distinct=${f.distinct} but observed=${f.observed} — none of them can vote` };
});

attack('A4', 'close a repair fact with a browser contradiction', () => {
  const fed = fedWith('twin-labs');
  const eq = { subject: 'repo:t', predicate: 'runner', object: 'jest' };
  fed.land({ shelf: 'world', carrier: 'repair', equation: eq, witness: 'structural', nodeId: 'twin-labs', reference: 'r1' });
  fed.contradict({ shelf: 'world', carrier: 'browser', equation: { subject: 'repo:t', predicate: 'runner', object: 'vitest' }, witness: 'structural', nodeId: 'twin-labs', reference: 'r2' });
  const f = fed.findByPredicate('repo:t', 'runner', 'world', 'shared', 'repair');
  return !f || f.closedAt
    ? { landed: true, how: 'the repair fact was closed from another carrier' }
    : { landed: false, how: `repair fact intact: ${f.equation.object}, closedAt=${f.closedAt}` };
});

attack('A5', 'read a migrated legacy fact whose observed/arrived were never written', () => {
  const dir = tmp();
  fs.mkdirSync(dir, { recursive: true });
  const eq = { subject: 'repo:old', predicate: 'test', object: 'make test' };
  const data = {
    id: 'f_old', schema: 'forgeflight.federation.v2', signature: null, realm: 'shared', shelf: 'operational',
    equation: eq, rendered: 'test(repo:old) = make test', target: 'repo:old', status: 'provisional',
    witnesses: [{ sig: 'w', kind: 'structural', nodeId: 'n1', reference: 'r', at: '2026-01-01T00:00:00.000Z' }],
    distinct: 1, landedAt: '2026-01-01T00:00:00.000Z', lastSeenAt: '2026-01-01T00:00:00.000Z',
    supersededBy: null, closedAt: null, closedBy: null,
  };
  const { equationSignature } = require(path.join(ROOT, 'src/passport/equation.js'));
  data.signature = equationSignature(eq, 'shared|operational');
  const { chainHash, GENESIS } = require(path.join(ROOT, 'src/federation/store.js'));
  const rec = { op: 'fact', data };
  fs.writeFileSync(path.join(dir, 'federation.jsonl'), JSON.stringify({ ...rec, prev: GENESIS, hash: chainHash(GENESIS, rec) }) + '\n');
  const fed = new Federation(dir).load();
  const f = fed.live()[0];
  const bad = f.observed === undefined || f.arrived === undefined;
  return bad
    ? { landed: true, how: `observed=${f.observed}, arrived=${f.arrived} — renders as "undefined/1 observed" in every briefing`, fix: 'backfill both counters in apply() when adopting a pre-v3 record' }
    : { landed: false, how: `observed=${f.observed}, arrived=${f.arrived}` };
});

// ======================================================================= BRIDGE

attack('A6', 'strip an origin from an arrived witness so it can vote', () => {
  const browser = fedWith('cockpit');
  const repairDir = tmp();
  const nodes = new NodeRegistry(repairDir, { gitRemote: () => null }).load();
  nodes.register({ remote: 'https://github.com/me/cockpit', localPath: '/tmp/cockpit' });
  const repair = new Federation(repairDir, { nodes }).load();
  const eq = { subject: 'capital', predicate: 'of', object: 'paris' };
  for (let i = 0; i < 5; i++) browser.land({ shelf: 'world', carrier: 'browser', equation: eq, witness: 'structural', nodeId: 'cockpit', reference: `r${i}` });
  transfer(browser, repair, { from: 'browser', to: 'repair', nodeId: 'cockpit', signatures: [browser.live()[0].signature] });
  // Edit the log on disk to remove the origin, then reload.
  const logPath = path.join(repairDir, 'federation.jsonl');
  const edited = fs.readFileSync(logPath, 'utf8').split('\n').filter(Boolean).map((l) => {
    const o = JSON.parse(l);
    if (o.op === 'fact' && o.data.witnesses) for (const w of o.data.witnesses) delete w.origin;
    return JSON.stringify(o);
  }).join('\n') + '\n';
  fs.writeFileSync(logPath, edited);
  const reloaded = new Federation(repairDir, { nodes }).load();
  const breaks = reloaded.chain.breaks.length;
  return breaks === 0
    ? { landed: true, how: 'the chain did not notice the edit' }
    : { landed: false, how: `${breaks} chain break(s) reported: ${JSON.stringify(reloaded.chain.breaks.slice(0, 2))} — tampering is visible, and the fact is refused, not trusted` };
});

attack('A7', 'transfer a closed fact so it arrives alive', () => {
  const browser = fedWith('cockpit');
  const repair = fedWith('cockpit');
  browser.land({ shelf: 'world', carrier: 'browser', equation: { subject: 'a', predicate: 'b', object: 'one' }, witness: 'structural', nodeId: 'cockpit', reference: 'r1' });
  browser.contradict({ shelf: 'world', carrier: 'browser', equation: { subject: 'a', predicate: 'b', object: 'two' }, witness: 'structural', nodeId: 'cockpit', reference: 'r2' });
  const closed = browser.all().find((f) => f.status === 'closed');
  const res = transfer(browser, repair, { from: 'browser', to: 'repair', nodeId: 'cockpit', signatures: [closed.signature] });
  return res.transferred.length > 0
    ? { landed: true, how: 'a closed fact arrived alive' }
    : { landed: false, how: `refused: ${res.refused[0].reason} — ${res.refused[0].detail}` };
});

attack('A8', 'two writers appending to one store at once', () => {
  // The bridge appends a `transfer-out` event to the SOURCE store, so a store
  // can have two writers: this process and whoever else has it open. Nothing in
  // the store takes a lock. This attack runs two real processes against one
  // file, genuinely concurrently, and then asks whether the chain survived.
  const dir = tmp();
  const nodes = new NodeRegistry(dir, { gitRemote: () => null }).load();
  nodes.register({ remote: 'https://github.com/me/w1', localPath: '/tmp/w1' });
  nodes.register({ remote: 'https://github.com/me/w2', localPath: '/tmp/w2' });

  const writer = path.join(dir, 'writer.js');
  fs.writeFileSync(writer, [
    `const { Federation, NodeRegistry } = require(${JSON.stringify(path.join(ROOT, 'src/federation/index.js'))});`,
    `const dir = ${JSON.stringify(dir)};`,
    'const nodes = new NodeRegistry(dir, { gitRemote: () => null }).load();',
    'const fed = new Federation(dir, { nodes }).load();',
    'const me = process.argv[2];',
    'let ok = 0; const refused = [];',
    'for (let i = 0; i < 60; i++) {',
    "  const r = fed.land({ shelf: 'operational', carrier: 'repair', realm: 'repo:' + me,",
    // A field over MAX_FIELD is refused as not-an-equation, so the payload has
    // to be a real equation or every append silently no-ops.
    "    equation: { subject: 'repo:' + me, predicate: 'k' + i, object: 'v' + i },",
    "    witness: 'structural', nodeId: me, reference: 'r' + i, target: 'repo:' + me });",
    '  if (r && r.rejected) refused.push(r.reason); else ok++;',
    '}',
    // The writer REPORTS its refusals. `land()` returns them instead of
    // throwing, so a writer that ignores the result prints success over zero
    // writes -- which is precisely how the first version of this attack proved
    // nothing while looking like it had.
    "process.stdout.write('ok=' + ok + ':refused=' + refused.length + (refused[0] ? ':' + refused[0] : '') + ':' + me);",
  ].join('\n'));

  // Both backgrounded in one shell, then `wait`: truly concurrent, and the
  // harness stays synchronous. A concurrency test that serialises its writers
  // proves nothing, which is exactly what the first version of this attack did.
  const run = spawnSync('/bin/sh', ['-c', `node ${writer} w1 & node ${writer} w2 & wait`], { encoding: 'utf8', timeout: 60000 });
  const out = `${run.stdout || ''}`;
  const both = /ok=(\d+):refused=(\d+)(?::([^:]+))?:w1/.exec(out) && /ok=(\d+):refused=(\d+)(?::([^:]+))?:w2/.exec(out);
  if (!both) {
    return {
      inconclusive: true, landed: false,
      how: `a writer did not report, so this proved nothing — stdout: ${out.slice(0, 140)} stderr: ${(run.stderr || '').slice(0, 160)}`,
    };
  }
  if (both[1] !== '60' || both[2] !== '0') {
    return {
      inconclusive: true, landed: false,
      how: `w1 landed ${both[1]}/60 and refused ${both[2]} (${both[3] || '-'}): the attack never exercised the write path`,
    };
  }

  const logPath = path.join(dir, 'federation.jsonl');
  const raw = fs.readFileSync(logPath, 'utf8');
  const lines = raw.split('\n').filter(Boolean).length;
  const checked = new Federation(dir, { nodes }).load();
  const breaks = checked.chain.breaks.length;

  // 120 appends were made. Fewer lines on disk means writes were LOST, which is
  // worse than a broken chain: a lost write is a fact that never existed and
  // nothing reports it.
  if (lines < 120) {
    return {
      landed: true,
      how: `${lines} lines on disk but 120 appends were made — writes were LOST, not merely reordered, and nothing reported the loss`,
      fix: 'appendFileSync from two processes is not serialised; the store needs a lock, or a documented single-writer rule that the bridge respects',
    };
  }
  if (breaks > 0) {
    return {
      landed: true,
      how: `${breaks} chain break(s) across ${lines} lines from two concurrent appenders`,
      fix: 'the store has no write lock; two processes appending to one JSONL can interleave',
    };
  }
  return { landed: false, how: `${lines} lines, chain intact over ${checked.chain.chained} links, ${breaks} breaks — concurrent appends survived` };
});

// ================================================================ REPAIR MEMORY

attack('M1', 'lie about the bar in summary.json, which the chain does not cover', () => {
  const dir = tmp();
  const built = buildCycle(dir, { passedGates: 3 });
  // summary.json is a plain file beside the ledger. Rewrite it; touch nothing
  // that is hashed.
  const summary = JSON.parse(fs.readFileSync(built.summaryPath, 'utf8'));
  const forged = { ...summary, passedGates: 99, changedPaths: ['src/never/touched.js'] };
  fs.writeFileSync(built.summaryPath, canonicalJson(forged) + '\n');

  const read = readCycle(dir);
  if (read.rejected) return { landed: false, how: `refused: ${read.reason} — ${read.detail}` };
  const fed = fedWith('clearcut');
  landLesson(fed, read.cycle, { slug: 'clearcut', nodeId: 'clearcut' });
  const bar = fed.live().find((f) => f.equation.predicate === 'risk_repair_bar');
  const lied = bar && /99-gates-passed/.test(bar.equation.object);
  return lied
    ? { landed: true, how: `the commons now asserts "${bar.equation.object}" — forged from a file no hash covers, and it TRAVELS to every other repository's passport`, fix: 'derive passedGates/changedPaths from the verified ledger events, not from summary.json; or refuse when they disagree' }
    : { landed: false, how: `bar reads ${bar && bar.equation.object}` };
});

attack('M2', 'file a lesson about a DIFFERENT repository than the one witnessing', () => {
  const dir = tmp();
  buildCycle(dir, { project: 'clearcut' });
  const fed = fedWith('twin-labs', 'fleets');
  // twin-labs is registered. It names --slug fleets, so the SUBJECT becomes
  // repo:fleets while the WITNESS is twin-labs.
  const res = ingestCycle(fed, dir, { slug: 'fleets', nodeId: 'twin-labs' });
  if (res.rejected) return { landed: false, how: `refused: ${res.reason}` };
  const bar = fed.live().find((f) => f.equation.predicate === 'risk_repair_bar');
  const wrongSubject = bar && bar.equation.subject === 'repo:fleets';
  return wrongSubject
    ? { landed: true, how: `twin-labs filed "${bar.rendered}" — fleets now carries a repair bar it never ran, and it will be told it was "found elsewhere" in its own passport`, fix: 'the subject repository and the witnessing node must agree, or the mismatch must be recorded as a claim ABOUT another repo rather than as that repo\'s own fact' }
    : { landed: false, how: `subject=${bar && bar.equation.subject}` };
});

attack('M3', 'soften a boundary by making a limit longer than one field', () => {
  const dir = tmp();
  const long = 'this repair was verified only against the frozen probe set recorded in this ledger and establishes nothing whatsoever about any other defect class, any other repository, any future version of this code, or any behavior not exercised by the registered cases';
  buildCycle(dir, { limits: [long] });
  const fed = fedWith('clearcut');
  const res = ingestCycle(fed, dir, { nodeId: 'clearcut' });
  if (res.rejected) return { landed: false, how: `refused: ${res.reason}` };
  const limit = fed.live().find((f) => f.equation.predicate === 'limit_1');
  const obj = limit ? limit.equation.object : '';
  const truncated = obj.length < long.length;
  return truncated
    ? { landed: true, how: `the limit was cut to ${obj.length}/${long.length} chars ending "${obj.slice(-24)}" — a truncated boundary reads as a weaker one, which is the exact softening this file claims to prevent`, fix: 'never truncate a limit: store a count plus the ledger pointer, the way repaired_paths already does' }
    : { landed: false, how: `the full ${obj.length}-char limit survived` };
});

attack('M4', 'exhaust memory with a cycle whose blobs are large', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  // A real cycle holds source snapshots. Add unreferenced-but-valid large blobs,
  // which verifyLedger hashes anyway because it checks every file present.
  const big = Buffer.alloc(64 * 1024 * 1024, 7); // 64 MiB
  fs.writeFileSync(path.join(built.ledgerDir, 'blobs', sha256Bytes(big)), big);
  const t0 = Date.now();
  const before = process.memoryUsage().heapUsed;
  const res = verifyLedger(built.ledgerDir);
  const ms = Date.now() - t0;
  const grew = process.memoryUsage().heapUsed - before;
  return res.ok && ms < 5000
    ? { landed: false, how: `verified in ${ms}ms (blob hashed and accepted)` }
    : { landed: true, how: `${ms}ms, heap grew ${(grew / 1048576).toFixed(0)} MiB for one 64 MiB blob — every blob is read fully into memory to be hashed`, fix: 'stream the hash instead of reading whole blobs; and bound the total bytes a cycle may present' };
});

attack('M5', 'land a lesson with a dangling blob pointer as its witness', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  const summary = JSON.parse(fs.readFileSync(built.summaryPath, 'utf8'));
  delete summary.baselineId;
  fs.writeFileSync(built.summaryPath, canonicalJson(summary) + '\n');
  const read = readCycle(dir);
  if (read.rejected) return { landed: false, how: `refused: ${read.reason}` };
  const fed = fedWith('clearcut');
  landLesson(fed, read.cycle, { slug: 'clearcut', nodeId: 'clearcut' });
  const paths = fed.live().find((f) => f.equation.predicate === 'repaired_paths');
  const dangling = paths && /blob:$/.test(paths.witnesses[0].reference);
  return dangling
    ? { landed: true, how: `witness reference is "${paths.witnesses[0].reference}" — it points at no blob, so the "re-derivable" witness is not re-derivable`, fix: 'refuse, or fall back to the ledger head alone rather than emitting an empty pointer' }
    : { landed: false, how: `reference=${paths && paths.witnesses[0].reference}` };
});

attack('M6', 'get a defect specific into the commons where every repo will read it', () => {
  const dir = tmp();
  buildCycle(dir, { project: 'clearcut' });
  const fed = fedWith('clearcut', 'fleets');
  ingestCycle(fed, dir, { nodeId: 'clearcut' });
  const commons = fed.live({ realm: 'shared' }).map((f) => f.equation.predicate);
  const leaked = fed.live({ realm: 'shared' }).filter((f) => /repaired_paths|reproduced_failures|limit_/.test(f.equation.predicate));
  const brief = fed.briefing({ realm: repoRealm('fleets'), viewer: 'fleets' });
  const reachedFleets = brief.facts.filter((f) => /repaired_paths|reproduced_failures|limit_/.test(f.equation.predicate));
  return leaked.length > 0 || reachedFleets.length > 0
    ? { landed: true, how: `${leaked.length} specifics in the commons, ${reachedFleets.length} reached fleets` }
    : { landed: false, how: `commons holds only [${commons.sort().join(', ')}]; fleets' briefing carries none of the specifics` };
});

attack('M7', 'forge the promoted status into a release', () => {
  const dir = tmp();
  const built = buildCycle(dir, { promotedStatus: 'local-exact-source-promotion-not-release' });
  // The promoted event IS in the chain, so editing it should break verification.
  const logPath = path.join(built.ledgerDir, 'events.jsonl');
  const lines = fs.readFileSync(logPath, 'utf8').trimEnd().split('\n').map((l) => {
    const ev = JSON.parse(l);
    if (ev.type === 'repository.promoted') ev.data.status = 'released-to-production';
    return JSON.stringify(ev);
  });
  fs.writeFileSync(logPath, lines.join('\n') + '\n');
  const read = readCycle(dir);
  return read.ok
    ? { landed: true, how: `the cycle still verified and reports promotion="${read.cycle.promotedStatus}"` }
    : { landed: false, how: `refused: ${read.reason} — the promotion status is inside the chain, so upgrading it is detectable` };
});

attack('M8', 'sneak a lesson onto the browser carrier', () => {
  const dir = tmp();
  buildCycle(dir);
  const fed = fedWith('clearcut');
  const res = ingestCycle(fed, dir, { nodeId: 'clearcut', carrier: 'browser' });
  return res.ok
    ? { landed: true, how: 'source-level detail landed where a chat composer can read it' }
    : { landed: false, how: `refused: ${res.reason} — ${String(res.detail).slice(0, 90)}` };
});

// ======================================================================= REPORT

const landed = results.filter((r) => r.landed);
const unproven = results.filter((r) => r.inconclusive);
console.log('\n' + '='.repeat(78));
console.log(`RED QUEEN VERDICT — ${landed.length} LANDED, ${unproven.length} UNPROVEN, ${results.length - landed.length - unproven.length} blocked`);
console.log('='.repeat(78));
for (const r of [...landed, ...unproven]) {
  console.log(`\n  ${r.id}  ${r.name}\n      ${r.how}${r.fix ? `\n      FIX: ${r.fix}` : ''}`);
}
if (!landed.length && !unproven.length) console.log('\n  nothing landed, and every attack ran to a verdict.');
console.log('');
// An unproven attack fails the run too: "it did not work" and "we could not
// tell" are different claims and only one of them is safe to ship.
process.exitCode = landed.length + unproven.length ? 1 : 0;
