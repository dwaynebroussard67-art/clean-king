'use strict';

/**
 * A repair cycle becomes memory without becoming a rule.
 *
 * Twin Labs stamps every lesson `bounded-historical-observation-not-universal-
 * rule` and refuses to generalize. That refusal is correct. These tests pin what
 * the Federation does with it: the METHOD and its boundary travel to the commons,
 * the defect specifics stay scoped to the repository they came from, and the
 * scope line travels with the claim every time.
 *
 * They also pin the part that makes the witness `structural` rather than
 * `outcome`: the ledger is re-derived from the published format here, so a
 * tampered cycle is refused instead of believed.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const { canonicalJson, verifyLedger, readBlob, sha256Bytes, ZERO } = require('../src/forge/ledger.js');
const { readCycle, landLesson, ingestCycle, lessonEquations, LESSON_SCOPE } = require('../src/forge/lessons.js');
const { Federation } = require('../src/federation/store.js');
const { NodeRegistry } = require('../src/federation/nodes.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'ff-lessons-'));
const blob = (dir, value) => {
  const bytes = Buffer.from(canonicalJson(value), 'utf8');
  const id = sha256Bytes(bytes);
  fs.writeFileSync(path.join(dir, 'blobs', id), bytes);
  return { id, bytes: bytes.length, mediaType: 'application/json' };
};

/** Build a cycle directory in Twin Labs' published format: a hash-chained
 *  event log over content-addressed blobs, plus a receipt and a summary. */
function buildCycle(dir, opts = {}) {
  const ledgerDir = path.join(dir, 'ledger');
  fs.mkdirSync(path.join(ledgerDir, 'blobs'), { recursive: true });

  const runId = opts.runId || 'run-test-0001';
  const lines = [];
  const ids = [];
  let previous = ZERO;

  const append = (type, data, { parents = [], artifacts = [] } = {}) => {
    const body = {
      schemaVersion: 1, runId, sequence: lines.length + 1, previous, type,
      // Overridable so a test can build a chain that is genuine in every
      // respect except one value.
      timestamp: opts.timestamp || new Date(Date.UTC(2026, 9, 17, 12, 0, lines.length)).toISOString(),
      elapsedNs: String(1000000 * (lines.length + 1)), parents, artifacts, rationale: null, data,
    };
    const id = sha256Bytes(Buffer.from(canonicalJson(body), 'utf8'));
    lines.push(canonicalJson({ ...body, id }));
    ids.push(id);
    previous = id;
    return id;
  };

  const failures = opts.failures || [{ caseId: 'probe-1', expected: 'a.js', got: 'b.js' }, { caseId: 'probe-2', expected: 'c.js', got: null }];
  const changedPaths = opts.changedPaths || ['src/federation/store.js', 'src/forge/runner.js'];

  const contract = append('repository.contract', { specs: ['discovery', 'reproduction', 'native', 'locked', 'fresh-retest'] });
  const baselineFiles = [{ path: changedPaths[0], sha256: sha256Bytes(Buffer.from('original\n')), bytes: 9 }];
  fs.writeFileSync(path.join(ledgerDir, 'blobs', baselineFiles[0].sha256), Buffer.from('original\n'));
  const baselineManifest = blob(ledgerDir, { files: baselineFiles });
  const baseline = append('repository.baseline', { manifestId: baselineManifest.id }, { parents: [contract], artifacts: [baselineManifest] });

  const discoveryResult = blob(ledgerDir, { failures });
  const discoveryProc = blob(ledgerDir, { exitCode: 1, stdout: 'not ok 1', stderr: '' });
  const discovery = append('repository.evaluated', { targetId: baselineManifest.id, specName: 'discovery', passed: false, processId: discoveryProc.id, resultId: discoveryResult.id },
    { parents: [baseline, contract], artifacts: [discoveryProc, discoveryResult] });

  const reproResult = blob(ledgerDir, { failures });
  const repro = append('repository.evaluated', { targetId: baselineManifest.id, specName: 'reproduction', passed: false, resultId: reproResult.id },
    { parents: [discovery], artifacts: [reproResult] });

  const patch = blob(ledgerDir, { parentId: baselineManifest.id, edits: changedPaths.map((p) => ({ path: p })) });
  const candidateManifest = blob(ledgerDir, { files: baselineFiles });
  const candidate = append('repository.candidate', { parentId: baselineManifest.id, manifestId: candidateManifest.id, patchId: patch.id, changedPaths },
    { parents: [repro, contract], artifacts: [candidateManifest, patch] });

  const gates = [];
  for (const name of ['native', 'locked', 'fresh-retest']) {
    const r = blob(ledgerDir, { passed: true });
    gates.push(append('repository.evaluated', { targetId: candidateManifest.id, specName: name, passed: true, resultId: r.id }, { parents: [candidate], artifacts: [r] }));
  }

  const promoted = append('repository.promoted', {
    targetId: candidateManifest.id, gateIds: gates,
    status: opts.promotedStatus || 'local-exact-source-promotion-not-release',
  }, { parents: gates });

  const lessonValue = {
    status: LESSON_SCOPE,
    project: opts.project || 'twin-labs',
    failures,
    patchId: patch.id,
    baselineId: baselineManifest.id,
    candidateId: candidateManifest.id,
    evidence: [discovery, repro, ...gates],
    limits: opts.limits || [
      'same case families with fresh parameters; not independent discovery of new vulnerability classes',
      'no prediction of future code correctness',
    ],
  };
  const lessonArtifact = blob(ledgerDir, lessonValue);
  const lessonEvent = append('repository.lesson', { lessonId: lessonArtifact.id }, { parents: [promoted], artifacts: [lessonArtifact] });

  const summary = {
    schemaVersion: 1, project: opts.project || 'twin-labs',
    baselineId: baselineManifest.id, promotedId: candidateManifest.id,
    reproducedFailingCases: failures.length, registeredCases: 5,
    changedPaths, passedGates: gates.length, nextTargetId: candidateManifest.id,
    lessonId: lessonEvent,
    claim: 'real uploaded source changed and passed the specified frozen checks; not a diamond/perfection certificate',
  };
  const summaryArtifact = blob(ledgerDir, summary);
  append('repository.completed', summary, { parents: [promoted, lessonEvent], artifacts: [summaryArtifact] });

  fs.writeFileSync(path.join(ledgerDir, 'events.jsonl'), lines.join('\n') + '\n');
  const receipt = { runId, events: lines.length, head: previous, failed: false, status: opts.status || 'completed' };
  fs.writeFileSync(path.join(dir, 'receipt.json'), canonicalJson(receipt) + '\n');
  fs.writeFileSync(path.join(dir, 'summary.json'), canonicalJson(summary) + '\n');
  return { receipt, summary, head: previous, lines, ids, ledgerDir };
}

/** A Federation with one or more registered repositories, ready to witness.
 *  Each slug becomes a real remote, so the registry derives the same slug back
 *  and a test cannot accidentally register a node under a name it did not ask
 *  for — which is exactly the mistake the first version of this helper made. */
function fedWith(...slugs) {
  const dir = tmp();
  const nodes = new NodeRegistry(dir, { gitRemote: () => null }).load();
  for (const slug of slugs.length ? slugs : ['twin-labs']) {
    const res = nodes.register({ remote: `https://github.com/me/${slug}`, localPath: `/tmp/${slug}` });
    if (!res || res.rejected || !res.node) throw new Error(`test setup could not register '${slug}': ${JSON.stringify(res)}`);
    if (res.node.slug !== slug) throw new Error(`test setup registered '${slug}' as '${res.node.slug}'`);
  }
  return new Federation(dir, { nodes }).load();
}

// --------------------------------------------------------------- canonicalJson

test('canonicalJson sorts object keys and preserves array order', () => {
  assert.equal(canonicalJson({ b: 1, a: 2 }), '{"a":2,"b":1}');
  assert.equal(canonicalJson([3, 1, 2]), '[3,1,2]', 'an array is a sequence, not a set');
  assert.equal(canonicalJson({ z: { y: [1, { b: 1, a: 2 }] } }), '{"z":{"y":[1,{"a":2,"b":1}]}}');
  assert.equal(canonicalJson('a"b'), '"a\\"b"');
  assert.equal(canonicalJson(null), 'null');
  assert.equal(canonicalJson(true), 'true');
});

test('canonicalJson refuses anything JSON would silently lose', () => {
  assert.throws(() => canonicalJson(NaN), /lossless/);
  assert.throws(() => canonicalJson(Infinity), /lossless/);
  assert.throws(() => canonicalJson(-0), /lossless/, '-0 and 0 stringify the same but are not the same number');
  assert.throws(() => canonicalJson([1, , 3]), /sparse/);
  assert.throws(() => canonicalJson({ [Symbol('s')]: 1 }), /symbol/);
  const cyclic = {}; cyclic.self = cyclic;
  assert.throws(() => canonicalJson(cyclic), /cycle/);
  class Thing { constructor() { this.a = 1; } }
  assert.throws(() => canonicalJson(new Thing()), /plain data/);
  const accessor = {}; Object.defineProperty(accessor, 'x', { get: () => 1, enumerable: true });
  assert.throws(() => canonicalJson(accessor), /accessor/);
});

// ------------------------------------------------------------------ the ledger

test('a well-formed ledger verifies, and reports its head', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  const res = verifyLedger(built.ledgerDir, { expectedHead: built.head });
  assert.equal(res.ok, true);
  assert.equal(res.head, built.head);
  assert.equal(res.events.length, built.lines.length);
  assert.equal(res.runId, 'run-test-0001');
});

test('an edited event is caught, because its id is recomputed from its body', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  const logPath = path.join(built.ledgerDir, 'events.jsonl');
  const lines = fs.readFileSync(logPath, 'utf8').trimEnd().split('\n');
  const ev = JSON.parse(lines[4]);
  ev.data.status = 'release'; // a quiet upgrade of what the promotion meant
  lines[4] = JSON.stringify(ev);
  fs.writeFileSync(logPath, lines.join('\n') + '\n');

  const res = verifyLedger(built.ledgerDir);
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'id-mismatch');
  assert.match(res.detail, /does not hash to its own id/);
});

test('a swapped blob is caught by its own address', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  const blobs = fs.readdirSync(path.join(built.ledgerDir, 'blobs'));
  const victim = path.join(built.ledgerDir, 'blobs', blobs[0]);
  fs.writeFileSync(victim, Buffer.from('{"tampered":true}'));
  const res = verifyLedger(built.ledgerDir);
  assert.equal(res.rejected, true);
  assert.ok(['artifact-integrity', 'blob-integrity'].includes(res.reason), res.reason);
});

test('a truncated log, a broken chain and a moved head are each refused by name', () => {
  const good = tmp();
  const built = buildCycle(good);

  // truncated: last line cut off
  const t = tmp(); buildCycle(t);
  const tl = path.join(t, 'ledger', 'events.jsonl');
  fs.writeFileSync(tl, fs.readFileSync(tl, 'utf8').slice(0, -20));
  const trunc = verifyLedger(path.join(t, 'ledger'));
  assert.equal(trunc.rejected, true);
  assert.ok(['truncated', 'unparseable-event', 'id-mismatch'].includes(trunc.reason), trunc.reason);

  // chain broken: an event re-pointed at the wrong predecessor
  const c = tmp(); const cb = buildCycle(c);
  const cl = path.join(c, 'ledger', 'events.jsonl');
  const clines = fs.readFileSync(cl, 'utf8').trimEnd().split('\n').map((l) => JSON.parse(l));
  clines[3].previous = clines[0].id;
  fs.writeFileSync(cl, clines.map((l) => JSON.stringify(l)).join('\n') + '\n');
  const brk = verifyLedger(path.join(c, 'ledger'));
  assert.equal(brk.rejected, true);
  assert.ok(['chain-break', 'id-mismatch'].includes(brk.reason), brk.reason);

  // head pinned to something else
  const head = verifyLedger(built.ledgerDir, { expectedHead: 'f'.repeat(64) });
  assert.equal(head.rejected, true);
  assert.equal(head.reason, 'head-mismatch');
});

test('a stray file in the evidence directory is refused, not skipped', () => {
  const dir = tmp();
  const built = buildCycle(dir);
  fs.writeFileSync(path.join(built.ledgerDir, 'blobs', 'notes.txt'), 'not evidence');
  const res = verifyLedger(built.ledgerDir);
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'stray-blob');
  assert.match(res.detail, /not evidence is in the evidence directory/);
});

test('a symlinked ledger is refused: evidence that can be a link can be swapped', () => {
  const real = tmp(); buildCycle(real);
  const dir = tmp();
  fs.symlinkSync(path.join(real, 'ledger'), path.join(dir, 'ledger'));
  const res = verifyLedger(path.join(dir, 'ledger'));
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'symlink');
});

// ------------------------------------------------------------------ readCycle

test('a completed cycle reads, and carries its own refusal verbatim', () => {
  const dir = tmp();
  buildCycle(dir);
  const res = readCycle(dir);
  assert.equal(res.ok, true);
  const c = res.cycle;
  assert.equal(c.lesson.status, LESSON_SCOPE);
  assert.equal(c.promotedStatus, 'local-exact-source-promotion-not-release');
  assert.equal(c.gatesPassed, 3);
  assert.equal(c.reproducedFailingCases, 2);
  assert.deepEqual(c.changedPaths, ['src/federation/store.js', 'src/forge/runner.js']);
  assert.equal(c.lesson.limits.length, 2);
  assert.ok(c.head && c.head.length === 64);
});

test('an incomplete or failed cycle is not a lesson', () => {
  const a = tmp(); buildCycle(a, { status: 'failed' });
  assert.equal(readCycle(a).reason, 'incomplete');

  const b = tmp(); const bb = buildCycle(b);
  fs.writeFileSync(path.join(b, 'receipt.json'), canonicalJson({ ...bb.receipt, failed: true }) + '\n');
  assert.equal(readCycle(b).reason, 'failed-run');

  const c = tmp(); const cb = buildCycle(c);
  fs.writeFileSync(path.join(c, 'receipt.json'), canonicalJson({ ...cb.receipt, events: cb.receipt.events - 1 }) + '\n');
  assert.equal(readCycle(c).reason, 'event-count');

  assert.equal(readCycle('').reason, 'no-directory');
  assert.equal(readCycle(tmp()).reason, 'missing-file');
});

// ----------------------------------------------------------------- landing it

test('a lesson lands on the repair carrier, witnessed structurally', () => {
  const dir = tmp(); buildCycle(dir, { project: 'twin-labs' });
  const cycle = readCycle(dir).cycle;
  const fed = fedWith('twin-labs');

  const res = landLesson(fed, cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  assert.equal(res.ok, true);
  assert.equal(res.refused.length, 0, JSON.stringify(res.refused));
  assert.equal(res.carrier, 'repair');
  assert.equal(res.scope, LESSON_SCOPE);
  assert.ok(res.landed.length >= 6);
  assert.equal(fed.live().every((f) => f.carrier === 'repair'), true);
  assert.equal(fed.live().every((f) => f.witnesses[0].kind === 'structural'), true, 're-derivable, so it travels on its own');
  assert.equal(fed.live().every((f) => f.witnesses[0].reference.startsWith('ledger:')), true);
});

test('THE REFUSAL TRAVELS: the scope lands in the commons, not beside the lesson', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  landLesson(fed, readCycle(dir).cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });

  const scope = fed.live().find((f) => f.equation.predicate === 'claim_scope');
  assert.ok(scope, 'the scope is a fact');
  assert.equal(scope.realm, 'shared', 'in the commons, where every reader will meet it');
  assert.equal(scope.equation.object, LESSON_SCOPE, 'verbatim — rewording it would soften it');

  const promotion = fed.live().find((f) => f.equation.predicate === 'promotion');
  assert.equal(promotion.equation.object, 'local-exact-source-promotion-not-release', 'a promotion is never upgraded to a release');
});

test('the METHOD travels and the DEFECT does not', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  landLesson(fed, readCycle(dir).cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });

  const commons = fed.live({ realm: 'shared' }).map((f) => f.equation.predicate).sort();
  const scoped = fed.live({ realm: 'repo:twin-labs' }).map((f) => f.equation.predicate).sort();

  assert.deepEqual(commons, ['claim_scope', 'promotion', 'repair_verified', 'risk_repair_bar']);
  assert.ok(scoped.includes('repaired_paths'), 'the specifics stay in the repository');
  assert.ok(scoped.includes('reproduced_failures'));
  assert.ok(scoped.includes('limit_1') && scoped.includes('limit_2'), 'every stated limit is its own fact');

  // The point of the split: another repository's briefing picks up the bar and
  // the boundary, and never the defect.
  const other = fedWith('fleets');
  const brief = fed.briefing({ realm: 'repo:fleets', viewer: 'fleets' });
  const preds = brief.facts.map((f) => f.equation.predicate).sort();
  assert.deepEqual(preds, ['claim_scope', 'promotion', 'repair_verified', 'risk_repair_bar'],
    'a repair lesson in one repository reaches another passport as method + boundary, never as a defect claim');
  assert.equal(brief.facts.every((f) => f.equation.subject === 'repo:twin-labs'), true);
  void other;
});

test('risk_repair_bar is shaped for the hub to surface as "found elsewhere"', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  landLesson(fed, readCycle(dir).cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  const bar = fed.live().find((f) => f.equation.predicate === 'risk_repair_bar');
  // hub.down() surfaces predicates starting with `risk` that are present
  // somewhere and absent here. That filter is what makes a repair lesson reach
  // another repository's PASSPORT.md without any change to the hub.
  assert.ok(bar.equation.predicate.startsWith('risk'));
  assert.match(bar.equation.object, /exact-parent-edits-only/);
  assert.match(bar.equation.object, /native-tests-unchanged/);
  assert.match(bar.equation.object, /3-gates-passed/);
  assert.match(bar.equation.object, /promoted-not-released/);
});

test('a long path list becomes a count, never half a path', () => {
  const dir = tmp();
  const many = Array.from({ length: 40 }, (_, i) => `src/some/deeply/nested/module/file-number-${String(i).padStart(3, '0')}.js`);
  buildCycle(dir, { changedPaths: many });
  const cycle = readCycle(dir).cycle;
  const fed = fedWith('twin-labs');
  const res = landLesson(fed, cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  assert.equal(res.refused.length, 0, JSON.stringify(res.refused));

  const paths = fed.live().find((f) => f.equation.predicate === 'repaired_paths');
  assert.equal(paths.equation.object, '40-paths-see-ledger');
  assert.ok(paths.equation.object.length <= 120);
  assert.match(paths.witnesses[0].reference, /^ledger:[a-f0-9]{64}\|blob:/, 'and the full list is where the witness points');
});

test('a lesson refuses to land on the browser carrier', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  const res = landLesson(fed, readCycle(dir).cycle, { slug: 'twin-labs', nodeId: 'twin-labs', carrier: 'browser' });
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'carrier');
  assert.match(res.detail, /chat composer/);
  assert.equal(fed.live().length, 0);
});

test('re-ingesting the same cycle is one set of witnesses, not two', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  const cycle = readCycle(dir).cycle;
  const first = landLesson(fed, cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  const second = landLesson(fed, cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  assert.equal(first.landed.length, second.landed.length);
  assert.equal(second.landed.every((l) => l.action === 'already-witnessed'), true);
  assert.equal(fed.live().every((f) => f.distinct === 1), true, 'a repeated lesson does not manufacture observations');
  assert.equal(fed.events.filter((e) => e.kind === 'lesson-landed').length, 2, 'but both ingestions are on the record');
});

test('a lesson from an unregistered node is refused', () => {
  const dir = tmp(); buildCycle(dir);
  const fed = fedWith('twin-labs');
  // Witnessing as the subject, but the subject is not registered here.
  const res = landLesson(fed, readCycle(dir).cycle, { slug: 'nowhere', nodeId: 'nowhere' });
  assert.equal(res.landed.length, 0);
  assert.equal(res.refused[0].reason, 'unregistered-node');
});

test('a node cannot file a lesson about a DIFFERENT repository', () => {
  // The registry checks that a node exists; it cannot check that a node is
  // talking about ITSELF. Without this, twin-labs could file
  // risk_repair_bar(repo:fleets) from a cycle it ran on its own source, and
  // fleets would be told a bar was "found elsewhere" when it was found nowhere
  // near fleets. A false fact with a valid witness is the hardest kind to notice.
  const dir = tmp(); buildCycle(dir, { project: 'clearcut' });
  const fed = fedWith('twin-labs', 'fleets');
  const res = landLesson(fed, readCycle(dir).cycle, { slug: 'fleets', nodeId: 'twin-labs' });
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'witness-is-not-subject');
  assert.match(res.detail, /cannot file a lesson whose subject is 'repo:fleets'/);
  assert.match(res.detail, /onBehalfOf/);
  assert.equal(fed.live().length, 0, 'nothing landed');

  // And the escape hatch is explicit, recorded, and still requires the subject
  // to be registered.
  const proxied = landLesson(fed, readCycle(dir).cycle, { slug: 'fleets', nodeId: 'twin-labs', onBehalfOf: 'twin-labs' });
  assert.equal(proxied.ok, true);
  assert.equal(proxied.refused.length, 0, JSON.stringify(proxied.refused));
  const ev = fed.events.find((e) => e.kind === 'lesson-landed');
  assert.equal(ev.onBehalfOf, 'twin-labs', 'a lesson filed by proxy says so on the record');
  assert.equal(ev.slug, 'fleets');
});

test('a limit too long to carry intact refuses the lesson rather than being cut', () => {
  // Decision D6 — refuse, never strip — applied to a boundary. A limit cut to
  // fit reads as a weaker limit than the repair engine wrote, and quietly
  // softening the boundary is the exact failure this module exists to prevent.
  const dir = tmp();
  const long = 'this repair was verified only against the frozen probe set recorded in this ledger and establishes nothing whatsoever about any other defect class, any other repository, or any future version of this code';
  buildCycle(dir, { project: 'clearcut', limits: [long] });
  const res = ingestCycle(fedWith('clearcut'), dir, { nodeId: 'clearcut' });
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'limit-too-long');
  assert.match(res.detail, /will not be truncated/);
  assert.match(res.detail, /weaker one/);
  assert.ok(res.detail.includes(String(long.length)), 'names the length it was given');
});

test('a forged summary.json is caught by the chain, not believed', () => {
  // summary.json sits BESIDE the ledger and no hash covers it. Everything that
  // travels is derived from inside the chain, and the summary is read only to be
  // checked against it.
  const dir = tmp();
  buildCycle(dir, { project: 'clearcut' });
  const summaryPath = path.join(dir, 'summary.json');
  const summary = JSON.parse(fs.readFileSync(summaryPath, 'utf8'));
  fs.writeFileSync(summaryPath, canonicalJson({ ...summary, passedGates: 99, changedPaths: ['src/never/touched.js'] }) + '\n');

  const res = readCycle(dir);
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'summary-disagrees');
  assert.match(res.detail, /not covered by the ledger's hash chain/);
  assert.match(res.detail, /passedGates: summary says 99, the ledger holds 3/);
  assert.match(res.detail, /src\/never\/touched\.js/, 'names the disagreement, not just the counts');

  // And the numbers that DO land come from the events, not the file.
  const dir2 = tmp();
  buildCycle(dir2, { project: 'clearcut' });
  const c = readCycle(dir2).cycle;
  assert.equal(c.gatesPassed, 3, 'counted from gate evaluations against the candidate');
  assert.deepEqual(c.changedPaths, ['src/federation/store.js', 'src/forge/runner.js'], 'from the candidate event');
  assert.equal(c.project, 'clearcut', 'from the lesson artifact, not the summary');
});

test('a witness reference never points at a blob nobody hashed', () => {
  const dir = tmp(); buildCycle(dir);
  const cycle = readCycle(dir).cycle;
  assert.ok(cycle.patchId, 'the patch blob id comes from the candidate event');
  const fed = fedWith('clearcut');
  landLesson(fed, cycle, { slug: 'clearcut', nodeId: 'clearcut' });
  for (const f of fed.live()) {
    for (const w of f.witnesses) {
      assert.ok(!/blob:$/.test(w.reference), `dangling pointer on ${f.equation.predicate}: ${w.reference}`);
      const m = /blob:([a-f0-9]{64})/.exec(w.reference);
      if (m) assert.ok(fs.existsSync(path.join(dir, 'ledger', 'blobs', m[1])), 'the blob it names exists');
    }
  }
});

test('ingestCycle reads and lands in one move, taking the slug from the project', () => {
  const dir = tmp(); buildCycle(dir, { project: 'clearcut' });
  const fed = fedWith('clearcut', 'fleets');
  const res = ingestCycle(fed, dir, { nodeId: 'clearcut' });
  assert.equal(res.ok, true);
  assert.equal(res.slug, 'clearcut');
  assert.ok(fed.live({ realm: 'repo:clearcut' }).length >= 3);
});

test('a tampered cycle lands NOTHING', () => {
  const dir = tmp(); buildCycle(dir);
  const logPath = path.join(dir, 'ledger', 'events.jsonl');
  const lines = fs.readFileSync(logPath, 'utf8').trimEnd().split('\n');
  const ev = JSON.parse(lines[lines.length - 2]);
  ev.data.status = 'released';
  lines[lines.length - 2] = JSON.stringify(ev);
  fs.writeFileSync(logPath, lines.join('\n') + '\n');

  const fed = fedWith('twin-labs');
  const res = ingestCycle(fed, dir, { nodeId: 'twin-labs' });
  assert.equal(res.rejected, true);
  assert.equal(res.reason, 'id-mismatch');
  assert.equal(fed.live().length, 0, 'no facts, and no event: nothing about this cycle is memory');
  assert.equal(fed.events.length, 0);
});

test('the equations are stable: same cycle, same signatures', () => {
  const dir = tmp(); buildCycle(dir);
  const cycle = readCycle(dir).cycle;
  const a = lessonEquations(cycle, { slug: 'twin-labs' });
  const b = lessonEquations(cycle, { slug: 'twin-labs' });
  assert.deepEqual(a.commons.map((r) => r.equation), b.commons.map((r) => r.equation));
  assert.deepEqual(a.scoped.map((r) => r.equation), b.scoped.map((r) => r.equation));
  // And a different slug is a different subject, so two repos' lessons never merge.
  const c = lessonEquations(cycle, { slug: 'clearcut' });
  assert.notEqual(a.commons[0].equation.subject, c.commons[0].equation.subject);
});

test('a malformed timestamp in somebody else\'s ledger is reported, never a crash', () => {
  // The cycle's timestamp comes from an external ledger, and
  // `new Date(x).toISOString()` THROWS on a value it cannot parse. A bad
  // timestamp in an otherwise sound cycle must not take down the write path —
  // this repository's standard is that a bad record is REPORTED, never a crash.
  // Built with the bad value from the start, so the chain, ids and lineage are
  // all genuine and the timestamp is the only thing wrong.
  const dir = tmp();
  buildCycle(dir, { timestamp: 'not-a-date' });

  const read = readCycle(dir);
  assert.equal(read.ok, true, 'the cycle still verifies — only the timestamp is unusable');
  assert.equal(read.cycle.completedAt, null, 'reported as null...');
  assert.equal(read.cycle.completedAtRaw, 'not-a-date', '...with the raw value kept, not hidden');

  const fed = fedWith('twin-labs');
  const res = landLesson(fed, read.cycle, { slug: 'twin-labs', nodeId: 'twin-labs' });
  assert.equal(res.ok, true, 'and it still lands, stamped with the landing time');
  assert.equal(res.refused.length, 0, JSON.stringify(res.refused));
  assert.ok(fed.live().length > 0);
  assert.ok(!Number.isNaN(new Date(fed.live()[0].landedAt).getTime()), 'the fact carries a real timestamp');
});

test('safeIso refuses what it cannot use, and keeps what it can', () => {
  const { safeIso } = require('../src/forge/lessons.js');
  assert.equal(safeIso('2026-10-17T12:00:00.000Z'), '2026-10-17T12:00:00.000Z');
  assert.equal(safeIso('not-a-date'), null);
  assert.equal(safeIso(''), null);
  assert.equal(safeIso(null), null);
  assert.equal(safeIso(undefined), null);
  // The shape a hand-built ledger produces past ten events: a two-digit second
  // field written as three digits. Not a valid ISO-8601 timestamp, and V8 does
  // not rescue it — so it is refused rather than silently reinterpreted.
  assert.equal(safeIso('2026-10-17T12:00:010.000Z'), null);
  assert.equal(safeIso({}), null, 'a non-string is refused, not coerced');
  assert.equal(safeIso(0), '1970-01-01T00:00:00.000Z', 'an epoch is a real time');
});

test('the boundary rides into another repository\'s PASSPORT.md beside the method', () => {
  // `elsewhere` is the section an agent actually reads. A method surfaced there
  // with no scope line on it reads as a rule, which is what a lesson refuses to
  // be — so the hub attaches `claim_scope` by subject.
  const { down } = require('../src/federation/hub.js');
  const { RepoPassport } = require('../src/passport/passport.js');

  const dir = tmp();
  buildCycle(dir, { project: 'clearcut' });
  const fedDir = tmp();
  const nodes = new NodeRegistry(fedDir, { gitRemote: () => null }).load();
  nodes.register({ remote: 'https://github.com/me/clearcut', localPath: '/tmp/clearcut' });
  const other = nodes.register({ remote: 'https://github.com/me/fleets', localPath: null });
  const fed = new Federation(fedDir, { nodes }).load();
  assert.equal(landLesson(fed, readCycle(dir).cycle, { slug: 'clearcut', nodeId: 'clearcut' }).refused.length, 0);

  // A second repository, which has never run a cycle, opens its passport.
  const repoDir = tmp();
  const passport = new RepoPassport(repoDir, { slug: 'fleets', remote: 'https://github.com/me/fleets' });
  passport.init({ languages: ['TypeScript'], testCommand: 'npm test' });
  passport.load();
  passport.realm = other.node ? other.node.realm : 'repo:fleets';

  const res = down(fed, passport, { realm: passport.realm, viewer: 'fleets' });
  const bar = res.elsewhere.find((e) => e.predicate === 'risk_repair_bar');
  assert.ok(bar, 'the method reaches a repository that never ran a cycle');
  assert.deepEqual(bar.seenIn, ['repo:clearcut']);
  assert.deepEqual(bar.scope, [LESSON_SCOPE], 'and its boundary arrives with it');

  const doc = fs.readFileSync(res.docPath, 'utf8');
  assert.match(doc, /Found elsewhere in the system/);
  assert.match(doc, /risk_repair_bar/);
  assert.match(doc, /exact-parent-edits-only/);
  assert.match(doc, new RegExp(`scope: ${LESSON_SCOPE}`), 'rendered in the document, not just in the object');
  assert.match(doc, /what this does NOT claim/);

  // And the defect specifics did NOT follow it there.
  assert.ok(!doc.includes('src/session/auth.js'), 'repo A\'s changed paths are repo A\'s business');
  assert.ok(!res.elsewhere.some((e) => e.predicate === 'repaired_paths'));
});

test('readBlob checks the address on the way in', () => {
  const dir = tmp(); const built = buildCycle(dir);
  const good = readBlob(built.ledgerDir, built.summary.baselineId, 'the baseline');
  assert.equal(good.ok, true);
  assert.ok(good.value.files);
  assert.equal(readBlob(built.ledgerDir, 'nothex').reason, 'bad-address');
  assert.equal(readBlob(built.ledgerDir, 'a'.repeat(64)).reason, 'missing-file');
});
