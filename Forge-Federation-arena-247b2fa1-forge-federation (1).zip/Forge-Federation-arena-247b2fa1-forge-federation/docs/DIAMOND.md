# DIAMOND — the standard

**Definition (yours):** diamond code is **unbreakable by hack, by natural
diffusion, or by intended diffusion.**

That is a better standard than "high quality" because all three halves of it
are already named in this codebase. It is not a new idea bolted on — it is the
thing the existing rules were always for, finally said in one sentence.

---

## The three diffusions

| Diffusion | What it is | The question it asks |
|---|---|---|
| **HACK** | Adversarial. Somebody trying to make the code do what it must not. | Can I be made to do the wrong thing? |
| **ROT** *(natural diffusion)* | Time. Dependencies drift, a site redesigns, a format changes, a fact expires. Nobody attacked you. | Can I silently become wrong? |
| **TAMPER** *(intended diffusion)* | Somebody editing the record on purpose — history, a log, a signature. | Can my past be rewritten without a trace? |

The three need **different defenses**, and confusing them is how you get code
that is hard to hack and quietly rots, or immutable and trivially tricked.

---

## Four postures, one per attack

For every attack in scope, a system is in exactly one of these. They are
ordered — each is strictly better than the one below.

| | Posture | Meaning |
|---|---|---|
| **P** | **Prevent** | The attack cannot succeed. Best possible. |
| **D** | **Detect** | It succeeds, but it is recorded and visible. |
| **R** | **Recover** | It succeeds, but you can restore the prior state. |
| **X** | **Exposed** | None of the above. It succeeds and nothing says so. |

**Diamond = no `X` anywhere in scope, and a `P` on every axis where
prevention is actually possible.**

### Why "detect" is not a consolation prize

The most important line already in this codebase is in `store.js`:

> a broken chain is REPORTED, never a crash, so tampering is visible rather
> than fatal

You cannot always prevent a break. A determined attacker with the disk, or
simply five years of drift, will get in. **You can always make it visible.**
An unreadable failure is the real defect; a visible one is an incident. So on
the TAMPER axis, `D` + `R` is the honest ceiling — and it is enough.

On HACK, `P` is usually achievable, because an attack that was refused never
happened. On ROT, `P` is mostly not achievable — time wins — so `D` + `R` is
the target and the discipline is **cadence**: how fast you find out.

---

## What each axis already has in this codebase

These are not proposals. Each row is shipped and tested.

### HACK — prevent

| Defense | Where | What it refuses |
|---|---|---|
| The write boundary | `src/passport/writeBoundary.js` | a model stampeding its own adjudication |
| The trust gate | `src/passport/trustGate.js` | unadjudicated memory reaching a context |
| The capability gate | `src/forge/tools.js` `RISK_RANK` | a tool above its authorization, or a path outside the worktree |
| Server-side gate, not client flags | D5, `src/main/main.js` | a compromised renderer — it may ask, never authorize |
| Fail closed with no operator | `src/main/operator.js` | an anonymous approval, which is the machine approving itself |
| Refuse, never strip | D6 | a privileged field: rejected whole, not quietly cleaned |

### ROT — detect, then recover

| Defense | Where | What it catches |
|---|---|---|
| Two shelves, two clocks | D23, `src/federation/store.js` | an operational fact that expired when the target moved |
| The staleness queue asks for a **recheck** | `Federation.stale()` | drift. It never deletes — it asks |
| Re-anchoring | `src/detector/reanchor.js` | a redesign that moved the composer |
| The build is the referee | `src/forge/referee.js` | a patch that broke what was passing |
| Regression reverts the tree | `src/forge/forge.js` | the loop's own bad move, undone |

### TAMPER — detect, then recover

| Defense | Where | What it makes visible |
|---|---|---|
| Hash-chained, append-only | 7 stores | any edit to any record, or to the pointer before it |
| No delete method at all | the store API | erasure. The absence is the design |
| Supersede, never overwrite | `contradict()` | a change leaves the old record, marked, pointing forward |
| `verify()` reports, never throws | every chain | tampering as a finding, not a crash |
| Git-as-proposal | `src/forge/git.js` | the human releases; the loop only ever stages |

---

## The honest ceiling

Nobody hands you unbreakable. What you can actually build is:

1. **Prevent** everything that can be refused at a boundary.
2. **Detect** everything else, automatically, at a known cadence.
3. **Recover** to a state you can prove is prior.
4. **Never** let any of the three happen silently.

That is the whole standard. It is also, notably, the only version of
"unbreakable" that survives contact with a real attacker — because the one
thing that makes code break permanently is a break nobody saw.
