# CARRIERS — two populations, one codebase

**One sentence:** the repair carrier and the browser carrier are separated in a
fact's *signature*, so they cannot contaminate each other by accident, and they
cross only through one door that leaves a receipt on both sides.

---

## Why this exists

Two Federations descend from the same store. They share `SCHEMA`, `GENESIS`,
`chainHash`, and — the part that mattered — `equationSignature`.

| | repair carrier | browser carrier |
|---|---|---|
| a node is | a **repository** | a **cockpit** (a Forge Flight) |
| a fact is about | source: tests, contracts, risk classes, repairs | websites: composers, selectors, rate limits |
| the reader is | an agent about to **patch a file** | a **chat composer** on somebody else's domain |
| the target churns | per commit | per redesign |
| the volume is | low, bounded, auditable | high, unbounded, personal |
| a wrong fact costs | a bad repair, from a passport an agent trusted | a bad line in a prompt |

They were separated by *directory*. A directory is a convention, not a
boundary. Because the signature was `sha256(equation | realm | shelf)`, the same
equation observed on both sides produced the **same key**:

```
composer(claude.ai) = textarea#prompt    browser   -> f8cf989cc8c127f5…
composer(claude.ai) = textarea#prompt    repair    -> f8cf989cc8c127f5…   <- same
```

`land()` finds the existing record and adds a witness. No error, no finding, no
log line. Two populations that must never vote together start voting together,
and five mixed witnesses promotes the result to `established` — the one status
an agent trusts enough to act on.

It was reachable from both ends. The hub's `briefing()` returned every fact in
the commons, so one browser observation reached every repository's
`PASSPORT.md`. And Forge Flight's boot block does not call `briefing()` at all —
`bridge.js` → `bootPayload()` reads `federation.all()`, **every fact in the
store**, and renders it into the session prompt. So repair intelligence had a
direct path into a third-party chat box.

Neither direction was malicious. Both were silent.

---

## The fix: carrier is the outermost axis

A fact's key is now `carrier | realm | shelf | equation`, broadest scope first.
The carrier sits *outside* the realm for the same reason the realm already sat
outside the shelf: it is the broader scope, and two populations must never pool
witnesses no matter how alike their equations look.

```
composer(claude.ai) = textarea#prompt    repair    -> 88229fd9974b7e95…
composer(claude.ai) = textarea#prompt    browser   -> 78db52ba564363e6…
```

Verified in **one file**, holding both carriers, same equation: two facts, two
signatures, no merge. The separation is in the identity, so it survives being
pointed at the wrong directory — which is the whole point, because a convention
is one typo from failing and this fails silently.

**The vocabulary is closed: `repair`, `browser`. No third.** An unrecognised
carrier is refused by name. A third population is a decision with a migration
attached, not a string somebody typed.

**The default is `repair`,** because this repository *is* the repair federation.
Its nodes are repositories and its readers are repair agents, so its history is
repair history. Adopting an existing chain anywhere else would misfile every
fact ever landed here.

---

## Where the carrier is enforced

Not just in the key. A partition that only gates identity leaks through every
read that forgot to ask.

| | | |
|---|---|---|
| `land` | carrier is part of the signature; stored on the fact | an unknown carrier is refused |
| `briefing` | **one carrier**, defaulting to `repair`; refuses an unknown one | reports `otherCarriers` by name and count |
| `live` / `all` | filterable, unfiltered by default | the store's own view is not the reader's view |
| `findByPredicate` | carrier-scoped | so contradiction cannot reach across |
| `contradict` | fires **within** a carrier only | a redesign cannot close a repair fact |
| `stale` | defaults to one carrier | a recheck is work; a repo cannot re-observe a website |
| `divergences` | one carrier | two populations describing two targets is noise, not a finding |
| `stats` | `byCarrier`, `arrivedWitnesses`, `carrierMigrated` | the split is visible, not assumed |

`briefing` refusing an unknown carrier while `stale` accepts `null` for "all" is
deliberate: a **hand-off must never silently widen**, while an analytic read has
a legitimate reason to see everything.

The exclusion is reported, never hidden — a briefing that quietly omits a
population is a briefing nobody can audit. Same rule as the boot block's
exclusion audit, which is half the product there.

---

## Crossing: a door, not a shared room

Separation that means "never speaks" is the wrong product. Forge Flight flying
to GitHub to relay a repair is a real workflow, and what those seats establish
belongs on the repair side — **and stays on the browser side too**, because it is
genuinely both.

So facts cross, through `src/federation/bridge.js`, and crossing means a
**second record** in the destination carrier carrying provenance back to the
first. Not one merged record with a pooled witness list.

### The invariant: an arrived fact informs and never votes

```
five browser seats establish a fact   -> status: established   (among browsers)
cross it five times into repair       -> distinct: 5, observed: 0
                                      -> status: provisional   (arrived ones do not count)
five repositories observe it locally  -> status: established   (on five OBSERVATIONS)
```

Promotion counts `observed`, not `distinct`. Both are on the record and both are
shown, so a reader can see corroboration and measurement side by side and never
mistake one for the other. `portable()` applies the same rule to replication:
an arrived witness was measured somewhere else, so it does not count toward
"N distinct nodes measured this". A re-derivable provenance or a named ruling
still travels, because those are checkable regardless of origin.

### The two directions are not symmetric

They carry different risks, so they get different bars. Treating them alike
would either make the relay unusable or make the leak easy.

**`browser -> repair` may be mechanical.** No signature needed. This is the
relay: seats worked a repository and what they established should inform the
repair side without a human signing every equation. It lands witnessed
`structural`, because the provenance is re-derivable by anybody holding both
logs. And it never votes.

**`repair -> browser` requires a named human.** This direction puts repair
intelligence onto a surface whose whole job is typing into somebody else's chat
composer. That is an export, exports are the human's call, and "the human is the
gate" is not a slogan that gets relaxed because the transfer was convenient.
Fail closed: no name, no crossing, and the refusal says why.

### The refusals

| | |
|---|---|
| `not-portable` | a fact that has not earned the right to travel *within* its own carrier does not earn it by crossing. Reuses `portable()` rather than inventing a looser rule for the door. |
| `closed` | a fact closed by contradiction does not arrive alive. |
| `superseded` | the target moved; the live replacement is the fact worth crossing. |
| `same-carrier` | a fact cannot arrive from where it already is — that is a no-op which would launder a local observation into an arrived one. |
| `unsigned-export` | `repair -> browser` with no `actor`. |
| `unwitnessed` | no witness carries an evidence pointer. |

Plus two at the write boundary: a partial `origin` is refused (a provenance that
looks checkable and is not is worse than none), and an arrived fact may not carry
an `outcome` witness — `outcome` means "I acted and it worked", and the
destination node did not act.

### Naming a dead fact gets you an answer

A caller who names signatures is searching **all** facts, closed and superseded
included, so it is *told* "that one is closed". Searching only the live set would
return "nothing selected" — indistinguishable from a typo — and the caller would
never learn the truth. A refusal has to be reachable to be a refusal. A caller
who supplies a *filter* is asking about present state, so that runs over the live
set.

### The receipt

Every crossing logs `transfer-out` on the source and `transfer-in` on the
destination, with the count, the refusals, the signatures, the actor, whether it
was mechanical, and the reason. A transfer only one side knows about is a
transfer the other side cannot audit, and the source is where the fact was
earned.

The witness reference **excludes the chain head** on purpose. Including it would
make every transfer after a new source write look like a fresh witness, and
repeated transfers would mint distinct witnesses — the exact vote-minting the
`already-witnessed` path exists to stop. The head lives in `origin`, where it
dates the reading without changing the identity of the observation. Transferring
the same fact twice is one witness.

### The receipt made the store need a write lock

Logging `transfer-out` on the source means the bridge appends to a store it does
not own — one another process may well have open. That exposed a pre-existing
hole: `appendFileSync` with `O_APPEND` will not interleave the *bytes* of one
write, but each process computed `prev` from the head it remembered at load, so
two concurrent appenders produced **23 chain breaks over 120 lines**. Every line
intact, nothing lost, and the file reads as tampered — which is what made it easy
to miss.

`append()` now takes an exclusive lock and **re-reads the true head from disk**
inside it. The re-read is the fix; a lock around a stale head only makes the
corruption orderly. Two adjacent holes were closed with it: a torn tail is refused
rather than appended onto (which would glue a record to a fragment and destroy
both), and a stale lock is **reported and never broken**, because deleting another
writer's lock is how two writers end up running at once. A lock that cannot be
acquired throws rather than falling back — a write that cannot be serialised must
not be mis-chained instead.

See `test/write-lock.test.js` and `docs/RED-QUEEN.md`.

---

## What the provenance is worth, honestly

`origin` names the source carrier, the fact id, its signature *in that store*,
and the chain head it was read from. Given **both** logs, all of it is checkable
and none of it has to be trusted. Given only the destination log, it is a claim
about a file you do not hold.

That is the same ceiling the rest of the system accepts — a hash identifies, it
does not attest — and it is stated here rather than left to be discovered.

---

## Migration: nothing already on disk is lost

The standard is the one D26 set for the rename: a reshape that only changed
strings would have started every existing carrier from nothing, with its whole
history sitting one key over and invisible.

Records are adopted on load by `apply()`, each axis independently, because they
went in at different times and a record can be missing one and not the other:

| record | adopted into | |
|---|---|---|
| v1 — no realm, no carrier | `shared` + `repair` | re-keyed, `migrated++` |
| v2 — realm, no carrier | keeps its realm, `repair` | re-keyed, `carrierMigrated++` |
| v3 — both | nothing to do | no-op |

The re-key is free: old lines carry their own `signature` and were hashed with
it inside them, so the chain does not care what the key becomes. `verify()` still
passes on a migrated log, and a fact landed years ago **merges** with a new one
about the same thing instead of sitting beside it as a duplicate. The
per-record `schema` label is never rewritten — an `omnibox.collective.v1` line
still says so.

The pre-carrier call shape `federationSignature(eq, realm, shelf, sig)` is
detected and **throws**, naming the change. Silently computing a different key is
the exact defect this function exists to prevent.

---

## Using it

```bash
fed land --carrier repair --shelf operational --realm shared \
         --subject repo:twin-labs --predicate test --object "npm test" \
         --witness structural --node twin-labs --ref sha256:aaa --target repo:twin-labs

fed brief --realm shared                     # the repair carrier (the default)
fed brief --realm shared --carrier browser   # the other one, asked for by name

fed bridge --from browser --to repair \
           --source ~/.config/forgeflight/federation --dest ~/.forge-federation \
           --node twin-labs --sig <signature> --reason "relay run 1"

fed bridge --from repair --to browser --actor dwayne --sig <signature>   # signed export
fed stats                                    # byCarrier, arrivedWitnesses
```

`--source` and `--dest` both default to this store's directory, which is
legitimate: a carrier is a field on the fact, not a file, so one store *may* hold
both populations and still keep them apart on every read. Naming two directories
is how you bridge the real topology.

---

## What is still open

- **`local-cockpit` is a hardcoded nodeId** in Forge Flight's bridge. At fleet
  scale every install on earth is the same node, so distinct-witness arithmetic
  becomes meaningless and one user's browser witnesses on behalf of all. It is a
  *browser*-side defect and it is already named in `docs/AUDIT-omnibox.md`; it is
  not fixed here. **This is the first thing that breaks when Forge Flight ships.**
- **`omnibox/` still runs the 454-line pre-realm store** with no carrier axis.
  It needs no change to be bridged — the door declares the population for a
  carrierless export — but it cannot itself enforce separation, so its reads
  (`all()`) remain unpartitioned. That is fine while it is a separate file and a
  problem the moment it is not.
- **The lock is advisory and single-host.** It binds processes that use this
  store. Anything writing `federation.jsonl` by other means ignores it, and there
  is no cross-host story at all. Tested with two writers, not twenty.
- **Volume.** `load()` reads the whole log into memory and replays every line;
  `facts` and `events` are held forever. Repair volume never notices. Browser
  volume will, and the two carriers now have separate files, so only the browser
  one needs compaction or sharding. Deliberately not solved here.
- **Twin Labs lessons do not cross yet.** The door is built and tested; nothing
  calls it from a repair cycle. That is the next seam.

---

## Tests

`test/carrier.test.js` (20) — the closed vocabulary; the collision is gone; the
old call shape throws; the write boundary refuses; contradiction, staleness and
divergence do not cross; a briefing shows one carrier and reports the other;
v1 and v2 records adopt and **merge**; provenance is complete or refused.

`test/bridge.test.js` (20) — mechanical crossing; provenance points back and the
source is untouched; **arrived facts never vote**; local witnesses still
establish; a non-portable fact does not cross; closed and superseded do not
arrive alive; `repair -> browser` refuses unsigned and lands signed; idempotence;
the head cannot mint a witness; both sides log; the chain survives reload;
"move everything" is not a default; a carrierless export takes the declared
carrier.

87 checks in this pair (125 across the suite), `npm test`, all passing. Diamond
audit of `src/`: HACK **P** 5/5, named refusals 27 → 84, no new gaps.
