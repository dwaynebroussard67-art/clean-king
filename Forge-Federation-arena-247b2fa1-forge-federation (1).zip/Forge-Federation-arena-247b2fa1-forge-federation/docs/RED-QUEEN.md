# RED QUEEN — attacking the carrier separation and the repair memory

**Run it:** `npm run redqueen`

This is not a test suite. It is a Hornet pointed at work that was just finished.
Every attack is a real attempt to make the system assert something false, and
each one reports **LANDED**, **BLOCKED**, or **UNPROVEN** with the evidence.

The standard being attacked is the one `docs/DIAMOND.md` sets: no `X` anywhere in
scope. A landed attack is an exposure.

---

## Why UNPROVEN is its own verdict

The first run of this harness reported **0 of 16 landed** — and it was lying.
Five attacks had "blocked" by throwing `ReferenceError: opts is not defined` in
the code under attack, and the harness counted a thrown exception as a defense.

A crash is not a defense. Counting one as a block is how a harness reports a
green it did not earn, and it is the same thing `DIAMOND.md` calls the real
defect: *"an unreadable failure is the real defect; a visible one is an
incident."* So a throw is now its own verdict, it prints **UNPROVEN**, and it
fails the run exactly like a landed attack does. "It did not work" and "we could
not tell" are different claims and only one of them is safe to ship.

Attack A8 earned that distinction the hard way — see below.

---

## Result

```
RED QUEEN VERDICT — 0 LANDED, 0 UNPROVEN, 16 blocked
```

Five attacks landed on the first run. All five were fixed, and each fix has a
regression test in the normal suite so it cannot quietly come back.

| | | | |
|---|---|---|---|
| **A5** | read a migrated legacy fact whose counters were never written | `observed=undefined, arrived=undefined` — rendered as *"undefined/1 observed"* in every briefing | `apply()` backfills both counters from the witnesses when adopting a pre-v3 record |
| **M1** | lie about the bar in `summary.json`, which no hash covers | the commons asserted **`99-gates-passed`** for a cycle that ran three — and that claim travels into every other repository's passport as guidance | everything that travels is derived from inside the chain; the summary is read only to be **checked**, and a disagreement refuses the cycle |
| **M2** | file a lesson about a different repository than the one witnessing | `twin-labs` filed `risk_repair_bar(repo:fleets)`; fleets was then told a bar was "found elsewhere" when it was found nowhere near fleets | the witness and the subject must be the same repository, with an explicit recorded `onBehalfOf` for a hub ingesting by proxy |
| **M3** | soften a boundary by making a limit longer than one field | the limit was cut to 119 of 256 characters, ending *"…hes nothing whatsoever a"* | a limit is **never** truncated; one that does not fit refuses the whole lesson |
| **M5** | land a lesson with a dangling blob pointer as its witness | reference ended `blob:` — a `structural` witness that could not be re-derived | references name only blob ids that are inside the chain |
| **A8** | two writers appending to one store at once | **23 chain breaks** over 120 lines | an exclusive write lock, and the head is **re-read from disk** under it |

M1 is the serious one. `summary.json` and `receipt.json` sit *beside* the ledger
and nothing hashes them, so one writable plain file was enough to put a false
number into the commons — where the whole design says it will be handed to an
agent about to patch source in a *different* repository. The passport footer
already carried the rule this violated: *"The chain is the truth; this file is the
reading of it."* It now applies to somebody else's derived file too.

M3 is a violation of this repository's own decision D6 — **refuse, never strip** —
applied to a boundary. A limit cut to fit reads as a weaker limit than the repair
engine wrote, and quietly softening the boundary is the exact failure the module
claims to prevent.

---

## A8, and how a broken attack nearly hid a real one

A8 reported **BLOCKED** on the first run with *"chain intact, 0 links"*. Zero
links. Nothing had been written, so nothing had been tested, and the harness
printed it as a pass.

Two layers of wrong, both worth recording:

1. The attack spawned its writers with `spawnSync` one after the other, so it
   measured *sequential* writers and called that concurrency.
2. The writers ignored `land()`'s return value. `land()` **returns** refusals
   instead of throwing, and the payload used a 400-character object — over
   `MAX_FIELD` — so every one of the 120 appends was refused as
   `not-an-equation`. The writers printed success over zero writes.

Rewritten to background both writers in one shell and `wait`, and to **report its
refusals**, it landed immediately: 23 chain breaks.

The defect is real and was pre-existing. `appendFileSync` with `O_APPEND` will not
interleave the *bytes* of one write, but that was never the hazard. The hazard is
the **head**: two processes each hold `this.head` from when they loaded, so both
compute `prev` from the same stale value and both append. Every line is intact and
the chain is broken. Nothing is lost, which is what makes it easy to miss — the
file looks complete and reads as tampered.

The bridge made it newly reachable, because `transfer()` appends a `transfer-out`
event to a store it does not own: one another process may well have open.

**The fix is the re-read, not the lock.** A lock around a stale head only makes the
corruption orderly. `append()` now takes an exclusive lock and reads the true head
from disk inside it, then appends, then releases in a `finally`.

Two adjacent holes fell out of writing it:

- **A torn tail.** If the file does not end in a newline, appending would glue the
  new record onto the fragment and destroy both. Refused as `torn-tail` — the
  store never overwrites, so the only honest move is to stop and let an operator
  look.
- **A stale lock.** Deleting somebody else's lock to make progress is how two
  writers end up running at once, which is the exact failure the lock exists to
  prevent. So a stale lock is **reported and never broken**, naming the pid that
  holds it and telling the operator to remove it by hand.

A lock that cannot be acquired *throws* rather than falling back. A write that
cannot be serialised must not be mis-chained instead, and quietly appending anyway
is the one option that produces a log you cannot trust and cannot explain.

After the fix: 120 lines, 120 links, 0 breaks, reproducible across repeated runs.

---

## What was attacked and held

| | |
|---|---|
| **A1** | read a browser fact through a repair briefing — the briefing returned 0 facts and named the other carrier |
| **A2** | promote a repair fact using arrived witnesses only — `distinct=5, observed=0`, stayed `provisional` |
| **A3** | mint witnesses by re-transferring through rotating node ids — `distinct=12, observed=0`; none of them can vote |
| **A4** | close a repair fact with a browser contradiction — the repair fact survived, `closedAt=null` |
| **A6** | strip an `origin` from an arrived witness so it can vote — 1 chain break reported; tampering is visible and the fact is refused, not trusted |
| **A7** | transfer a closed fact so it arrives alive — refused `closed` |
| **M4** | exhaust memory with a 64 MiB unreferenced blob — verified in ~110 ms |
| **M6** | get a defect specific into the commons — the commons holds only `claim_scope`, `promotion`, `repair_verified`, `risk_repair_bar`; fleets' briefing carries none of the specifics |
| **M7** | forge the promoted status into a release — refused `id-mismatch`; the status is inside the chain |
| **M8** | sneak a lesson onto the browser carrier — refused `carrier` |

---

## What this does NOT prove

Stated plainly, because the alternative is a certificate nobody earned.

- **16 attacks is not an adversary.** A real Hornet breeds; this is a fixed list
  written by the same person who wrote the defenses, which is the weakest possible
  position to attack from. The blind spots are correlated with the author's.
- **No timing or resource attack beyond M4.** M4 hashed one 64 MiB blob in about
  110 ms, which is fine — it is not evidence about a cycle holding a full source
  snapshot across many blobs, and `verifyLedger` still reads each blob whole
  rather than streaming.
- **The lock is advisory.** It binds processes that use this store. Anything
  writing `federation.jsonl` by other means ignores it entirely, and there is no
  cross-host story at all.
- **A8 was tested with two writers, not twenty.** The retry budget is 10 s at
  4 ms, which is unmeasured under real contention.
- **Twin Labs' own reader was never run against these cycles.** `ledger.js`
  reimplements the format from the published code and the two agree on every
  fixture here, but that is agreement on my fixtures, not a cross-check against
  theirs on theirs.
- **Nothing attacks the hub's judgment.** Every attack above is on integrity and
  separation. None asks whether `risk_repair_bar` is *good guidance*, which is a
  harder question and not one a Hornet can answer.

---

## Regression tests

The fixes live in the normal suite, not only in the harness:

- `test/write-lock.test.js` (9) — concurrent processes keep the chain intact;
  every line chains to the one *physically* before it; two handles on one file do
  not fork the chain; a torn tail refuses rather than glues; a stale lock is
  reported and never broken; a fresh lock is waited for by a real separate
  process; the lock is released in the `finally` even when the write fails.
- `test/lessons.test.js` — a node cannot file about another repository, and the
  proxy path records itself; a limit too long refuses the lesson; a forged
  `summary.json` is caught by the chain and the dispute names the difference; no
  witness reference points at a blob nobody hashed.
- `test/carrier.test.js` — pre-v3 records adopt and merge, with both counters
  backfilled.

125 checks, `npm test`, all passing. Diamond audit of `src/`: HACK **P** 5/5,
named refusals 84, ROT **D** 4/4. The one remaining exposure is the pre-existing
`no-erasure` heuristic on `gate.js`'s `delegation.json` and `passport.js`'s
`link.json` — derived current-state files, not chained records.
