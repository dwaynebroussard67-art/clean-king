# Forge Federation — the shape of it

**One sentence:** the passport is a neural link; the Federation is the hub; the
human is the gate.

---

## The topology

```
              ┌───────────────────────────────────────┐
              │        FORGE FEDERATION  (the hub)    │
              │                                       │
              │  federation.jsonl   the commons       │
              │  nodes.jsonl        passport registry │
              │  releases.jsonl     the human's queue │
              │  requests.jsonl     every ask, logged │
              │                                       │
              │  serves: context · ask · tool · skill │
              └───────────────────────────────────────┘
                 ▲  request            │  response
                 │                     ▼
     ┌───────────┴──────┐   ┌──────────┴───────┐   ┌──────────┴───────┐
     │ forge-passport/  │   │ forge-passport/  │   │ forge-passport/  │
     │   in repo: TWLD  │   │  in repo: striper │   │  in repo: Fleets │
     │                  │   │                  │   │                  │
     │ PASSPORT.md      │   │ PASSPORT.md      │   │ PASSPORT.md      │
     │ link.json        │   │ link.json        │   │ link.json        │
     │ profile.json     │   │ profile.json     │   │ profile.json     │
     │ memories.jsonl   │   │ memories.jsonl   │   │ memories.jsonl   │
     │ evidence.jsonl   │   │ evidence.jsonl   │   │ evidence.jsonl   │
     └──────────────────┘   └──────────────────┘   └──────────────────┘
```

**The Federation does not connect to repositories. It connects to passports.**
A repository is a moving thing; a passport is the contract it implements. The
repository can be renamed, rewritten, split or reorged and the link holds.

**No repository can see another repository.** Only the hub can. That is the
whole reason the hub exists: cross-repository learning is not possible without
one. N repos talking to each other is N² connections that cannot happen; N
passports through a hub is N connections that can.

---

## Two carriers, and why they are not one store

Everything above describes the **repair** carrier: nodes are repositories, facts
are about source, readers are agents about to patch a file. Forge Flight has a
second one — the **browser** carrier, where nodes are cockpits and facts are
about websites. They descend from the same code, and that made them one typo away
from merging: the same equation observed on both sides produced the same
signature, `land()` added a witness, and two populations that must never vote
together started voting together. Silently.

So the carrier is the outermost axis of a fact's identity —
`carrier | realm | shelf | equation` — and it is enforced on every read, not just
the key. Facts cross only through one door, as a **second record with
provenance**, and an arrived fact informs without voting. `repair -> browser`
needs a named human, because that direction exports onto a surface that types
into third-party chat.

**[`docs/CARRIERS.md`](CARRIERS.md)** — the collision, the fix, the door, the
migration.

---

## The passport is a link, not a store

An agent opening a repository finds `forge-passport/` and, with no network and
no hub, knows:

- **what this codebase is** — languages, framework, test command, entry points
- **what has been checked** — the evidence index, by category, every row
  pointing at something re-derivable
- **what has been learned here** — chained, witnessed memories
- **how to ask for more** — `link.json`, the protocol and the hub address

Everything else is a request away.

### Evidence is categorised, and the vocabulary is closed

`structure` · `contract` · `test` · `history` · `dependency` · `risk`

Closed, because an uncategorised fact is a fact nobody can find again, and an
open vocabulary is how an evidence index rots into a junk drawer.

---

## What the hub serves

| Kind | Answer |
|---|---|
| `context` | the briefing for a realm: what applies here, what was found elsewhere, where the system disagrees |
| `ask` | `established` / `impossible` / `unknown` — never "true", because the collective does not answer questions it cannot answer |
| `tool` | a capability, granted or deferred by its risk rank |
| `skill` | a maneuver that has earned the name: 5 successes, zero failures |
| `remember` | file a memory. **Self-reported outcomes are always deferred.** |
| `evidence` | file evidence. Structural, so it lands on its own. |

**Request, never command.** An agent asks; the hub authorizes. A confused or
hostile agent can at worst ask.

---

## The human is the gate

Nothing above `create` executes on request. It becomes a **ticket**, and the
ticket waits for a named human.

```
agent: git.commit
  hub:  deferred — needs-human-release — ticket tk_463baa209694
agent: release it, actor="the-agent"
  hub:  refused — no-operators-configured
  hub:  (operator configured, but not signed in)
  hub:  refused — not-signed-in — a name on disk is a memory, not a session
human: sign in as dwayne
human: release tk_463baa209694
  hub:  released, decidedBy=dwayne
```

Three things that are true and are tested:

- **Fail closed.** No operator configured → nothing releases.
- **Sign-in is per launch.** Configuring is not signing.
- **A supplied actor is ignored.** Identity comes from the session, never the
  caller. A renderer that claims to be somebody is still nobody.

### The delegation ladder

The usual dial is a boolean — trust everything or prompt for everything. Both
halves are wrong: a boolean delegates by *kind of action* and never learns, so
it is either tedious forever or dangerous immediately.

This ladder delegates by **track record**, on the same bar the system already
uses to decide what a skill is.

| | |
|---|---|
| `none` | nothing releases. For a system you have locked down. |
| `sealed` | every request needs a signature, reads included. For an agent you do not yet trust. |
| `ask` | every deferred request needs a signature. **The default.** |
| `earned` | a request **shape** approved 5 times with zero refusals releases itself |

**One refusal blocks that shape permanently.** Not "resets the counter" —
blocks. Otherwise delegation is a lock an agent can pick by asking enough
times.

---

## What is chained, and why

Every one of these is append-only, hash-chained, and re-verified on load. A
tampered log is a **finding to report**, never a crash — so tampering is
visible rather than fatal.

| File | Where | What it is |
|---|---|---|
| `federation.jsonl` | hub | the commons |
| `nodes.jsonl` | hub | which repositories exist |
| `releases.jsonl` | hub | the human's queue, including refusals |
| `requests.jsonl` | hub | every ask, granted or not |
| `memories.jsonl` | each repo | what that repository learned |
| `evidence.jsonl` | each repo | the categorised evidence index |

**Nothing is ever deleted.** Superseded, closed, refused — all recorded, all
still readable. The history is the entire reason any of it is trustworthy.

---

## The loop

```
1. ingest   the hub looks at every repository, categorises the evidence
2. up       evidence is structural, so it promotes itself into the commons
3. compute  the hub works out what applies where, and where members differ
4. down     every passport is rewritten with what the rest of the system knows
5. serve    an agent opens a repository, reads its passport, asks the hub
6. gate     anything that changes the world waits for a named human
7. repair   a cycle runs, its ledger is re-verified from scratch, and the lesson
            lands — the method in the commons, the defect in its own realm
```

Step 4 is the one that makes it a collective: a class of defect found in
Fleets is written into TWLD's passport **before it happens there**. No
repository could produce that line, because no repository can see the others.

Step 7 is what makes it a repair memory. A lesson is verified by re-deriving the
repair engine's own ledger from the published format — never by asking the engine
whether it passed — and it lands split: the **method and its boundary** travel to
the commons, the **defect specifics** stay in the repository they came from,
because repo A's probe failures are defined by repo A's probe contract.
**[`docs/REPAIR-MEMORY.md`](REPAIR-MEMORY.md)**
