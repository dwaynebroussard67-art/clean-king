# Diamond audit — Omnibox / Forge Flight (baseline)

Run: `node bin/diamond.js omnibox/src`

```
========================================================================
DIAMOND AUDIT — /home/user/Forge-Federation/omnibox/src
53 source files
========================================================================

HACK    [ X ]  3/5 defenses present
        EXPOSED: no-hardcoded-identity, no-eval-or-dynamic-exec
   P  refuse-by-name                 30 named refusals, 151 with a reason code
   P  fail-closed                    2 fail-closed statements, 24 empty-input denials
   X  no-hardcoded-identity          8 hardcoded identities
   P  authority-is-server-side       22 authority checks
   X  no-eval-or-dynamic-exec        3 dynamic execution sites

ROT     [ D ]  4/4 defenses present
   D  staleness-detected             32 staleness signals
   D  expiry-is-a-clock-not-a-failure 26 expiry-aware references
   R  regression-reverts             26 regression guards
   D  verification-is-executable     48 executable-verification hooks

TAMPER  [ X ]  4/5 defenses present
        EXPOSED: no-erasure
   D  chained-append-only            5 genesis anchors, 35 chain links, 6 append-only writes
   X  no-erasure                     record erasure paths found
   D  tamper-reported-not-fatal      23 verifiers, 7 explicit report-don't-crash contracts
   R  supersede-never-overwrite      6 supersede/close pointers
   D  verify-on-load                 3 stores re-verify as they hydrate

========================================================================
VERDICT: EXPOSED
========================================================================
  HACK    X  P/D/R present: P  — exposed: no-hardcoded-identity, no-eval-or-dynamic-exec
  ROT     D  P/D/R present: DR
  TAMPER  X  P/D/R present: DR  — exposed: no-erasure

GAPS, WITH EVIDENCE:

  [TAMPER] no-erasure — wanted P, found X
  why: A store that can delete can hide that something was ever there.
  record erasure paths found
     forge/store.js:60  if (jsonl) fs.writeFileSync(this.recorderPath, jsonl + '\n', 'utf8');
     forge/store.js:61  else fs.writeFileSync(this.recorderPath, '', 'utf8');
     forge/store.js:69  fs.writeFileSync(this.statePath, JSON.stringify(state, null, 2) + '\n', 'utf8');
     preload/seat.js:298  picker.box.remove();
     preload/seat.js:299  picker.hint.remove();

  [HACK] no-hardcoded-identity — wanted P, found X
  why: A hardcoded name trusted as "the human" is a standing backdoor. Identity must be configuration.
  8 hardcoded identities
     federation/bridge.js:73  nodeId: 'local-cockpit',
     main/main.js:1056  passport.boundary.adjudicate(id, { actor: 'human' });
     main/main.js:1060  passport.boundary.retire(id, { actor: 'human' });
     passport/writeBoundary.js:336  adjudicate(memoryId, { actor = 'human', at } = {}) {
     passport/writeBoundary.js:346  revokeAdjudication(memoryId, { actor = 'human', at } = {}) {
     passport/writeBoundary.js:363  pin(memoryId, pinned = true, { actor = 'human', at } = {}) {

  [HACK] no-eval-or-dynamic-exec — wanted P, found X
  why: Executing strings from content is the root of most adversarial input wins.
  3 dynamic execution sites
     renderer/chrome.js:1421  d.innerHTML = 'Four slots. Launch a pilot — it flies your active tab and starts clicking.';
     renderer/chrome.js:1455  d.innerHTML = 'No flights yet. Give a pilot a goal above.';
     renderer/chrome.js:1695  d.innerHTML = html;

```
