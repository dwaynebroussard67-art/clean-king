"use client";

import { useState, useRef } from "react";
import type { Passport } from "@/lib/types";
import { X, Upload, FileText, AlertCircle } from "lucide-react";

interface Props {
  onClose: () => void;
  onImported: (p: Passport) => void;
}

export function ImportModal({ onClose, onImported }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const [importing, setImporting] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (f: File) => {
    setFile(f);
    setError("");
    try {
      const text = await f.text();
      const data = JSON.parse(text);
      if (data.format !== "memory-passport-exchange") {
        setError("Invalid .mpx format — missing format identifier.");
        setPreview(null);
        return;
      }
      setPreview(
        `${data.passport?.identity?.name || "Unknown"} — ${data.memories?.length || 0} memories`
      );
    } catch {
      setError("Failed to parse file. Ensure it is valid JSON.");
      setPreview(null);
    }
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    setError("");

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const res = await fetch("/api/passports/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const err = await res.json();
        setError(err.error || "Import failed");
        setImporting(false);
        return;
      }

      const result = await res.json();
      onImported(result.passport);
    } catch {
      setError("Import failed. Please try again.");
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-md rounded-2xl bg-[#1a1f3a] border border-white/10 shadow-2xl animate-fade-in">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-green-500/10 flex items-center justify-center">
              <Upload className="h-5 w-5 text-green-400" />
            </div>
            <h2 className="text-lg font-bold text-white">
              Import Passport
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div
            onClick={() => inputRef.current?.click()}
            className="border-2 border-dashed border-white/10 hover:border-passport-500/40 rounded-xl p-8 text-center cursor-pointer transition group"
          >
            <input
              ref={inputRef}
              type="file"
              accept=".mpx,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
              }}
            />
            {file ? (
              <div className="flex items-center justify-center gap-3">
                <FileText className="h-8 w-8 text-passport-400" />
                <div className="text-left">
                  <p className="text-sm font-medium text-white">{file.name}</p>
                  <p className="text-xs text-slate-400">
                    {(file.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
            ) : (
              <>
                <Upload className="h-10 w-10 text-slate-500 mx-auto mb-3 group-hover:text-passport-400 transition" />
                <p className="text-sm text-slate-400">
                  Drop a <code className="text-passport-400">.mpx</code> or{" "}
                  <code className="text-passport-400">.json</code> file here
                </p>
                <p className="text-xs text-slate-500 mt-1">or click to browse</p>
              </>
            )}
          </div>

          {preview && (
            <div className="flex items-center gap-2 px-3 py-2 bg-green-500/10 border border-green-500/20 rounded-lg">
              <FileText className="h-4 w-4 text-green-400 shrink-0" />
              <p className="text-sm text-green-300">{preview}</p>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 px-3 py-2 bg-red-500/10 border border-red-500/20 rounded-lg">
              <AlertCircle className="h-4 w-4 text-red-400 shrink-0" />
              <p className="text-sm text-red-300">{error}</p>
            </div>
          )}

          <button
            onClick={handleImport}
            disabled={!file || !!error || importing}
            className="w-full py-3 bg-gradient-to-r from-passport-600 to-passport-500 hover:from-passport-500 hover:to-passport-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-passport-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {importing ? "Importing…" : "Import Passport"}
          </button>
        </div>
      </div>
    </div>
  );
}
