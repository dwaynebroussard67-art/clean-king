import type {
  HarnessClock,
  MissionEvent,
  MissionRecord,
  MissionStatus,
} from './contracts.ts';
import { TERMINAL_STATUSES } from './contracts.ts';

/**
 * The mission state graph is deliberately closed. A model may propose work,
 * but it cannot invent a lifecycle transition; only the harness can advance a
 * mission through this table.
 */
export const ALLOWED_TRANSITIONS: Readonly<Record<MissionStatus, readonly MissionStatus[]>> = {
  CREATED: ['NEURALINK_BOUND', 'CANCELLED'],
  NEURALINK_BOUND: ['CONTEXT_READY', 'FAILED', 'CANCELLED'],
  CONTEXT_READY: ['PLANNING', 'FAILED', 'CANCELLED'],
  PLANNING: ['WAITING_APPROVAL', 'RUNNING', 'FAILED', 'CANCELLED'],
  WAITING_APPROVAL: ['RUNNING', 'CANCELLED', 'FAILED'],
  RUNNING: ['WAITING_APPROVAL', 'WAITING_EXTERNAL', 'CONTEXT_UPDATED', 'EVALUATING', 'FAILED', 'CANCELLED'],
  WAITING_EXTERNAL: ['RUNNING', 'WAITING_APPROVAL', 'CONTEXT_UPDATED', 'FAILED', 'CANCELLED'],
  CONTEXT_UPDATED: ['RUNNING', 'PLANNING', 'EVALUATING', 'FAILED', 'CANCELLED'],
  EVALUATING: ['MEMORY_REVIEW', 'SUCCEEDED', 'FAILED', 'CANCELLED'],
  MEMORY_REVIEW: ['SUCCEEDED', 'FAILED', 'CANCELLED'],
  SUCCEEDED: [],
  FAILED: [],
  CANCELLED: [],
};

export class MissionStateError extends Error {
  readonly code = 'INVALID_MISSION_TRANSITION';
  readonly from: MissionStatus;
  readonly to: MissionStatus;

  constructor(from: MissionStatus, to: MissionStatus) {
    super(`invalid mission transition: ${from} -> ${to}`);
    this.name = 'MissionStateError';
    this.from = from;
    this.to = to;
  }
}

export function isTerminal(status: MissionStatus): status is (typeof TERMINAL_STATUSES)[number] {
  return TERMINAL_STATUSES.includes(status as (typeof TERMINAL_STATUSES)[number]);
}

export function canTransition(from: MissionStatus, to: MissionStatus): boolean {
  return ALLOWED_TRANSITIONS[from].includes(to);
}

export function assertTransition(from: MissionStatus, to: MissionStatus): void {
  if (!canTransition(from, to)) throw new MissionStateError(from, to);
}

export function createMissionRecord(
  input: Omit<MissionRecord, 'status' | 'revision' | 'createdAt' | 'updatedAt'>,
  clock: HarnessClock = () => new Date(),
): MissionRecord {
  const now = clock().toISOString();
  return {
    ...input,
    status: 'CREATED',
    revision: 0,
    createdAt: now,
    updatedAt: now,
  };
}

export function transitionMission(
  mission: MissionRecord,
  to: MissionStatus,
  actor: string,
  payload: Record<string, unknown> = {},
  clock: HarnessClock = () => new Date(),
): { mission: MissionRecord; event: MissionEvent } {
  assertTransition(mission.status, to);
  const now = clock().toISOString();
  const nextRevision = mission.revision + 1;
  const next: MissionRecord = {
    ...mission,
    status: to,
    revision: nextRevision,
    updatedAt: now,
    checkpoint: {
      status: to,
      step: payload.step ? String(payload.step) : to,
      state: { ...payload },
      revision: nextRevision,
      capturedAt: now,
    },
  };
  const event: MissionEvent = {
    id: `${mission.id}:event:${nextRevision}`,
    missionId: mission.id,
    sequence: nextRevision,
    type: to === 'SUCCEEDED' || to === 'FAILED' || to === 'CANCELLED'
      ? 'mission_completed'
      : 'status_changed',
    actor,
    payload: { from: mission.status, to, ...payload },
    createdAt: now,
  };
  return { mission: next, event };
}

export function assertResumable(mission: MissionRecord): void {
  if (isTerminal(mission.status)) {
    throw new Error(`terminal mission cannot resume: ${mission.status}`);
  }
  if (!mission.checkpoint) {
    throw new Error(`mission has no checkpoint: ${mission.id}`);
  }
  if (mission.checkpoint.revision !== mission.revision) {
    throw new Error(`checkpoint revision mismatch for mission: ${mission.id}`);
  }
}
