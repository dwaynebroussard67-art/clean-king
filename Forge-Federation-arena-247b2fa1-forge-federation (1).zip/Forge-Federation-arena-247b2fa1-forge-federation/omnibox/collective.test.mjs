/**
 * collective.test.mjs
 *
 * Baseline: does the gate do what it says.
 * Attacks: can a hostile or careless harness get a bad fact in.
 *
 * The attacks are the point. A gate that only passes the happy path is
 * a suggestion, not a gate.
 */

import assert from 'node:assert/strict'
import { admit, factId } from './gate.ts'
import { Collective } from './store.ts'

let passed = 0, failed = 0
const failures = []

function test(name, fn) {
  try { fn(); passed++ }
  catch (err) { failed++; failures.push({ name, message: err.message }) }
}

// ── Fixtures ──────────────────────────────────────────────────────────────

const witness = (over = {}) => ({
  kind: 'outcome',
  reference: 'req_01H8XK4M2P',
  harnessId: 'harness-alpha',
  observedAt: '2026-08-17T04:00:00.000Z',
  ...over,
})

const fact = (over = {}) => ({
  subject: 'endpoint:api.example.com/v1/charges',
  predicate: 'accepts_field',
  value: 'amount',
  witness: witness(),
  stability: 'contingent',
  ...over,
})

const fresh = () => new Collective()

// ── Baseline ──────────────────────────────────────────────────────────────

test('1. a well-formed witnessed fact is admitted', () => {
  const c = fresh()
  const v = admit(fact(), c)
  assert.equal(v.status, 'admitted')
  assert.equal(c.size(), 1)
})

test('2. same fact from a second harness corroborates, does not duplicate', () => {
  const c = fresh()
  admit(fact(), c)
  const v = admit(fact({ witness: witness({ harnessId: 'harness-beta', reference: 'req_ZZZ' }) }), c)
  assert.equal(v.status, 'corroborated')
  assert.equal(c.size(), 1, 'duplicate fact created a second record')
  assert.equal(v.fact.witnesses.length, 2)
})

test('3. identical fact ids across harnesses', () => {
  const a = factId('subj', 'accepts_field', 'x')
  const b = factId('subj', 'accepts_field', 'x')
  assert.equal(a, b)
})

test('4. established fact answers "established"', () => {
  const c = fresh()
  admit(fact(), c)
  const r = c.ask('endpoint:api.example.com/v1/charges', 'accepts_field', 'amount')
  assert.equal(r.answer, 'established')
})

test('5. contradicting a held fact answers "impossible" with receipts', () => {
  const c = fresh()
  admit(fact({ predicate: 'rejects_field', value: 'currency' }), c)
  const r = c.ask('endpoint:api.example.com/v1/charges', 'accepts_field', 'currency')
  assert.equal(r.answer, 'impossible')
  assert.equal(r.because.length, 1)
  assert.equal(r.because[0].predicate, 'rejects_field')
})

test('6. unknown is the honest default', () => {
  const c = fresh()
  const r = c.ask('endpoint:never.seen', 'accepts_field', 'anything')
  assert.equal(r.answer, 'unknown')
})

test('7. conflict is returned, not silently resolved', () => {
  const c = fresh()
  admit(fact({ predicate: 'accepts_field', value: 'currency' }), c)
  const v = admit(fact({ predicate: 'rejects_field', value: 'currency' }), c)
  assert.equal(v.status, 'conflict')
})

test('8. single-valued predicate: two different values conflict', () => {
  const c = fresh()
  admit(fact({ predicate: 'rate_limit_per_min', value: 60 }), c)
  const v = admit(fact({ predicate: 'rate_limit_per_min', value: 120 }), c)
  assert.equal(v.status, 'conflict')
})

test('9. min > max is caught as a conflict, not admitted', () => {
  const c = fresh()
  admit(fact({ predicate: 'field_max_length', value: 10 }), c)
  const v = admit(fact({ predicate: 'field_min_length', value: 50 }), c)
  assert.equal(v.status, 'conflict')
})

// ── Attacks ───────────────────────────────────────────────────────────────

test('A1. POISON: fact with no witness is refused', () => {
  const c = fresh()
  const v = admit(fact({ witness: undefined }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'UNWITNESSED')
})

test('A2. POISON: fabricated witness with empty reference is refused', () => {
  const c = fresh()
  const v = admit(fact({ witness: witness({ reference: '' }) }), c)
  assert.equal(v.status, 'refused', 'a witness pointing at nothing was accepted')
  assert.equal(v.reason, 'UNWITNESSED')
})

test('A3. POISON: human witness naming a role not a person is refused', () => {
  const c = fresh()
  const v = admit(fact({ witness: witness({ kind: 'human', reference: '12345' }) }), c)
  assert.equal(v.status, 'refused', '"the team" style witness got through')
})

test('A4. POISON: invented predicate is refused', () => {
  const c = fresh()
  const v = admit(fact({ predicate: 'is_probably_fine' }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'UNKNOWN_PREDICATE')
})

test('A5. POISON: 2+1=4 — self-inconsistent value is refused', () => {
  const c = fresh()
  const v = admit(fact({ predicate: 'rate_limit_per_min', value: -5 }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'SELF_INCONSISTENT')
})

test('A6. POISON: wrong value type is refused', () => {
  const c = fresh()
  const v = admit(fact({ predicate: 'rate_limit_per_min', value: 'lots' }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'TYPE_MISMATCH')
})

test('A7. POISON: impossible HTTP status is refused', () => {
  const c = fresh()
  const v = admit(fact({ predicate: 'returns_status', value: 999 }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'SELF_INCONSISTENT')
})

test('A8. CONSENSUS ATTACK: 50 harnesses agreeing cannot overturn a held fact', () => {
  const c = fresh()
  admit(fact({ predicate: 'rejects_field', value: 'currency' }), c)
  c.recordConflict(
    c.bySubject('endpoint:api.example.com/v1/charges')[0],
    fact({ predicate: 'accepts_field', value: 'currency' })
  )
  let admitted = 0
  for (let i = 0; i < 50; i++) {
    const v = admit(
      fact({
        predicate: 'accepts_field',
        value: 'currency',
        witness: witness({ harnessId: `harness-${i}`, reference: `req_${i}` }),
      }),
      c
    )
    if (v.status === 'admitted') admitted++
  }
  assert.equal(admitted, 0, `${admitted} of 50 agreeing harnesses got a fact into a quarantined subject`)
})

test('A9. QUARANTINE: a conflicted subject stops answering entirely', () => {
  const c = fresh()
  admit(fact({ predicate: 'rejects_field', value: 'currency' }), c)
  const inc = c.bySubject('endpoint:api.example.com/v1/charges')[0]
  c.recordConflict(inc, fact({ predicate: 'accepts_field', value: 'currency' }))
  const r = c.ask('endpoint:api.example.com/v1/charges', 'rejects_field', 'currency')
  assert.equal(r.answer, 'quarantined', 'a quarantined subject still answered as if sound')
})

test('A10. QUARANTINE: only a named human clears it', () => {
  const c = fresh()
  admit(fact({ predicate: 'rejects_field', value: 'currency' }), c)
  const inc = c.bySubject('endpoint:api.example.com/v1/charges')[0]
  c.recordConflict(inc, fact({ predicate: 'accepts_field', value: 'currency' }))
  assert.throws(
    () => c.resolveConflict('endpoint:api.example.com/v1/charges', 'incumbent', ''),
    /RESOLUTION_UNSIGNED/,
    'an unsigned resolution cleared a quarantine'
  )
  const out = c.resolveConflict('endpoint:api.example.com/v1/charges', 'incumbent', 'dwayne')
  assert.equal(out.resolved, 1)
  assert.equal(c.isQuarantined('endpoint:api.example.com/v1/charges'), false)
})

test('A11. no newer-wins: a later fact does not overwrite an earlier one', () => {
  const c = fresh()
  admit(fact({ predicate: 'rate_limit_per_min', value: 60 }), c)
  const v = admit(
    fact({
      predicate: 'rate_limit_per_min',
      value: 120,
      witness: witness({ observedAt: '2027-01-01T00:00:00.000Z' }),
    }),
    c
  )
  assert.equal(v.status, 'conflict', 'a newer timestamp silently won')
  const held = c.bySubject('endpoint:api.example.com/v1/charges')
  assert.equal(held.length, 1)
  assert.equal(held[0].value, 60, 'incumbent was overwritten')
})

test('A12. corroboration does not upgrade a fact, only records witnesses', () => {
  const c = fresh()
  admit(fact(), c)
  for (let i = 0; i < 20; i++) {
    admit(fact({ witness: witness({ harnessId: `h${i}`, reference: `req_00${i}` }) }), c)
  }
  const held = c.bySubject('endpoint:api.example.com/v1/charges')[0]
  assert.equal(held.witnesses.length, 21)
  assert.equal(c.size(), 1)
  assert.ok(!('confidence' in held), 'a confidence score appeared — votes are leaking in')
})

test('A13. same harness resubmitting does not inflate the witness count', () => {
  const c = fresh()
  admit(fact(), c)
  admit(fact(), c)
  admit(fact(), c)
  const held = c.bySubject('endpoint:api.example.com/v1/charges')[0]
  assert.equal(held.witnesses.length, 1, 'one harness counted as many by resubmitting')
})

test('A14. contingent facts can be listed as stale; invariant ones cannot', () => {
  const c = fresh()
  admit(fact({ stability: 'invariant', value: 'id' }), c)
  admit(fact({ stability: 'contingent', value: 'amount' }), c)
  const stale = c.staleContingent(-1)
  assert.equal(stale.length, 1)
  assert.equal(stale[0].stability, 'contingent')
})

test('A15. malformed subject is refused before anything else runs', () => {
  const c = fresh()
  const v = admit(fact({ subject: '   ' }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'MALFORMED')
})

console.log(`\ncollective: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
