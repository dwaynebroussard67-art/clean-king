package com.misfit.forgeflight.mobile;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

/**
 * A small, real Android browser shell for the Forge Flight clone.
 *
 * Each open page is a normal Android WebView with its own cookie jar and
 * navigation history. The seat agent is injected into the page after load and
 * uses structural signals, not provider selectors. Prompts fan out only to
 * tabs whose pages have a readable composer; a page that cannot be identified
 * is left alone and the status line says so.
 */
public final class MainActivity extends Activity {
    private static final int CANVAS = Color.rgb(8, 10, 13);
    private static final int PANEL = Color.rgb(16, 19, 25);
    private static final int PANEL_2 = Color.rgb(21, 26, 33);
    private static final int LINE = Color.rgb(35, 42, 52);
    private static final int INK = Color.rgb(243, 244, 246);
    private static final int MUTED = Color.rgb(138, 148, 164);
    private static final int FAINT = Color.rgb(83, 94, 110);
    private static final int ORANGE = Color.rgb(255, 91, 19);
    private static final int GREEN = Color.rgb(96, 196, 131);

    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private LinearLayout tabsBar;
    private FrameLayout browserFrame;
    private TextView homePanel;
    private TextView statusLine;
    private TextView seatBadge;
    private EditText address;
    private EditText prompt;
    private Button backButton;
    private Button forwardButton;
    private Button reloadButton;
    private String agentSource;
    private int activeIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(CANVAS);
        window.setNavigationBarColor(CANVAS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(0);
        }
        agentSource = readAsset("seat-agent.js");
        buildChrome();
        newTab();
    }

    private void buildChrome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CANVAS);

        LinearLayout header = row(LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        header.setPadding(dp(15), dp(7), dp(10), dp(6));
        TextView brand = label("FORGE FLIGHT\nPOCKET", 11, INK);
        brand.setTypeface(null, android.graphics.Typeface.BOLD);
        brand.setLetterSpacing(.14f);
        header.addView(brand, new LinearLayout.LayoutParams(0, -1, 1));

        seatBadge = label("0 seats", 11, ORANGE);
        seatBadge.setGravity(Gravity.CENTER);
        seatBadge.setPadding(dp(10), 0, dp(10), 0);
        seatBadge.setBackground(round(PANEL_2, LINE, 18));
        header.addView(seatBadge, new LinearLayout.LayoutParams(-2, dp(32)));

        Button plus = chromeButton("+", 19);
        plus.setContentDescription("New tab");
        plus.setOnClickListener(v -> newTab());
        header.addView(plus, new LinearLayout.LayoutParams(dp(42), dp(42)));
        root.addView(header);

        HorizontalScrollView tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setBackgroundColor(PANEL);
        tabsBar = row(LinearLayout.LayoutParams.WRAP_CONTENT, dp(43));
        tabsBar.setPadding(dp(8), dp(4), dp(8), dp(4));
        tabScroll.addView(tabsBar);
        root.addView(tabScroll, new LinearLayout.LayoutParams(-1, dp(43)));

        LinearLayout navigator = row(LinearLayout.LayoutParams.MATCH_PARENT, dp(53));
        navigator.setPadding(dp(7), dp(6), dp(7), dp(6));
        backButton = chromeButton("‹", 25);
        forwardButton = chromeButton("›", 25);
        reloadButton = chromeButton("↻", 18);
        backButton.setContentDescription("Back");
        forwardButton.setContentDescription("Forward");
        reloadButton.setContentDescription("Reload");
        backButton.setOnClickListener(v -> goBack());
        forwardButton.setOnClickListener(v -> goForward());
        reloadButton.setOnClickListener(v -> reloadPage());
        navigator.addView(backButton, new LinearLayout.LayoutParams(dp(38), -1));
        navigator.addView(forwardButton, new LinearLayout.LayoutParams(dp(38), -1));
        navigator.addView(reloadButton, new LinearLayout.LayoutParams(dp(38), -1));

        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(INK);
        address.setHintTextColor(FAINT);
        address.setTextSize(13);
        address.setHint("Search or enter a web address");
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setPadding(dp(12), 0, dp(7), 0);
        address.setSelectAllOnFocus(true);
        address.setBackground(round(CANVAS, LINE, 11));
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || (event != null && event.getKeyCode() == 66)) {
                navigate(address.getText().toString());
                return true;
            }
            return false;
        });
        navigator.addView(address, new LinearLayout.LayoutParams(0, -1, 1));
        Button go = chromeButton("↵", 18);
        go.setTextColor(ORANGE);
        go.setContentDescription("Go");
        go.setOnClickListener(v -> navigate(address.getText().toString()));
        navigator.addView(go, new LinearLayout.LayoutParams(dp(41), -1));
        root.addView(navigator);

        statusLine = label("Opening a new tab…", 10, MUTED);
        statusLine.setGravity(Gravity.CENTER_VERTICAL);
        statusLine.setPadding(dp(15), 0, dp(15), 0);
        statusLine.setBackgroundColor(PANEL);
        root.addView(statusLine, new LinearLayout.LayoutParams(-1, dp(27)));

        browserFrame = new FrameLayout(this);
        browserFrame.setBackgroundColor(Color.WHITE);
        root.addView(browserFrame, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setPadding(dp(12), dp(7), dp(12), dp(8));
        dock.setBackgroundColor(CANVAS);
        TextView dockLabel = label("●  ASK THE TABLE", 9, ORANGE);
        dockLabel.setTypeface(null, android.graphics.Typeface.BOLD);
        dockLabel.setLetterSpacing(.12f);
        dock.addView(dockLabel, new LinearLayout.LayoutParams(-1, dp(20)));

        LinearLayout promptRow = row(-1, dp(48));
        prompt = new EditText(this);
        prompt.setSingleLine(true);
        prompt.setTextColor(INK);
        prompt.setHintTextColor(FAINT);
        prompt.setTextSize(13);
        prompt.setHint("Ask every open seat…");
        prompt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        prompt.setImeOptions(EditorInfo.IME_ACTION_SEND);
        prompt.setPadding(dp(13), 0, dp(8), 0);
        prompt.setBackground(round(PANEL_2, LINE, 11));
        prompt.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                askTable();
                return true;
            }
            return false;
        });
        promptRow.addView(prompt, new LinearLayout.LayoutParams(0, -1, 1));
        Button send = chromeButton("↑", 19);
        send.setTextColor(CANVAS);
        send.setBackground(round(ORANGE, ORANGE, 9));
        send.setContentDescription("Ask the table");
        send.setOnClickListener(v -> askTable());
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(44), dp(42));
        sendParams.setMargins(dp(7), dp(2), 0, dp(2));
        promptRow.addView(send, sendParams);
        dock.addView(promptRow);
        root.addView(dock, new LinearLayout.LayoutParams(-1, dp(83)));

        setContentView(root);
    }

    private void newTab() {
        BrowserTab tab = new BrowserTab();
        tab.view = makeWebView(tab);
        tabs.add(tab);
        activateTab(tabs.size() - 1);
        updateTabs();
        showHome(tab);
    }

    private WebView makeWebView(final BrowserTab tab) {
        WebView view = new WebView(this);
        CookieManager.getInstance().setAcceptCookie(true);
        view.setBackgroundColor(Color.WHITE);
        view.setFocusable(true);
        view.setFocusableInTouchMode(true);
        android.webkit.WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);

        view.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                tab.url = url;
                tab.seated = false;
                if (tab == activeTab()) {
                    if (homePanel != null) homePanel.setVisibility(View.GONE);
                    statusLine.setText("Loading…");
                    syncBrowser();
                }
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                tab.url = url;
                if (agentSource != null && !agentSource.isEmpty()) {
                    v.evaluateJavascript(agentSource, ignored -> detectSeat(tab));
                } else {
                    detectSeat(tab);
                }
                if (tab == activeTab()) {
                    if (homePanel != null) homePanel.setVisibility(View.GONE);
                    statusLine.setText("Checking this page for a composer…");
                    syncBrowser();
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && tab == activeTab()) {
                    statusLine.setText("The page could not be loaded. Try reload or another address.");
                }
            }
        });
        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedTitle(WebView v, String title) {
                if (title != null && !title.trim().isEmpty()) tab.title = title.trim();
                updateTabs();
                if (tab == activeTab()) syncBrowser();
            }
        });
        browserFrame.addView(view, new FrameLayout.LayoutParams(-1, -1));
        return view;
    }

    private void detectSeat(final BrowserTab tab) {
        tab.view.evaluateJavascript("JSON.stringify(window.__forgeflightMobileDetect ? window.__forgeflightMobileDetect() : {ready:false,reason:'agent-missing'})", result -> {
            String value = result == null ? "" : result;
            tab.seated = value.contains("ready\\\":true") || value.contains("ready\":true");
            updateSeatBadge();
            if (tab == activeTab()) {
                if (tab.seated) {
                    statusLine.setText("Seat ready · composer identified structurally");
                    statusLine.setTextColor(GREEN);
                } else {
                    statusLine.setText("Browsing · no safe composer found on this page");
                    statusLine.setTextColor(MUTED);
                }
            }
            updateTabs();
        });
    }

    private void activateTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        activeIndex = index;
        for (int i = 0; i < tabs.size(); i++) {
            tabs.get(i).view.setVisibility(i == activeIndex ? View.VISIBLE : View.GONE);
        }
        BrowserTab tab = activeTab();
        if (tab != null && tab.url.isEmpty()) showHome(tab); else if (homePanel != null) homePanel.setVisibility(View.GONE);
        syncBrowser();
        updateTabs();
    }

    private void showHome(BrowserTab tab) {
        if (homePanel == null) {
            homePanel = new TextView(this);
            homePanel.setTextColor(MUTED);
            homePanel.setTextSize(15);
            homePanel.setGravity(Gravity.CENTER);
            homePanel.setPadding(dp(30), dp(30), dp(30), dp(30));
            homePanel.setText("FORGE FLIGHT\n\nOpen an AI chat in this tab.\nIt takes a seat when its composer can be identified.\n\nThen ask every open seat from the dock below.");
            homePanel.setLineSpacing(3, 1.2f);
            homePanel.setBackgroundColor(CANVAS);
            browserFrame.addView(homePanel, new FrameLayout.LayoutParams(-1, -1));
        }
        homePanel.setVisibility(View.VISIBLE);
    }

    private void updateTabs() {
        if (tabsBar == null) return;
        tabsBar.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int index = i;
            BrowserTab tab = tabs.get(i);
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            chip.setPadding(dp(10), 0, dp(3), 0);
            chip.setBackground(round(i == activeIndex ? PANEL_2 : PANEL, i == activeIndex ? ORANGE : LINE, 8));
            chip.setOnClickListener(v -> activateTab(index));

            TextView name = label(tab.title.isEmpty() ? "New tab" : tab.title, 11, i == activeIndex ? INK : MUTED);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chip.addView(name, new LinearLayout.LayoutParams(dp(112), -1));
            Button close = chromeButton("×", 16);
            close.setContentDescription("Close tab");
            close.setOnClickListener(v -> closeTab(index));
            chip.addView(close, new LinearLayout.LayoutParams(dp(28), dp(32)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34));
            params.setMargins(0, 0, dp(5), 0);
            tabsBar.addView(chip, params);
        }
        updateSeatBadge();
    }

    private void closeTab(int index) {
        if (tabs.size() == 1) {
            BrowserTab only = tabs.get(0);
            only.view.loadUrl("about:blank");
            only.url = "";
            only.title = "New tab";
            only.seated = false;
            activateTab(0);
            updateTabs();
            return;
        }
        BrowserTab removed = tabs.remove(index);
        browserFrame.removeView(removed.view);
        removed.view.destroy();
        if (activeIndex >= tabs.size()) activeIndex = tabs.size() - 1;
        if (index < activeIndex) activeIndex--;
        activateTab(activeIndex);
        updateTabs();
    }

    private void navigate(String input) {
        String url = normalizeUrl(input);
        if (url.isEmpty()) {
            Toast.makeText(this, "Enter a web address or search term", Toast.LENGTH_SHORT).show();
            return;
        }
        BrowserTab tab = activeTab();
        if (tab == null) return;
        tab.seated = false;
        tab.title = titleFor(url);
        tab.view.loadUrl(url);
        address.clearFocus();
        syncBrowser();
    }

    private void goBack() {
        BrowserTab tab = activeTab();
        if (tab != null && tab.view.canGoBack()) tab.view.goBack();
    }

    private void goForward() {
        BrowserTab tab = activeTab();
        if (tab != null && tab.view.canGoForward()) tab.view.goForward();
    }

    private void reloadPage() {
        BrowserTab tab = activeTab();
        if (tab != null && !tab.url.isEmpty()) tab.view.reload();
    }

    private void askTable() {
        final String text = prompt.getText().toString().trim();
        if (text.isEmpty()) return;
        final int expected = seatCount();
        if (expected == 0) {
            statusLine.setTextColor(Color.rgb(217, 161, 59));
            statusLine.setText("No safe seats yet — Forge Flight will not guess a box.");
            return;
        }
        prompt.setText("");
        prompt.clearFocus();
        final String argument = JSONObject.quote(text);
        final int[] pending = { tabs.size() };
        final int[] sent = { 0 };
        for (BrowserTab tab : tabs) {
            tab.view.evaluateJavascript("window.__forgeflightMobileSend ? JSON.stringify(window.__forgeflightMobileSend(" + argument + ")) : JSON.stringify({ok:false,reason:'agent-missing'})", result -> {
                if (result != null && (result.contains("ok\\\":true") || result.contains("ok\":true"))) sent[0]++;
                pending[0]--;
                if (pending[0] <= 0) {
                    statusLine.setTextColor(sent[0] > 0 ? GREEN : Color.rgb(217, 161, 59));
                    statusLine.setText(sent[0] + " of " + expected + " ready seat" + (expected == 1 ? "" : "s") + " received the prompt.");
                    updateTabs();
                }
            });
        }
        statusLine.setTextColor(ORANGE);
        statusLine.setText("Sending to the table…");
    }

    private void syncBrowser() {
        BrowserTab tab = activeTab();
        if (tab == null) return;
        if (!address.hasFocus()) address.setText(tab.url);
        backButton.setEnabled(tab.view.canGoBack());
        forwardButton.setEnabled(tab.view.canGoForward());
        backButton.setAlpha(tab.view.canGoBack() ? 1f : .35f);
        forwardButton.setAlpha(tab.view.canGoForward() ? 1f : .35f);
        updateSeatBadge();
    }

    private void updateSeatBadge() {
        int count = seatCount();
        if (seatBadge != null) seatBadge.setText(count + " seat" + (count == 1 ? "" : "s"));
    }

    private int seatCount() {
        int count = 0;
        for (BrowserTab tab : tabs) if (tab.seated) count++;
        return count;
    }

    private BrowserTab activeTab() {
        return activeIndex >= 0 && activeIndex < tabs.size() ? tabs.get(activeIndex) : null;
    }

    private static String normalizeUrl(String input) {
        String raw = input == null ? "" : input.trim();
        if (raw.isEmpty()) return "";
        if (raw.matches("(?i)^(javascript|data|file|vbscript):.*")) return "";
        if (raw.matches("(?i)^https?://.*")) {
            Uri parsed = Uri.parse(raw);
            return parsed.getHost() == null ? "" : raw;
        }
        String host = "(?i)^(?:localhost|(?:\\d{1,3}\\.){3}\\d{1,3}|\\[[0-9a-f:]+\\]|[\\w-]+(?:\\.[\\w-]+)+)(?::\\d{1,5})?(?:[/?#].*)?$";
        if (raw.matches(host)) return "https://" + raw;
        return "https://duckduckgo.com/?q=" + Uri.encode(raw);
    }

    private static String titleFor(String url) {
        try {
            String host = Uri.parse(url).getHost();
            if (host == null || host.isEmpty()) return "New tab";
            host = host.replaceFirst("^www\\.", "");
            String part = host.split("\\.")[0];
            return part.substring(0, 1).toUpperCase(Locale.ROOT) + part.substring(1);
        } catch (Exception ignored) {
            return "Web page";
        }
    }

    private String readAsset(String name) {
        try (InputStream input = getAssets().open(name); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toString("UTF-8");
        } catch (Exception ignored) {
            return "";
        }
    }

    private TextView label(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private Button chromeButton(String text, float size) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(size);
        button.setTextColor(MUTED);
        button.setGravity(Gravity.CENTER);
        button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setBackgroundColor(Color.TRANSPARENT);
        return button;
    }

    private LinearLayout row(int width, int height) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutParams(new LinearLayout.LayoutParams(width, height));
        return row;
    }

    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        BrowserTab tab = activeTab();
        if (tab != null && tab.view.canGoBack()) tab.view.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        for (BrowserTab tab : tabs) tab.view.destroy();
        tabs.clear();
        super.onDestroy();
    }

    private static final class BrowserTab {
        WebView view;
        String url = "";
        String title = "New tab";
        boolean seated = false;
    }
}
