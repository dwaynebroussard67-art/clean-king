/*
 * The Android WebView seat agent.
 *
 * It deliberately uses the same structural posture as src/detector: no
 * provider selectors, no provider names, and no credential access. A page is
 * a seat only when a visible editable near the bottom looks like a message
 * composer, survives the anchored/document-field discriminator, and its
 * read-back matches before the send control is pressed.
 */
(function () {
  'use strict';

  var messageWords = ['message', 'prompt', 'ask', 'chat', 'question', 'type a', 'send a'];
  var searchWords = ['search', 'find', 'filter', 'lookup', 'look up'];
  var documentWords = ['comment', 'feedback', 'review', 'description', 'bio', 'caption', 'subject', 'summary'];
  var sendWords = ['send', 'submit', 'ask', 'go', 'run', 'enter', 'post'];

  function textOf(el) {
    if (!el) return '';
    return [
      el.getAttribute('placeholder'), el.getAttribute('aria-label'),
      el.getAttribute('aria-placeholder'), el.getAttribute('title'),
      el.getAttribute('name'), el.getAttribute('id'), el.getAttribute('role'),
      el.getAttribute('data-testid'), el.textContent
    ].filter(Boolean).join(' ').toLowerCase().slice(0, 400);
  }

  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    var s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > .05;
  }

  function editable(el) {
    if (!visible(el) || el.disabled || el.readOnly) return false;
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'textarea') return true;
    if (tag === 'input') return ['text', 'search', 'url', 'email', ''].indexOf((el.type || 'text').toLowerCase()) >= 0;
    return el.isContentEditable || el.getAttribute('contenteditable') === 'true' || el.getAttribute('role') === 'textbox';
  }

  function hits(text, words) {
    var count = 0;
    words.forEach(function (word) { if (text.indexOf(word) >= 0) count++; });
    return count;
  }

  function pageScrolls() {
    var root = document.documentElement;
    return !!(root && root.scrollHeight > (window.innerHeight || root.clientHeight) + 4);
  }

  function anchored(el) {
    var node = el;
    var hops = 0;
    while (node && node.tagName && hops < 14) {
      var tag = node.tagName.toLowerCase();
      if (tag === 'body' || tag === 'html') break;
      var style = getComputedStyle(node);
      if (style.position === 'fixed' || style.position === 'sticky') return true;
      if ((style.overflowY === 'auto' || style.overflowY === 'scroll' || style.overflowY === 'overlay') && node.scrollHeight > node.clientHeight + 4) return false;
      node = node.parentElement;
      hops++;
    }
    return !pageScrolls();
  }

  function allEditables() {
    return Array.prototype.slice.call(document.querySelectorAll('textarea, input, [contenteditable], [role="textbox"]')).filter(editable);
  }

  function detect() {
    var viewport = window.innerHeight || 800;
    var width = window.innerWidth || 800;
    var candidates = allEditables().map(function (el) {
      var r = el.getBoundingClientRect();
      var label = textOf(el);
      var messageHits = hits(label, messageWords);
      var searchHits = hits(label, searchWords);
      var docHits = hits(label, documentWords);
      var isAnchored = anchored(el);
      var score = 0;
      if (messageHits) score += 4;
      if (searchHits) score -= 4;
      if (docHits) score -= 2;
      if (r.top + r.height / 2 > viewport * .55) score += 3;
      if (r.width > Math.min(280, width * .42)) score += 2;
      if (r.height >= 34 || el.tagName.toLowerCase() === 'textarea' || el.getAttribute('aria-multiline') === 'true') score += 2;
      if (isAnchored) score += 3;
      if (el.closest && el.closest('header, nav, aside, [role="navigation"], [role="search"]')) score -= 4;
      // A document-flow field without a positive message label is a form or
      // comment box, not a safe seat. This is the mobile equivalent of the
      // desktop detector's document-field conjunctive discriminator.
      if (!isAnchored && !messageHits) score = -100;
      return {
        el: el,
        score: score,
        message: !!messageHits,
        anchored: isAnchored,
        rect: r
      };
    }).filter(function (candidate) { return candidate.score > -50; }).sort(function (a, b) { return b.score - a.score; });
    if (!candidates.length || candidates[0].score < 6) return { ready: false, reason: candidates.length ? 'below-floor' : 'no-composer' };
    if (candidates[1] && candidates[0].score - candidates[1].score < 2) return { ready: false, reason: 'ambiguous' };
    return { ready: true, composer: candidates[0].el };
  }

  function read(el) {
    if (!el) return '';
    return typeof el.value === 'string' ? el.value : (el.innerText || el.textContent || '').replace(/\u00a0/g, ' ');
  }

  function fireInput(el, value) {
    try {
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: value }));
    } catch (_) {
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function write(el, value) {
    el.focus();
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'textarea' || tag === 'input') {
      var proto = tag === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto, 'value');
      if (setter && setter.set) setter.set.call(el, value); else el.value = value;
    } else {
      var inserted = false;
      try {
        document.execCommand('selectAll', false);
        inserted = document.execCommand('insertText', false, value);
      } catch (_) { /* use the plain fallback below */ }
      if (!inserted || read(el) !== value) el.textContent = value;
    }
    fireInput(el, value);
    return read(el) === value;
  }

  function sendFor(composer) {
    var controls = [];
    var seen = [];
    var node = composer;
    var hops = 0;
    while (node && node.querySelectorAll && hops < 9) {
      Array.prototype.slice.call(node.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]')).forEach(function (el) {
        if (seen.indexOf(el) < 0 && visible(el)) { seen.push(el); controls.push(el); }
      });
      node = node.parentElement;
      hops++;
    }
    controls = controls.map(function (el) {
      var label = textOf(el);
      var distance = Math.abs(el.getBoundingClientRect().left - composer.getBoundingClientRect().right) + Math.abs(el.getBoundingClientRect().top - composer.getBoundingClientRect().top);
      return {
        el: el,
        send: hits(label, sendWords),
        score: (hits(label, sendWords) * 10) + (el.tagName.toLowerCase() === 'button' ? 2 : 0) - distance / 1000
      };
    }).filter(function (candidate) { return candidate.send > 0; }).sort(function (a, b) { return b.score - a.score; });
    if (controls.length) {
      if (controls[0].el.disabled) return { ok: false, reason: 'send-disabled' };
      controls[0].el.click();
      return { ok: true, via: 'button' };
    }
    composer.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
    composer.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', bubbles: true }));
    composer.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
    return { ok: true, via: 'enter' };
  }

  function expose(name, fn) {
    try {
      // Keep the page from replacing the detector after it has loaded. The
      // function still runs in the page's WebView world (Android has no
      // Electron-style isolated preload), so this is tamper resistance, not a
      // claim that an untrusted page can never observe a prompt typed into it.
      Object.defineProperty(window, name, { value: fn, writable: false, configurable: false });
    } catch (_) {
      window[name] = fn;
    }
  }

  expose('__forgeflightMobileDetect', function () {
    var result = detect();
    return { ready: result.ready, reason: result.reason || null };
  });

  expose('__forgeflightMobileSend', function (prompt) {
    var result = detect();
    if (!result.ready) return { ok: false, reason: result.reason || 'no-composer' };
    if (!write(result.composer, String(prompt || '').trim())) return { ok: false, reason: 'readback-mismatch' };
    return sendFor(result.composer);
  });
})();
