# Forge Flight Pocket does not ship with a JavaScript bridge object. Keep the
# default Android rules for the first mobile build.
