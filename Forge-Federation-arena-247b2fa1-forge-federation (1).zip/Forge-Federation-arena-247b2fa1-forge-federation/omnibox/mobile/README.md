# Forge Flight on a phone

This folder is the mobile build of the clone. It has two delivery paths:

- **Pocket PWA** — a dependency-free, installable touch surface that works in
  Safari on iPhone and Chrome on Android. It keeps tabs, recent pages, and the
  AI seat list on the device. It never proxies a page or asks for credentials.
- **Android wrapper** — a real Android WebView browser for pages that refuse to
  be embedded in a PWA. Each tab is a normal WebView with its own navigation
  history and cookie jar. The structural seat agent is injected after a page
  loads; it verifies read-back before it presses send.

The desktop Electron build remains unchanged as the full desktop experience.
The phone build is additive and deliberately stays on this branch; nothing is
merged into the upstream repository.

## Try the PWA on a phone

From the repository root (the mobile server uses only Node built-ins, so no
package install is required for the PWA):

```sh
npm run mobile
```

The server binds to `0.0.0.0:4173`. Find the computer's LAN address, open
`http://YOUR-LAN-IP:4173` on the phone, then use **Add to Home Screen**. The
server does not proxy or cache remote websites; remote pages are loaded only
when the phone browser allows them to be framed. The web shell always exposes
an **Open full page** action. If a restrictive `X-Frame-Options` or
`frame-ancestors` policy prevents the embedded view from rendering, that is the
honest fallback; a parent web page cannot reliably read that policy across
origins.

For a local preview in the repository checkout, open
`http://localhost:4173/mobile/` only if another static server is serving the
repository root. `npm run mobile` is the supported command.

## Build the Android browser

Open `mobile/android` in Android Studio (Hedgehog or newer), let it install the
Android SDK platform 35, then choose **Build → Build APK(s)**. The project has
no third-party runtime libraries. The resulting debug APK can be installed on
an Android phone.

The Android app is intentionally honest about what it can read:

- the WebView loads the address you enter directly, with normal Android cookie
  storage;
- the bundled `seat-agent.js` only inspects visible editable elements in the
  current WebView, without provider names or CSS selectors;
- an ambiguous or missing composer is refused by name;
- prompts are sent only to tabs whose structural detector found a composer;
- no page text, password, or API key is copied into Forge Flight storage.

## Mobile design notes

`src/renderer/chrome.css` also has a `max-width: 720px` layout for the Electron
chrome: the seat rail becomes a touch drawer, tables become horizontally
scrollable cards, and the composer respects safe-area insets. That keeps the
same desktop code ready for a native WebView host while the standalone mobile
build remains easy to install.
