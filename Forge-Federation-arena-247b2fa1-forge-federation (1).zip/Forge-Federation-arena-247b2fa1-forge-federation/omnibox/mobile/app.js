/* Forge Flight Pocket — dependency-free mobile surface for the browser build. */
'use strict';

const STORAGE_KEY = 'forgeflight-pocket-v1';
// The key OmniBox Pocket saved under. Adopted once, then removed (D26).
const LEGACY_STORAGE_KEY = 'omnibox-pocket-v1';
const DEFAULT_TABS = [{ id: 'tab-1', title: 'New tab', url: '', history: [], index: -1 }];
const DEFAULT_STATE = {
  tabs: DEFAULT_TABS,
  activeId: 'tab-1',
  seats: [],
  pendingPrompt: '',
  recent: [],
  customSites: [],
};
const clone = (value) => JSON.parse(JSON.stringify(value));

const $ = (id) => document.getElementById(id);
const escapeText = (value) => String(value || '').trim();
function isHttpUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return (url.protocol === 'http:' || url.protocol === 'https:') && !!url.hostname;
  } catch {
    return false;
  }
}
let state = loadState();
let currentView = 'browse';
let installPrompt = null;
let frameTimer = null;
let frameLoaded = false;
let toastTimer = null;

function adoptLegacyState() {
  // Same rule as the desktop profile: only when there is nothing new yet,
  // move rather than copy, never throw.
  try {
    if (localStorage.getItem(STORAGE_KEY) !== null) return;
    const old = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (old === null) return;
    localStorage.setItem(STORAGE_KEY, old);
    localStorage.removeItem(LEGACY_STORAGE_KEY);
  } catch { /* storage is optional */ }
}

function loadState() {
  try {
    adoptLegacyState();
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (!parsed || !Array.isArray(parsed.tabs)) return clone(DEFAULT_STATE);
    const tabs = (parsed.tabs.length ? parsed.tabs : clone(DEFAULT_TABS)).map((tab, index) => {
      const history = Array.isArray(tab.history) ? tab.history.filter(isHttpUrl) : [];
      const requestedIndex = Number.isInteger(tab.index) ? tab.index : history.length - 1;
      const safeIndex = history.length ? Math.max(0, Math.min(requestedIndex, history.length - 1)) : -1;
      return {
        id: typeof tab.id === 'string' && tab.id ? tab.id : `tab-${index + 1}`,
        title: typeof tab.title === 'string' && tab.title ? tab.title.slice(0, 120) : 'New tab',
        url: safeIndex >= 0 ? history[safeIndex] : '',
        history,
        index: safeIndex,
      };
    });
    const activeId = tabs.some((tab) => tab.id === parsed.activeId) ? parsed.activeId : tabs[0].id;
    return {
      ...DEFAULT_STATE,
      ...parsed,
      activeId,
      tabs,
      seats: Array.isArray(parsed.seats) ? parsed.seats.filter((seat) => seat && isHttpUrl(seat.url)) : [],
      pendingPrompt: typeof parsed.pendingPrompt === 'string' ? parsed.pendingPrompt.slice(0, 2000) : '',
      recent: Array.isArray(parsed.recent) ? parsed.recent.filter((item) => item && isHttpUrl(item.url)).slice(0, 24) : [],
      customSites: Array.isArray(parsed.customSites) ? parsed.customSites.filter((site) => site && isHttpUrl(site.url)).slice(0, 8) : [],
    };
  } catch {
    return clone(DEFAULT_STATE);
  }
}

function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* storage is optional */ }
}

function activeTab() {
  return state.tabs.find((tab) => tab.id === state.activeId) || state.tabs[0];
}

function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return ''; }
}

function titleFor(url) {
  const host = hostOf(url);
  if (!host) return 'New tab';
  const part = host.split('.')[0];
  return part.charAt(0).toUpperCase() + part.slice(1);
}

function normalizeUrl(input) {
  const raw = escapeText(input);
  if (!raw) return '';
  if (/^(javascript|vbscript|file|data):/i.test(raw)) return '';
  if (/^https?:\/\//i.test(raw)) return isHttpUrl(raw) ? new URL(raw).href : '';
  const looksLikeHost = /^(?:localhost|(?:\d{1,3}\.){3}\d{1,3}|\[[0-9a-f:]+\]|[\w-]+(?:\.[\w-]+)+)(?::\d{1,5})?(?:[/?#].*)?$/i;
  if (looksLikeHost.test(raw)) {
    const url = `https://${raw}`;
    return isHttpUrl(url) ? new URL(url).href : '';
  }
  return `https://duckduckgo.com/?q=${encodeURIComponent(raw)}`;
}

function setView(view) {
  currentView = view;
  $('homeView').hidden = view !== 'browse' || !!activeTab().url;
  $('webviewWrap').hidden = view !== 'browse' || !activeTab().url;
  $('tablePanel').hidden = view !== 'table';
  $('historyPanel').hidden = view !== 'history';
  $('promptDock').hidden = view === 'history';
  document.querySelectorAll('.bottom-item[data-view]').forEach((button) => {
    button.classList.toggle('active', button.dataset.view === view);
  });
  if (view === 'table') renderSeats();
  if (view === 'history') renderHistory();
  if (view === 'browse') syncBrowser();
  closeSheets();
}

function syncBrowser() {
  const tab = activeTab();
  $('addressInput').value = tab.url || '';
  $('addressLock').textContent = /^https:/i.test(tab.url) ? '●' : '○';
  $('addressLock').style.color = /^https:/i.test(tab.url) ? 'var(--green)' : 'var(--faint)';
  $('backButton').disabled = tab.index <= 0;
  $('forwardButton').disabled = tab.index < 0 || tab.index >= tab.history.length - 1;
  $('tabsBadge').textContent = state.tabs.length;
  const hasSeats = state.seats.length;
  $('dockSeatCopy').textContent = `${hasSeats} saved seat${hasSeats === 1 ? '' : 's'}`;
  $('dockHint').textContent = hasSeats
    ? (state.pendingPrompt ? 'Prompt saved — copy it into each open seat.' : 'Open a saved destination, then send from the site’s own composer.')
    : 'Open an AI site to make your first seat.';
  $('tableBadge').textContent = hasSeats;
  $('tableBadge').hidden = hasSeats === 0;
  $('pageState').classList.remove('loading');
  $('pageState').innerHTML = '<i></i> ready';
  $('siteTitle').textContent = tab.title || hostOf(tab.url) || 'Web page';
  $('siteDot').style.background = /^https:/i.test(tab.url) ? 'var(--green)' : 'var(--orange)';
}

function recordRecent(url, title) {
  if (!url) return;
  state.recent = [{ url, title: title || titleFor(url), at: Date.now() }, ...state.recent.filter((item) => item.url !== url)].slice(0, 24);
}

function addSeat(url, name) {
  if (!isHttpUrl(url)) return;
  const host = hostOf(url);
  const existing = state.seats.find((seat) => seat.host === host);
  if (existing) {
    existing.url = url;
    existing.lastOpened = Date.now();
  } else {
    state.seats.push({ id: `seat-${Date.now()}`, host, name: name || titleFor(url), url, lastOpened: Date.now() });
  }
}

function navigate(input, { record = true, title } = {}) {
  const url = normalizeUrl(input);
  if (!url) {
    showToast('Enter a web address or a search term.');
    return;
  }
  const tab = activeTab();
  if (!tab) return;
  // A new navigation discards the forward branch, like a real browser.
  tab.history = tab.history.slice(0, tab.index + 1);
  tab.history.push(url);
  tab.index = tab.history.length - 1;
  tab.url = url;
  tab.title = title || titleFor(url);
  if (record) recordRecent(url, tab.title);
  addSeatIfAI(url);
  saveState();
  setView('browse');
  loadFrame(url);
  renderHistory();
}

function addSeatIfAI(url) {
  const host = hostOf(url);
  // The quick links are intentionally the only automatic seat labels in the
  // web fallback. Native builds can run the full structural detector inside
  // the page WebView; the PWA never pretends it can inspect a cross-origin
  // iframe it does not own.
  const known = [...document.querySelectorAll('.quick-card[data-url]')].find((card) => hostOf(card.dataset.url) === host);
  if (known) addSeat(url, known.dataset.name);
}

function loadFrame(url) {
  frameLoaded = false;
  clearTimeout(frameTimer);
  $('homeView').hidden = true;
  $('webviewWrap').hidden = false;
  $('frameFallback').hidden = true;
  $('pageState').classList.add('loading');
  $('pageState').innerHTML = '<i></i> loading';
  $('webview').src = url;
  $('siteTitle').textContent = titleFor(url);
  frameTimer = setTimeout(() => {
    if (!frameLoaded) $('frameFallback').hidden = false;
  }, 2600);
  syncBrowser();
}

function goBack() {
  const tab = activeTab();
  if (!tab || tab.index <= 0) return;
  tab.index -= 1;
  tab.url = tab.history[tab.index] || '';
  tab.title = titleFor(tab.url);
  saveState();
  loadFrame(tab.url);
}

function goForward() {
  const tab = activeTab();
  if (!tab || tab.index >= tab.history.length - 1) return;
  tab.index += 1;
  tab.url = tab.history[tab.index] || '';
  tab.title = titleFor(tab.url);
  saveState();
  loadFrame(tab.url);
}

function reload() {
  const frame = $('webview');
  if (!activeTab().url) return;
  frameLoaded = false;
  $('frameFallback').hidden = true;
  $('pageState').classList.add('loading');
  $('pageState').innerHTML = '<i></i> loading';
  frame.src = activeTab().url;
  clearTimeout(frameTimer);
  frameTimer = setTimeout(() => { if (!frameLoaded) $('frameFallback').hidden = false; }, 2600);
}

function openExternal(url = activeTab().url) {
  if (!url) return;
  window.open(url, '_blank', 'noopener,noreferrer');
}

function newTab() {
  const id = `tab-${Date.now()}`;
  state.tabs.push({ id, title: 'New tab', url: '', history: [], index: -1 });
  state.activeId = id;
  saveState();
  setView('browse');
  renderTabsSheet();
  showToast('New tab');
}

function closeTab(id) {
  if (state.tabs.length === 1) {
    state.tabs[0] = { id: state.tabs[0].id, title: 'New tab', url: '', history: [], index: -1 };
  } else {
    const index = state.tabs.findIndex((tab) => tab.id === id);
    state.tabs = state.tabs.filter((tab) => tab.id !== id);
    if (state.activeId === id) state.activeId = state.tabs[Math.max(0, index - 1)].id;
  }
  saveState();
  setView('browse');
  renderTabsSheet();
  syncBrowser();
}

function activateTab(id) {
  if (!state.tabs.some((tab) => tab.id === id)) return;
  state.activeId = id;
  saveState();
  closeSheets();
  setView('browse');
  const tab = activeTab();
  if (tab.url) loadFrame(tab.url);
  else syncBrowser();
}

function renderSeats() {
  const list = $('seatList');
  list.textContent = '';
  $('seatCount').textContent = state.seats.length;
  $('tableEmpty').hidden = state.seats.length > 0;
  $('pendingPrompt').hidden = !state.pendingPrompt;
  $('pendingPromptText').textContent = state.pendingPrompt;
  for (const seat of state.seats) {
    const row = document.createElement('div');
    row.className = 'mobile-seat';
    const icon = document.createElement('span');
    icon.className = 'mobile-seat-icon';
    icon.textContent = '↗';
    const copy = document.createElement('div');
    const name = document.createElement('strong');
    name.textContent = seat.name;
    const host = document.createElement('small');
    host.textContent = `${seat.host} · saved destination`;
    copy.append(name, host);
    const open = document.createElement('button');
    open.textContent = 'Open';
    open.setAttribute('aria-label', `Open ${seat.name}`);
    open.onclick = () => {
      navigate(seat.url, { title: seat.name });
      showToast(`${seat.name} opened in this tab`);
    };
    row.append(icon, copy, open);
    list.append(row);
  }
}

function renderHistory() {
  const list = $('historyList');
  list.textContent = '';
  $('historyEmpty').hidden = state.recent.length > 0;
  for (const item of state.recent) {
    const button = document.createElement('button');
    button.className = 'history-row';
    const favicon = document.createElement('span');
    favicon.className = 'history-favicon';
    favicon.textContent = '↗';
    const copy = document.createElement('span');
    copy.className = 'history-copy';
    const title = document.createElement('strong');
    title.textContent = item.title || titleFor(item.url);
    const url = document.createElement('small');
    url.textContent = item.url;
    copy.append(title, url);
    button.append(favicon, copy);
    button.onclick = () => navigate(item.url, { title: item.title });
    list.append(button);
  }
}

function renderTabsSheet() {
  const list = $('tabsSheetList');
  list.textContent = '';
  for (const tab of state.tabs) {
    const row = document.createElement('div');
    row.className = `mobile-tab${tab.id === state.activeId ? ' active' : ''}`;
    const dot = document.createElement('i');
    const open = document.createElement('button');
    open.className = 'tab-open';
    open.textContent = tab.title || 'New tab';
    open.setAttribute('aria-label', `Switch to ${tab.title || 'new tab'}`);
    const small = document.createElement('small');
    small.textContent = tab.url ? hostOf(tab.url) : 'start page';
    open.append(small);
    open.onclick = () => activateTab(tab.id);
    const close = document.createElement('button');
    close.className = 'close-tab';
    close.textContent = '×';
    close.setAttribute('aria-label', `Close ${tab.title || 'tab'}`);
    close.onclick = () => closeTab(tab.id);
    row.append(dot, open, close);
    list.append(row);
  }
  $('tabsBadge').textContent = state.tabs.length;
}

function submitPrompt(event) {
  event.preventDefault();
  const input = $('promptInput');
  const prompt = escapeText(input.value);
  if (!prompt) return;
  if (state.seats.length === 0) {
    showToast('Open an AI site first — it becomes a seat here.');
    setView('browse');
    return;
  }
  // The PWA cannot inject into a cross-origin frame. Do not claim that it did.
  // Native mobile wrappers use the same action with WebView injection and
  // keep the actual account pages in their own secure WebViews.
  const names = state.seats.map((seat) => seat.name).join(' + ');
  state.pendingPrompt = prompt;
  saveState();
  showToast(`Prompt saved for ${names}. Copy it into each open seat.`);
  input.value = '';
  setView('table');
}

function addCustomSite() {
  const value = window.prompt('Paste the site address for a new seat');
  const url = normalizeUrl(value);
  if (!isHttpUrl(url)) {
    if (value) showToast('That does not look like a web address.');
    return;
  }
  const name = window.prompt('Name this seat', titleFor(url)) || titleFor(url);
  state.customSites = [{ url, name: escapeText(name) || titleFor(url) }, ...state.customSites.filter((site) => site.url !== url)].slice(0, 8);
  addSeat(url, name);
  saveState();
  navigate(url, { title: name });
}

function showToast(message) {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  $('app').append(toast);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.remove(), 3200);
}

function closeSheets() {
  $('menuSheet').hidden = true;
  $('tabsSheet').hidden = true;
  $('scrim').hidden = true;
  $('menuButton').setAttribute('aria-expanded', 'false');
}
function openSheet(id) {
  renderTabsSheet();
  $('menuSheet').hidden = id !== 'menu';
  $('tabsSheet').hidden = id !== 'tabs';
  $('scrim').hidden = false;
  $('menuButton').setAttribute('aria-expanded', String(id === 'menu'));
}

// ---------------------------------------------------------------- controls
$('addressForm').addEventListener('submit', (event) => {
  event.preventDefault();
  navigate($('addressInput').value);
});
$('backButton').onclick = goBack;
$('forwardButton').onclick = goForward;
$('reloadButton').onclick = reload;
$('externalButton').onclick = () => openExternal();
$('fallbackOpen').onclick = () => openExternal();
$('promptForm').addEventListener('submit', submitPrompt);
$('browseButton').onclick = () => setView('browse');
$('addQuickButton').onclick = addCustomSite;
$('menuButton').onclick = () => openSheet('menu');
$('menuClose').onclick = closeSheets;
$('tabsButton').onclick = () => openSheet('tabs');
$('tabsClose').onclick = closeSheets;
$('newTabButton').onclick = () => { closeSheets(); newTab(); };
$('scrim').onclick = closeSheets;
$('installButton').onclick = async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  $('installButton').hidden = true;
};
$('installFromMenu').onclick = () => {
  closeSheets();
  $('installButton').click();
};
$('resetApp').onclick = () => {
  if (!window.confirm('Reset tabs, seats, and history on this device?')) return;
  localStorage.removeItem(STORAGE_KEY);
  state = clone(DEFAULT_STATE);
  saveState();
  renderHistory();
  renderSeats();
  renderTabsSheet();
  setView('browse');
  showToast('Pocket browser reset');
};
$('clearHistory').onclick = () => {
  state.recent = [];
  saveState();
  renderHistory();
};
$('copyPrompt').onclick = async () => {
  if (!state.pendingPrompt) return;
  try {
    await navigator.clipboard.writeText(state.pendingPrompt);
    showToast('Prompt copied to the clipboard.');
  } catch {
    showToast('Clipboard access was unavailable — select the prompt above.');
  }
};

document.querySelectorAll('.bottom-item[data-view]').forEach((button) => {
  button.onclick = () => setView(button.dataset.view);
});

document.querySelectorAll('.quick-card[data-url]').forEach((card) => {
  card.onclick = () => {
    const url = card.dataset.url;
    addSeat(url, card.dataset.name);
    navigate(url, { title: card.dataset.name });
  };
});

$('webview').addEventListener('load', () => {
  frameLoaded = true;
  clearTimeout(frameTimer);
  $('frameFallback').hidden = true;
  $('pageState').classList.remove('loading');
  $('pageState').innerHTML = '<i></i> loaded';
});

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
  $('installButton').hidden = false;
});
window.addEventListener('appinstalled', () => {
  installPrompt = null;
  $('installButton').hidden = true;
  showToast('Forge Flight Pocket is on your home screen.');
});

// Keep the PWA useful as a lightweight phone surface, while the native
// Android wrapper uses real WebViews for pages that refuse iframe embedding.
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});

function renderCustomSites() {
  const grid = $('quickGrid');
  const add = $('addQuickButton');
  for (const site of [...state.customSites].reverse()) {
    if ([...grid.querySelectorAll('.quick-card[data-url]')].some((card) => card.dataset.url === site.url)) continue;
    const card = document.createElement('button');
    card.className = 'quick-card';
    card.dataset.url = site.url;
    card.dataset.name = site.name;
    const icon = document.createElement('span');
    icon.className = 'quick-icon';
    icon.textContent = '↗';
    const copy = document.createElement('span');
    const name = document.createElement('b');
    name.textContent = site.name;
    const host = document.createElement('small');
    host.textContent = hostOf(site.url);
    copy.append(name, host);
    const arrow = document.createElement('span');
    arrow.className = 'arrow';
    arrow.textContent = '↗';
    card.append(icon, copy, arrow);
    card.onclick = () => { addSeat(site.url, site.name); navigate(site.url, { title: site.name }); };
    grid.insertBefore(card, add);
  }
}

renderCustomSites();
renderTabsSheet();
renderHistory();
renderSeats();
setView('browse');
