import { NextRequest, NextResponse } from 'next/server';
import { adaptiveSystem } from '@/lib/self-adaptive';

export const dynamic = 'force-dynamic';

// Read the live MAPE-K state out of the running process. This is in-memory by
// design: it describes *this* server instance, and averaging it across
// instances would describe none of them.
export async function GET() {
  return NextResponse.json(adaptiveSystem.getState());
}

// Manual override for a single parameter — the "operator in the loop" half of
// a self-adaptive system.
export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== 'object') {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  const { parameter, value, enabled } = body as {
    parameter?: string;
    value?: number;
    enabled?: boolean;
  };

  if (typeof enabled === 'boolean') {
    adaptiveSystem.setAdaptationEnabled(enabled);
  }

  if (typeof parameter === 'string') {
    if (typeof value !== 'number' || !Number.isFinite(value)) {
      return NextResponse.json(
        { error: 'value must be a finite number when parameter is given' },
        { status: 400 }
      );
    }
    adaptiveSystem.setParameter(parameter, value);
  }

  return NextResponse.json(adaptiveSystem.getState());
}
