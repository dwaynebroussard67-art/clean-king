import { json, fail, readBody } from '@/lib/http.ts';
import { getBrowserEngine, resolveAddressBar } from '@/lib/browser-engine.ts';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const raw = typeof body.url === 'string' ? body.url : '';
    if (!raw) return json({ error: 'url is required' }, 400);
    const engine = getBrowserEngine();
    const tab = await engine.navigate(
      resolveAddressBar(raw),
      typeof body.tabId === 'string' ? body.tabId : undefined,
    );
    return json({ tab, ...engine.status() });
  } catch (error) {
    return fail(error);
  }
}
