import { json, fail } from '@/lib/http.ts';
import { getBrowserEngine } from '@/lib/browser-engine.ts';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const tabId = new URL(request.url).searchParams.get('tab') ?? undefined;
    const engine = getBrowserEngine();
    await engine.ensure();
    return json(await engine.snapshot(tabId));
  } catch (error) {
    return fail(error);
  }
}
