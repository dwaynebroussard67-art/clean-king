import { getBrowserEngine } from '@/lib/browser-engine.ts';

export const dynamic = 'force-dynamic';

/**
 * The windshield. Served as same-origin HTML so the cockpit can iframe
 * any page without X-Frame-Options fighting us. The iframe is sandboxed
 * without allow-same-origin, so page scripts cannot read OmniBox cookies.
 */
export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const engine = getBrowserEngine();
    await engine.ensure();
    const tabId = url.searchParams.get('tab') ?? undefined;
    const doc = engine.documentHtml(tabId);
    return new Response(doc.html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'Content-Security-Policy': "frame-ancestors 'self'",
        'X-OmniBox-Url': doc.url,
        'X-OmniBox-Title': encodeURIComponent(doc.title),
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return new Response(`<!doctype html><pre>${message}</pre>`, {
      status: 500,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  }
}
