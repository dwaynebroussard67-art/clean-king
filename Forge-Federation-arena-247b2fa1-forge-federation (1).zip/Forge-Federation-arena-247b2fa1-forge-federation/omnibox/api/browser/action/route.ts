import { json, fail, readBody } from '@/lib/http.ts';
import { getBrowserEngine, mapScreenshotClick } from '@/lib/browser-engine.ts';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const engine = getBrowserEngine();
    await engine.ensure();
    const tabId = typeof body.tabId === 'string' ? body.tabId : undefined;
    const type = String(body.type ?? '');

    switch (type) {
      case 'click': {
        let x = typeof body.x === 'number' ? body.x : undefined;
        let y = typeof body.y === 'number' ? body.y : undefined;
        if (
          typeof body.clientX === 'number'
          && typeof body.clientY === 'number'
          && typeof body.displayWidth === 'number'
          && typeof body.displayHeight === 'number'
        ) {
          const mapped = mapScreenshotClick(body.clientX, body.clientY, body.displayWidth, body.displayHeight);
          x = mapped.x;
          y = mapped.y;
        }
        const result = await engine.click({
          selector: typeof body.selector === 'string' ? body.selector : undefined,
          text: typeof body.text === 'string' ? body.text : undefined,
          x,
          y,
        }, tabId);
        return json({ result, tab: engine.activeTab(), ...engine.status() });
      }
      case 'type':
        return json({
          result: await engine.type({
            selector: String(body.selector ?? ''),
            text: String(body.text ?? ''),
            clearFirst: body.clearFirst !== false,
          }, tabId),
        });
      case 'back':
        return json({ tab: await engine.back(tabId), ...engine.status() });
      case 'reload':
        return json({ tab: await engine.reload(tabId), ...engine.status() });
      default:
        return json({ error: 'type must be click|type|back|reload' }, 400);
    }
  } catch (error) {
    return fail(error);
  }
}
