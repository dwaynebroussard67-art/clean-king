import { json, fail } from '@/lib/http.ts';
import { getBrowserEngine } from '@/lib/browser-engine.ts';
import { getBridgeStatus } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const engine = getBrowserEngine();
    await engine.ensure();
    return json({
      ...engine.status(),
      bridge: getBridgeStatus(),
    });
  } catch (error) {
    return fail(error, 500);
  }
}
