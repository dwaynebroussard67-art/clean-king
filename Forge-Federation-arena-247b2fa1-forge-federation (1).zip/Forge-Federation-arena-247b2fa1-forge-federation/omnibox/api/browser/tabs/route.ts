import { json, fail, readBody } from '@/lib/http.ts';
import { getBrowserEngine, resolveAddressBar } from '@/lib/browser-engine.ts';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const engine = getBrowserEngine();
    await engine.ensure();
    return json(engine.status());
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request).catch(() => ({} as Record<string, unknown>));
    const engine = getBrowserEngine();
    if (body.action === 'activate') {
      return json({ tab: engine.activate(String(body.id ?? '')) });
    }
    if (body.action === 'close') {
      await engine.closeTab(String(body.id ?? ''));
      return json(engine.status());
    }
    const url = typeof body.url === 'string' && body.url.trim()
      ? resolveAddressBar(body.url)
      : undefined;
    const tab = await engine.newTab(url);
    return json({ tab, ...engine.status() }, 201);
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    if (!id) return json({ error: 'id is required' }, 400);
    await getBrowserEngine().closeTab(id);
    return json(getBrowserEngine().status());
  } catch (error) {
    return fail(error);
  }
}
