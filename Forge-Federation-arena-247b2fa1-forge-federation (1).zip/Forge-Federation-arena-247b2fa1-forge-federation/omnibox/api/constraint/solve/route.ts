import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { constraintProblems } from '@/db/schema';
import { desc } from 'drizzle-orm';
import {
  ConstraintSolver,
  buildProblem,
  type CSProblemSpec,
} from '@/lib/constraint-solver';

// The client sends constraint *specifications* (kind + variable names), never
// functions. Predicates are reconstructed server-side by buildProblem; that is
// the only reason this endpoint is safe to expose.
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => null);
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }

    const { name = 'Untitled problem', description = '', problem } = body as {
      name?: string;
      description?: string;
      problem?: CSProblemSpec;
    };

    if (!problem || !Array.isArray(problem.variables) || problem.variables.length === 0) {
      return NextResponse.json(
        { error: 'problem.variables must be a non-empty array' },
        { status: 400 }
      );
    }
    if (!Array.isArray(problem.constraints)) {
      return NextResponse.json(
        { error: 'problem.constraints must be an array' },
        { status: 400 }
      );
    }
    if (problem.variables.length > 200) {
      return NextResponse.json({ error: 'Too many variables (max 200)' }, { status: 400 });
    }

    let built;
    try {
      built = buildProblem(problem);
    } catch (error) {
      return NextResponse.json(
        { error: error instanceof Error ? error.message : 'Invalid constraint spec' },
        { status: 400 }
      );
    }

    const solver = new ConstraintSolver(built);
    const solution = solver.solve();

    try {
      await db.insert(constraintProblems).values({
        name: String(name).slice(0, 200),
        description: String(description).slice(0, 1000),
        variables: problem.variables,
        constraints: problem.constraints,
        solution: solution?.assignment ?? null,
        solutionMethod: 'backtracking+MRV+LCV+forward-checking',
        solvingTime: solution?.timeMs ?? null,
        isSolved: !!solution,
        solvedAt: solution ? new Date() : null,
      });
    } catch (error) {
      console.error('Failed to persist constraint problem:', error);
    }

    return NextResponse.json({
      success: !!solution,
      solution: solution?.assignment ?? null,
      backtrackCount: solution?.backtrackCount ?? null,
      timeMs: solution?.timeMs ?? null,
    });
  } catch (error) {
    console.error('Solving failed:', error);
    return NextResponse.json({ error: 'Solving failed' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  const raw = Number(new URL(request.url).searchParams.get('limit') ?? 10);
  const limit = Number.isFinite(raw) ? Math.min(50, Math.max(1, raw)) : 10;
  try {
    const problems = await db
      .select()
      .from(constraintProblems)
      .orderBy(desc(constraintProblems.createdAt))
      .limit(limit);
    return NextResponse.json({ problems });
  } catch (error) {
    console.error('Failed to list constraint problems:', error);
    return NextResponse.json({ problems: [] });
  }
}
