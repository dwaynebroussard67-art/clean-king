import { NextResponse } from 'next/server';
import { db } from '@/db';
import { conversations, evolvedSolutions, constraintProblems } from '@/db/schema';
import { sql, eq } from 'drizzle-orm';

export const dynamic = 'force-dynamic';

// Uptime of this server process, not of the machine — the dashboard labels it
// as such. Captured at module load, which is the closest thing to a start time
// a serverless-capable route has.
const STARTED_AT = Date.now();

export async function GET() {
  const zero = {
    totalConversations: 0,
    evolvedSolutions: 0,
    solvedProblems: 0,
    uptimeSeconds: Math.floor((Date.now() - STARTED_AT) / 1000),
  };

  try {
    const count = sql<number>`count(*)::int`;
    const [[conv], [evo], [solved]] = await Promise.all([
      db.select({ count }).from(conversations),
      db.select({ count }).from(evolvedSolutions),
      db
        .select({ count })
        .from(constraintProblems)
        .where(eq(constraintProblems.isSolved, true)),
    ]);

    return NextResponse.json({
      ...zero,
      totalConversations: conv?.count ?? 0,
      evolvedSolutions: evo?.count ?? 0,
      solvedProblems: solved?.count ?? 0,
    });
  } catch (error) {
    console.error('Failed to compute stats:', error);
    // A dashboard that renders zeros beats a dashboard that renders an error
    // wall; the health endpoint is the place that tells you the DB is down.
    return NextResponse.json(zero);
  }
}
