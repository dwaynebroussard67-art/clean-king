import { json, fail } from '@/lib/http.ts';
import { getBridgeStatus, getCockpit, getCockpitStore, getCollective, getHarness } from '@/lib/harness.ts';
import { getBrowserEngine } from '@/lib/browser-engine.ts';
import { BELTS } from '@/lib/belts.ts';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const runtime = getHarness();
    const collective = getCollective();
    const cockpit = getCockpit();
    const store = getCockpitStore();
    const engine = getBrowserEngine();
    await engine.ensure();

    return json({
      packs: runtime.listPacks(),
      gaps: runtime.capabilityGaps(),
      manoeuvres: runtime.flownManoeuvres(),
      learnable: runtime.learnableSkills(),
      collective: {
        size: collective.size(),
        subjects: collective.subjects(),
        quarantined: collective.subjects().filter((s) => collective.isQuarantined(s)).length,
        conflicts: collective.openConflicts().length,
      },
      bridge: getBridgeStatus(),
      browser: engine.status(),
      cockpit: {
        state: cockpit.state(),
        shape: cockpit.getShape(),
        flags: store.getFlags(),
        broadcasts: store.getBroadcasts(),
      },
    });
  } catch (error) {
    return fail(error, 500);
  }
}
