import { json, fail, readBody } from '@/lib/http.ts';
import { admitFact, getCollective } from '@/lib/harness.ts';
import type { FactValue, Predicate, Witness } from '@/collective/types.ts';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const collective = getCollective();
    const url = new URL(request.url);
    const subject = url.searchParams.get('subject');
    const predicate = url.searchParams.get('predicate') as Predicate | null;
    const rawValue = url.searchParams.get('value');

    if (subject && predicate && rawValue !== null) {
      const value = coerceValue(rawValue);
      return json({ ask: collective.ask(subject, predicate, value) });
    }

    return json({
      size: collective.size(),
      subjects: collective.subjects(),
      facts: collective.listFacts(),
      conflicts: collective.openConflicts(),
      quarantined: collective.subjects().filter((s) => collective.isQuarantined(s)),
    });
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const action = String(body.action ?? '');
    const collective = getCollective();

    if (action === 'admit') {
      const verdict = admitFact({
        subject: String(body.subject ?? ''),
        predicate: body.predicate as Predicate,
        value: body.value as FactValue,
        witness: body.witness as Witness,
        stability: body.stability === 'invariant' ? 'invariant' : 'contingent',
      });
      return json({ verdict });
    }

    if (action === 'resolve') {
      const keep = body.keep;
      if (keep !== 'incumbent' && keep !== 'challenger' && keep !== 'neither') {
        return json({ error: 'keep must be incumbent|challenger|neither' }, 400);
      }
      return json(collective.resolveConflict(String(body.subject ?? ''), keep, String(body.ruledBy ?? '')));
    }

    if (action === 'clear') {
      collective.reset();
      return json({ size: collective.size() });
    }

    return json({ error: 'action must be admit|resolve|clear' }, 400);
  } catch (error) {
    return fail(error);
  }
}

function coerceValue(raw: string): FactValue {
  if (raw === 'true') return true;
  if (raw === 'false') return false;
  if (raw !== '' && Number.isFinite(Number(raw))) return Number(raw);
  return raw;
}
