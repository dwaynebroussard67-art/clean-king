import { json, fail, readBody } from '@/lib/http.ts';
import { createCockpitMission, defaultAuthority, listMissions } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    return json({ missions: await listMissions() });
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const goal = typeof body.goal === 'string' ? body.goal.trim() : '';
    if (!goal) return json({ error: 'goal is required' }, 400);
    const authority = body.authority && typeof body.authority === 'object'
      ? body.authority as ReturnType<typeof defaultAuthority>
      : defaultAuthority();
    const mission = await createCockpitMission({
      goal,
      passportId: typeof body.passportId === 'string' ? body.passportId : undefined,
      authority,
    });
    return json({ mission }, 201);
  } catch (error) {
    return fail(error, 500);
  }
}
