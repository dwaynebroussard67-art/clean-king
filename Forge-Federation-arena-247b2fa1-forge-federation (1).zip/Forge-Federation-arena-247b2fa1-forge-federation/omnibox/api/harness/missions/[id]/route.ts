import { json, fail, readBody } from '@/lib/http.ts';
import { armMission, getDoor, getHarness, observeMission } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const mission = await getDoor().store.get(id);
    if (!mission) return json({ error: `mission not found: ${id}` }, 404);
    const runtime = getHarness();
    const [manifest, skills, events] = await Promise.all([
      runtime.capabilityManifest(id),
      runtime.availableSkills(id),
      getDoor().store.listEvents(id),
    ]);
    return json({ mission, manifest, skills, events });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await readBody(request);
    const action = String(body.action ?? '');
    const runtime = getHarness();

    switch (action) {
      case 'bind':
        return json({ mission: (await runtime.bindNeuralink(id)).mission });
      case 'plan':
        return json({ mission: await runtime.beginPlanning(id), plan: await runtime.getPlan(id) });
      case 'start':
        return json({ mission: await armMission(id) });
      case 'cancel':
        return json({
          mission: await runtime.cancelMission(
            id,
            String(body.actorId ?? 'cockpit'),
            String(body.reason ?? 'cancelled from cockpit'),
          ),
        });
      case 'observe':
        return json({
          decision: await observeMission(id, {
            type: (body.type as 'pilot_response') || 'pilot_response',
            source: String(body.source ?? 'cockpit'),
            content: String(body.content ?? ''),
            importance: body.importance === 'low' || body.importance === 'high' ? body.importance : 'normal',
          }),
        });
      case 'approve':
      case 'reject': {
        const toolCallId = String(body.toolCallId ?? '');
        if (!toolCallId) return json({ error: 'toolCallId is required' }, 400);
        const decided = await runtime.decideApproval(id, {
          approvalId: typeof body.approvalId === 'string' ? body.approvalId : crypto.randomUUID(),
          toolCallId,
          decision: action === 'approve' ? 'approve' : 'reject',
          actorId: String(body.actorId ?? 'operator'),
          decidedAt: new Date().toISOString(),
          editedArguments: body.editedArguments && typeof body.editedArguments === 'object'
            ? body.editedArguments as Record<string, unknown>
            : undefined,
        });
        if (action === 'reject') return json({ mission: decided });
        const toolCall = body.toolCall && typeof body.toolCall === 'object'
          ? body.toolCall as {
              id: string;
              missionId: string;
              capabilityId: string;
              arguments: Record<string, unknown>;
              argumentsDigest: string;
              requestedAt: string;
            }
          : null;
        if (!toolCall) {
          return json({
            mission: decided,
            awaitingExecution: true,
            note: 'Approved. Send the original toolCall to execute it.',
          });
        }
        const result = await runtime.executeAuthorized({
          ...toolCall,
          id: toolCallId,
          missionId: id,
        });
        return json({ mission: decided, result });
      }
      default:
        return json({ error: 'action must be bind|plan|start|cancel|observe|approve|reject' }, 400);
    }
  } catch (error) {
    return fail(error);
  }
}
