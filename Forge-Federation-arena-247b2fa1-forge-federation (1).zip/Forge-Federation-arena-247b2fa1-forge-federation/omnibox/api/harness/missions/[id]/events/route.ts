import { json, fail } from '@/lib/http.ts';
import { getDoor } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const events = await getDoor().store.listEvents(id);
    return json({ events });
  } catch (error) {
    return fail(error);
  }
}
