import { json, fail, readBody } from '@/lib/http.ts';
import { getHarness } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const runtime = getHarness();
    const [manifest, skills, gaps] = await Promise.all([
      runtime.capabilityManifest(id),
      runtime.availableSkills(id),
      Promise.resolve(runtime.capabilityGaps()),
    ]);
    return json({ manifest, skills, gaps });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(request: Request, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const body = await readBody(request);
    const capabilityId = String(body.capabilityId ?? '');
    if (!capabilityId) return json({ error: 'capabilityId is required' }, 400);
    const args = body.args && typeof body.args === 'object' && !Array.isArray(body.args)
      ? body.args as Record<string, unknown>
      : {};
    const result = await getHarness().runTool({
      missionId: id,
      capabilityId,
      arguments: args,
      intent: typeof body.intent === 'string' ? body.intent : undefined,
    });
    return json({ result });
  } catch (error) {
    return fail(error);
  }
}
