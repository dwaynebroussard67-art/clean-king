import { json, fail, readBody } from '@/lib/http.ts';
import {
  armMission,
  createCockpitMission,
  DEFAULT_CAPABILITY_IDS,
  getBridgeStatus,
  getHarness,
  listMissions,
} from '@/lib/harness.ts';
import { ALL_CAPABILITY_IDS, authorityFromBelt, BELTS, resolveBelt } from '@/lib/belts.ts';
import { ExecutionRefused } from '@/harness/executor.ts';

export const dynamic = 'force-dynamic';

/**
 * THE GUN BASE.
 *
 * Everything mounted, every named belt, and a way to fire one granted
 * function through the harness gate. Mounting is not granting: a custom
 * belt that names something this plane does not carry is trimmed.
 */
export async function GET() {
  try {
    const runtime = getHarness();
    const capabilities = runtime.listCapabilities().map((capability) => ({
      id: capability.id,
      name: capability.name,
      description: capability.description,
      risk: capability.risk,
      requiresApproval: capability.requiresApproval,
      packId: capability.packId,
      inputSchema: capability.inputSchema,
      grantedOnFullDeck: (DEFAULT_CAPABILITY_IDS as readonly string[]).includes(capability.id),
    }));
    return json({
      packs: runtime.listPacks(),
      capabilities,
      skills: runtime.listSkills(),
      belts: BELTS,
      arsenal: [...ALL_CAPABILITY_IDS],
      gaps: runtime.capabilityGaps(),
      missions: await listMissions(),
      bridge: getBridgeStatus(),
    });
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const capabilityId = String(body.capabilityId ?? '').trim();
    if (!capabilityId) return json({ error: 'capabilityId is required' }, 400);

    const extras = Array.isArray(body.capabilityIds)
      ? body.capabilityIds.filter((id): id is string => typeof id === 'string')
      : [];
    const requestedBelt = typeof body.beltId === 'string' ? body.beltId : 'custom';
    const belt = resolveBelt(
      requestedBelt,
      requestedBelt === 'custom'
        ? (extras.includes(capabilityId) ? extras : [...extras, capabilityId])
        : extras,
    );
    if (!belt.capabilityIds.includes(capabilityId)) {
      return json({
        error: `${capabilityId} is not on the ${belt.name} belt. Load a belt that carries it, or pick it on a custom belt.`,
        code: 'NOT_ON_BELT',
        belt,
      }, 403);
    }

    let missionId = typeof body.missionId === 'string' ? body.missionId : '';
    if (!missionId) {
      const created = await createCockpitMission({
        goal: typeof body.intent === 'string' && body.intent.trim()
          ? body.intent.trim().slice(0, 500)
          : `run ${capabilityId}`,
        authority: authorityFromBelt(belt),
      });
      missionId = created.id;
      await armMission(missionId);
    } else {
      try { await armMission(missionId); } catch { /* already in the air */ }
    }

    const args = body.args && typeof body.args === 'object' && !Array.isArray(body.args)
      ? body.args as Record<string, unknown>
      : {};

    const runtime = getHarness();
    try {
      const { toolCall, authorization } = await runtime.requestTool({
        missionId,
        id: typeof body.toolCallId === 'string' ? body.toolCallId : crypto.randomUUID(),
        capabilityId,
        arguments: args,
        intent: typeof body.intent === 'string' ? body.intent : undefined,
      });
      if (authorization.decision === 'require_approval') {
        return json({
          missionId,
          belt,
          awaitingApproval: true,
          toolCall,
          authorization,
          pending: runtime.pendingApprovalsFor(missionId),
        }, 202);
      }
      if (authorization.decision === 'deny') {
        return json({
          missionId,
          belt,
          error: authorization.reason,
          code: 'EXECUTION_REFUSED',
        }, 403);
      }
      const result = await runtime.executeAuthorized(toolCall);
      return json({ missionId, belt, result });
    } catch (error) {
      if (error instanceof ExecutionRefused) {
        return json({
          missionId,
          belt,
          error: error.message,
          code: error.code,
          pending: runtime.pendingApprovalsFor(missionId),
        }, 403);
      }
      throw error;
    }
  } catch (error) {
    return fail(error);
  }
}
