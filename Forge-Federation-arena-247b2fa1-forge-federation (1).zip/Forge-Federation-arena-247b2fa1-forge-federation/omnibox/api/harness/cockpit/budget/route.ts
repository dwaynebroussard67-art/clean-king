import { json, fail } from '@/lib/http.ts';
import { seatBudget } from '@/harness/seat-budget.ts';

export const dynamic = 'force-dynamic';

/**
 * What each seat has left.
 *
 * The ledger is the only component that knows a seat is nearly out, and
 * before this route existed nothing could display it — so an operator found
 * out a seat was exhausted by watching it refuse. Reading it is free: no
 * dispatch, no provider call, just the in-process meter.
 */
export async function GET() {
  try {
    return json({ seats: seatBudget.snapshot() });
  } catch (error) {
    return fail(error, 500);
  }
}
