import { json, fail, readBody } from '@/lib/http.ts';
import { armMission, createCockpitMission, getCockpit, getHarness } from '@/lib/harness.ts';
import { runRoutingPlan } from '@/lib/pilot-runner.ts';
import { authorityFromBelt, resolveBelt, seatHoldsBelt } from '@/lib/belts.ts';
import { extractProposedActions } from '@/lib/tool-request.ts';

export const dynamic = 'force-dynamic';

/**
 * THE IGNITION SWITCH.
 * Board pilots, then POST a prompt. Each ask is its own flight: seats go
 * flying, the models answer, then the seats sit back down.
 *
 * `beltId` (talk | look | browse | remember | full | custom) is the gun
 * belt for this mission. The local captain is the only seat that sees it.
 */
export async function POST(request: Request) {
  let missionId = '';
  try {
    const body = await readBody(request);
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt) return json({ error: 'prompt is required' }, 400);

    const cockpit = getCockpit();
    if (cockpit.isEmpty()) {
      return json({ error: 'NO_PILOTS: board at least one seat before flying' }, 400);
    }

    const extras = Array.isArray(body.capabilityIds)
      ? body.capabilityIds.filter((id): id is string => typeof id === 'string')
      : [];
    const belt = resolveBelt(typeof body.beltId === 'string' ? body.beltId : 'talk', extras);

    const created = await createCockpitMission({
      goal: prompt.slice(0, 500),
      authority: authorityFromBelt(belt),
    });
    missionId = created.id;
    const mission = await armMission(missionId);
    const plan = cockpit.routingPlan(prompt);

    const supplied = body.page as
      | { url?: unknown; title?: unknown; snapshot?: unknown; text?: unknown; contentHash?: unknown }
      | undefined;
    const page =
      supplied && typeof supplied.contentHash === 'string'
        ? {
            url: String(supplied.url ?? ''),
            title: String(supplied.title ?? ''),
            snapshot: String(supplied.snapshot ?? supplied.text ?? ''),
            contentHash: supplied.contentHash,
          }
        : undefined;

    const runtime = getHarness();
    const mounted = runtime.listCapabilities();
    const catalog = belt.capabilityIds
      .map((id) => mounted.find((capability) => capability.id === id))
      .filter((capability): capability is NonNullable<typeof capability> => Boolean(capability))
      .map((capability) => ({
        id: capability.id,
        description: capability.description,
        risk: capability.risk,
        requiresApproval: capability.requiresApproval,
      }));

    const responses = await runRoutingPlan(plan, missionId, page, catalog);

    const proposed = [];
    for (const response of responses) {
      if (!seatHoldsBelt({ type: response.type })) continue;
      const extracted = extractProposedActions(response.text);
      response.text = extracted.cleaned || response.text;
      for (const proposal of extracted.proposals) {
        proposed.push({
          ...proposal,
          seatIndex: response.seatIndex,
          label: response.label,
        });
      }
    }

    return json({
      mission,
      plan,
      responses,
      belt,
      proposed,
      contentHash: page?.contentHash ?? null,
      cockpit: cockpit.state(),
    });
  } catch (error) {
    return fail(error);
  } finally {
    if (missionId) {
      try {
        getCockpit().missionEnded(missionId);
      } catch {
        /* cockpit may already be idle */
      }
    }
  }
}
