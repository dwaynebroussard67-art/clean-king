import { json, fail, readBody } from '@/lib/http.ts';
import { getCockpit } from '@/lib/harness.ts';
import type { ConversationShape, SeatIndex, ShapeConfig } from '@/harness/cockpit.ts';

export const dynamic = 'force-dynamic';

const SHAPES: ConversationShape[] = ['communal', 'adversarial', 'relay', 'interview', 'sidebar', 'free'];

export async function GET() {
  try {
    return json({ shape: getCockpit().getShape(), state: getCockpit().state() });
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const shape = String(body.shape ?? '') as ConversationShape;
    if (!SHAPES.includes(shape)) return json({ error: `unknown shape: ${shape}` }, 400);

    const cockpit = getCockpit();
    const seated = cockpit.seatedPilots().map((s) => s.seatIndex);
    const config: ShapeConfig = { shape };

    if (shape === 'adversarial') {
      const sides = body.sides as ShapeConfig['sides'] | undefined;
      if (sides) {
        config.sides = sides;
      } else {
        if (seated.length < 2) {
          return json({ error: 'adversarial needs at least two seated pilots' }, 400);
        }
        const mid = Math.ceil(seated.length / 2);
        config.sides = { a: seated.slice(0, mid), b: seated.slice(mid) };
      }
    }

    if (shape === 'relay') {
      config.relayOrder = Array.isArray(body.relayOrder)
        ? body.relayOrder.map(Number) as SeatIndex[]
        : seated;
    }

    if (shape === 'interview') {
      config.interviewer = body.interviewer !== undefined
        ? Number(body.interviewer) as SeatIndex
        : seated[0];
    }

    if (shape === 'sidebar') {
      if (Array.isArray(body.sidebarPair) && body.sidebarPair.length === 2) {
        config.sidebarPair = [Number(body.sidebarPair[0]) as SeatIndex, Number(body.sidebarPair[1]) as SeatIndex];
      } else if (seated.length >= 2) {
        config.sidebarPair = [seated[0]!, seated[1]!];
      }
    }

    cockpit.setShape(config);
    return json({ shape: cockpit.getShape() });
  } catch (error) {
    return fail(error);
  }
}
