import { json, fail, readBody } from '@/lib/http.ts';
import { getCockpit, getCockpitStore } from '@/lib/harness.ts';
import type { PilotDescriptor, SeatIndex } from '@/harness/cockpit.ts';

export const dynamic = 'force-dynamic';

const TYPES: PilotDescriptor['type'][] = [
  'local', 'claude', 'gemini', 'gpt', 'grok', 'mistral', 'deepseek', 'perplexity', 'custom',
];

export async function GET() {
  try {
    const cockpit = getCockpit();
    const store = getCockpitStore();
    return json({
      state: cockpit.state(),
      shape: cockpit.getShape(),
      flags: store.getFlags(),
      broadcasts: store.getBroadcasts(),
    });
  } catch (error) {
    return fail(error, 500);
  }
}

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const action = String(body.action ?? '');
    const cockpit = getCockpit();

    if (action === 'board' || action === 'boardAny') {
      const type = String(body.type ?? '');
      if (!TYPES.includes(type as PilotDescriptor['type'])) {
        return json({ error: `unknown pilot type: ${type}` }, 400);
      }
      const pilot: PilotDescriptor = {
        pilotId: typeof body.pilotId === 'string' ? body.pilotId : `${type}-${Date.now().toString(36)}`,
        type: type as PilotDescriptor['type'],
        label: typeof body.label === 'string' && body.label.trim() ? body.label.trim() : type,
        endpoint: typeof body.endpoint === 'string' ? body.endpoint : undefined,
      };
      if (action === 'board') {
        const seatIndex = Number(body.seatIndex) as SeatIndex;
        return json({ seat: cockpit.board(seatIndex, pilot), seatIndex });
      }
      return json(cockpit.boardAny(pilot));
    }

    if (action === 'eject') {
      return json({ seat: cockpit.eject(Number(body.seatIndex) as SeatIndex) });
    }

    if (action === 'clear') {
      cockpit.clear(Number(body.seatIndex) as SeatIndex);
      return json({ state: cockpit.state() });
    }

    if (action === 'clearAll') {
      for (const index of [0, 1, 2, 3, 4] as SeatIndex[]) cockpit.clear(index);
      getCockpitStore().clear();
      return json({ state: cockpit.state() });
    }

    return json({ error: 'action must be board|boardAny|eject|clear|clearAll' }, 400);
  } catch (error) {
    return fail(error);
  }
}
