import { json, fail, readBody } from '@/lib/http.ts';
import { getCockpit } from '@/lib/harness.ts';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const body = await readBody(request);
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt) return json({ error: 'prompt is required' }, 400);
    return json({ plan: getCockpit().routingPlan(prompt) });
  } catch (error) {
    return fail(error);
  }
}
