import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Presence only — never the secrets themselves. */
function providers() {
  return {
    huggingface: Boolean(process.env.HF_TOKEN),
    anthropic: Boolean(process.env.ANTHROPIC_API_KEY),
    openai: Boolean(process.env.OPENAI_API_KEY),
    gemini: Boolean(process.env.GEMINI_API_KEY),
    ollama: Boolean(process.env.OLLAMA_API_URL),
  };
}

export async function GET() {
  const ready = providers();
  const anyModel = ready.huggingface || ready.anthropic || ready.openai || ready.gemini || ready.ollama;
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, database: "up", providers: ready, anyModel });
  } catch {
    return Response.json({ ok: false, database: "down", providers: ready, anyModel }, { status: 500 });
  }
}
