import { NextRequest, NextResponse } from 'next/server';
import { detectProvider, type ProviderId } from '@/lib/model-provider';

/**
 * One chat door for the Vector browser's AI dock. The dock does not name or
 * pick models — they are interchangeable. Instead the browser auto-links:
 * it looks at the page currently open and sends the matching `provider`
 * here, so whoever you are looking at is whoever answers.
 *
 *   provider: "anthropic" | "openai" | "gemini" | "ollama" | "huggingface"
 *             anything else (or omitted) → "default" → Hugging Face
 *
 * Provider order, per provider:
 *   anthropic  → Anthropic key,  else Hugging Face
 *   openai     → OpenAI key,     else Hugging Face
 *   gemini     → Gemini key,     else Hugging Face
 *   ollama     → Ollama,         else Hugging Face
 *   default    → Hugging Face (free)
 *
 * A missing key is never a crash — the API returns a clear error string so
 * the dock can tell the operator what to configure.
 */

const HF_URL = 'https://router.huggingface.co/v1/chat/completions';
const HF_MODEL = process.env.HF_MODEL || 'deepseek-ai/DeepSeek-V3-0324';

type Turn = { role: 'user' | 'assistant' | 'system'; content: string };

export type AssistantRequest = {
  messages?: Turn[];
  system?: string;
  provider?: string;
  page?: { url?: string; title?: string; snapshot?: string } | null;
};

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json().catch(() => null)) as AssistantRequest | null;
    if (!body || !Array.isArray(body.messages) || body.messages.length === 0) {
      return NextResponse.json({ error: 'messages must be a non-empty array' }, { status: 400 });
    }

    const provider = normalizeProvider(body.provider);
    const system = buildSystem(body.system, body.page);

    try {
      const result = await callModel(provider, system, body.messages);
      return NextResponse.json(result);
    } catch (error) {
      return NextResponse.json(
        {
          error:
            error instanceof Error ? error.message : String(error),
        },
        { status: 502 },
      );
    }
  } catch (error) {
    console.error('assistant route error', error);
    return NextResponse.json(
      { error: 'Failed to reach the model. Try again.' },
      { status: 500 },
    );
  }
}

function normalizeProvider(raw?: string): ProviderId {
  switch (raw) {
    case 'anthropic':
    case 'openai':
    case 'gemini':
    case 'ollama':
    case 'huggingface':
      return raw;
    default:
      return 'default';
  }
}

function buildSystem(extra?: string, page?: AssistantRequest['page']): string {
  const lines = [
    'You are an AI assistant inside a browser. You are helpful, direct, and concise.',
    'Answer the user clearly. If you are looking at the current page, ground claims in its snapshot.',
  ];
  if (extra) lines.push('', extra);
  if (page?.url || page?.snapshot) {
    lines.push(
      '',
      '--- CURRENT PAGE ---',
      `URL: ${page.url ?? ''}`,
      `TITLE: ${page.title ?? ''}`,
      'SNAPSHOT:',
      String(page.snapshot ?? '').slice(0, 12_000),
      '--- END PAGE ---',
    );
  }
  return lines.join('\n');
}

async function callModel(
  provider: ProviderId,
  system: string,
  messages: Turn[],
): Promise<{ content: string; provider: string }> {
  switch (provider) {
    case 'anthropic':
      if (process.env.ANTHROPIC_API_KEY) return callAnthropic(system, messages);
      return callHuggingFace(system, messages);
    case 'openai':
      if (process.env.OPENAI_API_KEY) return callOpenAI(system, messages);
      return callHuggingFace(system, messages);
    case 'gemini':
      if (process.env.GEMINI_API_KEY) return callGemini(system, messages);
      return callHuggingFace(system, messages);
    case 'ollama':
      return callOllama(system, messages);
    default:
      return callHuggingFace(system, messages);
  }
}

async function callOllama(system: string, messages: Turn[]) {
  const endpoint = (process.env.OLLAMA_API_URL || 'http://127.0.0.1:11434').replace(/\/$/, '');
  const model = process.env.OLLAMA_MODEL || 'qwen2.5';
  try {
    const res = await fetch(`${endpoint}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        stream: false,
        messages: [{ role: 'system', content: system }, ...messages],
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) throw new Error(`ollama ${res.status}`);
    const data = (await res.json()) as { message?: { content?: string } };
    const text = data.message?.content ?? '';
    if (!text) throw new Error('ollama returned an empty message');
    return { content: text, provider: `local (${model})` };
  } catch (error) {
    if (process.env.HF_TOKEN) return callHuggingFace(system, messages);
    throw new Error(
      `No local model reachable at ${endpoint} (${error instanceof Error ? error.message : error}). ` +
        'Start Ollama, or set HF_TOKEN for the fallback.',
    );
  }
}

async function callAnthropic(system: string, messages: Turn[]) {
  const model = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514';
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY as string,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      system,
      messages: messages.filter((m) => m.role !== 'system').map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: m.content,
      })),
    }),
    signal: AbortSignal.timeout(60_000),
  });
  const data = (await res.json()) as {
    content?: Array<{ text?: string }>;
    error?: { message?: string };
  };
  if (!res.ok) throw new Error(data.error?.message || `anthropic ${res.status}`);
  const text = (data.content ?? []).map((b) => b.text ?? '').join('');
  return { content: text, provider: 'anthropic' };
}

async function callOpenAI(system: string, messages: Turn[]) {
  const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'system', content: system }, ...messages],
    }),
    signal: AbortSignal.timeout(60_000),
  });
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    error?: { message?: string };
  };
  if (!res.ok) throw new Error(data.error?.message || `openai ${res.status}`);
  const text = data.choices?.[0]?.message?.content ?? '';
  return { content: text, provider: 'openai' };
}

async function callGemini(system: string, messages: Turn[]) {
  const model = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: messages.map((m) => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        })),
      }),
      signal: AbortSignal.timeout(60_000),
    },
  );
  const data = (await res.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    error?: { message?: string };
  };
  if (!res.ok) throw new Error(data.error?.message || `gemini ${res.status}`);
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? '').join('') ?? '';
  return { content: text, provider: 'gemini' };
}

async function callHuggingFace(system: string, messages: Turn[]) {
  if (!process.env.HF_TOKEN) {
    throw new Error(
      'No provider key configured. The browser tried to auto-link to the model on this page, but the server has no key for it (and no HF_TOKEN fallback).',
    );
  }
  const res = await fetch(HF_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.HF_TOKEN}`,
    },
    body: JSON.stringify({
      model: HF_MODEL,
      messages: [{ role: 'system', content: system }, ...messages],
      temperature: 0.7,
      max_tokens: 2048,
    }),
    signal: AbortSignal.timeout(90_000),
  });
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    error?: { message?: string } | string;
  };
  if (!res.ok) {
    const message = typeof data.error === 'string' ? data.error : data.error?.message;
    throw new Error(message || `huggingface ${res.status}`);
  }
  return { content: data.choices?.[0]?.message?.content ?? '', provider: 'huggingface' };
}

/** Imported so the auto-link label stays consistent across client + server. */
export { detectProvider };
