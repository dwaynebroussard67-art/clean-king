import { NextRequest, NextResponse } from 'next/server';
import { NeuroSymbolicEngine } from '@/lib/neuro-symbolic';
import { db } from '@/db';
import { knowledgeBase } from "@/db/schema";

interface IncomingFact {
  key: string;
  value: unknown;
  confidence?: number;
}

/**
 * Stateless forward-chaining inference.
 *
 * A fresh engine per request is deliberate: a process-global knowledge base
 * would leak facts between callers and make the same input produce different
 * output depending on who called first. The client owns the fact set; the
 * server owns the rules.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => null);
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }

    const incoming = (body as { facts?: IncomingFact[] }).facts;
    if (!Array.isArray(incoming)) {
      return NextResponse.json({ error: 'facts must be an array' }, { status: 400 });
    }
    if (incoming.length > 500) {
      return NextResponse.json({ error: 'Too many facts (max 500)' }, { status: 400 });
    }

    const engine = new NeuroSymbolicEngine();
    for (const fact of incoming) {
      if (!fact || typeof fact.key !== 'string' || !fact.key.trim()) continue;
      const confidence =
        typeof fact.confidence === 'number' && Number.isFinite(fact.confidence)
          ? Math.min(1, Math.max(0, fact.confidence))
          : 1;
      engine.addFact(fact.key.trim(), fact.value, confidence, 'user');
    }

    const result = engine.forwardChain();
    // Contradictions are resolved by confidence, then the caller is handed the
    // settled set — not the raw derivation, which can contain both X and !X.
    engine.resolveConflicts();

    const facts = engine.getAllFacts();
    const derived = facts.filter((f) => f.source !== 'user');

    // Persist only derived knowledge, and only best-effort: inference must
    // still answer when the database is unavailable.
    if (derived.length > 0) {
      try {
        await db.insert(knowledgeBase).values(
          derived.slice(0, 50).map((f) => ({
            concept: f.key,
            category: 'fact',
            symbolicRepresentation: { value: f.value, derivedFrom: f.derivedFrom ?? [] },
            confidence: f.confidence,
            source: 'forward-chaining',
          }))
        );
      } catch (error) {
        console.error('Failed to persist derived facts:', error);
      }
    }

    return NextResponse.json({
      facts,
      derivedCount: derived.length,
      rulesApplied: result.rulesApplied,
      confidence: result.confidence,
    });
  } catch (error) {
    console.error('Inference failed:', error);
    return NextResponse.json({ error: 'Inference failed' }, { status: 500 });
  }
}
