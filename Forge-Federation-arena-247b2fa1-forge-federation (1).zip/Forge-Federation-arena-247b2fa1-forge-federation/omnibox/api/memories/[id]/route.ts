import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories, memoryEvents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { contentDigest, evaluateAdjudication, assess } from "@/lib/epistemic";

const WRITABLE = [
  "type",
  "title",
  "content",
  "confidence",
  "tags",
  "metadata",
  "pinned",
] as const;

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const [row] = await db.select().from(memories).where(eq(memories.id, id));
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ ...row, epistemic: assess(row) });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const [before] = await db.select().from(memories).where(eq(memories.id, id));
  if (!before) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  for (const key of WRITABLE) {
    if (key in body) patch[key] = (body as Record<string, unknown>)[key];
  }

  const events: Array<typeof memoryEvents.$inferInsert> = [];
  const base = { memoryId: id, passportId: before.passportId };
  const contentChanged =
    typeof patch.content === "string" && patch.content !== before.content;

  if (contentChanged) {
    events.push({ ...base, kind: "edited", note: "content changed" });
    if (before.adjudicatedAt) {
      patch.adjudicatedAt = null;
      patch.adjudicatedDigest = null;
      events.push({
        ...base,
        kind: "adjudication_revoked",
        note: "content edited after adjudication",
      });
    }
  }

  const confidenceChanged =
    typeof patch.confidence === "number" && patch.confidence !== before.confidence;
  if (confidenceChanged) {
    events.push({
      ...base,
      kind: "confidence_changed",
      fromConfidence: before.confidence,
      toConfidence: patch.confidence as number,
      note:
        typeof (body as Record<string, unknown>).note === "string"
          ? ((body as Record<string, unknown>).note as string).slice(0, 500)
          : null,
    });
  }

  const adjudicationRequest = (body as Record<string, unknown>).adjudication;
  if (adjudicationRequest !== undefined) {
    if (!adjudicationRequest || typeof adjudicationRequest !== "object") {
      return NextResponse.json(
        { error: "adjudication must be an object with evidence[] and a note" },
        { status: 400 }
      );
    }

    const verdict = evaluateAdjudication(adjudicationRequest as Record<string, unknown>);
    if (!verdict.ok) {
      return NextResponse.json({ error: verdict.reason }, { status: 400 });
    }

    const finalContent =
      typeof patch.content === "string" ? patch.content : before.content;

    patch.adjudicatedAt = new Date();
    patch.adjudicatedDigest = contentDigest(finalContent);
    patch.origin = before.origin === "imported" ? "imported" : "local";

    const metadata = {
      ...((patch.metadata as Record<string, unknown>) ??
        (before.metadata as Record<string, unknown>) ??
        {}),
    };
    const existing = Array.isArray(metadata.evidence)
      ? (metadata.evidence as string[])
      : metadata.evidence
        ? [String(metadata.evidence)]
        : [];
    metadata.evidence = Array.from(new Set([...existing, ...verdict.evidence]));
    patch.metadata = metadata;

    events.push({
      ...base,
      kind: "adjudicated",
      fromConfidence: before.confidence,
      toConfidence:
        typeof patch.confidence === "number" ? patch.confidence : before.confidence,
      evidence: verdict.evidence,
      note: verdict.note,
    });
  }

  // The memory mutation and its audit trail are one transaction. Previously an
  // event-write failure was caught after the memory had already changed,
  // leaving an epistemic transition with no durable audit record.
  const row = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(memories)
      .set(patch)
      .where(eq(memories.id, id))
      .returning();

    if (!updated) throw new Error("Memory disappeared during update");
    if (events.length > 0) await tx.insert(memoryEvents).values(events);
    return updated;
  });

  return NextResponse.json({ ...row, epistemic: assess(row) });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  // Delete and its surviving audit record are one transaction. If the audit
  // insert fails, the deletion rolls back instead of silently losing history.
  const row = await db.transaction(async (tx) => {
    const [deleted] = await tx.delete(memories).where(eq(memories.id, id)).returning();
    if (!deleted) return null;

    await tx.insert(memoryEvents).values({
      memoryId: id,
      passportId: deleted.passportId,
      kind: "deleted",
      fromConfidence: deleted.confidence,
      note: deleted.title,
    });
    return deleted;
  });

  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ ok: true, id });
}
