import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memoryEvents } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

/**
 * The audit trail for one memory, oldest first.
 *
 * Read-only by design: there is no POST here. Events are appended by the write
 * paths that cause them, so a caller cannot manufacture a history — which is
 * the only reason the history is worth reading.
 *
 * Survives deletion of the memory itself. A trail that vanished with its
 * subject would be unable to answer the one question it exists for: what was
 * here, and what happened to it.
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const rows = await db
    .select()
    .from(memoryEvents)
    .where(eq(memoryEvents.memoryId, id))
    .orderBy(asc(memoryEvents.createdAt));

  return NextResponse.json(rows);
}
