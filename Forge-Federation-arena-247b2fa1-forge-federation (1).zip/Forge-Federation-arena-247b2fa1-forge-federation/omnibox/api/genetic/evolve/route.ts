import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { evolvedSolutions } from '@/db/schema';
import { desc } from 'drizzle-orm';
import { GeneticProgramming } from '@/lib/genetic-programming';
import { adaptiveSystem } from '@/lib/self-adaptive';

interface TestCase {
  input: Record<string, number>;
  output: number;
}

// Hard ceilings. The evolution loop runs inline in the request, so an
// unbounded populationSize x maxGenerations from the client is a trivial way
// to hang the server.
const MAX_POPULATION = 400;
const MAX_GENERATIONS = 200;
const MAX_TEST_CASES = 200;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => null);
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
    }

    const {
      problemType = 'function-approximation',
      problemDescription = '',
      targetFunction,
      config = {},
    } = body as {
      problemType?: string;
      problemDescription?: string;
      targetFunction?: { testCases?: TestCase[] };
      config?: Record<string, number>;
    };

    const testCases = (targetFunction?.testCases ?? []).filter(
      (t) => t && typeof t === 'object' && t.input && Number.isFinite(t.output)
    );

    if (testCases.length === 0) {
      return NextResponse.json(
        { error: 'targetFunction.testCases must contain at least one {input, output} pair' },
        { status: 400 }
      );
    }
    if (testCases.length > MAX_TEST_CASES) {
      return NextResponse.json(
        { error: `Too many test cases (max ${MAX_TEST_CASES})` },
        { status: 400 }
      );
    }

    const populationSize = clamp(config.populationSize ?? 100, 10, MAX_POPULATION);
    const maxGenerations = clamp(config.maxGenerations ?? 50, 1, MAX_GENERATIONS);

    const gp = new GeneticProgramming({
      populationSize,
      maxGenerations,
      mutationRate: clamp(config.mutationRate ?? 0.15, 0, 1),
      crossoverRate: clamp(config.crossoverRate ?? 0.7, 0, 1),
    });

    // Fitness: 1 / (1 + mean squared error), so a perfect program scores 1.0
    // and a diverging one decays smoothly toward 0 instead of returning NaN.
    const fitnessFunction = (
      evaluate: (vars: Record<string, number>) => number
    ): number => {
      let squaredError = 0;
      for (const testCase of testCases) {
        const predicted = evaluate(testCase.input);
        if (!Number.isFinite(predicted)) return 0;
        const diff = predicted - testCase.output;
        squaredError += diff * diff;
      }
      const mse = squaredError / testCases.length;
      return 1 / (1 + mse);
    };

    const startedAt = Date.now();
    const history: Array<{ generation: number; fitness: number; expression: string }> = [];

    gp.initializePopulation();
    for (let generation = 0; generation < maxGenerations; generation++) {
      gp.evolveGeneration(fitnessFunction);
      const best = gp.getBest();
      if (!best) break;
      history.push({
        generation: gp.getGeneration(),
        fitness: best.fitness,
        expression: gp.geneToString(best.genome),
      });
      // Converged: no point burning the remaining generations.
      if (best.fitness > 0.999) break;
    }

    const best = gp.getBest();
    if (!best) {
      return NextResponse.json({ error: 'Evolution produced no individuals' }, { status: 500 });
    }

    const expression = gp.geneToString(best.genome);
    const elapsedMs = Date.now() - startedAt;
    adaptiveSystem.addMetric({
      name: 'genetic_evolution_ms',
      value: elapsedMs,
      timestamp: Date.now(),
    });

    let saved: { id: number } | undefined;
    try {
      [saved] = await db
        .insert(evolvedSolutions)
        .values({
          problemType,
          problemDescription: problemDescription || `Evolved ${problemType}`,
          generation: gp.getGeneration(),
          fitness: best.fitness,
          genome: best.genome,
          metadata: { expression, populationSize, maxGenerations, elapsedMs },
        })
        .returning({ id: evolvedSolutions.id });
    } catch (error) {
      // Persistence is a convenience here; a DB outage should not throw away a
      // result the caller already paid CPU time for.
      console.error('Failed to persist evolved solution:', error);
    }

    return NextResponse.json({
      success: true,
      solution: {
        id: saved?.id ?? null,
        generation: gp.getGeneration(),
        fitness: best.fitness,
        expression,
        genome: best.genome,
        elapsedMs,
      },
      history,
    });
  } catch (error) {
    console.error('Evolution failed:', error);
    return NextResponse.json({ error: 'Evolution failed' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  const limit = clamp(Number(new URL(request.url).searchParams.get('limit') ?? 10), 1, 50);
  try {
    const solutions = await db
      .select()
      .from(evolvedSolutions)
      .orderBy(desc(evolvedSolutions.createdAt))
      .limit(limit);
    return NextResponse.json({ solutions });
  } catch (error) {
    console.error('Failed to list evolved solutions:', error);
    return NextResponse.json({ solutions: [] });
  }
}

function clamp(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}
