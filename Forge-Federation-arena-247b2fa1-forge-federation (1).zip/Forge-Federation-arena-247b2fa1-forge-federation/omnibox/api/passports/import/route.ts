import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports, memories, memoryEvents } from "@/db/schema";
import { MEMORY_TYPES } from "@/lib/types";

const KNOWN_TYPES = new Set<string>(MEMORY_TYPES.map((t) => t.value));

/**
 * Import a .mpx bundle produced by /api/passports/[id]/export.
 *
 * Ids in the file are deliberately discarded. A .mpx is a portable copy, not a
 * claim on a row: re-importing an export into the same database has to produce
 * a second passport, not overwrite the original or fail on a primary key.
 *
 * Epistemic status is discarded too. Every imported memory arrives as
 * origin='imported' with no adjudication, whatever the file claims.
 */
export async function POST(req: NextRequest) {
  const data = await req.json().catch(() => null);

  if (!data || typeof data !== "object") {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  if (data.format !== "memory-passport-exchange") {
    return NextResponse.json(
      { error: "Not a Memory Passport export (missing format identifier)." },
      { status: 400 }
    );
  }

  const identity = data.passport?.identity ?? {};
  const preferences = data.passport?.preferences ?? {};
  const name = typeof identity.name === "string" && identity.name.trim()
    ? identity.name.trim().slice(0, 255)
    : "Imported Passport";

  const incoming = Array.isArray(data.memories) ? data.memories : [];
  const sourceLabel =
    typeof data.passport?.id === "string"
      ? `mpx:${data.passport.id}`
      : "mpx:unknown-source";
  const exportedAt =
    typeof data.exportedAt === "string" ? data.exportedAt : "at an unstated time";

  const result = await db.transaction(async (tx) => {
    const [passport] = await tx
      .insert(passports)
      .values({
        name,
        preferredName: identity.preferredName ?? null,
        timezone: identity.timezone ?? "UTC",
        language: identity.language ?? "English",
        responseStyle: preferences.responseStyle ?? "balanced",
        verbosity: preferences.verbosity ?? "medium",
        codingLanguages: Array.isArray(preferences.codingLanguages)
          ? preferences.codingLanguages
          : [],
      })
      .returning();

    const rows = incoming
      .filter((m: unknown) => m && typeof m === "object")
      .map((m: Record<string, unknown>) => ({
        passportId: passport.id,
        type:
          typeof m.type === "string" && (KNOWN_TYPES.has(m.type) || m.type.length <= 50)
            ? m.type
            : "knowledge",
        title: typeof m.title === "string" && m.title.trim()
          ? m.title.slice(0, 500)
          : "Untitled",
        content: typeof m.content === "string" ? m.content : "",
        confidence:
          typeof m.confidence === "number" && Number.isFinite(m.confidence)
            ? Math.min(1, Math.max(0, m.confidence))
            : 1,
        tags: Array.isArray(m.tags) ? (m.tags as string[]) : [],
        metadata:
          m.metadata && typeof m.metadata === "object"
            ? (m.metadata as Record<string, unknown>)
            : {},
        pinned: m.pinned === true,
        origin: "imported" as const,
        adjudicatedAt: null,
        adjudicatedDigest: null,
      }));

    let imported: Array<typeof memories.$inferSelect> = [];
    if (rows.length > 0) {
      imported = await tx.insert(memories).values(rows).returning();
      await tx.insert(memoryEvents).values(
        imported.map((row) => ({
          memoryId: row.id,
          passportId: passport.id,
          kind: "imported",
          toConfidence: row.confidence,
          note: `asserted by ${sourceLabel}, exported ${exportedAt} — not adjudicated here`,
        }))
      );
    }

    return { passport, imported };
  });

  return NextResponse.json(
    {
      passport: result.passport,
      importedMemories: result.imported.length,
      epistemicNote:
        "Imported memories carry the confidence their author asserted. None are adjudicated here until checked locally against evidence.",
    },
    { status: 201 }
  );
}
