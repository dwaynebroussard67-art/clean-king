import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports } from "@/db/schema";
import { desc, isNull, isNotNull } from "drizzle-orm";

/**
 * List passports.
 *
 * Default: live passports only.
 * ?view=hidden: soft-deleted ones, so a person can bring them back.
 */
export async function GET(req: NextRequest) {
  const hidden = new URL(req.url).searchParams.get("view") === "hidden";
  const rows = await db
    .select()
    .from(passports)
    .where(hidden ? isNotNull(passports.deletedAt) : isNull(passports.deletedAt))
    .orderBy(desc(hidden ? passports.updatedAt : passports.createdAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const [row] = await db
    .insert(passports)
    .values({
      name: body.name || "Unnamed",
      preferredName: body.preferredName || null,
      timezone: body.timezone || "UTC",
      language: body.language || "English",
      responseStyle: body.responseStyle || "balanced",
      verbosity: body.verbosity || "medium",
      codingLanguages: body.codingLanguages || [],
    })
    .returning();
  return NextResponse.json(row, { status: 201 });
}
