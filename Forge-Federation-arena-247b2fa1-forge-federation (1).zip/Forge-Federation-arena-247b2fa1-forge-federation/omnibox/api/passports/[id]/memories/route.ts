import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories, memoryEvents } from "@/db/schema";
import { eq, desc, and, ilike, or } from "drizzle-orm";
import { assess } from "@/lib/epistemic";
import { findLivePassport, literalSearch } from "@/lib/passport-access";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const live = await findLivePassport(id);
  if (!live) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const search = url.searchParams.get("search");

  const conditions = [eq(memories.passportId, id)];

  if (type && type !== "all") {
    conditions.push(eq(memories.type, type));
  }

  let rows;
  if (search) {
    const needle = `%${literalSearch(search)}%`;
    rows = await db
      .select()
      .from(memories)
      .where(
        and(
          ...conditions,
          or(
            ilike(memories.title, needle),
            ilike(memories.content, needle)
          )
        )
      )
      .orderBy(desc(memories.pinned), desc(memories.updatedAt));
  } else {
    rows = await db
      .select()
      .from(memories)
      .where(and(...conditions))
      .orderBy(desc(memories.pinned), desc(memories.updatedAt));
  }

  return NextResponse.json(rows.map((row) => ({ ...row, epistemic: assess(row) })));
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const live = await findLivePassport(id);
  if (!live) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const row = await db.transaction(async (tx) => {
    const [created] = await tx
      .insert(memories)
      .values({
        passportId: id,
        type: body.type || "knowledge",
        title: body.title || "Untitled",
        content: body.content || "",
        confidence: body.confidence ?? 1.0,
        tags: body.tags || [],
        metadata: body.metadata || {},
        pinned: body.pinned ?? false,
        origin: "local",
      })
      .returning();

    await tx.insert(memoryEvents).values({
      memoryId: created.id,
      passportId: id,
      kind: "created",
      toConfidence: created.confidence,
      note: created.title,
    });
    return created;
  });

  return NextResponse.json({ ...row, epistemic: assess(row) }, { status: 201 });
}
