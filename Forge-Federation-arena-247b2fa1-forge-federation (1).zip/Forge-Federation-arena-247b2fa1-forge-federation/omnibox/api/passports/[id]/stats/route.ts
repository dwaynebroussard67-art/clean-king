import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { findLivePassport } from "@/lib/passport-access";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const live = await findLivePassport(id);
  if (!live) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(memories)
    .where(eq(memories.passportId, id));

  const typeBreakdown = await db
    .select({
      type: memories.type,
      count: sql<number>`count(*)::int`,
    })
    .from(memories)
    .where(eq(memories.passportId, id))
    .groupBy(memories.type);

  const [pinnedCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(memories)
    .where(
      sql`${memories.passportId} = ${id} AND ${memories.pinned} = true`
    );

  return NextResponse.json({
    totalMemories: countResult?.count || 0,
    pinnedMemories: pinnedCount?.count || 0,
    byType: Object.fromEntries(
      typeBreakdown.map((r) => [r.type, r.count])
    ),
  });
}
