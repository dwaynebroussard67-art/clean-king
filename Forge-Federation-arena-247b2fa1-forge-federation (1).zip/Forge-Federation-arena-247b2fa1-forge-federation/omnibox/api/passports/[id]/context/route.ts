import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { memories } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { compileBootBlock } from "@/lib/boot-block";
import { findLivePassport } from "@/lib/passport-access";
import type { Memory, Passport } from "@/lib/types";

/**
 * The boot block: paste-at-the-top context for a fresh session.
 *
 *   GET /api/passports/:id/context                 -> text/markdown
 *   GET /api/passports/:id/context?format=json     -> block + what was omitted
 *   &budget=1200  &minConfidence=0.9
 *
 * Markdown is the default because the consumer is usually a human pasting into
 * a chat box, and a JSON envelope would just be something to strip.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const url = new URL(req.url);

  const passport = await findLivePassport(id);
  if (!passport) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const rows = await db
    .select()
    .from(memories)
    .where(eq(memories.passportId, id))
    .orderBy(desc(memories.pinned), desc(memories.updatedAt));

  // Number(null) is 0, so an absent parameter must be checked before it is
  // coerced — otherwise "no minConfidence given" silently means "accept
  // everything", which is exactly the claim this endpoint must not make.
  const numeric = (key: string, fallback: number) => {
    const raw = url.searchParams.get(key);
    if (raw === null || raw.trim() === "") return fallback;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed : fallback;
  };

  const result = compileBootBlock(
    passport as unknown as Passport,
    rows as unknown as Memory[],
    {
      budgetTokens: numeric("budget", 2000),
      minConfidence: numeric("minConfidence", 0.7),
      includePreamble: url.searchParams.get("preamble") !== "false",
      // Unrecognised values fall back to the permissive default rather than
      // being treated as a high floor — a typo must not silently produce an
      // empty block that reads like "there is nothing settled here".
      minStatus:
        url.searchParams.get("minStatus") === "adjudicated"
          ? "adjudicated"
          : url.searchParams.get("minStatus") === "evidenced"
            ? "evidenced"
            : "asserted",
    }
  );

  if (url.searchParams.get("format") === "json") {
    return NextResponse.json(result);
  }

  return new NextResponse(result.text, {
    headers: {
      "Content-Type": "text/markdown; charset=utf-8",
      "Cache-Control": "no-store",
      // Cheap machine-readable summary for callers that only want the text.
      "X-Boot-Block-Tokens": String(result.estimatedTokens),
      "X-Boot-Block-Included": String(result.includedCount),
      "X-Boot-Block-Omitted": String(result.omittedCount),
    },
  });
}
