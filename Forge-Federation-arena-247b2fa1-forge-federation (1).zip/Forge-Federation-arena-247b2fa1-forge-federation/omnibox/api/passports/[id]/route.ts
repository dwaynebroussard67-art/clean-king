import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passports } from "@/db/schema";
import { eq } from "drizzle-orm";
import { findPassport } from "@/lib/passport-access";

const WRITABLE = [
  "name",
  "preferredName",
  "timezone",
  "language",
  "responseStyle",
  "verbosity",
  "codingLanguages",
] as const;

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const row = await findPassport(id);
  // A soft-deleted passport reads as absent. Returning it here would make
  // "deleted" mean nothing to every consumer that fetches by id.
  if (!row || row.deletedAt) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json(row);
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const existing = await findPassport(id);
  if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const restore = (body as { restore?: unknown }).restore === true;

  // A hidden passport can only be brought back. Anything else would let
  // "deleted" become just another editable field.
  if (existing.deletedAt && !restore) {
    return NextResponse.json(
      { error: "Passport is hidden. PATCH { restore: true } to bring it back." },
      { status: 409 }
    );
  }

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (restore) {
    patch.deletedAt = null;
    patch.deletedBy = null;
  }
  if (!existing.deletedAt || restore) {
    for (const key of WRITABLE) {
      if (key in (body as Record<string, unknown>)) {
        patch[key] = (body as Record<string, unknown>)[key];
      }
    }
  }

  const [row] = await db
    .update(passports)
    .set(patch)
    .where(eq(passports.id, id))
    .returning();
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(row);
}

/**
 * Soft delete.
 *
 * The passport is hidden; everything under it is preserved — memories keep
 * their rows, and the append-only event trail keeps its history. Restore with
 * PATCH { restore: true }.
 *
 * This is deliberately NOT erasure, and the response says so.
 */
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const actor = req.headers.get("x-actor")?.slice(0, 100) || "api";

  const [row] = await db
    .update(passports)
    .set({ deletedAt: new Date(), deletedBy: actor, updatedAt: new Date() })
    .where(eq(passports.id, id))
    .returning();

  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });

  return NextResponse.json({
    ok: true,
    id,
    deleted: "soft",
    note: "Passport hidden; memories and their audit trail are preserved. PATCH { restore: true } to undo. This is not erasure.",
  });
}
