/**
 * anchor-bridge.test.mjs
 *
 * Tests the keepalive rule, engine fallback, refusal contract, and flight
 * recorder integration. All browser and engine calls are mocked — this
 * tests the BRIDGE LOGIC, not the engine itself.
 *
 * The engine (forge-reanchor-v8) has its own gauntlet. Here we verify:
 *   1. Keepalive fires correctly on single-match stable ids
 *   2. Keepalive stays out of multi-match and no-match cases
 *   3. Engine is called when keepalive misses
 *   4. Provisional policy is honoured
 *   5. Flight recorder gets an event for every outcome
 *   6. click() and type() refuse cleanly when resolution fails
 *   7. Engine offline falls back to cssPath or refuses
 */

import assert from 'node:assert/strict'
import { AnchorBridge } from './anchor-bridge.ts'

let passed = 0
let failed = 0
const failures = []

function test(name, fn) {
  try {
    fn()
    passed++
  } catch (err) {
    failed++
    failures.push({ name, message: err.message })
  }
}

async function atest(name, fn) {
  try {
    await fn()
    passed++
  } catch (err) {
    failed++
    failures.push({ name, message: err.message })
  }
}

// ── Mock factory ──────────────────────────────────────────────────────────

function makeBridge(responses = {}) {
  return {
    calls: [],
    invoke(tool, args) {
      this.calls.push({ tool, args })
      if (responses[tool] !== undefined) {
        const r = responses[tool]
        return Promise.resolve(typeof r === 'function' ? r(args) : r)
      }
      return Promise.resolve(null)
    }
  }
}

function makeEngine(resolveWith) {
  return {
    version: 'v8.0.0-test',
    resolve: (_anchor, _bridge) => Promise.resolve(resolveWith)
  }
}

function makeRecorder() {
  return { events: [], record(e) { this.events.push(e) } }
}

const GOOD_ELEMENT = {
  tag: 'button',
  id: 'submit',
  testId: 'submit-btn',
  text: 'Submit',
  role: 'button',
}

const GOOD_ANCHOR = {
  testId: 'submit-btn',
  text: 'Submit',
  role: 'button',
  tag: 'button',
}

function reset() {
  AnchorBridge.setEngine(null)
  AnchorBridge.setBridge(null)
  AnchorBridge.setRecorder(null)
  AnchorBridge.setMissionId(null)
  AnchorBridge.setProvisionalPolicy('refuse')
}

// ── Baseline 1-9 ──────────────────────────────────────────────────────────

await atest('1. keepalive matches single testId, returns hit', async () => {
  reset()
  const bridge = makeBridge({
    'browser.query_all': [GOOD_ELEMENT],
  })
  AnchorBridge.setBridge(bridge)

  const result = await AnchorBridge.keepalive(GOOD_ANCHOR)
  assert.ok(result, 'keepalive returned null on a single match')
  assert.equal(result.element.resolvedSelector, '[data-testid="submit-btn"]')
})

await atest('2. keepalive returns null on zero matches', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  AnchorBridge.setBridge(bridge)
  const result = await AnchorBridge.keepalive(GOOD_ANCHOR)
  assert.equal(result, null)
})

await atest('3. keepalive returns null on multi-match', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [GOOD_ELEMENT, GOOD_ELEMENT] })
  AnchorBridge.setBridge(bridge)
  const result = await AnchorBridge.keepalive(GOOD_ANCHOR)
  assert.equal(result, null, 'keepalive should stay lost when 2+ elements match')
})

await atest('4. resolve returns hit via keepalive when single match', async () => {
  reset()
  const rec = makeRecorder()
  const bridge = makeBridge({ 'browser.query_all': [GOOD_ELEMENT] })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setRecorder(rec)

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'hit')
  assert.equal(result.method, 'keepalive')
})

await atest('5. engine is called when keepalive misses', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({
    status: 'hit',
    element: { resolvedSelector: '#submit', snapshot: GOOD_ELEMENT },
    method: 'full-score',
  })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'hit')
  assert.equal(result.method, 'full-score')
})

await atest('6. provisional is refused by default', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({
    status: 'provisional',
    element: { resolvedSelector: '#submit', snapshot: GOOD_ELEMENT },
    confidence: 0.55,
  })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)
  AnchorBridge.setProvisionalPolicy('refuse')

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'miss')
  assert.equal(result.reason, 'PROVISIONAL_REFUSED')
})

await atest('7. provisional proceeds when policy is proceed', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({
    status: 'provisional',
    element: { resolvedSelector: '#submit', snapshot: GOOD_ELEMENT },
    confidence: 0.55,
  })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)
  AnchorBridge.setProvisionalPolicy('proceed')

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'provisional')
})

await atest('8. flight recorder gets an event for every resolve', async () => {
  reset()
  const rec = makeRecorder()
  const bridge = makeBridge({ 'browser.query_all': [GOOD_ELEMENT] })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setRecorder(rec)
  AnchorBridge.setMissionId('m-test-1')

  await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(rec.events.length, 1)
  assert.equal(rec.events[0].missionId, 'm-test-1')
  assert.equal(rec.events[0].type, 'anchor_hit')
})

await atest('9. miss event emitted when bridge is offline', async () => {
  reset()
  const rec = makeRecorder()
  AnchorBridge.setRecorder(rec)
  // bridge is null

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'miss')
  assert.equal(result.reason, 'BRIDGE_OFFLINE')
  assert.equal(rec.events.length, 1)
  assert.equal(rec.events[0].type, 'anchor_miss')
})

// ── Attack probes ─────────────────────────────────────────────────────────

await atest('P1. click() refuses and returns refused:true when resolution fails', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({ status: 'miss', reason: 'NO_CANDIDATES' })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)

  const result = await AnchorBridge.click(GOOD_ANCHOR)
  assert.ok('refused' in result, `click() did not refuse on miss — got ${JSON.stringify(result)}`)
  assert.ok(result.refused)
})

await atest('P2. click() never calls browser.click when resolution returns miss', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({ status: 'miss', reason: 'AMBIGUOUS' })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)

  await AnchorBridge.click(GOOD_ANCHOR)
  const clickCalls = bridge.calls.filter(c => c.tool === 'browser.click')
  assert.equal(clickCalls.length, 0, 'browser.click was invoked despite a miss')
})

await atest('P3. type() refuses cleanly on resolution miss', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({ status: 'miss', reason: 'ENTROPY_LOW' })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)

  const result = await AnchorBridge.type(GOOD_ANCHOR, 'hello')
  assert.ok('refused' in result, 'type() did not refuse on miss')
})

await atest('P4. engine offline with cssPath returns provisional, not crash', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  AnchorBridge.setBridge(bridge)
  // engine is null

  const anchor = { ...GOOD_ANCHOR, cssPath: '#submit' }
  const result = await AnchorBridge.resolve(anchor, 'browser.click', {})
  assert.equal(result.status, 'provisional',
    `engine offline + cssPath should return provisional, got ${result.status}`)
  assert.equal(result.confidence, 0.0,
    'cssPath fallback should flag confidence 0.0 — the engine has not verified this')
})

await atest('P5. engine offline with no cssPath returns miss, not crash', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  AnchorBridge.setBridge(bridge)

  const anchorNoCss = { testId: 'submit-btn', text: 'Submit' }
  const result = await AnchorBridge.resolve(anchorNoCss, 'browser.click', {})
  assert.equal(result.status, 'miss')
  assert.equal(result.reason, 'ENGINE_OFFLINE')
})

await atest('P6. anchor with no stable id skips keepalive and goes straight to engine', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({
    status: 'hit',
    element: { resolvedSelector: 'button[type=submit]', snapshot: GOOD_ELEMENT },
    method: 'full-score',
  })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)

  const anchorNoId = { text: 'Submit', role: 'button', tag: 'button' }
  const result = await AnchorBridge.resolve(anchorNoId, 'browser.click', {})
  // keepalive should not have been called (no testId or id)
  const keepaliveCalls = bridge.calls.filter(c => c.tool === 'browser.query_all')
  assert.equal(keepaliveCalls.length, 0, 'keepalive queried the DOM even though no stable id was present')
  assert.equal(result.status, 'hit')
})

await atest('P7. recorder event includes tool name and anchor', async () => {
  reset()
  const rec = makeRecorder()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({ status: 'miss', reason: 'NO_CANDIDATES' })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)
  AnchorBridge.setRecorder(rec)

  await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.type', { text: 'hello' })
  assert.equal(rec.events[0].tool, 'browser.type')
  assert.deepEqual(rec.events[0].anchor, GOOD_ANCHOR)
})

await atest('P8. reanchored result emits anchor_reanchored event, not anchor_hit', async () => {
  reset()
  const rec = makeRecorder()
  const bridge = makeBridge({ 'browser.query_all': [] })
  const engine = makeEngine({
    status: 'reanchored',
    element: { resolvedSelector: '#submit-new', snapshot: GOOD_ELEMENT },
    method: 'fallback',
    confidence: 0.82,
  })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setEngine(engine)
  AnchorBridge.setRecorder(rec)

  await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(rec.events[0].type, 'anchor_reanchored',
    'a reanchored result was logged as a regular hit — wrong-grab risk invisible to the recorder')
})

await atest('P9. missionId is null when not set — event still has a timestamp', async () => {
  reset()
  const rec = makeRecorder()
  const bridge = makeBridge({ 'browser.query_all': [GOOD_ELEMENT] })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setRecorder(rec)
  // missionId not set

  await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(rec.events[0].missionId, undefined)
  assert.ok(rec.events[0].timestamp, 'event has no timestamp')
})

await atest('P10. setBridge(null) between calls returns BRIDGE_OFFLINE, not a crash', async () => {
  reset()
  const bridge = makeBridge({ 'browser.query_all': [GOOD_ELEMENT] })
  AnchorBridge.setBridge(bridge)
  AnchorBridge.setBridge(null)  // torn down mid-session

  const result = await AnchorBridge.resolve(GOOD_ANCHOR, 'browser.click', {})
  assert.equal(result.status, 'miss')
  assert.equal(result.reason, 'BRIDGE_OFFLINE')
})

// ── Report ─────────────────────────────────────────────────────────────────

console.log(`\nanchor-bridge: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
