# Protecting Forge Flight — the honest IP breakdown

*I am not a lawyer and this is not legal advice — it's strategy. Anything here
about "file X" or "register Y" is a map of the terrain so you can spend one
paid hour with an IP attorney wisely, instead of five. Forge Flight's repo is
currently **private on GitHub**, which matters, and I'll say why below.*

---

## First, the thing nobody wants to say: you can't own the idea

This is the foundation everything else sits on, so let's put it on the table.

Intellectual property law does **not** protect ideas. It protects four specific
things:

| Type | Protects | Automatic? | Cost | Blocks the big dogs from… |
|---|---|---|---|---|
| **Copyright** | the *expression* — your actual code, text, UI | ✅ yes, the moment you type it | ~$65 to register | copying your code verbatim / derivative code |
| **Trade secret** | the *how* — algorithms, constants, heuristics kept secret | ✅ yes, while it stays secret | free | reverse-engineering what they can't see |
| **Trademark** | the *brand* — "Forge Flight," the name, the logo | ⚠️ common-law on use, registered on filing | ~$250–$350/class | using your name to sell a knockoff |
| **Patent** | a specific *invention* — a novel, non-obvious mechanism | ❌ must file and be granted | $10k–$30k+, 2–4 years | practicing the exact mechanism |

Notice what's missing: **"fan one prompt to five AIs and let them vote" is an
idea.** So is "a memory log that needs five witnesses." So is "a browser whose
tabs are seats." None of those, standing alone, is ownable — by you *or* by the
big dogs. What you own is the *specific way you built them* and the *brand you
attached to them*.

That's not bad news. It's the same position every software company has ever
been in. Microsoft couldn't patent "spreadsheet." They won by shipping, branding,
and iterating faster than everyone else.

---

## What you already have (and what it's worth)

**1. Copyright — you already own the code.** The instant you wrote it, the
expression was yours. This is the strongest thing you have, and it's free.
What it blocks: someone (including a big dog) copying your source and shipping
it as their own. What it does *not* block: someone building the same *idea*
from scratch in their own code. That's legal, and always has been.

**2. A private repo — you're already doing the right thing.** Confirmed:
`Omnibox-browser` is `isPrivate: true`. A private repo is a trade-secret
container. Nobody can read the code without access, which means the specific
*how* (your selector-free detector, the 5-witness rule, τ = 0.10, the flight
recorder) is currently protected simply by not being visible.

**3. A dated trail of authorship.** Your git history, commit timestamps, the
GitHub repo creation date, the Arena session record — all of it is *evidence*.
If it ever matters, you can show you built this on these dates. Keep this. It's
the cheapest "first to build" proof you'll ever get.

---

## The AI wrinkle — this one is specific to you, and it's real

You built this by jumping between free AIs. That changes two things:

**Copyright side:** US Copyright Office guidance says AI-generated material
alone isn't registrable, but a human who *directs, selects, edits, and arranges*
AI output has authorship in that creative contribution. You wrote the
architecture, made the decisions, fixed the code, shaped the product — so the
work is yours to the extent of your creative control. You're on solid ground.
Just don't describe it as "the AI wrote it" in any filing — the accurate frame
is "I directed and authored it, with AI assistance."

**Trade-secret side — this is the important one:** whatever you pasted into a
free AI chat may no longer be *secret*, depending on that AI's terms of service.
Many free tiers reserve the right to use inputs for training, and "training on
it" means the material isn't confidential anymore. Practically speaking:

- The *idea* was never secret (it's been talked about publicly).
- Any *code* you pasted into free chats should be treated as **no longer
  secret**. You still own the copyright; you've just given up any claim that
  nobody's seen it.
- From **today forward**: stop pasting crown-jewel code (the detector
  heuristics, the equation logic, the flight-recorder algorithms, the specific
  constants) into free AI chats. For sensitive work, use an API tier or
  enterprise plan **with a no-training/no-retention clause** — that's the switch
  that preserves future trade secrets.

Big-dog paranoia check: AI providers don't hand your prompts to Google or
Microsoft. The realistic leak vectors are (a) *you* publishing the repo public,
(b) *you* pasting crown jewels into free chats, and (c) the provider training
on your inputs. All three are under your control.

---

## Do we need a patent? Honest answer: almost certainly not right now

Here's the breakdown, straight:

**Why patents look tempting:** they're the only thing that can protect an
*idea*, and "fan a prompt to five AIs with tamper-evident memory" feels
patent-worthy when you're emotionally attached to it.

**Why they're usually wrong for a solo builder right now:**

1. **Cost and time.** A non-provisional software patent runs roughly
   **$10,000–$30,000** and takes **2–4 years**. A *provisional* application
   ("patent pending") is cheap — roughly **$65–$500** depending on your entity
   size — but it's a *placeholder*: it buys you 12 months to decide, and
   expires worthless if you don't follow up.

2. **Software patents are weak in the US.** Since *Alice Corp. v. CLS Bank*
   (2014), abstract ideas aren't patent-eligible unless they add "significantly
   more." "A browser that sends one prompt to multiple chat services and logs
   agreement" reads, to the Patent Office, like an abstract idea. You'd spend
   real money fighting a §101 rejection.

3. **Publication is a gift to the big dogs.** A patent requires you to
   *publish exactly how the invention works*. For a small player, that document
   is often a free engineering spec handed to the competitors you're scared of —
   they design *around* it, and you paid to write their roadmap.

4. **It protects the wrong thing.** You're not scared of someone practicing one
   narrow mechanism. You're scared of someone shipping the same *product*. A
   patent barely helps with that; a brand and a community do.

**What *could* be patentable (worth one paid consult, nothing more):** a
genuinely novel, specific mechanism. Candidates in your codebase:

- the **selector-free structural composer detection** that names refusals
  (`ambiguous`, `below-floor`, etc.) instead of guessing,
- the **hash-chained witness memory with equation-identity and
  contradiction-closure** (5 witnesses promote, 1 closes),
- the **flight-recorder maneuver promotion** (5 successes promote, 1 failure
  blocks).

Any *one* of those, stated precisely, is the kind of thing a patent attorney
might say "maybe." All of them together are a product. So: **book one hour with
a patent attorney, describe those three mechanisms, and let them tell you if a
provisional is worth ~$500.** Expect the answer to be "probably not, but if you
want a 'patent pending' badge for investor conversations, a provisional is cheap
insurance."

One more AI note: a patent's **inventor must be a natural person** — an AI can't
be listed (the DABUS cases settled this). You conceived and directed it, so
you're the inventor. Fine.

---

## What actually protects you — do these, in this order

This is the stack that beats "somebody copies it," and almost none of it costs
real money:

### 1. Keep the repo private (✅ already done — keep doing it)
The single highest-leverage move. The specific *how* is invisible until you
choose to show it.

### 2. Choose your license *before* you ever go public
Right now there's **no LICENSE file**, which means "all rights reserved" by
default — technically fine while it's private, but you should decide the story
now. Because your whole pitch is *"free for the little guy,"* a plain MIT
license would let Google take your code and charge for it. Instead, look at
**source-available licenses** that encode your ethos into the moat:

- **PolyForm Noncommercial** — free for anyone except commercial use.
- **PolyForm Shield** — free for most, but big competitors can't compete with it.
- **Commons Clause** (on top of Apache/MIT) — you can use it, you can't *sell* it.
- Or the classic **dual license**: open/source-available for individuals and
  small teams, paid commercial license for companies over a revenue threshold.

The license *is* the legal encoding of "affordable for the little guy." Pick one
and put it in the repo. (When you do go public, a source-available license is
also what makes you *look* like a principled founder rather than a walled garden.)

### 3. Trademark "Forge Flight" (and maybe "OmniBox")
~$250–$350 per class, doable yourself through USPTO's TEAS system or a cheap
service. This is the highest value-per-dollar move in the whole list: it's the
only protection that survives even if someone legally clones the idea, because
*they* can't call it "Forge Flight" and ride your brand. If the big dogs copy
the feature, they'll call it something corporate and boring — your trademark is
what keeps the *identity* yours.

### 4. Register copyright on shipped releases
~$65 with the US Copyright Office (source-code deposit). Copyright is automatic,
but **registration** is what unlocks statutory damages and attorney's fees if
you ever sue. Without it you can only get actual damages, which are often near
zero for a free tool. Cheap insurance; do it at each major release.

### 5. Build the public "we were first" trail — this is the real moat
The big dogs can copy the feature. They **cannot** copy being first. So make the
internet record it: a launch post, a dated public roadmap, a "why Forge Flight
exists" essay, screenshots, a changelog. Every dated public artifact is evidence
of priority and — more importantly — *positioning*. You become the category's
name. That's worth more than a patent because it compounds.

### 6. Split the secret sauce going forward
Mentally (and later, structurally) separate:
- **Public story** — the ethos, the docs, the README philosophy, the marketing.
- **Secret sauce** — the detector's specific signal weights and lexicons, the
  equation/contradiction logic, the flight-recorder thresholds. These stay in
  the private repo and out of free AI chats.

---

## The strategic truth that will actually calm you down

**The big dogs are not going to steal this from you — and the idea isn't the
moat anyway.**

- They already ship multi-model routing and "AI committee" features. The *idea*
  is not news to them.
- They don't sit around mining private repos of solo developers. Your repo is
  invisible to them unless you make it public.
- If they ever do build "the feature," they'll build a sanitized corporate
  version — **and that's fine**, because it will validate the category *you*
  named, and they can't credibly copy the one thing that matters:

  > Your product's entire identity is **local-first, no-account, "the refusal is
  > the product," free for the little guy.** A big dog *cannot* claim that —
  > their business model is the literal opposite. They'd be advertising against
  > themselves. That positioning is your moat, and it can't be patented or
  > stolen; it can only be abandoned.

**Speed is the other half.** You can ship a bounded Code Forge in weeks. A big
company needs quarters and a committee. The person who ships first, names it,
and gathers the community wins — not the person with the patent. (Ask yourself:
did *Instagram* win on patents, or on shipping and network effects?)

---

## The one-sentence summary

> **Don't rush a patent. Keep the repo private, add a source-available license
> that encodes "free for the little guy," trademark "Forge Flight," register
> copyright on releases, stop pasting secret sauce into free AI chats, and
> spend your energy shipping and building the public "we were first" trail —
> because the brand, the community, and the speed are the moat, not the idea.**

And spend one hour with an IP attorney this quarter: bring this document, ask
about the three patentable mechanisms, and let them price a provisional. That
one hour converts all of this from "strategy" into "your specific plan."
