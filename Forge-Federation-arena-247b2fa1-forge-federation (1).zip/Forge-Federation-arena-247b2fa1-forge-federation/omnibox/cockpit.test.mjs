/**
 * neuralink.test.mjs
 * Cockpit seat management and routing.
 *
 * Structure: nine baseline cases (does it do what it says), then
 * attack probes (can a pilot end up somewhere it shouldn't, or
 * silently get dropped from a mission it's seated for).
 */

import assert from 'node:assert/strict'
import { Neuralink } from './cockpit.ts'

let passed = 0
let failed = 0
const failures = []

function test(name, fn) {
  try {
    fn()
    passed++
  } catch (err) {
    failed++
    failures.push({ name, message: err.message })
  }
}

const local = (label = 'Qwen local') => ({
  pilotId: `local-${Math.random().toString(36).slice(2, 8)}`,
  type: 'local',
  label,
  endpoint: 'http://localhost:11434',
})

const hosted = (type = 'claude', label = 'Claude Sonnet') => ({
  pilotId: `${type}-${Math.random().toString(36).slice(2, 8)}`,
  type,
  label,
})

// ── Baseline 1-9 ───────────────────────────────────────────────────────────

test('1. local pilot boards seat 0', () => {
  const n = new Neuralink()
  const seat = n.board(0, local())
  assert.equal(seat.status, 'seated')
  assert.equal(seat.pilot.type, 'local')
  assert.equal(seat.index, 0)
})

test('2. non-local pilot rejected from seat 0 (typelock)', () => {
  const n = new Neuralink()
  assert.throws(() => n.board(0, hosted()), /SEAT_TYPELOCK/)
  assert.equal(n.getSeat(0).status, 'empty')
})

test('3. five pilots fills the cockpit', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  n.board(3, hosted('gpt'))
  n.board(4, hosted('grok'))
  assert.equal(n.isFull(), true)
  assert.equal(n.seatedPilots().length, 5)
})

test('4. sixth pilot via boardAny throws COCKPIT_FULL', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  n.board(3, hosted('gpt'))
  n.board(4, hosted('grok'))
  assert.throws(() => n.boardAny(hosted('mistral')), /COCKPIT_FULL/)
})

test('5. adversarial shape with unseated seat is rejected', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  assert.throws(
    () => n.setShape({ shape: 'adversarial', sides: { a: [0], b: [3] } }),
    /SHAPE_CONFIG/
  )
})

test('6. communal routing gives every pilot a route with no waits', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  n.setShape({ shape: 'communal' })
  const plan = n.routingPlan('what is the best database')
  assert.equal(plan.routes.length, 3)
  for (const r of plan.routes) assert.deepEqual(r.waitFor, [])
})

test('7. relay routing chains waitFor in order', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  n.setShape({ shape: 'relay', relayOrder: [2, 0, 1] })
  const plan = n.routingPlan('build on this')
  assert.deepEqual(plan.routes.map(r => r.seatIndex), [2, 0, 1])
  assert.deepEqual(plan.routes[0].waitFor, [])
  assert.deepEqual(plan.routes[1].waitFor, [2])
  assert.deepEqual(plan.routes[2].waitFor, [2, 0])
})

test('8. eject leaves seat ejected, not empty', () => {
  const n = new Neuralink()
  n.board(1, hosted('claude'))
  const seat = n.eject(1)
  assert.equal(seat.status, 'ejected')
  assert.notEqual(seat.status, 'empty')
})

test('9. mission transitions seated -> flying -> seated with count', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.missionStarted('m-1')
  assert.equal(n.getSeat(0).status, 'flying')
  assert.equal(n.getSeat(1).status, 'flying')
  n.missionEnded('m-1')
  assert.equal(n.getSeat(0).status, 'seated')
  assert.equal(n.getSeat(0).missionCount, 1)
})

// ── Attack probes ──────────────────────────────────────────────────────────

test('P1. seated pilot is never silently dropped from adversarial routing', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  // seat 2 is seated but on neither side
  n.setShape({ shape: 'adversarial', sides: { a: [0], b: [1] } })
  const plan = n.routingPlan('argue')
  const routed = plan.routes.map(r => r.seatIndex)
  assert.ok(
    routed.includes(2),
    `seat 2 is seated but got no route — silently excluded from the mission. Routed: ${routed}`
  )
})

test('P2. a seat cannot be on both sides of an adversarial debate', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  assert.throws(
    () => n.setShape({ shape: 'adversarial', sides: { a: [0, 1], b: [1] } }),
    /SHAPE_CONFIG/,
    'seat 1 on both sides was accepted'
  )
})

test('P3. sidebar pair must be two distinct seats', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  assert.throws(
    () => n.setShape({ shape: 'sidebar', sidebarPair: [1, 1] }),
    /SHAPE_CONFIG/,
    'sidebar with the same seat twice was accepted'
  )
})

test('P4. interview requires at least two pilots', () => {
  const n = new Neuralink()
  n.board(0, local())
  assert.throws(
    () => n.setShape({ shape: 'interview', interviewer: 0 }),
    /SHAPE_CONFIG/,
    'interview with nobody to interview was accepted'
  )
})

test('P5. relay order omitting a seated pilot is rejected', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.board(2, hosted('gemini'))
  assert.throws(
    () => n.setShape({ shape: 'relay', relayOrder: [0, 1] }),
    /SHAPE_CONFIG/,
    'seat 2 seated but omitted from relay — would never receive the prompt'
  )
})

test('P6. state() does not leak mutable internals', () => {
  const n = new Neuralink()
  n.board(0, local('original'))
  const snap = n.state()
  snap.seats[0].pilot.label = 'MUTATED'
  assert.equal(
    n.getSeat(0).pilot.label,
    'original',
    'state() returned a live reference to the pilot descriptor'
  )
})

test('P7. getShape() does not leak mutable internals', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.setShape({ shape: 'adversarial', sides: { a: [0], b: [1] } })
  const shape = n.getShape()
  shape.sides.a.push(4)
  assert.equal(
    n.getShape().sides.a.length,
    1,
    'getShape() returned a live reference to the sides config'
  )
})

test('P8. boarding mid-mission does not create an unrecorded pilot', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.missionStarted('m-1')
  // someone boards while the plane is flying
  let boarded = true
  try {
    n.board(1, hosted('claude'))
  } catch {
    boarded = false
  }
  if (boarded) {
    assert.equal(
      n.getSeat(1).status,
      'flying',
      'pilot boarded mid-mission but was left "seated" — missionEnded will never count it'
    )
  }
})

test('P9. ejecting a side member invalidates a stale adversarial shape', () => {
  const n = new Neuralink()
  n.board(0, local())
  n.board(1, hosted('claude'))
  n.setShape({ shape: 'adversarial', sides: { a: [0], b: [1] } })
  n.eject(1)
  assert.throws(
    () => n.routingPlan('argue'),
    /SHAPE_STALE|SHAPE_CONFIG/,
    'side B is now empty — this is not a debate, it is one pilot talking to nobody'
  )
})

test('P10. boardAny for a local pilot when seat 0 is taken reports clearly', () => {
  const n = new Neuralink()
  n.board(0, local('first'))
  try {
    n.boardAny(local('second'))
    assert.fail('second local pilot was boarded somewhere')
  } catch (err) {
    assert.match(
      err.message,
      /LOCAL_SEAT_TAKEN/,
      `misleading error for a full local seat: "${err.message}"`
    )
  }
})

test('P11. routingPlan with no pilots throws rather than returning empty', () => {
  const n = new Neuralink()
  assert.throws(() => n.routingPlan('anything'), /NO_PILOTS/)
})

test('P12. ejected seat can be re-boarded', () => {
  const n = new Neuralink()
  n.board(1, hosted('claude'))
  n.eject(1)
  const seat = n.board(1, hosted('gemini'))
  assert.equal(seat.status, 'seated')
  assert.equal(seat.pilot.type, 'gemini')
})

// ── Report ─────────────────────────────────────────────────────────────────

console.log(`\nneuralink: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
