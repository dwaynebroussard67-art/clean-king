// Run with: node --experimental-strip-types src/harness/harness-hardening.test.mjs
//
// Hardening pass, round 2. Found by attacking the running harness the same way
// the re-anchor engine's hardening passes were done: not by reading the code
// for what looks wrong, but by driving the real classes into the shapes a real
// pilot produces and watching what breaks. All three checks below caught a live
// crash or a silent security hole before this file existed; they stay here as
// regression guards.

import { HarnessRuntime, InMemoryMissionStore } from './runtime.ts';
import { CapabilityRegistry } from './capabilities.ts';
import { ExecutionRefused } from './executor.ts';
import { corePack } from './packs/core-pack.ts';

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { console.log(`  ✓ ${name}`); passed++; }
  else { console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); failed++; }
}

const passport = {
  async loadContext() { return { passportId: 'p1', memories: [], preferences: {}, decisions: [] }; },
  async recordOutcome() {},
};

function newHarness() {
  const harness = new HarnessRuntime({
    store: new InMemoryMissionStore(), passport, capabilities: new CapabilityRegistry(),
  });
  harness.mount(corePack());
  return harness;
}

async function boot(harness, granted = ['core.note', 'core.record_evidence']) {
  const mission = await harness.createMission({
    passportId: 'p1', goal: 'harden',
    authority: { actorId: 'pilot', allowedCapabilityIds: granted, autoApproveRiskAtMost: 'read' },
  });
  await harness.bindNeuralink(mission.id);
  await harness.beginPlanning(mission.id);
  return mission;
}

console.log('\n1. Two approval-requiring requests outstanding at once must not crash the harness\n');
{
  // BUG (found this pass): requestTool() advanced to WAITING_APPROVAL
  // unconditionally on every require_approval decision. WAITING_APPROVAL ->
  // WAITING_APPROVAL is not a legal transition, so the second of two ordinary
  // concurrent approval requests -- "delete A" and "delete B", both needing a
  // human, neither decided yet -- crashed the entire harness with an uncaught
  // MissionStateError. Not a refusal: a crash.
  const harness = newHarness();
  const mission = await boot(harness);
  const a = await harness.requestTool({
    missionId: mission.id, id: 'a', capabilityId: 'core.record_evidence',
    arguments: { pointer: 'a', supports: 'x', origin: 'observed' },
  });
  let secondCrashed = false;
  let b;
  try {
    b = await harness.requestTool({
      missionId: mission.id, id: 'b', capabilityId: 'core.record_evidence',
      arguments: { pointer: 'b', supports: 'y', origin: 'observed' },
    });
  } catch { secondCrashed = true; }
  check('a second concurrent approval-requiring request does not crash', !secondCrashed);
  check('both are gated, not silently allowed',
    a.authorization.decision === 'require_approval' && b?.authorization.decision === 'require_approval');
}

console.log('\n2. Both concurrent approvals resolve independently, in either order\n');
{
  // BUG (found this pass, same root cause on the other side): decideApproval()
  // advanced to RUNNING unconditionally on approve/edit. Deciding the SECOND
  // of two pending approvals -- after the first had already moved the mission
  // to RUNNING -- tried RUNNING -> RUNNING and crashed the same way.
  const harness = newHarness();
  const mission = await boot(harness);
  const a = await harness.requestTool({
    missionId: mission.id, id: 'a', capabilityId: 'core.record_evidence',
    arguments: { pointer: 'a', supports: 'x', origin: 'observed' },
  });
  const b = await harness.requestTool({
    missionId: mission.id, id: 'b', capabilityId: 'core.record_evidence',
    arguments: { pointer: 'b', supports: 'y', origin: 'observed' },
  });

  await harness.decideApproval(mission.id, { approvalId: 'x1', toolCallId: 'a', decision: 'approve', actorId: 'human' });
  const resultA = await harness.executeAuthorized(a.toolCall);
  check('the first approval executes', resultA.status === 'succeeded');

  let secondCrashed = false;
  let missionAfter;
  try {
    missionAfter = await harness.decideApproval(mission.id, { approvalId: 'x2', toolCallId: 'b', decision: 'approve', actorId: 'human' });
  } catch { secondCrashed = true; }
  check('deciding the second pending approval does not crash', !secondCrashed);
  check('the mission is still running after both are resolved', missionAfter?.status === 'RUNNING');

  const resultB = await harness.executeAuthorized(b.toolCall);
  check('the second approval also executes', resultB.status === 'succeeded');

  const audit = await harness.auditToolAuthority(mission.id);
  check('both invocations still pair with their own grant', audit.ok === true, JSON.stringify(audit.violations));
}

console.log('\n3. A pending toolCallId cannot be silently redirected to a different request\n');
{
  // BUG (found this pass, the serious one): requesting the SAME toolCallId a
  // second time, before the first was decided, silently overwrote the pending
  // approval record with the new capability and arguments. A human shown
  // "approve SHARED" -- believing they were reviewing the first request --
  // could unknowingly approve a completely different one. The executor's own
  // argument-binding refuses the ORIGINAL call when it is later presented
  // (fail-safe), but nothing told the human their approval had been repointed
  // to the second request, which DID execute. That silent redirect is the
  // actual hole, independent of the fail-safe catching its symptom.
  const harness = newHarness();
  const mission = await boot(harness);

  await harness.requestTool({
    missionId: mission.id, id: 'SHARED', capabilityId: 'core.note',
    arguments: { key: 'benign', value: 1 },
  });

  let reuseRefused = false;
  try {
    await harness.requestTool({
      missionId: mission.id, id: 'SHARED', capabilityId: 'core.record_evidence',
      arguments: { pointer: 'x', supports: 'y', origin: 'observed' },
    });
  } catch (error) { reuseRefused = error instanceof ExecutionRefused; }
  check('reusing an outstanding toolCallId for a different request is refused', reuseRefused);

  // The original request must still be exactly what it was -- untouched by the
  // attempted reuse.
  const decided = await harness.decideApproval(mission.id, {
    approvalId: 'appr', toolCallId: 'SHARED', decision: 'approve', actorId: 'human',
  });
  check('the ORIGINAL request is what gets approved', decided.status === 'RUNNING');
}

console.log('\n4. A toolCallId is reusable again once its prior request is fully decided\n');
{
  const harness = newHarness();
  const mission = await boot(harness);
  await harness.requestTool({
    missionId: mission.id, id: 'recyclable', capabilityId: 'core.record_evidence',
    arguments: { pointer: 'first', supports: 'x', origin: 'observed' },
  });
  await harness.decideApproval(mission.id, { approvalId: 'a1', toolCallId: 'recyclable', decision: 'reject', actorId: 'human' });

  const second = await boot(harness);
  let refused = false;
  try {
    await harness.requestTool({
      missionId: second.id, id: 'recyclable', capabilityId: 'core.note', arguments: { key: 'k', value: 1 },
    });
  } catch { refused = true; }
  check('the same id on a DIFFERENT mission is unaffected (ids are per-mission)', !refused);
}

console.log(`\n${passed} passed, ${failed} failed`);
console.log(
  '\nFLAGGED, NOT FIXED: rejecting the second of two pending approvals CANCELS the\n' +
  'whole mission, even though the first request already executed successfully.\n' +
  'That is existing "any rejection cancels the mission" policy, not a crash --\n' +
  'changing it is a design decision about partial-completion semantics, not a\n' +
  'hardening fix, and it was left alone on purpose.',
);
process.exit(failed === 0 ? 0 : 1);
