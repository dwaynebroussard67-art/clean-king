/**
 * seat-budget.ts — per-seat consumption governance.
 *
 * THE PROBLEM THIS SOLVES
 *
 * MissionBudget (mission-computer.ts) meters the mission: total dollars, total
 * tool calls, total model turns. It is charged in exactly one place — the
 * approval path in runtime.ts — and it pools everything into one bucket.
 *
 * That is the wrong shape for five seats. Five pilots sharing one pool means a
 * seat that burns its free tier is invisible until the whole mission trips, and
 * `maxModelTurns` is never charged by anything at all, so a pilot answering
 * prompts all day never moves the counter.
 *
 * This file meters the SEAT. Every seat carries its own allowance, charged
 * before dispatch, and a seat that runs out is ejected rather than being
 * allowed to spend the operator's money.
 *
 * ── THE ORDERING RULE, AND WHY IT IS NOT NEGOTIABLE ─────────────────────
 *
 * Charge BEFORE the request leaves, never after it returns.
 *
 * A provider's 429 arrives after the request that may already have been
 * counted against the account. Waiting for the provider to say "no" means the
 * call that told you has already been made. The provider is the backstop. The
 * local ledger is the gate.
 *
 * ── NO REFUNDS, AND WHY THAT IS DELIBERATE ──────────────────────────────
 *
 * A dispatch that fails is NOT refunded. A request that reached the provider
 * and then errored may still have been metered on their side; a request that
 * never reached them was not. From here the two are indistinguishable, and
 * guessing in the operator's favour is guessing in the direction that spends
 * their money.
 *
 * So the error direction is fixed: this ledger may overcount, never undercount.
 * Same convention as the precedent extractor — it costs recall, never
 * soundness. Failed spend is recorded separately in `spentOnFailure` so the
 * measurement data stays honest about what the overcount consists of.
 *
 * ── UNKNOWN TIERS DO NOT EJECT ──────────────────────────────────────────
 *
 * A seat whose allowance is unknown is metered but never ejected. Ejecting on
 * a limit nobody established would break every operator on a paid plan, which
 * is a worse failure than letting an unmetered seat keep flying. Unknown means
 * "count it, report it, do not act on it".
 */

import type { PilotType, SeatIndex } from './cockpit.ts';

// ── Allowance ────────────────────────────────────────────────────────────

/**
 * `calls` is deliberately the primary unit rather than tokens. Free tiers are
 * overwhelmingly expressed as request counts, and a request count is knowable
 * before dispatch — token spend is not knowable until the response returns,
 * which is on the wrong side of the gate.
 */
export type SeatAllowance = {
  /** Maximum dispatches. `undefined` = unknown, meter but never eject. */
  maxCalls?: number;
  /** Maximum spend in USD. `undefined` = unknown. */
  maxUsd?: number;
  /** Human-readable name of the tier this allowance came from. */
  tier: string;
};

export type SeatUsage = {
  /** Dispatches charged, successful or not. */
  calls: number;
  /** Dollars charged. */
  usd: number;
  /** Of `calls`, how many did not come back with a usable answer. */
  spentOnFailure: number;
};

export type SeatBudgetStatus =
  | 'ok'
  | 'exhausted'
  /** Metered but not enforceable — no allowance was ever established. */
  | 'unmetered';

export class SeatBudgetExceededError extends Error {
  readonly seatIndex: SeatIndex;
  readonly resource: 'calls' | 'usd';
  readonly limit: number;
  readonly used: number;

  constructor(seatIndex: SeatIndex, resource: 'calls' | 'usd', limit: number, used: number) {
    super(
      `SEAT_BUDGET_EXCEEDED: seat ${seatIndex} has spent ${used} of ${limit} ${resource}. ` +
        `The seat is out of allowance and must be ejected or re-provisioned.`,
    );
    this.name = 'SeatBudgetExceededError';
    this.seatIndex = seatIndex;
    this.resource = resource;
    this.limit = limit;
    this.used = used;
  }
}

// ── Default tiers ────────────────────────────────────────────────────────

/**
 * Conservative published free-tier defaults, per seat per day.
 *
 * These are a starting position, not a source of truth: providers change tiers
 * without notice and an operator's actual plan is not knowable from the client.
 * Under-estimating costs a seat some reach. Over-estimating costs the operator
 * money. The numbers below therefore sit deliberately low, and any operator on
 * a paid plan is expected to override via `provision()`.
 *
 * `local` is unmetered because inference on the operator's own machine costs
 * them nothing per call.
 */
export const DEFAULT_TIERS: Record<PilotType, SeatAllowance> = {
  local: { tier: 'local (unmetered)' },
  claude: { maxCalls: 50, tier: 'conservative free-tier default' },
  gemini: { maxCalls: 50, tier: 'conservative free-tier default' },
  gpt: { maxCalls: 50, tier: 'conservative free-tier default' },
  grok: { maxCalls: 50, tier: 'conservative free-tier default' },
  mistral: { maxCalls: 50, tier: 'conservative free-tier default' },
  deepseek: { maxCalls: 50, tier: 'conservative free-tier default' },
  perplexity: { maxCalls: 50, tier: 'conservative free-tier default' },
  custom: { tier: 'unknown (custom endpoint)' },
} as Record<PilotType, SeatAllowance>;

export function defaultAllowanceFor(type: PilotType): SeatAllowance {
  return DEFAULT_TIERS[type] ?? { tier: 'unknown' };
}

// ── The per-seat record ──────────────────────────────────────────────────

/**
 * One dispatch, attributed.
 *
 * The key is `(seatIndex, pilotId, type, missionId, contentHash)` from the
 * first record onward. Retrofitting attribution onto rows that carry only a
 * mission id is painful, and without `contentHash` a divergence between two
 * seats cannot be shown to be divergence on identical input — which is the
 * only thing that makes cross-model comparison a measurement rather than an
 * anecdote.
 */
export type SeatDispatchRecord = {
  seatIndex: SeatIndex;
  pilotId: string;
  type: PilotType;
  missionId: string | null;
  /** Digest of the page the seat was looking at, when there was one. */
  contentHash: string | null;
  at: string;
  outcome: 'succeeded' | 'failed' | 'rate_limited';
  tookMs: number;
  usd: number;
  /** Populated on failure. */
  error?: string;
};

// ── The ledger ───────────────────────────────────────────────────────────

export class SeatBudgetLedger {
  private allowances = new Map<SeatIndex, SeatAllowance>();
  private usages = new Map<SeatIndex, SeatUsage>();
  private records: SeatDispatchRecord[] = [];

  /** Establish or replace a seat's allowance. Resets nothing by itself. */
  provision(seatIndex: SeatIndex, allowance: SeatAllowance): void {
    this.allowances.set(seatIndex, {
      maxCalls: normalizeLimit(allowance.maxCalls),
      maxUsd: normalizeLimit(allowance.maxUsd),
      tier: allowance.tier,
    });
    if (!this.usages.has(seatIndex)) this.usages.set(seatIndex, zeroUsage());
  }

  /** Provision from the pilot's type using the conservative defaults. */
  provisionFromType(seatIndex: SeatIndex, type: PilotType): void {
    this.provision(seatIndex, defaultAllowanceFor(type));
  }

  allowanceFor(seatIndex: SeatIndex): SeatAllowance | null {
    return this.allowances.get(seatIndex) ?? null;
  }

  usageFor(seatIndex: SeatIndex): SeatUsage {
    return { ...(this.usages.get(seatIndex) ?? zeroUsage()) };
  }

  /** How many dispatches remain. `null` when the seat is unmetered. */
  remainingCalls(seatIndex: SeatIndex): number | null {
    const allowance = this.allowances.get(seatIndex);
    if (!allowance || allowance.maxCalls === undefined) return null;
    const used = this.usageFor(seatIndex).calls;
    return Math.max(0, allowance.maxCalls - used);
  }

  status(seatIndex: SeatIndex): SeatBudgetStatus {
    const allowance = this.allowances.get(seatIndex);
    if (!allowance) return 'unmetered';
    const usage = this.usageFor(seatIndex);
    if (allowance.maxCalls === undefined && allowance.maxUsd === undefined) return 'unmetered';
    if (allowance.maxCalls !== undefined && usage.calls >= allowance.maxCalls) return 'exhausted';
    if (allowance.maxUsd !== undefined && usage.usd >= allowance.maxUsd) return 'exhausted';
    return 'ok';
  }

  /**
   * Charge one dispatch. CALL THIS BEFORE THE REQUEST LEAVES.
   *
   * Throws SeatBudgetExceededError when the charge would exceed the allowance.
   * The usage is not mutated when the charge is refused, so a refused charge
   * leaves the ledger exactly as it was and the caller may eject cleanly.
   *
   * An unmetered seat is still counted — measurement does not depend on
   * enforceability — it simply cannot be refused.
   */
  charge(seatIndex: SeatIndex, estimatedUsd = 0): SeatUsage {
    const usage = this.usages.get(seatIndex) ?? zeroUsage();
    const allowance = this.allowances.get(seatIndex);
    const usd = Math.max(0, finiteOrZero(estimatedUsd));

    if (allowance) {
      const nextCalls = usage.calls + 1;
      const nextUsd = usage.usd + usd;
      if (allowance.maxCalls !== undefined && nextCalls > allowance.maxCalls) {
        throw new SeatBudgetExceededError(seatIndex, 'calls', allowance.maxCalls, usage.calls);
      }
      if (allowance.maxUsd !== undefined && nextUsd > allowance.maxUsd) {
        throw new SeatBudgetExceededError(seatIndex, 'usd', allowance.maxUsd, usage.usd);
      }
    }

    const next: SeatUsage = {
      calls: usage.calls + 1,
      usd: usage.usd + usd,
      spentOnFailure: usage.spentOnFailure,
    };
    this.usages.set(seatIndex, next);
    return { ...next };
  }

  /**
   * Record how a charged dispatch turned out. Does not charge again — the
   * dispatch was already paid for at `charge()`. This only classifies the
   * spend and files the attributed record.
   */
  settle(record: SeatDispatchRecord): void {
    if (record.outcome !== 'succeeded') {
      const usage = this.usages.get(record.seatIndex) ?? zeroUsage();
      this.usages.set(record.seatIndex, {
        ...usage,
        spentOnFailure: usage.spentOnFailure + 1,
      });
    }
    this.records.push({ ...record });
  }

  /**
   * The provider said 429. Our local count was optimistic — it thought there
   * was room and there was not.
   *
   * Reconcile UPWARD to the ceiling. Never downward: a 429 is evidence that at
   * least the allowance has been consumed, never evidence that less has been.
   * After this the seat reports `exhausted` and should be ejected.
   */
  reconcileRateLimited(seatIndex: SeatIndex): void {
    const allowance = this.allowances.get(seatIndex);
    const usage = this.usages.get(seatIndex) ?? zeroUsage();

    if (!allowance || allowance.maxCalls === undefined) {
      // Unmetered seat that turned out to be metered after all. Establish a
      // ceiling at what has actually been spent, so the seat now reports
      // exhausted rather than continuing to look free.
      this.allowances.set(seatIndex, {
        ...(allowance ?? { tier: 'discovered by rate limit' }),
        maxCalls: Math.max(1, usage.calls),
        tier: allowance ? `${allowance.tier} (corrected by 429)` : 'discovered by rate limit',
      });
      return;
    }

    this.usages.set(seatIndex, {
      ...usage,
      calls: Math.max(usage.calls, allowance.maxCalls),
    });
  }

  /** Clear a seat's meter — on re-provisioning, or at a tier reset window. */
  reset(seatIndex: SeatIndex): void {
    this.usages.set(seatIndex, zeroUsage());
  }

  /** Every attributed dispatch, in order. */
  allRecords(): SeatDispatchRecord[] {
    return this.records.map((r) => ({ ...r }));
  }

  recordsForSeat(seatIndex: SeatIndex): SeatDispatchRecord[] {
    return this.records.filter((r) => r.seatIndex === seatIndex).map((r) => ({ ...r }));
  }

  /**
   * Dispatches grouped by the digest of what the seat was looking at.
   *
   * This is the join that makes cross-model comparison a measurement: every
   * record under one hash is a seat that provably saw byte-identical input.
   * Records with no hash are excluded rather than bucketed under a placeholder,
   * because an unhashed observation cannot be shown to be the same observation.
   */
  recordsByContentHash(): Map<string, SeatDispatchRecord[]> {
    const grouped = new Map<string, SeatDispatchRecord[]>();
    for (const record of this.records) {
      if (!record.contentHash) continue;
      const bucket = grouped.get(record.contentHash) ?? [];
      bucket.push({ ...record });
      grouped.set(record.contentHash, bucket);
    }
    return grouped;
  }

  /** Snapshot for the cockpit readout. */
  snapshot(): Array<{
    seatIndex: SeatIndex;
    tier: string;
    status: SeatBudgetStatus;
    usage: SeatUsage;
    remainingCalls: number | null;
  }> {
    const seats = new Set<SeatIndex>([...this.allowances.keys(), ...this.usages.keys()]);
    return [...seats]
      .sort((a, b) => a - b)
      .map((seatIndex) => ({
        seatIndex,
        tier: this.allowances.get(seatIndex)?.tier ?? 'unmetered',
        status: this.status(seatIndex),
        usage: this.usageFor(seatIndex),
        remainingCalls: this.remainingCalls(seatIndex),
      }));
  }
}

// ── helpers ──────────────────────────────────────────────────────────────

function zeroUsage(): SeatUsage {
  return { calls: 0, usd: 0, spentOnFailure: 0 };
}

function finiteOrZero(n: number): number {
  return Number.isFinite(n) ? n : 0;
}

/**
 * A limit that is negative, NaN, or Infinity is not a limit. Negative and NaN
 * become 0 — a seat with a nonsense allowance gets nothing rather than
 * everything, because the safe direction is refusing to spend. Infinity
 * becomes undefined, which is the honest encoding of "no ceiling".
 */
function normalizeLimit(n: number | undefined): number | undefined {
  if (n === undefined) return undefined;
  if (Number.isNaN(n)) return 0;
  if (!Number.isFinite(n)) return undefined;
  return Math.max(0, n);
}

/** Recognise a provider rate-limit response without depending on a client. */
export function isRateLimitError(error: unknown): boolean {
  if (!error) return false;
  const message = error instanceof Error ? error.message : String(error);
  return (
    /\b429\b/.test(message) ||
    /rate[ _-]?limit/i.test(message) ||
    /quota/i.test(message) ||
    /too many requests/i.test(message)
  );
}

// ── Process singleton ────────────────────────────────────────────────────

/**
 * One ledger per process, held on globalThis so Next's dev-mode module
 * reloading does not silently hand out a fresh meter mid-session — the same
 * pattern `cockpit.ts` uses for the Neuralink instance. A ledger that resets on
 * hot reload would under-count, which is the one direction this file is not
 * allowed to be wrong in.
 */
const globalForSeatBudget = globalThis as unknown as {
  __omniboxSeatBudget?: SeatBudgetLedger;
};

export const seatBudget: SeatBudgetLedger =
  globalForSeatBudget.__omniboxSeatBudget ?? new SeatBudgetLedger();

if (process.env.NODE_ENV !== 'production') {
  globalForSeatBudget.__omniboxSeatBudget = seatBudget;
}
