// Run with: node --experimental-strip-types src/harness/executor.test.mjs
//
// The executor gate. harness.test.mjs proves the lifecycle; harness-authority
// proves the boundary cannot be crossed; this file proves the parts that make
// a mission actually DO something -- tools reachable only through a grant,
// packs that mount without granting, skills that expand into plans, and the
// Passport reachable as a governed capability rather than a side door.

import { HarnessRuntime, InMemoryMissionStore } from './runtime.ts';
import { ToolExecutor, ExecutionRefused } from './executor.ts';
import { CapabilityRegistry } from './capabilities.ts';
import { PackRegistry, PackMountError } from './packs.ts';
import { corePack } from './packs/core-pack.ts';
import { passportPack } from './packs/passport-pack.ts';
import { validate } from './schema.ts';

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { console.log(`  ✓ ${name}`); passed++; }
  else { console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); failed++; }
}

const persisted = [];
const passport = {
  async loadContext() {
    return {
      passportId: 'passport-1',
      identity: { name: 'Owner', preferredName: 'O', timezone: 'America/Chicago', language: 'English' },
      memories: [
        {
          id: 'm1', title: 'Pooler port', content: 'Supabase transaction pooler uses port 6543.',
          status: 'evidenced', confidence: 0.9, pinned: true,
          evidence: ['https://supabase.com/docs'], tags: [], metadata: {},
        },
        {
          id: 'm2', title: 'Unrelated', content: 'Coffee is brewed at ninety-six degrees.',
          status: 'asserted', confidence: null, pinned: false, evidence: [], tags: [], metadata: {},
        },
      ],
    };
  },
  async persistMemoryCandidate(candidate) {
    persisted.push(candidate);
    return { memoryId: `mem-${persisted.length}` };
  },
};

async function boot(options = {}) {
  const harness = new HarnessRuntime({
    store: new InMemoryMissionStore(),
    passport,
    capabilities: new CapabilityRegistry(),
    mode: options.mode ?? 'execute',
  });
  harness.mount(corePack());
  harness.mount(passportPack(passport, { passportId: 'passport-1' }));
  const mission = await harness.createMission({
    passportId: 'passport-1',
    goal: 'exercise the executor',
    authority: {
      actorId: 'pilot',
      allowedCapabilityIds: options.granted ?? [
        'core.note', 'core.recall_note', 'core.record_evidence', 'core.list_evidence',
        'passport.search', 'passport.identity', 'passport.propose_memory',
      ],
      autoApproveRiskAtMost: 'transform',
    },
  });
  await harness.bindNeuralink(mission.id);
  await harness.beginPlanning(mission.id);
  return { harness, mission };
}

console.log('\n1. Schema validation\n');
{
  const schema = {
    type: 'object',
    properties: { path: { type: 'string', minLength: 1 }, count: { type: 'integer', minimum: 0 } },
    required: ['path'],
    additionalProperties: false,
  };
  check('a conforming object validates', validate(schema, { path: '/tmp/x', count: 2 }).length === 0);
  check('a missing required field is caught', validate(schema, { count: 2 }).length === 1);
  check('a wrong type is caught', validate(schema, { path: 5 }).length === 1);
  check('an unknown property is caught', validate(schema, { path: '/x', nope: 1 }).length === 1);
  check('a below-minimum number is caught', validate(schema, { path: '/x', count: -1 }).length === 1);
  check('an absent schema permits anything', validate(undefined, { anything: true }).length === 0);
}

console.log('\n2. The executor refuses everything it was not granted\n');
{
  const executor = new ToolExecutor();
  executor.register(
    { id: 't', name: 't', description: 't', risk: 'read', requiresApproval: false, inputSchema: { type: 'object' } },
    async () => ({ ran: true }),
  );
  const call = {
    id: 'c1', missionId: 'm1', capabilityId: 't',
    arguments: {}, argumentsDigest: 'digest-a', requestedAt: new Date().toISOString(),
  };

  let refused = false;
  try { await executor.execute(call); } catch (error) { refused = error instanceof ExecutionRefused; }
  check('an ungranted call is refused', refused);

  executor.issue({
    toolCallId: 'c1', missionId: 'm1', capabilityId: 't',
    argumentsDigest: 'digest-a', mode: 'execute', issuedAt: new Date().toISOString(),
  });
  let mismatched = false;
  try {
    await executor.execute({ ...call, argumentsDigest: 'digest-b' });
  } catch (error) { mismatched = error instanceof ExecutionRefused; }
  check('a grant cannot be spent on different arguments', mismatched);

  const ok = await executor.execute(call);
  check('a matching grant executes', ok.status === 'succeeded' && ok.output?.ran === true);

  let reused = false;
  try { await executor.execute(call); } catch (error) { reused = error instanceof ExecutionRefused; }
  check('a grant is single-use', reused);
}

console.log('\n3. Mounting a pack is not granting it\n');
{
  const { harness, mission } = await boot({ granted: ['core.note'] });
  const manifest = await harness.capabilityManifest(mission.id);
  check('the manifest is the intersection of mounted and granted',
    manifest.length === 1 && manifest[0].id === 'core.note',
    `got ${manifest.map((entry) => entry.id).join(',')}`);

  let denied = false;
  try {
    await harness.runTool({ missionId: mission.id, capabilityId: 'passport.search', arguments: { query: 'x' } });
  } catch (error) { denied = error instanceof ExecutionRefused; }
  check('a mounted but ungranted capability is refused', denied);

  const packs = harness.listPacks();
  check('mounted packs are inspectable', packs.length === 2 && packs.some((pack) => pack.id === 'passport'));
}

{
  const capabilities = new CapabilityRegistry();
  const registry = new PackRegistry(capabilities, new ToolExecutor());
  let rejected = false;
  try {
    registry.mount({
      id: 'bad', name: 'bad', description: 'bad', version: '1.0.0', maxRisk: 'read',
      tools: [{
        descriptor: {
          id: 'bad.delete', name: 'd', description: 'd', risk: 'delete',
          requiresApproval: true, inputSchema: { type: 'object' },
        },
        implementation: async () => null,
      }],
    });
  } catch (error) { rejected = error instanceof PackMountError; }
  check('a pack cannot mount a tool above its own declared risk ceiling', rejected);
}

console.log('\n4. Pilot handles carry no second path to a tool\n');
{
  const { harness, mission } = await boot();
  const handles = await harness.handlesFor(mission.id);
  const note = handles.find((handle) => handle.capabilityId === 'core.note');
  check('a handle exists for each granted capability', handles.length === 7);
  check('a handle exposes no implementation and no registry',
    note !== undefined
    && Object.keys(note).sort().join(',') === 'capabilityId,description,inputSchema,invoke,name,risk');

  const result = await note.invoke({ key: 'finding', value: 'the pooler port is 6543' });
  check('invoking a handle runs the tool', result.status === 'succeeded' && result.output?.stored === true);

  const audit = await harness.auditToolAuthority(mission.id);
  check('the event spine proves every invocation was authorized first',
    audit.ok === true && audit.invocations === 1, JSON.stringify(audit.violations));
}

console.log('\n5. Skills expand into plans without touching a tool\n');
{
  const { harness, mission } = await boot();
  const skills = await harness.availableSkills(mission.id);
  check('skills from every mounted pack are offered', skills.length === 3,
    skills.map((skill) => skill.id).join(','));

  const steps = harness.planSkill('passport.recall-then-answer', { question: 'what port does the pooler use' });
  check('a skill expands its argument template',
    steps[0].argumentsTemplate?.query === 'what port does the pooler use');
  check('a skill may contain reasoning-only steps', steps.some((step) => !step.capabilityId));

  const narrow = await boot({ granted: ['core.note'] });
  const runnable = await narrow.harness.availableSkills(narrow.mission.id);
  check('a skill the mission cannot complete is not offered', runnable.length === 0);
}

console.log('\n6. The Passport is reachable, and writing to it needs a human\n');
{
  const { harness, mission } = await boot();
  const found = await harness.runTool({
    missionId: mission.id, capabilityId: 'passport.search', arguments: { query: 'pooler port' },
  });
  check('a mission can read its Passport through a capability',
    found.output?.matched === 1 && found.output?.results[0].id === 'm1');
  check('a recalled memory arrives with its evidence, not as a bare claim',
    found.output?.results[0].evidence.length > 0 && found.output?.results[0].status === 'evidenced');

  let gated = false;
  try {
    await harness.runTool({
      missionId: mission.id, capabilityId: 'passport.propose_memory',
      arguments: { content: 'A new fact.', scope: 'this mission only', evidence: ['run://1'] },
    });
  } catch (error) { gated = error instanceof ExecutionRefused; }
  check('writing to the Passport always stops for approval', gated && persisted.length === 0);

  const events = await harness.auditToolAuthority(mission.id);
  check('the blocked write produced no invocation', events.invocations === 1);
}

console.log('\n7. An approved write lands as a candidate, never a promoted memory\n');
{
  const { harness, mission } = await boot();
  const request = await harness.requestTool({
    missionId: mission.id, id: 'write-1', capabilityId: 'passport.propose_memory',
    arguments: { content: 'The pooler needs postgres.<ref> as the username.', scope: 'Supabase pooler connections', evidence: ['run://db-setup'] },
  });
  check('the write enters the approval path', request.authorization.decision === 'require_approval');

  await harness.decideApproval(mission.id, {
    approvalId: 'appr-1', toolCallId: 'write-1', decision: 'approve', actorId: 'human',
    decidedAt: new Date().toISOString(),
  });
  const result = await harness.executeAuthorized(request.toolCall);
  check('the approved write executes', result.status === 'succeeded');
  check('it lands as a candidate', persisted.at(-1)?.status === 'candidate');
  check('the candidate carries its scope and evidence',
    persisted.at(-1)?.scope === 'Supabase pooler connections' && persisted.at(-1)?.evidence.length === 1);

  const audit = await harness.auditToolAuthority(mission.id);
  check('the approved invocation still pairs with its grant', audit.ok === true);
}

console.log('\n8. Dry-run mode is the harness\'s, and it changes nothing in the world\n');
{
  const before = persisted.length;
  const { harness, mission } = await boot({ mode: 'dry_run' });
  const request = await harness.requestTool({
    missionId: mission.id, id: 'dry-1', capabilityId: 'passport.propose_memory',
    arguments: { content: 'Simulated.', scope: 'nowhere', evidence: ['run://x'] },
  });
  check('dry-run mode does not lower what a capability requires',
    request.authorization.decision === 'require_approval');
  await harness.decideApproval(mission.id, {
    approvalId: 'appr-2', toolCallId: 'dry-1', decision: 'approve', actorId: 'human',
    decidedAt: new Date().toISOString(),
  });
  const result = await harness.executeAuthorized(request.toolCall);
  check('the tool simulates instead of writing',
    result.mode === 'dry_run' && result.output?.simulated === true && persisted.length === before);
}

console.log('\n9. Cancelling a mission destroys its tool authority\n');
{
  const { harness, mission } = await boot();
  const cancelled = await harness.cancelMission(mission.id, 'human', 'operator stopped it');
  check('cancel is terminal', cancelled.status === 'CANCELLED');
  let refused = false;
  try {
    await harness.runTool({ missionId: mission.id, capabilityId: 'core.note', arguments: { key: 'k', value: 1 } });
  } catch (error) { refused = error instanceof ExecutionRefused; }
  check('no tool runs after cancellation', refused);
}

console.log(`\n${passed} passed, ${failed} failed`);
console.log(
  '\nWhat this does NOT establish: that the pilot has no second path to a tool.\n' +
  'The executor makes a grant the only way IN, and auditToolAuthority() proves\n' +
  'the pairing over the event spine. Neither can see a pilot that holds its own\n' +
  'credentials or imports a tool module directly. That is an architectural\n' +
  'property and belongs in CI as an import-boundary check, not here.',
);
process.exit(failed === 0 ? 0 : 1);
