// Run with: node --experimental-strip-types src/harness/flight-recorder.test.mjs
//
// The plane learns from the pilots who fly it.
//
// Two claims are under test. First, that a pilot reaching for something this
// plane does not carry produces a RECORD rather than a wall -- the request is
// kept, attributed, and surfaced as a build queue. Second, that a sequence a
// pilot flies successfully often enough, across more than one mission, without
// ever failing, becomes a skill the plane owns.

import { HarnessRuntime, InMemoryMissionStore, CapabilityUnavailable } from './runtime.ts';
import { CapabilityRegistry } from './capabilities.ts';
import { FlightRecorder, PROMOTE_AFTER } from './flight-recorder.ts';
import { corePack } from './packs/core-pack.ts';

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { console.log(`  ✓ ${name}`); passed++; }
  else { console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); failed++; }
}

const passport = {
  async loadContext() {
    return { passportId: 'p1', identity: { name: 'Owner' }, memories: [] };
  },
  async persistMemoryCandidate() { return { memoryId: 'm1' }; },
};

async function boot(harness) {
  const mission = await harness.createMission({
    passportId: 'p1',
    goal: 'fly something',
    authority: {
      actorId: 'pilot',
      allowedCapabilityIds: ['core.note', 'core.recall_note', 'core.record_evidence', 'core.list_evidence'],
      autoApproveRiskAtMost: 'transform',
    },
  });
  await harness.bindNeuralink(mission.id);
  await harness.beginPlanning(mission.id);
  return mission;
}

function newHarness() {
  const harness = new HarnessRuntime({
    store: new InMemoryMissionStore(), passport, capabilities: new CapabilityRegistry(),
  });
  harness.mount(corePack());
  return harness;
}

console.log('\n1. A pilot may reach for anything; the plane records what it lacks\n');
{
  const harness = newHarness();
  const mission = await boot(harness);

  let error = null;
  try {
    await harness.runTool({
      missionId: mission.id, capabilityId: 'browser.screenshot',
      arguments: { url: 'https://example.com' }, intent: 'see what the page looks like',
    });
  } catch (caught) { error = caught; }

  check('an unknown capability does not crash the harness', error instanceof CapabilityUnavailable);
  check('the pilot is told the plane lacks it, not that it is forbidden',
    /does not carry/.test(String(error?.message)) && !/forbidden|not allowed|denied/i.test(String(error?.message)));

  const gaps = harness.capabilityGaps();
  check('the gap is recorded', gaps.length === 1 && gaps[0].capabilityId === 'browser.screenshot');
  check('the pilot\'s intent is kept with it', gaps[0].intents[0] === 'see what the page looks like');
  check('the gap is on the mission\'s own event spine',
    (await harness.auditToolAuthority(mission.id)).ok === true);
}

console.log('\n2. An unknown SKILL is a gap too, not a refusal\n');
{
  const harness = newHarness();
  const mission = await boot(harness);
  const skill = await harness.requestSkill(mission.id, 'research.deep-dive', 'wanted a research routine');
  check('an unknown skill returns null rather than throwing', skill === null);
  const gaps = harness.capabilityGaps();
  check('it is recorded as a skill gap', gaps[0].capabilityId === 'skill:research.deep-dive');

  const known = await harness.requestSkill(mission.id, 'core.evidence-first');
  check('a skill the plane does carry is returned', known?.id === 'core.evidence-first');
  check('a satisfied request is not recorded as a gap', harness.capabilityGaps().length === 1);
}

console.log('\n3. The gap report is a build queue written by use\n');
{
  const harness = newHarness();
  for (let i = 0; i < 3; i += 1) {
    const mission = await boot(harness);
    try {
      await harness.runTool({
        missionId: mission.id, capabilityId: 'browser.screenshot', arguments: {}, intent: `run ${i}`,
      });
    } catch { /* recorded */ }
  }
  const mission = await boot(harness);
  try {
    await harness.runTool({ missionId: mission.id, capabilityId: 'shell.exec', arguments: {} });
  } catch { /* recorded */ }

  const report = harness.capabilityGaps();
  check('the most-wanted capability sorts first',
    report[0].capabilityId === 'browser.screenshot' && report[0].requests === 3);
  check('it counts distinct missions, not just requests', report[0].missions === 3);
  check('every distinct intent is kept', report[0].intents.length === 3);
  check('a one-off request is still recorded', report.some((entry) => entry.capabilityId === 'shell.exec'));
}

console.log('\n4. The plane learns a manoeuvre by watching it work\n');
{
  const recorder = new FlightRecorder();
  const sequence = ['core.note', 'core.record_evidence', 'core.list_evidence'];

  check('a single call is not a manoeuvre',
    recorder.recordManoeuvre({ missionId: 'm0', sequence: ['core.note'], succeeded: true }) === null);

  for (let i = 0; i < PROMOTE_AFTER; i += 1) {
    recorder.recordManoeuvre({ missionId: `m${i}`, sequence, succeeded: true });
  }
  const flown = recorder.manoeuvreReport();
  check('the sequence is counted', flown[0].successes === PROMOTE_AFTER);
  check('it is attributed to every mission that flew it', flown[0].missionIds.length === PROMOTE_AFTER);

  const promotable = recorder.promotable();
  check('it has earned promotion', promotable.length === 1);

  const learned = recorder.promote(promotable[0].signature);
  check('the learned skill keeps the observed order',
    learned.skill.steps.map((step) => step.capabilityId).join(',') === sequence.join(','));
  check('it requires exactly the capabilities it flew',
    learned.skill.requiredCapabilityIds.sort().join(',') === [...sequence].sort().join(','));
  check('it carries replayable evidence, not a bare claim',
    learned.evidence.length === PROMOTE_AFTER && learned.evidence.every((entry) => entry.startsWith('mission://')));
  check('it is not promoted twice', recorder.promotable().length === 0);
}

console.log('\n5. Repetition promotes; a single contradiction blocks\n');
{
  const recorder = new FlightRecorder();
  const sequence = ['core.note', 'core.list_evidence'];
  for (let i = 0; i < PROMOTE_AFTER; i += 1) {
    recorder.recordManoeuvre({ missionId: `m${i}`, sequence, succeeded: true });
  }
  recorder.recordManoeuvre({ missionId: 'm-bad', sequence, succeeded: false });
  check('one failure blocks a manoeuvre that had already earned it', recorder.promotable().length === 0);

  let refused = false;
  try { recorder.promote(sequence.join(' -> ')); } catch { refused = true; }
  check('promoting it anyway is refused', refused);
}

{
  const recorder = new FlightRecorder();
  const sequence = ['core.note', 'core.list_evidence'];
  for (let i = 0; i < PROMOTE_AFTER; i += 1) {
    recorder.recordManoeuvre({ missionId: 'same-mission', sequence, succeeded: true });
  }
  check('five successes inside ONE mission is one pilot repeating itself, not evidence',
    recorder.promotable().length === 0);
}

console.log('\n6. The plane learns from its own audit trail, then flies it\n');
{
  const harness = newHarness();
  for (let i = 0; i < PROMOTE_AFTER; i += 1) {
    const mission = await boot(harness);
    await harness.runTool({ missionId: mission.id, capabilityId: 'core.note', arguments: { key: 'k', value: i } });
    await harness.runTool({
      missionId: mission.id, capabilityId: 'core.record_evidence',
      arguments: { pointer: `run://${i}`, supports: 'it worked', origin: 'observed' },
    });
    await harness.runTool({ missionId: mission.id, capabilityId: 'core.list_evidence', arguments: {} });
    await harness.recordFlight(mission.id);
  }

  const learnable = harness.learnableSkills();
  check('the manoeuvre was reconstructed from the event spine alone', learnable.length === 1,
    JSON.stringify(harness.flownManoeuvres().map((entry) => entry.signature)));

  const learned = harness.learnSkill(learnable[0].signature);
  check('the learned skill is named for what it does', learned.skill.id.startsWith('learned.'));

  const mission = await boot(harness);
  const available = await harness.availableSkills(mission.id);
  check('a later mission can fly the skill without being taught the sequence',
    available.some((skill) => skill.id === learned.skill.id));

  const steps = harness.planSkill(learned.skill.id);
  check('it expands into the same three steps', steps.length === 3);
  check('a learned skill still carries no authority of its own',
    steps.every((step) => step.capabilityId !== undefined)
    && (await harness.capabilityManifest(mission.id)).length === 4);
}

console.log(`\n${passed} passed, ${failed} failed`);
console.log(
  '\nCeiling: a learned skill is a sequence that WORKED, which is not the same\n' +
  'as a sequence that was RIGHT. The recorder cannot see whether the mission\n' +
  'should have been flown that way, only that it completed without failing.\n' +
  'Outcome quality is the loop\'s job, not the recorder\'s.',
);
process.exit(failed === 0 ? 0 : 1);
