"use client";

import { useCallback, useEffect, useState } from "react";
import type { Passport } from "@/lib/types";
import { LandingHero } from "@/components/LandingHero";
import { PassportList } from "@/components/PassportList";
import { PassportDashboard } from "@/components/PassportDashboard";
import { CreatePassportModal } from "@/components/CreatePassportModal";
import { ImportModal } from "@/components/ImportModal";
import {
  Shield,
  ArrowLeft,
  Upload,
  Plus,
  FlaskConical,
  Plane,
  Globe,
  RotateCcw,
  EyeOff,
} from "lucide-react";
import Link from "next/link";

type Modal = "create" | "import" | null;

export default function PassportPage() {
  const [passports, setPassports] = useState<Passport[]>([]);
  const [hidden, setHidden] = useState<Passport[]>([]);
  const [selected, setSelected] = useState<Passport | null>(null);
  const [modal, setModal] = useState<Modal>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [restoringId, setRestoringId] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [liveRes, hiddenRes] = await Promise.all([
        fetch("/api/passports"),
        fetch("/api/passports?view=hidden"),
      ]);
      if (!liveRes.ok) throw new Error(`HTTP ${liveRes.status}`);
      const liveData = await liveRes.json();
      setPassports(Array.isArray(liveData) ? liveData : []);
      if (hiddenRes.ok) {
        const hiddenData = await hiddenRes.json();
        setHidden(Array.isArray(hiddenData) ? hiddenData : []);
      }
      setError(null);
    } catch {
      setError(
        "Could not reach the passport store. Check the database connection, then reload.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Fetch-on-mount. Writes land after the network round trip.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load();
  }, [load]);

  const handleCreated = (p: Passport) => {
    setPassports((prev) => [p, ...prev]);
    setModal(null);
    setSelected(p);
  };

  const handleImported = (p: Passport) => {
    setPassports((prev) => [p, ...prev]);
    setModal(null);
    setSelected(p);
  };

  const handleDeleted = (id: string) => {
    const gone = passports.find((p) => p.id === id);
    setPassports((prev) => prev.filter((p) => p.id !== id));
    if (gone) setHidden((prev) => [gone, ...prev]);
    setSelected(null);
  };

  const handleUpdated = (p: Passport) => {
    setPassports((prev) => prev.map((x) => (x.id === p.id ? p : x)));
    setSelected(p);
  };

  const handleRestore = async (p: Passport) => {
    setRestoringId(p.id);
    try {
      const res = await fetch(`/api/passports/${p.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ restore: true }),
      });
      if (!res.ok) throw new Error("restore failed");
      const restored = (await res.json()) as Passport;
      setHidden((prev) => prev.filter((x) => x.id !== p.id));
      setPassports((prev) => [restored, ...prev]);
      setSelected(restored);
    } catch {
      setError("Could not bring that passport back. Try again.");
    } finally {
      setRestoringId(null);
    }
  };

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-[#0f1729]/70 border-b border-white/[0.06]">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <button
            onClick={() => setSelected(null)}
            className="flex items-center gap-2.5 text-white font-bold tracking-tight"
          >
            <span className="h-8 w-8 rounded-lg bg-gradient-to-br from-passport-500 to-passport-700 flex items-center justify-center shadow-lg shadow-passport-500/20">
              <Shield className="h-4 w-4" />
            </span>
            Memory Passport
          </button>

          <div className="flex items-center gap-2">
            <Link
              href="/cockpit"
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium bg-white/10 hover:bg-white/15 text-white rounded-lg transition border border-white/10"
            >
              <Plane className="h-4 w-4" />
              Cockpit
            </Link>
            <Link
              href="/browser"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition"
            >
              <Globe className="h-4 w-4" />
              Browser
            </Link>
            <Link
              href="/functions"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition"
            >
              Gun base
            </Link>
            <Link
              href="/lab"
              className="hidden sm:flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition"
            >
              <FlaskConical className="h-4 w-4" />
              Lab
            </Link>
            <button
              onClick={() => setModal("import")}
              className="flex items-center gap-2 px-3 py-2 text-sm text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition"
            >
              <Upload className="h-4 w-4" />
              Import
            </button>
            <button
              onClick={() => setModal("create")}
              className="flex items-center gap-2 px-3.5 py-2 text-sm font-medium bg-passport-600 hover:bg-passport-500 text-white rounded-lg transition shadow-lg shadow-passport-600/20"
            >
              <Plus className="h-4 w-4" />
              New
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-5 pb-24">
        {error && (
          <div className="mt-6 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200">
            {error}
          </div>
        )}

        {loading ? (
          <div className="py-32 text-center text-slate-400">Loading passports…</div>
        ) : selected ? (
          <div className="pt-8">
            <button
              onClick={() => setSelected(null)}
              className="flex items-center gap-2 mb-6 text-sm text-slate-400 hover:text-white transition"
            >
              <ArrowLeft className="h-4 w-4" />
              All passports
            </button>
            <PassportDashboard
              passport={selected}
              onDeleted={handleDeleted}
              onUpdated={handleUpdated}
            />
          </div>
        ) : passports.length === 0 ? (
          <>
            <LandingHero
              onCreateClick={() => setModal("create")}
              onImportClick={() => setModal("import")}
            />
            {hidden.length > 0 && (
              <HiddenPassports
                hidden={hidden}
                restoringId={restoringId}
                onRestore={handleRestore}
              />
            )}
          </>
        ) : (
          <div className="pt-10">
            <PassportList
              passports={passports}
              onSelect={setSelected}
              onCreateClick={() => setModal("create")}
            />
            {hidden.length > 0 && (
              <HiddenPassports
                hidden={hidden}
                restoringId={restoringId}
                onRestore={handleRestore}
              />
            )}
          </div>
        )}
      </div>

      {modal === "create" && (
        <CreatePassportModal
          onClose={() => setModal(null)}
          onCreated={handleCreated}
        />
      )}
      {modal === "import" && (
        <ImportModal onClose={() => setModal(null)} onImported={handleImported} />
      )}
    </main>
  );
}

function HiddenPassports({
  hidden,
  restoringId,
  onRestore,
}: {
  hidden: Passport[];
  restoringId: string | null;
  onRestore: (p: Passport) => void;
}) {
  return (
    <section className="mt-16 pt-8 border-t border-white/[0.06]">
      <div className="flex items-center gap-2 mb-4 text-slate-400">
        <EyeOff className="h-4 w-4" />
        <h3 className="text-sm font-semibold tracking-wide uppercase">
          Hidden — still here
        </h3>
      </div>
      <p className="text-sm text-slate-500 mb-4 max-w-xl">
        Deleting a passport hides it. The memories and their history stay.
        Bring one back whenever you want.
      </p>
      <ul className="space-y-2">
        {hidden.map((p) => (
          <li
            key={p.id}
            className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.06]"
          >
            <div className="min-w-0">
              <p className="text-sm font-medium text-slate-200 truncate">{p.name}</p>
              <p className="text-xs text-slate-500">
                Hidden, not erased
                {p.preferredName ? ` · ${p.preferredName}` : ""}
              </p>
            </div>
            <button
              onClick={() => onRestore(p)}
              disabled={restoringId === p.id}
              className="flex items-center gap-2 px-3 py-1.5 text-sm text-passport-200 hover:text-white rounded-lg hover:bg-white/5 transition disabled:opacity-50"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              {restoringId === p.id ? "Bringing back…" : "Bring back"}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
