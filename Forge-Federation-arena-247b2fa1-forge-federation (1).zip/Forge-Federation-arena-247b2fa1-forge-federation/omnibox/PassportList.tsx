"use client";

import type { Passport } from "@/lib/types";
import { Shield, Plus, Clock, Globe } from "lucide-react";

interface Props {
  passports: Passport[];
  onSelect: (p: Passport) => void;
  onCreateClick: () => void;
}

export function PassportList({ passports, onSelect, onCreateClick }: Props) {
  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white">Your Passports</h2>
          <p className="text-sm text-slate-400 mt-1">
            {passports.length} passport{passports.length !== 1 ? "s" : ""}
          </p>
        </div>
        <button
          onClick={onCreateClick}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium bg-passport-600 hover:bg-passport-500 text-white rounded-xl transition shadow-lg shadow-passport-600/20"
        >
          <Plus className="h-4 w-4" />
          New Passport
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {passports.map((p, i) => (
          <button
            key={p.id}
            onClick={() => onSelect(p)}
            className="text-left p-6 rounded-2xl bg-white/[0.03] border border-white/[0.06] hover:border-passport-500/30 hover:bg-white/[0.06] transition group glow-card"
            style={{ animationDelay: `${i * 100}ms` }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-passport-500 to-passport-700 flex items-center justify-center shadow-lg shadow-passport-500/20">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <span className="text-xs font-mono text-passport-400 bg-passport-400/10 px-2 py-1 rounded-md">
                .mpx
              </span>
            </div>

            <h3 className="font-bold text-white text-lg mb-1 group-hover:text-passport-300 transition">
              {p.name}
            </h3>
            {p.preferredName && (
              <p className="text-sm text-slate-400 mb-3">
                aka &ldquo;{p.preferredName}&rdquo;
              </p>
            )}

            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <Globe className="h-3 w-3" />
                {p.timezone || "UTC"}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {new Date(p.createdAt).toLocaleDateString()}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
