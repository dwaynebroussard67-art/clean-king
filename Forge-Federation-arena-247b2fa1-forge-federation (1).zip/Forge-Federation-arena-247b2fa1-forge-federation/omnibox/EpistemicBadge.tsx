"use client";

import type { Memory } from "@/lib/types";
import { ShieldCheck, FileSearch, MessageSquareWarning, Download } from "lucide-react";

/**
 * How well established a claim is, shown next to the claim.
 *
 * This is not decoration. The whole point of the passport is that a reader can
 * tell a checked finding from somebody's confident guess — if that distinction
 * only exists in the database, it does not exist where it matters.
 *
 * Mirrors src/lib/epistemic.ts. The server is authoritative; this recomputes
 * the display from the same fields so a list render does not need a join, and
 * resolves *downward* whenever it lacks information.
 */
export function epistemicOf(memory: Memory): {
  status: "adjudicated" | "evidenced" | "asserted";
  imported: boolean;
} {
  const imported = memory.origin === "imported";
  const metadata = memory.metadata ?? {};
  const hasEvidence =
    !!metadata &&
    typeof metadata === "object" &&
    ["evidence", "source", "sources", "url", "file", "path", "commit", "run"].some((key) => {
      const value = (metadata as Record<string, unknown>)[key];
      return Array.isArray(value) ? value.length > 0 : typeof value === "string" && !!value.trim();
    });

  // A digest is required for 'adjudicated'. The client cannot hash the content
  // cheaply on every render, so it trusts the server to have cleared the stamp
  // on edit — and shows the weaker status if either field is absent.
  if (memory.adjudicatedAt && memory.adjudicatedDigest) {
    return { status: "adjudicated", imported };
  }
  return { status: hasEvidence ? "evidenced" : "asserted", imported };
}

const STYLES = {
  adjudicated: {
    icon: ShieldCheck,
    label: "checked",
    title: "Verified here against evidence, and against this exact wording.",
    className: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20",
  },
  evidenced: {
    icon: FileSearch,
    label: "evidence attached",
    title: "Carries a pointer to evidence, but nobody has verified it here.",
    className: "bg-sky-500/10 text-sky-300 border-sky-500/20",
  },
  asserted: {
    icon: MessageSquareWarning,
    label: "asserted",
    title: "Somebody's word. No evidence attached, nothing checked.",
    className: "bg-amber-500/10 text-amber-300 border-amber-500/20",
  },
} as const;

export function EpistemicBadge({ memory }: { memory: Memory }) {
  const { status, imported } = epistemicOf(memory);
  const style = STYLES[status];
  const Icon = style.icon;

  return (
    <span className="inline-flex items-center gap-1">
      <span
        title={style.title}
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium border ${style.className}`}
      >
        <Icon className="h-3 w-3" />
        {style.label}
      </span>
      {imported && (
        <span
          title="Arrived from another passport. Its confidence is its author's claim, not a finding checked here."
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium border bg-violet-500/10 text-violet-300 border-violet-500/20"
        >
          <Download className="h-3 w-3" />
          imported
        </span>
      )}
    </span>
  );
}
