# The Coding Relay — the product that was missing

*You put your finger on it: coding is where every "big dog" is strong, and —
more importantly — where agreement can be **proven**, not argued. This is the
flagship. Here's the whole thing thought through, and ten ways it becomes money.*

---

## Why coding changes everything

In every other domain, "is this answer right?" is a judgment call. The
passport's witness model is brilliant there, but the *verdict* is still human.

Code is different. Code answers with a green light:

- **Does it compile?** — mechanical.
- **Do the tests pass?** — mechanical.
- **Did the attack land?** — mechanical.
- **Does the contradiction resolve?** — one seat says "there's an off-by-one
  here," the other four say "no there isn't" — and the build decides who's right.

That means the relay loop you're describing isn't just a nice product. It's the
**one place the whole Forge Flight architecture becomes falsifiable end-to-end**:
the seats write, the loop verifies, and the *build* is the final witness. The
human stops being the oracle and becomes the person who reads the audit trail.

---

## The loop maps onto machinery that already exists

This is the part that should make you excited — most of the memory substrate
you described is **already built**. What's missing is the loop harness, not the
philosophy.

| Your idea | Where it already lives | Status |
|---|---|---|
| 5–8 seats linked, one relay | `relay` shape in `src/main/table.js` — draft passes down the line, each hand improves it and says in one line what it changed | ✅ exists (linear, **capped at 4 rounds**) |
| "Knowledge of everything the ones before them tried and didn't work" | **`flight-recorder.ts` MANEUVERS** — sequences of actions that worked are recorded; **5 successes promote** a maneuver, **one failure blocks it**. This is *literally* the memory of what worked and what didn't. | ✅ exists |
| "What tool did the last hand reach for that we don't have?" | **`flight-recorder.ts` GAPS** — every capability a pilot asked for that isn't mounted. The loop's own wishlist, for free. | ✅ exists |
| "5 eyes find the hole" | **Passport witnesses** — 5 distinct witnesses promote a claim; **one contradiction closes it**. "Four seats say this line is safe, one says it's exploitable" is a passport event happening now. | ✅ exists |
| An agent that acts but can't just run wild | **`capabilities.ts` + `gate.ts`** — risk-ranked actions (`read`/`transform`/`create`/`update`/`delete`/`external_side_effect`), every authorization is `allow` / `require_approval` / `deny`. A code pilot would write files *through this gate*. | ✅ exists |
| Don't let it spend all your money | **`seat-budget.ts`** — charged *before* dispatch, per-seat allowances, hard caps, a spent seat is **ejected, not billed**. This is how a runaway 8-seat loop doesn't bankrupt the little guy. | ✅ exists |
| The security culture | **`docs/RED-TEAM-MOBILE.md`, the adversarial fixtures** — the team already red-teams its own product; that's the same muscle as red-teaming code. | ✅ exists |

---

## The honest gaps (name them, then build them)

Three things do **not** exist yet, and one rule must be bent on purpose:

1. **The loop itself.** Relay today is 4 rounds, linear, text-only, and ends. A
   coding loop needs: a build/run/test harness, git, a *stop condition* (tests
   green / budget spent / round cap), and the ability to loop *back* to seat one
   with the failure knowledge from the flight recorder loaded as context.

2. **A code-acting pilot.** Pilots today click and type on web pages (`src/main/pilots.js`).
   A code pilot needs `file.write`, `exec`, `git.commit` — all routed through the
   capability registry and the gate. The good news: the risk ranks and the
   approval gate are already written for exactly this.

3. **The rule to bend, deliberately.** README rule #1 is **"User-triggered only.
   No scheduler, no polling, no background querying."** A truly *continuous*
   loop contradicts it. The resolution that keeps the ethos intact:

   > The loop is **launched, budgeted, capped, gated, and stoppable.** It only
   runs while you're watching. Every commit is *proposed*, never pushed — the
   human releases, exactly like the Federation's "you are step four." And the
   failure knowledge persists in the flight recorder **between** flights, so a
   new run starts already knowing what the last five hands tried and broke.

   "Autonomous, never unattended." That sentence is a *feature*, and it's
   sellable.

---

## The power picture

Eight seats in relay. You hand the table a broken repo and one sentence: "make
the auth flow pass these tests, and find every way it can be broken." Seat one
reads the code. Seat two receives it and fixes. Seat three receives that and
attacks it. The loop runs, the build is the referee, and the flight recorder
writes down every maneuver that failed and every gap that appeared — so the next
loop doesn't repeat them. When tests go green, the passport holds the record:
*five witnesses agreed the session is sound, one seat found a hole and named it,
here's the hash chain proving none of this was edited.*

That is not a chat app. That is a **forge**.

---

# Ten ways the coding relay becomes a business

## 1. The Code Forge — the flagship itself

**What it is.** The loop, productized. A "Dev seats" mode: N seats in relay over
a codebase, the build/run/test harness as the referee, the flight recorder as
memory, stop-on-green. The free tier keeps bounded local loops; the paid tier
unlocks more seats, longer flights, and maneuver memory that persists across
sessions (so your loop *actually gets smarter* over time).

**Why it's the centerpiece.** It's the only one of the ten that *is* the vision
you described, and it's the thing every other avenue below is selling a slice
of. This is the "imagine the power of that" moment, shipped.

**Little-guy price.** **$9/mo or $99 one-time.** Bounded free tier so a broke
freelancer can still run a 4-seat local loop.

**Catch.** The heaviest build: harness, code pilot, git, stop conditions. It's
the engine — sequence it as the centerpiece that everything else plugs into,
not a month-one launch.

---

## 2. Pay-per-flight with hard caps (the loop's meter is the invoice)

**What it is.** A loop that runs 8 models continuously burns tokens like a
furnace. So you don't sell "unlimited." You sell **flights**: bounded runs with
a declared budget, charged against `seat-budget.ts` *before* dispatch, and a
hard dollar cap the user sets. A seat that runs out is ejected, never billed.
BYO-key optional.

**Why it fits.** The metering philosophy is already in the code — "charge before
the request leaves, no refunds on failure, overcount never undercount." The
flight is the natural unit: small, bounded, and *stoppable*, which is exactly
what "user-triggered only" wants.

**Little-guy price.** **$2–$6 per capped flight, or $15/mo for 10 flights.** The
selling line: *you cannot get a surprise bill, by construction.*

**Catch.** Token cost is real and volatile — price at ~3× worst-case cost and
re-check monthly. This is also the avenue that makes the "no account" promise
bend; be explicit that flights are optional and the local app never phones home
without one.

---

## 3. N-eyes code review — the everyday killer

**What it is.** Fan a PR, a diff, or a whole file to 5 seats. Each reviews.
Where four agree, you get a **witness**; where one disagrees, you get a
**contradiction** — named, timestamped, hash-chained. Deliver a one-page
tamper-evident review: *"four seats cleared this; seat three flagged the
condition on line 47; here's the proof it wasn't edited after the fact."*

**Why it fits.** Code review is the highest-frequency, lowest-friction coding
task in existence, and it's *exactly* the passport's witness model — agreement
is a real count, disagreement is a contradiction happening now.

**Little-guy price.** **$9/mo unlimited for a solo dev, or $2 per review.**
Freelancers and 3-person shops pay this without thinking.

**Catch.** Must be loud that it's *evidence of review*, not a security
guarantee. One "your AI said it was fine and we got hacked" story is a
liability. Frame it as "proof of attention," not "proof of safety."

---

## 4. Red-team-as-a-service (the adversarial loop on code)

**What it is.** One seat writes, the rest try to break it — the `adversarial`
shape applied to a codebase. Then the *loop*: every hole found is fed back, the
writer patches, the attackers re-attack, and the flight recorder keeps the score.
Deliver the hash-chained audit: what was found, what was patched, what survived.

**Why it fits.** You literally named it — "they're also good at finding holes in
code." And the repo already treats red-teaming as a first-class discipline
(`RED-TEAM-MOBILE.md`, the adversarial fixtures that "found two real bugs").
This is the highest-margin product in the portfolio because the buyer is scared.

**Little-guy price.** **$19–$49 per audit**, or included in the team tier. A
small shop pays one audit to find the bug their client would have found first.

**Catch.** The highest liability of all ten: a missed hole costs real money.
Contract language matters — "adversarial review, not a guarantee." And cap
scope per audit so costs stay predictable.

---

## 5. Bug-fix relay (pay per incident, success is mechanical)

**What it is.** Paste a failing test (or a bug report) and the repo. Seats take
turns proposing a fix — each hand sees the prior hands' failures from the flight
recorder as context. The loop stops when the test passes. You bill only on the
run, and "did it work" is decided by the build, not by opinion.

**Why it fits.** The mechanical success criterion makes this the *most honest
billing in software*: no argument about whether the fix was good, the green
light decides. And the "knowledge of what the prior hands tried and didn't
work" is literally the flight recorder's maneuver log.

**Little-guy price.** **$5–$15 per incident.** Cheaper than an hour of a
contractor, with a receipt proving what was tried.

**Catch.** Model confidence is high on small, well-scoped bugs and collapses on
big, architectural ones. Scope it: "small, bounded, test-covered bugs." Refuse
the rest with a named reason — the product already knows how to refuse honestly.

---

## 6. Legacy-code comprehension & porting

**What it is.** The witness model, pointed at *understanding*: 5 seats read an
unfamiliar codebase and each states "what this module does." Where they agree,
you get a **supported claim**; where they disagree, you get a contradiction —
and the contradiction is the *interesting* part, because it's where the code is
genuinely ambiguous. Then the relay ports or refactors it with the agreed
understanding as context.

**Why it fits.** "What does this 15-year-old Perl script actually do?" is a
real, expensive problem, and it's one where *five agreeing witnesses* is
genuinely better than one confident model. The passport's equation form
(`module(x) = does_y`) is built for exactly this kind of claim.

**Little-guy price.** **$49–$199 per project** or hourly consulting with the
report as the deliverable. A small business inheriting a codebase pays less than
one day of a contractor.

**Catch.** Comprehension claims need a human sanity check before money moves —
this is a *starting point* for a port, not a finished migration. Sell the map,
not the treasure.

---

## 7. MVP sprints for the little guy (idea → repo + audit trail)

**What it is.** A bounded "build me this" loop: describe the idea, seats build,
the harness runs tests, the attackers break it, the loop iterates, and you
deliver a working repo **plus** the append-only flight record — every attempt,
every failure, every contradiction, hash-chained.

**Why it fits.** This is the "imagine the power" vision turned into a concrete
deliverable for someone who can't code. And the audit trail is the differentiator:
no other AI-coding tool hands you *proof of how the code came to be*.

**Little-guy price.** **$49–$149 one-time per MVP**, scoped tightly. A
non-technical founder gets a prototype and the story of how it was built.

**Catch.** Scope creep is the killer — bound it hard (rounds, files, features)
or you eat the token cost of an unbounded build. The refusal culture applies
here too: refuse to build what can't be verified.

---

## 8. The provable-work log (agencies charge more for proof)

**What it is.** The passport + flight recorder become the *client deliverable*.
A freelancer or small agency hands the client the hash-chained record: what we
tried, what failed, which seats disagreed, what we shipped, and when. It's
"receipts as a service."

**Why it fits.** The memory system was always tamper-evident; nobody has yet
aimed it at the client relationship. A 2-person shop that can *prove* its work
can bill like a firm, because it can show the dead ends too — which is exactly
what clients pay trust for.

**Little-guy price.** **$9–$19/mo** (folds into the team tier). It's a margin
tool, not a cost center: it lets the little guy *raise* their rate.

**Catch.** You must make the log genuinely client-safe — strip prompts, keys,
and anything a client shouldn't see. The codebase already strips engine-training
records by name (`anchors.jsonl`); extend that discipline to the deliverable.

---

## 9. Code packs & relay recipes (the marketplace, aimed at code)

**What it is.** The pack idea from the main plan, but for the loop: curated,
industry-tuned *recipes* — "React bug-fix loop," "dependency upgrade pass,"
"SQL migration review," "auth-flow security pass," "legacy port." Each recipe
declares the shape, the seat assignments, the stop condition, and the rubric.
Creators publish, you take a revenue share. The loop *runs* the recipe.

**Why it fits.** The loop is general; the tuning — which seats, which shape,
what "done" means — is expertise a solo engineer already has and would sell.
The flight recorder's promoted maneuvers even give you the raw material: watch
what sequences keep succeeding, and *package the successful ones as recipes*.

**Little-guy price.** **$9–$29 one-time per pack.** Buy the one recipe your job
needs, ignore the rest.

**Catch.** Same marketplace cold-start and quality problems as before — gate
listings through a soundness review, or the trust brand dies.

---

## 10. The on-prem code forge (IP never leaves the building)

**What it is.** The whole loop — seats, relay, harness, flight recorder,
passport — self-hosted for firms whose code is their crown jewels. Because
*code* is the most sensitive IP there is, this is the compliance play that the
code loop makes possible where the general browser can't.

**Why it fits.** It's also the one place the "continuous" version of your loop
becomes *truly* continuous and unattended — their hardware, their keys, their
budget, their liability. The "user-triggered only" rule relaxes honestly on
premises they own.

**Little-guy price.** **$1,499 one-time or $199/mo.** For a boutique or a
municipality, that's less than one day of consultant time, and their code never
touches your servers.

**Catch.** Support burden (their server breaks, they call you) and the
documentation burden of "your credentials live here now." Price support
separately, or fold it into the membership.

---

## What the loop costs, and who pays what

| # | Product | Little-guy price | Who pays |
|---|---|---|---|
| 1 | Code Forge (flagship) | $9/mo / $99 one-time | solo dev |
| 2 | Pay-per-flight | $2–$6/flight / $15/mo | individual |
| 3 | N-eyes code review | $9/mo / $2 per review | freelancer, 3-person shop |
| 4 | Red-team-as-a-service | $19–$49 per audit | small business (scared) |
| 5 | Bug-fix relay | $5–$15 per incident | individual, shop |
| 6 | Legacy comprehension | $49–$199 per project | small business |
| 7 | MVP sprint | $49–$149 one-time | non-technical founder |
| 8 | Provable-work log | $9–$19/mo | freelancer, agency |
| 9 | Code packs & recipes | $9–$29 one-time | freelancer |
| 10 | On-prem code forge | $1,499 / $199/mo | firm, municipality |

**The two lines never crossed, even here:** the core roundtable browser stays
free, and the loop **never runs unattended on the little guy's machine without
their explicit launch, a cap, and a stop.** "Autonomous, never unattended" is
the trust moat — and the moment you ship a loop that silently drains someone's
API keys overnight, all ten avenues die at once.

---

## The guardrails that make the loop sellable

1. **Every commit is a proposal.** The loop writes to a branch, the human
   releases — the Federation's "you are step four" applied to git.
2. **The build is the referee.** No seat self-adjudicates; tests decide. If
   only "furniture" changed and nothing actually ran, the seat says
   `empty-response`, same as today.
3. **Failure is first-class.** The flight recorder already refuses to delete a
   failure. In the loop, "what didn't work" is *context*, not garbage — that's
   the entire power you described, and it's already the data model.
4. **Caps by construction.** `seat-budget.ts` charges before dispatch and ejects
   a spent seat. The loop inherits that: it cannot run away.
5. **Scope or refuse.** The loop refuses what it can't verify, by name, with a
   sentence. The same culture that refuses to guess the composer refuses to
   "fix" a bug it can't reproduce with a failing test.

## Sequencing (the loop reshuffles the old plan)

The coding relay **is now the flagship**, and it pulls the timeline forward:

- **Month 1–3:** **#1 Code Forge** in bounded form (4-seat loop, local harness,
  stop-on-green) + **#2 flights** with caps. These two are the engine.
- **Month 3–6:** **#3 N-eyes code review** — lowest friction, fastest revenue,
  feeds the passport's witness model daily.
- **Month 6–9:** **#4 red-team-as-a-service** and **#5 bug-fix relay** — both
  ride the forge, both have mechanical success criteria, both are high-margin.
- **Month 9–12:** **#6 legacy comprehension**, **#7 MVP sprints**, **#8
  provable-work log** (folds into the team tier).
- **Month 12+:** **#9 code packs** (once the flight recorder has enough promoted
  maneuvers to package), then **#10 on-prem forge** (once the continuous loop is
  proven safe *gated* before it's ever trusted *unattended*).

---

The through-line is the same one, now sharper: **Forge Flight's refusal to guess
is the business — and code is where a refusal plus a green build light adds up
to something nobody else sells.** Every other AI-coding tool gives you *an
answer*. This one gives you **a forge with a memory, a referee, and a receipt.**
That's the product you described. It was always the product; you just named it.
