"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Plus,
  X,
  Search,
  Lock,
  Home,
  Sparkles,
  Layers,
  Menu,
  Globe,
  Loader2,
  Shield,
  FlaskConical,
  Plane,
} from "lucide-react";
import { StartPage } from "./StartPage";
import { AssistantPanel } from "./AssistantPanel";
import { detectProvider, type DetectedProvider } from "@/lib/model-provider";

type TabInfo = { id: string; url: string; title: string; status: number };
type EngineStatus = {
  mode: "chromium" | "pane" | "offline";
  activeTabId: string | null;
  tabs: TabInfo[];
  launchError: string | null;
};
type PageContext = { url: string; title: string; snapshot: string } | null;

const NEWTAB = "omnibox://newtab";

export function BrowserShell() {
  const [engine, setEngine] = useState<EngineStatus | null>(null);
  const [address, setAddress] = useState("");
  const [docRev, setDocRev] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dockOpen, setDockOpen] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [focused, setFocused] = useState(false);
  const [pageContext, setPageContext] = useState<PageContext>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const refreshEngine = useCallback(async () => {
    try {
      const res = await fetch("/api/browser");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "engine status failed");
      setEngine(data);
      const active = data.tabs?.find((t: TabInfo) => t.id === data.activeTabId);
      if (active) setAddress(active.url === NEWTAB ? "" : active.url);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }, []);

  useEffect(() => {
    // Fetch-on-mount. Every setState inside refreshEngine lands after an
    // await, so there is no synchronous cascade — and there is no non-effect
    // place to start a load that must happen once per mount.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void refreshEngine();
  }, [refreshEngine]);

  // Keep a ref to the latest go for use inside postMessage/effects.
  const goRef = useRef<(raw?: string) => Promise<void>>(async () => undefined);

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      const data = event.data;
      if (!data || data.source !== "omnibox-pane") return;
      if (data.type === "navigate" && typeof data.url === "string") {
        void goRef.current(data.url);
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  const go = useCallback(async (raw?: string) => {
    const url = (raw ?? address).trim();
    if (!url) return;
    setBusy("navigate");
    setError(null);
    setMenuOpen(false);
    try {
      const res = await fetch("/api/browser/navigate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, tabId: engine?.activeTabId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "navigate failed");
      setEngine(data);
      const active = data.tabs?.find((t: TabInfo) => t.id === data.activeTabId);
      if (active) setAddress(active.url === NEWTAB ? "" : active.url);
      setDocRev((n) => n + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }, [address, engine]);
  // Assigning a ref during render is undefined behaviour under concurrent
  // rendering — React may render without committing. An effect runs only on
  // a commit, so the ref tracks the callback that is actually live.
  useEffect(() => {
    goRef.current = go;
  }, [go]);

  async function act(type: "back" | "reload") {
    setBusy(type);
    try {
      const res = await fetch("/api/browser/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, tabId: engine?.activeTabId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `${type} failed`);
      setEngine(data);
      const active = data.tabs?.find((t: TabInfo) => t.id === data.activeTabId);
      if (active) setAddress(active.url === NEWTAB ? "" : active.url);
      setDocRev((n) => n + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }

  async function newTab() {
    setBusy("tab");
    setError(null);
    try {
      const res = await fetch("/api/browser/tabs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "new tab failed");
      setEngine(data);
      setAddress("");
      setDocRev((n) => n + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }

  async function activateTab(id: string) {
    const res = await fetch("/api/browser/tabs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "activate", id }),
    });
    const data = await res.json();
    if (!res.ok) return;
    setEngine((prev) => (prev ? { ...prev, ...data, activeTabId: id, tabs: data.tabs ?? prev.tabs } : data));
    const active = (data.tabs ?? engine?.tabs)?.find((t: TabInfo) => t.id === id);
    if (active) setAddress(active.url === NEWTAB ? "" : active.url);
    setDocRev((n) => n + 1);
  }

  async function closeTab(id: string) {
    const res = await fetch("/api/browser/tabs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close", id }),
    });
    const data = await res.json();
    if (!res.ok) return;
    setEngine(data);
    const active = data.tabs?.find((t: TabInfo) => t.id === data.activeTabId);
    if (active) setAddress(active.url === NEWTAB ? "" : active.url);
    setDocRev((n) => n + 1);
  }

  // Poll the active page snapshot so the dock can use it as context.
  useEffect(() => {
    if (!engine?.activeTabId) return;
    const activeTab = engine.tabs?.find((t) => t.id === engine.activeTabId);
    let cancelled = false;
    void (async () => {
      // Every write below lands in a promise continuation rather than in the
      // effect body. Clearing context synchronously on a new tab was a
      // setState during commit, and it cascaded on every navigation.
      if (!activeTab || activeTab.url === NEWTAB) {
        if (!cancelled) setPageContext(null);
        return;
      }
      try {
        const res = await fetch(`/api/browser/snapshot?tab=${engine.activeTabId}`);
        if (!res.ok) return;
        const data = await res.json();
        if (!cancelled) {
          setPageContext({ url: data.url, title: data.title, snapshot: data.snapshot });
        }
      } catch {
        /* snapshot is best-effort */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [engine?.activeTabId, engine?.tabs, docRev]);

  const active = engine?.tabs.find((t) => t.id === engine.activeTabId);
  const isNewTab = !active || active.url === NEWTAB;

  // Auto-link the dock to the model provider on the open page.
  // This is a pure function of the active url, so it is derived at render
  // rather than mirrored into state by an effect. Holding it in state meant
  // one extra render per navigation and a frame where the dock claimed the
  // wrong provider.
  const provider: DetectedProvider | null = useMemo(
    () => detectProvider(isNewTab ? null : active?.url ?? null),
    [active?.url, isNewTab],
  );
  const docSrc = engine?.activeTabId
    ? `/api/browser/document?tab=${engine.activeTabId}&r=${docRev}`
    : "about:blank";

  const trimmed = address.trim();
  const looksLikeUrl =
    /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ||
    /^[a-z0-9.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(trimmed);
  const showSuggestions = focused && trimmed.length > 0;

  function submit(e: FormEvent) {
    e.preventDefault();
    void go();
    setFocused(false);
  }

  return (
    <div className="h-screen flex flex-col bg-[#0a0f1e] text-slate-100 overflow-hidden">
      {/* ── Tab strip ─────────────────────────────────────────── */}
      <div className="flex items-end gap-1 px-2 pt-2 bg-[#0a0f1e] border-b border-white/[0.06]">
        <div className="flex items-center gap-1 overflow-x-auto flex-1 min-w-0">
          {(engine?.tabs ?? []).map((tab) => {
            const on = tab.id === engine?.activeTabId;
            return (
              <div
                key={tab.id}
                onClick={() => void activateTab(tab.id)}
                className={`group flex items-center gap-2 max-w-[200px] min-w-[120px] px-3 py-2 rounded-t-lg border border-b-0 cursor-pointer select-none ${
                  on
                    ? "bg-[#121a2e] border-white/10 text-white"
                    : "bg-transparent border-transparent text-slate-500 hover:text-slate-200"
                }`}
              >
                <Globe className="h-3 w-3 shrink-0 opacity-60" />
                <span className="truncate text-xs">{tab.title || hostOf(tab.url)}</span>
                <span
                  role="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    void closeTab(tab.id);
                  }}
                  className="ml-auto opacity-0 group-hover:opacity-100 hover:text-red-300 rounded p-0.5"
                >
                  <X className="h-3 w-3" />
                </span>
              </div>
            );
          })}
        </div>
        <button
          onClick={() => void newTab()}
          aria-label="New tab"
          className="p-1.5 mb-1 rounded-md text-slate-400 hover:text-white hover:bg-white/5"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* ── Toolbar ───────────────────────────────────────────── */}
      <div className="flex items-center gap-1.5 px-2 py-2 bg-[#121a2e] border-b border-white/[0.06]">
        <IconBtn onClick={() => void act("back")} label="Back" disabled={busy !== null}>
          <ArrowLeft className="h-4 w-4" />
        </IconBtn>
        <IconBtn
          onClick={() => void act("reload")}
          label="Reload"
          disabled={busy !== null}
        >
          {busy === "reload" ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <RotateCw className="h-4 w-4" />
          )}
        </IconBtn>
        <IconBtn onClick={() => void newTab()} label="New tab">
          <Home className="h-4 w-4" />
        </IconBtn>

        {/* Omnibox */}
        <div className="relative flex-1 max-w-3xl mx-auto">
          <form
            onSubmit={submit}
            className="flex items-center gap-2 h-9 px-3.5 rounded-full bg-black/40 border border-white/10 focus-within:border-indigo-400/50 focus-within:ring-4 focus-within:ring-indigo-500/10 transition"
          >
            {looksLikeUrl && trimmed ? (
              <Lock className="h-3.5 w-3.5 text-emerald-400/80" />
            ) : (
              <Search className="h-3.5 w-3.5 text-slate-500" />
            )}
            <input
              ref={inputRef}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => setTimeout(() => setFocused(false), 150)}
              placeholder="Search or enter an address"
              className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-500 outline-none"
              spellCheck={false}
            />
            {busy === "navigate" && <Loader2 className="h-3.5 w-3.5 animate-spin text-indigo-300" />}
          </form>

          {showSuggestions && (
            <div className="absolute top-11 left-0 right-0 rounded-2xl bg-[#0d1526] border border-white/10 shadow-2xl overflow-hidden z-50">
              <button
                onMouseDown={(e) => {
                  e.preventDefault();
                  setAddress(trimmed);
                  void go(trimmed);
                  setFocused(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/5"
              >
                {looksLikeUrl ? (
                  <Lock className="h-4 w-4 text-emerald-400/80" />
                ) : (
                  <Search className="h-4 w-4 text-indigo-300" />
                )}
                <span className="text-sm text-slate-200">
                  {looksLikeUrl ? "Open" : "Search the web for"}
                  <span className="ml-2 text-slate-400 truncate">{trimmed}</span>
                </span>
              </button>
            </div>
          )}
        </div>

        <IconBtn
          onClick={() => setDockOpen((v) => !v)}
          label="Toggle AI dock"
          active={dockOpen}
        >
          <Sparkles className="h-4 w-4" />
        </IconBtn>
        <IconBtn onClick={() => setMenuOpen((v) => !v)} label="Menu">
          <Menu className="h-4 w-4" />
        </IconBtn>

        {menuOpen && (
          <div className="absolute right-3 top-[104px] w-56 rounded-2xl bg-[#0d1526] border border-white/10 shadow-2xl overflow-hidden z-50 p-1.5">
            <MenuLink href="/passport" icon={Shield} label="Memory Passport" onClick={() => setMenuOpen(false)} />
            <MenuLink href="/cockpit" icon={Plane} label="Cockpit" onClick={() => setMenuOpen(false)} />
            <MenuLink href="/functions" icon={Sparkles} label="Gun base" onClick={() => setMenuOpen(false)} />
            <MenuLink href="/lab" icon={FlaskConical} label="Lab" onClick={() => setMenuOpen(false)} />
            <button
              onClick={() => {
                void act("reload");
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-slate-200 hover:bg-white/5"
            >
              <RotateCw className="h-4 w-4 text-slate-400" /> Reload this page
            </button>
          </div>
        )}
      </div>

      {/* ── Content + dock ────────────────────────────────────── */}
      <div className="flex-1 min-h-0 flex">
        <div className="flex-1 min-w-0 relative bg-[#0a1020]">
          {isNewTab ? (
            <StartPage onSearch={go} onOpen={(u) => void go(u)} />
          ) : engine ? (
            <iframe
              ref={iframeRef}
              title={active?.title || "page"}
              src={docSrc}
              sandbox="allow-scripts allow-forms allow-popups"
              className="absolute inset-0 w-full h-full bg-white"
            />
          ) : (
            <div className="h-full grid place-items-center text-slate-500 text-sm">
              Starting the engine…
            </div>
          )}
          {error && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-40 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm text-red-200 shadow-2xl">
              {error}
            </div>
          )}
        </div>
        <AssistantPanel
          open={dockOpen}
          onClose={() => setDockOpen(false)}
          pageContext={pageContext}
          provider={provider}
        />
      </div>

      {/* Brand footer / status */}
      <div className="h-6 shrink-0 bg-[#0a0f1e] border-t border-white/[0.06] flex items-center gap-2 px-3 text-[10px] text-slate-600">
        <Layers className="h-3 w-3 text-violet-400" />
        <span className="font-medium text-slate-400">Vector</span>
        <span className="text-slate-700">·</span>
        <ModePill mode={engine?.mode} />
        <span className="ml-auto">the browser for your models</span>
      </div>
    </div>
  );
}

function ModePill({ mode }: { mode?: string | null }) {
  const label = mode === "chromium" ? "Chromium" : mode === "pane" ? "Pane engine" : "Engine…";
  const color = mode === "chromium" ? "text-emerald-400" : mode === "pane" ? "text-sky-400" : "text-slate-500";
  return <span className={color}>{label}</span>;
}

function IconBtn({
  children,
  onClick,
  label,
  disabled,
  active,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  disabled?: boolean;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      disabled={disabled}
      className={`h-8 w-8 grid place-items-center rounded-full text-slate-300 transition ${
        active ? "bg-indigo-500/20 text-indigo-200" : "hover:text-white hover:bg-white/10"
      } disabled:opacity-40`}
    >
      {children}
    </button>
  );
}

function MenuLink({
  href,
  icon: Icon,
  label,
  onClick,
}: {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
}) {
  return (
    <a
      href={href}
      onClick={onClick}
      className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-slate-200 hover:bg-white/5"
    >
      <Icon className="h-4 w-4 text-slate-400" /> {label}
    </a>
  );
}

function hostOf(url: string) {
  if (url === NEWTAB) return "New tab";
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}
