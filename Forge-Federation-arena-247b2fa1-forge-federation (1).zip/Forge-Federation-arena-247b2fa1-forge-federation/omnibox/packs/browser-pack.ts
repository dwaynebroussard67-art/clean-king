/**
 * browser-pack.ts
 * Real browser controls. Pilots navigate, read pages, click elements.
 * Every call goes through the harness gate — pilot holds no direct
 * browser access, only capability handles.
 *
 * Tools in this pack:
 *   browser.navigate   — go to a URL
 *   browser.read_page  — get the text content of the current page
 *   browser.click      — click an element by selector or text
 *   browser.type       — type into an input field
 *   browser.screenshot — capture what's on screen (returns base64)
 *   browser.back       — go back in history
 *
 * INTEGRATION NOTE (2026-08-19): the delivered descriptors were written
 * against a guessed CapabilityDescriptor shape ({ name, description,
 * inputSchema, maxRisk, requiresApproval, pack }). The real interface in
 * contracts.ts is { id, name, description, risk, inputSchema, ... } with the
 * ToolRisk vocabulary (read | transform | create | update | delete |
 * external_side_effect). Mapped here: navigation moves a live browser the
 * operator is watching → external_side_effect; click/type mutate page state
 * → transform; everything else is read.
 *
 * MOUNTING IS NOT GRANTING (C27): mount browserPack() to make these tools
 * exist. A mission's authority still has to grant each capability, and the
 * mission's autoApproveRiskAtMost ceiling decides whether an invocation
 * auto-approves or waits for a human.
 */

import type { CapabilityDescriptor } from '../contracts.ts';
import type { CapabilityPack } from '../packs.ts';
import {
  hashDomSnapshot,
  hashPageText,
  hashPngBase64,
  truncateText,
} from '../hashing.ts';
import { AnchorBridge } from '../anchor-bridge.ts';
import { toAnchor } from '../../lib/anchor.ts';

// ── Schema helpers ────────────────────────────────────────────────────────

const urlSchema = {
  type: 'object',
  required: ['url'],
  properties: {
    url: { type: 'string', description: 'Fully-qualified URL including protocol' },
  },
} as const

// ── Capability descriptors ────────────────────────────────────────────────

export const BROWSER_NAVIGATE: CapabilityDescriptor = {
  id: 'browser.navigate',
  name: 'Navigate the browser',
  description: 'Navigate the browser to a URL. The page must be allowed by the mission\'s domain whitelist if one is set.',
  inputSchema: urlSchema,
  risk: 'external_side_effect',
  requiresApproval: false,
}

export const BROWSER_READ_PAGE: CapabilityDescriptor = {
  id: 'browser.read_page',
  name: 'Read the page',
  description: 'Read the text content of the current page. Returns title, URL, and visible text plus content hash (sha256 of text bytes, not JSON.stringify wrapper).',
  inputSchema: {
    type: 'object',
    properties: {
      includeLinks: {
        type: 'boolean',
        description: 'If true, include hyperlinks in the output',
      },
      maxLength: {
        type: 'number',
        description: 'Max characters to return. Default 8000.',
      },
    },
  },
  risk: 'read',
  requiresApproval: false,
}

export const BROWSER_CLICK: CapabilityDescriptor = {
  id: 'browser.click',
  name: 'Click an element',
  description:
    'Click an element on the current page. Prefer a stable id (data-testid / id). A unique id is trusted immediately; anything else is resolved or refused — never guessed.',
  inputSchema: {
    type: 'object',
    properties: {
      selector: {
        type: 'string',
        description: 'CSS selector or #id. Used as a last-resort signal, not as identity.',
      },
      text: {
        type: 'string',
        description: 'Visible text to match if the selector is ambiguous.',
      },
      anchor: {
        type: 'object',
        description: 'Multi-signal descriptor. Prefer testId or id.',
        properties: {
          testId: { type: 'string' },
          id: { type: 'string' },
          text: { type: 'string' },
          role: { type: 'string' },
          tag: { type: 'string' },
          cssPath: { type: 'string' },
        },
      },
      verify: {
        type: 'boolean',
        description: 'Confirm after clicking that the right element was hit.',
      },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}

export const BROWSER_TYPE: CapabilityDescriptor = {
  id: 'browser.type',
  name: 'Type into an input',
  description:
    'Type text into an input. Prefer a stable id. The keepalive / re-anchor path refuses rather than typing into the wrong field.',
  inputSchema: {
    type: 'object',
    required: ['text'],
    properties: {
      selector: { type: 'string', description: 'CSS selector for the input' },
      text: { type: 'string', description: 'Text to type' },
      clearFirst: {
        type: 'boolean',
        description: 'Clear the field before typing. Default true.',
      },
      anchor: {
        type: 'object',
        description: 'Multi-signal descriptor. Prefer testId or id.',
        properties: {
          testId: { type: 'string' },
          id: { type: 'string' },
          text: { type: 'string' },
          role: { type: 'string' },
          tag: { type: 'string' },
          cssPath: { type: 'string' },
        },
      },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}

export const BROWSER_SCREENSHOT: CapabilityDescriptor = {
  id: 'browser.screenshot',
  name: 'Screenshot the page',
  description: 'Capture a screenshot of the current page. Returns base64 PNG plus hash of raw PNG bytes (sha256:...) — not JSON.stringify({ png }).',
  inputSchema: {
    type: 'object',
    properties: {
      fullPage: {
        type: 'boolean',
        description: 'Capture full scrollable page, not just the viewport. Default false.',
      },
    },
  },
  risk: 'read',
  requiresApproval: false,
}

export const BROWSER_BACK: CapabilityDescriptor = {
  id: 'browser.back',
  name: 'Go back',
  description: 'Go back one step in browser history.',
  inputSchema: { type: 'object', properties: {} },
  risk: 'read',
  requiresApproval: false,
}

export const BROWSER_SNAPSHOT: CapabilityDescriptor = {
  id: 'browser.snapshot',
  name: 'Snapshot the page structure',
  description:
    'Capture the structured page snapshot (URL, title, interactive elements grouped by heading) plus hash of canonical snapshot text. Hash is over raw snapshot bytes after normalizing line endings and trimming trailing whitespace — not JSON.stringify(output).',
  inputSchema: {
    type: 'object',
    properties: {
      maxElements: { type: 'number', description: 'Max interactive elements to include. Default 400.' },
    },
  },
  risk: 'read',
  requiresApproval: false,
}

// ── Pack manifest ─────────────────────────────────────────────────────────

export const BROWSER_PACK_CAPABILITIES: CapabilityDescriptor[] = [
  BROWSER_NAVIGATE,
  BROWSER_READ_PAGE,
  BROWSER_CLICK,
  BROWSER_TYPE,
  BROWSER_SCREENSHOT,
  BROWSER_BACK,
  BROWSER_SNAPSHOT,
]

export const BROWSER_PACK_NAME = 'browser'

/**
 * The actual tool implementations.
 * These are thin wrappers — the real browser control runs in the
 * OmniBox extension (content-bridge.js). The harness sends a
 * TOOL_INVOKE message over the bridge WebSocket and waits for
 * TOOL_RESULT. If the bridge is not connected, calls throw BridgeOfflineError.
 *
 * In tests, inject a mock BrowserBridge via BrowserPack.setBridge().
 *
 * HASHING NOTE: All implementations that produce content return BOTH the
 * content and a sha256 ref of RAW BYTES. Runtime collects _structuralRef and
 * mints a structural witness from it. Pilot cannot supply hash — plumbing
 * recomputes from bytes it observed.
 */

export class BridgeOfflineError extends Error {
  constructor() {
    super('BRIDGE_OFFLINE: OmniBox bridge is not connected. Open the bridge server and reload the extension.')
    this.name = 'BridgeOfflineError'
  }
}

export interface BrowserBridge {
  invoke(tool: string, args: Record<string, unknown>): Promise<unknown>
}

let _bridge: BrowserBridge | null = null

export const BrowserPack = {
  setBridge(bridge: BrowserBridge | null): void {
    _bridge = bridge
  },

  getBridge(): BrowserBridge {
    if (!_bridge) throw new BridgeOfflineError()
    return _bridge
  },

  async navigate(args: { url: string }): Promise<{ url: string; title: string; status: number }> {
    return BrowserPack.getBridge().invoke('browser.navigate', args) as Promise<{ url: string; title: string; status: number }>
  },

  async readPage(args: { includeLinks?: boolean; maxLength?: number }): Promise<{
    url: string
    title: string
    text: string
    contentHash: string
    truncated: boolean
    links?: Array<{ text: string; href: string }>
    _structuralRef: string
  }> {
    const raw = await BrowserPack.getBridge().invoke('browser.read_page', args) as {
      url: string
      title: string
      text: string
      links?: Array<{ text: string; href: string }>
    }
    const text = String(raw.text ?? '')
    const contentHash = hashPageText(text)
    const { truncated: truncatedText, wasTruncated } = truncateText(text, args.maxLength ?? 8000)
    return {
      url: raw.url,
      title: raw.title,
      text: truncatedText,
      links: raw.links,
      contentHash,
      truncated: wasTruncated,
      _structuralRef: contentHash,
    }
  },

  async click(args: {
    selector?: string
    text?: string
    anchor?: Record<string, unknown>
    verify?: boolean
  }): Promise<{ clicked: boolean; element: string; resolvedSelector?: string; method?: string }> {
    const anchor = toAnchor(args as Record<string, unknown>)
    try {
      const keepalive = await AnchorBridge.keepalive(anchor)
      if (keepalive) {
        const clicked = await BrowserPack.getBridge().invoke('browser.click', {
          selector: keepalive.element.resolvedSelector,
          text: args.text,
        }) as { clicked: boolean; element: string }
        return {
          ...clicked,
          resolvedSelector: keepalive.element.resolvedSelector,
          method: 'keepalive',
        }
      }
    } catch {
      /* keepalive is best-effort; fall through */
    }

    if (AnchorBridge.engineVersion()) {
      const result = await AnchorBridge.click(anchor, { verify: args.verify === true })
      if ('refused' in result) {
        throw new Error(`ANCHOR_REFUSED: ${result.reason}`)
      }
      return {
        clicked: result.clicked,
        element: result.resolvedSelector,
        resolvedSelector: result.resolvedSelector,
        method: 'engine',
      }
    }

    return BrowserPack.getBridge().invoke('browser.click', {
      selector: args.selector,
      text: args.text,
    }) as Promise<{ clicked: boolean; element: string }>
  },

  async type(args: {
    selector?: string
    text: string
    clearFirst?: boolean
    anchor?: Record<string, unknown>
  }): Promise<{ typed: boolean; resolvedSelector?: string; method?: string }> {
    const anchor = toAnchor(args as Record<string, unknown>)
    try {
      const keepalive = await AnchorBridge.keepalive(anchor)
      if (keepalive) {
        const typed = await BrowserPack.getBridge().invoke('browser.type', {
          selector: keepalive.element.resolvedSelector,
          text: args.text,
          clearFirst: args.clearFirst !== false,
        }) as { typed: boolean }
        return {
          ...typed,
          resolvedSelector: keepalive.element.resolvedSelector,
          method: 'keepalive',
        }
      }
    } catch {
      /* keepalive is best-effort; fall through */
    }

    if (AnchorBridge.engineVersion()) {
      const result = await AnchorBridge.type(anchor, args.text, { clearFirst: args.clearFirst !== false })
      if ('refused' in result) {
        throw new Error(`ANCHOR_REFUSED: ${result.reason}`)
      }
      return {
        typed: result.typed,
        resolvedSelector: result.resolvedSelector,
        method: 'engine',
      }
    }

    return BrowserPack.getBridge().invoke('browser.type', {
      selector: args.selector,
      text: args.text,
      clearFirst: args.clearFirst !== false,
    }) as Promise<{ typed: boolean }>
  },

  async screenshot(args: { fullPage?: boolean }): Promise<{ png: string; width: number; height: number; pngHash: string; _structuralRef: string }> {
    const raw = await BrowserPack.getBridge().invoke('browser.screenshot', args) as { png: string; width: number; height: number }
    const pngHash = hashPngBase64(String(raw.png ?? ''))
    return {
      png: raw.png,
      width: raw.width,
      height: raw.height,
      pngHash,
      _structuralRef: pngHash,
    }
  },

  async back(): Promise<{ url: string }> {
    return BrowserPack.getBridge().invoke('browser.back', {}) as Promise<{ url: string }>
  },

  async snapshot(args: { maxElements?: number }): Promise<{ snapshot: string; snapshotHash: string; truncated?: boolean; _structuralRef: string }> {
    const result = await BrowserPack.getBridge().invoke('browser.snapshot', args) as string | { snapshot: string }
    const snapshotText = typeof result === 'string' ? result : String((result as any)?.snapshot ?? result)
    const snapshotHash = hashDomSnapshot(snapshotText)
    // Truncate display copy, hash stays over full bytes
    const { truncated, wasTruncated } = truncateText(snapshotText, 16_000)
    return {
      snapshot: truncated,
      snapshotHash,
      truncated: wasTruncated ? true : undefined,
      _structuralRef: snapshotHash,
    }
  },
}

/**
 * Mountable pack form. Mount it on a HarnessRuntime to make the browser
 * tools exist; grant them per mission to make them usable. The pack's
 * declared ceiling is the highest risk any member tool carries — the
 * registry refuses the mount if a future tool slips above it.
 */
export function browserPack(): CapabilityPack {
  return {
    id: BROWSER_PACK_NAME,
    name: 'Browser controls',
    description:
      'Real browser actuation through the OmniBox bridge: navigate, read, click, type, screenshot, snapshot. No direct browser access exists for pilots — only governed handles. All content outputs include sha256 of raw bytes, not JSON.stringify(wrapper).',
    version: '1.1.0',
    maxRisk: 'external_side_effect',
    tools: [
      { descriptor: BROWSER_NAVIGATE, implementation: async (args) => BrowserPack.navigate({ url: String(args.url) }) },
      { descriptor: BROWSER_READ_PAGE, implementation: async (args) => BrowserPack.readPage({
        includeLinks: args.includeLinks === true,
        maxLength: typeof args.maxLength === 'number' ? args.maxLength : undefined,
      }) },
      { descriptor: BROWSER_CLICK, implementation: async (args) => BrowserPack.click({
        selector: typeof args.selector === 'string' ? args.selector : undefined,
        text: typeof args.text === 'string' ? args.text : undefined,
        anchor: args.anchor && typeof args.anchor === 'object' ? args.anchor as Record<string, unknown> : undefined,
        verify: args.verify === true,
      }) },
      { descriptor: BROWSER_TYPE, implementation: async (args) => BrowserPack.type({
        selector: typeof args.selector === 'string' ? args.selector : undefined,
        text: String(args.text),
        clearFirst: args.clearFirst !== false,
        anchor: args.anchor && typeof args.anchor === 'object' ? args.anchor as Record<string, unknown> : undefined,
      }) },
      { descriptor: BROWSER_SCREENSHOT, implementation: async (args) => BrowserPack.screenshot({
        fullPage: args.fullPage === true,
      }) },
      { descriptor: BROWSER_BACK, implementation: async () => BrowserPack.back() },
      { descriptor: BROWSER_SNAPSHOT, implementation: async (args) => BrowserPack.snapshot({
        maxElements: typeof (args as any).maxElements === 'number' ? (args as any).maxElements : undefined,
      }) },
    ],
  }
}
