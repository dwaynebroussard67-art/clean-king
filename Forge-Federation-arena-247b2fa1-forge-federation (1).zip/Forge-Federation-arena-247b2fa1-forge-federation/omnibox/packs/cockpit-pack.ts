/**
 * cockpit-pack.ts
 * Cross-seat coordination. Pilots can see who else is in the cockpit,
 * read what another seat said, and flag disagreement. This is what makes
 * the conversation shapes work — a pilot in an adversarial shape can
 * read the other side's last response before writing its own.
 *
 * Tools:
 *   cockpit.seats       — who is seated and what type they are
 *   cockpit.read_seat   — read the last N responses from a seat
 *   cockpit.broadcast   — send a message all seats will receive
 *   cockpit.flag        — flag a disagreement for the flight recorder
 *   cockpit.shape       — read the current conversation shape
 *
 * INTEGRATION NOTE (2026-08-19): descriptors rewritten against the real
 * CapabilityDescriptor (id + ToolRisk), and a mountable cockpitPack()
 * factory added. Seat state comes from src/harness/cockpit.ts (the
 * five-seat Neuralink); responses/flags/broadcasts live in the in-memory
 * cockpitStore until the flight recorder persists them to the mission spine.
 */

import type { CapabilityDescriptor } from '../contracts.ts';
import type { CapabilityPack } from '../packs.ts';
import type { SeatIndex } from '../cockpit.ts';
import { neuralink } from '../cockpit.ts';

// ── Capability descriptors ────────────────────────────────────────────────

export const COCKPIT_SEATS: CapabilityDescriptor = {
  id: 'cockpit.seats',
  name: 'List cockpit seats',
  description: 'List all occupied seats in the cockpit: seat index, pilot type, and label.',
  inputSchema: { type: 'object', properties: {} },
  risk: 'read',
  requiresApproval: false,
}

export const COCKPIT_READ_SEAT: CapabilityDescriptor = {
  id: 'cockpit.read_seat',
  name: 'Read another seat',
  description: 'Read the last N responses from a specific seat. Use this to see what another pilot said before responding.',
  inputSchema: {
    type: 'object',
    required: ['seatIndex'],
    properties: {
      seatIndex: {
        type: 'number',
        description: 'Seat index (0-4)',
      },
      last: {
        type: 'number',
        description: 'How many recent responses to fetch. Default 1.',
      },
    },
  },
  risk: 'read',
  requiresApproval: false,
}

export const COCKPIT_BROADCAST: CapabilityDescriptor = {
  id: 'cockpit.broadcast',
  name: 'Broadcast to the cockpit',
  description: 'Send a message that all seated pilots will receive as context. Use to share a finding or frame a debate.',
  inputSchema: {
    type: 'object',
    required: ['message'],
    properties: {
      message: { type: 'string', description: 'The message to broadcast' },
      tag: {
        type: 'string',
        description: 'Optional tag: "finding", "question", "claim", "context"',
        enum: ['finding', 'question', 'claim', 'context'],
      },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}

export const COCKPIT_FLAG: CapabilityDescriptor = {
  id: 'cockpit.flag',
  name: 'Flag a disagreement',
  description: 'Flag a disagreement between seats for the flight recorder. This is how cross-provider contradictions get logged.',
  inputSchema: {
    type: 'object',
    required: ['mySeat', 'theirSeat', 'claim', 'counter'],
    properties: {
      mySeat: { type: 'number', description: 'Your seat index' },
      theirSeat: { type: 'number', description: 'The seat you disagree with' },
      claim: { type: 'string', description: 'What they said' },
      counter: { type: 'string', description: 'What you say instead' },
      severity: {
        type: 'string',
        enum: ['factual', 'interpretive', 'strategic'],
        description: 'Type of disagreement',
      },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}

export const COCKPIT_SHAPE: CapabilityDescriptor = {
  id: 'cockpit.shape',
  name: 'Read the conversation shape',
  description: 'Read the current conversation shape and routing configuration.',
  inputSchema: { type: 'object', properties: {} },
  risk: 'read',
  requiresApproval: false,
}

// ── Pack manifest ─────────────────────────────────────────────────────────

export const COCKPIT_PACK_CAPABILITIES: CapabilityDescriptor[] = [
  COCKPIT_SEATS,
  COCKPIT_READ_SEAT,
  COCKPIT_BROADCAST,
  COCKPIT_FLAG,
  COCKPIT_SHAPE,
]

export const COCKPIT_PACK_NAME = 'cockpit'

// ── In-memory seat response store ────────────────────────────────────────
// The cockpit pack keeps a rolling buffer of responses per seat.
// This is process memory — survives the session, not a restart.
// The flight recorder persists to the mission spine; this is just
// the fast-read layer for cross-seat tool calls.

export interface SeatResponse {
  seatIndex: SeatIndex
  missionId: string
  prompt: string
  response: string
  timestamp: string
}

export interface FlaggedDisagreement {
  mySeat: SeatIndex
  theirSeat: SeatIndex
  claim: string
  counter: string
  severity: 'factual' | 'interpretive' | 'strategic'
  timestamp: string
  missionId: string
}

export interface BroadcastMessage {
  /** The seat that sent it, when the caller can attribute one. The harness
   *  routes tool calls without a seat in hand, so this stays optional rather
   *  than fabricating an attribution nobody observed. */
  fromSeat?: SeatIndex
  message: string
  tag?: 'finding' | 'question' | 'claim' | 'context'
  timestamp: string
  missionId: string
}

class CockpitStore {
  private responses: Map<SeatIndex, SeatResponse[]> = new Map()
  private flags: FlaggedDisagreement[] = []
  private broadcasts: BroadcastMessage[] = []

  recordResponse(entry: SeatResponse): void {
    const existing = this.responses.get(entry.seatIndex) ?? []
    // Keep last 20 per seat
    this.responses.set(entry.seatIndex, [...existing.slice(-19), entry])
  }

  readSeat(seatIndex: SeatIndex, last = 1): SeatResponse[] {
    const all = this.responses.get(seatIndex) ?? []
    return all.slice(-last)
  }

  recordFlag(flag: FlaggedDisagreement): void {
    this.flags.push(flag)
  }

  recordBroadcast(msg: BroadcastMessage): void {
    this.broadcasts.push(msg)
  }

  getFlags(): FlaggedDisagreement[] {
    return [...this.flags]
  }

  getBroadcasts(missionId?: string): BroadcastMessage[] {
    if (missionId) return this.broadcasts.filter(b => b.missionId === missionId)
    return [...this.broadcasts]
  }

  clear(): void {
    this.responses.clear()
    this.flags.length = 0
    this.broadcasts.length = 0
  }
}

const globalForStore = globalThis as typeof globalThis & { __omniboxCockpitStore?: CockpitStore }
export const cockpitStore = globalForStore.__omniboxCockpitStore ?? new CockpitStore()
if (!globalForStore.__omniboxCockpitStore) globalForStore.__omniboxCockpitStore = cockpitStore

/**
 * Mountable pack form. The tools read live cockpit state and record into
 * the in-memory store. Mounting makes them exist; a mission's authority
 * decides which a pilot may actually touch.
 */
export function cockpitPack(): CapabilityPack {
  return {
    id: COCKPIT_PACK_NAME,
    name: 'Cockpit coordination',
    description:
      'Cross-seat coordination: who is in the cockpit, what another seat said, shared broadcasts, and recorded cross-provider disagreements.',
    version: '1.0.0',
    maxRisk: 'transform',
    tools: [
      {
        descriptor: COCKPIT_SEATS,
        implementation: async () =>
          neuralink.seatedPilots().map(({ seatIndex, seat }) => ({
            seatIndex,
            status: seat.status,
            type: seat.pilot?.type ?? null,
            label: seat.pilot?.label ?? null,
            missionCount: seat.missionCount,
          })),
      },
      {
        descriptor: COCKPIT_READ_SEAT,
        implementation: async (args) => {
          const seatIndex = Number(args.seatIndex) as SeatIndex;
          const last = typeof args.last === 'number' ? args.last : 1;
          return { responses: cockpitStore.readSeat(seatIndex, last) };
        },
      },
      {
        descriptor: COCKPIT_BROADCAST,
        implementation: async (args, ctx) => {
          const msg: BroadcastMessage = {
            message: String(args.message),
            tag: args.tag === 'finding' || args.tag === 'question' || args.tag === 'claim' || args.tag === 'context'
              ? args.tag
              : undefined,
            timestamp: new Date().toISOString(),
            missionId: ctx.missionId,
          };
          cockpitStore.recordBroadcast(msg);
          return { broadcast: msg };
        },
      },
      {
        descriptor: COCKPIT_FLAG,
        implementation: async (args, ctx) => {
          const flag: FlaggedDisagreement = {
            mySeat: Number(args.mySeat) as SeatIndex,
            theirSeat: Number(args.theirSeat) as SeatIndex,
            claim: String(args.claim),
            counter: String(args.counter),
            severity: args.severity === 'interpretive' || args.severity === 'strategic' ? args.severity : 'factual',
            timestamp: new Date().toISOString(),
            missionId: ctx.missionId,
          };
          cockpitStore.recordFlag(flag);
          return { flag };
        },
      },
      {
        descriptor: COCKPIT_SHAPE,
        implementation: async () => ({ shape: neuralink.getShape() }),
      },
    ],
  }
}
