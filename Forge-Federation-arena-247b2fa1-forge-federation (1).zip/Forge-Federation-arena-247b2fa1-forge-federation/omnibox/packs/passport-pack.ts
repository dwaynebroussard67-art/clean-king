import type { PassportAdapter, PassportContext } from '../contracts.ts';
import type { CapabilityPack } from '../packs.ts';

/**
 * THE PASSPORT PACK -- the link between the harness and the Memory Passport.
 *
 * The Passport is already built. This pack does not reimplement any of it; it
 * exposes the existing PassportAdapter as governed capabilities so a mission
 * reaches memory through the same gate as every other tool, with the same
 * audit trail.
 *
 * Two asymmetries are deliberate:
 *
 *  1. Reading is `read` risk and needs no approval. Writing is `create` risk
 *     and ALWAYS needs one. A machine that can silently write its own memory
 *     can launder a guess into a stored fact, and the Passport's whole value is
 *     that a stored fact carries the receipt of why it is believed.
 *
 *  2. A write goes in as a CANDIDATE, never a promoted memory. Promotion stays
 *     where it already lives -- the Neuralink review path -- so this pack cannot
 *     become a side door around it.
 */
export function passportPack(
  passport: PassportAdapter,
  options: { passportId: string; maxMemories?: number },
): CapabilityPack {
  const maxMemories = options.maxMemories ?? 50;
  let cached: PassportContext | null = null;

  async function context(missionId: string): Promise<PassportContext> {
    if (cached) return cached;
    cached = await passport.loadContext({
      passportId: options.passportId,
      missionId,
      maxMemories,
    });
    return cached;
  }

  return {
    id: 'passport',
    name: 'Memory Passport',
    description: 'Read the mission owner\'s Passport memories and propose new ones.',
    version: '1.0.0',
    maxRisk: 'create',
    tools: [
      {
        descriptor: {
          id: 'passport.search',
          name: 'Search Passport memories',
          description:
            'Find stored memories whose title or content matches a query. Returns the memory, its epistemic status, and its evidence -- never a bare claim.',
          risk: 'read',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: {
            type: 'object',
            properties: {
              query: { type: 'string', minLength: 1, maxLength: 500 },
              limit: { type: 'integer', minimum: 1, maximum: 25 },
            },
            required: ['query'],
            additionalProperties: false,
          },
        },
        async implementation(args, ctx) {
          const frame = await context(ctx.missionId);
          const query = String(args.query).toLowerCase();
          const limit = Number(args.limit ?? 10);
          const terms = query.split(/\s+/).filter(Boolean);
          const hits = frame.memories
            .map((memory) => {
              const haystack = `${memory.title} ${memory.content}`.toLowerCase();
              const score = terms.filter((term) => haystack.includes(term)).length;
              return { memory, score };
            })
            .filter((entry) => entry.score > 0)
            .sort((a, b) => b.score - a.score || Number(b.memory.pinned) - Number(a.memory.pinned))
            .slice(0, limit);

          return {
            query: args.query,
            matched: hits.length,
            searched: frame.memories.length,
            results: hits.map(({ memory, score }) => ({
              id: memory.id,
              title: memory.title,
              content: memory.content,
              status: memory.status,
              evidence: memory.evidence,
              pinned: memory.pinned,
              matchedTerms: score,
            })),
          };
        },
      },
      {
        descriptor: {
          id: 'passport.identity',
          name: 'Read Passport identity',
          description:
            'The owner\'s stable identity frame: name, preferred name, timezone, language. No memories.',
          risk: 'read',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: { type: 'object', properties: {}, additionalProperties: false },
        },
        async implementation(_args, ctx) {
          const frame = await context(ctx.missionId);
          return { passportId: frame.passportId, identity: frame.identity };
        },
      },
      {
        descriptor: {
          id: 'passport.propose_memory',
          name: 'Propose a Passport memory',
          description:
            'Submit a candidate memory with its evidence and scope. Always requires approval, and always lands as a candidate -- promotion is a separate, human-gated decision.',
          risk: 'create',
          requiresApproval: true,
          supportsDryRun: true,
          inputSchema: {
            type: 'object',
            properties: {
              content: { type: 'string', minLength: 1, maxLength: 4000 },
              scope: { type: 'string', minLength: 1, maxLength: 500 },
              evidence: { type: 'array', items: { type: 'string', minLength: 1 } },
              sourceEventIds: { type: 'array', items: { type: 'string' } },
              outcomeStatus: { type: 'string', enum: ['confirmed', 'partial', 'failed', 'unknown'] },
            },
            required: ['content', 'scope', 'evidence'],
            additionalProperties: false,
          },
        },
        async implementation(args, ctx) {
          const evidence = (args.evidence as string[]) ?? [];
          if (evidence.length === 0) {
            throw new Error('a Passport memory cannot be proposed without evidence');
          }
          const candidate = {
            schema: 'omnibox.memory-candidate.v1' as const,
            passportId: options.passportId,
            missionId: ctx.missionId,
            content: String(args.content),
            scope: String(args.scope),
            evidence,
            sourceEventIds: (args.sourceEventIds as string[]) ?? [],
            outcomeStatus: (args.outcomeStatus as 'confirmed' | 'partial' | 'failed' | 'unknown') ?? 'unknown',
            status: 'candidate' as const,
            createdAt: new Date().toISOString(),
          };

          if (ctx.mode === 'dry_run') {
            return { simulated: true, wouldPersist: candidate };
          }
          const { memoryId } = await passport.persistMemoryCandidate(candidate);
          // A candidate changes what a later search sees; drop the cache.
          cached = null;
          return { memoryId, status: 'candidate', scope: candidate.scope };
        },
      },
    ],
    skills: [
      {
        id: 'passport.recall-then-answer',
        name: 'Recall before answering',
        description:
          'Search the Passport before reasoning, so a settled question is answered from evidence instead of re-litigated.',
        requiredCapabilityIds: ['passport.search'],
        steps: [
          {
            id: 'recall',
            description: 'Search the Passport for anything already settled about this question.',
            capabilityId: 'passport.search',
            argumentsTemplate: { query: '{{question}}', limit: 10 },
          },
          {
            id: 'assess',
            description:
              'Decide whether the recalled memories actually answer THIS question. Would the same answer satisfy both? If not, treat it as unanswered.',
          },
          {
            id: 'answer',
            description: 'Answer, citing the evidence of any memory relied on. Never cite a bare claim.',
          },
        ],
        successCriteria: [
          { id: 'evidence', description: 'The answer is recorded with evidence.', type: 'evidence_present' },
        ],
      },
      {
        id: 'passport.record-what-was-learned',
        name: 'Record what was learned',
        description:
          'After a mission produces something durable, propose it as a Passport candidate with its evidence and scope.',
        requiredCapabilityIds: ['passport.propose_memory'],
        steps: [
          {
            id: 'scope',
            description:
              'State the narrowest scope under which this is true. A memory with no stated scope will be reused where it does not apply.',
          },
          {
            id: 'evidence',
            description: 'Collect the observable artifacts that support it. No artifact, no memory.',
          },
          {
            id: 'propose',
            description: 'Submit the candidate for approval.',
            capabilityId: 'passport.propose_memory',
            argumentsTemplate: {
              content: '{{content}}',
              scope: '{{scope}}',
              evidence: '{{evidence}}',
              outcomeStatus: '{{outcomeStatus}}',
            },
          },
        ],
        successCriteria: [
          { id: 'human', description: 'A human approved the candidate.', type: 'human_confirmed' },
        ],
      },
    ],
  };
}
