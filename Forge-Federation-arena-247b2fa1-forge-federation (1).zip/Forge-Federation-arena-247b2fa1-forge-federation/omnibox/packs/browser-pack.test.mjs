/**
 * browser-pack.test.mjs — DOM snapshot and page text hashing wiring.
 *
 * Verifies browser pack now returns content hashes over raw bytes,
 * not JSON.stringify(output), and runtime mints structural witnesses.
 */

import assert from 'node:assert/strict'
import { BrowserPack, browserPack } from './browser-pack.ts'
import { HarnessRuntime, InMemoryMissionStore } from '../runtime.ts'
import { hashDomSnapshot, hashPageText, hashPngBase64 } from '../hashing.ts'

let passed = 0, failed = 0
const failures = []
function test(name, fn) { try { fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }
async function atest(name, fn) { try { await fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }

function makeBridge(responses = {}) {
  return {
    calls: [],
    invoke(tool, args) {
      this.calls.push({ tool, args })
      const r = responses[tool]
      return Promise.resolve(typeof r === 'function' ? r(args) : r)
    },
  }
}

await atest('read_page returns contentHash over raw text bytes, not JSON wrapper', async () => {
  const snapText = 'Hello  world  \nSecond line'
  const bridge = makeBridge({
    'browser.read_page': { url: 'https://example.com', title: 'Test', text: snapText },
  })
  BrowserPack.setBridge(bridge)
  const out = await BrowserPack.readPage({})
  assert.match(out.contentHash, /^sha256:[a-f0-9]{64}$/)
  assert.equal(out._structuralRef, out.contentHash)
  // hash should equal hashPageText(snapText), not JSON.stringify wrapper
  assert.equal(out.contentHash, hashPageText(snapText))
  const wrapperHash = `hash_of_${JSON.stringify({ url: 'https://example.com', title: 'Test', text: snapText })}`
  // Demonstrate wrapper differs conceptually — content hash is stable regardless of url/title
  assert.ok(true)
})

await atest('snapshot returns snapshotHash over canonical snapshot bytes', async () => {
  const snapshot = 'URL: https://example.com\r\nTITLE: Test\r\n\n## heading\n[1] button "Click me"  \n'
  const bridge = makeBridge({
    'browser.snapshot': snapshot,
  })
  BrowserPack.setBridge(bridge)
  const out = await BrowserPack.snapshot({})
  assert.match(out.snapshotHash, /^sha256:[a-f0-9]{64}$/)
  assert.equal(out._structuralRef, out.snapshotHash)
  assert.equal(out.snapshotHash, hashDomSnapshot(snapshot), 'snapshot hash must be canonicalized raw bytes')
})

await atest('screenshot returns pngHash over raw PNG bytes, not JSON.stringify({png})', async () => {
  const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII='
  const bridge = makeBridge({
    'browser.screenshot': { png: pngBase64, width: 1, height: 1 },
  })
  BrowserPack.setBridge(bridge)
  const out = await BrowserPack.screenshot({})
  assert.match(out.pngHash, /^sha256:[a-f0-9]{64}$/)
  assert.equal(out._structuralRef, out.pngHash)
  assert.equal(out.pngHash, hashPngBase64(pngBase64))
})

await atest('runtime mints structural witness from browser.read_page contentHash', async () => {
  const bridge = makeBridge({
    'browser.read_page': { url: 'https://example.com', title: 'T', text: 'page content for hashing' },
  })
  BrowserPack.setBridge(bridge)

  const store = new InMemoryMissionStore()
  const runtime = new HarnessRuntime({
    store,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
    harnessId: 'harness-browser-test',
  })
  runtime.mount(browserPack())
  const mission = await runtime.createMission({
    goal: 'test browser witness',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['browser.read_page'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await runtime.bindNeuralink(mission.id)
  await runtime.beginPlanning(mission.id)
  const result = await runtime.runTool({ missionId: mission.id, capabilityId: 'browser.read_page', arguments: {} })
  assert.equal(result.status, 'succeeded')
  assert.ok(result.structuralWitness, 'missing structural witness for page text')
  assert.equal(result.structuralWitness.kind, 'structural')
  assert.match(result.structuralWitness.reference, /^sha256:[a-f0-9]{64}$/)
  // ref must equal content hash from output (raw bytes), not wrapper hash
  assert.equal(result.structuralWitness.reference, result.output.contentHash)
})

await atest('runtime mints structural witness from browser.snapshot', async () => {
  const snapshot = 'URL: https://example.com\nTITLE: Test\n\n## sec\n[1] button "A"'
  const bridge = makeBridge({ 'browser.snapshot': snapshot })
  BrowserPack.setBridge(bridge)

  const store = new InMemoryMissionStore()
  const runtime = new HarnessRuntime({
    store,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
    harnessId: 'harness-snap-test',
  })
  runtime.mount(browserPack())
  const mission = await runtime.createMission({
    goal: 'test snapshot witness',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['browser.snapshot'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await runtime.bindNeuralink(mission.id)
  await runtime.beginPlanning(mission.id)
  const result = await runtime.runTool({ missionId: mission.id, capabilityId: 'browser.snapshot', arguments: {} })
  assert.ok(result.structuralWitness, 'missing structural witness for snapshot')
  assert.equal(result.structuralWitness.reference, hashDomSnapshot(snapshot))
})

console.log(`\nbrowser-pack: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
