/**
 * http-pack.ts — fetch as a governed capability with content-addressed witnesses.
 *
 * DESIGN:
 *  - Tool id: http.fetch — risk external_side_effect, because it touches the network.
 *  - Input: url (required, https only by default), method, headers, body (string), maxBytes.
 *  - Output: { url, status, statusText, headers, byteLength, bodyHash: sha256:..., bodyText (truncated), bodyTruncated }
 *  - Witness: structural witness minted from RAW BODY BYTES, NOT JSON.stringify(output).
 *
 * WHY RAW BYTES:
 *  - JSON.stringify({ body, status, headers, ... }) is unstable: key order, header order,
 *    inclusion of transient fields, base64 wrapping all change the hash even when body is identical.
 *  - Two identical bodies fetched at different times would otherwise get different hashes
 *    because statusText or date header differed inside the wrapper.
 *  - Collective fact identity needs to be over the CONTENT, not the envelope.
 *
 * PLUMBING:
 *  - Implementation computes sha256(bodyBytes) -> ref, then calls WitnessPlumbing
 *    via the harness runtime's plumbing (or directly via collective/witness if we are
 *    in a tool context where harnessId is available). For now we compute hash and
 *    return it; runtime will mint the structural witness from that hash. Pilot never
 *    supplies hash — plumbing recomputes from bytes it fetched.
 *
 * SECURITY:
 *  - URL must be http/https, no file://.
 *  - maxBytes ceiling (default 1 MiB) to avoid OOM.
 *  - Timeout via AbortSignal.
 *  - Response headers filtered to allowlist to avoid leaking cookies etc into tool output.
 */

import type { CapabilityDescriptor } from '../contracts.ts'
import type { CapabilityPack } from '../packs.ts'
import { sha256Ref, hashFetchBody, truncateText } from '../hashing.ts'

const MAX_BYTES_DEFAULT = 1_000_000
const FETCH_TIMEOUT_MS = 15_000
const SAFE_HEADER_ALLOWLIST = new Set([
  'content-type',
  'content-length',
  'content-encoding',
  'etag',
  'last-modified',
  'cache-control',
  'expires',
])

function filterHeaders(headers: Headers): Record<string, string> {
  const out: Record<string, string> = {}
  for (const [k, v] of headers.entries()) {
    if (SAFE_HEADER_ALLOWLIST.has(k.toLowerCase())) {
      out[k.toLowerCase()] = v.slice(0, 2000)
    }
  }
  return out
}

export const HTTP_FETCH: CapabilityDescriptor = {
  id: 'http.fetch',
  name: 'Fetch a URL',
  description:
    'Fetch an HTTP(S) URL and return status + body hash. Body is hashed as raw bytes (sha256:...) — not JSON.stringify(output). The hash is the artifact ref for structural witnesses. Body text truncated for display.',
  inputSchema: {
    type: 'object',
    required: ['url'],
    properties: {
      url: { type: 'string', description: 'Fully-qualified https:// URL' },
      method: { type: 'string', enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD'], description: 'HTTP method. Default GET.' },
      headers: { type: 'object', additionalProperties: { type: 'string' }, description: 'Optional request headers (filtered)' },
      body: { type: 'string', description: 'Optional request body as text' },
      maxBytes: { type: 'number', description: 'Max response bytes to read. Default 1 MiB.' },
      includeBodyText: { type: 'boolean', description: 'If true, include truncated body text. Default true for text/*.' },
    },
    additionalProperties: false,
  },
  risk: 'external_side_effect',
  requiresApproval: false,
  supportsDryRun: true,
}

type FetchArgs = {
  url: string
  method?: string
  headers?: Record<string, string>
  body?: string
  maxBytes?: number
  includeBodyText?: boolean
}

type FetchOutput = {
  url: string
  status: number
  statusText: string
  headers: Record<string, string>
  byteLength: number
  bodyHash: string // sha256:...
  bodyText?: string
  bodyTruncated: boolean
  contentType?: string
  // Content-addressed refs for wiring — NOT JSON.stringify(output)
  _structuralRef?: string // same as bodyHash, explicit for runtime collector
}

export async function fetchImpl(args: FetchArgs, ctx: { missionId: string; toolCallId: string; mode: string; signal?: AbortSignal }): Promise<FetchOutput> {
  if (ctx.mode === 'dry_run') {
    return {
      url: String(args.url),
      status: 0,
      statusText: 'dry_run',
      headers: {},
      byteLength: 0,
      bodyHash: 'sha256:dry_run',
      bodyText: '[dry_run] would fetch URL',
      bodyTruncated: false,
      _structuralRef: 'sha256:dry_run',
    } as any
  }

  const urlStr = String(args.url)
  let url: URL
  try {
    url = new URL(urlStr)
  } catch {
    throw new Error(`http.fetch: invalid URL "${urlStr}"`)
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new Error(`http.fetch: only http/https allowed, got ${url.protocol}`)
  }

  const maxBytes = typeof args.maxBytes === 'number' ? Math.min(Math.max(args.maxBytes, 1), 10_000_000) : MAX_BYTES_DEFAULT
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS)
  const combinedSignal = ctx.signal
    ? AbortSignal.any([ctx.signal, controller.signal])
    : controller.signal

  try {
    const method = (args.method ?? 'GET').toUpperCase()
    const reqHeaders: Record<string, string> = {}
    if (args.headers && typeof args.headers === 'object') {
      for (const [k, v] of Object.entries(args.headers)) {
        if (typeof k === 'string' && typeof v === 'string') {
          reqHeaders[k.slice(0, 200)] = v.slice(0, 4000)
        }
      }
    }

    const response = await fetch(url.toString(), {
      method,
      headers: reqHeaders,
      body: method === 'GET' || method === 'HEAD' ? undefined : args.body,
      signal: combinedSignal,
    })

    const contentType = response.headers.get('content-type') ?? undefined
    const filtered = filterHeaders(response.headers)

    // Read body as ArrayBuffer with maxBytes ceiling
    const reader = response.body?.getReader()
    let total = 0
    const chunks: Uint8Array[] = []
    if (reader) {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) {
          const remaining = maxBytes - total
          if (remaining <= 0) break
          if (value.length > remaining) {
            chunks.push(value.slice(0, remaining))
            total += remaining
            break
          } else {
            chunks.push(value)
            total += value.length
          }
          if (total >= maxBytes) break
        }
      }
    } else {
      // Fallback: no streaming body (e.g., mocked fetch)
      const buf = await response.arrayBuffer()
      const bytes = new Uint8Array(buf)
      const slice = bytes.length > maxBytes ? bytes.slice(0, maxBytes) : bytes
      chunks.push(slice)
      total = slice.length
    }

    // Concatenate
    const bodyBytes = new Uint8Array(total)
    let offset = 0
    for (const chunk of chunks) {
      bodyBytes.set(chunk, offset)
      offset += chunk.length
    }

    // Hash RAW BYTES — not JSON.stringify(output)
    const bodyHash = hashFetchBody(bodyBytes)

    // Optional text decoding (truncated) for human-readable output
    let bodyText: string | undefined
    let bodyTruncated = total >= maxBytes
    const shouldIncludeText = args.includeBodyText !== false // default true
    if (shouldIncludeText) {
      try {
        const decoder = new TextDecoder('utf-8', { fatal: false })
        const fullText = decoder.decode(bodyBytes)
        const { truncated, wasTruncated } = truncateText(fullText, 8000)
        bodyText = truncated
        bodyTruncated = bodyTruncated || wasTruncated
      } catch {
        bodyText = undefined
      }
    }

    return {
      url: url.toString(),
      status: response.status,
      statusText: response.statusText,
      headers: filtered,
      byteLength: total,
      bodyHash,
      bodyText,
      bodyTruncated,
      contentType,
      _structuralRef: bodyHash,
    }
  } finally {
    clearTimeout(timeout)
  }
}

export const HTTP_PACK_NAME = 'http'

export function httpPack(): CapabilityPack {
  return {
    id: HTTP_PACK_NAME,
    name: 'HTTP fetch',
    description:
      'Governed HTTP fetch: raw body bytes are hashed (sha256:...) for structural witnesses, not JSON.stringify(output). Body hash is content-addressed.',
    version: '1.0.0',
    maxRisk: 'external_side_effect',
    tools: [
      {
        descriptor: HTTP_FETCH,
        implementation: async (args, ctx) =>
          fetchImpl(
            {
              url: String((args as any).url),
              method: typeof (args as any).method === 'string' ? (args as any).method : undefined,
              headers: (args as any).headers as any,
              body: typeof (args as any).body === 'string' ? (args as any).body : undefined,
              maxBytes: typeof (args as any).maxBytes === 'number' ? (args as any).maxBytes : undefined,
              includeBodyText: typeof (args as any).includeBodyText === 'boolean' ? (args as any).includeBodyText : undefined,
            },
            ctx,
          ),
      },
    ],
  }
}
