/**
 * http-pack.test.mjs — fetch body bytes hashing wiring.
 *
 * Verifies:
 *  - fetchImpl hashes raw body bytes, not JSON.stringify(output)
 *  - returns bodyHash = sha256:hex
 *  - _structuralRef equals bodyHash for runtime collector
 *  - same body different envelope -> same hash
 *  - runtime mints structural witness from that hash (not from JSON wrapper)
 */

import assert from 'node:assert/strict'
import { fetchImpl } from './http-pack.ts'
import { HarnessRuntime, InMemoryMissionStore } from '../runtime.ts'
import { CapabilityRegistry } from '../capabilities.ts'
import { httpPack } from './http-pack.ts'

let passed = 0, failed = 0
const failures = []
function test(name, fn) { try { fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }
async function atest(name, fn) { try { await fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }

// Mock fetch that returns controllable body
function mockFetch(bodyText, extra = {}) {
  const bodyBytes = new TextEncoder().encode(bodyText)
  return async (_url, _init) => ({
    status: extra.status ?? 200,
    statusText: extra.statusText ?? 'OK',
    headers: {
      get: (k) => (k.toLowerCase() === 'content-type' ? 'text/plain' : null),
      entries: function* () { yield ['content-type', 'text/plain']; },
    },
    body: {
      getReader() {
        let done = false
        return {
          read() {
            if (done) return Promise.resolve({ done: true, value: undefined })
            done = true
            return Promise.resolve({ done: false, value: bodyBytes })
          },
        }
      },
    },
  })
}

await atest('http.fetch hashes raw body bytes, not JSON.stringify wrapper', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = mockFetch('hello world', { status: 200 })
  try {
    const out = await fetchImpl({ url: 'https://example.com' }, { missionId: 'm1', toolCallId: 't1', mode: 'execute' })
    assert.match(out.bodyHash, /^sha256:[a-f0-9]{64}$/)
    assert.equal(out._structuralRef, out.bodyHash)
    assert.equal(out.byteLength, 11)
    // body bytes hash should be sha256("hello world")
    const expectedHex = 'b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9'
    assert.equal(out.bodyHash, `sha256:${expectedHex}`)
  } finally {
    globalThis.fetch = originalFetch
  }
})

await atest('same body different status still same bodyHash — proves not hashing envelope', async () => {
  const originalFetch = globalThis.fetch
  // first with 200
  globalThis.fetch = mockFetch('same body', { status: 200 })
  const out200 = await fetchImpl({ url: 'https://example.com' }, { missionId: 'm1', toolCallId: 't1', mode: 'execute' })
  // then 404 same body
  globalThis.fetch = mockFetch('same body', { status: 404, statusText: 'Not Found' })
  const out404 = await fetchImpl({ url: 'https://example.com' }, { missionId: 'm1', toolCallId: 't2', mode: 'execute' })
  assert.equal(out200.bodyHash, out404.bodyHash, 'bodyHash must be content-addressed, not envelope-addressed')
  assert.notEqual(out200.status, out404.status)
  globalThis.fetch = originalFetch
})

await atest('runtime mints structural witness from fetch bodyHash, not JSON.stringify', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = mockFetch('structural witness body', { status: 200 })
  try {
    const store = new InMemoryMissionStore()
    const runtime = new HarnessRuntime({
      store,
      passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
      harnessId: 'harness-test-http',
    })
    runtime.mount(httpPack())
    const mission = await runtime.createMission({
      goal: 'test fetch witness',
      passportId: 'p1',
      authority: { actorId: 'tester', allowedCapabilityIds: ['http.fetch'], autoApproveRiskAtMost: 'external_side_effect' },
    })
    await runtime.bindNeuralink(mission.id)
    await runtime.beginPlanning(mission.id)
    const result = await runtime.runTool({ missionId: mission.id, capabilityId: 'http.fetch', arguments: { url: 'https://example.com' } })
    assert.equal(result.status, 'succeeded')
    // outcome witness always present
    assert.ok(result.witness, 'missing outcome witness')
    assert.equal(result.witness.kind, 'outcome')
    // structural witness from body bytes must be present
    assert.ok(result.structuralWitness, 'missing structural witness — fetch body hash not minted')
    assert.equal(result.structuralWitness.kind, 'structural')
    assert.match(result.structuralWitness.reference, /^sha256:[a-f0-9]{64}$/)
    // event spine must contain both
    const events = await store.listEvents(mission.id)
    const invoked = events.find(e => e.type === 'tool_invoked')
    assert.ok(invoked.payload.witness, 'outcome witness not on event')
    assert.ok(invoked.payload.structuralWitness, 'structural witness not on event spine')
    assert.equal(invoked.payload.structuralWitness.reference, result.structuralWitness.reference)
    // ensure structural ref equals bodyHash from output, not wrapper hash
    const bodyHash = result.output.bodyHash
    assert.equal(invoked.payload.structuralWitness.reference, bodyHash)
  } finally {
    globalThis.fetch = originalFetch
  }
})

await atest('dry_run does not fetch network and returns placeholder hash', async () => {
  const originalFetch = globalThis.fetch
  let called = false
  globalThis.fetch = async () => { called = true; throw new Error('should not be called in dry_run') }
  try {
    const out = await fetchImpl({ url: 'https://example.com' }, { missionId: 'm1', toolCallId: 't1', mode: 'dry_run' })
    assert.equal(called, false)
    assert.equal(out.statusText, 'dry_run')
  } finally {
    globalThis.fetch = originalFetch
  }
})

console.log(`\nhttp-pack: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
