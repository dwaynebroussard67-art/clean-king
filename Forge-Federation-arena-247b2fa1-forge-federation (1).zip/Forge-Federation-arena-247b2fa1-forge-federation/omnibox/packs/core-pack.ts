import type { CapabilityPack } from '../packs.ts';

/**
 * THE CORE PACK -- the capabilities every mission gets.
 *
 * Nothing here touches the network, the filesystem, or the database. Its
 * maxRisk is `transform`, which means the pack registry will refuse to mount it
 * if anyone ever tries to slip a `delete` or an `external_side_effect` tool in
 * here later. That refusal is the point: a pack's declared ceiling is a
 * standing assertion, checked at mount time, not a comment.
 *
 * The scratchpad is per-mission and lives only as long as the harness process.
 * It is a working surface, not memory -- durable memory goes through the
 * Passport pack, where it needs evidence, a scope, and an approval.
 */
export function corePack(): CapabilityPack {
  const scratch = new Map<string, Map<string, unknown>>();

  function pad(missionId: string): Map<string, unknown> {
    let existing = scratch.get(missionId);
    if (!existing) {
      existing = new Map();
      scratch.set(missionId, existing);
    }
    return existing;
  }

  return {
    id: 'core',
    name: 'Core reasoning',
    description: 'Scratch working memory and evidence collection. No external side effects.',
    version: '1.0.0',
    maxRisk: 'transform',
    tools: [
      {
        descriptor: {
          id: 'core.note',
          name: 'Write a scratch note',
          description:
            'Record an intermediate finding under a key. Scoped to this mission and discarded when it ends.',
          risk: 'transform',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: {
            type: 'object',
            properties: {
              key: { type: 'string', minLength: 1, maxLength: 120 },
              value: {},
            },
            required: ['key', 'value'],
            additionalProperties: false,
          },
        },
        async implementation(args, ctx) {
          if (ctx.mode === 'dry_run') {
            return { simulated: true, wouldWrite: args.key };
          }
          pad(ctx.missionId).set(String(args.key), args.value);
          return { key: args.key, stored: true, keys: [...pad(ctx.missionId).keys()].sort() };
        },
      },
      {
        descriptor: {
          id: 'core.recall_note',
          name: 'Read scratch notes',
          description: 'Read one scratch note by key, or list every key when no key is given.',
          risk: 'read',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: {
            type: 'object',
            properties: { key: { type: 'string', minLength: 1, maxLength: 120 } },
            additionalProperties: false,
          },
        },
        async implementation(args, ctx) {
          const notes = pad(ctx.missionId);
          if (args.key === undefined) return { keys: [...notes.keys()].sort() };
          const key = String(args.key);
          if (!notes.has(key)) return { key, found: false };
          return { key, found: true, value: notes.get(key) };
        },
      },
      {
        descriptor: {
          id: 'core.record_evidence',
          name: 'Record a piece of evidence',
          description:
            'Attach an observable artifact -- a URL, file path, commit, query, or run id -- to this mission. Evidence is what turns a claim into a memory that can be checked instead of re-argued.',
          risk: 'transform',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: {
            type: 'object',
            properties: {
              pointer: { type: 'string', minLength: 1, maxLength: 1000 },
              supports: { type: 'string', minLength: 1, maxLength: 1000 },
              origin: { type: 'string', enum: ['observed', 'inferred', 'derived'] },
            },
            required: ['pointer', 'supports', 'origin'],
            additionalProperties: false,
          },
        },
        async implementation(args, ctx) {
          // origin is required with no default on purpose. The manual's hard
          // rule: the harness must never fabricate a reasoning history, and an
          // untagged element is indistinguishable from an observed one later.
          const notes = pad(ctx.missionId);
          const existing = (notes.get('__evidence__') as unknown[]) ?? [];
          const entry = {
            pointer: String(args.pointer),
            supports: String(args.supports),
            origin: String(args.origin),
            recordedAt: new Date().toISOString(),
          };
          if (ctx.mode === 'dry_run') return { simulated: true, wouldRecord: entry };
          notes.set('__evidence__', [...existing, entry]);
          return { recorded: entry, total: existing.length + 1 };
        },
      },
      {
        descriptor: {
          id: 'core.list_evidence',
          name: 'List recorded evidence',
          description: 'Every artifact recorded on this mission so far, with its origin tag.',
          risk: 'read',
          requiresApproval: false,
          supportsDryRun: true,
          inputSchema: { type: 'object', properties: {}, additionalProperties: false },
        },
        async implementation(_args, ctx) {
          const evidence = (pad(ctx.missionId).get('__evidence__') as unknown[]) ?? [];
          return { count: evidence.length, evidence };
        },
      },
    ],
    skills: [
      {
        id: 'core.evidence-first',
        name: 'Evidence before conclusion',
        description:
          'Record what was actually observed before stating what it means, so the conclusion can be checked against the artifacts rather than taken on trust.',
        requiredCapabilityIds: ['core.record_evidence', 'core.list_evidence'],
        steps: [
          {
            id: 'observe',
            description: 'Record each artifact as it is found, tagged observed / inferred / derived.',
            capabilityId: 'core.record_evidence',
            argumentsTemplate: {
              pointer: '{{pointer}}',
              supports: '{{supports}}',
              origin: '{{origin}}',
            },
          },
          {
            id: 'review',
            description: 'List everything recorded and check the conclusion is actually carried by it.',
            capabilityId: 'core.list_evidence',
          },
          {
            id: 'state',
            description:
              'State the conclusion and its ceiling: what this evidence does NOT establish.',
          },
        ],
        successCriteria: [
          { id: 'evidence', description: 'Evidence was recorded.', type: 'evidence_present' },
        ],
      },
    ],
  };
}
