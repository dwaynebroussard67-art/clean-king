"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, X, Bot, ArrowUp, PlugZap, Sparkles } from "lucide-react";
import type { DetectedProvider } from "@/lib/model-provider";

type Msg = { role: "user" | "assistant"; content: string; error?: boolean; provider?: string };

type Props = {
  open: boolean;
  onClose: () => void;
  pageContext: { url: string; title: string; snapshot: string } | null;
  /** Auto-detected from the page open in the browser. */
  provider: DetectedProvider | null;
};

export function AssistantPanel({ open, onClose, pageContext, provider }: Props) {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "I am your AI dock. I auto-link to the model provider on the page you have open — open claude.ai, ChatGPT, Gemini, or a local model and I connect to it automatically. Ask me anything.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [includePage, setIncludePage] = useState(true);
  const endRef = useRef<HTMLDivElement>(null);

  const scrollToEnd = useCallback(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToEnd();
  }, [messages, loading, scrollToEnd]);

  // The greeting used to be written by an effect on first open: a setState
  // during commit that re-rendered the panel for nothing. It never depended
  // on anything fetched, so it is initial state now.

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    const userMsg: Msg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: provider?.id ?? "default",
          messages: [...messages, userMsg]
            .filter((m) => !m.error)
            .map((m) => ({ role: m.role, content: m.content })),
          page: includePage ? pageContext : undefined,
        }),
      });
      const data = await res.json();
      if (data.error) {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: data.error, error: true },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: data.content, provider: data.provider },
        ]);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Failed to reach the model. Please try again.", error: true },
      ]);
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <aside className="w-[360px] max-w-[46vw] shrink-0 flex flex-col bg-[#0b1220] border-l border-white/[0.08] animate-slide-in">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/[0.08] flex items-center gap-2">
        <span className="h-6 w-6 rounded-lg bg-gradient-to-br from-indigo-400 to-violet-500 grid place-items-center">
          <Bot className="h-3.5 w-3.5 text-white" />
        </span>
        <div className="flex-1">
          <div className="text-sm font-semibold text-white">AI Dock</div>
          <div className="text-[10px] text-slate-500">auto-links to the page you&apos;re on</div>
        </div>
        <button
          onClick={onClose}
          aria-label="Close dock"
          className="h-7 w-7 grid place-items-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Auto-link status */}
      <div className="px-4 py-3 border-b border-white/[0.08]">
        <div className="flex items-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3 py-2.5">
          <PlugZap
            className={`h-4 w-4 shrink-0 ${provider ? "text-emerald-400" : "text-slate-500"}`}
          />
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-widest text-slate-500">Linked to</div>
            <div className="text-sm font-medium text-slate-100 truncate">
              {provider ? `${provider.name} · ${provider.host}` : "Default model"}
            </div>
          </div>
        </div>
        <div className="mt-2 text-[10px] text-slate-600 leading-relaxed">
          Open a model&apos;s site in the browser and the dock connects to it automatically. No names, no
          choosing — the model you&apos;re looking at is the model that answers.
        </div>
        <label className="mt-3 flex items-center gap-2 text-xs text-slate-400">
          <input
            type="checkbox"
            checked={includePage}
            onChange={(e) => setIncludePage(e.target.checked)}
            className="accent-indigo-500"
          />
          Use current page as context
        </label>
      </div>

      {/* Messages */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`max-w-[92%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${
              msg.role === "user"
                ? "ml-auto bg-indigo-500/20 text-indigo-50 border border-indigo-400/20"
                : msg.error
                  ? "bg-red-500/10 text-red-200 border border-red-500/20"
                  : "bg-white/[0.05] text-slate-200 border border-white/[0.06]"
            }`}
          >
            <div className="text-[10px] uppercase tracking-wider opacity-60 mb-1">
              {msg.role === "user" ? "you" : msg.error ? "error" : "dock"}
              {msg.provider ? ` · ${msg.provider}` : ""}
            </div>
            <div className="whitespace-pre-wrap">{msg.content}</div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" /> thinking…
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t border-white/[0.08]">
        <div className="flex items-end gap-2 rounded-2xl bg-[#0a1124] border border-white/10 focus-within:border-indigo-400/50 px-3 py-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send();
              }
            }}
            placeholder="Ask the dock…"
            rows={2}
            className="flex-1 resize-none bg-transparent text-sm text-white placeholder:text-slate-500 outline-none"
          />
          <button
            onClick={() => void send()}
            disabled={loading || !input.trim()}
            aria-label="Send"
            className="h-8 w-8 shrink-0 grid place-items-center rounded-lg bg-gradient-to-r from-indigo-500 to-violet-500 text-white disabled:opacity-40 hover:from-indigo-400 hover:to-violet-400 transition"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
          </button>
        </div>
        <div className="mt-2 flex items-center justify-center gap-1 text-[10px] text-slate-600">
          <Sparkles className="h-3 w-3" /> add a provider key to the server env to connect
        </div>
      </div>
    </aside>
  );
}
