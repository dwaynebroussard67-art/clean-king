/**
 * A small, dependency-free validator for the subset of JSON Schema that
 * capability descriptors actually use.
 *
 * This exists because `CapabilityDescriptor.inputSchema` was declared and never
 * enforced: arguments reached the authorization path unconstrained. A schema
 * nobody checks is documentation, not a boundary.
 *
 * Deliberately small. It supports type, required, properties, enum, const,
 * items, minimum/maximum, minLength/maxLength, pattern and
 * additionalProperties. Anything it does not understand it ignores rather than
 * guessing -- an unknown keyword must never silently pass or silently fail.
 */

export type SchemaViolation = { path: string; message: string };

export function validate(
  schema: Record<string, unknown> | undefined,
  value: unknown,
): SchemaViolation[] {
  if (!schema || typeof schema !== 'object') return [];
  return walk(schema, value, '$');
}

export function assertValid(
  schema: Record<string, unknown> | undefined,
  value: unknown,
  label: string,
): void {
  const violations = validate(schema, value);
  if (violations.length === 0) return;
  const detail = violations.map((v) => `${v.path}: ${v.message}`).join('; ');
  throw new SchemaViolationError(label, violations, detail);
}

export class SchemaViolationError extends Error {
  readonly code = 'SCHEMA_VIOLATION';
  readonly violations: SchemaViolation[];

  constructor(label: string, violations: SchemaViolation[], detail: string) {
    super(`${label} does not satisfy its declared schema: ${detail}`);
    this.name = 'SchemaViolationError';
    this.violations = violations;
  }
}

function typeOf(value: unknown): string {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  if (Number.isInteger(value)) return 'integer';
  return typeof value;
}

function typeMatches(expected: string, value: unknown): boolean {
  const actual = typeOf(value);
  if (expected === 'number') return actual === 'number' || actual === 'integer';
  if (expected === 'integer') return actual === 'integer';
  return actual === expected;
}

function walk(schema: Record<string, unknown>, value: unknown, path: string): SchemaViolation[] {
  const out: SchemaViolation[] = [];

  const type = schema.type;
  if (typeof type === 'string' && !typeMatches(type, value)) {
    out.push({ path, message: `expected ${type}, received ${typeOf(value)}` });
    return out;
  }
  if (Array.isArray(type) && !type.some((candidate) => typeMatches(String(candidate), value))) {
    out.push({ path, message: `expected one of ${type.join('|')}, received ${typeOf(value)}` });
    return out;
  }

  if (Array.isArray(schema.enum) && !schema.enum.some((option) => deepEqual(option, value))) {
    out.push({ path, message: `value is not one of the permitted options` });
  }
  if ('const' in schema && !deepEqual(schema.const, value)) {
    out.push({ path, message: 'value does not equal the required constant' });
  }

  if (typeof value === 'number') {
    if (typeof schema.minimum === 'number' && value < schema.minimum) {
      out.push({ path, message: `must be >= ${schema.minimum}` });
    }
    if (typeof schema.maximum === 'number' && value > schema.maximum) {
      out.push({ path, message: `must be <= ${schema.maximum}` });
    }
  }

  if (typeof value === 'string') {
    if (typeof schema.minLength === 'number' && value.length < schema.minLength) {
      out.push({ path, message: `must be at least ${schema.minLength} characters` });
    }
    if (typeof schema.maxLength === 'number' && value.length > schema.maxLength) {
      out.push({ path, message: `must be at most ${schema.maxLength} characters` });
    }
    if (typeof schema.pattern === 'string' && !new RegExp(schema.pattern).test(value)) {
      out.push({ path, message: `does not match ${schema.pattern}` });
    }
  }

  if (Array.isArray(value) && schema.items && typeof schema.items === 'object') {
    value.forEach((entry, index) => {
      out.push(...walk(schema.items as Record<string, unknown>, entry, `${path}[${index}]`));
    });
  }

  if (isPlainObject(value)) {
    const properties = isPlainObject(schema.properties) ? schema.properties : {};
    const required = Array.isArray(schema.required) ? schema.required.map(String) : [];
    for (const key of required) {
      if (!(key in value)) out.push({ path: `${path}.${key}`, message: 'is required' });
    }
    for (const [key, entry] of Object.entries(value)) {
      const child = properties[key];
      if (isPlainObject(child)) {
        out.push(...walk(child, entry, `${path}.${key}`));
      } else if (schema.additionalProperties === false) {
        out.push({ path: `${path}.${key}`, message: 'is not a permitted property' });
      }
    }
  }

  return out;
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function deepEqual(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((entry, index) => deepEqual(entry, b[index]));
  }
  if (isPlainObject(a) && isPlainObject(b)) {
    const aKeys = Object.keys(a).sort();
    const bKeys = Object.keys(b).sort();
    return deepEqual(aKeys, bKeys) && aKeys.every((key) => deepEqual(a[key], b[key]));
  }
  return false;
}
