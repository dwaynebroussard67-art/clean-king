'use client'

/**
 * THE GUN BASE.
 *
 * Every mounted function, the named belts, and a way to fire one through
 * the gate. You load a belt for the job you know you are walking into.
 * The captain is the only seat that sees it. Writes still wait for you.
 */

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { BELTS, type BeltId } from '@/lib/belts.ts'

const MONO = "ui-monospace, 'SF Mono', 'Cascadia Mono', 'Roboto Mono', Menlo, monospace"

type Capability = {
  id: string
  name: string
  description: string
  risk: string
  requiresApproval: boolean
  packId: string | null
  inputSchema: Record<string, unknown>
}

type Pack = { id: string; name: string; version: string; capabilityIds: string[]; skillIds: string[] }

type Catalog = {
  packs: Pack[]
  capabilities: Capability[]
  belts: typeof BELTS
  gaps: unknown[]
  bridge: { mode?: string }
}

type FireResult = {
  missionId?: string
  awaitingApproval?: boolean
  result?: { status?: string; output?: unknown; error?: string }
  error?: string
  toolCall?: { id: string; arguments: Record<string, unknown>; argumentsDigest: string; capabilityId: string; requestedAt: string; missionId: string }
}

export default function FunctionsPage() {
  const [catalog, setCatalog] = useState<Catalog | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [beltId, setBeltId] = useState<BeltId>('browse')
  const [picked, setPicked] = useState<string>('browser.read_page')
  const [argsText, setArgsText] = useState('{}')
  const [intent, setIntent] = useState('')
  const [busy, setBusy] = useState(false)
  const [last, setLast] = useState<FireResult | null>(null)
  const [customIds, setCustomIds] = useState<string[]>([])

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/harness/functions', { cache: 'no-store' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || res.statusText)
      setCatalog(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    }
  }, [])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load()
  }, [load])

  const activeBelt = useMemo(() => {
    if (beltId === 'custom') return customIds
    return BELTS.find((b) => b.id === beltId)?.capabilityIds ?? []
  }, [beltId, customIds])

  const selected = catalog?.capabilities.find((c) => c.id === picked) ?? null

  const fire = async () => {
    let args: Record<string, unknown> = {}
    try {
      const parsed = JSON.parse(argsText || '{}')
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('args must be an object')
      args = parsed as Record<string, unknown>
    } catch (err) {
      setError(err instanceof Error ? err.message : 'args are not JSON')
      return
    }
    setBusy(true)
    setError(null)
    try {
      const res = await fetch('/api/harness/functions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          capabilityId: picked,
          args,
          intent: intent.trim() || undefined,
          beltId,
          capabilityIds: beltId === 'custom' ? customIds : undefined,
        }),
      })
      const data = await res.json() as FireResult
      setLast(data)
      if (!res.ok && res.status !== 202) setError(data.error || res.statusText)
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(false)
    }
  }

  const decide = async (action: 'approve' | 'reject') => {
    if (!last?.missionId || !last.toolCall) return
    setBusy(true)
    try {
      const res = await fetch(`/api/harness/missions/${last.missionId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          toolCallId: last.toolCall.id,
          toolCall: last.toolCall,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || res.statusText)
      setLast({ missionId: last.missionId, result: data.result })
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(false)
    }
  }

  const toggleCustom = (id: string) => {
    setCustomIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])
    setBeltId('custom')
  }

  return (
    <div style={{ fontFamily: MONO }} className="min-h-screen bg-[#FBFAF7] text-[#14140F]">
      <header className="border-b border-[#D8D5CC] px-4 sm:px-6 py-3 flex items-baseline gap-4 flex-wrap">
        <h1 className="text-sm font-bold tracking-[0.22em] uppercase">OmniBox</h1>
        <span className="text-[10px] tracking-[0.18em] uppercase text-[#14140F]/45">Gun base</span>
        <div className="ml-auto flex items-center gap-4 text-[10px] tracking-[0.14em] uppercase text-[#14140F]/45">
          <span>{catalog ? `${catalog.capabilities.length} mounted` : '…'}</span>
          <span>{catalog?.bridge?.mode ?? 'engine'}</span>
          <Link href="/cockpit" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">Cockpit</Link>
          <Link href="/passport" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">Passport</Link>
          <Link href="/browser" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">Browser</Link>
          <Link href="/lab" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">Lab</Link>
        </div>
      </header>

      <section className="px-4 sm:px-6 py-5 border-b border-[#D8D5CC] max-w-5xl">
        <p className="text-[15px] leading-relaxed">
          Load a belt for the mission you know you are walking into. The local captain
          is the only seat that sees these guns. Everyone else reasons. Nothing here
          fires without the grant, and a write still waits for you.
        </p>
      </section>

      {error && (
        <div className="mx-4 sm:mx-6 mt-4 border-l-2 border-[#A8281E] bg-[#A8281E]/[0.04] px-3 py-2">
          <div className="text-[10px] tracking-[0.16em] uppercase text-[#A8281E]">Did not go through</div>
          <div className="mt-1 text-[12px]">{error}</div>
        </div>
      )}

      <section className="px-4 sm:px-6 py-4 border-b border-[#D8D5CC]">
        <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">Belt farm</div>
        <div className="flex flex-wrap gap-1.5">
          {BELTS.map((belt) => (
            <button
              key={belt.id}
              onClick={() => setBeltId(belt.id)}
              title={belt.when}
              className={`px-2.5 py-1 text-[11px] border ${
                beltId === belt.id
                  ? 'border-[#1B3FCB] text-[#1B3FCB] bg-[#1B3FCB]/[0.05]'
                  : 'border-[#D8D5CC] text-[#14140F]/60 hover:text-[#14140F]'
              }`}
            >
              {belt.name}
              <span className="ml-2 text-[10px] text-[#14140F]/40">{belt.capabilityIds.length}</span>
            </button>
          ))}
          <button
            onClick={() => setBeltId('custom')}
            className={`px-2.5 py-1 text-[11px] border ${
              beltId === 'custom'
                ? 'border-[#1B3FCB] text-[#1B3FCB] bg-[#1B3FCB]/[0.05]'
                : 'border-[#D8D5CC] text-[#14140F]/60'
            }`}
          >
            Custom
            <span className="ml-2 text-[10px] text-[#14140F]/40">{customIds.length}</span>
          </button>
        </div>
        <p className="mt-2 text-[11px] text-[#14140F]/45 max-w-2xl">
          {beltId === 'custom'
            ? 'Tick the guns below. An empty custom belt falls back to Talk — it will not quietly arm the full deck.'
            : BELTS.find((b) => b.id === beltId)?.when}
        </p>
      </section>

      <section className="px-4 sm:px-6 py-4 grid gap-6 lg:grid-cols-[1fr_320px]">
        <div>
          <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-3">Mounted</div>
          <div className="space-y-6">
            {(catalog?.packs ?? []).map((pack) => {
              const tools = (catalog?.capabilities ?? []).filter((c) => c.packId === pack.id)
              if (tools.length === 0) return null
              return (
                <div key={pack.id}>
                  <div className="text-[11px] font-bold tracking-[0.14em] uppercase mb-2">
                    {pack.name}
                    <span className="ml-2 font-normal text-[#14140F]/40">{pack.id} · {pack.version}</span>
                  </div>
                  <ul className="border border-[#D8D5CC] bg-white divide-y divide-[#EFEDE6]">
                    {tools.map((tool) => {
                      const onBelt = activeBelt.includes(tool.id)
                      return (
                        <li key={tool.id} className="flex items-start gap-3 px-3 py-2">
                          <input
                            type="checkbox"
                            checked={onBelt}
                            onChange={() => toggleCustom(tool.id)}
                            className="mt-1 accent-[#1B3FCB]"
                            title="Add to a custom belt"
                          />
                          <button
                            onClick={() => {
                              setPicked(tool.id)
                              const required = Array.isArray(tool.inputSchema?.required) ? tool.inputSchema.required as string[] : []
                              const stub: Record<string, unknown> = {}
                              for (const key of required) stub[key] = ''
                              setArgsText(JSON.stringify(stub, null, 2))
                            }}
                            className="text-left flex-1 min-w-0"
                          >
                            <div className="flex items-baseline gap-2 flex-wrap">
                              <span className={`text-[12px] font-bold ${picked === tool.id ? 'text-[#1B3FCB]' : ''}`}>
                                {tool.id}
                              </span>
                              <span className="text-[10px] uppercase tracking-[0.12em] text-[#14140F]/40">
                                {tool.risk}{tool.requiresApproval ? ' · needs you' : ''}
                              </span>
                              {!onBelt && (
                                <span className="text-[10px] uppercase tracking-[0.12em] text-[#B0812A]">not on this belt</span>
                              )}
                            </div>
                            <div className="text-[11px] text-[#14140F]/60 leading-relaxed">{tool.description}</div>
                          </button>
                        </li>
                      )
                    })}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>

        <aside className="border border-[#D8D5CC] bg-white p-3 h-fit">
          <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">Fire one</div>
          <div className="text-[13px] font-bold break-all">{selected?.id ?? 'pick a gun'}</div>
          {selected && (
            <p className="mt-1 text-[11px] text-[#14140F]/55 leading-relaxed">{selected.description}</p>
          )}
          <label className="block mt-3 text-[10px] tracking-[0.16em] uppercase text-[#14140F]/40">
            Arguments
            <textarea
              value={argsText}
              onChange={(e) => setArgsText(e.target.value)}
              rows={8}
              spellCheck={false}
              style={{ fontFamily: MONO }}
              className="mt-1 w-full border border-[#D8D5CC] p-2 text-[11px] outline-none focus:border-[#1B3FCB]"
            />
          </label>
          <label className="block mt-2 text-[10px] tracking-[0.16em] uppercase text-[#14140F]/40">
            Intent
            <input
              value={intent}
              onChange={(e) => setIntent(e.target.value)}
              placeholder="why this call"
              className="mt-1 w-full border border-[#D8D5CC] px-2 py-1.5 text-[12px] outline-none focus:border-[#1B3FCB]"
            />
          </label>
          <button
            onClick={() => void fire()}
            disabled={busy || !selected || !activeBelt.includes(picked)}
            className="mt-3 w-full px-3 py-2 text-[11px] tracking-[0.16em] uppercase bg-[#14140F] text-[#FBFAF7] hover:bg-[#1B3FCB] disabled:opacity-25"
          >
            {busy ? 'Working' : activeBelt.includes(picked) ? 'Run with this belt' : 'Not on this belt'}
          </button>

          {last?.awaitingApproval && (
            <div className="mt-3 border-l-2 border-[#B0812A] pl-2.5 py-1">
              <div className="text-[10px] tracking-[0.16em] uppercase text-[#B0812A]">Needs you</div>
              <div className="text-[11px] mt-1">This write is waiting. Approve it or refuse it.</div>
              <div className="mt-2 flex gap-2">
                <button onClick={() => void decide('approve')} className="px-2 py-1 text-[10px] uppercase border border-[#14140F]">
                  Approve
                </button>
                <button onClick={() => void decide('reject')} className="px-2 py-1 text-[10px] uppercase border border-[#A8281E] text-[#A8281E]">
                  Refuse
                </button>
              </div>
            </div>
          )}

          {last?.result && (
            <pre className="mt-3 text-[10px] leading-relaxed whitespace-pre-wrap break-words text-[#14140F]/70 max-h-64 overflow-auto">
              {JSON.stringify(last.result.output ?? last.result, null, 2)}
            </pre>
          )}
        </aside>
      </section>
    </div>
  )
}
