# Cross-build notes — the specialist report vs this repo

Written 2026-08-27, after D handed over two documents: a "Vector Computation
& Embedding Specialist" report describing the **Python/Postgres passport
build** (`src/curation/…`, `src/db/…`, `docs/decisions/C1–C4.md` — the other
workspace, not this one), and an external layered-architecture proposal
(L0–L4: hash-chained log, vector store, fact graph, audit engine).

Purpose: the open question "which passport is the carrier" needs a
divergence table. This is it, verified against this repo's code — not
against either document's claims about itself.

---

## 1. The TrustGate math matches, factor for factor

The report's C3 spec was compared against `src/passport/trustGate.js`. It is
a faithful port — same constants, same structure, same deliberate
oddities:

| Spec (report) | This repo | Match |
|---|---|---|
| τ = 0.10, not √d (cosine/√768 ≈ ±0.036 squash) | `temperature: 0.1`, same rationale in the header | ✓ |
| ε = 1e-6 | `epsilon: 1e-6` | ✓ |
| T_adj: 1.0 digest-match / 0.50 mismatch / 0.55 unadjudicated | same, including the deliberate mismatch < unadjudicated ordering | ✓ |
| T_supp: supported = min(cc/5, 1); provisional = 0.20 + 0.40·min(cc/5, 0.80) | same (`tSuppProvBase/Span/Cap`) | ✓ |
| Drift: 14-day half-life, λ = ln2/14; stale at < 0.25 unless pinned | `driftHalfLifeDays: 14`, `staleCutoff: 0.25`, pinned exempt | ✓ |
| T_conf clamp [0.05, 1]; low-confidence < 0.20 unless pinned | same | ✓ |
| Hard exclude contested/invalidated before softmax | same — an excluded memory steals no probability mass | ✓ |
| imported_unadjudicated hard-exclude "when strict mode enabled" | same, as the opt-in `adjudicatedOnly` flag (default off) | ✓ |
| Pinned: reserved outside the softmax, admitted first, blocked only by contested/invalidated | same | ✓ |
| Token cost 0.25/char, min 10; greedy pack by descending weight | same | ✓ |
| Shortlist M = 50 (two-stage: ANN then TrustGate) | `shortlistSize: 50`; exact search stands in for ANN at passport scale | ✓ |
| Worked example (logits 8.449 vs 7.013 → 80.8% / 19.2%) | re-derived by hand — numerically correct | ✓ |

**Reading:** the two builds agree on the C3 retrieval math. That question is
settled between them; a carrier choice will not turn on TrustGate.

## 2. The divergences that DO matter

### Divergence A — strip vs reject at the write boundary (decision-relevant)

The report's Python boundary **pops privileged fields and continues**
("any attempted injection of privileged status is stripped"). This repo
**rejects the write and names the field** — D6/C4a in `docs/DECISIONS.md`,
which says outright: "This reverses the Python build, deliberately," on the
grounds of the export → relabel → reimport attack and the
visibly-absent-never-quietly-missing principle.

The report describes the Python side accurately. But the report presents
stripping as the defense; this repo's record shows stripping was argued
down and reversed. **If the Python build ever becomes the carrier, C4a must
be ported to it.** Until then, only this build enforces the boundary the
way the decision record says it must be enforced.

### Divergence B — witness dedup (possible real vulnerability, verify)

The report's `propose_memory` increments `confirmation_count += 1` on every
repeat proposal of the same signature, with no witness-signature dedup
visible in the sample. If that reflects the real Python build and is not
just simplification in the report, then **a model can promote a claim to
`supported` by repeating it five times** — the exact attack C2 exists to
stop ("five repetitions of the same witness are one witness").

This repo dedups by `witnessSignature(witness_kind, reference)`; a repeat
witness bumps nothing, and it is tested (`passport.test.js`). The Python
side needs the same check verified against its real source, not the report.

### Smaller notes

- The report's paths (`src/curation/`, `src/db/`, `docs/decisions/C1–…md`)
  are the other workspace. Nothing here was changed to match them.
- "All 14 unit and integration tests passing" — unverifiable from here; the
  code it describes is not in this sandbox. Recorded, not trusted.
- One wording nit in the report: it says privileged status is "stripped"
  (see Divergence A) and elsewhere that claims "require 5 distinct
  confirmations" — the word **distinct** is the whole content of C2, and the
  sample code does not implement distinctness. Words and code disagree
  there; here they agree because a test enforces it.

## 3. The layered-architecture proposal — triage

Mostly not adoptable as-is: its core is a vector store (L1), ANN retrieval,
NLI contradiction detection over cosine bands (0.80 < cos < 0.97), and
embedding-model version migrations. Vectors are ruled out — twice, for the
reason that keeps being right: a similarity band merges claims confidently
and wrongly. Its "cos > 0.97 → merge" rule is precisely the confident
wrong merge this store refuses; the equation form (D16) reaches the same
goal — same-fact identity across wording — by exact conjunctive fields.

What it proposes that this repo **already has**:

- append-only event log (D10, JSONL, torn-line recovery)
- bi-temporal validity (`validAt` / `invalidAt` / `supersededBy`)
- supersede, never overwrite; nothing auto-deletes
- contradiction as a first-class recorded event
- transparent exclusion at read time, with reasons named
- point-in-time fields (a "what did we believe at T" query is derivable)

The **one genuinely new, vector-free idea worth keeping**: hash-chaining
the event trail — each event records the hash of the previous one, so any
after-the-fact edit of the log breaks the chain and is detectable by
recomputation. Our log is append-only by discipline but not tamper-EVIDENT;
`adjudicatedDigest` already hashes memory content, and chaining the trail
is the natural extension of the same idea. Small, additive, fits D10.

**Status: queued as a candidate (D17), deliberately not built yet** — D has
more materials coming, and building into the log format while more input is
arriving is how conflicts happen. It is written down here so it survives.

## 4. What this changes

Nothing in this repo changed as a result of either document. The value of
the handover is: (1) the C3 math is now known to match across both builds,
(2) the strip-vs-reject divergence is now documented as the concrete thing
that must move if the Python build is chosen as carrier, (3) the Python
side has one suspected vulnerability to check (witness distinctness), and
(4) one new candidate idea is on the queue.

---

## 5. Strata — the three layers D handed over, ordered, and what each one says

D sent more material in two further batches: a Phase-4 *implementation*
document (TypeScript, older) and a re-paste of the specialist report
(confirmed identical to the first — disregarded as a repeat per D's note).
Ordering the three strata by internal evidence:

| | Stratum 1 — Phase 4 impl (TS) | Stratum 2 — specialist report | Stratum 3 — this repo |
|---|---|---|---|
| Scale | `/√d` | `τ = 0.10` | `τ = 0.10` |
| ε | `1e-3` | `1e-6` | `1e-6` |
| Gate | 3 factors | 5 factors (status, adj, supp, drift, conf) | 5 factors |
| Adjudication miss | falls back to raw confidence | 0.50 vs 0.55 unadjudicated | 0.50 vs 0.55 |
| Provisional support | `cc/5` | `0.20 + 0.40·min(cc/5, 0.80)` | same |
| Stale rule | gate < 0.05 floor | drift < 0.25 | drift < 0.25 |
| Imported + unadjudicated | hard-excluded, **mislabeled `invalidated`** | hard-excluded **unconditionally** in code; "strict mode" in spec text | opt-in `adjudicatedOnly`, own reason code |
| **Pinned + contested claim** | **BUG — admitted unconditionally** | guarded | guarded + tested |

**The finding that finishes the interrupted check.** Stratum 1's
`selectForBudget` reserves every pinned memory before any TrustGate check —
a pinned memory whose claim has since been contested is admitted anyway,
with weight 1.0. That is the narrow thing this project's own stance says
must never happen ("a contested claim served as if supported"), and Stratum
2's Python fixed it (`if reason in ('contested','invalidated'): excluded`).
This repo both implements the guard and tests it:
`test/passport.test.js` — "pinned survives the budget, but pinning cannot
override contested" — pins the asks-before-it-changes-the-world doctrine,
contests it, and asserts the boot block refuses it. **No action needed
here; the bug is a property of the oldest stratum only.** If any artifact
of Stratum 1 survives into the carrier build, its pinned-reservation block
is the one thing that must not be copied from it.

**One more words-vs-code divergence in the report itself** (beyond the
witness-dedup one already flagged): §1's spec scopes the
imported-unadjudicated exclusion to "when strict mode enabled," but its own
Python applies it unconditionally. This repo follows the spec text (the
`adjudicatedOnly` opt-in, default off) — an unadjudicated import is a
weighting question, not a boundary one. Another instance of the same
lesson: read the code, not the prose, and this repo's tests are what keep
the two honest here.

**Duplicate paste:** byte-for-byte the same report as the first handover
(same worked-example logits, same code, same claims). Disregarded except
as confirmation that stratum 2 is the current Python state.
