# The Code Forge — what is built, and what is still to build

The coding relay is now a working subsystem: `src/forge/`, tested by
`test/forge.test.js` (37 checks, part of `npm test`). It is the loop the
business plan called "Avenue 1 — the flagship."

The loop is **pure and deterministic**. It knows nothing about git, Electron,
or any AI provider. Those are seams, and the seams are the next build.

---

## What exists now

| File | What it is |
|---|---|
| `src/forge/forge.js` | `CodeForge` — the relay loop, the regression rule, the stop conditions, the proposal ledger (git-as-proposal), pause/resume |
| `src/forge/recorder.js` | `ForgeRecorder` — hash-chained, append-only failure memory + maneuver promotion (`PROMOTE_AFTER = 5`, one failure blocks) |
| `src/forge/budget.js` | `ForgeBudget` — charge-before-dispatch per-seat spend; exhausted seats are ejected, never billed |
| `src/forge/bench.js` | `ForgeBench` — the hangar: an ordered queue of spare seats, swapped in on ejection |
| `src/forge/git.js` | `GitForgeRepo` — real worktrees, real branches, `releaseToBase` = the human's merge |
| `src/forge/referee.js` | `BuildRunnerReferee` — a test run becomes green / red / broken-build / unrunnable |
| `src/forge/store.js` | `ForgeStore` — persistence: `recorder.jsonl` (the hash-chained audit) + `state.json` (budget, proposals, flight, replacements) |
| `src/forge/seat-adapter.js` | `buildProposalPrompt` + `parseProposalReply` + `forgeSeat` — a seated AI becomes a forge seat |
| `src/forge/tools.js` | `CapabilityGate` + `ForgeToolbox` — risk-ranked tools (`read_file`/`write_file`/`run_tests`/`git_diff`), path-bounded to the worktree |
| `src/forge/pilot.js` | `toolPilotSeat` + `parseToolReply` — a seat that flies tools through the gate and turns the resulting diff into a proposal |
| `src/forge/runner.js` | `detectTestCommand` — which test command a repo speaks, or `null` (a named refusal, never a guess) |
| `src/forge/controller.js` | `ForgeController` — owns the whole lifecycle: launch / stop / resume / release / reject / status, streaming events, persisting to the store |
| `src/forge/index.js` | the facade — one door in |
| `src/main/main.js` | the production glue: `forge:*` IPC handlers, seats built from the seated tabs via `dispatch`, the local model as the bench |
| `src/preload/chrome.js` | `forgeflight.forge.*` + `onForge` — the narrow bridge |
| `src/renderer/index.html` / `chrome.js` / `chrome.css` | the **Forge pane**: launch, watch the loop show its work, stop / resume, and release or reject proposals |
| `test/forge.test.js` | loop baseline + attack probes |
| `test/forge-git.test.js` | git + referee adapters, incl. the end-to-end demo |
| `test/forge-bench.test.js` | the self-healing relay: swap, pause, resume |
| `test/forge-store.test.js` | persistence: round-trip, tamper, torn line, corrupt state |
| `test/forge-seat.test.js` | seat adapter: prompt, parser, and the full chain (seat → forge → git → referee) |
| `test/forge-tools.test.js` | gate, toolbox, tool pilot, and the full tool-driven chain |
| `test/forge-controller.test.js` | the controller: launch → green → release, pause/resume, named refusals, persistence |

## The run, in order

1. **The trunk is verdicted first.** Unrunnable → `no_harness`. Already green →
   `already_green` (write the failing tests first, then run — red-test-driven
   forging). Red → proceed.
2. **Each round walks the seats in relay order.** A seat is charged *before* it
   is dispatched; an exhausted seat is ejected and skipped.
3. **A seat proposes a patch against the current tree.** It sees the goal, the
   current tree, the loop-back `failureMemory` (what did not work), and the
   `priorSeat` (what the last hand changed). A `pass`, `bad_shape`,
   `does_not_apply`, or `no_change` is a named refusal and does not advance.
4. **The referee verdicts before anything is accepted.** Green → stage a
   proposal and stop `goal_reached`. `unrunnable` → `no_harness`.
   `empty_response` → recorded, not accepted.
5. **Red is the interesting case.** If the patch broke a test that was passing —
   including turning green red — it is a **regression**: the tree reverts, the
   regression is recorded, and the loop keeps going. Otherwise the tree
   advances, and the failure memory grows.
6. **Stop conditions**, in order: `goal_reached`, `already_green`, `round_cap`,
   `budget_exhausted`, `stalled`, `no_harness`, `cancelled`, `error`. Every stop
   has a sentence (`STOP_REASONS`).

## The guardrails, and why they are the product

- **Every commit is a proposal.** The loop stages; only the human releases
  (`proposals.release(id)`). The Federation's "you are step four," applied to git.
- **Charge before dispatch, no refunds, unknown tiers don't eject.** The same
  ordering rule the engine already settled. A forge cannot run away with money.
- **The build is the referee.** No seat self-adjudicates. The memory is
  hash-chained, so what the loop remembers is a verifiable fact, not a claim.
- **Refuse before guess.** A patch that doesn't apply, doesn't change anything,
  or can't be verified is refused *by name* — the same culture as the composer
  detector.

## What is still to build (the seams)

The loop is complete; three of the six seams are now real — a loop can drive an
actual git repository end to end and swap in spare seats when one runs dry (see
`test/forge-git.test.js` and `test/forge-bench.test.js`):

1. ~~**The tree + apply adapter (git).**~~ **DONE — `src/forge/git.js`.** A
   dedicated worktree, a `forge/{runId}` branch, `apply` = reset + `git apply` +
   commit, `releaseToBase` = the human's merge. The user's own checkout is
   never touched.
2. ~~**The referee adapter (build/test runner).**~~ **DONE — `src/forge/referee.js`.**
   `BuildRunnerReferee` + `shellRunner` + `parseFailing` turn a test run into
   green / red-with-names / broken-build / unrunnable. A broken build (compile
   error) is a *regression*, not progress.
3. ~~**The seat adapter (real models).**~~ **DONE — `src/forge/seat-adapter.js`.**
   `buildProposalPrompt(ctx, extra)` turns the forge's context into the text an
   AI reads (goal, failures, prior hand, replacement note, reply contract);
   `parseProposalReply(text)` turns the AI's reply into a proposal / named
   `pass` / `bad_shape` — it refuses before it guesses, and a diff always ends
   with a newline (git apply rejects one that doesn't). `forgeSeat({id, send,
   gatherContext})` is the object the forge consumes. The only live piece is
   `send`; in production it is the table's own dispatch, wired in `main.js`:

   ```js
   // main.js — forgeSeatDescriptors(): a seat per seated tab
   send: dispatchSend(dispatch, r.tabId, { runId: 'forge', role: 'forge' }),
   ```

   `dispatch` already resolves to `{ ok, text }` (the streamed reply from
   `watch.js`) — exactly the shape `forgeSeat` expects. The adapter itself
   imports nothing from Electron, so it stays fully testable.
4. ~~**The tool sequence + capability gate.**~~ **DONE — `src/forge/tools.js` +
   `src/forge/pilot.js`.** A tool-flying seat (`toolPilotSeat`) sends a strict
   JSON reply (`{ summary, tools: [...] }`), each tool flies **through the
   gate**: risk-ranked (`read < transform < create < update < delete <
   external_side_effect`), denied by name if ungranted, operator-approved above
   the auto-approve ceiling (`run_tests` by default), and every filesystem tool
   is **path-bounded to the worktree** — a code pilot is not a root shell. The
   flown sequence is recorded in the hash-chained memory, and the loop's apply +
   referee stay the only authority (the pilot's own test run is advisory).
5. ~~**The hangar/bench (the self-healing relay).**~~ **DONE — `src/forge/bench.js`.**
   On exhaustion a seat is ejected and the next bench member is seated in its
   slot with the full `propose(ctx)` (goal, tree, `failureMemory`, `priorSeat`,
   plus `replacedSeat`/`joinedAt`). When the bench is empty the run **pauses**
   (`resumable: true`) instead of dying, and `resume()` continues the same
   `runId`, tree, and memory — after `resetBudgets()` (a new day) or
   `addSeat()` (a new provider). Without a `bench`, exhaustion stays terminal
   `budget_exhausted`. See `docs/SELF-HEALING-RELAY.md`.
6. ~~**Persistence.**~~ **DONE — `src/forge/store.js`.** `ForgeStore` writes the
   recorder's hash-chained records to `recorder.jsonl` and the budget /
   proposals / suspended flight / replacement ledger to `state.json`; a new
   forge `adopt(store.load())`s the state and `resume()`s the same `runId`.
   Seats are deliberately NOT persisted — they are re-seated by the operator on
   restart, the same "a session is a list of places" contract the browser
   already uses. Tampering is reported (never fatal); a torn line is dropped
   and counted.
7. ~~**The UI + the production glue.**~~ **DONE.** `src/forge/controller.js`
   (`ForgeController`) owns launch / stop / resume / release / reject / status
   and streams events; `src/main/main.js` wires the `forge:*` IPC handlers and
   builds seats from the seated tabs (via `dispatch`) with the local model as
   the bench; `src/preload/chrome.js` exposes `forgeflight.forge.*` +
   `onForge`; `src/renderer/` adds the **Forge** pane — launch, watch the loop
   show its work live, stop / resume, and release or reject the staged
   proposal.

## Using it (the live app)

1. Seat AIs the ordinary way — open claude.ai, ChatGPT, Gemini, etc.; each tab
   seats itself.
2. Open the **Forge** view, pick a git repo (or type its path), write a goal,
   set a per-seat call cap (blank = unlimited) and a round cap, then **Launch**.
3. Watch the log: every charge, refusal, ejection, bench swap, and accepted hand
   is a line. The build is the referee; a patch that breaks the build is a
   regression and is reverted.
4. When it goes green, the winning patch is **staged** on a `forge/{runId}`
   branch — the base repo is untouched. **Release** merges it; **Reject** leaves
   the branch. Only you can release.
5. If every seat runs dry and the bench (a free local model, when one is
   running) is empty, the run **pauses** and can be **Resume**d after allowances
   reset.

## What is still to build

- **Run it live.** The whole stack is wired and unit-tested; the remaining step
  is exercising it against real seats (needs the Electron binary `npm install`
  fetches, and real logins — the same caveat the README names for the table).
- **Cross-restart resume.** Pause/resume is proven within a process; the
  worktree lives in `os.tmpdir()` and does not survive a reboot, so resuming a
  paused run after a full restart is a later step (the store already round-trips
  the memory — only the worktree re-attach is missing).
- **Per-call approval.** `run_tests` is auto-approved inside a launched run (the
  launch itself is the approval). A future per-call approval UI plugs into the
  pilot's existing `approve` hook.

## Note on the engine harness layer

The root `.ts` harness files (`runtime.ts`, `cockpit.ts`, `flight-recorder.ts`,
`seat-budget.ts`, `gate.ts`, `capabilities.ts`) are a separate, aspirational
layer that currently does **not** run: `package.json` is `"type": "commonjs"`
so Node 22 loads `.ts` as CommonJS and rejects the ESM `export` syntax, and the
layer imports three files that do not exist yet (`neuralink.ts`,
`mission-computer.ts`, `packs.ts`). The Code Forge deliberately does not depend
on that layer — it re-implements only the *conventions* (chain, budget, maneuver
promotion) in the canonical, tested CommonJS style. Reuniting the two is a
separate task, and the forge's seams are written so they can be plugged into
either.
