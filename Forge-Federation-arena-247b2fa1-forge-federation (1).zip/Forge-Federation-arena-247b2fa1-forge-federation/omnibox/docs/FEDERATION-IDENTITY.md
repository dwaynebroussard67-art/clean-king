# SHARED CONTRACT — Federation release identity

**Status:** implemented on the Forge Flight side (D29, session sign-in in
D30). The queue still accepts any non-empty actor as a *name*; main is
what refuses an unsigned release, ignores a renderer-supplied actor, and
— as of D30 — requires a named sign-in **this launch** (`not-signed-in`).
A name on disk is a memory, not a session.
**Owner of the renderer side:** `src/main/operator.js`, `src/main/main.js`, `src/renderer/chrome.js`.
**Author:** Engineer 2 (Federation), wired by the radio pass.

## The problem

The release queue (`src/federation/queue.js`) is the only door a fact can
leave through, and the only thing that opens it is a named actor: a release
must carry an `actor`, and that actor must be a **configured operator**.
An unsigned release is refused outright (`unsigned-release`); a release by an
actor who is not configured is refused (`unauthorized-release`); and when
**no operator is configured at all, every release is refused**
(`no-operators-configured` — fail closed).

The one thing this must never become is a hardcoded literal in the UI — a
`'D'`, an `'operator'`, a `'human'` — because a hardcoded name is not an
identity, it is a constant, and a constant trusted as "the human" is a
standing backdoor. This design exists so the renderer has a real identity to
supply instead.

## What the Federation already guarantees (shipped in the FEDERATION PR)

```js
const fed = new Federation({ dir, operators: ['ada', 'grace'] }); // no default
fed.release(proposalId, { actor: 'ada' });   // ok — 'ada' is configured
fed.release(proposalId, { actor: 'mallory' }); // refused: unauthorized-release
fed.release(proposalId, { actor: undefined }); // refused: unsigned-release
const empty = new Federation({ dir });         // operators omitted
empty.release(proposalId, { actor: 'ada' });   // refused: no-operators-configured
```

The authority check lives in the **queue** (`ReleaseQueue.authorize()`), and
`curator.land()` re-checks it as defence in depth. There is no hardcoded
operator anywhere in `src/federation/`.

## The contract for the renderer / main process

1. **The operator list is configuration, not code.** `src/main/main.js` reads
   it from the environment (e.g. `OMNIBOX_OPERATORS`, a comma-separated list)
   or from a file in the user data dir — never from a literal in the renderer.

2. **The actor is identity, not a label.** Whatever the release UI shows, the
   `actor` it sends must be the configured operator's real name/identifier,
   resolved main-process-side and verified against the configured set before
   `federation.release()` is called. The renderer must not invent the actor.

3. **The renderer never decides.** Exactly like seating (D5, "server-side
   gate, not client flags"): the renderer requests a release; the main
   process authorizes it. A compromised renderer can at worst ask, never
   authorize.

4. **No new witness kind.** Agreement between nodes is deliberately not a
   witness kind (see `src/federation/curator.js`) and never will be. Operator
   identity is an authorization concern, not an evidence concern.

## What Engineer 4 ships later (not in this PR)

- A release control in the chrome that displays the current operator and
  attributes every release to it (`release.actor` is already recorded in the
  queue's release records).
- Wiring `operators` from configuration into `new Federation(...)`.

Until then the Federation ships **closed**: with no operator configured,
nothing can be released, which is the correct posture for a boundary that
must never trust a constant.
