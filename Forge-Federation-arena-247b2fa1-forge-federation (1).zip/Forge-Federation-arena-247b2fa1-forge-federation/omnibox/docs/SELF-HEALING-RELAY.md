# The Self-Healing Relay — the honest version of a good idea

*The idea, as stated:* the captain is the only actor with seat power. The
copilots (free-tier AIs) run the relay. When one runs out of tokens, the forge
auto-ejects it, the captain searches the internet for another free-tier AI,
seats it, gives it the full context, and the relay never has to stop.

**The verdict: the instinct is right and worth building. The literal mechanism
is the wrong one — for reasons that are already written into this codebase as
rules. Here's the separation, then the honest redesign.**

---

## The right half

1. **Auto-eject on exhaustion, auto-replace, keep flying.** This is exactly the
   discipline the engine already settled — `seat-budget.ts` charges before
   dispatch and a spent seat is *ejected, not billed* — and the forge inherits
   it (`ForgeBudget`, `budget_exhausted` stop). Swapping a dead seat for a live
   one is a real, correct operational pattern.

2. **The new seat falls into place with full context.** Already built. The
   forge's `propose(ctx)` hands every seat the `goal`, the current `tree`, the
   `failureMemory` (what the hands before tried and failed), the `priorSeat`,
   and the promoted maneuvers. A replacement seat gets everything it needs to
   continue the relay in one object. Nothing new to design there.

3. **The captain is the only one who can click/seat/eject; copilots only
   propose.** Clean privilege separation, and it mirrors the Federation's
   triangle. Seats (tabs) can't spawn other tabs; only the main process — the
   operator — can open a tab, seat an AI, or eject one. That is the actor the
   captain maps onto.

---

## The wrong half

"**The captain searches the internet for another free-tier AI and seats it.**"
Four problems, each one a rule this product already lives by:

1. **It breaks the ethos.** Forge Flight's entire identity is *no scraping, no
   guessing, no selector lists, honest refusal, you log in the ordinary way.*
   Auto-hunting free AIs and auto-seating them is a credential-forging bot —
   the precise opposite of the trust moat the whole business plan is built on.

2. **It breaks every provider's terms.** Auto-creating free-tier accounts to
   drain rate limits is exactly the behavior providers ban, and it turns a
   tool you're proud of into one you'd have to hide.

3. **It physically cannot clear signup walls.** Free tiers sit behind email
   verification, phone verification, and captchas. A captain can't complete
   those — and a captain that could would be a worse problem.

4. **It is bounded anyway by a law we already enforce.** *One seat per host.*
   There are a handful of distinct free-tier chat providers, not an infinite
   supply. "Search the internet" cannot produce more than a few distinct seats,
   and `seats.js` would refuse to seat two on the same host regardless.

---

## The honest redesign: the Hangar (a bench, not a search)

The same outcome, without any of the four problems:

- **The roster is the hangar.** The user's browser profile already holds
  logged-in sessions for every provider they use. Those are the seats. The
  forge keeps a *bench* of seats that are not currently flying.
- **On ejection, the captain seats the next bench member** and injects the full
  `propose(ctx)` — the relay continues with zero loss of memory.
- **Local models are free bench members, and this is already built.**
  `localLLM.js` probes for a running Ollama / LM Studio instance and seats it —
  no key, no account, *unmetered*. "Search the internet" becomes "probe your
  own machine for a free model," which is honest and already in the code.
- **The relay's uptime is honestly bounded by the roster + the reset clock.**
  Free tiers are per-day. When the bench is empty, the run *pauses* — the
  recorder is hash-chained and (once persisted) survives the pause — and it
  resumes when allowances reset or the user adds a provider. "Never stops" is
  delivered as *"never loses its place, never guesses, never drains you."*
- **The human keeps release authority; the captain gets flight authority.**
  The captain can seat, eject, and swap. Only the human merges. That boundary
  is already the forge's git-as-proposal model, and it is what makes the whole
  thing safe to describe to a customer.

---

## One correction to the captain model

In this codebase the *captain* (`src/main/captain.js`) is not the click-power
seat — it is the **local model as decider**: after the copilots answer, the
captain returns `verdict` / `defer` / `unknown` and never fuses four answers
into one confident wrong answer. The actor with *seat power* (open a tab, seat,
eject) is the **Electron main process / operator**. So the clean statement is:

> The **operator** is the only actor with seat power. The **captain** is the
> decider. The **copilots** propose. The **human** releases.

All four already exist as separate roles. The bench just makes the operator's
seat power *responsive to ejections* instead of only to human clicks.

---

## The exact seam it plugs into

No new architecture. Three touch points, all named:

| What | Where it lives today |
|---|---|
| Eject a spent seat | `ForgeBudget.eject` → `budget_exhausted` stop (`src/forge/forge.js`) |
| The bench (next seat up) | a roster in the spec; seats are already just `{ id, propose }` objects |
| Full context handoff | `propose(ctx)` — goal, tree, `failureMemory`, `priorSeat`, promoted maneuvers |
| Free local seat | `src/main/localLLM.js` discovery (already probes Ollama / LM Studio) |
| "Never lose its place" | `ForgeRecorder` (hash-chained) → persist to a `forge/` JSONL file |

The only genuinely new piece is a **`bench`**: an ordered list of seats with
their allowances, and a rule in the loop — *on ejection, seat the next bench
member; if the bench is empty, pause (not crash) and report the reset clock.*
That piece is now **built** (`src/forge/bench.js`, wired into `CodeForge`, 9
checks in `test/forge-bench.test.js`):

- `spec.bench` is the hangar; on exhaustion the forge ejects the spent seat and
  seats the next bench member in its slot, handing it the full `propose(ctx)`
  (goal, tree, `failureMemory`, `priorSeat`, and `replacedSeat`/`joinedAt`).
- With a bench configured, an empty bench yields **`paused`** (`resumable:
  true`) instead of terminal `budget_exhausted`. `resume()` continues the same
  `runId` and memory; `resetBudgets()` is "a new day," `addSeat()` is "the user
  added a provider."
- Without a `bench`, exhaustion stays terminal `budget_exhausted` — the engine's
  original, honest behavior is unchanged.

---

## Why this version is sellable

"The relay that never stops" is a promise you can't keep and shouldn't make.
"The relay that never loses its place, swaps in your own spare seats when one
runs dry, and refuses to spend a cent it wasn't told to spend" is a promise the
code already keeps — and it is *your* positioning, not a big dog's. The big
dog harvests free tiers; the little guy's forge tends its own hangar.
