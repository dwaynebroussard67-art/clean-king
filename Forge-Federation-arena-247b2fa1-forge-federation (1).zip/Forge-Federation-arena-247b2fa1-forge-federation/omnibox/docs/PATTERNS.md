# What the five uploads had in common

You handed over five things: two builds of the Memory Passport (a Python one
dated 08-26 and a TypeScript/Next.js one dated 08-11), the Forge Mode
flagship handoff for the template-picker app, and two saved Arena
conversations — the spec that produced the Python passport, and a critique of
that spec.

They look like three unrelated projects. They are one idea, stated three
times.

---

## The pattern

**Every one of these is a system that would rather visibly abstain than
quietly be wrong.**

| Where it shows up | The form it takes |
|---|---|
| Memory Passport | A hard-excluded claim never enters the softmax. The boot block *always* ends with the exclusion audit. `supported` is the ceiling — nothing is ever `settled`. One contradiction closes a claim rather than decrementing a tally. |
| The Arena critique | *"I'm not going to co-sign 'all 14 tests are passing'… Nothing in this conversation actually executed code. Treat this round as provisional."* A reviewer refusing to certify, on the grounds that an unverified assertion of "tested and passing" is exactly the shape of thing the passport exists to keep out. |
| Forge Mode | The site **never** renders `undefined`, empty brackets, or lorem ipsum — missing data falls back to category defaults. The AI copy guardrails forbid invented history, awards, credentials, licensing. |
| The re-anchor engine | Refuses rather than wrong-grabs. Finds ~34% at a measured zero wrong-grab rate. |
| The harness | A grant is the only way in to a tool. An unmounted capability writes a `capability_gap` event with the pilot's stated intent instead of throwing. |

Five projects, one invention. And it told me where it had to show up next.

---

## Where it merged into Forge Flight

Every multi-AI tool on the market — ChatHub, Parallel Chat, the rest — ships a
per-provider list of CSS selectors. The week a provider redesigns, those tools
type into the wrong box, or into nothing, and say nothing about it. That is
the same failure the passport's exclusion audit exists to prevent, in a
different domain.

So the seat detector is built the way the re-anchor engine is built:

- **Named, separable, weighted signals** — ten of them, each 0..1, each
  independently inspectable. Never one undifferentiated score. A refusal that
  says *"these two tied on `area`, `anchored` and `viewportBottom`"* is
  actionable; a refusal that says *"0.71 vs 0.70"* is not.
- **A margin requirement, not a maximum.** A winner must beat the runner-up by
  0.12 *and* clear an absolute floor of 0.42. Two near-identical composers
  produce `ambiguous`, and `ambiguous` is a first-class verdict the UI renders
  with a fix attached — not an error path.
- **The keepalive rule, applied to typing.** The composer must read back
  *exactly* what was typed into it before send is pressed. That is the DOM
  rule — match on a stable identifier when there is exactly one match, else
  stay lost — expressed as: prove the text landed, or refuse to send.

There are no provider names anywhere in `src/`. Verified against real saved
`arena.ai` pages: it found the TipTap/ProseMirror contenteditable and its
"Send message" button at 0.79 confidence, and the `Ask followup…` textarea at
0.93, with no selector, no allowlist and no knowledge that Arena exists.

---

## What I took from each, specifically

### The Memory Passport — implemented whole

Ported to dependency-free JavaScript, semantics unchanged: C1 (claim/memory
split, bi-temporal, nothing auto-deletes), C2 (signature counting unit, five
distinct witnesses promote, one contradiction closes), C3 (TrustGate,
attention-shaped admission), C4 (closed write shape).

The τ = 0.10 correction came across with its reasoning intact, because the
reasoning is the valuable part: √d_k scaling exists to normalize the variance
of a dot product between vectors whose *components* have unit variance. Once
q and k are L2-normalized, cosθ already has a fixed small range, and dividing
by √768 ≈ 27.7 crushes the semantic term to ±0.036 while log(TrustGate) still
swings over several units — so trust would dominate *unconditionally* rather
than appropriately.

The worked example from the critique is a test, and it reproduces to four
decimals: 0.98-cosine loses 4:1 to 0.85-cosine on trust; 0.99-cosine never
enters the competition at all.

The subtle ordering came too, with a comment saying it is deliberate:
`t_adj_mismatch` (0.50) is **lower** than `t_adj_unadjudicated` (0.55). A
claim verified once and then silently changed under its stamp is more
suspicious than one never verified.

### The Arena critique — one decision reversed, deliberately

The reviewer argued that a payload containing a privileged field should be
**rejected**, not silently stripped, on the same "visibly absent, never
quietly missing" grounds the exclusion audit is built on. The Python build
strips and continues.

I implemented reject, and logged it as decision **C4a** rather than shipping
it as an unannounced diff. The attack it closes is
export-relabel-reimport: take a provisional memory out, edit `"status"` in the
file, put it back. Stripping makes that a no-op the attacker never sees;
rejecting makes it an error that names the offending field.

The sixth exclusion reason (`imported_unadjudicated`) — the critique said
"pick one: fold it into the five, or formally add it and update the formatter
and docs together." I formally added it and updated the formatter.

### Forge Mode — the discipline, not the product

The template-picker app is a different product. Four things from it are load-
bearing here:

- **The one-shape contract.** *"Every template consumes exactly one shape. Not
  mostly — identically. A template that needs a field no other template has
  either gets that field added to every template, or it does not ship."* That
  is the answer to "no hardcoded providers." Every seat is `{id, name, host}`.
  Every detection returns one `Verdict` shape. There is no per-provider field
  anywhere, and adding one would be visible immediately.
- **Server-side gate, not client flags.** Forge Mode enforces the entitlement
  window on the server because client flags fail security requirements. Same
  here: seating, the one-per-host rule, muting and refusal all live in the
  main process. The renderer cannot seat a tab.
- **Zero flip calls.** Forge Mode pre-generates copy at invite time so the
  deck flip never waits on a model. Same shape: detection runs on load and
  settles *before* you press send, so send is instant and never waits on
  detection.
- **The look.** Cold steel, gunmetal, one molten heat accent `#FF5500`, zero
  purple gradients, zero glassmorphism, zero rounded-card soup. The active tab
  is welded to the page below it with a heat seam; the seam under the dock
  brightens while the table is working. `prefers-reduced-motion` kills the
  animation, as the spec requires.

---

## What I threw away, and why

| Thrown out | Why |
|---|---|
| Stripe, entitlements, the 14-day build window, the five-state machine | Forge Mode's business model. A browser has no entitlement. |
| The Steel Plate Deck and the 3D shared-element lift | Genuinely good, and it has no analogue here. A card-flip between templates makes sense when you are choosing a design you have not seen; it makes no sense when the thing you are "choosing" is a live web page already open in a tab. Taking the seam and the palette without the lift is the honest subset. |
| The `SiteData` contract, the six templates, the category defaults table | Different product entirely. Only the *discipline* transferred. |
| Next.js / Supabase / Drizzle / Postgres | Forge Flight is a desktop browser. A Postgres dependency turns `npm install` into a support burden, and the passport's data model is an append-only log anyway — so it stores one. JSONL: no native modules, no rebuild against Electron's ABI, greppable by hand. That is not a compromise, it is a better fit. |
| Python `sqlite3` | Same reason. The store interface is deliberately narrow so `node:sqlite` can slot in later without touching anything above it. |
| HNSW / pgvector | The Python handoff says exact search is the shortlist at passport scale. Agreed — the `shortlistSize` parameter is where an index goes when there is something to index. |
| A real bi-encoder / ONNX worker | The handoff lists it as "not in this pass." Same call. The `HashEncoder` is labelled a placeholder in its own docstring, behind a one-function interface. |
| Multi-account fan-out | Already ruled out. Now enforced: one seat per host, in `seats.js`. |
| Autonomous querying | Already ruled out. Now enforced: no scheduler exists, rounds are declared and capped at 4, every run is stoppable. |

---

## The one thing I did not paper over

`claimSignature` is normalized exact text. Two seats that both answer "Paris"
produce one claim and two witnesses. "Paris" and "The capital of France is
Paris" produce two claims and look like a disagreement.

That is the FLIGHT\_MANUAL's C9/C10/C11 — *"the weakest component… every claim
in the economic thesis is downstream of this component being right"* — showing
up inside Forge Flight, and it is exactly the identity-under-mutation problem the
re-anchor engine exists to solve.

I did **not** reach for embeddings to smooth it over. A dense-vector match
would merge claims confidently and wrongly, which is the failure mode this
entire system is built to refuse. It is left visible, named in the README, and
recorded as decision D7 — because a known limitation you can see is worth more
than a hidden one that looks like it works.

If you want the next real piece of work on this: that is it, and the engine is
already the right tool for it. The claims are stored as structured records
with a named scope and a normalized proposition — named, separable fields,
which is the engine's native domain and needs no adapter.
