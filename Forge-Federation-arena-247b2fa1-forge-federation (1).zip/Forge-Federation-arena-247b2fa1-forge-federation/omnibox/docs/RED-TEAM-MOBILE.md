# Mobile red-team pass — 2026-08-28

## Scope

This pass attacked the new phone surfaces rather than assuming the desktop
Electron tests covered them:

- the installable PWA in `mobile/`;
- the Android WebView wrapper in `mobile/android/`;
- the touch breakpoint in `src/renderer/chrome.css`.

The sandbox has no Android SDK or browser binary, so the checks here are static,
server-level, and source-level. No green result below claims that an APK was
built or that a third-party AI login was exercised.

## Findings and fixes

### P0 — disabled send control could be bypassed on Android

`seat-agent.js` found a send button that was disabled, then fell back to
synthetic Enter. That could submit a page that explicitly said it was not ready.
The agent now returns the named `send-disabled` refusal whenever its best
send control is disabled. Enter is used only when no send control exists.

### P0 — Android detector could seat a comment or checkout form

The first mobile score treated any large, bottom-of-page editable as a seat.
A document-flow comment field therefore passed without a message signal. The
agent now has the same conjunctive posture as the desktop detector: an
unanchored field needs a positive message label, and candidates must clear a
higher floor. It also names `ambiguous`, `below-floor`, and `no-composer`
refusals instead of guessing.

### P1 — the PWA forgot a prompt after claiming it was ready

The PWA cleared the prompt input and only showed a toast. If the user switched
to a seat, the text was gone. Prompts are now retained as a bounded local
`pendingPrompt`, rendered in the Table view, and can be copied explicitly.
The PWA says that it cannot inject through a cross-origin iframe; it does not
claim that it sent the prompt.

### P1 — corrupt local state could select a missing tab

A hand-edited or partially written local-storage record could point at a tab
that no longer existed, use an out-of-range history index, or carry non-HTTP
URLs into the UI. Load now repairs the active tab, clamps history, and filters
stored URLs before using them.

### P1 — phone address bar misread IPs and ports as searches

The PWA host recogniser did not accept `192.168.x.x:port`, IPv6 literals, or
some localhost paths. It now accepts hosts, IPs, ports, and path/query suffixes
while still refusing executable URL schemes.

### P1 — phone layout could hide the bottom of a table

The fixed prompt dock and bottom navigation could cover table/history content
on a short viewport. The app now lets the screen scroll vertically and adds
mobile bottom padding for the fixed controls.

### P2 — Android page scripts could replace the seat bridge

Android WebView injection runs in the page's JavaScript world, unlike the
Electron preload. A page could replace the global detector after injection and
make the wrapper believe a seat was ready. The agent now defines its two bridge
functions as non-writable/non-configurable where the WebView permits it. This
is tamper resistance, not isolation: a page still sees text that Forge Flight
intentionally types into that page. Full isolation would require a native
WebView API/plugin and is not claimed by this dependency-free wrapper.

## Residual risks kept visible

- A PWA cannot inspect or type into a cross-origin iframe. It offers **Open in
  browser** or **Copy prompt** rather than using a server-side proxy. The
  embedded frame also cannot reliably report an `X-Frame-Options` refusal to
  its parent, so the full-page action is always visible.
- The Android wrapper supports HTTP because it is a browser; users should
  prefer HTTPS. The default SSL behavior remains to reject certificate errors.
- Android's lightweight agent does not pierce closed shadow roots or
  cross-origin frames. It refuses when the current WebView cannot identify a
  safe composer.
- A third-party page can still observe text that the user deliberately sends
  into that page. The Android page-world bridge cannot provide Electron's
  isolated-preload guarantee without adding a native dependency.

## Re-runable checks

```sh
node --check mobile/app.js
node --check mobile/server.mjs
node --check mobile/sw.js
npm run mobile
```

Then verify the shell, manifest, service worker, and traversal refusal from a
phone or browser. The full Electron unit/UI/e2e gate remains separate; missing
Electron/Chromium tooling is reported as a skip rather than silently passing.
