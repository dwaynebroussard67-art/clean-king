# Decisions

One ruling per entry. A decision that was reversed from an earlier build says
so, and says why, rather than arriving as an unannounced diff.

---

## D1 — Forge Flight is the browser, not a bridge

The provider sessions live inside Forge Flight. Each tab is a real Chromium
`WebContentsView` in one shared persistent partition, so a login is a login
and it survives a restart.

**Rejected alternatives.** (a) A browser extension driving Chrome — that makes
Forge Flight a passenger in someone else's browser and puts it at the mercy of MV3
policy. (b) A local WebSocket bridge to tabs in another browser — two moving
parts to install, two things to keep in sync, and it was the source of every
connection bug in the earlier builds (`ws://localhost` resolving to IPv6 `::1`
while the server bound IPv4; an Edge-specific failure never isolated). One
process, no bridge, no extension.

**Cost, stated.** Electron. ~100 MB in `node_modules` and a real app to ship.
Accepted: nothing smaller gives real logged-in sessions with a real Chromium.

---

## D2 — Detection is structural, and refusal is a verdict

There are no provider names and no selector lists in `src/`. A composer is
identified by ten named, separable, weighted signals over real layout.

A candidate wins only if it beats the runner-up by `MIN_MARGIN` (0.12) **and**
clears `MIN_SCORE` (0.42). Otherwise the verdict is `ambiguous`,
`below-floor`, or `no-candidates` — and every one of those is rendered in the
seat rail with the tied signals named and a "Pick the box" button attached.

**Why a margin and not a maximum.** A maximum always produces a winner. On a
split-view page with two identical composers, "the best one" is a coin flip
that ships your prompt to the wrong pane and reports success. Refusing costs
one click. Guessing costs trust, and the person may never find out.

**The two signals that do the most work,** both lexicon-free:

- `anchored` — a chat composer does not scroll away with the thread. It is
  `position: fixed`/`sticky`, or it sits outside the scroll container. A
  comment box, a review field and a profile bio all live inside the document's
  own scrolling flow. This is what refuses the article-with-a-comment-box
  fixture.
- `sendAffinity` — a send-shaped control within six DOM hops, scored on its
  own six signals. Disabled buttons are kept as candidates, not skipped: a
  send button is *usually* disabled until the composer holds text, which makes
  disabledness a positive signal rather than a reason to look elsewhere.

---

## D3 — Read back before you send

`setComposerText` tries a ladder — native value setter, paste event,
`execCommand('insertText')`, `beforeinput`, direct DOM — and after each rung
reads the composer and compares. Send is pressed only on an exact match
(normalized for NBSP and line breaks). Which rung worked is reported and shown
in the run footer.

**Why.** Every fan-out tool sets a value and clicks send. When a provider
ships a new editor, that sequence quietly sends an empty message, or half a
message, or the *previous* message. Reading the box back is cheap and it is
the difference between a visible refusal and a silent wrong send.

**Why report the strategy.** When a provider changes editors, the rung that
stops working is the first useful piece of evidence, and it is already on
screen.

**A disabled send button is not forced.** If the page decided the prompt is
not sendable, Forge Flight reports `send-disabled` rather than dispatching a
synthetic Enter to get around it.

---

## D4 — The reply is found by time, not by size

`watchResponse` takes no selectors. It observes mutations and picks the
element that kept growing.

Two corrections were needed and both are load-bearing:

1. **Growth alone picks the thread**, because the thread holds your message
   *and* the reply — so the captured "answer" starts with your own prompt read
   back at you. The discriminator is time: your message appears once and
   stops; the reply grows until the model is done. Keep only what was still
   growing at the end, then take the deepest.
2. **A node that did not exist a moment ago is entirely growth.** Recording a
   freshly added node's baseline as "whatever text it already holds" makes a
   re-rendering chat — container destroyed and rebuilt per token — look like
   it never grew, and the thread wins again. Added nodes get a baseline of
   zero.

Both were found by writing `rerender-chat.html`, a fixture that destroys and
rebuilds its reply container on every token. It failed on the first run. That
fixture is the reason this section exists.

**Completion is settling, not a spinner class.** No growth for `settleMs` ends
the capture. If it never settles, the capture returns what it has and reports
`timeout` — shown in the UI as "never settled" — rather than truncating
silently and calling it an answer.

---

## D5 — The rules are code, not documentation

- **One seat per host** (`seats.js`). Two tabs on one site cannot both be
  seated. This is the multi-accounting rule, enforced.
- **User-triggered only** (`table.js`). No scheduler exists. Shapes declare
  their rounds, capped at `MAX_ROUNDS = 4`, and every run is stoppable.
- **Human pacing** (`table.js`). `STAGGER_MS = 260` between seats,
  `MIN_SEAT_INTERVAL_MS = 1500` per seat.
- Seating, muting and refusal are decided in the **main process**. The
  renderer cannot seat a tab. Client flags are not a boundary — that is the
  Forge Mode entitlement-gate lesson applied here.

---

## D6 — C4a: a privileged field is REJECTED, not stripped

**This reverses the Python build, deliberately.**

The Python `WriteBoundaryGuard` pops privileged fields (`status`,
`adjudicatedAt`, `pinned`, `confirmationCount`, `id`, `claimId`, …) and
continues. A reviewer on that build argued for reject, on the grounds that
silent stripping lets a model believe its write succeeded exactly as specified
when a field was quietly dropped — the same "visibly absent, never quietly
missing" principle the exclusion audit is built on, applied to writes.

That argument is right, and the specific attack decides it:
**export → relabel → reimport.** Take a provisional memory out, edit
`"status": "supported"` in the file, put it back. Stripping makes that a no-op
the attacker never sees. Rejecting makes it an error.

The forgiving case — a model that includes a stray field out of habit — is
handled by naming the offending field in the error, so the next attempt is
correct. Nested smuggling (`metadata.status`) is refused the same way.

---

## D7 — Claim identity stays exact text, and stays visible

> **Replaced by D16** for facts that reduce cleanly to an equation. Prose
> identity itself is unchanged and remains the fallback for everything that
> does not reduce.

`claimSignature = sha256(scope | normalized proposition)`. Whitespace and case
are normalized; nothing else is. Two seats answering "Paris" produce one claim
and two witnesses. "Paris" and "The capital of France is Paris" produce two
claims.

**Not fixed with embeddings, on purpose.** A dense-vector match merges claims
confidently and wrongly, and a wrong merge means serving an answer to a
different question — which is the exact failure this store exists to prevent.
Reaching for a fuzzy match here would trade a visible limitation for a hidden
one.

It is named in the README, and it is the same identity-under-mutation problem
the re-anchor engine solves. Claims are stored as structured records with
named separable fields, which is that engine's native domain.

---

## D8 — The composer may be inside a shadow root or a same-origin frame

`document.querySelectorAll` does not pierce a shadow root, so a chat built as
a web component is invisible to an ordinary query: the detector saw an empty
page and honestly reported `no-candidates` while the composer sat on screen.
Everything that walks the DOM now walks open shadow roots too, and a shadow
host counts as the parent of its root — so ancestry, hop counts and anchoring
all resolve across the boundary. Selection inside a shadow root comes from
`shadowRoot.getSelection()`, not `window.getSelection()`, which returns the
host. The manual picker uses `composedPath()[0]` rather than
`elementFromPoint`, which stops at the host.

Same-origin frames are walked the same way, and an element inside one is
scored against **that frame's** viewport — its layout has nothing to do with
the top window's.

Two things stay unreachable, and both report themselves rather than
pretending:

- **A closed shadow root** cannot be entered by anyone, including us.
  `no-candidates` is the truthful answer.
- **A cross-origin frame** may not be read by this process. That gets its own
  reason, `cross-origin-frame`, and a refusal that says what to do: *"Open
  that chat in its own tab and it will seat itself."* Reporting it as "not a
  chat" would have been a lie.

Widening `nodeIntegrationInSubFrames` would have made cross-origin frames
reachable and was rejected: it hands a Node-capable preload world to every
subframe on every page, including ad frames.

---

## D9 — The conjunctive rule: an unanchored, unlabelled box is not a seat

A weighted mean is the wrong shape for the comment-box case. A comment field
on an article is a big multiline editable, near a send-shaped button, wide,
centred and low on the page — seven signals near maximum. It fails on exactly
the two that matter, and three zeros out of ten do not sink a mean; it scored
0.56 and seated. Raising the floor to compensate would have been tuning to a
fixture.

So three signals combine instead of averaging:

> An editable that **scrolls away with the document** must be positively
> identified as a message field — labelled as one, and not labelled as
> something else.

Failing that is not a low score, it is a different kind of thing, and it gets
its own reason: `document-field`. This is the conjunctive-discriminator shape
— no single signal clears the case, a *pair* does.

It is deliberately hard to trip by accident. A real chat has to fail on two
independent axes at once: an unanchored composer still passes if the page
calls it a message box, and an unlabelled composer still passes if it is
anchored.

---

## D10 — The store is an append-only log, not a database

`passport.jsonl`, one JSON record per line, `appendFileSync`.

**Why.** The passport's own model *is* an append-only event trail with two
derived projections. A log is the honest representation. And a native SQLite
binding needs a rebuild against Electron's ABI on every machine — the single
most common reason a hobby Electron app fails to start on someone else's
Windows box. Forge Flight installs with `npm install` and nothing else.

A torn final line (a crash mid-write) is dropped on load and **counted**, not
swallowed. `node:sqlite` can replace this behind the same narrow interface
when there is a reason.

---

## D11 — A reply is a candidate, never a fact

`ingestReply` writes: `type: fact`, `confidence: 0.4`, unpinned,
unadjudicated, `origin: local`, evidence pointer `seat:<host> run:<id>`.

The evidence pointer *is* the witness identity, which means C2's witness
signature does the right thing for free: two seats answering one prompt are
two distinct witnesses; one seat answering twice is one.

A refused intake is logged as an `intake_refused` event and returns null. It
never throws — losing one candidate memory must not take down a run.

**Cross-provider agreement and disagreement are recorded, and neither closes
anything.** Two seats producing different claims is a `cross_disagreement`
event on both. It does not contest either claim, because "two models phrased
it differently" is not evidence that either is wrong. Closing a claim stays a
deliberate act.

---

## D12 — The chrome loads nothing remote

`src/renderer/` is local HTML under a strict CSP (`default-src 'none'`). The
preload bridge exposes named channels only — no `invoke(anything)` escape
hatch. Tab preloads run in Electron's isolated world with `contextIsolation`,
and expose **nothing** to the page: no `contextBridge` surface at all. A page
cannot reach Node, cannot reach IPC, and cannot see that it is seated.

---

## D13 — Import is a translation, not a restore

A passport exports as one readable JSON file carrying claims, memories and
the event trail. Importing it does **not** restore that state: each record is
reduced to the fields a writer is allowed to set, and everything privileged —
status, witness counts, promotion stamps, pins, adjudication — is left behind
**and reported by name**.

That is C4 carried across a file boundary, and it is why the obvious attack
does not work: open the export, set every claim to `supported` with 99
witnesses, import it somewhere else. Every memory still arrives provisional,
unpinned, unadjudicated, with zero witnesses, and the import tells you exactly
what it refused to carry. The export file says so about itself, in a `note`
field, so nobody has to guess.

Restoring a passport byte-for-byte is a different operation on a different
trust footing. It is not this one, and it is not built.

---

## D14 — Furniture is not a reply: five named demotions in the watcher

A real passport export (2026-08-27, three providers) came back with **zero
actual replies captured**. A sidebar's auto-generated chat title, an account
menu, and a mid-word slice of furniture text had all settled as "the answer"
and been ingested as `outcome` witnesses. A wrong capture is not a small bug:
it poisons the store at intake, because everything downstream — witness
counting, promotion, TrustGate — is fed it as fact.

Fixtures model reality now (first token at 600ms, not at click time), and
that alone exposed a fifth latent defect: with realistic timing the old
watcher settled on **the echo of your own prompt** whenever the model took
longer than `settleMs` to start. On real providers, that is most of the time.

Five demotions, each named in code with its reason, all in
`src/preload/watch.js`:

| Demotion | Rule | Kills |
|---|---|---|
| `reaction` | growth beginning within 500ms of the watch starting | the prompt echo, menus opening, sidebar retitles |
| `landmark` | growth inside nav/aside/header/footer/menu/dialog/tooltip/listbox that does not contain the composer | sidebars, account menus, dropdowns |
| `mid-word` | capture would start mid-word ("organ\|ization") | baselines taken mid-update |
| full priming | every element baselined, not only small containers | the mid-word mechanism itself |
| settle gate | early settle needs ≥3 chunks, or ≥240 chars, or grace elapsed with ≥64 | one-shot furniture landing whole |

The posture change is the important part: **demoted growth never satisfies an
empty capture.** If only furniture grew, the watcher returns empty and the
seat reports `empty-response` — a visible, named, re-runnable refusal —
rather than furniture as a fact. This reverses the old "if trivial growth is
all there is, we still return it" posture *for furniture specifically*;
trivial growth inside the conversation region still behaves as before.

The landmark list is HTML landmark tags and ARIA roles — structure, not
provider selectors. D2's "no selector list" rule is intact.

---

## D15 — Engine-training records live outside the Memory Passport

Forge Flight is the only thing in the stack that can give the re-anchor engine
production-time evidence: *I acted on this anchor and the world responded.*
That evidence is now captured — but into **its own append-only file**
(`anchors.jsonl` in the user data dir), never into the passport.

What a record can hold: the anchor stamp (identity fields, structural path,
box, the ten named signals, a `stabilityKey` for cross-load comparison), the
losing candidates with their signals, the named outcome of a step, the
human ruling when someone picks the box by hand, and — when a redetect on a
known URL changes the winner or flips the verdict — the before/after pair,
which is a real mutation with a known-good before-state and costs nothing to
collect.

What it can never hold: conversation content. `sanitize()` in
`src/main/anchors.js` strips any field whose name says it could carry human
or model text — prompt, reply, text, content, at any depth — before anything
touches disk, and bounds every string that is allowed. The e2e run asserts
the property end to end: three real runs, prompts nowhere in the file.

Two disciplines that came with it:

- **Instrumentation only.** Detection, refusal and margin rules are unchanged
  by the recording. A page is never seated because a label exists somewhere.
- **Dedup, not churn.** Mutation re-detects that produce an identical verdict
  write nothing; the log records changes. Before/after pairs are emitted on
  the change, per URL.

The label-to-lesson bridge is now in-product (D32). It reads this log,
promotes a named composer signal only under unanimity, and never feeds
`reanchor.js` or retunes `COMPOSER_WEIGHTS`.

---

## D16 — The equation form: claim identity for facts that reduce cleanly

**This reverses D7** ("claim identity stays exact text"), and says so rather
than arriving as an unannounced diff.

D7 was honest but measured-broken: with prose identity,
"The capital of France is Paris", "Paris is the capital of France" and
"France has Paris as its capital" are three claims with one witness each,
and nothing ever promotes. On one machine that means cross-provider
agreement almost never fires; on a store fed by many harnesses it means
near-duplicates accumulate forever and establish nothing.

**The form.** A fact may carry an equation — subject, predicate, object,
plus optional units and time, plus scope. Identity is CONJUNCTIVE: the same
claim only when every field agrees. A different object is a different
claim, never a merge, never silently reconciled. Time and units partition
identity ("the capital in 1900" is not "the capital"). An equation key is
prefixed so it can never collide with a prose key.

**The safety rules, all enforced in code** (`src/passport/equation.js`):

- *A model nominates; code decides.* A nomination is data on a write. The
  boundary checks its shape, canonicalises it, and verifies it is GROUNDED —
  the subject and object must actually occur in the prose being reduced. A
  nomination cannot invent content.
- *The soundness rule.* If the reduction is not clean — wrong shape,
  oversized fields, ungrounded — the claim keeps its prose form, the exact
  signature it has always had, and simply never merges with anything.
  Never merged wrongly beats often merged.
- *Prose identity is unchanged*, so existing stores replay identically.
- *Across a file boundary an equation is a re-nomination, not a carried
  identity.* Import re-proposes and re-accepts it against the prose; an
  edited export claiming `capital(france) = tokyo` against text that says
  Paris arrives as prose. Tested.

The deterministic nominator that runs today is a **labelled placeholder**
(same posture as `HashEncoder`): it recognises four closed sentence shapes
so the pipeline is demonstrable with no API key. A model nominating through
the same interface replaces it with zero downstream changes.

Vectors remain ruled out. This is not an embedding and not a similarity
merge — it is an exact key over named fields, and two equations merge only
when every field is equal.

---

## D17 — The event trail is hash-chained

The store was append-only by discipline. Now every line in `passport.jsonl`
carries `prev` (the hash of the line before it) and `hash` (of itself,
including `prev`), so an after-the-fact edit, deletion, or splice anywhere
in the log breaks the chain at that line and is detectable by
recomputation (`store.verify()`). Append-only is a verifiable fact, not a
hope.

Design points:

- **A break is reported, never fatal.** The store loads its data and
  carries the finding in `stats().chain.breaks` — a tampered history is
  evidence, and refusing to boot would destroy the evidence.
- **Legacy logs load untouched.** Lines written before D17 have no chain
  fields; they count as `legacy` and the chain starts at the first new
  line. A legacy-format line appearing *after* a chained line is itself a
  break.
- **The export carries the chain head as provenance, not authority**
  (`chain.head` in the bundle). Nothing on import trusts it — D13 is
  unchanged.
- A torn final line is still dropped and counted, as before.

Idea credit: the layered-architecture proposal D handed over 2026-08-27;
this is the one vector-free idea adopted from it (see
`docs/CROSS-BUILD-NOTES.md`).

---

## D18 — The local seat is a tab, not an app feature

Forge Flight is a browser. The reserved local-model seat (`forgeflight://local`,
ruled in the 2026-08-27 session) does not change that, and the design
decisions that keep it true are the point of this entry:

- **The model never ships inside Forge Flight.** The "model" is whatever
  OpenAI-compatible server is already running on the machine — Ollama on
  11434, LM Studio on 1234, or `FORGEFLIGHT_LOCAL_LLM_URL`. No key, no
  account, no download. No server running → the send control stays
  disabled and the seat says why: `send-disabled`, the same honest
  refusal any page gets. Never a faked answer.
- **The seat earns its place through the ordinary pipeline.** The local
  page is a chat page — composer at the bottom, thread above — detected
  by the same ten structural signals, typed into by the same ladder with
  read-back verification, captured by the same watcher. Nothing in the
  table special-cases it. The browser treats a page it owns exactly like
  a page it doesn't.
- **One preload per webContents, and the bridge is narrow.** Only
  `forgeflight://local` gets the bridge preload; the main-process handlers
  re-verify the sender's URL; the page's CSP forbids every network
  connect; the bridge talks to localhost only. A provider page can never
  reach it.
- **The helmet.** For the local seat alone, Forge Flight controls the whole
  context — so the passport's boot block (adjudicated facts, exclusion
  audit and all) rides in as the system message of every turn. This is
  the two-part delivery's immediate half, made concrete: a small free
  model wearing the Federation's knowledge, holding its weight at the
  table. The deep-well pull half is future work.
- **A watcher refinement came with it, and a fixture caught a bug in the
  refinement.** A local model can stream its first token inside the
  500ms reaction window, so "reaction" was narrowed from *started early*
  to *landed whole early* (first AND last growth inside the window) —
  furniture lands in one piece, a stream crosses the far edge still
  growing. The narrowing initially let long-running furniture's ANCESTORS
  back in (timestamps inherited from a late ticker); the
  `ticker-fragment` fixture caught it, and demotion now propagates up the
  furniture's own ancestry until something real grows inside it.

If you never open the tab, nothing about the browser changes. One icon
next to the new-tab button.

---

## D19 — A session is a list of places, not a bag of credentials

The logins were never the problem. Every tab lives in one persistent
partition (`persist:omnibox`, D1), so each provider's cookies and session
tokens were already on disk across restarts. What a restart lost was the
*list*: nothing recorded which sites were open, so getting the table back
meant reopening every AI by hand and letting each one decide whether it
still recognised you. Resuming is therefore a small thing, and the
decision is about keeping it small:

- **The session file stores URLs and nothing else.** `<userData>/session.json`
  holds the tab list, which one was in front, and who was assigned which
  side. No cookie, no token, no `Authorization` header, no prompt, no
  reply — there is nothing in it to steal that a browser profile does not
  already hold. Restoring means asking Chromium to open those places again
  with the profile it already has.
- **The allowlist is by name, not by trust.** `https:` and our own
  `forgeflight:` pages, plus `http:` for loopback so a local fixture or dev
  server can be resumed. `file:`, `data:`, `blob:` and `javascript:` are
  refused on the way in *and* on the way back out: a file we wrote is not
  automatically a file we still vouch for. A URL that will not survive the
  allowlist is dropped, never rewritten.
- **A resume is compared by host, because one seat per host is the law.**
  If a tab on that site is already open, the saved tab does not come back —
  the rail would only block it as `duplicate-host`. Forge Flight's own pages are
  the exception and are compared exactly, because `forgeflight://local` and
  `forgeflight://start` are different rooms, not the same site.
- **Emptying the table is recorded, not mistaken for forgetting it.** Closing
  the last tab flags the session `closedAll` and leaves the list on disk. A
  launch honours the choice and opens the start page; the Resume button
  still offers the list, which is the case it exists for. Deleting the file
  instead would make a mis-click unrecoverable, and reopening it anyway
  would make "I closed everything" mean nothing.
- **A hand-picked composer is remembered, as a hint and never as a
  verdict.** A ruling used to live only in the tab that received it —
  `manualPick` is in-memory, and the copy written to `anchors.jsonl` is an
  engine-training record nothing reads back (D15). It now also lands in
  `<userData>/picks.json`, per host, as the stamp's stability key and
  structural path: identity and structure, never a placeholder, a label or
  any text a person or model wrote. On the next load the key is recomputed
  against the page's current composer candidates and applied only on an
  exact match. No match means no replay: the ordinary verdict stands, so an
  ambiguous page after a redesign asks again instead of inheriting a guess.
  The pick is checked against the host it was made on, so it can never
  follow a tab that navigated somewhere else.
- **What it cannot do is named.** If a provider revoked the login, the
  restored tab shows their login page and the detector refuses to seat it,
  with the reason. Forge Flight has no credential to re-inject and does not
  pretend otherwise. Scroll position and the visible thread belong to the
  provider; a restored tab shows whatever the site shows.

---

---

## D20 — The triangle is three machines. The human is step four.

The runtime triangle is READER (proposes, cannot promote), OVERSEER (decides,
never reads the page), ORACLE (does not listen). The obvious way to add human
oversight is to make the human the overseer. That is wrong, and it is wrong in
a way that only shows up under pressure.

If the human is the overseer, the reader is optimising to **persuade a
person** — and models are extremely good at that. Because the overseer is
blind and mechanical, there is nothing in it to persuade: a proposal wins by
being correct against the equations or it does not win. So persuasion has
already failed as a strategy *before* anything reaches a human.

The human is therefore not the defence. The human is the **release**. Putting
them outside the triangle makes it tighter, not looser.

---

## D21 — The curator writes to one place, and it is not the Federation

Mission control sees more than any pilot. That is its job, and it is also
exactly what makes it the most valuable thing in the system to compromise —
everything else is distributed; this one thing sees everything.

So: read access to everything, write access to **one append-only proposal
queue**. Not the Federation, not the passport, not a capability registry. It
proposes; it never sends, never flies, never mounts.

Two consequences, both deliberate:

- **Filter, never source.** It may only reduce what flows from facts that
  already cleared the entry rule. It cannot originate one. A compromised
  curator can therefore only STARVE the fleet — loud and detectable — never
  POISON it, which is silent. You survive starvation.
- **Strictly additive.** A mission must complete with the curator entirely
  offline. The moment pilots start failing without it, it has stopped being
  additive and become a single point of failure *and* a single point of
  attack at once.

Withdrawals stay in the record. A curator that could quietly retract would
leave a history showing only the proposals it still stood behind — which is
precisely the history you would want if you ever suspected it of steering.

---

## D22 — A denial must name a broken constraint, or it is an opinion

This is the reason the Federation stores equations rather than prose, and it
is the deepest property in the design.

Because the base is equations, the curator **cannot object arbitrarily**. It
cannot say "I have a bad feeling about this." The only objection available to
it is to point at a named broken constraint and the named variable that broke
it:

    Pilot 3 requested browser.fetch.
    Its preconditions assumed rate_limit(claude.ai) = 100.
    Federation holds rate_limit(claude.ai) = 0 — 3 witnesses, provisional,
    since 2026-08-30. Constraint rate_limit(claude.ai) fails.
    Denied pending your call.

Four seconds to check. With prose you get a paragraph of reasoning and you are
back to rubber-stamping.

So it can never become the oracle — not because power was taken away, but
because **every objection it makes is independently verifiable by the person
it is making it to**. A thing that must show its work cannot accumulate
authority.

Corollary, enforced in code: `federation:release` takes no default actor. An
anonymous approval is the machine approving itself, and the queue refuses it.

---

## D23 — Two shelves, two clocks, one gate

The Federation holds two kinds of thing and one lifecycle breaks both.

**World** claims are true independently of who is asking. Five distinct
witnesses promote; one contradiction **closes** the claim permanently. They do
not expire.

**Operational** facts are scoped to a target that mutates. When a site ships a
redesign the old fact did not become wrong — it **expired**. So a
contradiction **supersedes** rather than closes, because firing "one
contradiction closes it forever" on every redesign would empty the shelf every
quarter.

Same entry rule for both — `outcome`, `structural`, `contract`, `human`, and
agreement is deliberately not on the list and never will be. Different clocks.

Nothing is ever deleted on either shelf: the store exposes no delete method at
all, and the test suite asserts its absence. Stale gets a **recheck**, never an
eraser — which is also the answer to the measured drift problem, since a
promoted ruleset is a snapshot and the curator is the cadence that keeps it
from staying one.

---

## D24 — Replication is not agreement

Three of the four witness kinds do not require trusting the sender:
`structural` is re-derivable by anyone, `contract` is published, `human` names
the human. That is why no reputation system is needed — a hostile node cannot
produce a witness that must be *believed*, so the worst it can do is spam
unverifiable noise, which drops.

`outcome` is the exception and the one the oracle plan leans on hardest: "I
acted and it worked" is self-reported and nobody else saw it. So a single
node's outcome fact stays **local**. It travels only when independently
replicated by distinct nodes, or paired with a structural witness.

Five nodes independently **measuring** the same outcome is not five parties
agreeing on an opinion — it is five measurements. That distinction is what
lets the outcome witness survive fleet scale without the oracle starting to
listen.

---

## D25 — A background tab needs a real box, or it can never take a seat

Session restore shipped and did not work: relaunching brought back one seat
out of three, and the cause was not in the session code at all.

Every signal the detector uses is a **layout fact** — area, distance from the
bottom of the viewport, horizontal centrality. `open()` parks a background tab
at 0x0, and Chromium does not lay out a zero-size view, so every signal reads
zero, every candidate falls below the floor, and the tab can never seat. Only
the one tab that got activated ever came back.

Invisible when you open tabs one at a time, because each is active as it
opens. Fatal to a restore, which opens them all in the background at once.

Fix: a tab that has not yet produced a verdict gets the **same box as the
active tab**, with the active tab raised above it in z-order by re-adding its
view; once it rules, it is parked like any other background tab. Off-screen
positioning was tried first and does not work — Chromium skips layout for
those too.

The same fix exposed a bad assertion the bug had been hiding: the sides test
compared restored assignments by *position*, which only passed because a seat
was missing. It now checks by host, and a seat that joined after an assignment
was made correctly takes the default instead of failing the run.

---

## D26 — OmniBox is Forge Flight; the collective is the Forge Federation. Nothing a person built is lost in the rename.

Somebody else already ships a product called Omnibox, so the browser is now
**Forge Flight** and the carrier — the collective, the shared equation base
that many cockpits land facts on — is the **Forge Federation**. This entry
exists because a product rename is trivial in prose and dangerous on disk:
Electron names the profile folder after the app, and inside that folder sit
the cookie jar (every login), the passport, the session, the picks, the
anchors and the federation. A rename that only changed strings would have
started every existing user from nothing, with their whole history sitting
one folder over, invisible.

**What changed, in one sweep** (2026-09-04): product name, every string a
person sees, the custom scheme (`forgeflight://start`, `forgeflight://local`),
the page-visible globals and attributes (`__FORGEFLIGHT_*__`,
`data-forgeflight-*`, `window.forgeflight`, `forgeflightLocal`), the
environment variables (`FORGEFLIGHT_USER_DATA`, `FORGEFLIGHT_LOCAL_LLM_URL`,
`FORGEFLIGHT_CHROMIUM`, `FORGEFLIGHT_E2E`), the package and installer
identity (`forgeflight`, `com.misfit.forgeflight`, `ForgeFlight-<v>-<arch>`),
the phone build (`Forge Flight Pocket`, `com.misfit.forgeflight.mobile`, its
storage and cache keys), the source folder `src/collective/` →
`src/federation/`, the class `Collective` → `Federation`, the IPC namespace
`collective:*` → `federation:*`, the on-disk folder `collective/` →
`federation/` and its log `collective.jsonl` → `federation.jsonl`, and the
export schema ids (`forgeflight.passport.v1`, `forgeflight.federation.v1`,
`forgeflight.queue.v1`). Decisions D19–D24 of the federation line were
renumbered D20–D25 to resolve a numbering collision with the session-restore
D19; no text changed.

**What deliberately did NOT change, and why — each one enforced or tested:**

| Kept | Where | Why |
|---|---|---|
| `persist:omnibox` — the cookie partition name | `src/main/tabs.js` | It **is** the logins. A partition name is never shown to a person or a page; renaming it signs everyone out of every provider for nothing. Pinned by `test/rename.test.js`. |
| `omnibox.passport.v1` accepted on import | `src/passport/index.js` `IMPORT_SCHEMAS` | A passport carried out of OmniBox is the same shape and crosses the same translation (D13). New exports declare `forgeflight.passport.v1`. Tested both ways. |
| `omnibox.collective.v1` / `omnibox.queue.v1` lines in old logs | `src/federation/` | The schema field is a per-record label, never checked on read. Old lines replay identically; the hash chain is untouched because the bytes are. Tested. |
| `omnibox://start` / `omnibox://local` in a saved session | `src/main/session.js` `restorableURL` | Translated to `forgeflight://…` on the way in rather than dropped — same two rooms. The allowlist did not widen. Tested. |
| `OMNIBOX_LOCAL_LLM_URL` | `src/main/localLLM.js` | Still honoured when the new variable is unset, so a shell profile keeps working. Tested. |

**The profile adoption** (`src/main/profile.js`, run once at boot unless
`FORGEFLIGHT_USER_DATA` isolates the run): if the Forge Flight profile
folder is empty and an `omnibox` folder sits beside it, the old folder is
**moved** into place — not copied; a profile can be gigabytes of Chromium
cache, and two live copies of one cookie jar is how a person ends up logged
out of the one they are using. A note is left in the old location naming
where the profile went. Rules, all tested: never overwrite a populated new
profile; never adopt twice (the note marks it); fall back to a copy across
volumes and say so; never throw — a failed adoption starts a fresh profile,
leaves the old one untouched, and tries again next launch. The same
once-only, never-overwrite, never-throw adoption moves an old
`collective/collective.jsonl` and `collective/queue.jsonl` into
`federation/`, and on the phone moves Pocket's saved tabs from the
`omnibox-pocket-v1` localStorage key to `forgeflight-pocket-v1`.

**Two things a rename cannot bridge, named so nobody is surprised:** the
desktop installer id (`com.misfit.omnibox` → `com.misfit.forgeflight`) and
the Android application id (`com.misfit.omnibox.mobile` →
`com.misfit.forgeflight.mobile`) are the identities operating systems use to
decide whether an install is an upgrade. They are not. A Forge Flight
install lands beside an OmniBox one and adopts its profile on first launch;
the OmniBox install can then be removed by hand. Keeping the old ids would
have kept the old name in every OS settings pane forever, which is the one
place the rename was for.

The rename touched no rule: detection, refusal, the write boundary, the
witness arithmetic, the hash chain, the triangle, and the pipe rule are
byte-for-byte the same logic under a different name. The gate is the proof —
143 unit checks green after the sweep, 11 of them new and all about not
losing anything.

---

## D27 — Field evidence: the person looking at the page is the oracle

The fixtures prove the detector refuses the failures we imagined. Real pages
redesign without warning and fail in ways nobody imagined, so the
confidently-wrong rate has to be measured on pages we do not control, against
drift we did not author. The instrument is two halves:

- **A ruling.** The seat sheet on an automatically seated tab asks "is this
  the right box?" with "box is right" / "wrong box" buttons. The ruling lands
  in `anchors.jsonl` as a `confirm` record carrying the seated anchor's
  stability key — the join key, never the page text — and stays rendered on
  the tab only while the anchor is unchanged. A changed winner retires it,
  because "k1 was right" says nothing about k2; a navigation clears it,
  because a new page is a new claim. Manual seats are never asked: the person
  already chose the box.
- **A scorer.** `src/field-evidence/scorer.mjs` reads the log and scores
  confident automatic claims against human rulings (picks and confirms),
  joined by exact url. Outcomes and anchor-changes are counted and reported
  but never adjudicate: whether the world answered says nothing about whether
  the anchor was the right box, and a flipped winner is instability, not
  wrongness. With no rulings the rate is null — unknown — never 0.0, because
  absence of disagreement is not evidence of correctness.

Last ruling wins: a person who confirms and then changes their mind has their
latest judgment stand. A ruling that pairs to no confident claim is unpaired,
and when the latest verdict there was a refusal it is a refusal resolution —
the refusal path working, counted apart from the seating path failing.

---

## D28 — Pilots fly tabs; the address bar remembers places

The table asks; the pilots act. Four browser agents, four slots, twelve steps
each, one verb per step from a closed set — navigate, click, type, press,
wait, done. The brain is the local model if one answers, else the first open
seat; prose instead of strict JSON is `bad-json` and the flight stops. Every
guard in this product is a refusal with a name, and the pilots add three:

- **Ambiguity is a refusal.** A click or type matching more than one visible
  element stops the flight (`ambiguous-click` / `ambiguous-type`, count named)
  instead of first-match guessing into the wrong control. The disabled control
  it almost touched gets its own name too (`disabled`), never a mislabelled
  `not-found`. When the re-anchor engine lands it takes over this decision
  with a corroborated re-grab; until then refusal is the whole defence.
- **A pilot with nowhere to fly never leaves the ground.** Launch without a
  URL or a tab is `no-target` at the gate, so the Launch button always sends
  the pilot at the tab you are looking at — launching was the dead button in
  the first draft, and a goal alone was its cause.
- **Cleartext is loopback-only.** A pilot navigates to `https`,
  `forgeflight:` pages, and `http` on localhost — never an arbitrary
  cleartext page that would read everything it types.

Every step lands in the anchors log as verb + refusal (`pilot-step`), never
the selector, the typed text, or a page word — the scorer counts these lines
as flight records, never as detector evidence, so the flight recorder cannot
pollute the confidently-wrong rate it shares a file with.

Beside them, the address bar grows a memory: `recent.json` keeps the last 200
restorable places (URL + title, nothing else) and suggests mid-URL matches as
you type. Corrupt file, empty list — never a crash.

Ported from the pilots/history branch, which was never merged: its live-update
path was dead twice over (events emitted on channels nobody listened to, in a
shape nobody destructured), and its base predated the rename. The port fixes
both and carries the re-anchor rule the original lacked: never guess.

---

## D29 — The radio, the operator, the captain, the short helmet

The Memory Passport and the Federation were two stores in one process with
no radio between them. That is now wired, in four pieces, all additive
(D21): a mission completes if any of them is offline.

- **Up.** A Passport claim that is `supported` *and* reduced to an equation
  is proposed to the curator. Already-queued equations are not re-proposed.
  The curator still cannot release. A human still signs.
- **Down.** Federation facts enter a session's boot block as a separate
  `=== FEDERATION CARRIER ===` section under the same exclusion audit.
  They are not injected as Passport witnesses.
- **Operator.** A release is signed by a configured name
  (`FORGEFLIGHT_OPERATOR` or `operator.json` in the user data dir). The
  renderer may ask to set the name; the main process is what writes it and
  what stamps it. A renderer-supplied actor is ignored. No operator
  configured → every release is refused (`no-operator`). There is no
  hardcoded `'D'`. See `docs/FEDERATION-IDENTITY.md`.
- **Captain.** After the copilots answer, the local model is asked for
  strict JSON: `verdict`, `defer` (name one seat), or `unknown`. Anything
  else is refused. No local model → `{skipped:true, reason:'no-captain'}`.
  The captain is a chair, not a table peer, and does not unseat the local
  tab (D18).
- **Helmets.** The local seat wears the full boot block as its system
  message. Copilots get a short briefing of *established* carrier facts
  only, capped, never the notebook. Dumping the passport into a public
  chat box would leak the fighter.

Re-anchor is still not in this product. Refusal stays the whole defence
until it lands.

---

## D30 — The human is captain when the local model is away; sign in every launch; talk both ways

D29 left the captain chair empty when no local model answered
(`{skipped:true, reason:'no-captain'}`). That is now reversed. Copilots
still run. The chair is never skipped: a live local model decides; if it
is absent or fails to answer, the **human** takes the same three
decisions — verdict, defer to a named seat, or unknown — and the stamp
is this launch's signed name. Unknown stays first-class. Fusing is still
refused.

Two more rules, both about the human in the cockpit:

- **Sign in every launch.** A name on disk (`operator.json`) or in
  `FORGEFLIGHT_OPERATOR` is a memory, not a session. The chrome asks who
  is flying before anything else. Main writes the name and stamps it. A
  renderer-supplied actor is still ignored. Not signed in this launch →
  `not-signed-in` (this replaces D29's `no-operator` as the closed
  door). Env-locked cockpits confirm the locked name; they cannot pick
  another.
- **Talk both ways.** Every input has talk-to-text. Every output has a
  Listen button. Listening is never automatic.

The local model is still whatever OpenAI-compatible server is already
running on this machine. It is not a chat box we ship, and it is not a
product name. The house seat (`forgeflight://local`) may still sit at
the table as a peer (D18). Re-anchor is still not in this product.

---

## D31 — SOUND find: unique badge, unique strong id, unique text. Nothing else commits.

The re-anchor engine landed, as a copy, at `src/detector/reanchor.js`
(v8.0.0). It is the only grab that may commit after a page moves.

Three tiers, in order:

1. An injected badge (`data-frg-id`) — unique by construction.
2. A strong app id (`id` / `data-id` / `data-testid` / `name`) — only if
   exactly one element in the document bears it.
3. The same tag and the same normalised text — only if unique in the
   document. Bidi marks are stripped so a wrap-only mutation still matches.

Class, href, src, and structural tag+index never commit. A crowd is a
miss, never a first match. `suggest()` exists and is unconfirmed; nothing
in Forge Flight auto-applies it.

Where it sits:

- A seated composer is badged this load. A mutation re-finds it or
  falls through to ordinary detection. A miss is not a guess.
- A pilot click or type that matches several elements still refuses,
  unless the engine uniquely re-finds the control this flight already
  stamped, and that hit is one of the matches. Corroborated re-grab.
  Otherwise `ambiguous-click` / `ambiguous-type`, as before.
- Remembered picks on disk are unchanged: join key, no page text, no
  id. The engine does not write conversation content.

This reverses the "until the engine lands, refusal is the whole
defence" clause of D28 only for the corroborated case. Refusal remains
the defence whenever the engine cannot uniquely commit.

---

## D32 — A refusal is a lesson, but only under unanimity

The notebook already existed (D15): an ambiguous verdict writes `tiedOn`
and stamped candidates into `anchors.jsonl`, and a later pick on that
URL is the human ruling. Nothing read those records to seat anyone.
That is the teacher (`src/field-evidence/teacher.js`).

**Join.** The last same-URL `verdict` with `status=refused` and
`verdictReason=ambiguous`, plus a later `pick` that is `ok`. The pick's
`stamp.stabilityKey` must match a refusal candidate. Confirm is not a
join — it judges a seated box, it does not name a discriminator.
A later seated / not-a-seat on that URL without a pick abandons the
pending refusal. Unresolved refusals are counted and never become a
negative lesson or a weight demotion.

**Discriminator.** Among the ten named composer signals that are *not*
in `tiedOn`, the winner minus the best loser must clear 0.05. Several
qualifying → the widest margin. None → unexplained, and unexplained
does not promote. Class, href, src, sibling index, and `suggest()` are
not signals and cannot become a lesson. Conversation text is stripped
the same way the log strips it.

**Unanimity.** Group by the sorted `tiedOn` key. Promote only when
every example shares one named discriminator, at least three distinct
hosts agree, and none contradict. Mixed discriminator, a null
discriminator, or a contradiction blocks the whole set. Short of that
bar the lesson is provisional. Provisional is the notebook. It is
never applied.

**Apply.** Only on a later matching ambiguous tie, only a promoted
lesson, only among candidates close enough on the aggregate that they
were in the tie (within `MIN_MARGIN` of the leader, still above
`MIN_SCORE`). A fourth-place box that merely clears the floor is not
in the argument. The discriminator must uniquely separate that close
crowd by `MIN_MARGIN`, and a missing signal is ineligible, not zero.
Else the ordinary refusal stands. Detection stamps `lessonApplied`
when it seats this way. `COMPOSER_WEIGHTS` are not retuned. SOUND find
(`reanchor.js`) is not taught and still never auto-commits a crowd.

**Persist.** `<userData>/lessons.json` — versioned, bounded, no text
fields, never a jsonl `lesson` type. Main reteaches after a pick and
broadcasts promoted lessons only.

---

## D33 — The war diary: named plays, not essays

Three walls people plant a flag on. The front door of each is locked.
This is the crack that actually exists in this ship.

1. **Isolated models cannot share a brain.** We cannot read a copilot's
   inner numbers, and dumping the notebook into a public chat box would
   leak the fighter. What syncs is a short closed list of named plays
   the fighter already flew. Copilots never see the diary. The captain
   and the house seat may.
2. **A model that grades its own homework drifts.** We do not retrain
   anyone. A diary line is written by code from what the table and the
   captain actually did — shape, agreement, move. A model cannot write
   one. Code stamps `held` only for the one case it can see without
   grading the answer: unknown on a split. A named human may later mark
   held or broke. Unsigned is refused.
3. **A small local model cannot wear the whole notebook.** The captain
   wears the playbook (a dozen short lines) plus a short carrier
   briefing, and a clipped copilot answer. It chooses. It does not
   re-read four novels. The local house seat still wears the passport
   boot block (D18). That is a different job.

A play's name is `shape-agreement-move` (for example
`communal-split-unknown`). No seat brand in the name — that would turn
a play into a favourite. No question, no reply, no essay in the file
(`<userData>/diary/diary.jsonl`).

This reverses the captain helmet of D29 (full passport boot block on
the stick). The stick now wears the diary. The house tab is unchanged.

A play is a packet (schema, name, residual, held/broke), not a vector.
Inner numbers are not a portable mind; we do not send them. A held
unknown that has stood at least twice, and more than it broke, may
fire without waking the local model. That firing is not recorded as
another hold — the play does not grade itself. Defer and verdict still
need the chair.

---

## D34 — The gate owns the screen: no page view mounts until this launch signs in; a profile that cannot open is quarantined, not re-died on

Two failures were found on a real Windows machine, one in the chrome and
one in the migration, and the second one had been hiding the first.

**The chrome failure (a native view over the sign-in card).** A browser
tab is a native `WebContentsView` composited ABOVE the window's HTML; it
wins every click and keystroke inside its bounds. Boot opened a tab the
moment the chrome loaded (`did-finish-load`), while the sign-in gate —
HTML, "Who is flying?" — was up. The result was a window that looked
alive: tabs, address bar, start page, all visible. And nothing in it
could be touched: the start page's native view sat over the gate card in
the centre, the gate overlay ate the clicks that stayed on the HTML, and
keyboard focus went into the page view. Tab did nothing. The operator
had to kill it.

The rule is now structural, in three layers, all fail-closed:

1. **No page view mounts before sign-in.** `TabManager` starts gated.
   `open()` refuses (returns null — nothing constructed, nothing added,
   nothing loaded), `restore()` restores nothing, and the first tabs come
   from `openInitialContent()` which runs on the `operator:signin`
   handshake, exactly once, resuming the saved session or opening the
   start page. `did-finish-load` no longer opens anything. The chrome's
   own `chrome:pageVisible` is refused by main while the launch is
   unsigned, so even a compromised renderer cannot raise a page over the
   gate.
2. **Layout parks hidden views.** While the page is hidden — gate up, or
   the table/memory/carrier pane showing — every view stays at 0x0 with
   `setVisible(false)`, including an unjudged background tab that would
   otherwise get a real box "for measuring". A real box is exactly a
   native lid over the chrome; measuring is only ever allowed when the
   page may actually be on screen.
3. **The chrome behind the gate is inert.** The gate's state class now
   means something: `body.gated` sets `pointer-events: none` on the
   strip, nav, body, dock and sheet, and the elements themselves are
   `inert` while gated — no click, no focus, no keystroke, no Tab. The
   gate input is focused for you; a name and Enter is the whole
   ceremony. When the gate leaves, focus lands in the address bar.

The default tab bounds are 0x0 as well: a page view must never show in a
hole the chrome has not reported yet (the old default of 1200×600 at
`x:0,y:96` covered the seat rail and the nav on any machine whose
viewport arrived late). The viewport is re-reported immediately before
the page is allowed to show, on the same IPC pipe, so main cannot reveal
a page in a stale hole.

A side rule this forced: an empty table must not be written while the
gate is up. "No tabs open" before sign-in is the gate, not a table that
was emptied on purpose — stamping `closedAll` then would have silently
killed session auto-resume on every gated launch.

**The migration failure (a profile that kills the app).** The profile
adoption (D26) MOVES the OmniBox tree into the Forge Flight folder —
including the Chromium storage an older Electron wrote. Usually the new
Chromium migrates it forward. On the machine in question it died inside
its own storage layer instead: IndexedDB schema errors for `claude.ai`,
`quota_database` resets, then a silent exit, on every launch of the
adopted folder. A fresh profile ran fine, which is how the operator
kept going. This was treated as a separate bug from the click-through,
and it had to be: the poisoned profile made every `npm start` die before
the gate could even be seen, which is also why the click-through bug
survived so long.

A process that dies inside Chromium cannot be caught by the app that
contains it, so the fix is a **boot watch** in `profile.js`, run before
Electron opens the folder:

- Only a folder a legacy sibling's note names as adopted is watched. A
  profile Forge Flight created itself is never armed, let alone
  quarantined.
- Each launch of an adopted profile writes a boot mark. A launch that
  ends well — graceful quit, or a page that actually loaded, or 90
  seconds past the window showing — clears it.
- Two launches in a row that end abnormally (crash, silent exit,
  task-kill: no clear) say the profile itself cannot open. The next
  launch MOVES the tree aside to a sibling `forgeflight.old` — nothing
  deleted, cookies and passport intact — rewrites the legacy note to
  say where it went, and starts fresh. The fresh folder is never
  mistaken for the adopted one again.

Two deaths, not one: a single crash (GPU fault, battery pull, a kill
from Task Manager) must not throw a working profile away, and the
adopted profile that cannot open will die every single time until it is
quarantined, so the second death costs one extra failed boot and buys
immunity from false positives. The watch is scoped by evidence: the
failing component is always Chromium's storage under an adopted tree,
never a tree Forge Flight itself wrote.

---

## Open, and deliberately not built

- **A real encoder.** `HashEncoder` is a labelled placeholder behind
  `(text) => Float64Array`.
- **Cross-origin frames.** Named and refused rather than reached into. See D8.
- **A closed shadow root.** Unreachable by construction; reported as such.
- **Byte-for-byte passport restore.** See D13 — a different operation on a
  different trust footing.
- **Rejecting one of several pending approvals** — inherited from the harness
  work, still a policy question rather than a bug.

---
