# The passport as a cognitive map — Neuralink, the neuroscience of mapping, and what D's vision already shares with both

Written 2026-08-27. This is research D asked for, not a build. The question
on the table, in D's words: the passport is meant to be "an AI version of a
cognitive mapping apparatus" — as much observable insight into how models
reason as can be captured "without being illegal," so that any model wearing
it gets sharper, and a thousand users' observations compound into Federation
intelligence that levels the field for people who cannot pay.

What follows: (1) what Neuralink actually is and where it stands, grounded
and cited; (2) the sixty-year neuroscience of cognitive mapping — which is
uncannily the passport's own architecture; (3) published AI work that
already validates pieces of the design; (4) the "invasive but lawful"
boundary for observing model behavior, and how this repo's existing rules
already sit on the right side of it; (5) what it implies for the build.

---

## 1. Neuralink, factually

Neuralink's stack, as of the public record:

- **N1 implant**: 1,024 electrodes on 64 flexible threads, threaded into
  cortex by the **R1 surgical robot**, battery inductive, fully internal.
- **Telepathy** (the motor product): first human implanted January 2024
  (Noland Arbaugh, who played chess with his mind); by late 2025 the public
  count was around nine patients, with the early **thread-retraction**
  problem (some electrodes pulled out of tissue in patient 1, degrading
  signal) reported addressed in later implants ([axis-intelligence.com](
  https://axis-intelligence.com/neuralink-beyond-first-human-updates/)).
- **Blindsight** (the vision product): FDA **Breakthrough Device
  designation** September 2024 ([wearable-technologies.com](
  https://wearable-technologies.com/news/neuralink-gets-fdas-breakthrough-device-designation));
  as of early 2026 Musk claimed readiness for the first blind human implant
  pending regulatory sign-off, which FDA had not publicly confirmed
  ([tesorb.com](https://tesorb.com/neuralink-blindsight-implant-2026/)).
  Treat 2026 dates as time-sensitive.
- **The scientific direction that matters for this document**: the field is
  converging on *foundation models trained on recorded activity* — BrainLM,
  self-supervised over 6,700 hours of fMRI ([biorxiv](
  https://www.biorxiv.org/content/10.1101/2023.09.12.557460v1)); NeuroLM,
  which tokenises EEG and trains an LLM over ~25,000 hours of signals
  ([arxiv.org/abs/2409.00101](https://arxiv.org/abs/2409.00101)). Neuralink
  itself has reported a self-supervised model over its own clinical neural
  recordings ("LMNet," mid-2025, per its public updates); this doc treats
  that as **unverified here** — the search set confirmed the trend, not that
  specific paper's numbers.

**The lesson D should take from Neuralink is not the hardware.** It is the
business model of the insight: an implant that observes the minimum
necessary signal, at scale, continuously — and whose value compounds as
more subjects join. That is the passport's thesis with "neurons" swapped
for "observable model behavior."

## 2. The cognitive mapping canon — the passport's architecture, discovered 60 years early

- **Tolman (1948)**: rats don't just learn stimulus→reward chains; they
  build **cognitive maps** — internal models of the territory that support
  detours and shortcuts never trained. The founding claim that *knowledge
  is a map, not a habit.*
- **O'Keefe (1971) place cells; O'Keefe & Nadel (1978)**: the hippocampus
  fires for *locations* — it is the map's index.
- **Moser & Moser (2005) grid cells**: entorhinal hexagonal firing — a
  coordinate system. (Nobel Prize 2014, O'Keefe + the Mosers.)
- **Hippocampal indexing theory (Teyler & DiScenna 1986)** — the one that
  should be framed and hung next to the passport's design: the hippocampus
  does NOT store content. It stores a **sparse index** of pointers; the
  cortex stores the content. Recall = index fires → cortex re-renders.
  *The passport (small, structured, session-scale) is the index; the
  Federation is the cortex. D built the split the theory says brains use.*
- **Complementary learning systems (McClelland, McNaughton, O'Reilly
  1995)**: fast, plastic hippocampus + slow, conservative neocortex, so new
  knowledge can be held *pending* without overwriting consolidated
  knowledge. That is exactly **provisional vs supported**: fast intake that
  does not touch the consolidated store until promotion (5 distinct
  witnesses) — the passport's C2 is CLS with different constants.
- **Replay and sharp-wave ripples**: offline, the hippocampus re-runs the
  day's traces and gradually transfers them to cortex. The engine's design
  already does this literally — record during runs, extract lessons
  *offline* under the unanimity gate, ship a new engine version. That is
  replay.
- **Reconsolidation (Nader et al. 2000)**: a recalled memory reopens and
  must re-stabilise; a stale memory can be updated or decay. The passport's
  `nextRecheckAt` cadence + drift decay (14-day half-life) is
  reconsolidation, scheduled.
- **Synaptic homeostasis (Tononi & Cirelli)**: sleep downsamples so the
  signal survives. The TrustGate and the exclusion audit are the passport's
  answer to the same problem: admitting everything would be epilepsy, not
  intelligence.

## 3. Published AI work that says this architecture is right

- **HippoRAG (NeurIPS 2024)** — explicitly "inspired by the hippocampal
  indexing theory"; LLM-extracted triples form a knowledge-graph index,
  Personalized PageRank plays the role of pattern completion. Single-step
  retrieval matched iterative methods at 10–20× lower cost
  ([neurips.cc](https://neurips.cc/virtual/2024/poster/94043)). Note what
  that endorses: *index-then-complete beats load-everything*, and triples —
  structured claims — are the index. The passport's equation form (D16,
  `capital(france) = paris`) is the same move: subject-predicate-object as
  the unit of memory.
- **Generative Agents (Park et al. 2023)**: memory streams scored by
  *recency × importance × relevance*. The TrustGate is this triad with the
  epistemics made strict (trust replaces raw importance; contested is a
  hard zero).
- **Voyager (Wang et al. 2023)**: a Minecraft agent with a **skill
  library** — verified skills become named, reusable tools that compound.
  That is D's capability-pack plan ("tools and skills he loaded up") with
  published precedent: *skills as accreting, inspectable library beats
  skills as ephemeral context*.

None of these is the passport — each takes one piece. The passport's whole
is: index (D16) + trust-gated admission (C3) + bi-temporal append-only
trail (D10/D17) + two-way portability that refuses to carry status (D13).

## 4. "As invasive as possible without being illegal" — the boundary, mapped

D's framing: record everything observable about how models reason — what
they do and don't do — without touching weights or anything proprietary.
The law's rough shape (orientation, **not legal advice**):

**Generally the right side of the line:**
- *Facts are not copyrightable* (Feist, US 1991). "Model X refused Y,"
  latency, which strategy a composer accepted, whether a reply settled —
  these are facts about D's own sessions, observed from his own client.
- *Observation is not trade-secret theft.* Trade-secret law (DTSA/UTSA)
  protects secrets taken by improper means; lawful observation of behavior
  from an interaction you're entitled to have is the classic defense, and
  independent derivation is lawful. hiQ v. LinkedIn (9th Cir.) also
  narrowed "unauthorized access" for publicly observable data.
- *Behavioral telemetry of one's own sessions* — what the anchors log
  records: descriptors, signals, outcomes, timings.

**The wrong side — which the repo already refuses:**
- Circumventing technical protection measures (DMCA §1201) — never break a
  paywall, rate-limit bypass, or anti-bot measure.
- Wholesale copying of *expression* — replies are copyrighted text;
  systematic republication of providers' expression at scale is a different
  legal universe from recording facts about behavior.
- Contract/ToS exposure: automated-access clauses are civil-contract
  territory; defensible, but the more "invasive," the more a courtroom
  would ask about agreed terms.

**The remarkable thing**: the pipe rule this repo already enforces —
anchors and outcomes only, prompts and replies stripped by name
(`src/main/anchors.js`) — is simultaneously the *privacy* rule (D's 8–10
hours of daily conversation never enters the store) and the *legal-safety*
rule (facts in, expression out). The clean pipe was designed for ethics and
turns out to be the lawful pipe. Keep it exactly as is.

**On humans in the Federation**: the neurorights wave is the analog —
California SB 1223 amended the CCPA to classify **neural data** as
sensitive personal information (2024), Colorado did similar, Chile
constitutionalised neurorights in 2021, and UNESCO moved a
neurotech-ethics recommendation in 2025
([calmatters.digitaldemocracy.org](https://calmatters.digitaldemocracy.org/bills/ca_202320240sb1223),
[insideprivacy.com](https://www.insideprivacy.com/uncategorized/california-enacts-health-ai-bill-and-protections-for-neural-data/)).
Direction of travel: the more a datum approaches "thought," the more the
law protects it. The Federation's two-pipe privacy split (facts
contribute-by-default; conversation local-by-default) should be designed to
*that* standard now, as D already ruled.

## 5. What it means for the build

1. **A seat is reserved for a local LLM in the cockpit** — D ruled it in
   this session. The whole point of the passport is that a small local
   model wearing the Federation holds its weight against the big accounts.
   Design note: it is a seat like any other (one per "host," human pacing,
   read-back verification) — the local seat just has zero-latency,
   offline, uncapped behavior, which also makes it the safest place to
   trial new instrumentation.
2. **The equation form is the index.** HippoRAG's result plus the indexing
   theory both say: make structured triples the unit, and retrieval becomes
   cheap pattern-completion. D16 is already that. The Federation should
   store equations, not prose.
3. **Consolidation is a scheduled job, not a live write.** The hippocampal
   metaphor gives the Federation's architecture: installs propose (index),
   the Federation consolidates offline under the unanimity/promotion gates
   (cortex), recheck cadence reopens drifters (reconsolidation). Nothing
   about that requires new law-breaking invasiveness — it requires exactly
   the clean pipe that exists.
4. **What compounding actually runs on.** D's thousand-user vision is
   sound *if and only if* the store fills with facts that generalize
   (anchor behavior, outcome patterns, equation-claims) rather than
   expression that doesn't (chat text). That is the same rule three ways —
   privacy, law, and learning-theory — and it is already the repo's rule.
5. **The local seat is built** (D18): `forgeflight://local`, a tab like any
   other tab, wearing the boot block as its helmet. Still queued: the
   two-way gate's pull protocol (`passport.search`-family) and the
   Federation's consolidation cycle.

---

*Time-sensitive items (Neuralink patient counts, Blindsight approval
status, LMNet specifics, legislation) are cited to their sources above and
will drift; the neuroscience canon and the case law are stable.*
