"use client";

import {
  Shield,
  ArrowRight,
  Upload,
  Database,
  Lock,
  Layers,
  Zap,
} from "lucide-react";

interface Props {
  onCreateClick: () => void;
  onImportClick: () => void;
}

export function LandingHero({ onCreateClick, onImportClick }: Props) {
  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <div className="text-center pt-12 pb-16">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-passport-500/10 border border-passport-500/20 text-passport-300 text-xs font-medium mb-8">
          <span className="h-1.5 w-1.5 rounded-full bg-passport-400 animate-pulse" />
          Universal AI Memory Standard
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.1] max-w-3xl mx-auto">
          Own Your
          <span className="bg-gradient-to-r from-passport-400 to-blue-400 bg-clip-text text-transparent">
            {" "}
            AI Memory
          </span>
        </h1>

        <p className="mt-6 text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
          One format. Any platform. Move your context, preferences, projects, and
          knowledge between AI systems without starting over.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onCreateClick}
            className="group flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-passport-600 to-passport-500 hover:from-passport-500 hover:to-passport-400 text-white font-semibold rounded-xl transition-all shadow-xl shadow-passport-600/25"
          >
            <Shield className="h-5 w-5" />
            Create Your Passport
            <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform" />
          </button>
          <button
            onClick={onImportClick}
            className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 text-white font-medium rounded-xl transition border border-white/10"
          >
            <Upload className="h-5 w-5" />
            Import .mpx File
          </button>
        </div>
      </div>

      {/* Feature grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pb-12">
        {[
          {
            icon: Database,
            title: "Memory Layers",
            desc: "Identity, preferences, projects, knowledge, and workflows in one portable file.",
          },
          {
            icon: Lock,
            title: "User-Owned",
            desc: "Your data. Not OpenAI's. Not Anthropic's. Not Google's. Yours.",
          },
          {
            icon: Layers,
            title: "Universal Format",
            desc: "Export as .mpx — the portable standard that works with any AI system.",
          },
          {
            icon: Zap,
            title: "Instant Context",
            desc: "Import into any AI and recover 90%+ of useful working context instantly.",
          },
        ].map((f) => (
          <div
            key={f.title}
            className="p-6 rounded-2xl bg-white/[0.03] border border-white/[0.06] hover:border-passport-500/20 hover:bg-white/[0.05] transition group"
          >
            <div className="h-10 w-10 rounded-xl bg-passport-500/10 flex items-center justify-center mb-4 group-hover:bg-passport-500/20 transition">
              <f.icon className="h-5 w-5 text-passport-400" />
            </div>
            <h3 className="font-semibold text-white mb-2">{f.title}</h3>
            <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>

      {/* Format preview */}
      <div className="max-w-2xl mx-auto pb-16">
        <div className="rounded-2xl bg-white/[0.03] border border-white/[0.06] overflow-hidden">
          <div className="px-4 py-3 border-b border-white/[0.06] flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="h-3 w-3 rounded-full bg-red-500/60" />
              <div className="h-3 w-3 rounded-full bg-yellow-500/60" />
              <div className="h-3 w-3 rounded-full bg-green-500/60" />
            </div>
            <span className="text-xs text-slate-500 font-mono ml-2">
              passport.mpx
            </span>
          </div>
          <pre className="p-4 text-sm text-slate-300 font-mono overflow-x-auto leading-relaxed">
            {`{
  "format": "memory-passport-exchange",
  "version": "1.0.0",
  "passport": {
    "identity": {
      "name": "Dwayne",
      "preferred_name": "Big Daddy",
      "timezone": "America/Chicago"
    },
    "preferences": {
      "response_style": "technical",
      "verbosity": "high",
      "coding_languages": ["typescript", "python"]
    }
  },
  "memories": [...]
}`}
          </pre>
        </div>
      </div>
    </div>
  );
}
