import type { CapabilityDescriptor, ToolCall } from './contracts.ts';
import { assertValid } from './schema.ts';

/**
 * THE EXECUTOR
 *
 * Before this file existed, `requestTool()` authorized a call and then returned.
 * Whoever held the actual tool made the actual call, and nothing structurally
 * required them to have asked first or to have honoured the answer. Every other
 * boundary in the harness was downstream of that, so authorization was advisory
 * by construction -- "the pilot cannot bypass this" was not provable at any
 * level of test coverage.
 *
 * The executor closes that. A tool implementation is registered HERE and
 * nowhere else. The only way to reach it is `execute()`, and `execute()` refuses
 * unless it is handed a grant that the harness itself issued for these exact
 * arguments. The pilot never receives the implementation, only a handle.
 *
 * The property this is built to make checkable:
 *
 *   No side effect occurs without a preceding grant whose argumentsDigest
 *   equals the digest of the arguments actually executed.
 *
 * That is mechanically verifiable by replaying the event spine. It is only
 * MEANINGFUL if the pilot has no second path to the tool, which is an
 * architectural property, not a test: the pilot process must hold no ambient
 * credentials and must not import tool modules directly. Assert that in CI as a
 * boundary check.
 */

export type ExecutionMode = 'execute' | 'dry_run';

export type ToolContext = {
  missionId: string;
  toolCallId: string;
  /** 'dry_run' means: describe what you WOULD do, change nothing. */
  mode: ExecutionMode;
  /** Set by the harness from the mission deadline, if any. */
  signal?: AbortSignal;
};

export type ToolImplementation = (
  args: Record<string, unknown>,
  context: ToolContext,
) => Promise<unknown>;

/**
 * A grant is a single-use, argument-bound permission to invoke one capability.
 * The harness mints it after authorization; the executor destroys it on use.
 * It is the only currency the executor accepts.
 */
export type ExecutionGrant = {
  readonly toolCallId: string;
  readonly missionId: string;
  readonly capabilityId: string;
  readonly argumentsDigest: string;
  readonly mode: ExecutionMode;
  readonly issuedAt: string;
};

export type ExecutionResult = {
  toolCallId: string;
  capabilityId: string;
  mode: ExecutionMode;
  status: 'succeeded' | 'failed';
  output?: unknown;
  error?: string;
  startedAt: string;
  finishedAt: string;
};

export class ExecutionRefused extends Error {
  readonly code = 'EXECUTION_REFUSED';
  constructor(reason: string) {
    super(`tool execution refused: ${reason}`);
    this.name = 'ExecutionRefused';
  }
}

export class ToolExecutor {
  private readonly implementations = new Map<string, ToolImplementation>();
  private readonly descriptors = new Map<string, CapabilityDescriptor>();
  /** Grants are single-use. Presence here means "not yet spent". */
  private readonly outstanding = new Map<string, ExecutionGrant>();

  register(descriptor: CapabilityDescriptor, implementation: ToolImplementation): void {
    if (this.implementations.has(descriptor.id)) {
      throw new Error(`tool already registered: ${descriptor.id}`);
    }
    this.implementations.set(descriptor.id, implementation);
    this.descriptors.set(descriptor.id, descriptor);
  }

  has(capabilityId: string): boolean {
    return this.implementations.has(capabilityId);
  }

  list(): string[] {
    return [...this.implementations.keys()].sort();
  }

  /**
   * Mint a grant. Only the harness runtime calls this, and only after
   * authorization has returned `allow` (or an approval has been recorded for
   * this exact tool call). The grant is bound to the digest, so an approval for
   * one set of arguments cannot be spent on another.
   */
  issue(grant: ExecutionGrant): ExecutionGrant {
    this.outstanding.set(grant.toolCallId, grant);
    return grant;
  }

  revoke(toolCallId: string): void {
    this.outstanding.delete(toolCallId);
  }

  /** Drop every outstanding grant for a mission. Used when a mission ends. */
  revokeMission(missionId: string): number {
    let revoked = 0;
    for (const [id, grant] of this.outstanding) {
      if (grant.missionId === missionId) {
        this.outstanding.delete(id);
        revoked += 1;
      }
    }
    return revoked;
  }

  outstandingFor(missionId: string): ExecutionGrant[] {
    return [...this.outstanding.values()].filter((grant) => grant.missionId === missionId);
  }

  /**
   * The single entry point to a real tool.
   *
   * Refuses -- before touching the implementation -- if the grant is missing,
   * already spent, for a different mission or capability, or bound to different
   * arguments than the ones presented.
   */
  async execute(
    toolCall: ToolCall,
    signal?: AbortSignal,
  ): Promise<ExecutionResult> {
    const grant = this.outstanding.get(toolCall.id);
    if (!grant) {
      throw new ExecutionRefused(
        `no outstanding grant for tool call ${toolCall.id}; a call must be authorized before it is made`,
      );
    }
    if (grant.missionId !== toolCall.missionId) {
      throw new ExecutionRefused('grant belongs to a different mission');
    }
    if (grant.capabilityId !== toolCall.capabilityId) {
      throw new ExecutionRefused('grant was issued for a different capability');
    }
    if (grant.argumentsDigest !== toolCall.argumentsDigest) {
      throw new ExecutionRefused(
        'arguments do not match the arguments that were authorized (time-of-approval / time-of-use)',
      );
    }

    const implementation = this.implementations.get(toolCall.capabilityId);
    const descriptor = this.descriptors.get(toolCall.capabilityId);
    if (!implementation || !descriptor) {
      throw new ExecutionRefused(`no tool is mounted for capability ${toolCall.capabilityId}`);
    }

    // Validate again at the boundary. requestTool() already checked, but the
    // executor must not trust an earlier layer for a property it can verify
    // itself immediately before the side effect.
    assertValid(descriptor.inputSchema, toolCall.arguments, `arguments for ${descriptor.id}`);

    if (grant.mode === 'dry_run' && descriptor.supportsDryRun === false) {
      throw new ExecutionRefused(`capability ${descriptor.id} cannot be simulated`);
    }

    // Spend the grant BEFORE running, so a throwing tool cannot be retried on
    // the same authorization.
    this.outstanding.delete(toolCall.id);

    const startedAt = new Date().toISOString();
    try {
      const output = await implementation(toolCall.arguments, {
        missionId: toolCall.missionId,
        toolCallId: toolCall.id,
        mode: grant.mode,
        signal,
      });
      return {
        toolCallId: toolCall.id,
        capabilityId: toolCall.capabilityId,
        mode: grant.mode,
        status: 'succeeded',
        output,
        startedAt,
        finishedAt: new Date().toISOString(),
      };
    } catch (error) {
      return {
        toolCallId: toolCall.id,
        capabilityId: toolCall.capabilityId,
        mode: grant.mode,
        status: 'failed',
        error: error instanceof Error ? error.message : String(error),
        startedAt,
        finishedAt: new Date().toISOString(),
      };
    }
  }
}

/**
 * What a pilot is given. It carries no registry, no implementation, and no
 * credentials -- only the ability to ask the harness for one named capability
 * on one mission. Handing a pilot anything richer than this reopens the hole
 * the executor exists to close.
 */
export type CapabilityHandle = {
  readonly capabilityId: string;
  readonly name: string;
  readonly description: string;
  readonly risk: CapabilityDescriptor['risk'];
  readonly inputSchema: Record<string, unknown>;
  invoke(args: Record<string, unknown>): Promise<ExecutionResult>;
};
