/**
 * index.js — the Memory Passport facade, and Forge Flight's reason for existing.
 *
 * Every reply that comes back to the table is a CANDIDATE memory, tagged with
 * the seat that produced it, the prompt that produced it, and when. Nothing
 * is promoted for being said; a claim needs five DISTINCT witnesses, and one
 * contradiction closes it.
 *
 * The cross-provider property Forge Flight has and a single chat does not: when
 * four seats are asked the same question at the same moment, agreement is
 * four distinct witnesses arriving together, and disagreement is a
 * contradiction that lands with both sides attached. That is contradiction
 * NOW, as distinct from contradiction over time.
 */

'use strict';

const path = require('node:path');
const { PassportStore } = require('./store.js');
const { WriteBoundary, WriteBoundaryError } = require('./writeBoundary.js');
const { TrustGate } = require('./trustGate.js');
const { HashEncoder, newId, nowIso } = require('./core.js');
const { renderBootBlock } = require('./format.js');

/** What an export declares itself to be. */
const EXPORT_SCHEMA = 'forgeflight.passport.v1';
/** What an import will accept. The OmniBox id stays: a passport carried out
 *  of OmniBox is the same shape and crosses the same translation (D13). */
const IMPORT_SCHEMAS = [EXPORT_SCHEMA, 'omnibox.passport.v1'];

class Passport {
  constructor(dir, opts = {}) {
    this.dir = dir;
    this.store = new PassportStore(dir).load();
    this.boundary = new WriteBoundary(this.store, opts);
    this.gate = new TrustGate(opts.trustGate);
    this.encoder = opts.encoder || new HashEncoder(256);
    this.embeddings = new Map(); // memoryId -> Float64Array
  }

  embOf(mem) {
    let e = this.embeddings.get(mem.id);
    if (!e) {
      e = this.encoder.encode(`${mem.title}\n${mem.content}`);
      this.embeddings.set(mem.id, e);
    }
    return e;
  }

  setEmbedding(memoryId, vec) {
    this.embeddings.set(memoryId, vec);
  }

  propose(payload, opts) {
    return this.boundary.propose(payload, opts);
  }

  contradict(payload, opts) {
    return this.boundary.contradict(payload, opts);
  }

  import(payload, opts) {
    return this.boundary.import(payload, opts);
  }

  rows() {
    const out = [];
    for (const mem of this.store.liveMemories()) {
      const claim = this.store.getClaim(mem.claimId);
      if (!claim) continue;
      out.push({ memory: mem, claim, emb: this.embOf(mem) });
    }
    return out;
  }

  /** The read shape: what a session is actually given, plus what it was NOT
   *  given and why. The exclusion audit is not diagnostics — it is half the
   *  product. A context window that quietly dropped something is the failure
   *  this whole store exists to prevent. */
  bootBlock(query, { tokenBudget = 1200, now, adjudicatedOnly = false } = {}) {
    const gate = adjudicatedOnly ? new TrustGate({ ...this.gate.config, adjudicatedOnly: true }) : this.gate;
    const result = gate.curate(this.encoder.encode(query), this.rows(), { tokenBudget, now });
    return { ...result, query, text: renderBootBlock(query, result) };
  }

  // ------------------------------------------------------------------ intake

  /**
   * Turn one seat's reply into a candidate memory. Deliberately conservative:
   * a reply is an OBSERVATION with the seat as its witness, at low confidence,
   * and it is never pinned and never adjudicated. It has to earn everything
   * else.
   */
  ingestReply({ seatName, host, prompt, text, runId, round, role, equation, at }) {
    const content = String(text || '').trim();
    if (!content) return null;
    const payload = {
      type: 'fact',
      title: clipLine(prompt, 120),
      content: clipLine(content, 2000),
      confidence: 0.4,
      tags: ['forgeflight', 'reply', role || 'answer'].filter(Boolean),
      metadata: {
        witness_kind: 'outcome',
        // The reference IS the witness identity. Two seats answering the same
        // prompt are two distinct witnesses; the same seat answering twice is
        // one. That falls out of C2's witness signature for free.
        reference: `seat:${host || seatName} run:${runId || 'manual'}${round ? ` round:${round}` : ''}`,
        seat: seatName,
        host: host || null,
        runId: runId || null,
        round: round || null,
        prompt: clipLine(prompt, 1000),
        // An equation NOMINATION — data, not truth. The boundary decides
        // whether it is clean and grounded; if not, the claim keeps prose
        // form and simply never merges (D16).
        ...(equation ? { equation } : {}),
      },
    };
    try {
      return this.boundary.propose(payload, { actor: `seat:${seatName}`, at });
    } catch (e) {
      // A refused intake is logged, never thrown at the UI — losing one
      // candidate memory must not take a run down with it.
      this.store.putEvent({
        id: newId('ev'),
        kind: 'intake_refused',
        note: e.message,
        actor: `seat:${seatName}`,
        createdAt: nowIso(at),
      });
      return null;
    }
  }

  /**
   * Cross-provider disagreement, recorded as such. When two seats answer the
   * same prompt with propositions that do not share a claim signature, that
   * is a disagreement HAPPENING NOW rather than drift over time. Recorded as
   * an event on both claims; it does not close either one, because "two
   * models phrased it differently" is not evidence that either is wrong.
   * Closing a claim stays a deliberate act.
   */
  recordDisagreement(runId, results) {
    const ok = results.filter((r) => r.ok && r.memory);
    if (ok.length < 2) return null;
    const byClaim = new Map();
    for (const r of ok) {
      const list = byClaim.get(r.memory.claim.id) || [];
      list.push(r);
      byClaim.set(r.memory.claim.id, list);
    }
    const stamp = nowIso();
    const agreement = Math.max(...[...byClaim.values()].map((v) => v.length));
    const event = {
      id: newId('ev'),
      kind: byClaim.size === 1 ? 'cross_agreement' : 'cross_disagreement',
      note:
        byClaim.size === 1
          ? `${ok.length} seats produced the same claim for run ${runId}`
          : `${byClaim.size} distinct claims across ${ok.length} seats for run ${runId}`,
      actor: 'forgeflight',
      runId,
      claims: [...byClaim.keys()],
      agreementCount: agreement,
      seatCount: ok.length,
      createdAt: stamp,
    };
    this.store.putEvent(event);
    return event;
  }

  // ------------------------------------------------------------ portability

  /**
   * A passport you can carry. The whole store, readable by a person, with
   * the claim state written down so an exported file explains itself.
   */
  export() {
    return {
      schema: EXPORT_SCHEMA,
      exportedAt: nowIso(),
      note:
        'Status and adjudication in this file are a RECORD, not an instruction. ' +
        'Importing it anywhere re-derives them from scratch: every memory arrives ' +
        'provisional, with no witnesses and no adjudication stamp.',
      // D17: the head of the hash chain over the trail this bundle was copied
      // from. Provenance, not authority — an importer cannot verify it against
      // its own store, and nothing on import trusts it.
      chain: { head: this.store.chain.head, chained: this.store.chain.chained, legacy: this.store.chain.legacy },
      claims: [...this.store.claims.values()],
      memories: this.store.liveMemories(),
      events: this.store.events,
    };
  }

  /**
   * Import is a TRANSLATION, not a restore.
   *
   * This is C4's whole point and the reason export/relabel/reimport does not
   * work: an incoming record is reduced to the fields a writer is allowed to
   * set, and everything privileged is left behind and REPORTED. You cannot
   * carry a `supported` status across a file boundary, whether you edited the
   * file or not.
   */
  importBundle(bundle, { actor = 'import', at } = {}) {
    if (!bundle || !IMPORT_SCHEMAS.includes(bundle.schema)) {
      return { ok: false, reason: 'not-a-passport', detail: 'That file is not a Forge Flight passport export.' };
    }
    const rows = Array.isArray(bundle.memories) ? bundle.memories : [];
    const dropped = new Set();
    const skipped = [];
    let imported = 0;

    // Claim state is the thing an attacker would edit, and it is the thing
    // that most obviously does not cross. Report it by name.
    for (const c of Array.isArray(bundle.claims) ? bundle.claims : []) {
      if (c && c.status && c.status !== 'provisional') dropped.add('status');
      if (c && Number(c.confirmationCount) > 0) dropped.add('confirmationCount');
      if (c && c.promotedAt) dropped.add('promotedAt');
    }

    // An equation travels as a RE-NOMINATION, never as identity. The claim's
    // equation in the file is a record of how it was reduced; on import it is
    // re-proposed and re-accepted against the prose (grounding included), so
    // an edited file cannot force a merge that the text does not support.
    const equationByClaim = new Map();
    for (const c of Array.isArray(bundle.claims) ? bundle.claims : []) {
      if (c && c.id && c.equation && typeof c.equation === 'object') equationByClaim.set(c.id, c.equation);
    }

    for (const m of rows) {
      for (const f of ['status', 'adjudicatedAt', 'adjudicatedDigest', 'pinned', 'id', 'claimId', 'origin']) {
        if (m && m[f] != null && m[f] !== false) dropped.add(f);
      }
      const meta = (m && m.metadata) || {};
      const nomination = equationByClaim.get(m && m.claimId);
      const payload = {
        type: m && m.type,
        title: m && m.title,
        content: m && m.content,
        confidence: typeof (m && m.confidence) === 'number' ? m.confidence : 0.4,
        tags: Array.isArray(m && m.tags) ? m.tags : [],
        scope: (m && m.scope) || 'global',
        metadata: {
          witness_kind: meta.witness_kind || meta.witnessKind || 'structural',
          reference: meta.reference || `imported:${(bundle.exportedAt || 'unknown').slice(0, 10)}`,
          derived_from: Array.isArray(meta.derived_from) ? meta.derived_from : [],
          importedFrom: bundle.exportedAt || null,
          ...(nomination ? { equation: nomination } : {}),
        },
      };
      try {
        this.boundary.import(payload, { actor, at });
        imported++;
      } catch (e) {
        skipped.push({ title: (m && m.title) || '(untitled)', reason: e.message });
      }
    }

    return {
      ok: true,
      imported,
      skipped,
      dropped: [...dropped],
      detail:
        `${imported} memories imported as provisional, with no witnesses and no adjudication.` +
        (dropped.size ? ` Left behind: ${[...dropped].join(', ')} — those cannot cross a file boundary.` : ''),
    };
  }

  stats() {
    return this.store.stats();
  }

  static defaultDir(app) {
    return path.join(app.getPath('userData'), 'passport');
  }
}

function clipLine(s, n) {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  return t.length <= n ? t : `${t.slice(0, n - 1)}…`;
}

module.exports = { Passport, WriteBoundaryError, EXPORT_SCHEMA, IMPORT_SCHEMAS };
