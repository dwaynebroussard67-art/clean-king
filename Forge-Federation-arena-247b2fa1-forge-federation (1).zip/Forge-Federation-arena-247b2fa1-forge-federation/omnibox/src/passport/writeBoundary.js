/**
 * writeBoundary.js — C4. The one path a memory can enter through.
 *
 * DECISION C4a (this port, logged rather than slipped in):
 * A payload carrying a privileged field is REJECTED, not silently stripped.
 *
 * The Python build strips-and-continues. A reviewer on that build argued for
 * reject, and the argument is right for the same reason the exclusion audit
 * exists on the read side: visibly absent, never quietly missing. A model
 * that puts `"status": "supported"` in a write should learn that it cannot,
 * not believe its write succeeded as specified. The specific attack this
 * closes is export-relabel-reimport: take a provisional memory out, edit the
 * status in the file, put it back. Stripping makes that a no-op the attacker
 * never sees; rejecting makes it an error.
 *
 * The forgiving case — a model that includes a stray field out of habit —
 * is handled by naming the offending field in the error, so the next attempt
 * is correct.
 */

'use strict';

const {
  MEMORY_TYPES,
  WITNESS_KINDS,
  PROMOTION_THRESHOLD,
  DEFAULT_RECHECK_DAYS,
  nowIso,
  daysFrom,
  newId,
  sha256,
  claimSignature,
  witnessSignature,
} = require('./core.js');
const { acceptEquation, equationSignature, renderEquation } = require('./equation.js');

const PRIVILEGED_FIELDS = [
  'adjudicatedAt',
  'adjudicated_at',
  'adjudicatedDigest',
  'adjudicated_digest',
  'status',
  'claimId',
  'claim_id',
  'pinned',
  'confirmationCount',
  'confirmation_count',
  'promotedAt',
  'promoted_at',
  'id',
];

class WriteBoundaryError extends Error {
  constructor(message, field) {
    super(message);
    this.name = 'WriteBoundaryError';
    this.field = field || null;
  }
}

class WriteBoundary {
  constructor(store, opts = {}) {
    this.store = store;
    this.driftDays = opts.driftDays ?? DEFAULT_RECHECK_DAYS;
    this.promotionThreshold = opts.promotionThreshold ?? PROMOTION_THRESHOLD;
  }

  /** @returns {object} the sanitized payload, or throws WriteBoundaryError. */
  validate(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      throw new WriteBoundaryError('A proposal must be a JSON object.');
    }

    for (const f of PRIVILEGED_FIELDS) {
      if (Object.prototype.hasOwnProperty.call(raw, f)) {
        throw new WriteBoundaryError(
          `"${f}" is set by the passport, never by a writer. Remove it and propose again.`,
          f
        );
      }
    }
    const metadata = raw.metadata;
    if (metadata && typeof metadata === 'object') {
      for (const f of PRIVILEGED_FIELDS) {
        if (Object.prototype.hasOwnProperty.call(metadata, f)) {
          throw new WriteBoundaryError(
            `"metadata.${f}" is a privileged field smuggled inside metadata. Remove it and propose again.`,
            `metadata.${f}`
          );
        }
      }
    }

    if (!MEMORY_TYPES.includes(raw.type)) {
      throw new WriteBoundaryError(`type must be one of ${MEMORY_TYPES.join(', ')} (got ${JSON.stringify(raw.type)}).`, 'type');
    }

    const title = String(raw.title || '').trim();
    const content = String(raw.content || '').trim();
    if (!title) throw new WriteBoundaryError('title is required.', 'title');
    if (!content) throw new WriteBoundaryError('content is required.', 'content');

    const confidence = Number(raw.confidence);
    if (!Number.isFinite(confidence) || confidence < 0 || confidence > 1) {
      throw new WriteBoundaryError('confidence must be a number in [0, 1].', 'confidence');
    }

    if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) {
      throw new WriteBoundaryError('a metadata object is required.', 'metadata');
    }
    const witnessKind = metadata.witness_kind ?? metadata.witnessKind;
    if (!WITNESS_KINDS.includes(witnessKind)) {
      throw new WriteBoundaryError(
        `metadata.witness_kind must be one of ${WITNESS_KINDS.join(', ')}.`,
        'metadata.witness_kind'
      );
    }
    const reference = String(metadata.reference || '').trim();
    if (!reference) {
      throw new WriteBoundaryError(
        'metadata.reference is required — a claim with no evidence pointer has no value.',
        'metadata.reference'
      );
    }
    const derivedFrom = metadata.derived_from ?? metadata.derivedFrom ?? [];
    if (!Array.isArray(derivedFrom)) {
      throw new WriteBoundaryError('metadata.derived_from must be a list of ids.', 'metadata.derived_from');
    }
    const tags = raw.tags ?? [];
    if (!Array.isArray(tags) || tags.some((t) => typeof t !== 'string')) {
      throw new WriteBoundaryError('tags must be a list of strings.', 'tags');
    }

    // ------------------------------------------------------------ equation
    // A writer may NOMINATE an equation (it is data, not privileged). Code
    // decides whether to accept it: shape here, grounding in acceptEquation.
    // A structurally malformed nomination is a bad payload and is refused
    // outright; a well-shaped nomination that does not ground in the prose
    // is simply not accepted, and the claim keeps its prose form.
    let equation = null;
    let equationRejected = null;
    const nomination = metadata.equation;
    if (nomination !== undefined) {
      if (!nomination || typeof nomination !== 'object' || Array.isArray(nomination)) {
        throw new WriteBoundaryError(
          'metadata.equation must be an object with subject, predicate, object.',
          'metadata.equation'
        );
      }
      const allowed = ['subject', 'predicate', 'object', 'units', 'time'];
      for (const k of Object.keys(nomination)) {
        if (!allowed.includes(k)) {
          throw new WriteBoundaryError(
            `metadata.equation.${k} is not an equation field. Allowed: ${allowed.join(', ')}.`,
            `metadata.equation.${k}`
          );
        }
      }
      for (const k of ['subject', 'predicate', 'object']) {
        if (typeof nomination[k] !== 'string' || !nomination[k].trim()) {
          throw new WriteBoundaryError(
            `metadata.equation.${k} is required and must be a non-empty string.`,
            `metadata.equation.${k}`
          );
        }
      }
      const verdict = acceptEquation(nomination, content);
      if (verdict.rejected) {
        equationRejected = verdict.reason;
      } else {
        equation = verdict;
      }
      delete metadata.equation; // the canonical form lives on the claim, not the memory
    }

    return {
      type: raw.type,
      title,
      content,
      confidence,
      tags: tags.slice(),
      scope: String(raw.scope || 'global'),
      metadata: {
        ...metadata,
        witness_kind: witnessKind,
        reference,
        derived_from: derivedFrom.slice(),
        ...(equation ? {} : equationRejected ? { equation_rejected: equationRejected } : {}),
      },
      ...(equation ? { equation } : {}),
    };
  }

  propose(raw, { actor = 'model', pin = false, at } = {}) {
    return this.ingest(this.validate(raw), { origin: 'local', isContradiction: false, actor, pin, at });
  }

  contradict(raw, { actor = 'model', at } = {}) {
    return this.ingest(this.validate(raw), { origin: 'local', isContradiction: true, actor, pin: false, at });
  }

  /** Import can never arrive pre-adjudicated. That is the whole of C4's
   *  export-relabel-reimport defence, and it is why import contributes no
   *  confirmation and no witness. */
  import(raw, { actor = 'import', at } = {}) {
    return this.ingest(this.validate(raw), { origin: 'imported', isContradiction: false, actor, pin: false, at });
  }

  ingest(clean, { origin, isContradiction, actor, pin, at }) {
    const stamp = nowIso(at);
    // Identity: an ACCEPTED equation signs conjunctively over its fields, so
    // every phrasing of one fact is one claim. Prose keeps the exact
    // signature it has always had — a claim that did not reduce cleanly is
    // never merged with anything (D16's soundness rule).
    const sig = clean.equation ? equationSignature(clean.equation, clean.scope) : claimSignature(clean.content, clean.scope);
    const wsig = witnessSignature(clean.metadata.witness_kind, clean.metadata.reference);

    let claim = this.store.getClaimBySignature(sig);

    if (!claim) {
      claim = {
        id: newId('claim'),
        signature: sig,
        questionText: clean.title,
        proposition: clean.content,
        scope: clean.scope,
        form: clean.equation ? 'equation' : 'prose',
        equation: clean.equation || null,
        status: 'provisional',
        confirmationCount: origin === 'imported' ? 0 : 1,
        contradictionCount: 0,
        witnessSignatures: origin === 'imported' ? [] : [wsig],
        validAt: stamp,
        invalidAt: null,
        supersededBy: null,
        derivedFrom: clean.metadata.derived_from.slice(),
        promotedAt: null,
        lastConfirmedAt: origin === 'imported' ? null : stamp,
        nextRecheckAt: daysFrom(stamp, this.driftDays),
        createdAt: stamp,
      };
      this.store.putClaim(claim);
    } else if (isContradiction) {
      // ONE contradiction CLOSES the claim. It does not decrement a tally.
      claim = {
        ...claim,
        contradictionCount: claim.contradictionCount + 1,
        status: 'contested',
        invalidAt: stamp,
      };
      this.store.putClaim(claim);
      this.store.putEvent({
        id: newId('ev'),
        kind: 'contradicted',
        claimId: claim.id,
        evidence: clean.metadata.reference,
        note: 'a single contradiction closed the claim',
        actor,
        createdAt: stamp,
      });
    } else if (claim.status === 'contested' || claim.status === 'invalidated') {
      // A confirmation does not reopen a closed claim; the caller must
      // supersede. The memory still attaches so the trail stays complete.
    } else if (origin !== 'imported') {
      if (!claim.witnessSignatures.includes(wsig)) {
        const witnesses = [...claim.witnessSignatures, wsig];
        claim = {
          ...claim,
          witnessSignatures: witnesses,
          confirmationCount: witnesses.length,
          lastConfirmedAt: stamp,
          nextRecheckAt: daysFrom(stamp, this.driftDays),
        };
        if (claim.confirmationCount >= this.promotionThreshold && claim.status === 'provisional') {
          claim.status = 'supported';
          claim.promotedAt = stamp;
          this.store.putEvent({
            id: newId('ev'),
            kind: 'promoted',
            claimId: claim.id,
            note: `reached ${this.promotionThreshold} distinct witnesses`,
            actor: 'system',
            createdAt: stamp,
          });
        }
        this.store.putClaim(claim);
        this.store.putEvent({
          id: newId('ev'),
          kind: 'confirmed',
          claimId: claim.id,
          evidence: clean.metadata.reference,
          actor,
          createdAt: stamp,
        });
      }
      // A duplicate witness bumps nothing. Five repetitions of one source are
      // one witness — C2, and the reason a model cannot promote itself.
    }

    const memory = {
      id: newId('mem'),
      claimId: claim.id,
      type: clean.type,
      title: clean.title,
      content: clean.content,
      confidence: clean.confidence,
      tags: clean.tags,
      metadata: clean.metadata,
      pinned: !!pin,
      origin,
      adjudicatedAt: null,
      adjudicatedDigest: null,
      createdAt: stamp,
      updatedAt: stamp,
      retiredAt: null,
    };
    this.store.putMemory(memory);
    this.store.putEvent({
      id: newId('ev'),
      kind: origin === 'imported' ? 'imported' : 'created',
      memoryId: memory.id,
      claimId: claim.id,
      toConfidence: memory.confidence,
      evidence: clean.metadata.reference,
      actor,
      createdAt: stamp,
    });

    return { memory, claim };
  }

  // ------------------------------------------------------------------ system
  // These are system paths. They are not reachable from a write, which is the
  // point: a model cannot stamp its own adjudication.

  adjudicate(memoryId, { actor = 'human', at } = {}) {
    const mem = this.store.getMemory(memoryId);
    if (!mem) throw new WriteBoundaryError(`Unknown memory ${memoryId}.`);
    const stamp = nowIso(at);
    const next = { ...mem, adjudicatedAt: stamp, adjudicatedDigest: sha256(mem.content), updatedAt: stamp };
    this.store.putMemory(next);
    this.store.putEvent({ id: newId('ev'), kind: 'adjudicated', memoryId, claimId: mem.claimId, actor, createdAt: stamp });
    return next;
  }

  revokeAdjudication(memoryId, { actor = 'human', at } = {}) {
    const mem = this.store.getMemory(memoryId);
    if (!mem) throw new WriteBoundaryError(`Unknown memory ${memoryId}.`);
    const stamp = nowIso(at);
    const next = { ...mem, adjudicatedAt: null, adjudicatedDigest: null, updatedAt: stamp };
    this.store.putMemory(next);
    this.store.putEvent({
      id: newId('ev'),
      kind: 'adjudication_revoked',
      memoryId,
      claimId: mem.claimId,
      actor,
      createdAt: stamp,
    });
    return next;
  }

  pin(memoryId, pinned = true, { actor = 'human', at } = {}) {
    const mem = this.store.getMemory(memoryId);
    if (!mem) throw new WriteBoundaryError(`Unknown memory ${memoryId}.`);
    const stamp = nowIso(at);
    const next = { ...mem, pinned: !!pinned, updatedAt: stamp };
    this.store.putMemory(next);
    this.store.putEvent({
      id: newId('ev'),
      kind: pinned ? 'pinned' : 'unpinned',
      memoryId,
      claimId: mem.claimId,
      actor,
      createdAt: stamp,
    });
    return next;
  }

  /** Soft retire only. C1: nothing auto-deletes, and nothing hard-deletes here. */
  retire(memoryId, { actor = 'human', at } = {}) {
    const mem = this.store.getMemory(memoryId);
    if (!mem) throw new WriteBoundaryError(`Unknown memory ${memoryId}.`);
    const stamp = nowIso(at);
    const next = { ...mem, retiredAt: stamp, updatedAt: stamp };
    this.store.putMemory(next);
    this.store.putEvent({ id: newId('ev'), kind: 'deleted', memoryId, claimId: mem.claimId, actor, createdAt: stamp });
    return next;
  }

  supersede(oldClaimId, newClaimId, { actor = 'human', at } = {}) {
    const oldClaim = this.store.getClaim(oldClaimId);
    if (!oldClaim) throw new WriteBoundaryError(`Unknown claim ${oldClaimId}.`);
    if (!this.store.getClaim(newClaimId)) throw new WriteBoundaryError(`Unknown claim ${newClaimId}.`);
    const stamp = nowIso(at);
    const next = { ...oldClaim, status: 'invalidated', invalidAt: stamp, supersededBy: newClaimId };
    this.store.putClaim(next);
    this.store.putEvent({
      id: newId('ev'),
      kind: 'superseded',
      claimId: oldClaimId,
      note: `superseded by ${newClaimId}`,
      actor,
      createdAt: stamp,
    });
    return next;
  }

  recheck(claimId, { actor = 'system', at } = {}) {
    const claim = this.store.getClaim(claimId);
    if (!claim) throw new WriteBoundaryError(`Unknown claim ${claimId}.`);
    const stamp = nowIso(at);
    // Resets the drift clock without touching counts — a recheck is not a
    // confirmation.
    const next = { ...claim, nextRecheckAt: daysFrom(stamp, this.driftDays) };
    this.store.putClaim(next);
    this.store.putEvent({ id: newId('ev'), kind: 'rechecked', claimId, actor, createdAt: stamp });
    return next;
  }
}

module.exports = { WriteBoundary, WriteBoundaryError, PRIVILEGED_FIELDS };
