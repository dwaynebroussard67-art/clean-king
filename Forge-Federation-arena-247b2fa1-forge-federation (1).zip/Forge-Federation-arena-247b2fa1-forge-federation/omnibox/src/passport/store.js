/**
 * store.js — append-only persistence, no native dependencies.
 *
 * The Passport's own data model is an append-only event trail with two
 * derived projections (claims, memories). That is a log, so this stores a
 * log: newline-delimited JSON, fsync-able, human-readable, greppable, and
 * trivially recoverable. A torn final line is dropped on load and reported
 * rather than crashing the app.
 *
 * The choice is deliberate. A native SQLite binding would need a rebuild
 * against Electron's ABI on every machine Forge Flight is installed on — the
 * single most common reason a hobby Electron app fails to start on someone
 * else's Windows box. Forge Flight installs with `npm install` and nothing else.
 * `node:sqlite` can be swapped in behind this interface later; the interface
 * is deliberately narrow for that reason.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { sha256 } = require('./core.js');

/** D17: the event trail is HASH-CHAINED. Every record carries `prev` (the
 *  hash of the line before it) and `hash` (of itself, including `prev`), so
 *  an after-the-fact edit, deletion, or insertion anywhere in the log breaks
 *  the chain at that line and is detectable by recomputation. Append-only
 *  was a discipline; this makes it a verifiable fact.
 *
 *  Legacy logs written before D17 have no chain fields. They load exactly as
 *  they always did; the chain starts at the first new line. A legacy line
 *  appearing AFTER a chained line is itself reported as a break. */
const CHAIN_GENESIS = '0'.repeat(64);

function chainHash(prev, rec) {
  // Hash the {op, data} body in construction order, prefixed by the previous
  // line's hash. Verification rebuilds the same body from the parsed line —
  // JSON.parse preserves the file's key order, and we always write in that
  // order — so any edit to data or prev changes the recomputed hash.
  const body = JSON.stringify({ op: rec.op, data: rec.data });
  return sha256(`${prev}\u0000${body}`);
}

class PassportStore {
  constructor(dir) {
    this.dir = dir;
    this.logPath = path.join(dir, 'passport.jsonl');
    this.claims = new Map(); // id -> claim
    this.bySignature = new Map(); // signature -> claim id
    this.memories = new Map(); // id -> memory
    this.events = [];
    this.corrupt = 0;
    this.loaded = false;
    this.head = CHAIN_GENESIS; // hash of the last chained line written
    this.chainLines = 0; // chained lines written by this instance
    this.chain = { head: CHAIN_GENESIS, chained: 0, legacy: 0, breaks: [] };
  }

  load() {
    fs.mkdirSync(this.dir, { recursive: true });
    if (fs.existsSync(this.logPath)) {
      const raw = fs.readFileSync(this.logPath, 'utf8');
      const lines = raw.split('\n');
      for (const line of lines) {
        const s = line.trim();
        if (!s) continue;
        let rec;
        try {
          rec = JSON.parse(s);
        } catch {
          this.corrupt++;
          continue;
        }
        this.apply(rec, { replay: true });
      }
      // Walk the chain after replay so a bad line cannot disturb the
      // projections — the store still loads; the chain REPORTS.
      this.chain = this.verify();
      this.head = this.chain.head;
    }
    this.loaded = true;
    return this;
  }

  /** The only write path to disk. Every line is chained to the last. */
  append(rec) {
    const prev = this.head;
    const hash = chainHash(prev, rec);
    const line = `${JSON.stringify({ op: rec.op, data: rec.data, prev, hash })}\n`;
    fs.mkdirSync(this.dir, { recursive: true });
    fs.appendFileSync(this.logPath, line, 'utf8');
    this.head = hash;
    this.chainLines++;
    this.apply(rec, { replay: false });
    return rec;
  }

  /** Recompute the chain over the file as it exists right now. Never throws;
   *  a tampered log is a finding to report, not a reason to refuse to look. */
  verify() {
    const out = { head: CHAIN_GENESIS, chained: 0, legacy: 0, breaks: [] };
    if (!fs.existsSync(this.logPath)) return out;
    const lines = fs.readFileSync(this.logPath, 'utf8').split('\n');
    let expectedPrev = null; // null until the first chained line: genesis
    let sawChained = false;
    let idx = 0;
    for (const line of lines) {
      idx++;
      const s = line.trim();
      if (!s) continue;
      let rec;
      try {
        rec = JSON.parse(s);
      } catch {
        out.breaks.push({ line: idx, kind: 'unparseable' });
        continue;
      }
      if (rec.hash === undefined && rec.prev === undefined) {
        if (sawChained) out.breaks.push({ line: idx, kind: 'legacy-after-chained' });
        else out.legacy++;
        continue;
      }
      sawChained = true;
      const wantPrev = expectedPrev === null ? CHAIN_GENESIS : expectedPrev;
      if (rec.prev !== wantPrev) {
        out.breaks.push({ line: idx, kind: 'prev-mismatch', expected: wantPrev, found: rec.prev });
      }
      const wantHash = chainHash(rec.prev === undefined ? wantPrev : rec.prev, rec);
      if (rec.hash !== wantHash) {
        out.breaks.push({ line: idx, kind: 'hash-mismatch', expected: wantHash, found: rec.hash });
      }
      out.chained++;
      expectedPrev = rec.hash;
      out.head = rec.hash;
    }
    return out;
  }

  apply(rec, { replay }) {
    switch (rec.op) {
      case 'claim':
        this.claims.set(rec.data.id, rec.data);
        this.bySignature.set(rec.data.signature, rec.data.id);
        break;
      case 'memory':
        this.memories.set(rec.data.id, rec.data);
        break;
      case 'event':
        this.events.push(rec.data);
        break;
      default:
        if (!replay) throw new Error(`unknown op ${rec.op}`);
        this.corrupt++;
    }
  }

  putClaim(claim) {
    return this.append({ op: 'claim', data: claim }).data;
  }

  putMemory(memory) {
    return this.append({ op: 'memory', data: memory }).data;
  }

  putEvent(event) {
    return this.append({ op: 'event', data: event }).data;
  }

  getClaim(id) {
    return this.claims.get(id) || null;
  }

  getClaimBySignature(sig) {
    const id = this.bySignature.get(sig);
    return id ? this.claims.get(id) || null : null;
  }

  getMemory(id) {
    return this.memories.get(id) || null;
  }

  liveMemories() {
    return [...this.memories.values()].filter((m) => !m.retiredAt);
  }

  eventsFor({ memoryId, claimId } = {}) {
    return this.events.filter(
      (e) => (memoryId ? e.memoryId === memoryId : true) && (claimId ? e.claimId === claimId : true)
    );
  }

  stats() {
    const byStatus = {};
    for (const c of this.claims.values()) byStatus[c.status] = (byStatus[c.status] || 0) + 1;
    return {
      claims: this.claims.size,
      memories: this.memories.size,
      live: this.liveMemories().length,
      events: this.events.length,
      byStatus,
      corruptLines: this.corrupt,
      logPath: this.logPath,
      bytes: fs.existsSync(this.logPath) ? fs.statSync(this.logPath).size : 0,
      // D17: the trail's integrity, as a fact rather than a hope.
      chain: {
        head: this.chain.head,
        chained: this.chain.chained,
        legacy: this.chain.legacy,
        breaks: this.chain.breaks.length,
      },
    };
  }
}

module.exports = { PassportStore, CHAIN_GENESIS, chainHash };
