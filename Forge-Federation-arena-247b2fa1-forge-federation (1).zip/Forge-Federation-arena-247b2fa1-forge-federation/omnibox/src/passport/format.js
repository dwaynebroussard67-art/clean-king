/**
 * format.js — the read shape.
 *
 * A boot block is the text a session is actually given. It always ends with
 * the exclusion audit, and the audit is not optional: a context window that
 * quietly dropped something is the exact failure this store exists to
 * prevent. Visibly absent, never quietly missing.
 */

'use strict';

const REASON_LABEL = {
  'low-confidence': 'below the confidence floor',
  budget: 'did not fit the token budget',
  contested: 'the claim is contested',
  invalidated: 'the claim has been invalidated',
  stale: 'past its recheck date and drifting',
  imported_unadjudicated: 'imported and not yet adjudicated',
};

function statusMark(claim) {
  switch (claim.status) {
    case 'supported':
      return 'supported';
    case 'provisional':
      return 'provisional';
    case 'contested':
      return 'contested';
    case 'invalidated':
      return 'invalidated';
    default:
      return claim.status;
  }
}

function renderBootBlock(query, result) {
  const lines = [];
  lines.push('=== MEMORY PASSPORT ===');
  lines.push(`query: ${query}`);
  lines.push(
    `admitted ${result.admitted.length} of ${result.admitted.length + result.excluded.length} · ` +
      `${result.tokensUsed}/${result.tokenBudget} tokens`
  );
  lines.push('');

  if (result.admitted.length === 0) {
    lines.push('(nothing in the passport cleared admission for this query)');
  }

  for (const a of result.admitted) {
    const m = a.memory;
    const tag = [
      statusMark(a.claim),
      `${a.claim.confirmationCount} witness${a.claim.confirmationCount === 1 ? '' : 'es'}`,
      a.pinned ? 'pinned' : `w=${a.weight.toFixed(3)}`,
      m.adjudicatedAt ? 'adjudicated' : null,
    ]
      .filter(Boolean)
      .join(' · ');
    lines.push(`- [${m.type}] ${m.title}`);
    lines.push(`  ${m.content}`);
    lines.push(`  (${tag}) evidence: ${m.metadata && m.metadata.reference ? m.metadata.reference : 'none'}`);
  }

  lines.push('');
  lines.push('--- not shown ---');
  if (result.excluded.length === 0) {
    lines.push('nothing was withheld.');
  } else {
    const byReason = new Map();
    for (const e of result.excluded) {
      const list = byReason.get(e.reason) || [];
      list.push(e);
      byReason.set(e.reason, list);
    }
    for (const [reason, items] of byReason) {
      lines.push(`${items.length} × ${REASON_LABEL[reason] || reason}:`);
      for (const it of items.slice(0, 6)) lines.push(`  · ${it.memory.title}`);
      if (items.length > 6) lines.push(`  · …and ${items.length - 6} more`);
    }
  }
  lines.push('');
  lines.push('status ceiling is `supported`. nothing here is asserted as simply true.');
  return lines.join('\n');
}

module.exports = { renderBootBlock, REASON_LABEL };
