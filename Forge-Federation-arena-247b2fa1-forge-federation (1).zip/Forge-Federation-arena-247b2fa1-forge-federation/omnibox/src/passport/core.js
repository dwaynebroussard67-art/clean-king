/**
 * core.js — identifiers, hashing, the closed vocabularies, and the encoder.
 *
 * Ported from the Python Memory Passport (docs/decisions C1–C4). The rules
 * that survive the port unchanged, because they are the point:
 *
 *   - `supported` is the status ceiling. There is no `settled`.
 *   - More witnesses make a claim cheaper to adjudicate, not more true.
 *   - One contradiction CLOSES a claim. It does not decrement a tally.
 *   - A model can never stamp its own adjudication.
 *   - Nothing auto-deletes.
 */

'use strict';

const crypto = require('node:crypto');

const CLAIM_STATUSES = ['provisional', 'supported', 'contested', 'invalidated'];
const MEMORY_TYPES = ['fact', 'preference', 'decision', 'rule'];
const WITNESS_KINDS = ['outcome', 'structural', 'contract', 'human'];
const MEMORY_ORIGINS = ['local', 'imported'];
const EXCLUSION_REASONS = ['low-confidence', 'budget', 'contested', 'invalidated', 'stale', 'imported_unadjudicated'];

const PROMOTION_THRESHOLD = 5;
const DEFAULT_RECHECK_DAYS = 30;

const nowIso = (d) => (d ? new Date(d) : new Date()).toISOString();
const parseIso = (s) => (s ? new Date(s) : null);
const daysFrom = (date, days) => new Date(new Date(date).getTime() + days * 86400000).toISOString();

function newId(prefix) {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

function sha256(s) {
  return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex');
}

const normalizeProposition = (t) => String(t || '').toLowerCase().split(/\s+/).filter(Boolean).join(' ');

/** C2: the counting unit. Title is presentation and is deliberately excluded —
 *  two memories stating the same proposition in the same scope are ONE claim
 *  even when their titles differ. */
function claimSignature(proposition, scope = 'global') {
  return sha256(`${String(scope).trim().toLowerCase()}|${normalizeProposition(proposition)}`);
}

/** C2: what makes a confirmation *distinct*. Five repetitions of the same
 *  witness are one witness — that is the whole defence against a model
 *  promoting a claim by saying it five times. */
function witnessSignature(witnessKind, reference) {
  return sha256(`${String(witnessKind).trim().toLowerCase()}|${String(reference).trim()}`);
}

// --------------------------------------------------------------------------
// Encoder
// --------------------------------------------------------------------------

/**
 * Deterministic feature-hashing encoder: unigrams + bigrams -> signed hash
 * buckets -> L2 normalize.
 *
 * This is a PLACEHOLDER and is labelled as one, exactly as the TypeScript
 * build labelled its own. It exists so the whole retrieval pipeline is
 * demonstrable and testable with no API key and no model download. Retrieval
 * quality numbers from this encoder describe the MECHANISM, not semantic
 * recall. Swap it for a real bi-encoder behind the same
 * `(text: string) => Float64Array` interface; nothing downstream assumes
 * anything beyond "unit vector, higher dot product = more related".
 */
class HashEncoder {
  constructor(dim = 256) {
    this.dim = dim;
  }

  tokens(text) {
    const words = String(text || '')
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, ' ')
      .split(/\s+/)
      .filter(Boolean);
    const out = words.slice();
    for (let i = 0; i + 1 < words.length; i++) out.push(`${words[i]}_${words[i + 1]}`);
    return out;
  }

  encode(text) {
    const v = new Float64Array(this.dim);
    for (const tok of this.tokens(text)) {
      const h = crypto.createHash('md5').update(tok).digest();
      const bucket = ((h[0] << 16) | (h[1] << 8) | h[2]) % this.dim;
      const sign = h[3] & 1 ? 1 : -1;
      v[bucket] += sign;
    }
    let norm = 0;
    for (let i = 0; i < this.dim; i++) norm += v[i] * v[i];
    norm = Math.sqrt(norm) || 1e-12;
    for (let i = 0; i < this.dim; i++) v[i] /= norm;
    return v;
  }
}

function dot(a, b) {
  const n = Math.min(a.length, b.length);
  let s = 0;
  for (let i = 0; i < n; i++) s += a[i] * b[i];
  return s;
}

module.exports = {
  CLAIM_STATUSES,
  MEMORY_TYPES,
  WITNESS_KINDS,
  MEMORY_ORIGINS,
  EXCLUSION_REASONS,
  PROMOTION_THRESHOLD,
  DEFAULT_RECHECK_DAYS,
  nowIso,
  parseIso,
  daysFrom,
  newId,
  sha256,
  normalizeProposition,
  claimSignature,
  witnessSignature,
  HashEncoder,
  dot,
};
