/**
 * trustGate.js — C3. Trust-weighted admission.
 *
 *   logit_i  = (q · k_i) / τ  +  log(TrustGate_i + ε)
 *   weight_i = softmax(logit_i)   over the eligible shortlist
 *
 * τ = 0.10, NOT √d. That correction matters and is the reason this file
 * carries a note instead of a constant: Vaswani's √d_k scaling exists to
 * normalize the variance of a dot product between vectors whose *components*
 * have unit variance. Once q and k are L2-normalized, q·k = cosθ ∈ [-1,1]
 * already has a fixed small range, and dividing it by √768 ≈ 27.7 squashes
 * the semantic term to ±0.036 while log(TrustGate) still swings over several
 * units — so trust would dominate unconditionally rather than appropriately.
 * A tuned temperature (CLIP-style, ~0.05–0.1) is the right structural fix.
 *
 * This is a retrieval-time heuristic that runs BEFORE anything reaches a
 * context window. It does not touch, and cannot touch, any model's weights.
 */

'use strict';

const { PROMOTION_THRESHOLD, parseIso, sha256, dot } = require('./core.js');

const CONFIG = {
  temperature: 0.1,
  epsilon: 1e-6,
  promoteThreshold: PROMOTION_THRESHOLD,
  driftHalfLifeDays: 14, // a starting constant, not a settled one
  staleCutoff: 0.25,
  lowConfidenceCutoff: 0.2,

  // Adjudication trust. Note the ordering, which is deliberate and easy to
  // read as a typo: a DIGEST MISMATCH (0.50) scores LOWER than NEVER
  // ADJUDICATED (0.55). A claim that was verified once and then silently
  // changed under its stamp is more suspicious than one never verified.
  tAdjMatch: 1.0,
  tAdjMismatch: 0.5,
  tAdjUnadjudicated: 0.55,

  tSuppProvBase: 0.2,
  tSuppProvSpan: 0.4,
  tSuppProvCap: 0.8,

  confFloor: 0.05,
  tokenCostPerChar: 0.25,
  minTokens: 10,
  shortlistSize: 50,
  adjudicatedOnly: false,
};

const driftLambda = (cfg) => Math.log(2) / cfg.driftHalfLifeDays;

function estimateTokens(mem, cfg) {
  const n = mem.title.length + 1 + mem.content.length;
  return Math.max(cfg.minTokens, Math.ceil(n * cfg.tokenCostPerChar));
}

function stableSoftmax(logits) {
  const max = Math.max(...logits);
  const exp = logits.map((l) => Math.exp(l - max));
  const sum = exp.reduce((a, b) => a + b, 0) || 1;
  return exp.map((e) => e / sum);
}

class TrustGate {
  constructor(config = {}) {
    this.config = { ...CONFIG, ...config };
  }

  /** Multiplicative over fields already in the schema. A hard exclude returns
   *  0 and never enters the softmax — an excluded memory does not steal
   *  probability mass from an admitted one. */
  evaluate(mem, claim, now = new Date()) {
    const cfg = this.config;
    const zero = (reason, detail, partial = {}) => ({
      trustGate: 0,
      tStatus: 0,
      tAdj: 0,
      tSupp: 0,
      tDrift: 0,
      tConf: 0,
      ...partial,
      excludeReason: reason,
      detail,
    });

    if (claim.status === 'contested' || claim.status === 'invalidated') {
      return zero(claim.status, `Gated by ${claim.status}`);
    }

    if (mem.origin === 'imported' && cfg.adjudicatedOnly && !mem.adjudicatedAt) {
      // Scoped to the caller's opt-in, not applied unconditionally — an
      // unadjudicated import is a weighting question, not a boundary one.
      return zero('imported_unadjudicated', 'Imported and unadjudicated (adjudicated-only context)');
    }

    const tStatus = 1;

    let tAdj;
    if (mem.adjudicatedAt) {
      tAdj = mem.adjudicatedDigest === sha256(mem.content) ? cfg.tAdjMatch : cfg.tAdjMismatch;
    } else {
      tAdj = cfg.tAdjUnadjudicated;
    }

    let tSupp;
    if (claim.status === 'supported') {
      tSupp = Math.min(claim.confirmationCount / cfg.promoteThreshold, 1);
    } else if (claim.status === 'provisional') {
      const frac = Math.min(claim.confirmationCount / cfg.promoteThreshold, cfg.tSuppProvCap);
      tSupp = cfg.tSuppProvBase + cfg.tSuppProvSpan * frac;
    } else {
      tSupp = 0;
    }

    const recheck = parseIso(claim.nextRecheckAt);
    let tDrift = 1;
    if (recheck) {
      const deltaDays = (now.getTime() - recheck.getTime()) / 86400000;
      tDrift = deltaDays <= 0 ? 1 : Math.exp(-driftLambda(cfg) * deltaDays);
    }
    if (tDrift < cfg.staleCutoff && !mem.pinned) {
      return zero('stale', `Gated by stale (drift=${tDrift.toFixed(3)})`, { tStatus, tAdj, tSupp, tDrift });
    }

    const tConf = Math.max(cfg.confFloor, Math.min(Number(mem.confidence), 1));
    if (tConf < cfg.lowConfidenceCutoff && !mem.pinned) {
      return zero('low-confidence', 'Gated by low-confidence', { tStatus, tAdj, tSupp, tDrift, tConf });
    }

    return {
      trustGate: tStatus * tAdj * tSupp * tDrift * tConf,
      tStatus,
      tAdj,
      tSupp,
      tDrift,
      tConf,
      excludeReason: null,
      detail: '',
    };
  }

  logits(sims, gates) {
    const cfg = this.config;
    return sims.map((s, i) => s / cfg.temperature + Math.log(gates[i] + cfg.epsilon));
  }

  /**
   * @param {Float64Array} queryEmb
   * @param {Array<{memory:object, claim:object, emb:Float64Array}>} rows
   * @param {{tokenBudget?:number, now?:Date, shortlistSize?:number}} opts
   */
  curate(queryEmb, rows, opts = {}) {
    const cfg = this.config;
    const now = opts.now || new Date();
    const tokenBudget = opts.tokenBudget ?? 2048;
    if (rows.length === 0) {
      return { admitted: [], excluded: [], tokensUsed: 0, tokenBudget, weights: {} };
    }

    const sims = rows.map((r) => dot(queryEmb, r.emb));

    // Stage 1 — shortlist by raw similarity. Exact search is the shortlist at
    // passport scale; the parameter exists so an ANN index can slot in later.
    const k = Math.min(opts.shortlistSize ?? cfg.shortlistSize, rows.length);
    const order = rows.map((_, i) => i).sort((a, b) => sims[b] - sims[a]);
    const shortlisted = new Set(order.slice(0, k));
    // Pinned always makes the shortlist, so reservation cannot lose it.
    rows.forEach((r, i) => {
      if (r.memory.pinned) shortlisted.add(i);
    });

    const admitted = [];
    const excluded = [];
    const candidates = [];
    let tokensUsed = 0;

    rows.forEach((row, i) => {
      const { memory: mem, claim } = row;
      const ev = this.evaluate(mem, claim, now);
      const toks = estimateTokens(mem, cfg);

      if (!shortlisted.has(i) && !mem.pinned) {
        excluded.push({ memory: mem, claim, reason: 'budget', detail: 'Not in the shortlist', similarity: sims[i] });
        return;
      }

      if (mem.pinned) {
        // Pinned survives budget — unless the claim is contested or
        // invalidated, which pinning cannot override.
        if (ev.excludeReason === 'contested' || ev.excludeReason === 'invalidated') {
          excluded.push({
            memory: mem,
            claim,
            reason: ev.excludeReason,
            detail: `Pinned blocked: claim ${ev.excludeReason}`,
            similarity: sims[i],
          });
        } else {
          tokensUsed += toks;
          admitted.push({
            memory: mem,
            claim,
            weight: 1,
            similarity: sims[i],
            trustGate: ev.trustGate > 0 ? ev.trustGate : 1,
            tokens: toks,
            pinned: true,
          });
        }
        return;
      }

      if (ev.excludeReason) {
        excluded.push({ memory: mem, claim, reason: ev.excludeReason, detail: ev.detail, similarity: sims[i] });
      } else {
        candidates.push({ i, memory: mem, claim, similarity: sims[i], trustGate: ev.trustGate, tokens: toks });
      }
    });

    const weights = {};
    for (const a of admitted) weights[a.memory.id] = a.weight;

    if (candidates.length) {
      const logits = this.logits(
        candidates.map((c) => c.similarity),
        candidates.map((c) => c.trustGate)
      );
      const w = stableSoftmax(logits);
      const ranked = candidates.map((c, idx) => ({ ...c, weight: w[idx] })).sort((a, b) => b.weight - a.weight);
      for (const c of ranked) {
        weights[c.memory.id] = c.weight;
        if (tokensUsed + c.tokens <= tokenBudget) {
          tokensUsed += c.tokens;
          admitted.push({
            memory: c.memory,
            claim: c.claim,
            weight: c.weight,
            similarity: c.similarity,
            trustGate: c.trustGate,
            tokens: c.tokens,
            pinned: false,
          });
        } else {
          excluded.push({
            memory: c.memory,
            claim: c.claim,
            reason: 'budget',
            detail: `Budget full (${tokenBudget - tokensUsed} tokens remaining)`,
            similarity: c.similarity,
          });
        }
      }
    }

    const pinned = admitted.filter((a) => a.pinned);
    const rest = admitted.filter((a) => !a.pinned).sort((a, b) => b.weight - a.weight);

    return { admitted: [...pinned, ...rest], excluded, tokensUsed, tokenBudget, weights };
  }
}

module.exports = { TrustGate, CONFIG, estimateTokens, stableSoftmax };
