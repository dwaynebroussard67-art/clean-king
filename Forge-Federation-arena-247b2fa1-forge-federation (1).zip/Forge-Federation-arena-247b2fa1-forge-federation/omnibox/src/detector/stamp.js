/**
 * stamp.js — the engine's join key, built where the DOM is.
 *
 * The re-anchor engine cannot see a page; Forge Flight can. A stamp is a
 * structured, runtime-derivable descriptor of an element: identity fields,
 * a structural path, a bounding box, and the named signals the engine's
 * discriminator consumes. It is what "the anchor descriptor, in the engine's
 * own stamp format" means on this side of the boundary — every field is
 * recomputable from the page by anyone, which is the whole point.
 *
 * `stabilityKey` identifies the anchor ACROSS loads for before/after pairs:
 * it hashes identity + structural path and deliberately excludes the
 * bounding box and the signal scores, because a composer that moved or a
 * score that drifted is the SAME anchor observed twice — that is the
 * observation, not a different anchor.
 *
 * What is deliberately absent: any text a human typed or a model wrote.
 * Element identity and layout only. The oracle store stays clean by never
 * being given anything else to carry.
 */

'use strict';

/* eslint-disable no-undef */

/** Parent that crosses a shadow boundary (root -> host) and a same-origin
 *  frame boundary (document -> the <iframe> holding it). */
function parentOf(el) {
  if (!el) return null;
  if (el.parentElement) return el.parentElement;
  const root = el.parentNode;
  if (root && root.host) return root.host;
  const doc = el.ownerDocument;
  if (el === (doc && doc.documentElement)) {
    try {
      return (doc.defaultView && doc.defaultView.frameElement) || null;
    } catch {
      return null;
    }
  }
  return null;
}

/** tag:nth-of-tag path, bounded in depth. A refactored layout changes the
 *  path; identical layouts on two loads produce identical paths. */
function structuralPath(el, maxDepth = 8) {
  const parts = [];
  let n = el;
  let hops = 0;
  while (n && n.nodeType === 1 && hops < maxDepth) {
    const tag = (n.tagName || '').toLowerCase();
    if (tag === 'html' || tag === 'body') break;
    let idx = '';
    const p = parentOf(n);
    if (p && p.children) {
      let i = 0;
      let found = 0;
      for (const sib of p.children) {
        if ((sib.tagName || '').toLowerCase() === tag) {
          i++;
          if (sib === n) {
            found = i;
            break;
          }
        }
      }
      if (found > 0) idx = `:${found}`;
    }
    parts.unshift(tag + idx);
    n = p;
    hops++;
  }
  return `body>${parts.join('>')}`;
}

/** djb2-xor, hex. A comparison key, not a cryptographic signature: it exists
 *  so two stamps of the same anchor compare equal without carrying the whole
 *  descriptor around. */
function hash32(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
  return h.toString(16).padStart(8, '0');
}

function attr(el, name) {
  try {
    const v = el.getAttribute && el.getAttribute(name);
    return v == null ? null : String(v).slice(0, 120);
  } catch {
    return null;
  }
}

/**
 * @param {Element} el
 * @param {object} [extra] spread last — typically { score, signals }.
 */
function stampOf(el, extra = {}) {
  if (!el) return null;
  const tag = (el.tagName || '').toLowerCase();
  const role = attr(el, 'role');
  const type = attr(el, 'type');
  const id = attr(el, 'id');
  const name = attr(el, 'name');
  const testid = attr(el, 'data-testid') || attr(el, 'data-test-id');
  const ariaLabel = attr(el, 'aria-label');
  const placeholder = attr(el, 'placeholder') || attr(el, 'data-placeholder');
  const path = structuralPath(el);

  const editableKind =
    tag === 'textarea'
      ? 'textarea'
      : tag === 'input'
        ? 'input'
        : attr(el, 'contenteditable') || el.isContentEditable
          ? 'contenteditable'
          : role === 'textbox'
            ? 'role-textbox'
            : 'other';

  let classes = null;
  try {
    if (el.classList && el.classList.length) classes = [...el.classList].slice(0, 8).join(' ');
  } catch {
    classes = null;
  }

  let box = null;
  try {
    const r = el.getBoundingClientRect();
    box = { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) };
  } catch {
    box = null;
  }

  const stabilityKey = hash32(
    [tag, editableKind, role, type, id, name, testid, ariaLabel, placeholder, path].join('|')
  );

  return {
    tag,
    editableKind,
    role,
    type,
    id,
    name,
    testid,
    ariaLabel,
    placeholder,
    classes,
    path,
    box,
    stabilityKey,
    ...extra,
  };
}

const API = { stampOf, structuralPath, hash32 };

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_STAMP__ = API;
