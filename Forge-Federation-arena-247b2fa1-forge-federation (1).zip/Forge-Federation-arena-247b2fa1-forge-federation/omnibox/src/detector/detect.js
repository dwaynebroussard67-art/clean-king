/**
 * detect.js — soundness-first seat detection.
 *
 * The one law: Forge Flight would rather visibly refuse a page than quietly type
 * into the wrong box. Every other AI-fan-out tool on the market ships a list
 * of CSS selectors per provider and breaks silently the week a provider ships
 * a redesign. This file has no provider names in it and no selector list.
 * It identifies the composer structurally, and when the structure is
 * ambiguous it says so and hands the user a way to resolve it.
 *
 * Contract:
 *   detectComposer(doc, opts) -> Verdict
 *
 *   Verdict =
 *     | { ok: true,  composer, send|null, confidence, margin, signals, runnerUp }
 *     | { ok: false, reason: 'no-candidates' | 'ambiguous' | 'below-floor',
 *         candidates: [...], detail }
 *
 * `ok:false` is a first-class, expected outcome — not an error. The seat rail
 * renders it, names the tied candidates, and offers manual pick. A refusal is
 * a product surface, not a failure path.
 */

'use strict';

/* eslint-disable no-undef */
const S =
  typeof module !== 'undefined' && module.exports
    ? require('./signals.js')
    : globalThis.__FORGEFLIGHT_SIGNALS__;
const STAMP =
  typeof module !== 'undefined' && module.exports
    ? require('./stamp.js')
    : globalThis.__FORGEFLIGHT_STAMP__;
const REANCHOR =
  typeof module !== 'undefined' && module.exports
    ? require('./reanchor.js')
    : globalThis.__FORGEFLIGHT_REANCHOR__;
const TEACHER =
  typeof module !== 'undefined' && module.exports
    ? require('../field-evidence/teacher.js')
    : globalThis.__FORGEFLIGHT_TEACHER__;

// --------------------------------------------------------------------------
// Tunables. Named, with the reason for the value written next to it —
// the Passport's constants.ts posture, applied here.
// --------------------------------------------------------------------------

const CONFIG = {
  // A winner must beat the runner-up by this much aggregate score. Below it,
  // we refuse. Chosen so that two genuinely different elements (a real
  // composer and a header search box) separate comfortably, while two
  // near-identical editables (the ambiguous case we must refuse) do not.
  MIN_MARGIN: 0.12,

  // A winner must also clear this floor in absolute terms. Prevents "best of
  // a bad lot" on a page with no composer at all.
  MIN_SCORE: 0.42,

  // Boxes smaller than this are chrome, not a composer.
  MIN_AREA_PX: 900, // e.g. 60x15

  // How far down the viewport counts as "bottom".
  BOTTOM_BAND: 0.45,

  // A send control must be within this many DOM hops of the composer.
  SEND_MAX_HOPS: 6,
};

// --------------------------------------------------------------------------
// Shadow DOM.
//
// `document.querySelectorAll` does not pierce a shadow root, so a chat built
// as a web component is invisible to an ordinary query — the detector sees an
// empty page and honestly reports "no candidates" while the composer is right
// there on screen. Everything below walks open shadow roots as if they were
// part of the document, and treats a shadow host as the parent of its root so
// ancestry, hop counts and anchoring all still work across the boundary.
//
// A CLOSED shadow root cannot be entered by anyone, including us. That page
// gets `no-candidates`, which is the truthful answer.
// --------------------------------------------------------------------------

const SHADOW_WALK_CAP = 4000;

/** The document inside a same-origin iframe, or null if we cannot reach it.
 *  A cross-origin frame throws here, and that throw is the honest answer:
 *  nothing in this process may look inside it. */
function sameOriginDoc(iframe) {
  try {
    const d = iframe.contentDocument;
    return d && d.body ? d : null;
  } catch {
    return null;
  }
}

/** True if the page embeds a frame we are not allowed to look into. */
function hasUnreachableFrame(root) {
  const frames = root.querySelectorAll ? root.querySelectorAll('iframe, frame') : [];
  for (const f of frames) {
    const box = boxOf(f);
    if (box.width * box.height < 40000) continue; // a tracking pixel is not a chat
    if (!sameOriginDoc(f)) return true;
  }
  return false;
}

/** Every element in the document, in every open shadow root under it, and in
 *  every same-origin iframe inside it. */
function deepQueryAll(root, selector) {
  const out = [];
  const stack = [root];
  let visited = 0;
  while (stack.length) {
    const node = stack.pop();
    if (!node || !node.querySelectorAll) continue;
    for (const el of node.querySelectorAll(selector)) out.push(el);
    for (const el of node.querySelectorAll('*')) {
      if (++visited > SHADOW_WALK_CAP) return out;
      if (el.shadowRoot) stack.push(el.shadowRoot);
      const tag = el.tagName && el.tagName.toLowerCase();
      if (tag === 'iframe' || tag === 'frame') {
        const d = sameOriginDoc(el);
        if (d) stack.push(d);
      }
    }
  }
  return out;
}

/** Parent that crosses a shadow boundary (root -> host) and a same-origin
 *  frame boundary (document -> the <iframe> that holds it). */
function parentOf(el) {
  if (!el) return null;
  if (el.parentElement) return el.parentElement;
  const root = el.parentNode;
  if (root && root.host) return root.host;
  const doc = el.ownerDocument;
  if (el === (doc && doc.documentElement)) {
    try {
      return (doc.defaultView && doc.defaultView.frameElement) || null;
    } catch {
      return null;
    }
  }
  return null;
}

/** `closest`, but it climbs out of shadow roots instead of stopping at them. */
function closestDeep(el, selector) {
  let n = el;
  let hops = 0;
  while (n && hops < 40) {
    if (n.matches && n.matches(selector)) return n;
    n = parentOf(n);
    hops++;
  }
  return null;
}

// --------------------------------------------------------------------------
// Gates — a candidate that fails any of these is not a candidate at all.
// --------------------------------------------------------------------------

function isEditable(el) {
  const tag = (el.tagName || '').toLowerCase();
  if (tag === 'textarea') return !el.disabled && !el.readOnly;
  if (tag === 'input') {
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    return ['text', 'search', 'url', 'email', ''].includes(t) && !el.disabled && !el.readOnly;
  }
  const ce = el.getAttribute && el.getAttribute('contenteditable');
  if (ce === '' || ce === 'true' || ce === 'plaintext-only') return true;
  if (el.isContentEditable) return true;
  return false;
}

function boxOf(el) {
  try {
    const r = el.getBoundingClientRect();
    return { x: r.x, y: r.y, width: r.width, height: r.height, top: r.top, bottom: r.bottom };
  } catch {
    return { x: 0, y: 0, width: 0, height: 0, top: 0, bottom: 0 };
  }
}

function isVisible(el, box) {
  if (!box || box.width <= 0 || box.height <= 0) return false;
  const win = el.ownerDocument && el.ownerDocument.defaultView;
  if (!win || !win.getComputedStyle) return true;
  const cs = win.getComputedStyle(el);
  if (!cs) return true;
  if (cs.display === 'none' || cs.visibility === 'hidden') return false;
  if (parseFloat(cs.opacity || '1') < 0.05) return false;
  if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false;
  return true;
}

/**
 * anchored — the single best lexicon-free discriminator between a chat
 * composer and a comment box, and the reason the article fixture is refused.
 *
 * A chat composer does not scroll away with the conversation. It is either
 * position:fixed / sticky, or it sits OUTSIDE the scroll container that holds
 * the thread. A comment box, a review field, a profile bio — all of them live
 * *inside* the document's own scrolling flow and scroll off the screen.
 *
 * Walking up from the element, the first of these three we meet decides it:
 *   fixed/sticky ancestor        -> anchored (1)
 *   scrollable ancestor          -> scrolls with content (0)
 *   root, and the page scrolls   -> scrolls with content (0)
 *   root, and the page does not  -> anchored (1)
 */
function anchoredScore(el) {
  const doc = el.ownerDocument;
  const win = doc.defaultView;
  if (!win || !win.getComputedStyle) return 0.5; // unknown, not evidence either way

  let n = el;
  let hops = 0;
  while (n && n.tagName && hops < 14) {
    const tag = n.tagName.toLowerCase();
    if (tag === 'body' || tag === 'html') break;
    const cs = win.getComputedStyle(n);
    if (cs) {
      if (cs.position === 'fixed' || cs.position === 'sticky') return 1;
      const oy = cs.overflowY;
      const scrollable = oy === 'auto' || oy === 'scroll' || oy === 'overlay';
      if (scrollable && n.scrollHeight > n.clientHeight + 4) return 0;
    }
    n = parentOf(n);
    hops++;
  }

  const de = doc.documentElement;
  const pageScrolls = de && de.scrollHeight > (win.innerHeight || de.clientHeight) + 4;
  return pageScrolls ? 0 : 1;
}

/** Walk up looking for a container that means "this is chrome, not content". */
function chromeAncestry(el) {
  let n = el;
  let hops = 0;
  const found = [];
  while (n && n.tagName && hops < 12) {
    const tag = n.tagName.toLowerCase();
    const role = (n.getAttribute && n.getAttribute('role')) || '';
    if (['header', 'nav', 'aside', 'footer'].includes(tag)) found.push(tag);
    if (['search', 'navigation', 'banner', 'complementary'].includes(role)) found.push(role);
    if (n.getAttribute && n.getAttribute('data-forgeflight-chrome') != null) found.push('forgeflight');
    n = parentOf(n);
    hops++;
  }
  return found;
}

// --------------------------------------------------------------------------
// Composer scoring
// --------------------------------------------------------------------------

function scoreComposer(el, ctx) {
  const box = boxOf(el);
  const label = S.labelText(el);
  const tag = (el.tagName || '').toLowerCase();
  // An element inside a same-origin frame is laid out against THAT frame's
  // viewport. Scoring it against the top window's would put a perfectly
  // ordinary composer in the wrong place on every geometric signal.
  const ownWin = el.ownerDocument && el.ownerDocument.defaultView;
  const vpH = (ownWin && ownWin.innerHeight) || ctx.viewportHeight || 800;
  const vpW = (ownWin && ownWin.innerWidth) || ctx.viewportWidth || 1280;

  const askHits = S.matchesAny(label, S.ASK_INTENT);
  const searchHits = S.matchesAny(label, S.SEARCH_INTENT);

  // askIntent — the page named its own purpose.
  const askIntent = S.hitScore(askHits);

  // viewportBottom — 1.0 at the very bottom, tapering to 0 above the band.
  const vh = vpH || 1;
  const centerY = box.top + box.height / 2;
  const rel = centerY / vh;
  const viewportBottom =
    rel <= 1 - CONFIG.BOTTOM_BAND ? 0 : S.clamp01((rel - (1 - CONFIG.BOTTOM_BAND)) / CONFIG.BOTTOM_BAND);

  // area — relative to the largest editable found, so it is scale-free.
  const area = ctx.maxArea > 0 ? S.clamp01((box.width * box.height) / ctx.maxArea) : 0;

  // sendAffinity — is there a send-shaped control nearby? Computed later and
  // injected, because it needs the button pass to have run.
  const sendAffinity = Number.isFinite(ctx.sendAffinity && ctx.sendAffinity.get(el))
    ? ctx.sendAffinity.get(el)
    : 0;

  // centrality — wide relative to viewport and roughly centered.
  const vw = vpW || 1;
  const widthShare = S.clamp01(box.width / vw);
  const cx = box.x + box.width / 2;
  const offCenter = Math.abs(cx - vw / 2) / (vw / 2 || 1);
  const centrality = S.clamp01(widthShare * (1 - S.clamp01(offCenter)));

  // multiline
  const multiline =
    tag === 'textarea' ||
    el.getAttribute?.('aria-multiline') === 'true' ||
    (tag === 'div' && isEditable(el))
      ? 1
      : 0;

  // notChrome
  const chrome = chromeAncestry(el);
  const notChrome = chrome.length === 0 ? 1 : 0;

  // notSearch
  const typeAttr = (el.getAttribute?.('type') || '').toLowerCase();
  const roleAttr = (el.getAttribute?.('role') || '').toLowerCase();
  const searchy =
    typeAttr === 'search' ||
    roleAttr === 'searchbox' ||
    (el.getAttribute?.('name') || '').toLowerCase() === 'q' ||
    searchHits > 0;
  const notSearch = searchy ? 0 : 1;

  // notDocument — a comment box, review field or profile bio is not a seat.
  const docHits = S.matchesAny(label, S.DOCUMENT_INTENT);
  const notDocument = docHits > 0 ? 0 : 1;

  const anchored = anchoredScore(el);

  const signals = {
    askIntent,
    anchored,
    viewportBottom,
    area,
    sendAffinity,
    centrality,
    multiline,
    notChrome,
    notSearch,
    notDocument,
  };

  return {
    el,
    box,
    label,
    signals,
    score: S.aggregate(signals, S.COMPOSER_WEIGHTS),
  };
}

// --------------------------------------------------------------------------
// Send-control scoring
// --------------------------------------------------------------------------

function hopsBetween(a, b) {
  // Distance from `b` up to the nearest common ancestor with `a`.
  const chain = new Map();
  let n = a;
  let d = 0;
  while (n && d < 30) {
    chain.set(n, d);
    n = parentOf(n);
    d++;
  }
  let m = b;
  let e = 0;
  while (m && e < 30) {
    if (chain.has(m)) return chain.get(m) + e;
    m = parentOf(m);
    e++;
  }
  return Infinity;
}

function candidateButtons(doc) {
  const out = [];
  const nodes = deepQueryAll(
    doc,
    'button, [role="button"], input[type="submit"], input[type="button"], a[href="#"]'
  );
  for (const el of nodes) {
    const box = boxOf(el);
    if (!isVisible(el, box)) continue;
    if (el.disabled && el.getAttribute('data-forgeflight-allow-disabled') == null) {
      // Keep disabled buttons — a send button is usually disabled until the
      // composer holds text, and that is a *positive* signal, not a reason
      // to skip it. Recorded explicitly so the behaviour is not accidental.
      out.push({ el, box, initiallyDisabled: true });
      continue;
    }
    out.push({ el, box, initiallyDisabled: false });
  }
  return out;
}

function scoreSend(btn, composerEl, ctx) {
  const { el, box } = btn;
  const text = S.buttonText(el);

  const sendIntent = S.hitScore(S.matchesAny(text, S.SEND_INTENT));
  const stopHits = S.matchesAny(text, S.STOP_INTENT);
  const notStop = stopHits > 0 ? 0 : 1;

  const hops = hopsBetween(composerEl, el);
  const proximity = Number.isFinite(hops)
    ? S.clamp01(1 - hops / (CONFIG.SEND_MAX_HOPS * 2))
    : 0;

  const tag = (el.tagName || '').toLowerCase();
  const typeAttr = (el.getAttribute?.('type') || '').toLowerCase();
  const submitShape = tag === 'button' || typeAttr === 'submit' || el.getAttribute?.('role') === 'button' ? 1 : 0;

  const cmpBox = boxOf(composerEl);
  const trailing = box.x >= cmpBox.x || box.top >= cmpBox.top ? 1 : 0;

  const aspect = box.height > 0 ? box.width / box.height : 99;
  const iconOnly = aspect > 0.6 && aspect < 1.8 && box.width < 80 ? 1 : 0;

  const signals = { sendIntent, proximity, submitShape, trailing, notStop, iconOnly };

  // Hard gate: too far away is not a send button for THIS composer.
  if (hops > CONFIG.SEND_MAX_HOPS) {
    return { el, box, signals, score: 0, rejected: 'too-far' };
  }

  return { el, box, signals, score: S.aggregate(signals, S.SEND_WEIGHTS) };
}

// --------------------------------------------------------------------------
// The pass
// --------------------------------------------------------------------------

function collectEditables(doc) {
  const out = [];
  const nodes = deepQueryAll(
    doc,
    'textarea, input, [contenteditable], [contenteditable="true"], [contenteditable="plaintext-only"], [role="textbox"]'
  );
  for (const el of nodes) {
    if (closestDeep(el, '[data-forgeflight-chrome]')) continue;
    if (!isEditable(el)) continue;
    const box = boxOf(el);
    if (!isVisible(el, box)) continue;
    if (box.width * box.height < CONFIG.MIN_AREA_PX) continue;
    // A contenteditable that contains another contenteditable is a wrapper.
    if (deepQueryAll(el, '[contenteditable="true"], textarea').length > 0) continue;
    out.push(el);
  }
  return out;
}

/**
 * @param {Document} doc
 * @param {{viewportWidth?:number, viewportHeight?:number, config?:object}} [opts]
 */
function detectComposer(doc, opts = {}) {
  const cfg = { ...CONFIG, ...(opts.config || {}) };
  const win = doc.defaultView || { innerWidth: 1280, innerHeight: 800 };
  const ctx = {
    viewportWidth: opts.viewportWidth || win.innerWidth || 1280,
    viewportHeight: opts.viewportHeight || win.innerHeight || 800,
    maxArea: 0,
    sendAffinity: new Map(),
  };

  const editables = collectEditables(doc);
  if (editables.length === 0) {
    if (hasUnreachableFrame(doc)) {
      return {
        ok: false,
        reason: 'cross-origin-frame',
        candidates: [],
        detail:
          'The content on this page is inside a frame from another site, which Forge Flight is not allowed to read. ' +
          'Open that chat in its own tab and it will seat itself.',
      };
    }
    return {
      ok: false,
      reason: 'no-candidates',
      candidates: [],
      detail: 'No visible editable element large enough to be a composer.',
    };
  }

  for (const el of editables) {
    const b = boxOf(el);
    ctx.maxArea = Math.max(ctx.maxArea, b.width * b.height);
  }

  // Pass 1 — provisional composer scores with sendAffinity unset, so we can
  // find the buttons that belong to each candidate.
  const buttons = candidateButtons(doc);
  for (const el of editables) {
    let best = 0;
    for (const btn of buttons) {
      const s = scoreSend(btn, el, ctx);
      if (s.score > best) best = s.score;
    }
    ctx.sendAffinity.set(el, best);
  }

  // Pass 2 — real scores.
  const allScored = editables.map((el) => scoreComposer(el, ctx)).sort((a, b) => b.score - a.score);

  /**
   * The conjunctive rule.
   *
   * A weighted mean is the wrong shape for the comment-box case: a comment
   * field on an article is a big multiline editable, near a send-shaped
   * button, wide, centred, low on the page — seven signals near maximum. It
   * fails on exactly the two that matter, and three zeros out of ten do not
   * sink a mean. Raising the floor to compensate would be tuning to a fixture.
   *
   * So `anchored` and the two label signals combine instead of averaging:
   *
   *   An editable that SCROLLS AWAY WITH THE DOCUMENT must be positively
   *   identified as a message field — labelled as one, and not labelled as
   *   something else.
   *
   * Failing that is not a low score, it is a different kind of thing. A real
   * chat has to fail on two independent axes at once to be dropped here: an
   * unanchored composer still passes if the page calls it a message box, and
   * an unlabelled composer still passes if it is anchored.
   */
  const isDocumentField = (c) =>
    c.signals.anchored <= 0.5 && (c.signals.askIntent === 0 || c.signals.notDocument === 0);

  const scored = allScored.filter((c) => !isDocumentField(c));

  /** A described candidate carries its stamp: identity fields, structural
   *  path, stability key — the join key for engine-training records. This is
   *  additive; scoring and verdicts change not at all. */
  const describe = (c) => ({
    ...STAMP.stampOf(c.el),
    label: c.label.slice(0, 80),
    score: Number(c.score.toFixed(4)),
    signals: Object.fromEntries(Object.entries(c.signals).map(([k, v]) => [k, Number(Number(v).toFixed(3))])),
    box: c.box,
  });

  if (scored.length === 0) {
    return {
      ok: false,
      reason: 'document-field',
      candidates: allScored.slice(0, 4).map(describe),
      detail:
        'The editable boxes on this page scroll away with the document and none is labelled as a message field. ' +
        'That is a comment box or a form, not a conversation.',
    };
  }

  let winner = scored[0];
  let runnerUp = scored[1] || null;
  let margin = runnerUp ? winner.score - runnerUp.score : 1;
  let lessonApplied = null;

  if (winner.score < cfg.MIN_SCORE) {
    return {
      ok: false,
      reason: 'below-floor',
      candidates: scored.slice(0, 4).map(describe),
      detail: `Best candidate scored ${winner.score.toFixed(3)}, floor is ${cfg.MIN_SCORE}. This page does not look like a chat surface.`,
    };
  }

  if (runnerUp && margin < cfg.MIN_MARGIN) {
    // The tie-breaking signals, named — this is what makes the refusal useful.
    const tiedOn = Object.keys(S.COMPOSER_WEIGHTS).filter(
      (k) => Math.abs((winner.signals[k] || 0) - (runnerUp.signals[k] || 0)) < 0.05
    );
    // A promoted lesson may break this tie, and only this tie. Provisional
    // lessons stay in the notebook. A miss leaves the ordinary refusal standing.
    let taught = null;
    try {
      taught =
        TEACHER && typeof TEACHER.applyLesson === 'function'
          ? TEACHER.applyLesson(scored, tiedOn, opts.lessons || [], {
              minMargin: cfg.MIN_MARGIN,
              minScore: cfg.MIN_SCORE,
            })
          : null;
    } catch {
      taught = null;
    }
    if (taught && taught.winner && taught.winner.score >= cfg.MIN_SCORE) {
      winner = taught.winner;
      runnerUp = scored.find((c) => c !== winner) || null;
      margin = taught.margin;
      lessonApplied = { discriminator: taught.lesson.discriminator, tiedOn };
    } else {
      return {
        ok: false,
        reason: 'ambiguous',
        candidates: scored.slice(0, 4).map(describe),
        tiedOn,
        margin: Number(margin.toFixed(4)),
        detail: `Two editable regions scored within ${margin.toFixed(3)} of each other (floor ${cfg.MIN_MARGIN}); they tie on ${tiedOn.join(', ') || 'no single signal'}. Forge Flight will not guess which one is the composer.`,
      };
    }
  }

  // Bind the send control to the winning composer.
  const sends = buttons
    .map((btn) => scoreSend(btn, winner.el, ctx))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);
  const send = sends[0] && sends[0].score >= 0.35 ? sends[0] : null;

  const sendBit = send
    ? 'Composer identified with a bound send control.'
    : 'Composer identified; no send control found — will submit with Enter.';
  const detail = lessonApplied
    ? `${sendBit} A lesson on ${lessonApplied.discriminator} broke a tie on ${lessonApplied.tiedOn.join(', ') || 'signals'}.`
    : sendBit;

  return {
    ok: true,
    composer: winner.el,
    send: send ? send.el : null,
    sendScore: send ? Number(send.score.toFixed(4)) : 0,
    sendSignals: send ? send.signals : null,
    confidence: Number(winner.score.toFixed(4)),
    margin: Number(margin.toFixed(4)),
    signals: winner.signals,
    runnerUp: runnerUp ? describe(runnerUp) : null,
    // Every candidate that was scored, winners and losers alike — a correct
    // choice with a close runner-up is exactly the case a lesson is made of,
    // and that data was always computed and always discarded.
    candidates: scored.slice(0, 4).map(describe),
    lessonApplied,
    detail,
  };
}

/**
 * Find the element a person picked on a previous load.
 *
 * A remembered pick is a stability key (see stamp.js): identity fields plus
 * structural path, hashed. Recomputing the stamp of every current composer
 * candidate and comparing keys is the whole replay — there is no selector to
 * cache, no nth-child to go stale, and nothing stored about the page except
 * the one key the human's click produced.
 *
 * The search space is `collectEditables`, the same set detection scores, so a
 * replay can only ever land on an element that is right now visible, editable
 * and large enough to be a composer. A key that matches nothing returns null,
 * and the caller leaves the ordinary verdict standing: remembering an answer
 * is never a licence to guess.
 *
 * @param {Document} doc
 * @param {string} stabilityKey
 * @returns {Element|null}
 */
function findEditableByStamp(doc, stabilityKey) {
  const key = typeof stabilityKey === 'string' ? stabilityKey.toLowerCase() : '';
  if (!/^[0-9a-f]{1,16}$/.test(key)) return null;
  for (const el of collectEditables(doc)) {
    let s = null;
    try {
      s = STAMP.stampOf(el);
    } catch {
      continue;
    }
    if (s && s.stabilityKey === key) return el;
  }
  return null;
}

/**
 * Re-find a composer after the page moved. The engine commits only on a
 * unique badge, unique strong id, or unique text. A miss is null — the
 * caller leaves the ordinary verdict standing. suggest() is never used.
 *
 * @param {Document} doc
 * @param {object} fp  capture() fingerprint, in memory this load
 * @returns {Element|null}
 */
function reanchorEditable(doc, fp) {
  if (!REANCHOR || !fp || !doc) return null;
  let hit = null;
  try {
    hit = REANCHOR.reanchor(fp, doc);
  } catch {
    return null;
  }
  if (!hit) return null;
  try {
    if (!isEditable(hit)) return null;
  } catch {
    return null;
  }
  return hit;
}

const API = {
  detectComposer,
  findEditableByStamp,
  reanchorEditable,
  CONFIG,
  isEditable,
  isVisible,
  scoreComposer,
  scoreSend,
  collectEditables,
  deepQueryAll,
  parentOf,
  closestDeep,
  sameOriginDoc,
  hasUnreachableFrame,
};

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_DETECT__ = API;
