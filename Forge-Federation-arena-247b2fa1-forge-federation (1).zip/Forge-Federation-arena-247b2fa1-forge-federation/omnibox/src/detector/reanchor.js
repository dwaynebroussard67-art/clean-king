'use strict';
// forge-reanchor v8.0.0 — three-tier SOUND find: badge, strong id, text uniqueness.
//
// TIER 1: injected badge data-frg-id — unique by construction
// TIER 2: strong app id (id/data-id/data-testid/name) — committed ONLY if unique in doc
// TIER 3: text uniqueness — same tag + same NORMALIZED text, committed ONLY if unique in doc
// Collidable signals (class/href/src/STRUCTURE) are NEVER committed on. Wrong grabs = 0 by design.
//
// v8 vs v7:
//  - REMOVED the structural tag+index path entirely. It caused wrong grabs under M11
//    child-rotation (a path walks to the wrong element). It was dead code in sound-v7 but
//    a re-arm risk (the header used to advertise it). Soundness > coverage.
//  - Tier-3 text is bidi-normalized: strips RTL/LRE/PDF/isolate marks that i18n/RTL
//    mutations inject, so a mutation that only WRAPS text no longer breaks a unique match.
//  - Tier-3 length guard relaxed (>0). The unique-match check is the safety, not the length:
//    short text that collides simply isn't unique -> safe miss, never a wrong grab.
//
// This file is the engine, given as a copy. Forge Flight uses it to re-find an
// element after the page moves. find() is the only commit. suggest() is a
// hint and is never auto-applied.

const VERSION = 'v8.0.0';
const OWN_PREFIX = 'frg-';
const STRONG = ['id', 'data-id', 'data-testid', 'name'];
const WEAK = ['href', 'src', 'alt', 'aria-label'];

function uid() {
  return OWN_PREFIX + Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10);
}
function eachDeep(s, fn) {
  (function w(n) {
    if (!n) return;
    if (n.nodeType === 1) {
      fn(n);
      if (n.shadowRoot) w(n.shadowRoot);
    }
    for (const c of n.children || n.childNodes || []) if (c.nodeType === 1) w(c);
  })(s.documentElement || s);
}

// Comparison-only normalizer: strip bidi/directional control chars + collapse whitespace.
// Does NOT change what the engine commits on — Tier-3 still requires an exactly-unique match.
const BIDI = /[\u202A-\u202E\u2066-\u2069\u200E\u200F\u061C]/g;
function normalizeText(s) {
  return (s || '')
    .replace(BIDI, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
}

function reseal(el, id) {
  if (!el || !id) return;
  if (el.getAttribute('data-frg-id') !== id) el.setAttribute('data-frg-id', id);
  const cur = el.getAttribute('id') || '';
  // Mirror the badge onto id only when the element had none, or when the
  // current id IS the badge we minted. A page id that merely starts with
  // `frg-` is the page's, not ours — overwriting it is a collision, not a stamp.
  if (!cur || cur === id) el.setAttribute('id', id);
  // deliberately NOT mirrored into class — frameworks clone class onto siblings, defeating soundness.
}
function stamp(el) {
  if (!el) return;
  let id = el.getAttribute('data-frg-id');
  if (!id) {
    id = uid();
    el.setAttribute('data-frg-id', id);
  }
  reseal(el, id);
  return id;
}

function capture(el) {
  if (!el) return null;
  // ownId is the injected badge only. A page that happened to name an
  // element `frg-…` is not ours, and is not a commit signal by prefix.
  const ownId = el.getAttribute('data-frg-id') || null;
  const strong = {},
    weak = {};
  for (const k of STRONG) {
    const v = el.getAttribute(k);
    if (!v) continue;
    if (k === 'id' && v === ownId) continue; // our mirror, not the page's id
    strong[k] = v;
  }
  for (const k of WEAK) {
    const v = el.getAttribute(k);
    if (v) weak[k] = v;
  }
  const text = normalizeText(el.textContent);
  const tag = (el.tagName || '').toLowerCase();
  return { ownId, strong, weak, text, tag, _version: VERSION };
}

function badgeMatch(el, id) {
  if (!id) return false;
  if (el.getAttribute('data-frg-id') === id) return true;
  return (el.getAttribute('id') || '') === id;
}

// ============================================================
// SOUND CORE. Commit only on a unique-in-document signal.
// ============================================================
function find(fp, scope) {
  if (!fp || !scope) return null;
  // TIER 1: badge (unique by construction)
  if (fp.ownId) {
    let hit = null;
    eachDeep(scope, (el) => {
      if (!hit && badgeMatch(el, fp.ownId)) hit = el;
    });
    if (hit) return hit;
  }
  // TIER 2: a strong app id, but ONLY if exactly one element in the doc bears it
  const keys = Object.keys(fp.strong || {});
  if (keys.length) {
    const matched = [];
    eachDeep(scope, (el) => {
      for (const k of keys) {
        if (el.getAttribute(k) === fp.strong[k]) {
          matched.push(el);
          break;
        }
      }
    });
    if (matched.length === 1) return matched[0]; // unique -> safe to commit
  }
  // TIER 3: text uniqueness — same tag, same NORMALIZED text, only if unique in doc
  if (fp.tag && fp.text && fp.text.length > 0) {
    const matched = [];
    eachDeep(scope, function (el) {
      if ((el.tagName || '').toLowerCase() === fp.tag) {
        if (normalizeText(el.textContent) === fp.text) matched.push(el);
      }
    });
    if (matched.length === 1) return matched[0];
  }
  return null; // gone or ambiguous -> fail safe
}

function reanchor(fp, scope) {
  const el = find(fp, scope);
  if (el && fp.ownId) reseal(el, fp.ownId);
  return el;
}

// UNCONFIRMED suggestion (badge AND strong id gone). Weak/text signals. NEVER auto-commit.
function suggest(fp, scope) {
  if (!fp || !scope) return null;
  let best = null,
    bs = 0,
    second = 0;
  eachDeep(scope, (el) => {
    let s = 0;
    for (const k of Object.keys(fp.weak || {})) if (el.getAttribute(k) === fp.weak[k]) s += 2;
    const t = normalizeText(el.textContent);
    if (fp.text && t === fp.text) s += 2;
    if (s > bs) {
      second = bs;
      bs = s;
      best = el;
    } else if (s > second) second = s;
  });
  if (!best || bs === 0) return null;
  return { element: best, confirmed: false, confidence: (bs - second) / bs };
}

const API = { stamp, capture, find, reanchor, reseal, suggest, normalizeText, version: VERSION, VERSION, OWN_PREFIX, STRONG, WEAK };

if (typeof module !== 'undefined' && module.exports && typeof process !== 'undefined' && process.versions && process.versions.node) {
  module.exports = API;
}
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_REANCHOR__ = API;
