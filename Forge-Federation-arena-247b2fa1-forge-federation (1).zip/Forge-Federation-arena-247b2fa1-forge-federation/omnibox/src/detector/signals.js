/**
 * signals.js — named, separable, weighted signals for seat detection.
 *
 * Design rule inherited from the re-anchor engine: never score a candidate
 * with one undifferentiated number. Every signal has a name, produces a
 * value in [0,1] independently of every other signal, and can be inspected
 * after the fact. A refusal that says "two candidates tied on `area` and
 * `viewportBottom`" is actionable. A refusal that says "score 0.71 vs 0.70"
 * is not.
 *
 * GATES are hard requirements (fail => candidate is not a candidate).
 * SCORES are weighted evidence.
 */

'use strict';

// --------------------------------------------------------------------------
// Lexicons. Deliberately data, not code: a user can extend these without
// touching detection logic, and no provider is named anywhere in this file.
// --------------------------------------------------------------------------

const ASK_INTENT = [
  'message', 'ask', 'prompt', 'chat', 'type a', 'send a message',
  'question', 'anything', 'query',
  'how can i help', "what's on your mind", 'whats on your mind',
];

// The lexicon that says "this editable belongs to the document, not to a
// conversation". A comment box is the single most common false positive for
// a chat composer: it is a big multiline editable near a send-shaped button.
const DOCUMENT_INTENT = [
  'comment', 'reply to', 'review', 'feedback', 'note', 'caption',
  'description', 'bio', 'about you', 'answer', 'post a', 'compose',
  'subject', 'body', 'summary', 'title',
];

const SEND_INTENT = [
  'send', 'submit', 'go', 'run', 'ask', 'enter', 'post', 'dispatch',
];

const SEARCH_INTENT = [
  'search', 'find', 'filter', 'lookup', 'look up', 'jump to', 'go to',
];

const STOP_INTENT = ['stop', 'cancel', 'abort', 'halt', 'pause'];

// --------------------------------------------------------------------------
// Weights. Sum is not required to be 1; the aggregate is normalized.
// Every weight is a judgement and is written down so it can be argued with.
// --------------------------------------------------------------------------

const COMPOSER_WEIGHTS = {
  askIntent: 3.0, // strongest static signal: the page told us what it wants
  anchored: 3.0, // a chat composer does not scroll away with the thread
  viewportBottom: 2.0, // chat composers live at the bottom of the column
  area: 1.5, // the main composer is the biggest editable on the page
  sendAffinity: 2.5, // a send-shaped control sits next to it
  centrality: 1.0, // wide and horizontally centered
  multiline: 1.0, // textarea / aria-multiline / contenteditable div
  notChrome: 2.0, // NOT inside header/nav/aside/dialog-that-is-a-palette
  notSearch: 2.5, // NOT search-shaped
  notDocument: 2.5, // NOT a comment / review / profile field
};

const SEND_WEIGHTS = {
  sendIntent: 3.0,
  proximity: 2.5, // shares an ancestor with the composer, close by
  submitShape: 1.5, // type=submit / role=button / <button>
  trailing: 1.0, // sits after the composer in document order
  notStop: 2.0, // NOT a stop/cancel control
  iconOnly: 0.5, // small square button, common for send arrows
};

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

/** Lowercased concatenation of every human-readable label on an element. */
function labelText(el) {
  if (!el || !el.getAttribute) return '';
  const parts = [
    el.getAttribute('placeholder'),
    el.getAttribute('aria-label'),
    el.getAttribute('aria-placeholder'),
    el.getAttribute('title'),
    el.getAttribute('name'),
    el.getAttribute('data-testid'),
    el.getAttribute('data-test-id'),
    el.getAttribute('id'),
  ];
  // aria-labelledby resolves through the document
  const labelledBy = el.getAttribute && el.getAttribute('aria-labelledby');
  if (labelledBy && el.ownerDocument) {
    for (const id of labelledBy.split(/\s+/)) {
      const t = el.ownerDocument.getElementById(id);
      if (t) parts.push(t.textContent);
    }
  }
  // A wrapping <label>
  if (el.labels && el.labels.length) {
    for (const l of el.labels) parts.push(l.textContent);
  }
  return parts.filter(Boolean).join(' ').toLowerCase().slice(0, 400);
}

/** Text a button shows, including a nested icon's accessible name. */
function buttonText(el) {
  const own = (el.textContent || '').trim().toLowerCase().slice(0, 120);
  return `${labelText(el)} ${own}`.trim();
}

function matchesAny(haystack, needles) {
  if (!haystack) return 0;
  let hits = 0;
  for (const n of needles) if (haystack.includes(n)) hits++;
  return hits;
}

/** Saturating 0..1 from a hit count. One hit is most of the evidence. */
function hitScore(hits) {
  if (hits <= 0) return 0;
  if (hits === 1) return 0.8;
  return 1;
}

function clamp01(n) {
  if (!Number.isFinite(n)) return 0;
  return n < 0 ? 0 : n > 1 ? 1 : n;
}

/** Weighted mean. Non-finite signal values make the signal ineligible
 *  rather than poisoning the aggregate (same rule as the discriminator's
 *  non-finite margin guard). */
function aggregate(signals, weights) {
  let num = 0;
  let den = 0;
  for (const key of Object.keys(weights)) {
    const v = signals[key];
    if (!Number.isFinite(v)) continue;
    num += weights[key] * clamp01(v);
    den += weights[key];
  }
  return den === 0 ? 0 : num / den;
}

module.exports = {
  ASK_INTENT,
  DOCUMENT_INTENT,
  SEND_INTENT,
  SEARCH_INTENT,
  STOP_INTENT,
  COMPOSER_WEIGHTS,
  SEND_WEIGHTS,
  labelText,
  buttonText,
  matchesAny,
  hitScore,
  clamp01,
  aggregate,
};
