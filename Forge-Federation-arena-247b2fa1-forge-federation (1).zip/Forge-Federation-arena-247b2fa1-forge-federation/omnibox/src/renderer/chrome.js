/* Forge Flight chrome — the UI process. Local only; it never loads remote content. */
'use strict';

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};

function fieldGet(target) {
  if (!target) return '';
  return target.isContentEditable ? String(target.textContent || '') : String(target.value || '');
}
function fieldSet(target, v) {
  if (!target) return;
  if (target.isContentEditable) target.textContent = v;
  else target.value = v;
}

/**
 * attachMic — talk-to-text on any input, textarea, or editable, via the
 * browser's own Web Speech API. No server, no key. If the engine is not
 * available in this build, the button disables itself and says so rather
 * than failing silently on click.
 */
function attachMic(btn, target, { autoGrow = false, onCommit } = {}) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR || !btn) {
    if (btn) {
      btn.disabled = true;
      btn.title = 'Voice input is not available in this build';
    }
    return;
  }
  const rec = new SR();
  rec.continuous = true;
  rec.interimResults = true;
  try {
    rec.lang = navigator.language || 'en-US';
  } catch {
    /* default engine language */
  }

  let listening = false;
  let baseValue = '';

  const grow = () => {
    if (!autoGrow || !target || target.isContentEditable) return;
    target.style.height = 'auto';
    target.style.height = `${target.scrollHeight}px`;
  };

  rec.onstart = () => {
    listening = true;
    baseValue = fieldGet(target);
    btn.classList.add('listening');
    btn.title = 'Listening… click to stop';
  };
  rec.onerror = () => {
    listening = false;
    btn.classList.remove('listening');
    btn.title = 'Speak instead of typing';
  };
  rec.onend = () => {
    listening = false;
    btn.classList.remove('listening');
    btn.title = 'Speak instead of typing';
    if (onCommit) onCommit(fieldGet(target));
  };
  rec.onresult = (e) => {
    let finalText = '';
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    if (finalText) baseValue = `${baseValue ? `${baseValue} ` : ''}${finalText.trim()}`;
    fieldSet(target, interim ? `${baseValue} ${interim}`.trim() : baseValue);
    target.dispatchEvent(new Event('input', { bubbles: true }));
    grow();
  };

  btn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (listening) {
      rec.stop();
      return;
    }
    target.focus();
    try {
      rec.start();
    } catch {
      /* already running — Chromium throws if start() is called twice */
    }
  };
}

/**
 * attachSpeak — a Listen button on an output. Never auto-plays. Click again
 * to stop. One voice at a time: starting a new reading stops the last one.
 */
let speakBtn = null;
function attachSpeak(btn, getText) {
  const synth = window.speechSynthesis;
  if (!synth || !btn) {
    if (btn) {
      btn.disabled = true;
      btn.title = 'Voice output is not available in this build';
    }
    return;
  }
  const idle = () => {
    btn.classList.remove('speaking');
    btn.title = 'Listen';
    btn.textContent = btn.dataset.label || 'Listen';
  };
  const stopAll = () => {
    try {
      synth.cancel();
    } catch {
      /* nothing speaking */
    }
    if (speakBtn && speakBtn !== btn) {
      speakBtn.classList.remove('speaking');
      speakBtn.title = 'Listen';
      speakBtn.textContent = speakBtn.dataset.label || 'Listen';
    }
    speakBtn = null;
  };
  btn.dataset.label = btn.textContent || 'Listen';
  btn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (speakBtn === btn && synth.speaking) {
      stopAll();
      idle();
      return;
    }
    stopAll();
    const text = String(typeof getText === 'function' ? getText() : getText || '').trim();
    if (!text) return;
    const u = new SpeechSynthesisUtterance(text);
    try {
      u.lang = navigator.language || 'en-US';
    } catch {
      /* default engine language */
    }
    u.onend = () => {
      if (speakBtn === btn) speakBtn = null;
      idle();
    };
    u.onerror = () => {
      if (speakBtn === btn) speakBtn = null;
      idle();
    };
    speakBtn = btn;
    btn.classList.add('speaking');
    btn.title = 'Stop listening';
    btn.textContent = 'Stop';
    synth.speak(u);
  };
}

function listenButton(getText) {
  const b = el('button', 'speak', 'Listen');
  b.type = 'button';
  b.title = 'Listen';
  attachSpeak(b, getText);
  return b;
}

let state = { tabs: [], activeId: null, rail: [], shapes: [], seatCount: 0, passport: null, session: null };
let view = 'browse';

/* Who sits where. Kept in the chrome because it is a per-run choice, not a
   property of the tab — and defaulted so the shape is usable the moment you
   pick it, without making you assign anything first. Seeded from the saved
   session (keyed by host, since tab ids are new every launch) so a resumed
   table has the same sides it had. */
const table = { assign: {}, subjectId: null, order: [] };

/** The host a tab id is seated on, per the rail. '' for a tab with no seat. */
function hostOfTab(id) {
  const r = state.rail.find((x) => x.tabId === id);
  return r ? r.host : '';
}

/** Tell main who sits where, so the next launch can put them back. */
function pushTableLayout() {
  const assign = {};
  for (const id of Object.keys(table.assign)) {
    const host = hostOfTab(id);
    if (host) assign[host] = table.assign[id];
  }
  window.forgeflight.session.assign({
    assign,
    order: table.order.map(hostOfTab).filter(Boolean),
    subjectHost: table.subjectId ? hostOfTab(table.subjectId) : null,
  });
}

function shapeNeeds() {
  const s = state.shapes.find((x) => x.id === $('shape').value);
  return s ? s.needs : null;
}

/** Fill in anything unassigned, and drop anyone who has left the table. */
function reconcileTable() {
  const seated = state.rail.filter((r) => r.seated).map((r) => r.tabId);
  const live = new Set(seated);
  for (const id of Object.keys(table.assign)) if (!live.has(id)) delete table.assign[id];
  const saved = (state.session && state.session.assign) || {};
  seated.forEach((id, i) => {
    if (!table.assign[id]) {
      // A seat that comes back from a saved session comes back on the side it
      // was on; a seat nobody has arranged yet gets the default alternation.
      const remembered = saved[hostOfTab(id)];
      table.assign[id] = remembered || (i % 2 === 0 ? 'A' : 'B');
    }
  });
  // Existing places are kept, so reordering by hand is never fought. New seats
  // join in the order they were saved, and anyone unsaved joins after them.
  const added = seated.filter((id) => !table.order.includes(id));
  table.order = table.order.filter((id) => live.has(id));
  const savedOrder = (state.session && state.session.order) || [];
  const rank = new Map(savedOrder.map((h, i) => [h, i]));
  added.sort((a, b) => (rank.has(hostOfTab(a)) ? rank.get(hostOfTab(a)) : 99) - (rank.has(hostOfTab(b)) ? rank.get(hostOfTab(b)) : 99));
  table.order.push(...added);
  if (!live.has(table.subjectId)) {
    const savedSubject = state.session && state.session.subjectHost;
    const cameBack = savedSubject ? seated.find((id) => hostOfTab(id) === savedSubject) : null;
    table.subjectId = cameBack || (live.has(state.activeId) ? state.activeId : seated[0] || null);
  }
}
let live = null; // { runId, cols: Map<tabId, {body, foot, head}> }
const runsEl = $('runs');

// ---------------------------------------------------------------- viewport
// The page is a real Chromium view owned by the main process. The chrome
// tells it where the hole is; nothing about the page is emulated here.
function reportViewport() {
  const r = $('panePage').getBoundingClientRect();
  window.forgeflight.viewport({
    x: Math.round(r.x),
    y: Math.round(r.y),
    width: Math.round(r.width),
    height: Math.round(r.height),
  });
}
new ResizeObserver(reportViewport).observe($('stage'));
window.addEventListener('resize', reportViewport);

// The sign-in gate is up: this launch has not signed in, so no page may be
// on screen. The main process refuses to show one anyway — this is the
// renderer's side of the same rule, so the UI and its messages agree.
const gateUp = () => !(state.operator && state.operator.signedIn);

/**
 * Tell main whether the page view may be on screen: only when the Browse
 * pane is the view AND the gate is down. The viewport is reported first, so
 * main never shows a page in a stale hole.
 */
function syncPageVisible() {
  const show = view === 'browse' && !gateUp();
  if (show) reportViewport();
  window.forgeflight.pageVisible(show);
}

// ---------------------------------------------------------------- views
function setView(v) {
  view = v;
  $('panePage').parentElement.querySelectorAll('.pane').forEach((p) => (p.hidden = true));
  const paneFor = { browse: 'panePage', table: 'paneTable', memory: 'paneMemory', carrier: 'paneCarrier', pilots: 'panePilots', forge: 'paneForge' };
  $(paneFor[v] || 'panePage').hidden = false;
  for (const [id, name] of [
    ['viewBrowse', 'browse'],
    ['viewTable', 'table'],
    ['viewMemory', 'memory'],
    ['viewCarrier', 'carrier'],
    ['viewPilots', 'pilots'],
    ['viewForge', 'forge'],
  ]) {
    $(id).classList.toggle('on', name === v);
    $(id).setAttribute('aria-selected', String(name === v));
  }
  syncPageVisible();
  if (v === 'memory') loadMemory();
  if (v === 'carrier') loadCarrier();
  if (v === 'pilots') loadPilots();
  if (v === 'forge') loadForge();
  if (v === 'table') $('tableBadge').hidden = true;
}
$('viewBrowse').onclick = () => setView('browse');
$('viewTable').onclick = () => setView('table');
$('viewMemory').onclick = () => setView('memory');
$('viewCarrier').onclick = () => setView('carrier');
$('viewPilots').onclick = () => setView('pilots');
$('viewForge').onclick = () => setView('forge');

// ---------------------------------------------------------------- tabs
function renderTabs() {
  const wrap = $('tabs');
  wrap.textContent = '';
  for (const t of state.tabs) {
    const node = el('div', `tab${t.id === state.activeId ? ' on' : ''}`);
    node.onclick = () => window.forgeflight.tab.activate(t.id);

    const seatEntry = state.rail.find((r) => r.tabId === t.id);
    if (seatEntry && seatEntry.seated) {
      const d = el('span', 'dot');
      d.style.background = 'var(--heat)';
      d.title = `Seated as ${seatEntry.name}`;
      node.append(d);
    } else if (t.favicon) {
      const img = el('img', 'fav');
      img.src = t.favicon;
      img.onerror = () => img.remove();
      node.append(img);
    } else {
      const d = el('span', 'dot');
      d.style.background = 'var(--edge-hot)';
      node.append(d);
    }

    node.append(el('span', 't', t.loading ? 'Loading…' : t.title || t.url));
    const x = el('button', 'x', '×');
    x.title = 'Close tab';
    x.onclick = (e) => {
      e.stopPropagation();
      window.forgeflight.tab.close(t.id);
    };
    node.append(x);
    wrap.append(node);
  }
}
$('newTab').onclick = () => window.forgeflight.tab.open();
// The reserved seat: a local model at the table, no account, no key.
$('localBtn').onclick = () => window.forgeflight.tab.open('forgeflight://local');

// ---------------------------------------------------------------- resume
/* The session resumes itself on launch, so this button is the other half:
   the way back after a crash, or after you closed the table by hand. It is
   offered only when something is actually missing, and it is additive — it
   reopens sites, it never closes one you have open. */
function renderResume() {
  const s = state.session;
  const missing = (s && s.missing) || [];
  const btn = $('resumeBtn');
  btn.disabled = missing.length === 0;
  btn.setAttribute('aria-label', missing.length ? 'Resume last session' : 'Nothing to resume');
  btn.title = missing.length
    ? `Resume your last session — reopen ${missing.length} ${missing.length === 1 ? 'site' : 'sites'}: ${missing
        .map((m) => m.title || m.url)
        .slice(0, 4)
        .join(', ')}${missing.length > 4 ? '…' : ''}`
    : s && s.savedAt
      ? `Your session is already open. Forge Flight resumes ${s.savedTabs} ${s.savedTabs === 1 ? 'site' : 'sites'} on launch.`
      : 'Nothing saved yet — open an AI chat and it becomes part of your session.';
}

$('resumeBtn').onclick = async () => {
  const btn = $('resumeBtn');
  btn.disabled = true;
  const r = await window.forgeflight.session.restore();
  // The tabs arriving and the rail filling is the feedback; the title carries
  // the sentence for the case where there was nothing to bring back.
  btn.title = (r && r.detail) || 'Nothing to resume.';
};

// ---------------------------------------------------------------- nav
// Phone layout: the seat rail is a touch drawer under 720px (chrome.css).
const rail = $('rail');
const railToggle = $('railToggle');
const railBackdrop = $('railBackdrop');
function setRailOpen(open) {
  const on = !!open;
  rail.classList.toggle('open', on);
  railBackdrop.hidden = !on;
  railToggle.setAttribute('aria-expanded', String(on));
  railToggle.textContent = on ? '×' : '☰';
}
railToggle.onclick = () => setRailOpen(!rail.classList.contains('open'));
railBackdrop.onclick = () => setRailOpen(false);
document.addEventListener('click', (e) => {
  if (!rail.classList.contains('open')) return;
  if (!rail.contains(e.target) && e.target !== railToggle) setRailOpen(false);
});

const addr = $('addr');
let addrDirty = false;
// ---------------------------------------------------------------- address suggestions
// The places you went, offered while you type — from the local file only.
let sugTimer = null;
function showAddrSuggestions() {
  const q = addr.value.trim();
  window.forgeflight.history.suggest(q, 6).then((items) => {
    let d = $('addrSug');
    if (!d) {
      d = el('div', 'addrsug');
      d.id = 'addrSug';
      document.querySelector('.addrwrap').append(d);
    }
    d.textContent = '';
    if (!items.length) {
      d.hidden = true;
      return;
    }
    for (const it of items) {
      const b = el('button', 'addrsug-r');
      b.append(el('span', 'as-t', it.title || it.url));
      b.append(el('span', 'as-u', it.url));
      b.onclick = (e) => {
        e.preventDefault();
        addrDirty = false;
        addr.value = it.url;
        window.forgeflight.tab.navigate(state.activeId, it.url);
        addr.blur();
      };
      d.append(b);
    }
    d.hidden = false;
  });
}
addr.addEventListener('input', () => {
  addrDirty = true;
  clearTimeout(sugTimer);
  sugTimer = setTimeout(() => showAddrSuggestions(), 120);
});
addr.addEventListener('focus', () => addr.select());
addr.addEventListener('blur', () => {
  addrDirty = false;
  syncAddr();
  setTimeout(() => {
    const d = $('addrSug');
    if (d) d.hidden = true;
  }, 150);
});
addr.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    const d = $('addrSug');
    if (d && !d.hidden) {
      e.preventDefault();
      const rows = d.querySelectorAll('.addrsug-r');
      let i = [...rows].findIndex((r) => r.classList.contains('on'));
      if (e.key === 'ArrowDown') i = Math.min(i + 1, rows.length - 1);
      else i = Math.max(i - 1, 0);
      rows.forEach((r, j) => r.classList.toggle('on', j === i));
      if (rows[i]) {
        addrDirty = true;
        addr.value = rows[i].querySelector('.as-u').textContent;
      }
      return;
    }
  }
  if (e.key === 'Enter') {
    const d = $('addrSug');
    const on = d && !d.hidden ? d.querySelector('.addrsug-r.on') : null;
    addrDirty = false;
    window.forgeflight.tab.navigate(state.activeId, on ? on.querySelector('.as-u').textContent : addr.value);
    addr.blur();
  } else if (e.key === 'Escape') {
    addrDirty = false;
    syncAddr();
    addr.blur();
  }
});

function syncAddr() {
  const t = state.tabs.find((x) => x.id === state.activeId);
  if (!t) {
    addr.value = '';
    return;
  }
  if (!addrDirty && document.activeElement !== addr) {
    addr.value = t.url === 'forgeflight://start' ? '' : t.url;
  }
  $('lock').classList.toggle('secure', /^https:/i.test(t.url));
  $('back').disabled = !t.canGoBack;
  $('fwd').disabled = !t.canGoForward;
}
$('back').onclick = () => window.forgeflight.tab.back(state.activeId);
$('fwd').onclick = () => window.forgeflight.tab.forward(state.activeId);
$('reload').onclick = () => window.forgeflight.tab.reload(state.activeId);

// ---------------------------------------------------------------- seat rail
/* The label a person reads. It comes from the VERDICT, not from the coarse
   status — a document-field refusal rendering as "ambiguous" is a small lie,
   and the whole point of this thing is that it does not tell small lies. */
const REASON_TEXT = {
  ambiguous: 'ambiguous',
  'document-field': 'a form, not a chat',
  'cross-origin-frame': 'inside a frame',
  'below-floor': 'not a chat',
  'no-candidates': 'nothing to type in',
};
const STATUS_TEXT = {
  seated: 'seated',
  refused: 'ambiguous',
  'not-a-seat': 'not a chat',
  unknown: 'looking…',
};
const seatLabel = (r) =>
  r.blocked === 'duplicate-host'
    ? 'duplicate'
    : r.blocked === 'muted'
      ? 'muted'
      : REASON_TEXT[r.reason] || STATUS_TEXT[r.status] || r.status;

function renderRail() {
  const body = $('railBody');
  body.textContent = '';
  $('seatCount').textContent = String(state.seatCount);

  if (state.rail.length === 0) {
    body.append(
      Object.assign(el('div', 'railempty'), {
        innerHTML: 'Open a tab. If it is a chat, it <b>takes a seat by itself</b>.',
      })
    );
    return;
  }

  const anySeated = state.rail.some((r) => r.seated);
  for (const r of state.rail) {
    const cls = r.seated
      ? 'seat seated'
      : r.blocked
        ? 'seat blocked'
        : r.status === 'refused'
          ? 'seat refused'
          : 'seat dim';
    const node = el('button', cls);
    node.onclick = () => openSheet(r);
    node.oncontextmenu = (e) => {
      e.preventDefault();
      window.forgeflight.tab.contextmenu(r.tabId);
    };

    // The host on the row, so a test (and a person inspecting the DOM) can
    // tell which seat is which without matching on a display name.
    node.dataset.host = r.host || '';
    const row1 = el('div', 'row1');
    row1.append(el('span', 'nm', r.name || r.host || 'Tab'));
    row1.append(el('span', `st${r.status === 'unknown' ? ' pulse' : ''}`, seatLabel(r)));
    node.append(row1);

    const detail = r.blocked
      ? r.detail
      : r.seated
        ? r.manual
          ? r.restored
            ? 'Composer restored from your pick on this site.'
            : 'Composer chosen by hand.'
          : `${r.title || r.host}`
        : r.pickMissing
          ? 'The box you picked here is no longer on this page. Pick it again.'
          : r.detail || '';
    if (detail) node.append(el('div', 'row2', detail));

    if (r.seated && r.confidence) {
      const bar = el('div', 'bar');
      const i = el('i');
      i.style.width = `${Math.round(Math.min(1, r.confidence) * 100)}%`;
      bar.append(i);
      node.append(bar);
    }

    if (r.seated && r.confirmed) {
      node.append(el('div', 'row2', r.confirmed.value ? '✓ You confirmed this box.' : '✗ You flagged this box.'));
    }

    if (r.seated) {
      const ctrl = assignControl(r);
      if (ctrl) node.append(ctrl);
    }

    if (r.status === 'refused' && !r.blocked) {
      const fix = el('div', 'fix');
      const pick = el('button', 'btn', r.reason === 'ambiguous' ? 'Pick the box' : 'Seat it anyway');
      pick.onclick = (e) => {
        e.stopPropagation();
        window.forgeflight.tab.activate(r.tabId);
        setView('browse');
        window.forgeflight.seat.pick(r.tabId);
      };
      const why = el('button', 'btn ghost', 'Why');
      why.onclick = (e) => {
        e.stopPropagation();
        openSheet(r);
      };
      fix.append(pick, why);
      node.append(fix);
    }

    body.append(node);
  }

  if (!anySeated) {
    body.append(
      Object.assign(el('div', 'railempty'), {
        innerHTML: 'No seats yet — open an AI chat in a tab and it joins the table.',
      })
    );
  }
}

/** The per-seat control for whichever shape is selected. Null when the shape
 *  treats every seat the same, so Communal stays uncluttered. */
function assignControl(r) {
  const needs = shapeNeeds();
  if (!needs) return null;
  const row = el('div', 'assign');
  const stop = (fn) => (e) => {
    e.stopPropagation();
    fn();
  };

  if (needs === 'assignments') {
    for (const [val, label, title] of [
      ['A', 'For', 'Argue the case for'],
      ['B', 'Against', 'Argue the case against'],
      ['out', 'Sit out', 'Not sent to on this run'],
    ]) {
      const b = el('button', table.assign[r.tabId] === val ? `pill on ${val}` : 'pill', label);
      b.title = title;
      b.onclick = stop(() => {
        table.assign[r.tabId] = val;
        pushTableLayout();
        renderRail();
        syncDock();
      });
      row.append(b);
    }
    return row;
  }

  if (needs === 'subject') {
    const isSubject = table.subjectId === r.tabId;
    const b = el(
      'button',
      isSubject ? 'pill on A' : 'pill',
      $('shape').value === 'interview' ? (isSubject ? 'Asks' : 'Answers') : isSubject ? 'Answers first' : 'Critiques'
    );
    b.title = 'Give this seat the lead role';
    b.onclick = stop(() => {
      table.subjectId = r.tabId;
      pushTableLayout();
      renderRail();
    });
    row.append(b);
    return row;
  }

  if (needs === 'order') {
    const i = table.order.indexOf(r.tabId);
    row.append(el('span', 'ord', `${i + 1}`));
    const up = el('button', 'pill', '↑');
    up.title = 'Earlier in the relay';
    up.disabled = i <= 0;
    up.onclick = stop(() => {
      [table.order[i - 1], table.order[i]] = [table.order[i], table.order[i - 1]];
      pushTableLayout();
      renderRail();
    });
    const down = el('button', 'pill', '↓');
    down.title = 'Later in the relay';
    down.disabled = i === -1 || i >= table.order.length - 1;
    down.onclick = stop(() => {
      [table.order[i + 1], table.order[i]] = [table.order[i], table.order[i + 1]];
      pushTableLayout();
      renderRail();
    });
    row.append(up, down);
    return row;
  }

  if (needs === 'focus') {
    const on = state.activeId === r.tabId;
    const b = el('button', on ? 'pill on A' : 'pill', on ? 'This one' : 'Look at it');
    b.onclick = stop(() => window.forgeflight.tab.activate(r.tabId));
    row.append(b);
    return row;
  }

  return null;
}

// ---------------------------------------------------------------- sheet
function openSheet(r) {
  $('sheetTitle').textContent = r.name || r.host || 'Seat';
  const b = $('sheetBody');
  b.textContent = '';

  b.append(el('h4', null, 'Status'));
  b.append(el('p', null, r.detail || seatLabel(r)));

  if (r.signals) {
    b.append(el('h4', null, 'Why Forge Flight thinks so'));
    const g = el('div', 'sigs');
    for (const [k, v] of Object.entries(r.signals)) {
      g.append(el('div', 'k', k));
      const val = el('div', `v${Number(v) >= 0.75 ? ' hi' : ''}`, Number(v).toFixed(2));
      g.append(val);
    }
    b.append(g);
  }

  if (r.status === 'refused' && r.candidates && r.candidates.length) {
    b.append(el('h4', null, 'What it could not choose between'));
    if (r.tiedOn && r.tiedOn.length) {
      b.append(el('p', null, `They score the same on: ${r.tiedOn.join(', ')}.`));
    }
    const ul = el('ul', 'cands');
    for (const c of r.candidates.slice(0, 4)) {
      const li = el('li');
      li.append(el('code', null, `<${c.tag}>`));
      li.append(document.createTextNode(` ${c.label || '(no label)'} — score ${c.score}`));
      ul.append(li);
    }
    b.append(ul);
    b.append(
      el(
        'p',
        null,
        'Forge Flight will not type into a box it cannot identify, because sending your prompt to the wrong field is worse than not sending it. Point at the right one and it will remember.'
      )
    );
  }

  b.append(el('h4', null, 'Name'));
  const rn = el('div', 'rename');
  const input = el('input');
  input.value = r.name || '';
  input.placeholder = r.host;
  const mic = el('button', 'mic', '🎤');
  mic.type = 'button';
  mic.title = 'Speak instead of typing';
  attachMic(mic, input);
  const save = el('button', 'btn', 'Save');
  save.onclick = async () => {
    await window.forgeflight.seat.rename(r.host, input.value);
    closeSheet();
  };
  rn.append(input, mic, save);
  b.append(rn);
  b.append(el('p', null, `Names stick to ${r.host || 'this site'} — rename once, it stays renamed.`));

  const acts = el('div', 'sheetacts');
  if (r.status === 'refused' || !r.seated) {
    const pick = el('button', 'btn hot', 'Pick the box by hand');
    pick.onclick = () => {
      closeSheet();
      window.forgeflight.tab.activate(r.tabId);
      setView('browse');
      window.forgeflight.seat.pick(r.tabId);
    };
    acts.append(pick);
  }
  if (r.manual) {
    const undo = el('button', 'btn', 'Forget my pick');
    undo.onclick = () => {
      window.forgeflight.seat.unpick(r.tabId);
      closeSheet();
    };
    acts.append(undo);
  }
  // A ruling on a seated anchor. Manual seats need none — the person already
  // chose the box. Automatic seats are claims the person can judge, and the
  // ruling is the oracle the field-evidence scorer joins on.
  if (r.seated && !r.manual) {
    if (r.confirmed) {
      b.append(
        el(
          'p',
          null,
          r.confirmed.value
            ? 'You confirmed this is the right box. Change your mind below — the latest ruling stands.'
            : 'You flagged this box as wrong. Change your mind below, or pick the right box by hand.'
        )
      );
    } else {
      b.append(el('h4', null, 'Is this the right box?'));
      b.append(
        el('p', null, 'Forge Flight seated this tab on its own. Your ruling is what teaches it whether it was right.')
      );
    }
    const yes = el('button', 'btn', '✓ Box is right');
    yes.onclick = async () => {
      await window.forgeflight.seat.confirm(r.tabId, true);
      closeSheet();
    };
    const no = el('button', 'btn', '✗ Wrong box');
    no.onclick = async () => {
      await window.forgeflight.seat.confirm(r.tabId, false);
      closeSheet();
    };
    acts.append(yes, no);
  }
  const again = el('button', 'btn', 'Look again');
  again.onclick = () => window.forgeflight.seat.redetect(r.tabId);
  acts.append(again);

  const mute = el('button', 'btn', r.blocked === 'muted' ? 'Allow this site' : 'Never seat this site');
  mute.onclick = async () => {
    await window.forgeflight.seat.mute(r.host, r.blocked !== 'muted');
    closeSheet();
  };
  acts.append(mute);
  b.append(acts);

  $('sheet').hidden = false;
}
function closeSheet() {
  $('sheet').hidden = true;
}
$('sheetClose').onclick = closeSheet;
$('sheet').onclick = (e) => {
  if (e.target === $('sheet')) closeSheet();
};

// ---------------------------------------------------------------- shapes
function renderShapes() {
  const sel = $('shape');
  if (sel.options.length === state.shapes.length && sel.options.length) return;
  sel.textContent = '';
  for (const s of state.shapes) {
    const o = el('option', null, s.label);
    o.value = s.id;
    sel.append(o);
  }
  sel.value = 'communal';
  syncShape();
}
function syncShape() {
  const s = state.shapes.find((x) => x.id === $('shape').value);
  $('shapeBlurb').textContent = s ? s.blurb : '';
}
$('shape').onchange = () => {
  syncShape();
  reconcileTable();
  renderRail();
  syncDock();
};

// ---------------------------------------------------------------- dock
const prompt = $('prompt');
prompt.addEventListener('input', () => {
  prompt.style.height = 'auto';
  prompt.style.height = `${Math.min(108, prompt.scrollHeight)}px`;
  syncDock();
});
prompt.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});
$('send').onclick = send;
$('stop').onclick = () => window.forgeflight.table.stop(live ? live.runId : null);

/** How many seats this shape will actually send to — which is not always the
 *  seat count. Sides can have people sitting out; Solo is always one. */
function willReceive() {
  const seated = state.rail.filter((r) => r.seated);
  const shape = $('shape').value;
  if (shape === 'solo') return seated.some((r) => r.tabId === state.activeId) ? 1 : Math.min(1, seated.length);
  if (shape === 'sides') return seated.filter((r) => table.assign[r.tabId] !== 'out').length;
  return seated.length;
}

function syncDock() {
  const hasText = prompt.value.trim().length > 0;
  const n = willReceive();
  $('send').disabled = !hasText || n === 0 || !!live;
  const hint = $('dockHint');
  hint.classList.remove('warn');
  if (live) hint.textContent = 'The table is answering…';
  else if (state.seatCount === 0) {
    hint.textContent = 'No seats yet';
    hint.classList.add('warn');
  } else if (n === 0) {
    hint.textContent = 'Everyone is sitting out';
    hint.classList.add('warn');
  } else {
    const extra = state.seatCount !== n ? ` of ${state.seatCount}` : '';
    hint.textContent = `${n}${extra} seat${n === 1 ? '' : 's'}`;
  }
}

async function send() {
  const text = prompt.value.trim();
  if (!text || live) return;
  const spec = { prompt: text, shape: $('shape').value, focusId: state.activeId };

  reconcileTable();
  if (spec.shape === 'sides') spec.assignments = { ...table.assign };
  if (spec.shape === 'adversarial' || spec.shape === 'interview') spec.subjectId = table.subjectId;
  if (spec.shape === 'relay') spec.order = [...table.order];

  prompt.value = '';
  prompt.style.height = 'auto';
  setView('table');
  $('dock').classList.add('live');
  $('stop').hidden = false;

  const res = await window.forgeflight.table.send(spec);
  $('dock').classList.remove('live');
  $('stop').hidden = true;
  live = null;
  syncDock();

  if (!res.ok && res.reason === 'no-seats') {
    const box = el('div', 'run');
    const head = el('div', 'runhead');
    head.append(el('div', 'q', res.detail));
    box.append(head);
    runsEl.prepend(box);
    $('tableEmpty').hidden = true;
  }
}

// ---------------------------------------------------------------- runs
function startRun(p) {
  $('tableEmpty').hidden = true;
  const run = el('div', 'run');
  run.dataset.runId = p.runId;

  const head = el('div', 'runhead');
  head.append(el('div', 'q', p.prompt));
  const meta = el('div', 'meta');
  meta.append(el('span', 'chip hot', p.shapeLabel));
  meta.append(document.createTextNode(' '));
  meta.append(el('span', 'chip', `${p.seats.length} seat${p.seats.length === 1 ? '' : 's'}`));
  head.append(meta);
  run.append(head);

  const cols = el('div', 'cols');
  run.append(cols);
  runsEl.prepend(run);

  live = { runId: p.runId, node: run, cols, byTab: new Map() };
  syncDock();
}

function colFor(tabId, seatName, role) {
  if (!live) return null;
  if (live.byTab.has(tabId)) return live.byTab.get(tabId);
  const col = el('div', 'col');
  const head = el('div', 'colhead');
  head.append(el('span', 'nm', seatName));
  head.append(el('span', 'rl', role || ''));
  const body = el('div', 'colbody waiting', 'waiting…');
  const foot = el('div', 'colfoot');
  col.append(head, body, foot);
  live.cols.append(col);
  const rec = { col, head, body, foot, text: '' };
  live.byTab.set(tabId, rec);
  return rec;
}

function runEl(runId) {
  if (live && live.runId === runId) return live.node;
  return runsEl.querySelector(`.run[data-run-id="${runId}"]`);
}

function showCaptain(payload) {
  const node = runEl(payload.runId);
  if (!node) return;
  const existing = node.querySelector('.captainblock');
  if (existing) existing.remove();
  const block = el('div', 'captainblock');
  const cap = payload.captain || {};
  const mark = el('div', 'roundmark');

  if (cap.awaitingHuman) {
    mark.textContent = 'You are the captain. The table already answered.';
    block.append(mark);
    block.append(humanChair(payload.runId, cap));
    node.append(block);
    return;
  }
  if (cap.ok === false) {
    mark.textContent = `Captain refused: ${cap.detail || cap.reason}`;
    block.append(mark);
    node.append(block);
    return;
  }
  const who = cap.actor ? ` · ${cap.actor}` : cap.source === 'human' ? ' · you' : '';
  if (cap.source === 'playbook') mark.textContent = `Named play fired — the plane did not guess${who}`;
  else if (cap.decision === 'verdict') mark.textContent = `Captain: verdict${who}`;
  else if (cap.decision === 'defer') mark.textContent = `Captain deferred to ${cap.seat}${who}`;
  else if (cap.decision === 'unknown') mark.textContent = `Captain: unknown — ${cap.reason || 'the plane does not know'}${who}`;
  else mark.textContent = 'Captain: no decision';
  block.append(mark);
  const play = payload.play;
  if (play && play.name) {
    const line = el('div', 'roundmark');
    const held = play.held ? `held ×${play.held}` : play.result || 'open';
    line.textContent = `Named play: ${play.name} — ${play.blurb || play.move} (${held})`;
    block.append(line);
    const row = el('div', 'chairrow');
    row.style.padding = '8px 18px 12px';
    const heldBtn = el('button', 'btn', 'This play held');
    heldBtn.onclick = async () => {
      const r = await window.forgeflight.diary.mark(play.name, 'held');
      if (r && r.ok) heldBtn.textContent = 'Marked held';
    };
    const brokeBtn = el('button', 'btn ghost', 'This play broke');
    brokeBtn.onclick = async () => {
      const r = await window.forgeflight.diary.mark(play.name, 'broke');
      if (r && r.ok) brokeBtn.textContent = 'Marked broke';
    };
    row.append(heldBtn, brokeBtn);
    block.append(row);
  }
  const bodyText = cap.decision === 'unknown' ? cap.reason : cap.text;
  if (!bodyText) {
    node.append(block);
    return;
  }
  const cols = el('div', 'cols');
  const col = el('div', 'col');
  const head = el('div', 'colhead');
  head.append(el('span', 'nm', cap.source === 'human' ? `Captain (${cap.actor || 'you'})` : 'Captain'));
  head.append(el('span', 'rl', cap.decision || ''));
  const body = el('div', cap.decision === 'unknown' ? 'colbody failed' : 'colbody', bodyText);
  const foot = el('div', 'colfoot');
  foot.append(listenButton(() => bodyText));
  col.append(head, body, foot);
  cols.append(col);
  block.append(cols);
  node.append(block);
}

function humanChair(runId, cap) {
  const chair = el('div', 'captainchair');
  chair.append(el('p', null, cap.detail || 'No local model is running. You decide.'));
  const err = el('div', 'err');
  err.hidden = true;

  const verdict = el('textarea');
  verdict.placeholder = 'Your verdict, in your own words';
  verdict.setAttribute('aria-label', 'Captain verdict');
  const verdictMic = el('button', 'mic', '🎤');
  verdictMic.type = 'button';
  verdictMic.title = 'Speak instead of typing';
  attachMic(verdictMic, verdict, { autoGrow: true });
  const verdictRow = el('div', 'chairfield');
  verdictRow.append(verdict, verdictMic);

  const reason = el('textarea');
  reason.placeholder = 'Why the plane does not know (optional)';
  reason.setAttribute('aria-label', 'Why unknown');
  const reasonMic = el('button', 'mic', '🎤');
  reasonMic.type = 'button';
  reasonMic.title = 'Speak instead of typing';
  attachMic(reasonMic, reason, { autoGrow: true });
  const reasonRow = el('div', 'chairfield');
  reasonRow.append(reason, reasonMic);

  const setErr = (text) => {
    err.hidden = !text;
    err.textContent = text || '';
  };

  const submit = async (decision, extra) => {
    setErr('');
    const r = await window.forgeflight.table.captain({ runId, decision, ...extra });
    if (!r || !r.ok) setErr((r && (r.detail || r.reason)) || 'The chair refused.');
  };

  const tools = el('div', 'chairrow');
  const vBtn = el('button', 'btn hot', 'Verdict');
  vBtn.onclick = () => submit('verdict', { text: verdict.value });
  const uBtn = el('button', 'btn', 'Unknown');
  uBtn.onclick = () => submit('unknown', { reason: reason.value });
  tools.append(vBtn, uBtn);

  const answers = (cap.answers || []).filter((a) => a && a.seatName);
  if (answers.length) {
    chair.append(el('p', null, 'Or defer to one copilot who already answered:'));
    const deferRow = el('div', 'chairrow');
    for (const a of answers) {
      const b = el('button', 'btn ghost', a.seatName);
      b.onclick = () => submit('defer', { seat: a.seatName });
      deferRow.append(b);
    }
    chair.append(deferRow);
  }

  chair.append(el('p', null, 'Write a verdict, or say unknown.'));
  chair.append(verdictRow);
  chair.append(reasonRow);
  chair.append(tools);
  chair.append(err);
  return chair;
}

window.forgeflight.onTable(({ event, payload }) => {
  if (event === 'run:started') return startRun(payload);
  if (event === 'run:captain') return showCaptain(payload);
  if (event === 'run:consensus' && payload.consensus) {
    const node = runEl(payload.runId);
    if (!node) return;
    const c = payload.consensus;
    const mark = el('div', 'roundmark');
    mark.textContent =
      c.kind === 'cross_agreement'
        ? `${c.agreementCount} of ${c.seatCount} seats produced the same claim — recorded as ${c.agreementCount} distinct witnesses`
        : `${c.claims.length} different claims across ${c.seatCount} seats — recorded as a disagreement happening now, not drift over time`;
    node.append(mark);
    return;
  }
  if (!live) return;

  if (event === 'step:started') {
    const c = colFor(payload.seatId, payload.seatName, payload.role);
    if (!c) return;
    c.head.querySelector('.rl').textContent = payload.role || '';
    c.body.className = 'colbody waiting';
    c.body.textContent = 'thinking…';
    c.text = '';
  }

  if (event === 'seat:phase') {
    const c = live.byTab.get(payload.tabId);
    if (!c) return;
    if (payload.phase === 'typing') c.body.textContent = 'typing the prompt…';
    if (payload.phase === 'sending') c.body.textContent = `sent (${payload.strategy})…`;
    if (payload.phase === 'waiting') c.body.textContent = 'waiting for the reply…';
  }

  if (event === 'seat:chunk') {
    const c = live.byTab.get(payload.tabId);
    if (!c) return;
    c.text = payload.text;
    c.body.className = 'colbody';
    c.body.textContent = payload.text;
    c.body.append(el('span', 'caret'));
  }

  if (event === 'step:finished') {
    const c = live.byTab.get(payload.seatId);
    if (!c) return;
    c.body.className = payload.ok ? 'colbody' : 'colbody failed';
    c.body.textContent = payload.ok ? payload.text : refusalText(payload);
    c.foot.textContent = '';
    if (payload.ok) {
      c.foot.append(el('span', null, `${(payload.elapsedMs / 1000).toFixed(1)}s`));
      if (payload.strategy) c.foot.append(el('span', 'chip', payload.strategy));
      if (payload.reason === 'timeout') c.foot.append(el('span', 'chip warn', 'never settled'));
    } else {
      c.foot.append(el('span', 'chip warn', payload.reason || 'refused'));
    }
    const spoken = c.body.textContent;
    if (spoken) c.foot.append(listenButton(() => spoken));
  }

  if (event === 'round:started' && payload.round > 1) {
    live.node.insertBefore(el('div', 'roundmark', `round ${payload.round}`), live.cols);
    live.byTab.clear();
    live.cols = el('div', 'cols');
    live.node.append(live.cols);
  }

  if (event === 'run:finished' || event === 'run:stopped') {
    live = null;
    syncDock();
    if (view !== 'table') {
      $('tableBadge').hidden = false;
      $('tableBadge').textContent = '1';
    }
  }
});

function refusalText(p) {
  switch (p.reason) {
    case 'readback-mismatch':
      return 'Forge Flight typed the prompt but the box did not read it back, so it did not press send. Nothing was sent to this seat.';
    case 'send-disabled':
      return 'The page kept its send control disabled. Forge Flight did not force a submit.';
    case 'not-seated':
      return 'This tab is not a seat right now.';
    case 'empty-response':
      return 'The prompt went in but nothing came back.';
    case 'busy':
      return 'This seat was still answering the previous prompt.';
    default:
      return p.detail || `Refused: ${p.reason}`;
  }
}

// ---------------------------------------------------------------- memory
async function loadMemory() {
  const { rows, stats } = await window.forgeflight.passport.list();
  $('memStats').textContent =
    `${stats.claims} claims · ${stats.live} memories · ${stats.events} events` +
    (stats.byStatus.supported ? ` · ${stats.byStatus.supported} supported` : '') +
    (stats.byStatus.contested ? ` · ${stats.byStatus.contested} contested` : '');

  const list = $('memList');
  list.textContent = '';
  if (rows.length === 0) {
    list.append(
      Object.assign(el('div', 'railempty'), {
        innerHTML:
          'Empty. Every reply the table gives you lands here as a <b>candidate</b> — provisional, low confidence, evidence attached. Five distinct witnesses promote a claim; one contradiction closes it.',
      })
    );
    return;
  }
  for (const m of rows.slice(0, 300)) {
    const n = el('div', `mem ${m.claim.status}`);
    n.append(el('div', 't', m.title));
    n.append(el('div', 'c', m.content));
    const f = el('div', 'f');
    f.append(el('span', 'chip', m.claim.status));
    if (m.claim.equation) f.append(el('span', 'chip eq', m.claim.equation));
    f.append(el('span', null, `${m.claim.witnesses} witness${m.claim.witnesses === 1 ? '' : 'es'}`));
    if (m.seat) f.append(el('span', null, m.seat));
    f.append(el('span', 'sp'));
    f.append(listenButton(() => m.content));
    const pin = el('button', m.pinned ? 'on' : null, m.pinned ? 'pinned' : 'pin');
    pin.onclick = async () => {
      await window.forgeflight.passport.pin(m.id, !m.pinned);
      loadMemory();
    };
    const adj = el('button', m.adjudicated ? 'on' : null, m.adjudicated ? 'adjudicated' : 'adjudicate');
    adj.onclick = async () => {
      await window.forgeflight.passport.adjudicate(m.id);
      loadMemory();
    };
    f.append(pin, adj);
    n.append(f);
    list.append(n);
  }
}

$('memBoot').onclick = async () => {
  const q = $('memQuery').value.trim();
  const b = await window.forgeflight.passport.boot(q || 'anything', 1200);
  $('bootBlock').textContent = b.text;
};
$('memQuery').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('memBoot').click();
});

function memNote(text, kind) {
  const n = $('memNote');
  n.hidden = !text;
  n.textContent = text || '';
  n.className = `memnote ${kind || ''}`;
}

$('memExport').onclick = async () => {
  const r = await window.forgeflight.passport.export();
  if (!r.ok) return memNote(r.reason === 'cancelled' ? '' : r.detail || 'Export failed.', 'warn');
  memNote(`Saved ${r.memories} memories and ${r.claims} claims to ${r.path}`, 'ok');
};

$('memImport').onclick = async () => {
  const r = await window.forgeflight.passport.import();
  if (!r.ok) return memNote(r.reason === 'cancelled' ? '' : r.detail || 'That file could not be read.', 'warn');
  memNote(r.detail, r.skipped && r.skipped.length ? 'warn' : 'ok');
  loadMemory();
};

// ---------------------------------------------------------------- state
function renderGate() {
  const gate = $('gate');
  if (!gate) return;
  const wasGated = document.body.classList.contains('gated');
  const op = state.operator;
  const signed = !!(op && op.signedIn);
  gate.hidden = signed;
  document.body.classList.toggle('gated', !signed);
  // While the gate is up, everything behind it is inert: it can take no
  // click, no focus, no keystroke. This is the HTML half of the hit-test
  // fix — the native half is main mounting no page view until sign-in.
  const behind = document.querySelectorAll('.strip, .nav, .body, .dock, .sheet');
  for (const n of behind) n.inert = !signed;
  // The page view and the gate must never be up together. Showing the page
  // is main's decision (it refuses while this launch is unsigned), but the
  // chrome is the one that knows when the gate actually left the screen.
  syncPageVisible();
  if (signed) {
    // The gate just closed: keyboard goes where a fresh browser puts it, so
    // a typed URL or Ctrl/Cmd+L works without a mouse first.
    if (wasGated && $('addr')) $('addr').focus();
    return;
  }
  const name = $('gateName');
  const go = $('gateGo');
  const blurb = $('gateBlurb');
  const err = $('gateErr');
  if (err) {
    err.hidden = true;
    err.textContent = '';
  }
  if (op && op.envLocked) {
    if (name) {
      name.value = op.configured || '';
      name.readOnly = true;
    }
    if (go) go.textContent = 'Confirm';
    if (blurb) blurb.textContent = `This cockpit is locked to ${op.configured}. Confirm you are flying.`;
  } else {
    if (name) name.readOnly = false;
    if (go) go.textContent = 'Sign in';
    if (op && op.configured) {
      if (name && !name.dataset.filled) {
        name.value = op.configured;
        name.dataset.filled = '1';
      }
      if (blurb) blurb.textContent = `Last launch remembered ${op.configured}. Confirm, or type a different name.`;
    } else if (blurb) {
      blurb.textContent = 'Say who you are. A name on disk is a memory, not this launch.';
    }
  }
  // The gate is the only thing on screen that can take input — put the
  // keyboard in the name field so a name and Enter is the whole ceremony.
  if (name && !gate.contains(document.activeElement)) name.focus();
}

async function submitGate() {
  const err = $('gateErr');
  const r = await window.forgeflight.operator.signIn($('gateName').value);
  if (r && r.ok) {
    if (err) {
      err.hidden = true;
      err.textContent = '';
    }
    return;
  }
  if (err) {
    err.hidden = false;
    err.textContent = (r && (r.detail || r.reason)) || 'Sign in failed.';
  }
}

function apply(s) {
  state = s;
  renderShapes();
  reconcileTable();
  renderTabs();
  renderRail();
  renderResume();
  syncAddr();
  syncDock();
  renderGate();
}

window.forgeflight.onState(apply);
window.forgeflight.onOpenSheet(({ tabId }) => {
  const r = state.rail.find((x) => x.tabId === tabId);
  if (r) openSheet(r);
});
window.forgeflight.onAccel((action) => {
  if (action === 'focus-address') {
    setView('browse');
    addr.focus();
  }
  if (action === 'focus-forgeflight') prompt.focus();
});

window.forgeflight.ready().then((s) => {
  apply(s);
  setView('browse');
  reportViewport();
  attachMic($('addrMic'), addr);
  attachMic($('promptMic'), prompt, { autoGrow: true, onCommit: syncDock });
  attachMic($('memQueryMic'), $('memQuery'));
  attachMic($('gateMic'), $('gateName'));
  if ($('carOpMic') && $('carOpName')) attachMic($('carOpMic'), $('carOpName'));
  attachSpeak($('bootSpeak'), () => $('bootBlock').textContent);
  attachSpeak($('carSpeak'), () => $('carDetail').textContent);
  attachSpeak($('pilotSpeak'), () => $('pilotDetail').textContent);
});

$('gateGo').onclick = submitGate;
$('gateName').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    submitGate();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !$('sheet').hidden) closeSheet();
});


// ---------------------------------------------------------------- pilots
// Four browser agents. A pilot flies one real tab — the one you are looking
// at — and reports every step here. Launching with no target is refused, so
// the goal box always sends the pilot at the active tab.

let pilotTab = 'slots';

async function loadPilots() {
  const st = await window.forgeflight.pilot.status();
  $('pilotStatus').textContent = st
    ? `${st.running} of ${st.maxActive} flying · ${st.slots.filter((s) => s.state !== 'idle').length} active slots · ${st.maxSteps} steps max per flight`
    : 'Pilots are not ready.';
  const badge = $('pilotBadge');
  badge.textContent = String(st ? st.running : 0);
  badge.hidden = !st || st.running === 0 || view === 'pilots';

  const list = $('pilotList');
  list.textContent = '';
  const slots = st ? st.slots : [];
  const detailOf = (slot, goal, log) =>
    `# P${slot}${goal ? ' — ' + goal : ''}\n\n${(log || []).map((l) => `${String(l.kind || '').padEnd(9)} ${l.text}`).join('\n') || 'no steps yet'}`;
  if (pilotTab === 'slots') {
    if (slots.length === 0) {
      const d = el('div', 'railempty');
      d.innerHTML = 'Four slots. Launch a pilot — it flies your active tab and starts clicking.';
      list.append(d);
    }
    for (const s of slots) {
      const n = el('div', `mem ${s.state === 'flying' ? 'provisional' : s.state === 'done' ? 'supported' : ''} clickable`);
      const head = el('div', 't');
      head.append(el('span', 'chip', `P${s.slot}`));
      head.append(document.createTextNode(' ' + (s.goal || 'idle slot')));
      n.append(head);
      n.append(el('div', 'c', s.state === 'flying' ? `flying — ${s.steps} steps so far` : s.state === 'done' ? (s.result && s.result.detail) || 'completed' : 'Waiting.'));
      const f = el('div', 'f');
      f.append(el('span', 'chip', s.state));
      f.append(el('span', null, s.startedAt ? fmtWhen(s.startedAt) : ''));
      f.append(el('span', 'sp'));
      if (s.state === 'flying') {
        const stp = el('button', null, 'Stop');
        stp.onclick = async (e) => {
          e.stopPropagation();
          await window.forgeflight.pilot.stop(s.id);
          loadPilots();
        };
        f.append(stp);
      }
      n.append(f);
      n.onclick = () => pilotDetail(detailOf(s.slot, s.goal, s.log));
      list.append(n);
    }
    return;
  }

  /* flight log */
  const all = await window.forgeflight.pilot.list();
  if (!all.length) {
    const d = el('div', 'railempty');
    d.innerHTML = 'No flights yet. Give a pilot a goal above.';
    list.append(d);
    return;
  }
  for (const t of all.slice(0, 50)) {
    const n = el('div', `mem ${t.state === 'flying' ? 'provisional' : t.state === 'done' ? 'supported' : 'contested'} clickable`);
    n.append(el('div', 't', `P${t.slot}: ${t.goal}`));
    n.append(el('div', 'c', t.log.length ? t.log[t.log.length - 1].text : t.state));
    const f = el('div', 'f');
    f.append(el('span', 'chip', t.state));
    n.append(f);
    n.onclick = () => pilotDetail(detailOf(t.slot, t.goal, t.log));
    list.append(n);
  }
}

function pilotDetail(text) {
  $('pilotDetail').textContent = text;
}

$('pilotLaunch').onclick = async () => {
  const goal = $('pilotGoal').value.trim();
  if (!goal) return;
  const r = await window.forgeflight.pilot.launch(goal, undefined, state.activeId);
  if (!r.ok) {
    pilotDetail(r.detail || `Refused: ${r.reason}`);
    return;
  }
  $('pilotGoal').value = '';
  pilotDetail(`P${r.pilot.slot} launched: ${r.pilot.goal}\n\nIt flies your active tab and will report here as it acts.`);
  loadPilots();
};
$('pilotGoal').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') $('pilotLaunch').click();
});
$('pilotStop').onclick = async () => {
  const r = await window.forgeflight.pilot.stopAll();
  pilotDetail(r.ok ? `Stopping ${r.stopping} pilot${r.stopping === 1 ? '' : 's'} at the end of the current step.` : r.detail);
  loadPilots();
};
$('pilotSlots').onclick = () => {
  pilotTab = 'slots';
  $('pilotSlots').classList.add('on');
  $('pilotLog').classList.remove('on');
  loadPilots();
};
$('pilotLog').onclick = () => {
  pilotTab = 'log';
  $('pilotLog').classList.add('on');
  $('pilotSlots').classList.remove('on');
  loadPilots();
};
attachMic($('pilotGoalMic'), $('pilotGoal'), { onCommit: () => $('pilotLaunch').click() });

// Live flight updates: the main process forwards every pilot event here.
// Refresh the pane when it is open; otherwise just count fliers on the badge.
window.forgeflight.onPilot((kind, payload) => {
  if (kind !== 'pilot:started' && kind !== 'pilot:step' && kind !== 'pilot:finished') return;
  if (view === 'pilots') {
    loadPilots();
  } else {
    window.forgeflight.pilot.status().then((st) => {
      const badge = $('pilotBadge');
      badge.textContent = String(st ? st.running : 0);
      badge.hidden = !st || st.running === 0;
    });
  }
  if (kind === 'pilot:finished' && view === 'pilots' && payload) {
    const done = payload.state === 'done';
    pilotDetail(
      `${done ? 'Landed' : 'Stopped'}: P${payload.slot} — ${payload.goal}\n\n` +
        ((payload.log || []).map((l) => `${String(l.kind || '').padEnd(9)} ${l.text}`).join('\n') || 'no steps')
    );
  }
});


// ---------------------------------------------------------------- the forge
/*
 * The relay that writes code. The loop shows its work as it flies; the only
 * thing on this screen that changes the world is a release, and a release is
 * yours — the loop only ever stages.
 */

async function loadForge() {
  const v = await window.forgeflight.forge.status();
  renderForge(v);
}

function renderForge(v) {
  if (!v) return;
  const status = $('forgeStatus');
  if (v.active) status.textContent = 'Running — the relay is flying.';
  else if (v.paused) status.textContent = 'Paused — every seat is out of allowance and the bench is empty. Resume, or add a seat.';
  else if (v.lastResult && v.lastResult.stopReason === 'goal_reached') {
    status.textContent = `Green at round ${v.lastResult.roundsRun} — a proposal awaits your release.`;
  } else if (v.lastResult && v.lastResult.stopSentence) {
    status.textContent = v.lastResult.stopSentence;
  } else {
    status.textContent = 'Launch the relay over a repo and every seat at the table takes a hand. The build is the referee; only you can release.';
  }

  $('forgeLaunch').hidden = v.active || v.paused;
  $('forgeStop').hidden = !v.active;
  $('forgeResume').hidden = !v.paused;
  if (!v.active) $('forgeGoal').value = v.goal || '';
  $('forgeRepo').value = v.repoDir || '';
  renderForgeLog(v.log || []);
  renderForgeProposals(v.proposals || []);
}

function renderForgeLog(log) {
  const box = $('forgeLog');
  box.textContent = '';
  if (!log.length) {
    box.append(el('div', 'railempty', 'The relay will show its work here — every charge, refusal, and accepted hand.'));
    return;
  }
  for (const line of log) box.append(el('div', 'forgeline', forgeLineText(line)));
  box.scrollTop = box.scrollHeight;
}

function forgeLineText(l) {
  switch (l.event) {
    case 'run:started': return `Launched: ${l.goal}`;
    case 'round:started': return `— round ${l.round} —`;
    case 'seat:charged': return `${l.seatId} charged (${(l.usage && l.usage.calls) || 0} calls this seat)`;
    case 'seat:ejected': return `${l.seatId} exhausted — ejected, never billed again`;
    case 'seat:swapped': return `${l.ejected} exhausted — ${l.seated} seated in its place`;
    case 'seat:proposed': return `${l.seatId} proposed a change`;
    case 'seat:accepted': return `${l.seatId} accepted — still failing: ${(l.failing || []).join(', ') || 'none'}`;
    case 'seat:refused': return `${l.seatId} refused: ${l.reason}`;
    case 'seat:regressed': return `${l.seatId} regressed — reverted, not accepted`;
    case 'goal:reached': return `GREEN — ${l.seatId} reached the goal; proposal staged`;
    case 'run:finished': return `Run finished: ${l.stopReason}`;
    case 'run:paused': return 'Paused — seats exhausted and the bench is empty. Resume, or start fresh.';
    case 'run:resumed': return 'Resumed';
    case 'run:error': return `Error: ${l.detail || l.stopReason || 'unknown'}`;
    case 'proposal:released': return `Released ${l.id} — merged into the base branch`;
    case 'proposal:rejected': return `Rejected ${l.id}`;
    default: return `${l.event}${l.round != null ? ` · round ${l.round}` : ''}`;
  }
}

function renderForgeProposals(proposals) {
  const box = $('forgeProposals');
  box.textContent = '';
  if (!proposals.length) {
    box.append(el('div', 'hint', 'No proposals yet. A run only ever stages one.'));
    return;
  }
  for (const p of proposals) {
    const card = el('div', `proposal ${p.status}`);
    const head = el('div', 'prophead');
    head.append(el('span', null, `${p.status === 'staged' ? 'Awaiting you' : p.status} — ${p.seatId}`));
    head.append(el('span', 'chip', p.branch));
    card.append(head);
    card.append(el('p', 'propsum', p.summary));
    if (p.status === 'staged') {
      const row = el('div', 'proprow');
      const release = el('button', 'btn', 'Release');
      release.onclick = async () => {
        const r = await window.forgeflight.forge.release(p.id);
        if (r && r.ok) loadForge();
        else forgeToast(r);
      };
      const reject = el('button', 'btn ghost', 'Reject');
      reject.onclick = async () => {
        const r = await window.forgeflight.forge.reject(p.id, 'rejected by the operator');
        if (r && r.ok) loadForge();
        else forgeToast(r);
      };
      row.append(release, reject);
      card.append(row);
    }
    box.append(card);
  }
}

function forgeToast(r) {
  const status = $('forgeStatus');
  if (r && r.detail) status.textContent = `Refused: ${r.reason} — ${r.detail}`;
  else if (r && r.reason) status.textContent = `Refused: ${r.reason}`;
  else status.textContent = 'Refused.';
}

window.forgeflight.onForge(({ event, payload }) => {
  if (view === 'forge') {
    loadForge();
  } else {
    const badge = $('forgeBadge');
    if (event === 'run:finished' || event === 'run:paused' || event === 'run:error') {
      badge.hidden = false;
      badge.textContent = '1';
    }
  }
});

$('forgeBrowse').onclick = async () => {
  const dir = await window.forgeflight.forge.browse();
  if (dir) $('forgeRepo').value = dir;
};

$('forgeLaunch').onclick = async () => {
  const goal = $('forgeGoal').value.trim();
  const repoDir = $('forgeRepo').value.trim();
  const maxRounds = Number($('forgeRounds').value) || 4;
  const maxCalls = Number($('forgeCalls').value) || 0;
  if (!goal || !repoDir) {
    $('forgeStatus').textContent = 'A goal and a repo path are both required.';
    return;
  }
  const spec = { goal, repoDir, maxRounds };
  if (maxCalls > 0) spec.seatBudget = { maxCalls };
  const r = await window.forgeflight.forge.launch(spec);
  if (r && r.ok) loadForge();
  else forgeToast(r || { reason: 'unknown' });
};

$('forgeStop').onclick = async () => {
  await window.forgeflight.forge.stop();
};

$('forgeResume').onclick = async () => {
  const r = await window.forgeflight.forge.resume({ resetBudgets: true });
  if (r && r.ok) loadForge();
  else forgeToast(r || { reason: 'unknown' });
};

// ---------------------------------------------------------------- the carrier
/*
 * Mission control's queue, and the two shelves behind it.
 *
 * The only thing on this screen that changes the world is a release, and a
 * release names you. Everything else is read.
 */

/** Helpers the carrier pane needs. Kept local so nothing else has to change. */
function emptyNote(html) {
  const d = el('div', 'railempty');
  d.innerHTML = html;
  return d;
}

function fmtWhen(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const today = new Date().toDateString() === d.toDateString();
  return today
    ? d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
    : d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

let carTab = 'queue';
const CAR_TABS = [
  ['carQueue', 'queue'],
  ['carWorld', 'world'],
  ['carOps', 'operational'],
];

for (const [id, name] of CAR_TABS) {
  $(id).onclick = () => {
    carTab = name;
    for (const [i, n] of CAR_TABS) {
      $(i).classList.toggle('on', n === name);
      $(i).setAttribute('aria-selected', String(n === name));
    }
    loadCarrier();
  };
}

$('carExplainToggle').onclick = () => {
  const box = $('carExplainBox');
  box.hidden = !box.hidden;
  $('carExplainToggle').classList.toggle('on', !box.hidden);
};

$('carRecheck').onclick = async () => {
  const props = await window.forgeflight.federation.rechecks(30);
  carDetail(
    props.length
      ? `${props.length} fact${props.length === 1 ? '' : 's'} queued for recheck.\n\nNothing was deleted. A recheck either confirms the fact — its clock refreshes — or contradicts it, and the store supersedes it. That is the cadence a promoted ruleset needs to stop being a snapshot.`
      : 'Nothing has gone stale. Every operational fact has been re-observed inside the window.'
  );
  carTab = 'queue';
  loadCarrier();
};

function carDetail(text) {
  $('carDetail').textContent = text;
}

function renderOperator() {
  const op = state.operator;
  const label = $('carOperator');
  const input = $('carOpName');
  const save = $('carOpSave');
  const mic = $('carOpMic');
  if (!label) return;
  const hide = (n) => { if (n) n.hidden = true; };
  if (op && op.signedIn) {
    label.textContent = op.envLocked
      ? `Signed in as ${op.name} this launch (locked).`
      : `Signed in as ${op.name} this launch.`;
    label.classList.remove('warn');
    hide(input); hide(save); hide(mic);
  } else {
    label.textContent = 'Not signed in this launch — the gate asks first.';
    label.classList.add('warn');
    hide(input); hide(save); hide(mic);
  }
}

$('carOpSave').onclick = async () => {
  const r = await window.forgeflight.operator.signIn($('carOpName').value);
  carDetail(r.ok ? `Signed in as ${r.name} this launch.` : r.detail || r.reason);
  loadCarrier();
};

async function loadCarrier() {
  renderOperator();
  const { federation, queue, health } = await window.forgeflight.federation.stats();
  const w = (federation.byShelf.world || {});
  const o = (federation.byShelf.operational || {});
  $('carStats').textContent =
    `${federation.live} facts landed · ${w.total || 0} world (${w.established || 0} established) · ` +
    `${o.total || 0} operational · ${federation.events} events` +
    (federation.chain.breaks.length ? ` · ${federation.chain.breaks.length} CHAIN BREAKS` : ' · chain intact');
  $('carStats').title = federation.logPath;

  const note = $('carHealth');
  note.textContent = health.detail;
  note.className = `memnote ${health.healthy ? 'ok' : 'warn'}`;
  note.hidden = false;

  const open = queue.byState && queue.byState.open ? queue.byState.open : 0;
  $('carQueueCount').textContent = String(open);
  $('carQueueCount').hidden = open === 0;
  $('carrierBadge').textContent = String(open);
  $('carrierBadge').hidden = open === 0;

  const list = $('carList');
  list.textContent = '';
  if (carTab === 'queue') return renderQueue(list);
  return renderShelf(list, carTab);
}

async function renderQueue(list) {
  const items = await window.forgeflight.federation.queue();
  const open = items.filter((i) => i.state === 'open');
  if (!open.length) {
    list.append(
      emptyNote(
        'Nothing is waiting on you. That is the system working — the math eliminated everything it could, ' +
          'and what reaches this queue is only the residue it genuinely could not settle.'
      )
    );
  }
  for (const it of [...open, ...items.filter((i) => i.state !== 'open').slice(0, 20)]) {
    const n = el('div', `mem ${it.state === 'open' ? 'provisional' : it.state === 'released' ? 'supported' : 'contested'}`);
    n.append(el('div', 't', it.ask === 'capability' ? `${it.pilot} → ${it.capability}` : it.rendered || it.ask));
    n.append(el('div', 'c', (it.notice || '').split('\n')[0]));

    const f = el('div', 'f');
    f.append(el('span', 'chip', it.ask));
    f.append(el('span', 'chip', it.state));
    if (it.actor) f.append(el('span', null, `by ${it.actor}`));
    f.append(el('span', null, fmtWhen(it.proposedAt || it.at)));
    f.append(el('span', 'sp'));

    if (it.state === 'open') {
      const named = state.operator && state.operator.name;
      const rel = el('button', 'on', 'Release');
      rel.title = named
        ? `Authorise this. It will be signed as ${named}.`
        : 'Name who signs first. Until then nothing can be released.';
      rel.disabled = !named;
      rel.onclick = async (e) => {
        e.stopPropagation();
        const r = await window.forgeflight.federation.release(it.id);
        const who = (r.released && r.released.actor) || named || 'the operator';
        carDetail(
          r.ok
            ? `Released by ${who}.\n\n${it.notice || ''}\n\n${r.landed && r.landed.ok ? `Landed: ${r.landed.fact.rendered} (${r.landed.action})` : 'Authorised. The action is performed by the harness, not by this screen.'}`
            : `Refused: ${r.detail || r.reason}`
        );
        loadCarrier();
      };
      const no = el('button', null, 'Deny');
      no.title = named ? `Refuse this. It will be signed as ${named}.` : 'Name who signs first.';
      no.disabled = !named;
      no.onclick = async (e) => {
        e.stopPropagation();
        await window.forgeflight.federation.refuse(it.id);
        loadCarrier();
      };
      f.append(rel, no);
    }
    n.append(f);
    n.onclick = () => carDetail(it.notice || JSON.stringify(it, null, 2));
    list.append(n);
  }
}

async function renderShelf(list, shelf) {
  const facts = await window.forgeflight.federation.facts(shelf, 200);
  if (!facts.length) {
    list.append(
      emptyNote(
        shelf === 'world'
          ? 'No world claims yet. These are propositions true independently of who is asking — five <b>distinct</b> witnesses promote one, one contradiction closes it permanently, and they never expire.'
          : 'No operational facts yet. These are scoped to a target that mutates — when a site redesigns, the old fact did not become wrong, it <b>expired</b>, and it is superseded rather than closed.'
      )
    );
    return;
  }
  for (const f of facts) {
    const n = el('div', `mem ${f.status === 'established' ? 'supported' : 'provisional'}`);
    n.append(el('div', 't', f.rendered));
    if (f.target) n.append(el('div', 'c', `scoped to ${f.target}`));
    const foot = el('div', 'f');
    foot.append(el('span', 'chip', f.status));
    foot.append(el('span', null, `${f.distinct} distinct witness${f.distinct === 1 ? '' : 'es'}`));
    foot.append(el('span', null, [...new Set(f.witnesses.map((w) => w.kind))].join(', ')));
    foot.append(el('span', 'sp'));
    foot.append(el('span', null, fmtWhen(f.lastSeenAt)));
    n.append(foot);
    n.onclick = () =>
      carDetail(
        `${f.rendered}\n\nshelf        ${f.shelf}\n` +
          (f.target ? `target       ${f.target}\n` : '') +
          `status       ${f.status}\n` +
          `witnesses    ${f.distinct} distinct\n` +
          f.witnesses.map((w) => `             ${w.kind} from ${w.nodeId} · ${fmtWhen(w.at)}`).join('\n') +
          `\nlanded       ${fmtWhen(f.landedAt)}\nlast seen    ${fmtWhen(f.lastSeenAt)}`
      );
    list.append(n);
  }
}
