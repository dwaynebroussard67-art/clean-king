/**
 * curator.js — mission control. Sees everything. Flies nothing.
 *
 * THE TRIANGLE OF AUTHORITY IS THREE MACHINE ROLES. THE HUMAN IS NOT ONE.
 *
 *   READER    proposes, and cannot promote. It is the thing that looks at
 *             the world — the pilot on the page, or the curator over the
 *             carrier. It can be persuaded, poisoned, and can drift, which
 *             is exactly why it holds no power.
 *
 *   OVERSEER  decides, and never reads the page. It sees only equations and
 *             constraints. It is mechanical. There is nothing in it to
 *             persuade.
 *
 *   ORACLE    does not listen. The equation base. It takes no argument, no
 *             confidence score, and no vote.
 *
 * The human is STEP FOUR, outside the triangle — and that is what makes it
 * airtight rather than weaker. If the human were the overseer, the reader
 * would be optimising to persuade a person, and models are extremely good at
 * that. Because the overseer is blind and mechanical, persuasion has already
 * failed as a strategy before anything reaches a human. The human is not the
 * defence. The human is the release.
 *
 * WHAT THE CURATOR IS
 *
 * A reader on the outbound side, with exactly the standing a pilot has on the
 * inbound side. It has more knowledge than any pilot — that is its whole job —
 * and MORE KNOWLEDGE IS NOT MORE AUTHORITY. Breadth of view earns it a better
 * proposal, never a shorter path through the gate.
 *
 * It cannot send. It cannot fly. It cannot mount a capability. It writes to
 * exactly one place: an append-only proposal queue.
 *
 * WHY ITS OBJECTIONS ARE SAFE
 *
 * Because the base is equations, the curator cannot object arbitrarily. It
 * cannot say "I have a bad feeling about this." The only objection it can
 * make is to point at a NAMED BROKEN CONSTRAINT and the NAMED VARIABLE that
 * broke it — and the human can look at that and see it for themselves.
 *
 * That is the deepest reason it can never become the oracle: not because
 * power was taken away, but because every objection it makes is
 * independently verifiable by the person it is making it to. A thing that
 * must show its work cannot accumulate authority.
 *
 * THE FUNNEL
 *
 *   pilot requests  ->  math discards most  ->  curator proposes what survives
 *                   ->  human answers
 *
 * The math's job is to ELIMINATE, not to rank. What reaches a human is only
 * what the math genuinely cannot settle — which means the human's queue is
 * the Federation's refusal set, exactly as the engine's refusals are what the
 * teacher gets. And the size of that queue is a MEASURABLE property: if it
 * grows, the funnel upstream has stopped working. See `health()`.
 */

'use strict';

const crypto = require('node:crypto');
const { canonicalEquation, renderEquation, equationSignature } = require('../passport/equation.js');

const newId = (p) => `${p}_${crypto.randomBytes(6).toString('hex')}`;
const nowIso = (d) => (d ? new Date(d) : new Date()).toISOString();

/** Verdicts the overseer can return. Closed set — an unnamed verdict is a bug. */
const VERDICTS = ['satisfied', 'unsatisfied', 'unknown', 'malformed'];

/** What a proposal is asking for. Closed set. */
const ASKS = ['capability', 'transfer', 'recheck'];

/** Above this, the funnel has stopped funnelling and a human is being asked
 *  to rubber-stamp. It is an alarm, not a limit. */
const QUEUE_ALARM = 12;

// --------------------------------------------------------------------------
// THE OVERSEER — decides, never reads prose
// --------------------------------------------------------------------------

/**
 * Check one precondition against the Federation.
 *
 * This is the entire mechanical core, and it is deliberately tiny. It takes
 * an equation, finds what the Federation holds for that same subject and
 * predicate, and compares the object. No model. No prose. No judgment.
 *
 *   satisfied    the Federation agrees, or holds nothing that conflicts
 *   unsatisfied  the Federation holds a DIFFERENT object for the same
 *                subject+predicate — a named broken constraint
 *   unknown      the Federation holds nothing on this subject+predicate
 *   malformed    the precondition is not an equation and cannot be checked
 */
function checkPrecondition(federation, shelf, want) {
  const eq = canonicalEquation(want);
  if (!eq) return { verdict: 'malformed', want: null };

  const held = federation.findByPredicate(eq.subject, eq.predicate, shelf);
  if (!held) return { verdict: 'unknown', want: eq, rendered: renderEquation(eq) };

  const same = equationSignature(eq, shelf) === held.signature;
  if (same) {
    return {
      verdict: 'satisfied',
      want: eq,
      rendered: renderEquation(eq),
      held: held.rendered,
      variable: `${eq.predicate}(${eq.subject})`,
      witnesses: held.distinct,
      status: held.status,
      since: held.landedAt,
    };
  }

  return {
    verdict: 'unsatisfied',
    want: eq,
    rendered: renderEquation(eq),
    held: held.rendered,
    // THE NAMED VARIABLE. This is what makes a denial checkable rather than
    // an opinion: the human can look up this exact term themselves.
    variable: `${eq.predicate}(${eq.subject})`,
    expected: eq.object,
    actual: held.equation.object,
    witnesses: held.distinct,
    status: held.status,
    since: held.landedAt,
    signature: held.signature,
  };
}

/**
 * The overseer's ruling on a whole request. Blind: it is handed equations and
 * returns a verdict. It never sees the prose that produced them.
 */
function overseer(federation, request) {
  const shelf = request.shelf === 'world' ? 'world' : 'operational';
  const checks = (request.preconditions || []).map((p) => checkPrecondition(federation, shelf, p));

  const broken = checks.filter((c) => c.verdict === 'unsatisfied');
  const unknown = checks.filter((c) => c.verdict === 'unknown');
  const malformed = checks.filter((c) => c.verdict === 'malformed');

  let ruling;
  if (malformed.length) ruling = 'malformed';
  else if (broken.length) ruling = 'blocked';
  else if (unknown.length) ruling = 'unproven';
  else ruling = 'clear';

  return { ruling, checks, broken, unknown, malformed, shelf };
}

// --------------------------------------------------------------------------
// THE CURATOR — a reader on the outbound side
// --------------------------------------------------------------------------

class Curator {
  /**
   * @param {object} federation  the store. READ ONLY from here — the curator
   *   is handed the object but never calls a write method on it, and the
   *   test suite asserts that.
   * @param {object} queue  the ONLY thing it may write to.
   */
  constructor(federation, queue, opts = {}) {
    this.federation = federation;
    this.queue = queue;
    this.queueAlarm = opts.queueAlarm ?? QUEUE_ALARM;
  }

  /**
   * A pilot wants a capability it does not carry.
   *
   * It has already cleared its own filter to get here; that is not a grant.
   * The curator checks the request's preconditions against the LARGER base —
   * the things the pilot cannot see — and either lets it through untouched,
   * or denies it with the exact constraint that failed.
   *
   * It never grants. `clear` means "nothing in the Federation objects", and
   * a grant still comes from the harness the way it always did.
   */
  reviewCapability(request, { at } = {}) {
    const r = overseer(this.federation, request);
    const stamp = nowIso(at);

    const base = {
      id: newId('prop'),
      ask: 'capability',
      capability: String(request.capability || '').slice(0, 120),
      pilot: String(request.pilot || '').slice(0, 120),
      missionId: request.missionId || null,
      ruling: r.ruling,
      checks: r.checks,
      at: stamp,
    };

    if (r.ruling === 'clear') {
      return { ...base, decision: 'no-objection', notice: null, needsHuman: false };
    }

    if (r.ruling === 'malformed') {
      return {
        ...base,
        decision: 'refused',
        needsHuman: false,
        notice:
          `${base.pilot} requested ${base.capability}. Its preconditions are not equations, ` +
          'so the Federation cannot check them. Refused — nothing was denied on judgment.',
      };
    }

    // `unproven` is NOT a denial. The Federation simply holds nothing on the
    // subject. Absence of evidence is not evidence, so this rises as a note
    // rather than a block, and the pilot proceeds.
    if (r.ruling === 'unproven') {
      return {
        ...base,
        decision: 'no-objection',
        needsHuman: false,
        notice:
          `${base.pilot} requested ${base.capability}. The Federation holds nothing on ` +
          `${r.unknown.map((u) => u.rendered).join(', ')} — no objection, and no assurance either.`,
      };
    }

    // Blocked. Build the signable denial notice: the named constraint, the
    // named variable, what the Federation holds instead, and on what evidence.
    const proposal = {
      ...base,
      decision: 'denied-pending-human',
      needsHuman: true,
      notice: denialNotice(base, r.broken),
      broken: r.broken,
    };
    this.queue.propose(proposal);
    return proposal;
  }

  /**
   * A fact wants to leave a cockpit and land on the carrier, or cross to
   * another product.
   *
   * The same triangle, the same direction of travel: the curator proposes,
   * the overseer decides, a human releases. And what the human signs is a
   * DELTA OF EQUATIONS, never a story — if they sign prose they are rubber
   * stamping, and the cutoff is theatre.
   */
  reviewTransfer(spec, { at } = {}) {
    const eq = canonicalEquation(spec.equation);
    const stamp = nowIso(at);
    if (!eq) {
      return {
        id: newId('prop'),
        ask: 'transfer',
        decision: 'refused',
        needsHuman: false,
        at: stamp,
        notice: 'Not an equation. Prose does not cross the radio; it stays in the cockpit.',
      };
    }

    const shelf = spec.shelf === 'world' ? 'world' : 'operational';
    const held = this.federation.findByPredicate(eq.subject, eq.predicate, shelf);
    const conflict =
      held && equationSignature(eq, shelf) !== held.signature
        ? { variable: `${eq.predicate}(${eq.subject})`, held: held.rendered, incoming: renderEquation(eq) }
        : null;

    const proposal = {
      id: newId('prop'),
      ask: 'transfer',
      shelf,
      equation: eq,
      rendered: renderEquation(eq),
      witness: spec.witness,
      nodeId: spec.nodeId,
      reference: spec.reference,
      target: spec.target || null,
      replication: spec.replication || 1,
      conflict,
      decision: 'proposed',
      needsHuman: true,
      at: stamp,
      notice: transferNotice(eq, shelf, spec, conflict),
    };
    this.queue.propose(proposal);
    return proposal;
  }

  /**
   * Staleness. The curator NEVER deletes and never expires anything itself —
   * it asks for a recheck. The recheck then either confirms the fact (its
   * clock refreshes) or contradicts it (the store supersedes or closes it).
   *
   * This is the answer to the drift measurement: a promoted ruleset is a
   * snapshot, not a standing guarantee. The curator is the cadence.
   */
  proposeRechecks({ days = 30, limit = 10, now } = {}) {
    const stale = this.federation.stale({ days, now }).slice(0, limit);
    return stale.map((f) => {
      const proposal = {
        id: newId('prop'),
        ask: 'recheck',
        signature: f.signature,
        rendered: f.rendered,
        target: f.target,
        lastSeenAt: f.lastSeenAt,
        ageDays: Math.floor((Date.now() - new Date(f.lastSeenAt).getTime()) / 86400000),
        decision: 'proposed',
        needsHuman: true,
        at: nowIso(now),
        notice:
          `${f.rendered} was last confirmed ${f.lastSeenAt.slice(0, 10)} against ${f.target}. ` +
          'Nothing is deleted — re-establish it, or let a contradiction supersede it.',
      };
      this.queue.propose(proposal);
      return proposal;
    });
  }

  /**
   * The alarm. The whole design rests on the funnel narrowing, so a growing
   * queue is a DEFECT WITH A NAME rather than a feeling of being overwhelmed:
   * either the equations have stopped discriminating, or the entry rule is
   * admitting too much, or the curator has started forwarding instead of
   * deciding.
   */
  health() {
    const open = this.queue.open();
    return {
      open: open.length,
      alarm: this.queueAlarm,
      healthy: open.length <= this.queueAlarm,
      detail:
        open.length <= this.queueAlarm
          ? 'The funnel is narrowing. Decisions reaching a human are the residue the math could not settle.'
          : `${open.length} decisions are waiting on a human, over an alarm of ${this.queueAlarm}. ` +
            'The funnel upstream has stopped working — the math is not discriminating, or the curator is forwarding instead of deciding.',
    };
  }
}

// --------------------------------------------------------------------------
// The notices. Signable in seconds, or the cutoff is theatre.
// --------------------------------------------------------------------------

function denialNotice(base, broken) {
  const lines = [`${base.pilot} requested ${base.capability}.`];
  for (const b of broken) {
    lines.push(
      `Its preconditions assumed ${b.rendered}. ` +
        `Federation holds ${b.held} — ${b.witnesses} witness${b.witnesses === 1 ? '' : 'es'}, ${b.status}, since ${String(b.since).slice(0, 10)}. ` +
        `Constraint ${b.variable} fails.`
    );
  }
  lines.push('Denied pending your call.');
  return lines.join('\n');
}

function transferNotice(eq, shelf, spec, conflict) {
  const lines = [`${renderEquation(eq)} wants to land on the ${shelf} shelf.`];
  lines.push(
    `Witness: ${spec.witness}${spec.nodeId ? ` from ${spec.nodeId}` : ''}` +
      (spec.replication > 1 ? `, replicated by ${spec.replication} distinct nodes` : '') +
      `. Evidence: ${spec.reference}.`
  );
  if (conflict) {
    lines.push(
      `CONFLICT on ${conflict.variable}: Federation holds ${conflict.held}. ` +
        (shelf === 'world'
          ? 'Landing this closes the old claim permanently.'
          : 'Landing this supersedes the old fact — the target moved.')
    );
  }
  lines.push('Release?');
  return lines.join('\n');
}

module.exports = {
  Curator,
  overseer,
  checkPrecondition,
  denialNotice,
  transferNotice,
  VERDICTS,
  ASKS,
  QUEUE_ALARM,
};
