/**
 * queue.js — the proposal queue. The curator's only write path.
 *
 * The curator gets read access to everything and write access to exactly one
 * thing: this. Not the Federation, not the passport, not a capability
 * registry. One append-only file where it may say "I think this should
 * happen" and nothing else.
 *
 * APPEND-ONLY, INCLUDING WITHDRAWALS
 *
 * A proposal that was made and then withdrawn stays in the record. If the
 * curator could quietly retract, the record would show only the proposals it
 * still stood behind — which is exactly the history you would want to inspect
 * if you ever suspected it had started steering.
 *
 * WHAT A HUMAN SIGNS
 *
 * A release names the human, the proposal, and the decision. It is a ticket,
 * not a mood: the queue refuses a release with no actor, because an anonymous
 * approval is indistinguishable from the machine approving itself.
 *
 * The release does NOT perform the action. It authorises it. The thing that
 * acts is the thing that always acted — the harness for a capability, the
 * Federation's own `land` for a transfer. This file hands out permission and
 * touches nothing.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

// A per-record label, never checked on read; 'omnibox.queue.v1' lines replay as before.
const SCHEMA = 'forgeflight.queue.v1';
const GENESIS = '0'.repeat(64);

const nowIso = (d) => (d ? new Date(d) : new Date()).toISOString();
const sha256 = (s) => crypto.createHash('sha256').update(String(s), 'utf8').digest('hex');
const chainHash = (prev, rec) => sha256(`${prev}|${JSON.stringify(rec)}`);

/** Every state a proposal can be in. Closed set. */
const STATES = ['open', 'released', 'refused', 'withdrawn'];

class ProposalQueue {
  constructor(dir) {
    this.dir = dir;
    this.logPath = path.join(dir, 'queue.jsonl');
    this.items = new Map(); // id -> proposal
    this.head = GENESIS;
    this.corrupt = 0;
  }

  load() {
    fs.mkdirSync(this.dir, { recursive: true });
    // The queue lived in `collective/queue.jsonl` before the rename. Adopt it
    // once if nothing is here yet; never overwrite, never throw. See D26.
    if (!fs.existsSync(this.logPath)) {
      const old = path.join(path.dirname(this.dir), 'collective', 'queue.jsonl');
      try {
        if (fs.existsSync(old)) fs.renameSync(old, this.logPath);
      } catch {
        /* leave both as they were */
      }
    }
    if (!fs.existsSync(this.logPath)) return this;
    for (const line of fs.readFileSync(this.logPath, 'utf8').split('\n')) {
      const s = line.trim();
      if (!s) continue;
      try {
        const rec = JSON.parse(s);
        this.apply(rec);
        this.head = rec.hash || this.head;
      } catch {
        this.corrupt++;
      }
    }
    return this;
  }

  apply(rec) {
    if (rec.op === 'propose') this.items.set(rec.data.id, { ...rec.data, state: 'open' });
    else if (rec.op === 'decide') {
      const cur = this.items.get(rec.data.id);
      if (cur) this.items.set(rec.data.id, { ...cur, ...rec.data });
    }
  }

  append(op, data) {
    const rec = { op, data };
    const prev = this.head;
    const hash = chainHash(prev, rec);
    fs.mkdirSync(this.dir, { recursive: true });
    fs.appendFileSync(this.logPath, `${JSON.stringify({ ...rec, prev, hash })}\n`, 'utf8');
    this.head = hash;
    this.apply(rec);
    return data;
  }

  /** The curator's one verb. */
  propose(proposal) {
    if (!proposal || !proposal.id) throw new Error('a proposal needs an id');
    const item = { ...proposal, schema: SCHEMA, state: 'open', proposedAt: proposal.at || nowIso() };
    this.append('propose', item);
    return item;
  }

  /**
   * A human answers. Names them, or it is refused — an anonymous approval is
   * indistinguishable from the machine approving itself.
   */
  release(id, { actor, note, at } = {}) {
    return this.decide(id, 'released', { actor, note, at });
  }

  refuse(id, { actor, note, at } = {}) {
    return this.decide(id, 'refused', { actor, note, at });
  }

  /** The curator may withdraw its own proposal. The record keeps it. */
  withdraw(id, { reason, at } = {}) {
    const cur = this.items.get(id);
    if (!cur) return { ok: false, reason: 'unknown-proposal' };
    if (cur.state !== 'open') return { ok: false, reason: 'already-decided', state: cur.state };
    return {
      ok: true,
      item: this.append('decide', { id, state: 'withdrawn', withdrawnAt: nowIso(at), withdrawReason: reason || null }),
    };
  }

  decide(id, state, { actor, note, at } = {}) {
    if (!STATES.includes(state)) return { ok: false, reason: 'bad-state' };
    const cur = this.items.get(id);
    if (!cur) return { ok: false, reason: 'unknown-proposal' };
    if (cur.state !== 'open') return { ok: false, reason: 'already-decided', state: cur.state };
    const who = String(actor || '').trim();
    if (!who) {
      return {
        ok: false,
        reason: 'unsigned',
        detail: 'A release names the human. An anonymous approval is the machine approving itself.',
      };
    }
    const item = this.append('decide', {
      id,
      state,
      actor: who,
      note: note ? String(note).slice(0, 400) : null,
      decidedAt: nowIso(at),
    });
    return { ok: true, item: this.items.get(id), record: item };
  }

  open() {
    return [...this.items.values()].filter((i) => i.state === 'open');
  }

  all({ limit = 200 } = {}) {
    return [...this.items.values()].slice(-limit).reverse();
  }

  get(id) {
    return this.items.get(id) || null;
  }

  stats() {
    const by = {};
    for (const i of this.items.values()) by[i.state] = (by[i.state] || 0) + 1;
    return { schema: SCHEMA, total: this.items.size, byState: by, corrupt: this.corrupt, logPath: this.logPath };
  }

  static defaultDir(app) {
    return path.join(app.getPath('userData'), 'federation');
  }
}

module.exports = { ProposalQueue, SCHEMA, STATES };
