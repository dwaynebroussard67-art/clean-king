/**
 * scorer.mjs — field evidence: what the detector got right and wrong, measured
 * on real pages instead of fixtures.
 *
 * The fixtures in test/fixtures/ are pages we wrote, mutating in ways we
 * authored. They prove the detector refuses the failures we imagined. They
 * say nothing about the pages a person actually opens, which redesign without
 * warning and fail in ways nobody imagined. This scorer closes that gap: it
 * reads the engine-training log (`anchors.jsonl`, written by
 * src/main/anchors.js) and scores the detector's confident claims against the
 * only oracle that exists for a live page — the person looking at it.
 *
 * ── What counts as evidence, and what does not ──────────────────────────
 *
 * A CONFIDENT claim is an automatic verdict (`manual: false`) with
 * `status: 'seated'` and `confidence >= threshold` (default 0.7 — well clear
 * of the detector's 0.42 floor; a seat at 0.45 is seated but tentative, and
 * tentative claims are not what this metric is about). Manual verdicts are
 * human rulings, not machine claims, so they can never be "confidently wrong".
 *
 * A RULING is a human judgment on a seated anchor:
 *   - a `pick` with `ok: true` — the person pointed at the box. Agrees with
 *     the confident verdict when the picked stamp's stability key equals the
 *     winner's key; disagrees otherwise.
 *   - a `confirm` — the person pressed "box is right" / "wrong box" in the
 *     seat sheet. Pairs by `anchorKey` to the confident verdict that claimed
 *     that key. `confirmed: true` agrees, `confirmed: false` disagrees.
 *
 * confidentlyWrongRate = disagreed / adjudicated, where adjudicated is the
 * count of confident verdicts that received at least one ruling. With no
 * rulings the rate is null — unknown — never zero. Absence of disagreement
 * is not evidence of correctness, and reporting 0.0 on an unadjudicated log
 * would be the exact confident wrongness this file exists to measure.
 *
 * Deliberately NOT evidence:
 *   - `outcome` records. Whether the world answered says nothing about
 *     whether the anchor was the right box — the furniture post-mortem in the
 *     handoff proved replies can be captured from page chrome while the
 *     anchor was fine, and a refusal to send (send-disabled, readback
 *     mismatch) can happen on a perfectly identified composer. Outcomes are
 *     counted and reported as weak signals, and never adjudicate.
 *   - `anchor-change` records. A flipped winner is instability, not
 *     wrongness — the before-state may have been correct for the page as it
 *     was. Drift is counted separately.
 *   - Below-threshold seats. A ruling on a tentative seat is still a ruling,
 *     but the metric is *confidently* wrong; tentative disagreements are
 *     reported as unpaired, not folded in.
 *
 * ── Join rules ──────────────────────────────────────────────────────────
 *
 * Joins are by EXACT url string — the same rule AnchorLog itself uses when it
 * pairs before/after records. A navigation breaks the join, because the page
 * the ruling was made on is not the page the verdict was made on. Records
 * with a missing or non-string url are counted in their totals but can never
 * join: pairing two records neither of which names its page would manufacture
 * evidence.
 *
 * Last ruling wins. A person who confirms and then changes their mind has
 * their latest judgment stand; a verdict with two rulings is adjudicated
 * once. First-ruling-wins would freeze a mistake the person already
 * corrected.
 *
 * A ruling that pairs to no confident verdict is unpaired — and when the
 * latest verdict on that url was a refusal, it is additionally a
 * refusalResolution: the human settling exactly the case the detector
 * declined to guess. That is the refusal path working, not the seating path
 * failing, and the two are never mixed.
 *
 * ── Log hygiene ─────────────────────────────────────────────────────────
 *
 * parseAnchorsText tolerates the same damage the stores do: a torn final line
 * (unterminated, unparseable) is dropped and counted as torn; an unparseable
 * line anywhere else is corrupt and counted; a parsed line with an unknown or
 * missing `type` is counted as unknown and skipped, so a future record type
 * never breaks an old scorer. Scoring functions take the parsed records; the
 * `scoreAnchorsText` / `scoreAnchorsFile` conveniences merge the hygiene
 * counts into the report.
 *
 * Pure modules, no I/O except scoreAnchorsFile and the CLI print at the
 * bottom. No dependencies.
 */

const KNOWN_TYPES = new Set(['verdict', 'anchor-change', 'outcome', 'pick', 'confirm', 'pilot-step']);

/**
 * The confidence floor for "confident". The detector seats at 0.42; a claim
 * at 0.45 is a seat but not a boast. 0.7 means the winner cleared the floor
 * by a margin nobody can call borderline. Override per call with
 * `{ confidentThreshold }` — the report always echoes the threshold it used.
 */
export const CONFIDENT_THRESHOLD = 0.7;

/** Refusal statuses: the detector declined to seat. `not-a-seat` (below
 *  floor, no candidates) and `refused` (ambiguous, document-field,
 *  cross-origin-frame) are both "did not guess". */
const REFUSAL_STATUSES = new Set(['refused', 'not-a-seat']);

export function hostOfUrl(url) {
  try {
    return new URL(url).host.toLowerCase() || '(invalid)';
  } catch {
    return '(invalid)';
  }
}

function isNonEmptyString(v) {
  return typeof v === 'string' && v.length > 0;
}

/**
 * Split raw log text into scorable records plus hygiene counts.
 *
 * A failed parse is `torn` only when it is the final line of an
 * unterminated file — the crash-mid-write case. Anywhere else it is
 * `corrupt`. The distinction matters because torn is expected damage and
 * corrupt is unexpected.
 */
export function parseAnchorsText(text) {
  const input = String(text ?? '');
  const endsWithNewline = input.endsWith('\n');
  const lines = input.split('\n');
  const records = [];
  let corrupt = 0;
  let torn = 0;
  let unknown = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const isLast = i === lines.length - 1;
    let rec = null;
    try {
      rec = JSON.parse(line);
    } catch {
      if (isLast && !endsWithNewline) torn += 1;
      else corrupt += 1;
      continue;
    }
    if (!rec || typeof rec !== 'object' || !KNOWN_TYPES.has(rec.type)) {
      unknown += 1;
      continue;
    }
    records.push(rec);
  }

  return { records, corrupt, torn, unknown, total: records.length + corrupt + torn + unknown };
}

function emptyReport(threshold) {
  return {
    threshold,
    verdicts: 0,
    seatedAuto: 0,
    seatedManual: 0,
    seatedBelowThreshold: 0,
    refused: 0,
    notASeat: 0,
    otherStatus: 0,
    /** Automatic seated verdicts at or above the threshold — the claim set. */
    confident: 0,
    /** Confident verdicts that can never join (no winner key, no url). */
    confidentUnjoinable: 0,
    rulings: 0,
    picks: 0,
    confirms: 0,
    cancelledPicks: 0,
    /** Confident verdicts carrying at least one ruling (last wins). */
    adjudicated: 0,
    agreed: 0,
    disagreed: 0,
    /** null when adjudicated is 0: unknown, never 0.0 by default. */
    confidentlyWrongRate: null,
    refusalResolutions: 0,
    unpairedRulings: 0,
    driftPairs: 0,
    outcomes: 0,
    outcomesOk: 0,
    outcomesFailed: 0,
    /** Weak signal only — counted here, never adjudicates (see header). */
    outcomeOkRate: null,
    /** `readback-mismatch` outcomes. Typing failed; the anchor may be fine. */
    typingFailures: 0,
    /** Pilot steps: the fliers' own record. Counted here so the flight
     *  recorder's lines never pollute `unknown`; never detector evidence. */
    pilotSteps: 0,
    pilotStepsOk: 0,
    pilotStepsRefused: 0,
    /** Weak signal only — counted here, never adjudicates (see header). */
    pilotOkRate: null,
    /** host -> { confident, adjudicated, agreed, disagreed, rate } */
    perHost: {},
  };
}

/**
 * Score parsed anchor records. See the header for the join and evidence
 * rules — the implementation below is those rules, nothing else.
 */
export function scoreFieldEvidence(records, opts = {}) {
  const threshold =
    typeof opts.confidentThreshold === 'number' && Number.isFinite(opts.confidentThreshold)
      ? opts.confidentThreshold
      : CONFIDENT_THRESHOLD;
  const report = emptyReport(threshold);
  const rows = Array.isArray(records) ? records : [];

  // url -> { lastStatus, confident: [{ key, ruling }] }
  const byUrl = new Map();
  const bucketFor = (url) => {
    let b = byUrl.get(url);
    if (!b) {
      b = { lastStatus: null, confident: [] };
      byUrl.set(url, b);
    }
    return b;
  };

  const noteUnpaired = (url) => {
    report.unpairedRulings += 1;
    const b = byUrl.get(url);
    if (b && REFUSAL_STATUSES.has(b.lastStatus)) report.refusalResolutions += 1;
  };

  for (const rec of rows) {
    if (!rec || typeof rec !== 'object') continue;
    const url = isNonEmptyString(rec.url) ? rec.url : null;

    if (rec.type === 'verdict') {
      report.verdicts += 1;
      if (url) bucketFor(url).lastStatus = rec.status || null;
      if (rec.status === 'seated') {
        if (rec.manual) {
          report.seatedManual += 1;
        } else {
          report.seatedAuto += 1;
          const confidence = Number(rec.confidence);
          if (!(confidence >= threshold)) {
            report.seatedBelowThreshold += 1;
          } else if (!url) {
            report.confidentUnjoinable += 1;
          } else {
            const key = rec.winner && isNonEmptyString(rec.winner.stabilityKey) ? rec.winner.stabilityKey : null;
            if (!key) {
              report.confidentUnjoinable += 1;
            } else {
              report.confident += 1;
              bucketFor(url).confident.push({ key, ruling: null });
            }
          }
        }
      } else if (rec.status === 'refused') {
        report.refused += 1;
      } else if (rec.status === 'not-a-seat') {
        report.notASeat += 1;
      } else {
        report.otherStatus += 1;
      }
      continue;
    }

    if (rec.type === 'pick') {
      if (!rec.ok) {
        report.cancelledPicks += 1; // Esc during picking: not a ruling.
        continue;
      }
      report.rulings += 1;
      report.picks += 1;
      const pickKey = rec.stamp && isNonEmptyString(rec.stamp.stabilityKey) ? rec.stamp.stabilityKey : null;
      if (!url || !pickKey) {
        report.unpairedRulings += 1;
        continue;
      }
      const list = bucketFor(url).confident;
      const target = list.length ? list[list.length - 1] : null;
      if (!target) {
        noteUnpaired(url);
        continue;
      }
      target.ruling = { agree: pickKey === target.key };
      continue;
    }

    if (rec.type === 'confirm') {
      report.rulings += 1;
      report.confirms += 1;
      const anchorKey = isNonEmptyString(rec.anchorKey) ? rec.anchorKey : null;
      if (!url || !anchorKey) {
        report.unpairedRulings += 1;
        continue;
      }
      const list = bucketFor(url).confident;
      let target = null;
      for (let i = list.length - 1; i >= 0; i--) {
        if (list[i].key === anchorKey) {
          target = list[i];
          break;
        }
      }
      if (!target) {
        noteUnpaired(url);
        continue;
      }
      target.ruling = { agree: !!rec.confirmed };
      continue;
    }

    if (rec.type === 'outcome') {
      report.outcomes += 1;
      if (rec.ok) report.outcomesOk += 1;
      else report.outcomesFailed += 1;
      if (rec.reason === 'readback-mismatch') report.typingFailures += 1;
      continue;
    }

    if (rec.type === 'anchor-change') {
      report.driftPairs += 1;
      continue;
    }

    if (rec.type === 'pilot-step') {
      report.pilotSteps += 1;
      if (rec.ok) report.pilotStepsOk += 1;
      else report.pilotStepsRefused += 1;
      continue;
    }
  }

  // Roll up adjudications, overall and per host. Last ruling wins was applied
  // during the walk by overwriting `ruling`.
  const perHost = new Map();
  const hostEntry = (host) => {
    let e = perHost.get(host);
    if (!e) {
      e = { confident: 0, adjudicated: 0, agreed: 0, disagreed: 0, rate: null };
      perHost.set(host, e);
    }
    return e;
  };

  for (const [url, b] of byUrl) {
    const host = hostOfUrl(url);
    const entry = hostEntry(host);
    for (const c of b.confident) {
      entry.confident += 1;
      if (!c.ruling) continue;
      report.adjudicated += 1;
      entry.adjudicated += 1;
      if (c.ruling.agree) {
        report.agreed += 1;
        entry.agreed += 1;
      } else {
        report.disagreed += 1;
        entry.disagreed += 1;
      }
    }
  }

  if (report.adjudicated > 0) report.confidentlyWrongRate = report.disagreed / report.adjudicated;
  if (report.outcomes > 0) report.outcomeOkRate = report.outcomesOk / report.outcomes;
  if (report.pilotSteps > 0) report.pilotOkRate = report.pilotStepsOk / report.pilotSteps;
  for (const entry of perHost.values()) {
    if (entry.adjudicated > 0) entry.rate = entry.disagreed / entry.adjudicated;
  }
  report.perHost = Object.fromEntries([...perHost.entries()].sort(([a], [b]) => (a < b ? -1 : 1)));

  return report;
}

/** The headline number, or null when no confident claim has been ruled on. */
export function confidentlyWrongRate(records, opts) {
  return scoreFieldEvidence(records, opts).confidentlyWrongRate;
}

/** Parse and score in one step; hygiene counts ride along in `lines`. */
export function scoreAnchorsText(text, opts) {
  const parsed = parseAnchorsText(text);
  const report = scoreFieldEvidence(parsed.records, opts);
  report.lines = { total: parsed.total, corrupt: parsed.corrupt, torn: parsed.torn, unknown: parsed.unknown };
  return report;
}

/**
 * Score the log file at `logPath`. A missing file is an empty report flagged
 * `logMissing` — a person who has never seated anything has no evidence yet,
 * which is a fact about the log, not a failure of the scorer.
 */
export async function scoreAnchorsFile(logPath, opts) {
  const { readFile } = await import('node:fs/promises');
  try {
    const text = await readFile(logPath, 'utf8');
    const report = scoreAnchorsText(text, opts);
    report.logPath = logPath;
    report.logMissing = false;
    return report;
  } catch (err) {
    if (err && err.code === 'ENOENT') {
      const report = scoreFieldEvidence([], opts);
      report.lines = { total: 0, corrupt: 0, torn: 0, unknown: 0 };
      report.logPath = logPath;
      report.logMissing = true;
      return report;
    }
    throw err;
  }
}

// ---------------------------------------------------------------- CLI
//   node src/field-evidence/scorer.mjs [path/to/anchors.jsonl]
// Prints the report as JSON. A missing path scores nothing and says so.

const invokedAsScript = (() => {
  try {
    return !!process.argv[1] && import.meta.url === new URL(`file://${process.argv[1]}`).href;
  } catch {
    return false;
  }
})();

if (invokedAsScript) {
  const target = process.argv[2] || null;
  const run = async () => {
    if (!target) {
      console.log(JSON.stringify(scoreAnchorsText('', {}), null, 2));
      return;
    }
    console.log(JSON.stringify(await scoreAnchorsFile(target, {}), null, 2));
  };
  run().catch((err) => {
    console.error(`scorer: ${err && err.message ? err.message : err}`);
    process.exitCode = 1;
  });
}
