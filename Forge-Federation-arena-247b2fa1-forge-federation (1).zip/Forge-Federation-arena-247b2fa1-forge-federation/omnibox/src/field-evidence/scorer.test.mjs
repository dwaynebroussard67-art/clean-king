/**
 * scorer.test.mjs — the field-evidence scorer, pinned down.
 *
 * The behaviors that matter, in the order the header of scorer.mjs states
 * them: confident claims vs tentative ones, human rulings as the only oracle,
 * outcomes and drift as counted-but-not-evidence, exact-url joins, and log
 * hygiene. Every refusal-shaped behavior (null rate, unpaired ruling) is a
 * test, because a scorer that invents evidence is worse than no scorer.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  CONFIDENT_THRESHOLD,
  confidentlyWrongRate,
  hostOfUrl,
  parseAnchorsText,
  scoreAnchorsFile,
  scoreAnchorsText,
  scoreFieldEvidence,
} from './scorer.mjs';

const URL = 'https://chat.example/room';
const OTHER_URL = 'https://other.example/chat';

/** A confident automatic seated verdict with winner key `key`. */
const seated = (key = 'k1', over = {}) => ({
  type: 'verdict',
  url: URL,
  trigger: 'load',
  status: 'seated',
  manual: false,
  confidence: 0.9,
  margin: 0.2,
  winner: { tag: 'div', stabilityKey: key },
  losers: [],
  ...over,
});

const refused = (over = {}) => ({
  type: 'verdict',
  url: URL,
  trigger: 'load',
  status: 'refused',
  verdictReason: 'ambiguous',
  manual: false,
  confidence: 0,
  margin: 0,
  tiedOn: ['anchored'],
  candidates: [{ stabilityKey: 'k1' }, { stabilityKey: 'k2' }],
  ...over,
});

const pick = (key, over = {}) => ({
  type: 'pick',
  url: URL,
  ok: true,
  stamp: { stabilityKey: key },
  ...over,
});

const confirm = (key, confirmed, over = {}) => ({
  type: 'confirm',
  url: URL,
  anchorKey: key,
  confirmed,
  source: 'sheet',
  ...over,
});

const outcome = (over = {}) => ({
  type: 'outcome',
  url: URL,
  runId: 'r1',
  anchorKey: 'k1',
  ok: true,
  reason: 'settled',
  ...over,
});

// ------------------------------------------------------------------ hygiene

test('1. an empty log scores zeros and refuses a rate (null, not 0.0)', () => {
  const r = scoreFieldEvidence([]);
  assert.equal(r.verdicts, 0);
  assert.equal(r.confident, 0);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.confidentlyWrongRate, null);
  assert.equal(confidentlyWrongRate([]), null);
});

test('2. a torn final line is dropped and counted, the rest scores', () => {
  const good = JSON.stringify(seated());
  const r = scoreAnchorsText(`${good}\n{"type":"verdict", "url":`);
  assert.equal(r.verdicts, 1);
  assert.equal(r.confident, 1);
  assert.equal(r.lines.torn, 1);
  assert.equal(r.lines.corrupt, 0);
  assert.equal(r.confidentlyWrongRate, null);
});

test('3. a corrupt middle line is counted and skipped, the rest scores', () => {
  const text = [JSON.stringify(seated()), 'not json at all', JSON.stringify(pick('k1'))].join('\n') + '\n';
  const r = scoreAnchorsText(text);
  assert.equal(r.lines.corrupt, 1);
  assert.equal(r.lines.torn, 0);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.agreed, 1);
  assert.equal(r.confidentlyWrongRate, 0);
});

test('4. unknown record types are counted and skipped, never scored', () => {
  const r = scoreAnchorsText(
    [JSON.stringify(seated()), JSON.stringify({ type: 'fingerprint-v9', url: URL }), JSON.stringify({})].join('\n') +
      '\n'
  );
  assert.equal(r.lines.unknown, 2);
  assert.equal(r.verdicts, 1);
  assert.equal(r.confident, 1);
  assert.equal(r.rulings, 0);
});

// ------------------------------------------------- the oracle and the rate

test('5. a confident seat with no ruling is unadjudicated: rate null', () => {
  const r = scoreFieldEvidence([seated()]);
  assert.equal(r.confident, 1);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.confidentlyWrongRate, null);
});

test('6. a pick agreeing with the winner adjudicates right (rate 0)', () => {
  const r = scoreFieldEvidence([seated('k1'), pick('k1')]);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.agreed, 1);
  assert.equal(r.disagreed, 0);
  assert.equal(r.confidentlyWrongRate, 0);
});

test('7. a pick disagreeing with the winner adjudicates wrong (rate 1)', () => {
  const r = scoreFieldEvidence([seated('k1'), pick('k9')]);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.agreed, 0);
  assert.equal(r.disagreed, 1);
  assert.equal(r.confidentlyWrongRate, 1);
});

test('8. a pick after a refusal is a refusal resolution, not a wrong seat', () => {
  const r = scoreFieldEvidence([refused(), pick('k1')]);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.disagreed, 0);
  assert.equal(r.confidentlyWrongRate, null);
  assert.equal(r.refusalResolutions, 1);
  assert.equal(r.unpairedRulings, 1);
});

test('9. confirm:true on the claimed key adjudicates right', () => {
  const r = scoreFieldEvidence([seated('k1'), confirm('k1', true)]);
  assert.equal(r.confirms, 1);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.agreed, 1);
  assert.equal(r.confidentlyWrongRate, 0);
});

test('10. confirm:false on the claimed key adjudicates wrong', () => {
  const r = scoreFieldEvidence([seated('k1'), confirm('k1', false)]);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.disagreed, 1);
  assert.equal(r.confidentlyWrongRate, 1);
});

test('11. manual verdicts are rulings, not claims: never confident, never rated', () => {
  const r = scoreFieldEvidence([seated('k1', { manual: true, confidence: 1 }), pick('k9')]);
  assert.equal(r.seatedManual, 1);
  assert.equal(r.confident, 0);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.unpairedRulings, 1);
  assert.equal(r.confidentlyWrongRate, null);
});

test('12. below-threshold seats are not confident, even when ruled on', () => {
  assert.ok(CONFIDENT_THRESHOLD > 0.42, 'threshold must clear the detector floor');
  const r = scoreFieldEvidence([seated('k1', { confidence: 0.45 }), pick('k9')]);
  assert.equal(r.seatedBelowThreshold, 1);
  assert.equal(r.confident, 0);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.unpairedRulings, 1);
  assert.equal(r.confidentlyWrongRate, null);
});

test('13. two rulings on one verdict adjudicate once, latest wins', () => {
  const r = scoreFieldEvidence([seated('k1'), confirm('k1', true), pick('k9')]);
  assert.equal(r.rulings, 2);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.disagreed, 1);
  assert.equal(r.agreed, 0);
  assert.equal(r.confidentlyWrongRate, 1);
});

test('14. a navigation breaks the join: ruling on another url is unpaired', () => {
  const r = scoreFieldEvidence([seated('k1'), pick('k1', { url: OTHER_URL })]);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.unpairedRulings, 1);
  assert.equal(r.confidentlyWrongRate, null);
});

// --------------------------------------- counted but never evidence

test('15. a successful outcome does not adjudicate (rate stays null)', () => {
  const r = scoreFieldEvidence([seated('k1'), outcome({ ok: true })]);
  assert.equal(r.outcomes, 1);
  assert.equal(r.outcomeOkRate, 1);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.confidentlyWrongRate, null);
});

test('16. a readback mismatch is a typing failure, not a wrong anchor', () => {
  const r = scoreFieldEvidence([seated('k1'), outcome({ ok: false, reason: 'readback-mismatch' })]);
  assert.equal(r.typingFailures, 1);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.confidentlyWrongRate, null);
});

test('17. per-host rates split: one host wrong, one host right', () => {
  const r = scoreFieldEvidence([
    seated('k1', { url: 'https://a.example/' }),
    pick('k9', { url: 'https://a.example/' }),
    seated('k2', { url: 'https://b.example/' }),
    pick('k2', { url: 'https://b.example/' }),
  ]);
  assert.equal(r.confidentlyWrongRate, 0.5);
  assert.equal(r.perHost['a.example'].rate, 1);
  assert.equal(r.perHost['b.example'].rate, 0);
  assert.equal(hostOfUrl('not a url'), '(invalid)');
});

// ------------------------------------------------- file convenience

test('18. scoreAnchorsFile flags a missing log instead of throwing', async () => {
  const r = await scoreAnchorsFile('/nonexistent-dir-omnibox/anchors.jsonl');
  assert.equal(r.logMissing, true);
  assert.equal(r.confidentlyWrongRate, null);
});

test('19. pilot steps count as flight records, never as detector evidence', () => {
  const r = scoreFieldEvidence([
    { type: 'pilot-step', url: URL, pilot: 'p1', step: 1, verb: 'click', ok: true, reason: null },
    { type: 'pilot-step', url: URL, pilot: 'p1', step: 2, verb: 'click', ok: false, reason: 'ambiguous-click' },
  ]);
  assert.equal(r.pilotSteps, 2);
  assert.equal(r.pilotStepsOk, 1);
  assert.equal(r.pilotStepsRefused, 1);
  assert.equal(r.pilotOkRate, 0.5);
  assert.equal(r.verdicts, 0);
  assert.equal(r.confidentlyWrongRate, null);
  const parsed = parseAnchorsText(
    '{"type":"pilot-step","url":"https://x.example/","verb":"click","ok":true}\n'
  );
  assert.equal(parsed.unknown, 0);
  assert.equal(parsed.records.length, 1);
});
