/**
 * teacher.js — a refusal is a lesson, but only under unanimity.
 *
 * The notebook already exists (`anchors.jsonl`): when two boxes are too
 * close, the log keeps the named tie and both stamps. This file is the
 * missing half. It reads those records, joins a later human pick, and
 * promotes a rule only when independent hosts agree and none contradict.
 *
 * A lesson is: "when candidates tie on these named signals, the human
 * consistently chose the one that scored higher on THIS other named
 * signal." Class, href, src and sibling index never become a lesson.
 * Conversation text never enters a lesson. suggest() is never applied.
 *
 * Provisional lessons are the notebook. Only a promoted lesson may break
 * a later tie, and only when that one signal uniquely separates the
 * crowd by the same margin detection already demands. If it does not,
 * the ordinary refusal stands.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { verifyAnchorLog } = require('../main/anchors.js');

const S =
  typeof module !== 'undefined' && module.exports
    ? require('../detector/signals.js')
    : globalThis.__FORGEFLIGHT_SIGNALS__;

const SIGNAL_NAMES = Object.keys((S && S.COMPOSER_WEIGHTS) || {});
/** Same threshold detection uses to call two signals "the same". */
const TIED_EPS = 0.05;
/** Distinct hosts required before a lesson may seat anyone. */
const MIN_HOSTS = 3;
/** Same as detect.js MIN_MARGIN — a lesson that cannot clear it is not unique. */
const MIN_MARGIN = 0.12;
const MAX_LESSONS = 200;

function hostOfUrl(url) {
  try {
    return new URL(url).host.toLowerCase() || '';
  } catch {
    return '';
  }
}

function tiedKey(tiedOn) {
  return (Array.isArray(tiedOn) ? tiedOn : [])
    .filter((s) => SIGNAL_NAMES.includes(s))
    .slice()
    .sort()
    .join(',');
}

function rawSignal(candidate, name) {
  return candidate && candidate.signals ? Number(candidate.signals[name]) : NaN;
}

/** Display/rank helper. A missing signal is never evidence — pickDiscriminator
 *  and applyLesson treat non-finite as ineligible, not as zero. */
function signalOf(candidate, name) {
  const v = rawSignal(candidate, name);
  return Number.isFinite(v) ? v : 0;
}

/**
 * The named signal that actually separated the human's pick from the
 * crowd. Signals the detector already called a tie are ineligible.
 * If several separate, the widest margin wins. If none do, the pick
 * is unexplained by the ten signals and cannot promote.
 */
function pickDiscriminator(winner, losers, tiedOn) {
  const tied = new Set(tiedOn || []);
  let best = null;
  let bestMargin = 0;
  for (const name of SIGNAL_NAMES) {
    if (tied.has(name)) continue;
    const wv = rawSignal(winner, name);
    // Same rule as signals.aggregate: a non-finite value makes this
    // feature ineligible, not zero. Zeroing a miss manufactures a margin.
    if (!Number.isFinite(wv)) continue;
    let maxL = -Infinity;
    let eligible = true;
    for (const loser of losers) {
      const v = rawSignal(loser, name);
      if (!Number.isFinite(v)) {
        eligible = false;
        break;
      }
      if (v > maxL) maxL = v;
    }
    if (!eligible || maxL === -Infinity) continue;
    const m = wv - maxL;
    if (m >= TIED_EPS && m > bestMargin) {
      bestMargin = m;
      best = name;
    }
  }
  return best;
}

function crowdOf(refusal) {
  const list = refusal.losers || refusal.candidates || [];
  return Array.isArray(list) ? list : [];
}

function exampleFrom(refusal, pick) {
  if (!refusal || !pick || !pick.ok) return null;
  const key = pick.stamp && typeof pick.stamp.stabilityKey === 'string' ? pick.stamp.stabilityKey : '';
  if (!key) return null;
  const crowd = crowdOf(refusal);
  const winner = crowd.find((c) => c && c.stabilityKey === key);
  if (!winner || !winner.signals) return null;
  const losers = crowd.filter((c) => c && c.stabilityKey !== key && c.signals);
  if (!losers.length) return null;
  const tiedOn = (Array.isArray(refusal.tiedOn) ? refusal.tiedOn : []).filter((s) => SIGNAL_NAMES.includes(s)).sort();
  const host = hostOfUrl(refusal.url);
  if (!host) return null;
  return {
    host,
    tiedOn,
    discriminator: pickDiscriminator(winner, losers, tiedOn),
    winnerKey: key,
  };
}

/**
 * Walk the engine-training log. A pick joins the most recent ambiguous
 * refusal on the exact same URL. A later seated/not-a-seat on that URL
 * without a pick abandons the pending refusal — the page moved on.
 */
function teach(records, opts = {}) {
  const minHosts = Number.isFinite(opts.minHosts) ? opts.minHosts : MIN_HOSTS;
  const rows = Array.isArray(records) ? records : [];
  const pending = new Map(); // url -> last ambiguous refusal
  const examples = [];
  let unresolved = 0;

  for (const rec of rows) {
    if (!rec || typeof rec !== 'object') continue;
    const url = typeof rec.url === 'string' && rec.url ? rec.url : null;
    if (!url) continue;

    if (rec.type === 'verdict') {
      if (rec.status === 'refused' && rec.verdictReason === 'ambiguous') {
        pending.set(url, rec);
      } else if (pending.has(url)) {
        unresolved += 1;
        pending.delete(url);
      }
      continue;
    }

    if (rec.type === 'pick') {
      const refusal = pending.get(url);
      pending.delete(url);
      if (!rec.ok) continue;
      const ex = exampleFrom(refusal, rec);
      if (ex) examples.push(ex);
      continue;
    }
  }
  unresolved += pending.size;

  const groups = new Map();
  for (const ex of examples) {
    const key = tiedKey(ex.tiedOn);
    if (!key) continue;
    let g = groups.get(key);
    if (!g) {
      g = { tiedOn: ex.tiedOn, examples: [] };
      groups.set(key, g);
    }
    g.examples.push(ex);
  }

  const lessons = [];
  for (const g of groups.values()) {
    const discs = [...new Set(g.examples.map((e) => e.discriminator))];
    const n = g.examples.length;
    const hosts = new Set(g.examples.map((e) => e.host));
    if (discs.length !== 1 || !discs[0]) {
      lessons.push({
        tiedOn: g.tiedOn,
        discriminator: null,
        status: 'blocked',
        n,
        hosts: hosts.size,
        blockedReason: discs.some((d) => d) ? 'contradiction' : 'unexplained',
      });
      continue;
    }
    const discriminator = discs[0];
    const hostCount = hosts.size;
    const status = hostCount >= minHosts ? 'promoted' : 'provisional';
    lessons.push({
      tiedOn: g.tiedOn,
      discriminator,
      status,
      n,
      hosts: hostCount,
      blockedReason: status === 'provisional' ? 'too-few-hosts' : null,
    });
  }

  lessons.sort((a, b) => b.n - a.n);
  const stats = {
    examples: examples.length,
    promoted: lessons.filter((l) => l.status === 'promoted').length,
    provisional: lessons.filter((l) => l.status === 'provisional').length,
    blocked: lessons.filter((l) => l.status === 'blocked').length,
    unresolved,
  };
  return { examples, lessons, unresolved, stats };
}

function parseRecords(text) {
  const records = [];
  for (const line of String(text || '').split('\n')) {
    if (!line.trim()) continue;
    try {
      const rec = JSON.parse(line);
      if (rec && typeof rec === 'object' && rec.type) records.push(rec);
    } catch {
      /* torn or corrupt: skip, same posture as the scorer */
    }
  }
  return records;
}

function teachFromText(text, opts) {
  return teach(parseRecords(text), opts);
}

function emptyTeach(extra) {
  return {
    examples: [],
    lessons: [],
    unresolved: 0,
    stats: { examples: 0, promoted: 0, provisional: 0, blocked: 0, unresolved: 0 },
    ...extra,
  };
}

function teachFromFile(logPath, opts) {
  try {
    const verification = verifyAnchorLog(logPath);
    if (!verification.ok) {
      const first = verification.breaks[0] || {};
      return emptyTeach({
        refused: true,
        reason: 'chain-break',
        detail: `Integrity failure in anchor log at line ${first.line}: ${first.kind}`,
        firstBreakAt: first.line || null,
        chain: verification,
      });
    }
    return teachFromText(fs.readFileSync(logPath, 'utf8'), opts);
  } catch (e) {
    if (e && e.code === 'ENOENT') return teach([], opts);
    throw e;
  }
}

/**
 * Break a detection tie only when a promoted lesson uniquely separates
 * the crowd on its named discriminator. A miss is null — the caller
 * leaves the ordinary refusal standing.
 *
 * `candidates` are scored composer objects (`signals` required).
 */
function applyLesson(candidates, tiedOn, lessons, opts = {}) {
  if (!Array.isArray(candidates) || candidates.length < 2) return null;
  if (!Array.isArray(lessons) || !lessons.length) return null;
  const key = tiedKey(tiedOn);
  if (!key) return null;
  const lesson = lessons.find((l) => l && l.status === 'promoted' && tiedKey(l.tiedOn) === key && l.discriminator);
  if (!lesson) return null;
  const d = lesson.discriminator;
  if (!SIGNAL_NAMES.includes(d)) return null;
  const need = Number.isFinite(opts.minMargin) ? opts.minMargin : MIN_MARGIN;
  const floor = Number.isFinite(opts.minScore) ? opts.minScore : 0;
  const rankedAgg = [...candidates].sort((a, b) => Number(b && b.score) - Number(a && a.score));
  const top = Number(rankedAgg[0] && rankedAgg[0].score);
  if (!Number.isFinite(top)) return null;
  // The tie is closeness on the aggregate — the same gap that made detection
  // refuse — not "anyone who cleared the floor." A fourth-place box that
  // merely beats MIN_SCORE was never in this argument. Top-two-only would
  // be too narrow: a genuine three-way close crowd is one tie.
  const pool = rankedAgg.filter((c) => {
    const s = Number(c && c.score);
    if (!Number.isFinite(s)) return false;
    if (floor > 0 && s < floor) return false;
    return top - s <= need;
  });
  if (pool.length < 2) return null;
  if (pool.some((c) => !Number.isFinite(rawSignal(c, d)))) return null;
  const ranked = [...pool].sort((a, b) => signalOf(b, d) - signalOf(a, d));
  const margin = signalOf(ranked[0], d) - signalOf(ranked[1], d);
  if (margin < need) return null;
  return { winner: ranked[0], lesson, margin };
}

function cleanLesson(l) {
  if (!l || typeof l !== 'object') return null;
  const tiedOn = Array.isArray(l.tiedOn) ? l.tiedOn.filter((s) => SIGNAL_NAMES.includes(s)).sort() : [];
  const discriminator = SIGNAL_NAMES.includes(l.discriminator) ? l.discriminator : null;
  const status = l.status === 'promoted' || l.status === 'provisional' || l.status === 'blocked' ? l.status : null;
  if (!status) return null;
  return {
    tiedOn,
    discriminator,
    status,
    n: Number.isFinite(l.n) ? l.n : 0,
    hosts: Number.isFinite(l.hosts) ? l.hosts : 0,
    blockedReason: typeof l.blockedReason === 'string' ? l.blockedReason.slice(0, 40) : null,
  };
}

class LessonStore {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'lessons.json');
    this.data = this.load();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const lessons = Array.isArray(raw && raw.lessons) ? raw.lessons.map(cleanLesson).filter(Boolean) : [];
      return { version: 1, lessons: lessons.slice(0, MAX_LESSONS) };
    } catch {
      return { version: 1, lessons: [] };
    }
  }

  replace(lessons) {
    const clean = (Array.isArray(lessons) ? lessons : []).map(cleanLesson).filter(Boolean).slice(0, MAX_LESSONS);
    this.data = { version: 1, savedAt: new Date().toISOString(), lessons: clean };
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2), 'utf8');
    } catch {
      /* a lesson that fails to persist is retried on the next refusal */
    }
    return this.data;
  }

  promoted() {
    return this.data.lessons.filter((l) => l.status === 'promoted');
  }
}

const API = {
  SIGNAL_NAMES,
  MIN_HOSTS,
  MIN_MARGIN,
  TIED_EPS,
  teach,
  teachFromText,
  teachFromFile,
  applyLesson,
  pickDiscriminator,
  LessonStore,
  cleanLesson,
};

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_TEACHER__ = API;
