/**
 * seat.js — the tab-side agent. Runs in every tab Forge Flight opens.
 *
 * This is the whole "automatically links to AIs you open" mechanism. There is
 * no boarding step, no provider picker, no API key. You open a page; this
 * looks at it; if it is a chat surface the tab becomes a seat at the table.
 * If it is not, the tab is just a tab. If it is *ambiguous*, the tab says so
 * and offers you a click to settle it — it never guesses.
 *
 * Isolation: this runs in Electron's isolated world. It can touch the DOM.
 * It exposes NOTHING to the page — no contextBridge surface at all — so the
 * page cannot reach Node, cannot reach IPC, and cannot see that it is seated.
 */

'use strict';

const { ipcRenderer } = require('electron');
const { detectComposer, findEditableByStamp, reanchorEditable } = require('../detector/detect.js');
const { stampOf } = require('../detector/stamp.js');
const { stamp, capture } = require('../detector/reanchor.js');
const { setComposerText, submit, readComposer } = require('./inject.js');
const { watchResponse } = require('./watch.js');

const OVERLAY_ATTR = 'data-forgeflight-chrome';

let current = null; // { composer, send, verdict, fp }
let manualPick = null; // an element the user chose by hand, this load
let rememberedPick = null; // { stabilityKey, host } — a pick from a previous load
let lessons = []; // promoted lessons only; main never sends provisional
let booted = false;
let redetectTimer = null;
let busy = false;

// --------------------------------------------------------------------------
// Detection
// --------------------------------------------------------------------------

function describeVerdict(v) {
  if (v.ok) {
    return {
      status: 'seated',
      confidence: v.confidence,
      margin: v.margin,
      signals: v.signals,
      hasSend: !!v.send,
      detail: v.detail,
      // The winners and the losers, stamped — engine-training records are
      // made of exactly this, and a correct choice with a close runner-up
      // matters as much as a refusal.
      anchor: stampOf(v.composer, { signals: v.signals, score: v.confidence }),
      sendAnchor: stampOf(v.send, { sendScore: v.sendScore || null }),
      candidates: v.candidates || [],
      lessonApplied: v.lessonApplied || null,
    };
  }
  return {
    status: v.reason === 'no-candidates' || v.reason === 'below-floor' ? 'not-a-seat' : 'refused',
    verdictReason: v.reason,
    detail: v.detail,
    tiedOn: v.tiedOn || [],
    candidates: v.candidates || [],
    confidence: 0,
    signals: null,
  };
}

/** Badge the live composer so a later mutation can re-find it uniquely.
 *  stampOf for records happens first — the engine badge must not change
 *  the join key we already wrote. */
function hold(el, extra) {
  if (!el) return extra;
  try {
    stamp(el);
    extra.fp = capture(el);
  } catch {
    extra.fp = extra.fp || null;
  }
  return extra;
}

function runDetection(reason = 'auto') {
  if (busy) return;

  // Same load, page moved: the engine re-finds the composer we already held.
  // A miss falls through to detection. suggest() is never applied.
  if (current && current.fp && (reason === 'mutation' || (current.composer && !current.composer.isConnected))) {
    try {
      const hit = reanchorEditable(document, current.fp);
      if (hit) {
        const anchor = stampOf(hit, { signals: null, score: 1, reanchored: true });
        current.composer = hit;
        current = hold(hit, current);
        ipcRenderer.send('seat:status', {
          status: 'seated',
          confidence: 1,
          margin: 1,
          manual: !!manualPick,
          restored: !!current.restored,
          hasSend: !!current.send,
          detail: 'Composer re-found after the page moved.',
          signals: null,
          anchor,
          candidates: [],
          reason,
        });
        return;
      }
    } catch {
      /* ordinary detection below */
    }
  }

  let verdict;
  try {
    verdict = detectComposer(document, { lessons });
  } catch (e) {
    verdict = { ok: false, reason: 'below-floor', candidates: [], detail: `Detector error: ${e.message}` };
  }

  if (manualPick && manualPick.isConnected) {
    // A hand-picked composer outranks detection until the page navigates.
    const sendGuess = verdict.ok ? verdict.send : null;
    const anchor = stampOf(manualPick, { signals: null, score: 1, manual: true });
    current = hold(manualPick, { composer: manualPick, send: sendGuess, verdict: { ok: true } });
    ipcRenderer.send('seat:status', {
      status: 'seated',
      confidence: 1,
      margin: 1,
      manual: true,
      hasSend: !!sendGuess,
      detail: 'Composer chosen by hand.',
      signals: null,
      anchor,
      candidates: [],
      reason,
    });
    return;
  }

  // A pick from a previous load of this site. It is a hint, never a verdict:
  // it applies only to an element that is on this page right now and whose
  // recomputed stamp matches the remembered key exactly. Detection already
  // chose that element, or something that matches it, means nothing to do.
  // A key that matches nothing is reported by name and the ordinary verdict
  // stands — for an ambiguous page that means the refusal and the Pick button
  // come back, which is the only honest answer after a redesign.
  let pickMissing = false;
  // The ruling travels with the host it was made on. Checking it against the
  // page actually being looked at means a pick can never be replayed onto a
  // different site, however the tab got here.
  const onHost =
    rememberedPick &&
    rememberedPick.stabilityKey &&
    (!rememberedPick.host || String(location.host || '').toLowerCase() === rememberedPick.host);
  if (onHost) {
    let autoKey = null;
    try {
      autoKey = verdict.ok ? stampOf(verdict.composer).stabilityKey : null;
    } catch {
      autoKey = null;
    }
    if (autoKey !== rememberedPick.stabilityKey) {
      const el = findEditableByStamp(document, rememberedPick.stabilityKey);
      if (el) {
        const sendGuess = verdict.ok ? verdict.send : null;
        const anchor = stampOf(el, { signals: null, score: 1, manual: true, restored: true });
        current = hold(el, { composer: el, send: sendGuess, verdict: { ok: true }, restored: true });
        ipcRenderer.send('seat:status', {
          status: 'seated',
          confidence: 1,
          margin: 1,
          manual: true,
          restored: true,
          hasSend: !!sendGuess,
          detail: 'Composer restored from your pick on this site.',
          signals: null,
          anchor,
          candidates: [],
          reason,
        });
        return;
      }
      pickMissing = true;
    }
  }

  const described = describeVerdict(verdict);
  current = verdict.ok ? hold(verdict.composer, { composer: verdict.composer, send: verdict.send, verdict }) : null;
  ipcRenderer.send('seat:status', { ...described, reason, pickMissing });
}

function scheduleRedetect(delay = 400) {
  clearTimeout(redetectTimer);
  redetectTimer = setTimeout(() => runDetection('mutation'), delay);
}

// --------------------------------------------------------------------------
// Sending
// --------------------------------------------------------------------------

ipcRenderer.on('seat:send', async (_e, { runId, text, settleMs, timeoutMs }) => {
  if (busy) {
    ipcRenderer.send('seat:result', { runId, ok: false, reason: 'busy', detail: 'This seat is still answering.' });
    return;
  }
  if (!current || !current.composer || !current.composer.isConnected) {
    runDetection('pre-send');
    if (!current) {
      ipcRenderer.send('seat:result', {
        runId,
        ok: false,
        reason: 'not-seated',
        detail: 'Forge Flight has not identified a composer on this page, so it will not type into it.',
      });
      return;
    }
  }

  busy = true;
  ipcRenderer.send('seat:state', { runId, phase: 'typing' });

  const typed = setComposerText(current.composer, text);
  if (!typed.ok) {
    busy = false;
    ipcRenderer.send('seat:result', {
      runId,
      ok: false,
      reason: typed.reason,
      detail: typed.detail || 'The composer did not accept the prompt.',
      attempts: typed.attempts,
    });
    return;
  }

  // Watch BEFORE submitting, so the first token cannot be missed.
  // The reply arrives in the composer's own document — which is a subframe's
  // document when the chat is embedded in a same-origin iframe.
  const scope = current.composer.ownerDocument || document;
  const watching = watchResponse(scope, {
    ignore: [current.composer],
    // The composer anchors the landmark carve-out: a region that contains
    // the composer may legitimately contain the conversation too.
    composer: current.composer,
    settleMs: settleMs || 1200,
    timeoutMs: timeoutMs || 240000,
    onChunk: (t) => ipcRenderer.send('seat:chunk', { runId, text: t }),
  });

  ipcRenderer.send('seat:state', { runId, phase: 'sending', strategy: typed.strategy });

  // Give a controlled composer a frame to enable its send button.
  await new Promise((r) => setTimeout(r, 90));
  const sent = submit(current.composer, current.send);
  if (!sent.ok) {
    busy = false;
    ipcRenderer.send('seat:result', {
      runId,
      ok: false,
      reason: sent.reason,
      detail:
        sent.reason === 'send-disabled'
          ? 'The page kept its send control disabled, so Forge Flight did not force a submit.'
          : 'Forge Flight could not press send on this page.',
    });
    return;
  }

  ipcRenderer.send('seat:state', { runId, phase: 'waiting', via: sent.via });

  const result = await watching;
  busy = false;
  ipcRenderer.send('seat:result', {
    runId,
    ok: result.text.length > 0,
    reason: result.text.length ? result.reason : 'empty-response',
    text: result.text,
    elapsedMs: result.elapsedMs,
    strategy: typed.strategy,
    via: sent.via,
    detail:
      result.reason === 'timeout'
        ? 'The reply never stopped growing; Forge Flight returned what it had rather than truncating it silently.'
        : '',
  });
});

// --------------------------------------------------------------------------
// Manual pick — the resolution path for a refused seat.
// --------------------------------------------------------------------------

let picker = null;

function stopPicking() {
  if (!picker) return;
  document.removeEventListener('mousemove', picker.move, true);
  document.removeEventListener('click', picker.click, true);
  document.removeEventListener('keydown', picker.key, true);
  picker.box.remove();
  picker.hint.remove();
  picker = null;
}

function startPicking() {
  if (picker) return;
  const box = document.createElement('div');
  box.setAttribute(OVERLAY_ATTR, '');
  Object.assign(box.style, {
    position: 'fixed',
    pointerEvents: 'none',
    zIndex: '2147483646',
    border: '2px solid #ff5500',
    background: 'rgba(255,85,0,.12)',
    borderRadius: '6px',
    transition: 'all 60ms linear',
    display: 'none',
  });
  const hint = document.createElement('div');
  hint.setAttribute(OVERLAY_ATTR, '');
  hint.textContent = 'Click the box you type your prompt into  ·  Esc to cancel';
  Object.assign(hint.style, {
    position: 'fixed',
    left: '50%',
    top: '16px',
    transform: 'translateX(-50%)',
    zIndex: '2147483647',
    background: '#11141a',
    color: '#e6e9ef',
    border: '1px solid #ff5500',
    borderRadius: '999px',
    padding: '8px 16px',
    font: '13px system-ui,sans-serif',
    pointerEvents: 'none',
    boxShadow: '0 8px 32px rgba(0,0,0,.6)',
  });
  document.documentElement.append(box, hint);

  // `elementFromPoint` stops at a shadow host; composedPath() reaches the
  // element the person is actually pointing at, inside a web component.
  const deepTarget = (e) => {
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    const start = path[0] || document.elementFromPoint(e.clientX, e.clientY);
    let n = start;
    let hops = 0;
    while (n && hops < 40) {
      if (n.matches && n.matches('textarea, input, [contenteditable], [role="textbox"]')) return n;
      n = n.parentElement || (n.parentNode && n.parentNode.host) || null;
      hops++;
    }
    return null;
  };

  const move = (e) => {
    const target = deepTarget(e);
    if (!target) {
      box.style.display = 'none';
      return;
    }
    const r = target.getBoundingClientRect();
    Object.assign(box.style, {
      display: 'block',
      left: `${r.x - 2}px`,
      top: `${r.y - 2}px`,
      width: `${r.width}px`,
      height: `${r.height}px`,
    });
  };
  const click = (e) => {
    const target = deepTarget(e);
    e.preventDefault();
    e.stopPropagation();
    if (!target) return;
    manualPick = target;
    stopPicking();
    // The human ruling carries the stamp of what was picked — a person
    // adjudicating a live page is the strongest label there is. Main keeps it
    // (picks.js) so the next load of this site starts from the ruling instead
    // of asking again.
    const picked = stampOf(target, { pickedBy: 'human' });
    rememberedPick = { stabilityKey: picked.stabilityKey, host: String(location.host || '').toLowerCase() };
    ipcRenderer.send('seat:picked', { ok: true, tag: target.tagName.toLowerCase(), stamp: picked });
    runDetection('manual');
  };
  const key = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      stopPicking();
      ipcRenderer.send('seat:picked', { ok: false, reason: 'cancelled' });
    }
  };

  document.addEventListener('mousemove', move, true);
  document.addEventListener('click', click, true);
  document.addEventListener('keydown', key, true);
  picker = { box, hint, move, click, key };
}

ipcRenderer.on('seat:pick', () => startPicking());
ipcRenderer.on('seat:unpick', () => {
  manualPick = null;
  // Unpicking here also retires the remembered pick for this site, so the
  // next load starts from detection again instead of replaying a ruling the
  // person has just withdrawn.
  rememberedPick = null;
  ipcRenderer.send('seat:forgetPick');
  stopPicking();
  runDetection('unpick');
});
ipcRenderer.on('seat:redetect', () => runDetection('manual-refresh'));

// The ruling from a previous load, if there is one. Asked for as early as the
// preload runs, so it is normally in hand before the first detection; if it
// arrives late, detection runs again with it.
ipcRenderer.on('seat:rememberedPick', (_e, pick) => {
  const key = pick && typeof pick.stabilityKey === 'string' ? pick.stabilityKey : null;
  if (!key || (rememberedPick && rememberedPick.stabilityKey === key)) return;
  rememberedPick = {
    stabilityKey: key,
    host: pick && typeof pick.host === 'string' ? pick.host.toLowerCase() : null,
  };
  if (booted) runDetection('restored');
});
ipcRenderer.send('seat:askPick');

// Promoted lessons from earlier refusals. Held here and passed into
// detection; a later matching tie may seat, a miss leaves the refusal.
ipcRenderer.on('seat:lessons', (_e, list) => {
  lessons = Array.isArray(list) ? list : [];
  if (booted) runDetection('lessons');
});
ipcRenderer.send('seat:askLessons');

// A live read of the composer, for the "what will actually be sent" preview.
ipcRenderer.on('seat:peek', (_e, { runId }) => {
  ipcRenderer.send('seat:peeked', {
    runId,
    text: current && current.composer ? readComposer(current.composer).slice(0, 500) : null,
  });
});

// --------------------------------------------------------------------------
// Lifecycle
// --------------------------------------------------------------------------

function boot() {
  booted = true;
  runDetection('load');
  // Chat apps hydrate late and re-render constantly. Re-detect on a debounce
  // rather than on every mutation, and re-detect once more after the app has
  // had time to settle — the first paint of a chat app rarely has a composer.
  const mo = new MutationObserver(() => {
    if (busy || picker) return;
    scheduleRedetect(600);
  });
  mo.observe(document.documentElement, { subtree: true, childList: true });
  setTimeout(() => runDetection('settle-1'), 1200);
  setTimeout(() => runDetection('settle-2'), 3500);
  window.addEventListener('resize', () => scheduleRedetect(300));
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}
