/**
 * watch.js — capture a streamed reply without knowing whose page this is.
 *
 * No selectors, no provider names, no `.message-content` guesses. The reply is
 * found the way a person finds it: it is the part of the page that keeps
 * growing after you press send, and it stops growing when the model is done.
 *
 * Three properties matter and all three are enforced here:
 *   1. TIGHTEST CONTAINER. Growth propagates to every ancestor up to <body>,
 *      so the naive "most-changed element" is always <body>.
 *   2. THE REPLY, NOT YOUR OWN ECHO. Most chat pages append your message and
 *      the reply to the same thread, so "the thing that grew most" is the
 *      thread — and the captured answer starts with your own prompt read back
 *      at you. The discriminator is TIME, not size: your message appears once
 *      and stops; the reply keeps growing until the model is done. Keep only
 *      what was still growing at the end, then take the deepest.
 *   3. SETTLE, DON'T GUESS. Completion is "no growth for settleMs", not a
 *      spinner class. If it never settles we return what we have and say
 *      `timeout` — never silently truncate and call it an answer.
 *
 * And a fourth, added 2026-08-27 after a real passport export showed three
 * providers captured, zero replies:
 *   4. FURNITURE IS NOT A REPLY. Growth that is a reaction to the click
 *      (<500ms), growth inside a nav/aside/menu region, and growth whose
 *      capture would start mid-word are demoted: they can never win, never
 *      settle the watch, and never satisfy an empty capture. An empty result
 *      is an honest named refusal; furniture as the answer is a poisoned
 *      outcome witness.
 */

'use strict';

// --------------------------------------------------------------------------
// Named defences, each with its reason. All five exist because of one
// passport export dated 2026-08-27: three real providers, three captures,
// zero replies — a sidebar title, an account menu, and a mid-word slice of
// furniture text all settled as "the answer" and were ingested as outcome
// witnesses. A wrong capture is not a small bug; it poisons the store at
// intake.
// --------------------------------------------------------------------------

/** Growth that lands WHOLE within half a second of the watch starting is a
 *  reaction to the click, not a reply: the prompt echo, a menu opening, a
 *  sidebar retitling itself. No remote model answers that fast — network
 *  and inference alone cost more.
 *
 *  The rule is deliberately early-AND-whole, not merely early: a LOCAL
 *  model on the same machine can stream its first token in well under
 *  500ms, and a stream that is still growing past the window is a reply,
 *  not a menu. Furniture lands in one piece inside the window; a fast
 *  stream crosses its far edge still growing. Fixtures use a 600ms first
 *  token; the local seat deliberately starts sooner to pin the
 *  distinction. */
const REACTION_MS = 500;

/** Page regions that never carry a reply: sidebars, nav bars, account menus,
 *  dialogs, tooltips, listbox dropdowns. These are HTML landmark tags and
 *  ARIA roles — structure, not provider selectors. The one carve-out: if the
 *  composer itself sits inside the landmark, the conversation may too, and
 *  the landmark does not demote anything. */
const LANDMARK_SELECTOR = [
  'aside', 'nav', 'header', 'footer',
  '[role="navigation"]', '[role="complementary"]', '[role="banner"]', '[role="contentinfo"]',
  '[role="menu"]', '[role="menubar"]', '[role="dialog"]', '[role="alertdialog"]',
  '[role="tooltip"]', '[role="listbox"]',
].join(', ');

/** A candidate whose captured text would start in the middle of a word —
 *  "organ|ization billing" — is a baseline taken mid-update, never a reply.
 *  Real appends land on text boundaries; the echo case ends on whitespace or
 *  punctuation. A mid-word slice is furniture by construction. */

/** The watch may not settle on the first thing that grows, because furniture
 *  arrives whole in one chunk and a reply streams. Settling early requires
 *  streaming (several chunks), a whole-delivered reply (substantial length),
 *  or the grace period having passed with at least a short-but-real text. */
const STREAM_CHUNKS = 3;
const SUBSTANTIAL_CHARS = 240;   // a reply delivered unstreamed is long
const SHORT_SETTLE_CHARS = 64;   // after grace, a short one-shot text may settle
const FIRST_TOKEN_GRACE_MS = 2500;

/** Priming covers every element, not only small containers. The old
 *  `< 40 children` gap left big containers unprimed until the first
 *  mutation touched them — which baselined them mid-update and produced
 *  mid-word slices. Very large pages are capped so priming stays bounded. */
const PRIME_CAP = 20000;

function textOf(el) {
  const t = el && (el.innerText != null ? el.innerText : el.textContent);
  return t == null ? '' : String(t);
}

/** Parent that crosses a shadow boundary: a root's parent is its host. */
function parentOf(el) {
  if (!el) return null;
  if (el.parentElement) return el.parentElement;
  const root = el.parentNode;
  return root && root.host ? root.host : null;
}

/** `closest`, climbing out of shadow roots. */
function closestDeep(el, selector) {
  let n = el;
  let hops = 0;
  while (n && n.nodeType === 1 && hops < 40) {
    if (n.matches && n.matches(selector)) return n;
    n = parentOf(n);
    hops++;
  }
  return null;
}

function depthOf(el) {
  let d = 0;
  let n = parentOf(el);
  while (n && d < 200) {
    n = parentOf(n);
    d++;
  }
  return d;
}

/** Every open shadow root under a node. A MutationObserver on the document
 *  does not see inside a shadow root, so a reply rendered by a web component
 *  is invisible unless each root is observed in its own right. */
function shadowRootsUnder(node, cap = 3000) {
  const out = [];
  const stack = [node];
  let seen = 0;
  while (stack.length) {
    const n = stack.pop();
    if (!n || !n.querySelectorAll) continue;
    for (const el of n.querySelectorAll('*')) {
      if (++seen > cap) return out;
      if (el.shadowRoot) {
        out.push(el.shadowRoot);
        stack.push(el.shadowRoot);
      }
    }
  }
  return out;
}

/** Never-track: page furniture that carries no answer. */
function isFurniture(el) {
  if (!el || el.nodeType !== 1) return true;
  const tag = el.tagName.toLowerCase();
  if (tag === 'script' || tag === 'style' || tag === 'noscript' || tag === 'head' || tag === 'title') return true;
  if (el.getAttribute && el.getAttribute('data-forgeflight-chrome') != null) return true;
  return false;
}

/** The composer and everything inside it. Typing is not an answer.
 *  An ANCESTOR that merely contains the composer is still trackable — many
 *  layouts put the thread and the composer in one column. */
function inIgnored(el, ignore) {
  for (const ig of ignore) if (ig && ig.contains && ig.contains(el)) return true;
  return false;
}

/**
 * @param {Document} doc
 * @param {{onChunk?:(text:string)=>void, settleMs?:number, timeoutMs?:number,
 *          ignore?:Element[], minLength?:number}} [opts]
 * @returns {Promise<{text:string, reason:'settled'|'timeout'|'aborted', el:Element|null,
 *                    growth:number, elapsedMs:number}>}
 */
function watchResponse(doc, opts = {}) {
  const settleMs = opts.settleMs ?? 900;
  const timeoutMs = opts.timeoutMs ?? 180000;
  const minLength = opts.minLength ?? 1;
  const ignore = (opts.ignore || []).filter(Boolean);
  const composerEl = opts.composer || null; // for the landmark carve-out
  const onChunk = typeof opts.onChunk === 'function' ? opts.onChunk : null;
  const started = Date.now();

  // Baseline text length for every element we will end up tracking.
  const baseline = new Map();
  const seen = new Set();
  const lastChange = new Map(); // element -> when its text last got longer
  const lastLen = new Map();
  const firstGrowth = new Map(); // element -> when it first grew after the watch started

  function baseOf(el) {
    if (!baseline.has(el)) baseline.set(el, textOf(el).length);
    return baseline.get(el);
  }

  // Prime the baseline for the current document so pre-existing text never
  // counts as growth. Shadow content is primed too, or a web component's
  // existing text would look like it all arrived at once. Every element is
  // primed, up to PRIME_CAP — see the note on mid-word slices above.
  const roots = doc.body ? [doc.body, ...shadowRootsUnder(doc.body)] : [];
  for (const root of roots) {
    let primed = 0;
    for (const el of root.querySelectorAll('*')) {
      if (++primed > PRIME_CAP) break;
      baseline.set(el, textOf(el).length);
    }
  }
  if (doc.body) baseline.set(doc.body, textOf(doc.body).length);

  return new Promise((resolve) => {
    let lastGrowthAt = Date.now();
    let lastEmitted = '';
    let chunksEmitted = 0;
    let finished = false;
    let observer = null;
    let settleTimer = null;
    let rescanTimer = null;
    let hardTimer = null;

    /**
     * Pick the reply, not the echo of your own prompt, and not the furniture.
     *
     * Growth alone picks the thread container, because the thread contains
     * both your message and the reply. The discriminator is TIME: your
     * message appears once and then stops; the reply keeps growing until the
     * model is done. So among everything that grew, keep only what was STILL
     * growing at the end, and of those take the deepest — the tightest
     * container that is actually the answer.
     *
     * Before any of that, three named kinds of growth are DEMOTED — they can
     * never win and can never settle the watch:
     *   reaction  it began within REACTION_MS of the watch starting
     *   landmark  it lives in a nav/aside/header/footer/menu/dialog region
     *             that does not contain the composer
     *   mid-word  its captured text would start mid-word ("organ|ization"),
     *             which is a baseline taken mid-update and never a reply
     * Demoted growth is not returned at the end either: a capture of
     * furniture is worse than no capture, because an empty result is an
     * honest, named refusal and furniture is a poisoned outcome witness.
     */
    function currentBest() {
      let grew = [];
      for (const el of seen) {
        if (!el.isConnected) continue;
        const full = textOf(el);
        const g = full.length - baseOf(el);
        if (g <= 0) continue;
        grew.push({ el, growth: g, at: lastChange.get(el) || 0, depth: depthOf(el), full });
      }
      if (grew.length === 0) return { el: null, growth: 0 };

      for (const c of grew) {
        const why = [];
        // Reaction = landed whole inside the window (first AND last growth
        // both early). A stream that started early and kept growing is a
        // fast reply — almost certainly the local seat — and is kept.
        const t0 = firstGrowth.get(c.el) ?? started;
        const t1 = lastChange.get(c.el) ?? t0;
        if (t0 - started < REACTION_MS && t1 - started < REACTION_MS) why.push('reaction');
        const lm = closestDeep(c.el, LANDMARK_SELECTOR);
        if (lm && !(composerEl && lm.contains(composerEl))) why.push('landmark');
        const b = baseOf(c.el);
        if (b > 0 && b < c.full.length && /\S/.test(c.full[b - 1]) && /\S/.test(c.full[b])) {
          why.push('mid-word');
        }
        c.demoted = why;
      }

      // Furniture pulls its own ancestry down with it: an element whose
      // LATEST growth is the furniture's (it has not grown since the
      // furniture stopped) is a wrapper around furniture, not a reply —
      // even when its own slice happens to start on a word boundary and
      // its timestamps straddle the reaction window. The moment something
      // real grows inside that ancestry, its lastChange moves past the
      // furniture's and it is eligible again. Recomputed on every pass, so
      // the demotion self-heals.
      {
        const byEl = new Map(grew.map((c) => [c.el, c]));
        for (const c of grew) {
          if (!c.demoted.length) continue;
          let n = parentOf(c.el);
          let hops = 0;
          while (n && hops < 40) {
            const a = byEl.get(n);
            if (a) {
              if ((a.at || 0) > (c.at || 0)) break; // real growth happened here after the furniture
              if (!a.demoted.includes('furniture-line')) a.demoted.push('furniture-line');
            }
            n = parentOf(n);
            hops++;
          }
        }
      }

      let eligible = grew.filter((c) => c.demoted.length === 0);
      if (eligible.length === 0) return { el: null, growth: 0 };

      // A live clock, a token counter or a virtualised row rewriting "rev 9"
      // as "rev 10" grows by one character forever. Trivial growth cannot win
      // the reply — but if trivial growth is ALL there is, we still return it
      // rather than pretending nothing happened.
      const MIN_CANDIDATE_GROWTH = 8;
      const substantial = eligible.filter((c) => c.growth >= MIN_CANDIDATE_GROWTH);
      if (substantial.length) eligible = substantial;

      let latest = 0;
      for (const c of eligible) latest = Math.max(latest, c.at);
      const STILL_GROWING_MS = 400;
      let live = eligible.filter((c) => c.at >= latest - STILL_GROWING_MS);
      if (live.length === 0) live = eligible;

      live.sort((a, b) => b.depth - a.depth || b.growth - a.growth);
      const winner = live[0];
      return { el: winner.el, growth: winner.growth };
    }

    function finish(reason) {
      if (finished) return;
      finished = true;
      if (observer) observer.disconnect();
      clearInterval(rescanTimer);
      clearInterval(settleTimer);
      clearTimeout(hardTimer);
      const { el, growth } = currentBest();
      const full = el ? textOf(el) : '';
      const base = el ? baseOf(el) : 0;
      const text = el ? full.slice(Math.max(0, base)) : '';
      resolve({
        text: text.trim(),
        reason,
        el,
        growth,
        elapsedMs: Date.now() - started,
      });
    }

    /**
     * A node that did not exist a moment ago is ENTIRELY growth. Recording
     * its baseline as "whatever text it already holds" is what makes a
     * re-rendering chat (container destroyed and rebuilt per token) look
     * like it never grew at all — and then the only thing that appears to
     * have grown is the thread, which also holds the echo of your own
     * prompt. Freshly added nodes get a baseline of zero.
     */
    function markFresh(el) {
      if (!el || el.nodeType !== 1) return;
      if (!baseline.has(el)) baseline.set(el, 0);
      let n = 0;
      for (const d of el.querySelectorAll ? el.querySelectorAll('*') : []) {
        if (++n > 400) break;
        if (!baseline.has(d)) baseline.set(d, 0);
      }
    }

    function note(node, fresh) {
      if (fresh) markFresh(node);
      let el = node && node.nodeType === 1 ? node : node && node.parentElement;
      let hops = 0;
      const at = Date.now();
      while (el && hops < 25) {
        if (!isFurniture(el) && !inIgnored(el, ignore)) {
          baseOf(el); // record baseline the first time we ever see it
          seen.add(el);
          const len = textOf(el).length;
          if (len > (lastLen.get(el) ?? baseOf(el))) {
            if (!firstGrowth.has(el)) firstGrowth.set(el, at);
            lastLen.set(el, len);
            lastChange.set(el, at);
          }
        }
        el = parentOf(el);
        hops++;
      }
    }

    observer = new (doc.defaultView || window).MutationObserver((records) => {
      for (const r of records) {
        if (r.type === 'characterData') note(r.target);
        else if (r.type === 'childList') {
          for (const n of r.addedNodes) note(n, true);
          note(r.target, false);
        }
      }
      const { el, growth } = currentBest();
      if (growth > 0 && el) {
        const base = baseOf(el);
        const t = textOf(el).slice(Math.max(0, base)).trim();
        if (t !== lastEmitted) {
          lastGrowthAt = Date.now();
          lastEmitted = t;
          chunksEmitted += 1;
          if (onChunk) {
            try {
              onChunk(t);
            } catch {
              /* a consumer throwing must not kill the capture */
            }
          }
        }
      }
    });

    const OBSERVE = { subtree: true, childList: true, characterData: true };
    const observed = new Set();
    function observeRoot(root) {
      if (!root || observed.has(root)) return;
      observed.add(root);
      try {
        observer.observe(root, OBSERVE);
      } catch {
        /* a detached root is not worth failing over */
      }
    }
    observeRoot(doc.body || doc.documentElement);
    for (const r of shadowRootsUnder(doc.body || doc.documentElement)) observeRoot(r);
    /** Early settle is earned, not assumed: furniture lands whole in one
     *  chunk and a reply streams. The watch may settle when the current best
     *  has streamed several chunks, or holds a whole-delivered (substantial)
     *  reply, or the grace period has passed with at least a short text. */
    function canSettle(textLen) {
      const elapsed = Date.now() - started;
      return (
        chunksEmitted >= STREAM_CHUNKS ||
        textLen >= SUBSTANTIAL_CHARS ||
        (elapsed >= FIRST_TOKEN_GRACE_MS && textLen >= SHORT_SETTLE_CHARS)
      );
    }

    // A component that attaches its shadow root after the watch starts still
    // gets observed: re-scan cheaply on the same interval as the settle check.
    rescanTimer = setInterval(() => {
      if (finished) return;
      for (const r of shadowRootsUnder(doc.body || doc.documentElement)) observeRoot(r);
    }, 500);

    settleTimer = setInterval(() => {
      if (finished) return;
      const { el, growth } = currentBest();
      if (!el || growth < minLength) return;
      if (Date.now() - lastGrowthAt < settleMs) return;
      const textLen = textOf(el)
        .slice(Math.max(0, baseOf(el)))
        .trim().length;
      if (canSettle(textLen)) finish('settled');
    }, Math.max(60, Math.floor(settleMs / 4)));

    hardTimer = setTimeout(() => finish('timeout'), timeoutMs);
  });
}

const API = {
  watchResponse,
  textOf,
  REACTION_MS,
  LANDMARK_SELECTOR,
  STREAM_CHUNKS,
  SUBSTANTIAL_CHARS,
  SHORT_SETTLE_CHARS,
  FIRST_TOKEN_GRACE_MS,
};

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_WATCH__ = API;
