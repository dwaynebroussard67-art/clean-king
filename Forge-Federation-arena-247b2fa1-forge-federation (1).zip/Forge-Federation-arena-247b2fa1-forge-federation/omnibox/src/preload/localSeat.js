/**
 * localSeat.js — the preload for forgeflight://local.
 *
 * One preload per webContents, so this file is two things at once:
 *   1. the ordinary seat machinery (require('./seat.js') boots detection,
 *      typing, watching — the local page is seated like any other page);
 *   2. a narrow bridge for OUR page: named channels, localhost-only,
 *      guarded in the main process by sender URL. The page never touches
 *      the network; the bridge is the only door, and it opens onto the
 *      machine's own inference server.
 *
 * A provider page never gets this preload — it is selected at tab creation
 * for forgeflight://local only, and the main-side handlers re-check the sender
 * before doing anything.
 */

'use strict';

const { contextBridge, ipcRenderer } = require('electron');

require('./seat.js');

contextBridge.exposeInMainWorld('forgeflightLocal', {
  status: () => ipcRenderer.invoke('localLLM:status'),
  generate: (prompt) => ipcRenderer.invoke('localLLM:generate', { prompt: String(prompt || '') }),
  onToken: (cb) => {
    ipcRenderer.on('localLLM:token', (_e, token) => {
      try {
        cb(token);
      } catch {
        /* a page throwing must not break the stream */
      }
    });
  },
});
