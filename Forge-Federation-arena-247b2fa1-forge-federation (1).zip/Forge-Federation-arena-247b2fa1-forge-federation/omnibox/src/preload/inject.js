/**
 * inject.js — put text into a composer, and prove it landed before sending.
 *
 * THE KEEPALIVE RULE, applied to typing:
 *   Do not press send until the composer reads back exactly what we put in it.
 *
 * Every fan-out tool that exists sets a value and clicks send. When a provider
 * ships a new editor, that sequence quietly sends an empty message, or half a
 * message, or the previous message. Forge Flight reads the box back first and
 * refuses if it does not match. A refused seat is visible in the rail; a
 * silently truncated prompt is not.
 *
 * The strategies are a ladder, tried in order, cheapest and most faithful
 * first. Which one worked is reported, because when a provider changes editors
 * the strategy that stops working is the first thing worth knowing.
 */

'use strict';

/** Contenteditables round-trip NBSP and line breaks; compare on the shape a
 *  human would call "the same text". */
function normalize(s) {
  return String(s == null ? '' : s)
    .replace(/ /g, ' ')
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function isFormField(el) {
  const tag = (el.tagName || '').toLowerCase();
  return tag === 'textarea' || tag === 'input';
}

function readComposer(el) {
  if (!el) return '';
  if (isFormField(el)) return el.value == null ? '' : String(el.value);
  // innerText respects rendered line breaks; textContent does not.
  const t = el.innerText != null ? el.innerText : el.textContent;
  return t == null ? '' : String(t);
}

function fire(el, type, init) {
  try {
    el.dispatchEvent(new (init && init.__cls ? init.__cls : Event)(type, { bubbles: true, cancelable: true, ...init }));
  } catch {
    /* a page may have broken the constructor; the next strategy will tell us */
  }
}

function fireInput(el, data) {
  const win = el.ownerDocument.defaultView || window;
  try {
    el.dispatchEvent(
      new win.InputEvent('input', { bubbles: true, cancelable: false, data, inputType: 'insertText' })
    );
  } catch {
    fire(el, 'input');
  }
  fire(el, 'change');
}

/** Selection inside a shadow root does not come from `window.getSelection()`
 *  — that returns the host. Chromium exposes `shadowRoot.getSelection()`, and
 *  a composer inside a web component is unreachable without it. */
function selectionFor(el) {
  const root = el.getRootNode ? el.getRootNode() : el.ownerDocument;
  if (root && typeof root.getSelection === 'function') return root.getSelection();
  const win = el.ownerDocument.defaultView || window;
  return win.getSelection();
}

function selectAll(el) {
  const doc = el.ownerDocument;
  el.focus();
  if (isFormField(el)) {
    try {
      el.setSelectionRange(0, el.value.length);
    } catch {
      /* number/date inputs throw; harmless here */
    }
    return;
  }
  const range = doc.createRange();
  range.selectNodeContents(el);
  const sel = selectionFor(el);
  if (!sel) return;
  sel.removeAllRanges();
  sel.addRange(range);
}

// --------------------------------------------------------------------------
// Strategies
// --------------------------------------------------------------------------

/** React (and every controlled-input framework) listens for the native setter,
 *  not for `el.value = x`. Bypassing the framework's own descriptor is the
 *  only assignment it will observe. */
function strategyNativeSetter(el, text) {
  if (!isFormField(el)) return false;
  const win = el.ownerDocument.defaultView || window;
  const proto = el.tagName.toLowerCase() === 'textarea' ? win.HTMLTextAreaElement : win.HTMLInputElement;
  const desc = Object.getOwnPropertyDescriptor(proto.prototype, 'value');
  if (!desc || !desc.set) return false;
  el.focus();
  desc.set.call(el, text);
  fireInput(el, text);
  return true;
}

/** ProseMirror, Lexical, Slate and Quill all implement paste correctly —
 *  it is the one input path a rich editor cannot afford to get wrong. */
function strategyPaste(el, text) {
  const win = el.ownerDocument.defaultView || window;
  if (typeof win.DataTransfer !== 'function' || typeof win.ClipboardEvent !== 'function') return false;
  selectAll(el);
  const dt = new win.DataTransfer();
  dt.setData('text/plain', text);
  const ev = new win.ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
  const delivered = el.dispatchEvent(ev);
  // If nothing called preventDefault, no editor handled it — the paste was a
  // no-op and we should fall through rather than claim success.
  return !delivered;
}

/** Deprecated, still the most broadly supported contenteditable insert in
 *  Chromium, and it produces a real beforeinput/input pair. */
function strategyExecCommand(el, text) {
  const doc = el.ownerDocument;
  selectAll(el);
  let ok = false;
  try {
    ok = doc.execCommand('insertText', false, text);
  } catch {
    ok = false;
  }
  return ok;
}

/** Some editors listen only for beforeinput and build their own model. */
function strategyBeforeInput(el, text) {
  const win = el.ownerDocument.defaultView || window;
  if (typeof win.InputEvent !== 'function') return false;
  selectAll(el);
  let handled = false;
  try {
    const ev = new win.InputEvent('beforeinput', {
      bubbles: true,
      cancelable: true,
      inputType: 'insertText',
      data: text,
    });
    handled = !el.dispatchEvent(ev);
  } catch {
    handled = false;
  }
  return handled;
}

/** Last resort. Works on a plain contenteditable, invisible to a framework
 *  that keeps its own document model — which is exactly why read-back exists. */
function strategyDirect(el, text) {
  if (isFormField(el)) {
    el.value = text;
  } else {
    el.textContent = '';
    const doc = el.ownerDocument;
    const lines = String(text).split('\n');
    lines.forEach((line, i) => {
      if (i) el.appendChild(doc.createElement('br'));
      el.appendChild(doc.createTextNode(line));
    });
  }
  fireInput(el, text);
  return true;
}

const LADDER = [
  ['native-setter', strategyNativeSetter],
  ['paste-event', strategyPaste],
  ['exec-command', strategyExecCommand],
  ['before-input', strategyBeforeInput],
  ['direct', strategyDirect],
];

/**
 * @returns {{ok:true, strategy:string, readBack:string, attempts:string[]}
 *          |{ok:false, reason:'readback-mismatch'|'no-composer', attempts:object[], readBack?:string}}
 */
function setComposerText(el, text) {
  if (!el || !el.ownerDocument) return { ok: false, reason: 'no-composer', attempts: [] };
  const want = normalize(text);
  const attempts = [];

  for (const [name, fn] of LADDER) {
    let applied = false;
    try {
      applied = fn(el, text);
    } catch (e) {
      attempts.push({ strategy: name, applied: false, error: String((e && e.message) || e) });
      continue;
    }
    const got = readComposer(el);
    const match = normalize(got) === want;
    attempts.push({ strategy: name, applied, match, readBack: got.slice(0, 120) });
    if (applied && match) {
      return { ok: true, strategy: name, readBack: got, attempts: attempts.map((a) => a.strategy) };
    }
  }

  return {
    ok: false,
    reason: 'readback-mismatch',
    readBack: readComposer(el),
    wanted: text,
    attempts,
    detail:
      'Text was written to the composer but the composer did not read it back. ' +
      'Forge Flight will not press send on a box whose contents it cannot confirm.',
  };
}

/** Press send. Clicking a bound control is preferred; Enter is the fallback. */
function submit(composerEl, sendEl) {
  if (sendEl && !sendEl.disabled) {
    sendEl.click();
    return { ok: true, via: 'click' };
  }
  if (sendEl && sendEl.disabled) {
    // The page has decided this prompt is not sendable. Do not force it —
    // report it, so the rail can say why nothing happened.
    return { ok: false, via: 'click', reason: 'send-disabled' };
  }
  const win = composerEl.ownerDocument.defaultView || window;
  const opts = { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 };
  composerEl.focus();
  try {
    composerEl.dispatchEvent(new win.KeyboardEvent('keydown', opts));
    composerEl.dispatchEvent(new win.KeyboardEvent('keypress', opts));
    composerEl.dispatchEvent(new win.KeyboardEvent('keyup', opts));
  } catch {
    return { ok: false, via: 'enter', reason: 'keyboard-event-unavailable' };
  }
  let form = null;
  {
    let n = composerEl;
    let hops = 0;
    while (n && hops < 30) {
      if (n.tagName && n.tagName.toLowerCase() === 'form') {
        form = n;
        break;
      }
      n = n.parentElement || (n.parentNode && n.parentNode.host) || null;
      hops++;
    }
  }
  if (form && typeof form.requestSubmit === 'function') {
    try {
      form.requestSubmit();
    } catch {
      /* the form may have no submitter; the Enter dispatch above stands */
    }
  }
  return { ok: true, via: 'enter' };
}

const API = { setComposerText, submit, readComposer, normalize, selectionFor };

if (typeof module !== 'undefined' && module.exports) module.exports = API;
if (typeof globalThis !== 'undefined') globalThis.__FORGEFLIGHT_INJECT__ = API;
