/**
 * chrome.js — the only surface the Forge Flight UI can reach.
 *
 * The chrome is local HTML that never loads remote content, so this bridge is
 * narrow by construction: named channels, no `invoke(anything)` escape hatch,
 * no `require` leaking through.
 */

'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const on = (channel) => (cb) => {
  const handler = (_e, payload) => cb(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.off(channel, handler);
};

contextBridge.exposeInMainWorld('forgeflight', {
  ready: () => ipcRenderer.invoke('chrome:ready'),
  onState: on('state'),
  onTable: on('table'),
  onAccel: on('accel'),
  onOpenSheet: on('rail:openSheet'),

  viewport: (rect) => ipcRenderer.send('chrome:viewport', rect),
  pageVisible: (v) => ipcRenderer.send('chrome:pageVisible', v),

  tab: {
    open: (url) => ipcRenderer.invoke('tab:new', url),
    close: (id) => ipcRenderer.invoke('tab:close', id),
    activate: (id) => ipcRenderer.invoke('tab:activate', id),
    navigate: (id, input) => ipcRenderer.invoke('tab:navigate', { id, input }),
    back: (id) => ipcRenderer.invoke('tab:back', id),
    forward: (id) => ipcRenderer.invoke('tab:forward', id),
    reload: (id) => ipcRenderer.invoke('tab:reload', id),
    devtools: (id) => ipcRenderer.invoke('tab:devtools', id),
    tearOff: (id) => ipcRenderer.invoke('tab:tearOff', id),
    dock: (id) => ipcRenderer.invoke('tab:dock', id),
    contextmenu: (id) => ipcRenderer.send('rail:contextmenu', { tabId: id }),
  },

  seat: {
    pick: (id) => ipcRenderer.invoke('seat:pick', id),
    unpick: (id) => ipcRenderer.invoke('seat:unpick', id),
    redetect: (id) => ipcRenderer.invoke('seat:redetect', id),
    rename: (host, name) => ipcRenderer.invoke('seat:rename', { host, name }),
    mute: (host, muted) => ipcRenderer.invoke('seat:mute', { host, muted }),
    confirm: (id, confirmed) => ipcRenderer.invoke('seat:confirm', { id, confirmed }),
  },

  table: {
    send: (spec) => ipcRenderer.invoke('table:send', spec),
    stop: (runId) => ipcRenderer.invoke('table:stop', runId),
    captain: (spec) => ipcRenderer.invoke('table:captain', spec),
  },

  // The pilots and the address-bar memory. User-triggered only.
  onPilot: (cb) => {
    const kinds = ['pilot:started', 'pilot:step', 'pilot:finished'];
    const offs = kinds.map((k) => on(k)((payload) => cb(k, payload)));
    return () => offs.forEach((off) => off());
  },

  pilot: {
    launch: (goal, url, tabId) => ipcRenderer.invoke('pilot:launch', { goal, url, tabId }),
    stop: (id) => ipcRenderer.invoke('pilot:stop', { id }),
    stopAll: () => ipcRenderer.invoke('pilot:stopAll'),
    status: () => ipcRenderer.invoke('pilot:status'),
    list: () => ipcRenderer.invoke('pilot:list'),
    get: (id) => ipcRenderer.invoke('pilot:get', { id }),
  },

  history: {
    recent: (limit) => ipcRenderer.invoke('history:recent', { limit }),
    suggest: (input, limit) => ipcRenderer.invoke('history:suggest', { input, limit }),
  },

  // Resuming. The bridge carries URLs and seat assignments; it never carries
  // a credential, because Forge Flight never holds one.
  session: {
    info: () => ipcRenderer.invoke('session:info'),
    restore: () => ipcRenderer.invoke('session:restore'),
    save: () => ipcRenderer.invoke('session:save'),
    assign: (layout) => ipcRenderer.send('session:assign', layout),
  },

  // The Code Forge. Launch, watch, stop, resume, and the human's release.
  forge: {
    status: () => ipcRenderer.invoke('forge:status'),
    browse: () => ipcRenderer.invoke('forge:browse'),
    launch: (spec) => ipcRenderer.invoke('forge:launch', spec),
    stop: () => ipcRenderer.invoke('forge:stop'),
    resume: (opts) => ipcRenderer.invoke('forge:resume', opts || {}),
    release: (id) => ipcRenderer.invoke('forge:release', { id }),
    reject: (id, reason) => ipcRenderer.invoke('forge:reject', { id, reason }),
  },
  onForge: on('forge'),

  federation: {
    stats: () => ipcRenderer.invoke('federation:stats'),
    facts: (shelf, limit) => ipcRenderer.invoke('federation:facts', { shelf, limit }),
    queue: () => ipcRenderer.invoke('federation:queue'),
    // The renderer does not name the actor. Main stamps the configured operator.
    release: (id, note) => ipcRenderer.invoke('federation:release', { id, note }),
    refuse: (id, note) => ipcRenderer.invoke('federation:refuse', { id, note }),
    rechecks: (days) => ipcRenderer.invoke('federation:rechecks', { days }),
    review: (request) => ipcRenderer.invoke('federation:review', request),
    propose: (spec) => ipcRenderer.invoke('federation:propose', spec),
    autoPropose: () => ipcRenderer.invoke('federation:autoPropose'),
  },

  operator: {
    get: () => ipcRenderer.invoke('operator:get'),
    set: (name) => ipcRenderer.invoke('operator:set', { name }),
    signIn: (name) => ipcRenderer.invoke('operator:signin', { name }),
  },

  diary: {
    mark: (name, result) => ipcRenderer.invoke('diary:mark', { name, result }),
  },

  flight: {
    mark: (name, result) => ipcRenderer.invoke('flight:mark', { name, result }),
  },

  passport: {
    boot: (query, tokenBudget) => ipcRenderer.invoke('passport:boot', { query, tokenBudget }),
    list: () => ipcRenderer.invoke('passport:list'),
    pin: (id, pinned) => ipcRenderer.invoke('passport:pin', { id, pinned }),
    adjudicate: (id) => ipcRenderer.invoke('passport:adjudicate', { id }),
    retire: (id) => ipcRenderer.invoke('passport:retire', { id }),
    export: () => ipcRenderer.invoke('passport:export'),
    import: () => ipcRenderer.invoke('passport:import'),
  },

  openExternal: (url) => ipcRenderer.invoke('shell:open', url),
});
