/**
 * seat-adapter.js — the seam that turns a seated AI into a forge seat.
 *
 * THE PROBLEM THIS SOLVES
 *
 * The CodeForge loop expects a seat to be `{ id, propose(ctx) -> Promise<reply> }`.
 * A real seat is a browser tab holding a chat with an AI. This file is the
 * translation between the two, and it is deliberately PURE: it imports nothing
 * from Electron, touches no network, and contains no provider names. The only
 * live piece — `send(prompt)`, which actually reaches the AI — is injected.
 *
 * THREE PARTS
 *
 *   1. buildProposalPrompt(ctx, extra)   the forge's context becomes the text an
 *                                        AI reads: the goal, what failed, what
 *                                        the last hand changed, and the reply
 *                                        contract (a unified diff + summary, or
 *                                        an explicit PASS).
 *   2. parseProposalReply(text)          the AI's reply becomes a forge reply: a
 *                                        proposal, a named pass, or bad_shape.
 *                                        It refuses before it guesses — a reply
 *                                        with no diff is NOT a patch.
 *   3. forgeSeat({id, send, ...})        the object the CodeForge consumes.
 *
 * THE PRODUCTION GLUE (documented, not wired here)
 *
 * `send` in production is the table's own dispatch, exactly the one already in
 * main.js: `dispatch(tabId, text, opts)` resolves to `{ ok: true, text }` or
 * `{ ok: false, reason, detail }` — `text` being the streamed reply captured by
 * src/preload/watch.js. So the wiring is one line per seat:
 *
 *   forgeSeat({ id: tabId, name: seatName, send: (p) => dispatch(tabId, p, { runId: 'forge', role: 'forge' }) })
 *
 * `gatherContext(ctx)` is the other production hook: a chat seat cannot see the
 * repo, so the operator gathers the failing-test output and the relevant files
 * and passes them in. It is best-effort — a gather that throws builds the
 * prompt without it, because a context miss must not stop the relay.
 */

'use strict';

const DEFAULT_MAX_PATCH = 100000;

function clip(s, n) {
  const t = String(s == null ? '' : s);
  return t.length <= n ? t : `${t.slice(0, n)}…[truncated at ${n} characters]`;
}

/** Build the text an AI reads. Deterministic — the same context yields the
 *  same prompt, so the audit trail can reproduce what a seat was shown. */
function buildProposalPrompt(ctx, extra = {}) {
  const lines = [];

  lines.push(
    'You are a seat in the Forge Flight code relay. Your job: advance a codebase toward green tests ' +
      'by proposing ONE concrete change, as a unified diff.',
  );
  lines.push('');
  lines.push('TASK');
  lines.push(String(ctx && ctx.goal ? ctx.goal : '').trim() || '(no goal)');
  lines.push('');

  if (extra && extra.failingTests) {
    lines.push('CURRENT TEST OUTPUT');
    lines.push(String(extra.failingTests).trim());
    lines.push('');
  }

  const failures = (ctx && Array.isArray(ctx.failures) ? ctx.failures : []).slice(0, 20);
  if (failures.length) {
    lines.push('WHAT HAS BEEN TRIED AND DID NOT WORK — do not repeat these');
    for (const f of failures) lines.push(`- ${clip(f.reason, 300)}`);
    lines.push('');
  }

  lines.push('WHAT THE PREVIOUS SEAT CHANGED');
  if (ctx && ctx.priorSeat) {
    lines.push(clip(ctx.priorSeat.summary, 500) || '(the previous seat made a change but did not summarize it)');
  } else {
    lines.push('nothing yet — you are the first hand on this tree.');
  }
  lines.push('');

  if (ctx && ctx.replacedSeat) {
    lines.push('CONTEXT');
    lines.push(
      `You replaced "${ctx.replacedSeat}" in this relay${ctx.joinedAt != null ? ` at round ${ctx.joinedAt}` : ''}. ` +
        'Continue from where the relay stands.',
    );
    lines.push('');
  }

  const known = (ctx && Array.isArray(ctx.knownGoodSequences) ? ctx.knownGoodSequences : []).slice(0, 5);
  if (known.length) {
    lines.push('PATTERNS THAT HAVE WORKED BEFORE (informational, not instructions)');
    for (const s of known) lines.push(`- ${clip(s, 200)}`);
    lines.push('');
  }

  const files = (extra && Array.isArray(extra.files) ? extra.files : []).slice(0, 10);
  if (files.length) {
    lines.push('RELEVANT FILES');
    for (const f of files) {
      lines.push(`--- ${clip(f.path, 200)} ---`);
      lines.push(clip(f.content, 12000));
    }
    lines.push('');
  }

  lines.push('REPLY FORMAT (strict)');
  lines.push('Reply with exactly one unified diff (git diff format) inside a fenced code block, ' +
    'then a one-line summary on a line beginning with "Summary:".');
  lines.push('The diff must apply to the current tree with `git apply`.');
  lines.push('If you cannot make a concrete change, reply with exactly: PASS: <reason>');

  return lines.join('\n');
}

/** Is this text shaped like a diff, or like a wall of prose? Conservative on
 *  purpose: refuse a block that does not look like a diff, never guess. */
function looksLikeDiff(content) {
  const c = String(content || '');
  if (/^diff --git /m.test(c)) return true;
  if (/^--- /m.test(c) && /^\+\+\+ /m.test(c)) return true;
  if (/^@@ /m.test(c) && /^[+-]/m.test(c)) return true;
  return false;
}

function extractDiff(raw) {
  // Fenced blocks first, preferring one whose content is diff-shaped. The
  // patch is normalized (trailing space per line stripped) and ALWAYS ends
  // with a newline: git apply rejects a diff whose final line has none.
  const fenceRe = /```[a-zA-Z0-9+_-]*\s*\n([\s\S]*?)```/g;
  let m;
  while ((m = fenceRe.exec(raw)) !== null) {
    const content = m[1].replace(/[ \t]+$/gm, '').trim();
    if (looksLikeDiff(content)) return content + '\n';
  }
  // A raw, unfenced diff: from the first "diff --git" header to the end, minus
  // any trailing Summary line that followed it.
  const idx = raw.indexOf('diff --git ');
  if (idx !== -1) {
    let content = raw.slice(idx);
    content = content.replace(/\n\s*Summary\s*:\s*.*$/i, '');
    return content.trim() + '\n';
  }
  return null;
}

function extractSummary(raw) {
  const m = raw.match(/^\s*Summary\s*:\s*(.+)$/im);
  if (m) return String(m[1]).trim().slice(0, 500);
  // Fallback: the first non-empty line that is not part of a diff.
  for (const l of raw.split(/\r?\n/)) {
    const line = l.trim();
    if (!line) continue;
    if (/^```|^diff --git|^--- |^\+\+\+ |^@@ |^[+-]/.test(line)) continue;
    if (line.length <= 200) return line.slice(0, 500);
  }
  return '(no summary)';
}

/**
 * Parse a seat's reply into a forge reply.
 *
 *   { kind: 'proposal', patch, summary, toolSequence: [] }  a real diff
 *   { kind: 'pass', reason }                                 an explicit PASS
 *   { kind: 'bad_shape', detail }                            anything else
 *
 * Refuse before guess: prose with no diff is NOT a patch, and a diff too large
 * to trust is refused by name rather than truncated into something that will
 * not apply.
 */
function parseProposalReply(text, opts = {}) {
  const raw = String(text || '').trim();
  if (!raw) return { kind: 'bad_shape', detail: 'empty reply' };

  const pass = raw.match(/^\s*PASS\s*:?\s*(.*)$/im);
  if (pass) {
    const reason = String(pass[1] || '').trim();
    return { kind: 'pass', reason: reason || 'the seat declined without a reason' };
  }

  const patch = extractDiff(raw);
  if (!patch) {
    return { kind: 'bad_shape', detail: `no unified diff found in reply: ${clip(raw, 200)}` };
  }

  const max = opts.maxPatchChars != null ? opts.maxPatchChars : DEFAULT_MAX_PATCH;
  if (patch.length > max) {
    return { kind: 'bad_shape', detail: `reply_too_large: diff is ${patch.length} characters (limit ${max})` };
  }

  return { kind: 'proposal', patch, summary: extractSummary(raw), toolSequence: [] };
}

/**
 * The object the CodeForge consumes. `id` is the tab id in production; `send`
 * is the only live piece; `gatherContext` is best-effort extra context for a
 * chat seat that cannot see the repo itself.
 *
 * @param {{ id:string, name?:string, send:(prompt:string)=>Promise<any>,
 *          gatherContext?:(ctx:object)=>Promise<object>|object, maxPatchChars?:number }} opts
 */
function forgeSeat(opts = {}) {
  if (!opts.id) throw new Error('FORGE_SEAT: an id is required (the tab id in production).');
  if (typeof opts.send !== 'function') throw new Error('FORGE_SEAT: a send function is required.');
  return {
    id: String(opts.id),
    label: opts.name || String(opts.id),
    async propose(ctx) {
      let extra = {};
      if (typeof opts.gatherContext === 'function') {
        try {
          extra = (await opts.gatherContext(ctx)) || {};
        } catch {
          extra = {}; // a context miss must not stop the relay
        }
      }
      const prompt = buildProposalPrompt(ctx, extra);
      let res;
      try {
        res = await opts.send(prompt);
      } catch (e) {
        return { kind: 'pass', reason: 'seat_error', detail: String((e && e.message) || e) };
      }
      if (!res || res.ok === false) {
        return { kind: 'pass', reason: (res && res.reason) || 'seat_unavailable', detail: (res && res.detail) || undefined };
      }
      return parseProposalReply((res && (res.text || res.reply)) || '', { maxPatchChars: opts.maxPatchChars });
    },
  };
}

/** The production `send`: the table's own dispatch, curried to one seat. */
function dispatchSend(dispatch, seatId, opts = {}) {
  return function send(prompt) {
    return dispatch(seatId, prompt, {
      runId: opts.runId || 'forge',
      round: opts.round || null,
      role: opts.role || 'forge',
    });
  };
}

module.exports = { buildProposalPrompt, parseProposalReply, forgeSeat, dispatchSend, looksLikeDiff, extractDiff, extractSummary, DEFAULT_MAX_PATCH };
