/**
 * tools.js — the capability gate and the forge's toolbox.
 *
 * THE PROBLEM THIS SOLVES
 *
 * A forge seat that proposes a diff is safe by construction: the loop's apply +
 * referee are the only hands that touch the tree. A seat that FLIES TOOLS —
 * reads files, writes files, runs the tests — is a different animal, and it
 * needs the same discipline the engine already settled in capabilities.ts:
 *
 *   - every action carries a RISK rank;
 *   - authorization is a pure function of the actor's grant and the risk;
 *   - a pilot that reaches for a tool it was not granted is DENIED, by name,
 *     before the tool runs — never after the side effect.
 *
 * This file is the forge's copy of that discipline, in the canonical CommonJS
 * style, self-contained and testable. The risk ranks mirror capabilities.ts:
 *
 *   read < transform < create < update < delete < external_side_effect
 *
 * THE TOOLBOX IS BOUNDED
 *
 * Every tool that touches the filesystem is bound to the worktree directory.
 * A path that is absolute, walks with `..`, or resolves outside the worktree is
 * refused by name — a code pilot is not a root shell, and the tests assert the
 * boundary, not just the happy path.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

// ── Risk ──────────────────────────────────────────────────────────────────

const RISK_RANK = Object.freeze({
  read: 0,
  transform: 1,
  create: 2,
  update: 3,
  delete: 4,
  external_side_effect: 5,
});

/** Authorization is a pure function of the grant and the declared risk. */
function authorize(toolId, risk, authority) {
  const a = authority || {};
  const allowed = Array.isArray(a.allowedCapabilityIds) ? a.allowedCapabilityIds : [];
  if (!allowed.includes(toolId)) {
    return { decision: 'deny', reason: 'capability_not_granted' };
  }
  const auto = RISK_RANK[a.autoApproveRiskAtMost !== undefined ? a.autoApproveRiskAtMost : 'transform'];
  const r = RISK_RANK[risk] !== undefined ? RISK_RANK[risk] : 5;
  if (r > auto) {
    return { decision: 'require_approval', reason: 'risk_exceeds_auto_approve' };
  }
  return { decision: 'allow', reason: 'within_authority' };
}

/** The authority a forge tool pilot flies under by default: all four forge
 *  tools, auto-approving everything up to `update`. `run_tests` is
 *  `external_side_effect`, so it always requires the operator's approval. */
const DEFAULT_FORGE_AUTHORITY = Object.freeze({
  allowedCapabilityIds: ['forge.read_file', 'forge.write_file', 'forge.run_tests', 'forge.git_diff'],
  autoApproveRiskAtMost: 'update',
});

class CapabilityGate {
  constructor(authority) {
    this.authority = authority || DEFAULT_FORGE_AUTHORITY;
  }

  authorize(toolId, risk) {
    return authorize(toolId, risk, this.authority);
  }
}

// ── Path containment ──────────────────────────────────────────────────────

/** Resolve a tool-supplied path against the worktree, refusing anything that
 *  escapes it. Absolute paths, `..` walks, and anything that resolves outside
 *  the worktree root are refused by name. */
function safeRelPath(worktreeDir, p) {
  if (typeof p !== 'string' || p.length === 0) {
    return { ok: false, reason: 'path_required' };
  }
  if (path.isAbsolute(p)) {
    return { ok: false, reason: 'absolute_path_refused' };
  }
  const norm = path.normalize(p);
  if (norm === '..' || norm.startsWith(`..${path.sep}`)) {
    return { ok: false, reason: 'traversal_refused' };
  }
  const root = path.resolve(worktreeDir);
  const resolved = path.resolve(root, norm);
  if (resolved !== root && !resolved.startsWith(root + path.sep)) {
    return { ok: false, reason: 'outside_worktree' };
  }
  return { ok: true, resolved };
}

function runGit(dir, args) {
  const r = spawnSync('git', args, { cwd: dir, encoding: 'utf8' });
  if (r.error) throw r.error;
  return { code: r.status, out: r.stdout || '', err: r.stderr || '' };
}

function toolError(code, message) {
  const e = new Error(message || code);
  e.code = code;
  e.name = 'ToolError';
  return e;
}

// ── The toolbox ───────────────────────────────────────────────────────────

const READ_LIMIT_CHARS = 100000;

class ForgeToolbox {
  /**
   * @param {object} opts
   * @param {string} opts.worktreeDir   every filesystem tool is bound to this
   * @param {() => {code,stdout,stderr,signal}|Promise} [opts.runTests]  runs the
   *        test suite in the worktree
   */
  constructor(opts = {}) {
    if (!opts.worktreeDir) throw new Error('FORGE_TOOLBOX: a worktreeDir is required.');
    this.worktreeDir = opts.worktreeDir;
    this.runTests = opts.runTests || null;
    this.tools = new Map();
    this._register();
  }

  _register() {
    this.tools.set('forge.read_file', {
      id: 'forge.read_file',
      name: 'Read a file',
      description: 'Read the contents of a file in the worktree, by relative path.',
      risk: 'read',
      run: (args) => this._readFile(args),
    });
    this.tools.set('forge.write_file', {
      id: 'forge.write_file',
      name: 'Write a file',
      description: 'Write (create or replace) a file in the worktree, by relative path.',
      risk: 'update',
      run: (args) => this._writeFile(args),
    });
    this.tools.set('forge.run_tests', {
      id: 'forge.run_tests',
      name: 'Run the tests',
      description: 'Run the test suite in the worktree and return its output.',
      risk: 'external_side_effect',
      run: () => this._runTests(),
    });
    this.tools.set('forge.git_diff', {
      id: 'forge.git_diff',
      name: 'Inspect your diff',
      description: 'Return the current working diff of the worktree.',
      risk: 'read',
      run: () => this._gitDiff(),
    });
  }

  descriptor(id) {
    const t = this.tools.get(id);
    if (!t) return null;
    return { id: t.id, name: t.name, description: t.description, risk: t.risk };
  }

  list() {
    return [...this.tools.values()].map((t) => ({ id: t.id, name: t.name, description: t.description, risk: t.risk }));
  }

  async execute(id, args) {
    const t = this.tools.get(id);
    if (!t) return { ok: false, reason: 'unknown_tool' };
    try {
      const result = await t.run(args || {});
      return { ok: true, result };
    } catch (e) {
      return { ok: false, reason: (e && e.code) || String((e && e.message) || e) };
    }
  }

  async _readFile(args) {
    const s = safeRelPath(this.worktreeDir, args.path);
    if (!s.ok) throw toolError(s.reason, `refused: ${s.reason}`);
    let stat;
    try {
      stat = fs.statSync(s.resolved);
    } catch {
      throw toolError('file_not_found', `no such file: ${args.path}`);
    }
    if (!stat.isFile()) throw toolError('not_a_file', `not a file: ${args.path}`);
    const content = fs.readFileSync(s.resolved, 'utf8');
    if (content.length > READ_LIMIT_CHARS) {
      return { path: args.path, content: content.slice(0, READ_LIMIT_CHARS), truncated: true };
    }
    return { path: args.path, content };
  }

  async _writeFile(args) {
    const s = safeRelPath(this.worktreeDir, args.path);
    if (!s.ok) throw toolError(s.reason, `refused: ${s.reason}`);
    if (typeof args.content !== 'string') throw toolError('content_required', 'write_file needs a string content');
    fs.mkdirSync(path.dirname(s.resolved), { recursive: true });
    fs.writeFileSync(s.resolved, args.content, 'utf8');
    return { path: args.path, bytes: Buffer.byteLength(args.content, 'utf8') };
  }

  async _runTests() {
    if (typeof this.runTests !== 'function') throw toolError('no_test_runner', 'no test runner is mounted');
    const r = await this.runTests();
    return { code: r && r.code, stdout: (r && r.stdout) || '', stderr: (r && r.stderr) || '', signal: (r && r.signal) || null };
  }

  async _gitDiff() {
    // Stage everything (including untracked new files) so `git diff --cached`
    // is the complete change set. The loop's apply resets the worktree before
    // it applies, so this staging is discarded harmlessly.
    runGit(this.worktreeDir, ['add', '-A']);
    const d = runGit(this.worktreeDir, ['diff', '--cached']);
    return { diff: d.out };
  }
}

module.exports = {
  RISK_RANK,
  authorize,
  DEFAULT_FORGE_AUTHORITY,
  CapabilityGate,
  safeRelPath,
  ForgeToolbox,
  toolError,
};
