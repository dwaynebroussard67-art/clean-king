/**
 * bench.js — the hangar. Spare seats, in relay-ready order, waiting to fly.
 *
 * THE PROBLEM THIS SOLVES
 *
 * A forge whose seats are free-tier models runs dry. The loop must not stop —
 * but it also must not harvest free tiers it has no right to (see
 * docs/SELF-HEALING-RELAY.md). The honest mechanism is a bench: the user's own
 * spare seats — their other logged-in providers, their auto-discovered local
 * models — held in order, and swapped into a relay slot the moment the seat in
 * it is ejected.
 *
 * The bench is deliberately dumb: an ordered queue. seatNext() hands out the
 * next spare and removes it, because a seat can fly in only one slot at a time
 * and a bench member that has flown is no longer spare. All the intelligence
 * — when to swap, what context the newcomer gets, when to pause instead — lives
 * in the forge, not here. A dumb bench cannot be wrong in interesting ways.
 */

'use strict';

class ForgeBench {
  constructor(seats = []) {
    if (!Array.isArray(seats)) throw new Error('FORGE_BENCH: bench seats must be an array.');
    this.queue = seats.slice();
  }

  /** Push a spare seat onto the end of the bench. */
  add(seat) {
    this.queue.push(seat);
    return this.queue.length;
  }

  /** The next spare seat, or null when the hangar is empty. Removes it. */
  seatNext() {
    return this.queue.shift() || null;
  }

  /** Peek without removing. */
  peek() {
    return this.queue[0] || null;
  }

  isEmpty() {
    return this.queue.length === 0;
  }

  get remaining() {
    return this.queue.length;
  }

  all() {
    return this.queue.slice();
  }
}

module.exports = { ForgeBench };
