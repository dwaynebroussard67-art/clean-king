/**
 * budget.js — per-seat consumption governance for the Code Forge.
 *
 * THE PROBLEM THIS SOLVES
 *
 * Eight seats in a continuous loop is a furnace for money. The same lesson the
 * engine's seat-budget.ts teaches applies here, in the same order:
 *
 *   1. Charge BEFORE the request leaves, never after it returns. The provider
 *      is the backstop; the local ledger is the gate.
 *   2. NO REFUNDS. A dispatch that failed may still have been metered on the
 *      provider's side, and from here the two are indistinguishable — so the
 *      ledger may overcount, never undercount. Failed spend is still counted,
 *      separately, in `spentOnFailure`, so the measurement stays honest about
 *      what the overcount consists of.
 *   3. UNKNOWN TIERS DO NOT EJECT. A seat with no established allowance is
 *      metered but never ejected — ejecting on a limit nobody established
 *      would break every operator, which is worse than letting an unmetered
 *      seat keep flying.
 *
 * The unit is CALLS, deliberately, not tokens: a request count is knowable
 * before dispatch, and token spend is not knowable until after the response —
 * which is on the wrong side of the gate.
 */

'use strict';

class BudgetExceededError extends Error {
  constructor(seatId, resource, limit, used) {
    super(
      `FORGE_BUDGET_EXCEEDED: seat ${seatId} has spent ${used} of ${limit} ${resource}. ` +
        `The seat is out of allowance and must be ejected or re-provisioned.`,
    );
    this.name = 'BudgetExceededError';
    this.seatId = seatId;
    this.resource = resource;
    this.limit = limit;
    this.used = used;
  }
}

const zeroUsage = () => ({ calls: 0, usd: 0, spentOnFailure: 0 });

class ForgeBudget {
  constructor() {
    this.allowances = new Map(); // seatId -> { maxCalls?, maxUsd?, tier }
    this.usages = new Map(); // seatId -> { calls, usd, spentOnFailure }
    this.ejectedSeats = new Set();
  }

  /** Establish or replace a seat's allowance. Resets nothing by itself. */
  provision(seatId, allowance) {
    this.allowances.set(seatId, {
      maxCalls: allowance && allowance.maxCalls !== undefined ? allowance.maxCalls : undefined,
      maxUsd: allowance && allowance.maxUsd !== undefined ? allowance.maxUsd : undefined,
      tier: allowance && allowance.tier ? allowance.tier : 'unknown',
    });
    if (!this.usages.has(seatId)) this.usages.set(seatId, zeroUsage());
  }

  usageFor(seatId) {
    return { ...(this.usages.get(seatId) || zeroUsage()) };
  }

  allowanceFor(seatId) {
    return this.allowances.get(seatId) || null;
  }

  remainingCalls(seatId) {
    const a = this.allowances.get(seatId);
    if (!a || a.maxCalls === undefined) return null;
    return Math.max(0, a.maxCalls - this.usageFor(seatId).calls);
  }

  status(seatId) {
    const a = this.allowances.get(seatId);
    if (!a) return 'unmetered';
    const u = this.usageFor(seatId);
    if (a.maxCalls !== undefined && u.calls >= a.maxCalls) return 'exhausted';
    if (a.maxUsd !== undefined && u.usd >= a.maxUsd) return 'exhausted';
    return 'ok';
  }

  ejected(seatId) {
    return this.ejectedSeats.has(seatId);
  }

  eject(seatId) {
    this.ejectedSeats.add(seatId);
  }

  /** Charge a dispatch BEFORE it leaves. Throws if the seat is exhausted; the
   *  caller must eject. Unmetered seats are counted but never thrown. */
  chargeBeforeDispatch(seatId, usd = 0) {
    if (this.ejected(seatId)) {
      throw new BudgetExceededError(seatId, 'calls', 0, this.usageFor(seatId).calls);
    }
    const a = this.allowances.get(seatId);
    if (!a) {
      // Meter but never eject.
      const u = this.usages.get(seatId) || zeroUsage();
      u.calls += 1;
      u.usd += usd;
      this.usages.set(seatId, u);
      return this.usageFor(seatId);
    }
    const u = this.usages.get(seatId) || zeroUsage();
    if (a.maxCalls !== undefined && u.calls >= a.maxCalls) {
      throw new BudgetExceededError(seatId, 'calls', a.maxCalls, u.calls);
    }
    if (a.maxUsd !== undefined && u.usd + usd > a.maxUsd) {
      throw new BudgetExceededError(seatId, 'usd', a.maxUsd, u.usd);
    }
    u.calls += 1;
    u.usd += usd;
    this.usages.set(seatId, u);
    return this.usageFor(seatId);
  }

  /** Mark a charged dispatch that returned nothing usable. Deliberately no
   *  refund — this only makes the overcount visible. */
  markFailed(seatId) {
    const u = this.usages.get(seatId) || zeroUsage();
    u.spentOnFailure += 1;
    this.usages.set(seatId, u);
  }

  reset(seatId) {
    this.usages.set(seatId, zeroUsage());
    this.ejectedSeats.delete(seatId);
  }

  /** True when none of these seats can be dispatched — the loop cannot fly. */
  allExhausted(seatIds) {
    if (!seatIds || seatIds.length === 0) return true;
    return seatIds.every((id) => this.ejected(id) || this.status(id) === 'exhausted');
  }

  snapshot() {
    return {
      allowances: Object.fromEntries(this.allowances),
      usages: Object.fromEntries(this.usages),
      ejected: [...this.ejectedSeats],
    };
  }

  hydrate(state) {
    this.allowances = new Map(Object.entries((state && state.allowances) || {}));
    this.usages = new Map(Object.entries((state && state.usages) || {}));
    this.ejectedSeats = new Set((state && state.ejected) || []);
  }
}

module.exports = { ForgeBudget, BudgetExceededError };
