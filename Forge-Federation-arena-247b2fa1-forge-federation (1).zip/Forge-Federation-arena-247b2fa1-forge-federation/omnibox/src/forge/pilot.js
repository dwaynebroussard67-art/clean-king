/**
 * pilot.js — the tool pilot: a seat that flies tools, not just diffs.
 *
 * THE PROBLEM THIS SOLVES
 *
 * A chat seat is good at deciding; it is bad at emitting a perfect unified diff
 * every time. So give it tools instead: it reads files, writes the fix, runs
 * the tests — and the pilot turns whatever the tools did into the same shape
 * the loop already consumes: `{ kind: 'proposal', patch, summary,
 * toolSequence }`. The loop's apply + referee stay the only authority; the
 * pilot's own test run is advisory, never a verdict.
 *
 * THE FLOW OF propose(ctx)
 *
 *   1. Check out the tree the loop is flying, so the tools operate on the
 *      right base.
 *   2. Send a tool-oriented prompt (goal, failures, prior hand, the tool list,
 *      and a strict JSON reply contract).
 *   3. If the reply is JSON with a `tools` array, fly each tool THROUGH THE
 *      GATE: deny stops the flight by name; a risk above the auto-approve
 *      ceiling asks the operator (the `approve` hook); allow executes.
 *   4. After the tools fly, `forge.git_diff` becomes the patch. A flight that
 *      produced no change is a named refusal (`no_diff`), never an empty patch.
 *   5. If the reply is not tool JSON, fall back to the diff contract from
 *      seat-adapter.js — a seat may still just hand over a diff.
 */

'use strict';

const { parseProposalReply } = require('./seat-adapter.js');
const { CapabilityGate, DEFAULT_FORGE_AUTHORITY } = require('./tools.js');

function clip(s, n) {
  const t = String(s == null ? '' : s);
  return t.length <= n ? t : `${t.slice(0, n)}…[truncated at ${n} characters]`;
}

/** Build the text a tool-flying seat reads. Deterministic, so the audit trail
 *  can reproduce what a seat was shown. */
function buildToolPrompt(ctx, extra, toolsList) {
  const lines = [];
  lines.push('You are a seat in the Forge Flight code relay. You have tools. Use them to advance the codebase toward green tests.');
  lines.push('');
  lines.push('TASK');
  lines.push(String(ctx && ctx.goal ? ctx.goal : '').trim() || '(no goal)');
  lines.push('');

  if (extra && extra.failingTests) {
    lines.push('CURRENT TEST OUTPUT');
    lines.push(String(extra.failingTests).trim());
    lines.push('');
  }

  const failures = (ctx && Array.isArray(ctx.failures) ? ctx.failures : []).slice(0, 20);
  if (failures.length) {
    lines.push('WHAT HAS BEEN TRIED AND DID NOT WORK — do not repeat these');
    for (const f of failures) lines.push(`- ${clip(f.reason, 300)}`);
    lines.push('');
  }

  lines.push('WHAT THE PREVIOUS SEAT CHANGED');
  lines.push(ctx && ctx.priorSeat ? clip(ctx.priorSeat.summary, 500) : 'nothing yet — you are the first hand on this tree.');
  lines.push('');

  if (ctx && ctx.replacedSeat) {
    lines.push(`You replaced "${ctx.replacedSeat}" in this relay${ctx.joinedAt != null ? ` at round ${ctx.joinedAt}` : ''}. Continue from where the relay stands.`);
    lines.push('');
  }

  const files = (extra && Array.isArray(extra.files) ? extra.files : []).slice(0, 10);
  if (files.length) {
    lines.push('RELEVANT FILES');
    for (const f of files) {
      lines.push(`--- ${clip(f.path, 200)} ---`);
      lines.push(clip(f.content, 12000));
    }
    lines.push('');
  }

  lines.push('AVAILABLE TOOLS');
  for (const t of toolsList || []) lines.push(`- ${t.id} (risk: ${t.risk}) — ${t.description}`);
  lines.push('');
  lines.push('REPLY FORMAT (strict JSON, nothing else)');
  lines.push('{ "summary": "what you changed in one line", "tools": [ { "tool": "<tool id>", "args": { ... } } ] }');
  lines.push('Use forge.read_file to read, forge.write_file to write, forge.run_tests to run the tests, forge.git_diff to inspect your diff.');
  lines.push('forge.run_tests requires operator approval; if it is not approved, your flight stops.');
  lines.push('If you cannot make a concrete change, reply with exactly: PASS: <reason>');
  return lines.join('\n');
}

/** Extract a strict-JSON tool reply from a seat's answer. Returns
 *  { summary, tools } or null. The brace scan tolerates braces inside string
 *  values, so a file body containing `{` does not break the parse. */
function parseToolReply(text) {
  const raw = String(text || '').trim();
  if (!raw) return null;
  const start = raw.indexOf('{');
  if (start === -1) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < raw.length; i++) {
    const ch = raw[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        let j;
        try {
          j = JSON.parse(raw.slice(start, i + 1));
        } catch {
          return null;
        }
        if (j && Array.isArray(j.tools) && j.tools.length) return j;
        return null;
      }
    }
  }
  return null;
}

/**
 * The object the CodeForge consumes, backed by a toolbox.
 *
 * @param {object} opts
 * @param {string} opts.id          the seat id (tab id in production)
 * @param {string} [opts.name]
 * @param {(prompt:string)=>Promise<any>} opts.send
 * @param {ForgeToolbox} opts.toolbox
 * @param {CapabilityGate} [opts.gate]        defaults to DEFAULT_FORGE_AUTHORITY
 * @param {({toolId:string,args:object})=>Promise<boolean>|boolean} [opts.approve]
 * @param {(sha:string)=>void|Promise<void>} [opts.checkout]
 * @param {(ctx:object)=>object|Promise<object>} [opts.gatherContext]
 * @param {number} [opts.maxPatchChars]
 */
function toolPilotSeat(opts = {}) {
  if (!opts.id) throw new Error('FORGE_PILOT: an id is required.');
  if (typeof opts.send !== 'function') throw new Error('FORGE_PILOT: a send function is required.');
  if (!opts.toolbox || typeof opts.toolbox.execute !== 'function' || typeof opts.toolbox.list !== 'function') {
    throw new Error('FORGE_PILOT: a ForgeToolbox is required.');
  }
  const gate = opts.gate || new CapabilityGate(DEFAULT_FORGE_AUTHORITY);

  return {
    id: String(opts.id),
    label: opts.name || String(opts.id),
    async propose(ctx) {
      if (typeof opts.checkout === 'function') {
        try {
          await opts.checkout(ctx.tree);
        } catch (e) {
          return { kind: 'pass', reason: 'seat_error', detail: `checkout failed: ${String((e && e.message) || e)}` };
        }
      }

      let extra = {};
      if (typeof opts.gatherContext === 'function') {
        try {
          extra = (await opts.gatherContext(ctx)) || {};
        } catch {
          extra = {}; // a context miss must not stop the relay
        }
      }

      let res;
      try {
        res = await opts.send(buildToolPrompt(ctx, extra, opts.toolbox.list()));
      } catch (e) {
        return { kind: 'pass', reason: 'seat_error', detail: String((e && e.message) || e) };
      }
      if (!res || res.ok === false) {
        return { kind: 'pass', reason: (res && res.reason) || 'seat_unavailable', detail: (res && res.detail) || undefined };
      }

      const text = (res && (res.text || res.reply)) || '';
      const toolReply = parseToolReply(text);
      if (!toolReply) {
        // Not tool JSON — the seat may still have handed over a diff directly.
        return parseProposalReply(text, { maxPatchChars: opts.maxPatchChars });
      }

      // Fly each tool through the gate: deny stops by name, above the ceiling
      // asks the operator, allow executes.
      const sequence = [];
      for (const call of toolReply.tools) {
        const toolId = String((call && call.tool) || '');
        const args = (call && call.args) || {};
        const desc = opts.toolbox.descriptor(toolId);
        if (!desc) return { kind: 'pass', reason: 'unknown_tool', detail: `tool not mounted: ${toolId}` };

        const decision = gate.authorize(toolId, desc.risk);
        if (decision.decision === 'deny') {
          return { kind: 'pass', reason: 'denied', detail: `${toolId}: ${decision.reason}` };
        }
        if (decision.decision === 'require_approval') {
          let ok = false;
          if (typeof opts.approve === 'function') {
            try {
              ok = !!(await opts.approve({ toolId, args }));
            } catch {
              ok = false;
            }
          }
          if (!ok) return { kind: 'pass', reason: 'approval_required', detail: `${toolId} requires operator approval` };
        }

        let out;
        try {
          out = await opts.toolbox.execute(toolId, args);
        } catch (e) {
          return { kind: 'pass', reason: 'tool_error', detail: `${toolId}: ${String((e && e.message) || e)}` };
        }
        if (!out || out.ok === false) {
          return { kind: 'pass', reason: (out && out.reason) || 'tool_failed', detail: `${toolId}` };
        }
        sequence.push(toolId);
      }

      // The tools flew; the diff is what changed. A flight that changed
      // nothing is a named refusal, never an empty patch.
      const diff = await opts.toolbox.execute('forge.git_diff', {});
      const patch = diff && diff.ok && diff.result ? diff.result.diff : null;
      if (!patch || !String(patch).trim()) {
        return { kind: 'pass', reason: 'no_diff', detail: 'tools ran but produced no change' };
      }
      return {
        kind: 'proposal',
        patch: String(patch),
        summary: String(toolReply.summary || '(no summary)').slice(0, 500),
        toolSequence: sequence,
      };
    },
  };
}

module.exports = { buildToolPrompt, parseToolReply, toolPilotSeat };
