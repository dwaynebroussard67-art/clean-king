/**
 * referee.js — the build/test adapter. Turns a test run into a verdict the
 * forge can act on: green, red with named failing tests, or a broken build.
 *
 * THE VERDICT CONTRACT
 *
 *   { status: 'green' }                      exit 0
 *   { status: 'red', failing: [...] }        exit non-zero, named failing tests
 *   { status: 'red', failing: [], brokenBuild: true }
 *                                            exit non-zero, NO named failing
 *                                            test — the build/test harness
 *                                            itself broke (compile error,
 *                                            crash, missing runner).
 *   { status: 'unrunnable', reason }         the runner is not present at all
 *   { status: 'empty_response', reason }     passed, but produced no test signal
 *                                            (only when requireSignal is set)
 *
 * THE BROKEN-BUILD DISTINCTION, AND WHY IT MATTERS
 *
 * A compile error looks like "no tests failed", which — taken literally — looks
 * like progress. The forge's regression rule compares failing sets, so a broken
 * build with an empty failing set would otherwise advance the tree. The referee
 * therefore marks a non-zero exit with no named failing tests as `brokenBuild`,
 * and the forge refuses it as a regression instead of accepting it. A patch
 * that breaks the build is not a patch that fixes the bug.
 */

'use strict';

const { spawnSync } = require('node:child_process');

const RUNNER_MISSING = 'RUNNER_MISSING';

/**
 * Extract failing test names from common runner output. Conservative by design:
 * it recognises TAP (`not ok N - name`), Jest (`✕/✗/×/● name`, `FAIL file › name`),
 * and Mocha's failure list (`  1) name:`). A runner it cannot parse yields
 * nothing — and an empty parse on a non-zero exit is exactly what marks a
 * broken build. Skipped and TODO'd TAP lines are deliberately excluded.
 */
function parseFailing(output) {
  const out = String(output || '');
  const names = [];
  for (const line of out.split(/\r?\n/)) {
    const tap = line.match(/^\s*not ok\s+\d+\s*-\s*(.+?)\s*$/i);
    if (tap && !/#\s*(SKIP|TODO)/i.test(line)) names.push(tap[1].trim());
    const jest = line.match(/^\s*(?:✕|✗|×|●)\s+(.+?)\s*$/u);
    if (jest) names.push(jest[1].trim());
    const mocha = line.match(/^\s+\d+\)\s+(.+?)\s*$/);
    if (mocha) names.push(mocha[1].trim().replace(/:\s*$/, ''));
  }
  for (const m of out.matchAll(/^\s*FAIL\s+(\S+)(?:\s*›.*)?$/gm)) {
    names.push(m[1]);
  }
  const seen = new Set();
  return names
    .map((n) => n.trim())
    .filter((n) => n && !seen.has(n) && (seen.add(n), true));
}

/** A runner that shells out. Maps a missing command to RUNNER_MISSING so the
 *  referee can say `unrunnable` instead of crashing the run. */
function shellRunner(command, args = [], opts = {}) {
  return function run(dir) {
    const r = spawnSync(command, args, {
      cwd: dir,
      encoding: 'utf8',
      timeout: opts.timeout || 0,
      shell: opts.shell === true,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT') {
        const e = new Error(`runner not found: ${command}`);
        e.code = RUNNER_MISSING;
        throw e;
      }
      throw r.error;
    }
    return { code: r.status, stdout: r.stdout || '', stderr: r.stderr || '', signal: r.signal || null };
  };
}

class BuildRunnerReferee {
  /**
   * @param {object} opts
   * @param {(dir) => {code, stdout, stderr}} opts.run  runs the build; throws
   *        { code: RUNNER_MISSING } when the harness is absent
   * @param {(output) => string[]} [opts.parse]          failing-name parser
   * @param {boolean} [opts.requireSignal]               a green with no test
   *        signal becomes empty_response instead of green
   * @param {(sha) => void} [opts.checkout]              called with the sha
   *        before running — wire this to GitForgeRepo#checkout
   */
  constructor(opts = {}) {
    if (typeof opts.run !== 'function') {
      throw new Error('BuildRunnerReferee needs a run function.');
    }
    this.run = opts.run;
    this.dir = opts.dir || null; // the checkout the build runs in (e.g. the worktree)
    this.parse = opts.parse || parseFailing;
    this.requireSignal = opts.requireSignal === true;
    this.checkout = opts.checkout || null;
  }

  async verdict(sha) {
    if (this.checkout) {
      try {
        this.checkout(sha);
      } catch (e) {
        return { status: 'unrunnable', reason: String((e && e.message) || e) };
      }
    }
    let out;
    try {
      out = this.run(this.dir);
    } catch (e) {
      if (e && e.code === RUNNER_MISSING) return { status: 'unrunnable', reason: e.message };
      throw e;
    }

    if (out.signal) {
      return { status: 'red', failing: [], brokenBuild: true, reason: `the runner was killed by ${out.signal}` };
    }

    const failing = this.parse(`${out.stdout}\n${out.stderr}`);

    if (out.code === 0) {
      if (this.requireSignal && failing.length === 0) {
        return { status: 'empty_response', reason: 'the runner passed but produced no test signal' };
      }
      return { status: 'green' };
    }

    if (failing.length === 0) {
      return {
        status: 'red',
        failing: [],
        brokenBuild: true,
        reason: String(out.stderr || out.stdout || '').trim().slice(0, 400) || 'the build failed with no named failing test',
      };
    }
    return { status: 'red', failing };
  }
}

module.exports = { BuildRunnerReferee, shellRunner, parseFailing, RUNNER_MISSING };
