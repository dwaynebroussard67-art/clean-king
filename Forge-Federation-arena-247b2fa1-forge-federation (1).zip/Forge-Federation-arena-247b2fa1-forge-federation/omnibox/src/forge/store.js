/**
 * store.js — persistence for the Code Forge.
 *
 * THE PROBLEM THIS SOLVES
 *
 * The forge's memory (recorder), meter (budget), staged proposals, and a
 * suspended flight all live in process. Close the app while a run is paused and
 * that is gone — the relay would lose its place, which is the one thing the
 * hangar promised it would never do. This store is the disk.
 *
 * It is the sibling of the passport store (src/passport/store.js) and follows
 * the same disciplines:
 *
 *   - two files under one directory: `recorder.jsonl` (the hash-chained audit,
 *     one record per line) and `state.json` (budget, proposals, flight,
 *     replacements — everything that is state, not evidence);
 *   - the recorder file is APPEND-ONLY and HASH-CHAINED. A tampered log is a
 *     finding to report on load (never a throw, never fatal), because the
 *     recorder re-verifies its chain as it hydrates;
 *   - a torn or unparseable line is dropped and counted (`corrupt`), never a
 *     crash — the same posture as the passport store's torn final line;
 *   - no native modules, no database. `npm install` and nothing else.
 *
 * WHAT IS NOT PERSISTED, AND WHY
 *
 * The seats themselves. A seat is a function — `propose(ctx)` — and functions
 * do not serialize. On restart the operator re-seats the providers (the same
 * "a session is a list of places" contract the browser already uses), builds a
 * fresh CodeForge with those seats, and calls `adopt(store.load())`. The
 * persisted state is everything a resumed run needs: goal, tree, round,
 * verdict, failure memory, spend, proposals, and who replaced whom.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

const { ForgeRecorder } = require('./recorder.js');
const { ForgeBudget } = require('./budget.js');
const { ProposalLedger } = require('./forge.js');

class ForgeStore {
  constructor(dir) {
    if (!dir) throw new Error('FORGE_STORE: a directory is required.');
    this.dir = dir;
    this.recorderPath = path.join(dir, 'recorder.jsonl');
    this.statePath = path.join(dir, 'state.json');
  }

  /** Serialize and write both files. The recorder writes the raw chained
   *  records; the state file writes everything that is state, not evidence. */
  save(snapshot) {
    fs.mkdirSync(this.dir, { recursive: true });
    const recorder = snapshot.recorder || new ForgeRecorder();
    const budget = snapshot.budget || new ForgeBudget();
    const proposals = snapshot.proposals || new ProposalLedger();

    const jsonl = recorder.toJSONL();
    if (jsonl) fs.writeFileSync(this.recorderPath, jsonl + '\n', 'utf8');
    else fs.writeFileSync(this.recorderPath, '', 'utf8');

    const state = {
      budget: budget.snapshot(),
      proposals: proposals.snapshot(),
      flight: snapshot.flight || null,
      replacements: snapshot.replacements || {},
    };
    fs.writeFileSync(this.statePath, JSON.stringify(state, null, 2) + '\n', 'utf8');
    return { recorderPath: this.recorderPath, statePath: this.statePath };
  }

  /** Read both files and rebuild live instances. Returns a chain report plus a
   *  corrupt-line count; a tampered log is reported, never fatal. */
  load() {
    const recorder = new ForgeRecorder();
    let corrupt = 0;
    const records = [];
    if (fs.existsSync(this.recorderPath)) {
      const lines = fs.readFileSync(this.recorderPath, 'utf8').split('\n');
      for (const line of lines) {
        const s = line.trim();
        if (!s) continue;
        try {
          records.push(JSON.parse(s));
        } catch {
          corrupt++;
        }
      }
    }
    const chain = recorder.hydrate(records);

    let state = {};
    if (fs.existsSync(this.statePath)) {
      try {
        state = JSON.parse(fs.readFileSync(this.statePath, 'utf8'));
      } catch {
        state = {};
        corrupt++;
      }
    }

    const budget = new ForgeBudget();
    budget.hydrate(state.budget);
    const proposals = new ProposalLedger();
    proposals.hydrate(state.proposals);

    return {
      recorder,
      budget,
      proposals,
      flight: state.flight || null,
      replacements: state.replacements || {},
      chain,
      corrupt,
    };
  }
}

module.exports = { ForgeStore };
