/**
 * index.js — the Code Forge facade.
 *
 * The loop, its memory, its budget, and its proposal ledger — one door in.
 */

'use strict';

const { CodeForge, ProposalLedger, ProposalStateError, ForgeBusyError, ForgePausedError, MAX_ROUNDS, STOP_REASONS, isRegression, newlyBroken, fixedTests } = require('./forge.js');
const { ForgeRecorder, PROMOTE_AFTER, CHAIN_GENESIS, chainHash } = require('./recorder.js');
const { ForgeBudget, BudgetExceededError } = require('./budget.js');
const { ForgeBench } = require('./bench.js');
const { ForgeStore } = require('./store.js');
const { buildProposalPrompt, parseProposalReply, forgeSeat, dispatchSend, looksLikeDiff, extractDiff, extractSummary, DEFAULT_MAX_PATCH } = require('./seat-adapter.js');
const { RISK_RANK, authorize, DEFAULT_FORGE_AUTHORITY, CapabilityGate, safeRelPath, ForgeToolbox, toolError } = require('./tools.js');
const { buildToolPrompt, parseToolReply, toolPilotSeat } = require('./pilot.js');
const { detectTestCommand, CANDIDATES } = require('./runner.js');
const { ForgeController } = require('./controller.js');
const { GitForgeRepo, GitForgeError } = require('./git.js');
const { BuildRunnerReferee, shellRunner, parseFailing, RUNNER_MISSING } = require('./referee.js');

module.exports = {
  CodeForge,
  ProposalLedger,
  ProposalStateError,
  ForgeBusyError,
  ForgePausedError,
  ForgeRecorder,
  ForgeBudget,
  ForgeBench,
  ForgeStore,
  BudgetExceededError,
  buildProposalPrompt,
  parseProposalReply,
  forgeSeat,
  dispatchSend,
  looksLikeDiff,
  extractDiff,
  extractSummary,
  DEFAULT_MAX_PATCH,
  RISK_RANK,
  authorize,
  DEFAULT_FORGE_AUTHORITY,
  CapabilityGate,
  safeRelPath,
  ForgeToolbox,
  toolError,
  buildToolPrompt,
  parseToolReply,
  toolPilotSeat,
  detectTestCommand,
  CANDIDATES,
  ForgeController,
  GitForgeRepo,
  GitForgeError,
  BuildRunnerReferee,
  shellRunner,
  parseFailing,
  RUNNER_MISSING,
  MAX_ROUNDS,
  STOP_REASONS,
  PROMOTE_AFTER,
  CHAIN_GENESIS,
  chainHash,
  isRegression,
  newlyBroken,
  fixedTests,
};
