/**
 * recorder.js — the Code Forge's flight recorder.
 *
 * THE PROBLEM THIS SOLVES
 *
 * A forge run that only ever keeps the winning patch learns nothing from its
 * own dead ends. The user's loop — "knowledge of everything the ones before
 * them have tried and didn't work" — needs a memory that is (a) append-only,
 * so a failure is never quietly dropped, and (b) hash-chained, so the memory
 * is a verifiable fact rather than a claim. This file is that memory.
 *
 * It is the sibling of the passport store (src/passport/store.js) and uses the
 * same chain convention — genesis of 64 zeros, each line hashed with the line
 * before it, a break reported and never fatal. It also carries the maneuver
 * promotion rule from the engine's flight recorder (flight-recorder.ts):
 * a sequence of tools that succeeded PROMOTE_AFTER times and never failed is
 * a maneuver the plane owns. Successes alone are not enough — one failure
 * blocks, because a maneuver with a known failure mode is not a skill.
 *
 * THE DERIVATION RULE
 *
 * Nothing here keeps a second, parallel list of "what failed." The chained
 * records ARE the memory, and failureMemory() / alreadyTried() are derived by
 * walking them — if it is not in the log, it did not happen, and a derived
 * view that disagrees with the log is the bug, never the other way around.
 */

'use strict';

const { sha256 } = require('../passport/core.js');

const CHAIN_GENESIS = '0'.repeat(64);

/** A maneuver is not a skill until it has succeeded this many times — and it
 *  is never a skill if it has failed even once. */
const PROMOTE_AFTER = 5;

function chainHash(prev, op, data) {
  // Hash the {op, data} body in construction order, prefixed by the previous
  // line's hash — the same convention as the passport store, so a tamper with
  // either the body or the chain pointer changes the recomputed hash.
  const body = JSON.stringify({ op, data });
  return sha256(`${prev}\u0000${body}`);
}

class ForgeRecorder {
  constructor() {
    this.records = []; // chained records: { op, data, prev, hash }
    this.head = CHAIN_GENESIS;
    this.tried = new Set(); // patchDigest -> true, a derived index over attempts
    this.manoeuvres = new Map(); // signature -> { sequence, successes, failures }
  }

  /** The only write path. Every record is chained to the one before it. */
  append(op, data) {
    const prev = this.head;
    const hash = chainHash(prev, op, data);
    const rec = { op, data, prev, hash };
    this.records.push(rec);
    this.head = hash;
    if (op === 'attempt' && typeof data.patchDigest === 'string') {
      this.tried.add(data.patchDigest);
    }
    return rec;
  }

  alreadyTried(patchDigest) {
    return this.tried.has(patchDigest);
  }

  recordAttempt(input) {
    const {
      round,
      seatId,
      patchDigest,
      summary,
      status, // 'green' | 'red' | 'empty_response' | 'unrunnable'
      failing = [],
      detail = null,
      toolSequence = [],
    } = input;
    return this.append('attempt', {
      round,
      seatId,
      patchDigest,
      summary: String(summary || ''),
      status,
      failing,
      detail,
      toolSequence,
      at: new Date().toISOString(),
    });
  }

  recordRefusal({ round, seatId, reason, detail = null }) {
    return this.append('refusal', {
      round,
      seatId,
      reason,
      detail,
      at: new Date().toISOString(),
    });
  }

  /** A patch that made a previously-passing test fail was NOT accepted. The
   *  tree did not advance; this record says why. */
  recordRegression({ round, seatId, patchDigest, broke = [], whileFixing = [] }) {
    return this.append('regression', {
      round,
      seatId,
      patchDigest,
      broke,
      whileFixing,
      at: new Date().toISOString(),
    });
  }

  recordEvent(type, data = {}) {
    return this.append('event', { type, ...data, at: new Date().toISOString() });
  }

  /** Record one flown sequence. Sequences of one are ignored — a single call is
   *  not a skill, it is a tool, and the plane already has it. */
  recordManoeuvre(sequence, succeeded) {
    if (!Array.isArray(sequence) || sequence.length < 2) return null;
    const signature = sequence.join(' -> ');
    let m = this.manoeuvres.get(signature);
    if (!m) {
      m = { sequence, signature, successes: 0, failures: 0 };
      this.manoeuvres.set(signature, m);
    }
    if (succeeded) m.successes += 1;
    else m.failures += 1;
    return m;
  }

  /** Sequences that have succeeded PROMOTE_AFTER times and never failed. These
   *  are offered to seats as CONTEXT, never as authority — a seat still decides. */
  promotedSequences() {
    const out = [];
    for (const m of this.manoeuvres.values()) {
      if (m.successes >= PROMOTE_AFTER && m.failures === 0) out.push(m.sequence);
    }
    return out;
  }

  /**
   * The loop-back memory: what did not work, most recent last, capped at n.
   * Derived from the chain, never from a parallel structure. Each entry is a
   * compact sentence a seat can use — "tests still failing: auth, login" is
   * context; "regression: broke login while fixing auth" is a warning.
   */
  failureMemory(n) {
    const out = [];
    for (const rec of this.records) {
      const d = rec.data;
      if (rec.op === 'attempt' && d.status === 'red') {
        out.push({
          round: d.round,
          seatId: d.seatId,
          patchDigest: d.patchDigest,
          reason: `tests still failing: ${(d.failing || []).join(', ')}`,
        });
      } else if (rec.op === 'attempt' && d.status === 'empty_response') {
        out.push({
          round: d.round,
          seatId: d.seatId,
          patchDigest: d.patchDigest,
          reason: `empty response: ${d.detail || 'nothing runnable changed'}`,
        });
      } else if (rec.op === 'regression') {
        out.push({
          round: d.round,
          seatId: d.seatId,
          patchDigest: d.patchDigest,
          reason: `regression: broke ${(d.broke || []).join(', ') || 'nothing named'}` +
            (d.whileFixing && d.whileFixing.length ? ` while fixing ${d.whileFixing.join(', ')}` : ''),
        });
      } else if (rec.op === 'refusal') {
        out.push({
          round: d.round,
          seatId: d.seatId,
          reason: `refused: ${d.reason}${d.detail ? ` (${d.detail})` : ''}`,
        });
      }
    }
    return out.slice(-n);
  }

  /** Recompute the chain over everything recorded. A break is a finding to
   *  report, never a reason to stop looking — and never a throw. */
  verify() {
    const out = { head: CHAIN_GENESIS, chained: 0, breaks: [] };
    for (let i = 0; i < this.records.length; i++) {
      const rec = this.records[i];
      const expected = chainHash(out.head, rec.op, rec.data);
      if (rec.prev !== out.head || rec.hash !== expected) {
        out.breaks.push({ index: i, op: rec.op, expected, stored: rec.hash });
      }
      // Continue from the stored hash so a single tamper is localized to one
      // reported break rather than cascading into a wall of them.
      out.head = rec.hash;
      out.chained += 1;
    }
    return out;
  }

  toJSONL() {
    return this.records.map((r) => JSON.stringify(r)).join('\n');
  }

  /** A serializable snapshot: the chained records, nothing else. The tried
   *  index and the maneuver map are derived from the records on hydrate — if it
   *  is not in the log, it did not happen. */
  snapshot() {
    return { records: this.records.slice() };
  }

  /**
   * Rebuild the recorder from persisted records. The chain is recomputed and
   * verified as part of loading, and the derived indexes (tried, manoeuvres)
   * are rebuilt from the attempt records — never from a parallel store, so a
   * tampered log yields a tampered memory, never a silent disagreement.
   *
   * @returns the chain report from verify(): { head, chained, breaks }.
   */
  hydrate(records) {
    this.records = [];
    this.head = CHAIN_GENESIS;
    this.tried = new Set();
    this.manoeuvres = new Map();
    for (const rec of records || []) {
      this.records.push(rec);
      this.head = rec.hash;
      const d = rec.data;
      if (rec.op === 'attempt') {
        if (typeof d.patchDigest === 'string') this.tried.add(d.patchDigest);
        if (Array.isArray(d.toolSequence)) {
          this.recordManoeuvre(d.toolSequence, d.status === 'green');
        }
      }
    }
    return this.verify();
  }

  get count() {
    return this.records.length;
  }
}

module.exports = { ForgeRecorder, PROMOTE_AFTER, CHAIN_GENESIS, chainHash };
