/**
 * controller.js — the Code Forge, owned end to end.
 *
 * THE PROBLEM THIS SOLVES
 *
 * The loop, the git adapter, the referee, the bench, the seat adapter and the
 * tool pilot are all pure and tested. What is missing is the thing that owns
 * them together and speaks to the UI: launch a run over a real repo, stream its
 * events, let the human stop / resume / release / reject, and persist the
 * tamper-evident memory. This file is that owner.
 *
 * It is STILL pure: no Electron import. Seats arrive as { id, name, send }
 * descriptors; the directory for persistence is injected. The production glue
 * — building `send` from the table's dispatch, a file picker, the local-model
 * bench seat — lives in main.js, which is thin and untestable here.
 *
 * THE HUMAN REMAINS STEP FOUR
 *
 * A run only ever STAGES a proposal. release(id) merges the forge branch into
 * the base branch and records the act; reject(id) records the refusal and
 * leaves the branch. The loop never merges. The loop never runs unattended:
 * stop() sets the kill switch the loop checks between rounds and between seats.
 */

'use strict';

const { CodeForge } = require('./forge.js');
const { ForgeStore } = require('./store.js');
const { GitForgeRepo } = require('./git.js');
const { BuildRunnerReferee, shellRunner } = require('./referee.js');
const { ForgeToolbox } = require('./tools.js');
const { toolPilotSeat } = require('./pilot.js');
const { detectTestCommand } = require('./runner.js');

class ForgeController {
  /**
   * @param {object} opts
   * @param {string} opts.storeDir           where recorder.jsonl + state.json live
   * @param {(msg:{event:string,payload:object})=>void} [opts.emit]  event stream to the UI
   * @param {boolean} [opts.autoApproveRunTests]  the launch IS the approval; the
   *        pilot's run_tests is auto-approved within a launched run
   * @param {number} [opts.maxLog]
   */
  constructor(opts = {}) {
    if (!opts.storeDir) throw new Error('FORGE_CONTROLLER: storeDir is required.');
    this.store = new ForgeStore(opts.storeDir);
    this.emit = opts.emit || (() => {});
    this.autoApproveRunTests = opts.autoApproveRunTests !== false;
    this.maxLog = opts.maxLog || 200;

    this.forge = null;
    this.repo = null;
    this.runPromise = null;
    this.runId = null;
    this.lastResult = null;
    this.lastSpec = null;
    this.log = []; // ring of { t, event, ...payload } for the UI
    this.saved = null;
    this._loadSaved();
  }

  get active() {
    return !!(this.forge && this.forge.running);
  }

  get paused() {
    return !!(this.forge && this.forge.isPaused);
  }

  /** The run promise, so a test (or a shutdown) can await completion. */
  whenIdle() {
    return this.runPromise || Promise.resolve(this.lastResult);
  }

  _emit(event, payload) {
    this.emit({ event, payload });
  }

  _push(event, payload) {
    this.log.push({ t: Date.now(), event, ...payload });
    if (this.log.length > this.maxLog) this.log.splice(0, this.log.length - this.maxLog);
  }

  _loadSaved() {
    const s = this.store.load();
    this.saved = {
      paused: !!s.flight,
      runId: (s.flight && s.flight.runId) || null,
      proposals: s.proposals.entries.map((e) => ({ id: e.id, branch: e.branch, seatId: e.seatId, summary: e.summary, status: e.status, at: e.at })),
      chainBreaks: s.chain.breaks.length,
      corrupt: s.corrupt,
    };
  }

  _save() {
    if (this.forge) this.store.save(this.forge.snapshot());
    this._loadSaved();
  }

  _buildForge(spec, repo, seats, bench) {
    const command = detectTestCommand(repo.repoDir);
    const runTests = () => shellRunner(command.command, command.args)(repo.worktreeDir);
    const toolbox = new ForgeToolbox({ worktreeDir: repo.worktreeDir, runTests });

    const wrap = (d) =>
      toolPilotSeat({
        id: d.id,
        name: d.name,
        send: d.send,
        toolbox,
        checkout: (sha) => repo.checkout(sha),
        approve: () => this.autoApproveRunTests,
        gatherContext: typeof d.gatherContext === 'function' ? d.gatherContext : undefined,
      });

    const budget = {};
    const maxCalls = spec.seatBudget && spec.seatBudget.maxCalls;
    for (const d of [...seats, ...bench]) {
      if (maxCalls) budget[d.id] = { maxCalls, tier: 'forge-run' };
    }

    const onEvent = (ev) => {
      this._push(ev.type, ev);
      this._emit(ev.type, ev);
    };

    const referee = {
      async verdict(sha) {
        repo.checkout(sha);
        return new BuildRunnerReferee({ run: runTests, dir: repo.worktreeDir }).verdict();
      },
    };

    return new CodeForge({
      goal: spec.goal.trim(),
      trunk: repo.trunk(),
      seats: seats.map(wrap),
      bench: bench.map(wrap),
      budget,
      maxRounds: spec.maxRounds,
      referee,
      apply: (tree, patch) => repo.apply(tree, patch),
      proposalBranch: () => repo.branch,
      onEvent,
    });
  }

  /** Launch a run. Returns { ok:true } and streams events; the run proceeds in
   *  the background and persists itself when it finishes. */
  async launch(spec = {}) {
    if (this.active) return { ok: false, reason: 'busy', detail: 'a run is already in progress' };
    if (this.paused) return { ok: false, reason: 'paused', detail: 'resume the suspended run, or start fresh' };
    const goal = spec.goal && String(spec.goal).trim();
    if (!goal) return { ok: false, reason: 'goal_required' };
    if (!spec.repoDir) return { ok: false, reason: 'repo_required' };
    const seats = Array.isArray(spec.seats) ? spec.seats.filter((s) => s && typeof s.send === 'function') : [];
    if (seats.length === 0) return { ok: false, reason: 'no_seats', detail: 'seat at least one AI first' };
    const bench = Array.isArray(spec.bench) ? spec.bench.filter((s) => s && typeof s.send === 'function') : [];

    const repo = new GitForgeRepo({ repoDir: spec.repoDir, base: spec.base || null });
    try {
      repo.setup();
    } catch (e) {
      try {
        repo.dispose();
      } catch {
        /* not set up yet */
      }
      return { ok: false, reason: 'repo_error', detail: String((e && e.message) || e) };
    }
    if (!detectTestCommand(repo.repoDir)) {
      repo.dispose();
      return { ok: false, reason: 'no_test_command', detail: 'no package.json, test.sh, Makefile, Cargo.toml, go.mod or pyproject.toml found' };
    }

    const forge = this._buildForge(spec, repo, seats, bench);
    this.forge = forge;
    this.repo = repo;
    this.lastSpec = {
      goal,
      repoDir: spec.repoDir,
      base: spec.base || repo.baseBranch,
      maxRounds: spec.maxRounds,
      seatBudget: spec.seatBudget || null,
    };

    this._emit('run:started', { goal, repoDir: spec.repoDir, branch: repo.branch, seats: seats.map((s) => s.id) });

    this.runPromise = forge
      .run()
      .then((result) => {
        this.runId = result.runId;
        this.lastResult = result;
        this._save();
        this._emit('run:finished', this._summary(result));
        return result;
      })
      .catch((e) => {
        this._emit('run:error', { detail: String((e && e.message) || e) });
        return null;
      });

    return { ok: true, branch: repo.branch };
  }

  /** The operator's kill switch. */
  stop() {
    if (this.forge) this.forge.stop();
    return { ok: true };
  }

  /** Continue a suspended run. The seats are the same live tabs in the same
   *  process; a tab that has been closed is refused honestly by its send. */
  async resume(opts = {}) {
    if (!this.forge) return { ok: false, reason: 'no_run' };
    if (this.active) return { ok: false, reason: 'busy' };
    if (!this.forge.isPaused) return { ok: false, reason: 'not_paused' };
    if (opts.resetBudgets) this.forge.resetBudgets();
    this._emit('run:resumed', { runId: this.runId });
    this.runPromise = this.forge
      .resume()
      .then((result) => {
        this.runId = result.runId;
        this.lastResult = result;
        this._save();
        this._emit('run:finished', this._summary(result));
        return result;
      })
      .catch((e) => {
        this._emit('run:error', { detail: String((e && e.message) || e) });
        return null;
      });
    return { ok: true };
  }

  /** The human, and only the human, merges a staged proposal. */
  release(id) {
    if (!this.forge) return { ok: false, reason: 'no_run' };
    const p = this.forge.proposals.entries.find((e) => e.id === id);
    if (!p) return { ok: false, reason: 'not_found' };
    if (p.status !== 'staged') return { ok: false, reason: 'not_staged', detail: `proposal is ${p.status}` };
    try {
      if (this.repo) this.repo.releaseToBase(p.branch, `Forge Flight: accept proposal — ${p.summary}`);
      this.forge.proposals.release(id);
      this._save();
      this._emit('proposal:released', { id, branch: p.branch });
      return { ok: true, id };
    } catch (e) {
      return { ok: false, reason: 'release_error', detail: String((e && e.message) || e) };
    }
  }

  /** The human records a refusal. The branch stays; nothing is merged. */
  reject(id, reason) {
    if (!this.forge) return { ok: false, reason: 'no_run' };
    const p = this.forge.proposals.entries.find((e) => e.id === id);
    if (!p) return { ok: false, reason: 'not_found' };
    if (p.status !== 'staged') return { ok: false, reason: 'not_staged', detail: `proposal is ${p.status}` };
    this.forge.proposals.reject(id, reason || null);
    this._save();
    this._emit('proposal:rejected', { id });
    return { ok: true, id };
  }

  _summary(result) {
    return {
      runId: result.runId,
      stopReason: result.stopReason,
      stopSentence: result.stopSentence,
      resumable: result.resumable,
      roundsRun: result.roundsRun,
      attempts: result.attempts,
      proposal: result.proposal
        ? { id: result.proposal.id, branch: result.proposal.branch, seatId: result.proposal.seatId, summary: result.proposal.summary }
        : null,
      failureMemory: (result.failureMemory || []).slice(-5),
      promotedSequences: result.promotedSequences || [],
      benchRemaining: result.benchRemaining,
      chainBreaks: result.chain ? result.chain.breaks.length : 0,
    };
  }

  /** The view model the UI renders. */
  view() {
    const proposals = this.forge
      ? this.forge.proposals.entries.map((e) => ({ id: e.id, branch: e.branch, seatId: e.seatId, summary: e.summary, status: e.status, at: e.at }))
      : this.saved.proposals;
    return {
      active: this.active,
      paused: this.paused,
      runId: this.runId,
      goal: this.lastSpec ? this.lastSpec.goal : null,
      repoDir: this.lastSpec ? this.lastSpec.repoDir : null,
      branch: this.repo ? this.repo.branch : null,
      lastResult: this.lastResult ? this._summary(this.lastResult) : null,
      proposals,
      log: this.log.slice(),
      saved: this.saved,
    };
  }
}

module.exports = { ForgeController };
