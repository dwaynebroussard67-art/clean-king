/**
 * forge.js — the Code Forge loop.
 *
 * THE PROBLEM THIS SOLVES
 *
 * Several seats, in relay, over a codebase, looping until the build is green —
 * with every hand knowing what the hands before it tried and failed. That is
 * the product. This file is the harness that makes it a bounded, honest,
 * stoppable machine instead of a firehose.
 *
 * THE SHAPE OF A RUN
 *
 *   1. The trunk is verdicted FIRST. A forge whose referee cannot even run the
 *      starting tree is refused by name before a single seat is dispatched. A
 *      trunk that is already green is refused as `already_green` — write the
 *      failing tests for what you want first (red-test-driven forging), then
 *      run again.
 *   2. Each round walks the seats in relay order. A seat is charged BEFORE it
 *      is dispatched; an exhausted seat is ejected, never billed.
 *   3. A seat proposes a patch against the current tree. The patch must apply
 *      and must CHANGE the tree — a no-op is refused as `no_change`.
 *   4. The referee verdicts the candidate. Green stops the loop and STAGES a
 *      proposal — it does not apply it. Every commit is a proposal; the human
 *      releases. Red advances the tree only if nothing that was passing broke;
 *      a regression is reverted and recorded, never accepted silently.
 *   5. Failures accumulate in the recorder and are fed back to every seat on
 *      the next dispatch. What did not work is context; what worked is offered
 *      as a promoted maneuver, never as authority.
 *
 * THE ORDERING RULE THAT MUST NOT BE RELAXED
 *
 * Charge before dispatch. Verdict before accept. Refuse before guess. Each of
 * the three is a gate that sits on the correct side of the spend, and the
 * tests assert the ordering, not just the outcome.
 */

'use strict';

const { createHash, randomBytes } = require('node:crypto');
const { ForgeRecorder } = require('./recorder.js');
const { ForgeBudget, BudgetExceededError } = require('./budget.js');
const { ForgeBench } = require('./bench.js');

/** A run may not loop forever. The relay shape in the engine is capped at 4;
 *  the forge inherits the same ceiling and a spec may lower it, never raise it. */
const MAX_ROUNDS = 4;

const sha256 = (s) => createHash('sha256').update(String(s), 'utf8').digest('hex');

const newId = (prefix) => `${prefix}_${randomBytes(6).toString('hex')}`;

/** Every way a run can end, named, with the sentence a human reads. A thing
 *  that must show its work names its stops. */
const STOP_REASONS = Object.freeze({
  goal_reached: 'the referee judged the tree green; the winning patch is staged as a proposal, not applied to the trunk',
  already_green: 'the trunk already passes the referee; write the failing tests for what you want, then run again',
  round_cap: 'the loop reached its declared round cap without green',
  budget_exhausted: 'every seat is out of allowance and there is no bench to replace them, so the loop cannot dispatch',
  paused: 'every seat is out of allowance and the bench is empty; the run is suspended, not dead, and resumes when allowances reset or a seat is added',
  stalled: 'a full round produced no new accepted change — every seat refused, repeated itself, or regressed',
  no_harness: 'the referee cannot run the build or tests, so progress is unverifiable',
  cancelled: 'the operator stopped the loop',
  error: 'an unrecoverable error ended the loop',
});

class ForgeBusyError extends Error {
  constructor() {
    super('FORGE_BUSY: a run is already in progress on this forge.');
    this.name = 'ForgeBusyError';
  }
}

class ForgePausedError extends Error {
  constructor(message) {
    super(message || 'FORGE_PAUSED: a run is suspended on this forge.');
    this.name = 'ForgePausedError';
  }
}

class ProposalStateError extends Error {
  constructor(proposalId, status) {
    super(`PROPOSAL_STATE: proposal ${proposalId} is ${status}; it cannot be released or rejected again.`);
    this.name = 'ProposalStateError';
  }
}

/**
 * The proposal ledger — the git-as-proposal model. The loop only ever STAGES.
 * `release` and `reject` are the human's explicit step — the Federation's "you
 * are step four," applied to git. In production each entry is a branch named
 * `forge/{id}`, and releasing is a merge the human performs and records here.
 */
class ProposalLedger {
  constructor() {
    this.entries = [];
    this.seq = 0;
  }

  stage({ seatId, patch, summary, patchDigest, branch }) {
    this.seq += 1;
    const entry = {
      id: `proposal_${this.seq}`,
      branch: branch || `forge/${this.seq}-${patchDigest.slice(0, 12)}`,
      seatId,
      patch,
      summary,
      patchDigest,
      status: 'staged',
      at: new Date().toISOString(),
    };
    this.entries.push(entry);
    return entry;
  }

  release(id) {
    const e = this.entries.find((x) => x.id === id);
    if (!e) throw new ProposalStateError(id, 'missing');
    if (e.status !== 'staged') throw new ProposalStateError(id, e.status);
    e.status = 'released';
    e.releasedAt = new Date().toISOString();
    return e;
  }

  reject(id, reason) {
    const e = this.entries.find((x) => x.id === id);
    if (!e) throw new ProposalStateError(id, 'missing');
    if (e.status !== 'staged') throw new ProposalStateError(id, e.status);
    e.status = 'rejected';
    e.reason = reason || null;
    e.rejectedAt = new Date().toISOString();
    return e;
  }

  staged() {
    return this.entries.filter((e) => e.status === 'staged');
  }

  snapshot() {
    return { entries: this.entries.slice(), seq: this.seq };
  }

  hydrate(state) {
    this.entries = ((state && state.entries) || []).slice();
    this.seq = (state && state.seq) || 0;
  }
}

/** Is `next` a regression against `prev`? A patch has regressed when it breaks
 *  a test that was passing before — including turning a green tree red. Fixing
 *  a test while breaking another is still a regression: we never knowingly
 *  break what already worked. */
function newlyBroken(prev, next) {
  if (!prev || prev.status !== 'red') return [];
  const p = new Set(prev.failing || []);
  return (next.failing || []).filter((t) => !p.has(t));
}

function fixedTests(prev, next) {
  if (!prev || prev.status !== 'red') return [];
  const n = new Set(next.failing || []);
  return (prev.failing || []).filter((t) => !n.has(t));
}

function isRegression(prev, next) {
  if (!prev) return false;
  if (prev.status === 'green' && next.status !== 'green') return true;
  if (prev.status === 'red' && next.status === 'red') return newlyBroken(prev, next).length > 0;
  return false;
}

class CodeForge {
  /**
   * @param {object} spec
   * @param {string} spec.goal              what the loop is trying to achieve
   * @param {any} spec.trunk                the starting tree (opaque to the loop)
   * @param {Array<object>} spec.seats      relay order; each seat has id, label,
   *                                        propose(ctx) -> Promise<reply>, and an
   *                                        optional costUsd per dispatch
   * @param {{ verdict(tree) -> Promise<verdict> }} spec.referee   build/tests
   * @param {(tree, patch) => {ok:boolean, tree?, changed?, reason?}} spec.apply
   * @param {number} [spec.maxRounds]       cap, lowered from MAX_ROUNDS only
   * @param {object} [spec.budget]          seatId -> { maxCalls?, maxUsd?, tier }
   * @param {Array<object>} [spec.bench]    spare seats, in order; swapped into a
   *                                        relay slot when the seat in it is
   *                                        ejected. Omitting bench keeps the
   *                                        terminal `budget_exhausted` behavior;
   *                                        providing it (even empty) makes the
   *                                        forge PAUSE instead and resume later.
   * @param {number} [spec.maxFailuresRemembered]  loop-back memory cap
   * @param {(event) => void} [spec.onEvent]
   */
  constructor(spec) {
    if (!spec || !Array.isArray(spec.seats) || spec.seats.length === 0) {
      throw new Error('FORGE_SPEC: a forge needs at least one seat.');
    }
    if (typeof spec.referee?.verdict !== 'function' || typeof spec.apply !== 'function') {
      throw new Error('FORGE_SPEC: a forge needs a referee and an apply function.');
    }
    this.spec = spec;
    this.maxRounds = spec.maxRounds !== undefined ? Math.min(spec.maxRounds, MAX_ROUNDS) : MAX_ROUNDS;
    this.maxFailuresRemembered = spec.maxFailuresRemembered !== undefined ? spec.maxFailuresRemembered : 20;
    this.recorder = new ForgeRecorder();
    this.budget = new ForgeBudget();
    this.proposals = new ProposalLedger();
    this.bench = new ForgeBench(spec.bench || []);
    this.pausable = spec.bench !== undefined;
    this.slots = spec.seats.slice(); // the mutable relay; replacements write into it
    this.replacements = new Map(); // seatId -> { replacedSeatId, joinedAt }
    this.flight = null; // suspended run state, set on pause, consumed by resume()
    this.running = false;
    this.stopRequested = false;
  }

  /** The operator's kill switch. Checked between rounds and between seats; a
   *  run only ever continues while someone is watching. */
  stop() {
    this.stopRequested = true;
  }

  /** Start a fresh run. Refuses while a run is in progress or suspended. */
  async run() {
    if (this.running) throw new ForgeBusyError();
    if (this.flight) {
      throw new ForgePausedError('FORGE_PAUSED: a run is suspended; call resume() to continue it, or reset() to abandon it.');
    }
    return this._start(null);
  }

  /** Continue a suspended run. The recorder, budget, tree and round counter are
   *  all exactly where the pause left them. */
  async resume() {
    if (this.running) throw new ForgeBusyError();
    if (!this.flight) throw new ForgePausedError('FORGE_PAUSED: there is no suspended run to resume.');
    const flight = this.flight;
    this.flight = null;
    return this._start(flight);
  }

  /** Abandon a suspended run. The recorder and proposals are untouched — this
   *  only forgets the in-flight loop state. */
  reset() {
    this.flight = null;
    this.stopRequested = false;
  }

  /** Add a spare seat to the bench — the "user added a provider" path. */
  addSeat(seat) {
    this.bench.add(seat);
    if (seat && seat.id) {
      const b = this.spec.budget && this.spec.budget[seat.id];
      this.budget.provision(seat.id, b || {});
    }
    return this.bench.remaining;
  }

  /** A new day: un-eject every seat and zero its usage. Allowances stay. */
  resetBudgets() {
    for (const id of [...this.budget.allowances.keys()]) this.budget.reset(id);
  }

  get isPaused() {
    return this.flight !== null;
  }

  /** The full run state, in a shape the store can serialize. Seats are NOT
   *  included — they are re-seated by the operator on restart. */
  snapshot() {
    return {
      recorder: this.recorder,
      budget: this.budget,
      proposals: this.proposals,
      flight: this.flight,
      replacements: Object.fromEntries(this.replacements),
    };
  }

  /** Adopt a loaded run state (from ForgeStore#load). Replaces the in-memory
   *  recorder, budget, proposals, suspended flight and replacement ledger with
   *  the persisted ones, so resume() can continue across a restart. */
  adopt(state) {
    if (state.recorder) this.recorder = state.recorder;
    if (state.budget) this.budget = state.budget;
    if (state.proposals) this.proposals = state.proposals;
    this.flight = state.flight || null;
    this.replacements = new Map(Object.entries(state.replacements || {}));
    return this;
  }

  /** Swap a spare seat into slot `i`: provision its allowance, record who it
   *  replaced, and tell the human. The newcomer gets the full propose(ctx) on
   *  its first dispatch, same as every other seat — the context is already the
   *  memory of the run. */
  _seatReplacement(slotIndex, ejected, next, round, onEvent) {
    const b = this.spec.budget && this.spec.budget[next.id];
    this.budget.provision(next.id, b || {});
    this.replacements.set(next.id, { replacedSeatId: ejected.id, joinedAt: round });
    this.slots[slotIndex] = next;
    this.recorder.recordEvent('seat_swapped', { round, slot: slotIndex, ejected: ejected.id, seated: next.id });
    onEvent({ type: 'seat:swapped', round, slot: slotIndex, ejected: ejected.id, seated: next.id });
  }

  async _start(flight) {
    this.running = true;
    this.stopRequested = false;

    const onEvent = this.spec.onEvent || (() => {});
    const goal = flight ? flight.goal : this.spec.goal;
    const runId = flight ? flight.runId : newId('forge');
    const slots = this.slots;

    let stop = null;
    let round = flight ? flight.round : 0;
    let tree = flight ? flight.tree : this.spec.trunk;
    let lastVerdict = flight ? flight.lastVerdict : null;
    let priorSeat = flight ? flight.priorSeat : null;
    let winning = null;

    if (flight) {
      onEvent({ type: 'run:resumed', runId, round, goal });
    } else {
      // Provision the budget for the initial seats. A seat with no provision is
      // unmetered — counted, never ejected.
      for (const seat of slots) {
        const b = this.spec.budget && this.spec.budget[seat.id];
        this.budget.provision(seat.id, b || {});
      }
      onEvent({ type: 'run:started', runId, goal, seats: slots.map((s) => s.id) });
    }

    try {
      if (!flight) {
        // ── The trunk is verdicted first ─────────────────────────────────────
        const initial = await this.safeVerdict(tree, onEvent, runId);
        if (!initial) {
          stop = 'error';
        } else if (initial.status === 'green') {
          stop = 'already_green';
        } else if (initial.status !== 'red') {
          stop = 'no_harness';
        } else {
          lastVerdict = initial;
        }
      }

      outer: while (stop === null) {
        if (this.stopRequested) {
          stop = 'cancelled';
          break;
        }
        if (round >= this.maxRounds) {
          stop = 'round_cap';
          break;
        }
        round += 1;

        let changed = false;
        onEvent({ type: 'round:started', round });

        for (let i = 0; i < slots.length; i++) {
          if (this.stopRequested) {
            stop = 'cancelled';
            break outer;
          }

          // Make sure a live seat occupies this slot: swap out ejected
          // occupants for the next spare until one can fly.
          let seat = slots[i];
          for (;;) {
            if (!this.budget.ejected(seat.id)) break;
            const next = this.bench.seatNext();
            if (!next) break;
            this._seatReplacement(i, seat, next, round, onEvent);
            seat = slots[i];
          }
          if (this.budget.ejected(seat.id)) continue; // slot empty, no spare

          // 1. Charge BEFORE the request leaves; swap in a spare on ejection.
          let charged;
          for (;;) {
            try {
              charged = this.budget.chargeBeforeDispatch(seat.id, seat.costUsd || 0);
              break;
            } catch (e) {
              if (!(e instanceof BudgetExceededError)) throw e;
              this.budget.eject(seat.id);
              this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'budget_exhausted', detail: e.message });
              onEvent({ type: 'seat:ejected', round, seatId: seat.id });
              const next = this.bench.seatNext();
              if (!next) {
                seat = null;
                break;
              }
              this._seatReplacement(i, seat, next, round, onEvent);
              seat = slots[i];
            }
          }
          if (!seat) continue;
          onEvent({ type: 'seat:charged', round, seatId: seat.id, usage: charged });

          // 2. The seat proposes against the current tree, with the loop-back
          //    memory of what did not work — and, if it is a replacement, the
          //    name of the seat it replaced.
          let reply;
          try {
            reply = await seat.propose({
              goal,
              round,
              tree,
              failures: this.recorder.failureMemory(this.maxFailuresRemembered),
              knownGoodSequences: this.recorder.promotedSequences(),
              priorSeat,
              replacedSeat: (this.replacements.get(seat.id) || {}).replacedSeatId || null,
              joinedAt: (this.replacements.get(seat.id) || {}).joinedAt || null,
            });
          } catch (e) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'seat_error', detail: String(e && e.message ? e.message : e) });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'seat_error' });
            continue;
          }
          onEvent({ type: 'seat:proposed', round, seatId: seat.id });

          // 3. Named refusals — a seat that will not or cannot propose.
          if (!reply || reply.kind === 'pass') {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: (reply && reply.reason) || 'pass' });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'pass' });
            continue;
          }
          if (reply.kind === 'bad_shape') {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'bad_shape', detail: reply.detail });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'bad_shape' });
            continue;
          }

          const patch = reply.patch;
          const summary = String(reply.summary || '');
          const patchDigest = sha256(patch);

          // A patch we have already tried this run would reproduce its verdict.
          if (this.recorder.alreadyTried(patchDigest)) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'redundant', detail: 'the same patch was already tried this run' });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'redundant' });
            continue;
          }

          // 4. Apply. A patch that does not apply, or does not change the
          //    tree, is refused — a no-op is not progress.
          let applied;
          try {
            applied = this.spec.apply(tree, patch);
          } catch (e) {
            stop = 'error';
            this.recorder.recordEvent('apply_error', { round, seatId: seat.id, detail: String(e && e.message ? e.message : e) });
            break outer;
          }
          if (!applied || applied.ok === false) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'does_not_apply', detail: applied && applied.reason });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'does_not_apply' });
            continue;
          }
          if (applied.changed === false) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRefusal({ round, seatId: seat.id, reason: 'no_change', detail: 'the patch does not change the tree' });
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'no_change' });
            continue;
          }

          // 5. Verdict BEFORE accept.
          let verdict;
          try {
            verdict = await this.spec.referee.verdict(applied.tree);
          } catch (e) {
            stop = 'error';
            this.recorder.recordEvent('referee_error', { round, seatId: seat.id, detail: String(e && e.message ? e.message : e) });
            break outer;
          }

          const toolSequence = Array.isArray(reply.toolSequence) ? reply.toolSequence : [];

          if (verdict.status === 'green') {
            this.recorder.recordAttempt({ round, seatId: seat.id, patchDigest, summary, status: 'green', toolSequence });
            this.recorder.recordManoeuvre(toolSequence, true);
            const branch = typeof this.spec.proposalBranch === 'function'
              ? this.spec.proposalBranch({ seatId: seat.id, patchDigest })
              : undefined;
            winning = this.proposals.stage({ seatId: seat.id, patch, summary, patchDigest, branch });
            stop = 'goal_reached';
            onEvent({ type: 'goal:reached', round, seatId: seat.id, proposalId: winning.id });
            break outer;
          }

          if (verdict.status === 'unrunnable') {
            this.recorder.recordAttempt({ round, seatId: seat.id, patchDigest, summary, status: 'unrunnable', detail: verdict.reason, toolSequence });
            this.recorder.recordManoeuvre(toolSequence, false);
            stop = 'no_harness';
            break outer;
          }

          if (verdict.status === 'empty_response') {
            this.budget.markFailed(seat.id);
            this.recorder.recordAttempt({ round, seatId: seat.id, patchDigest, summary, status: 'empty_response', detail: verdict.reason, toolSequence });
            this.recorder.recordManoeuvre(toolSequence, false);
            onEvent({ type: 'seat:refused', round, seatId: seat.id, reason: 'empty_response' });
            continue;
          }

          // 6. Red: regression refused, progress accepted.
          this.recorder.recordAttempt({ round, seatId: seat.id, patchDigest, summary, status: 'red', failing: verdict.failing || [], toolSequence });
          this.recorder.recordManoeuvre(toolSequence, false);

          // A broken build (compile error, crashed harness) reports no named
          // failing test — which a naive failing-set comparison would read as
          // "progress." It is the opposite: a patch that breaks the build is a
          // regression, refused by name.
          if (verdict.brokenBuild === true) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRegression({
              round,
              seatId: seat.id,
              patchDigest,
              broke: ['build'],
              whileFixing: fixedTests(lastVerdict, verdict),
            });
            onEvent({ type: 'seat:regressed', round, seatId: seat.id, detail: 'broken build' });
            continue;
          }

          if (isRegression(lastVerdict, verdict)) {
            this.budget.markFailed(seat.id);
            this.recorder.recordRegression({
              round,
              seatId: seat.id,
              patchDigest,
              broke: newlyBroken(lastVerdict, verdict),
              whileFixing: fixedTests(lastVerdict, verdict),
            });
            onEvent({ type: 'seat:regressed', round, seatId: seat.id });
            continue; // the tree does NOT advance
          }

          tree = applied.tree;
          lastVerdict = verdict;
          changed = true;
          priorSeat = { id: seat.id, summary };
          onEvent({ type: 'seat:accepted', round, seatId: seat.id, failing: verdict.failing || [] });
        }

        if (stop !== null) break;
        if (this.stopRequested) {
          stop = 'cancelled';
          break;
        }
        // Before declaring a stall, honor the pause: every slot exhausted and
        // no spare left is a suspension, not a verdict about the seats' skill.
        if (this.budget.allExhausted(slots.map((s) => s.id)) && this.bench.isEmpty()) {
          stop = this.pausable ? 'paused' : 'budget_exhausted';
          break;
        }
        if (!changed) {
          stop = 'stalled';
          break;
        }
        onEvent({ type: 'round:finished', round });
      }
    } finally {
      this.running = false;
    }

    const reason = stop || 'error';

    if (reason === 'paused') {
      // Freeze the flight exactly where it is; the memory survives in the
      // recorder and the budget, and resume() continues from this frame.
      this.flight = { goal, runId, round, tree, lastVerdict, priorSeat };
    } else {
      this.flight = null;
    }

    const result = {
      runId,
      goal,
      stopReason: reason,
      stopSentence: STOP_REASONS[reason],
      resumable: reason === 'paused',
      roundsRun: round,
      lastVerdict,
      proposal: winning,
      attempts: this.recorder.count,
      failureMemory: this.recorder.failureMemory(this.maxFailuresRemembered),
      promotedSequences: this.recorder.promotedSequences(),
      budget: Object.fromEntries([...this.budget.allowances.keys()].map((id) => [id, this.budget.usageFor(id)])),
      benchRemaining: this.bench.remaining,
      chain: this.recorder.verify(),
    };
    if (reason === 'paused') {
      onEvent({ type: 'run:paused', runId, round });
    } else {
      onEvent({ type: 'run:stopped', runId, stopReason: reason, proposalId: winning && winning.id });
    }
    return result;
  }



  /** Verdict the trunk without letting a referee crash the run — a referee
   *  error is itself a named stop, not an unhandled throw. */
  async safeVerdict(tree, onEvent, runId) {
    try {
      return await this.spec.referee.verdict(tree);
    } catch (e) {
      this.recorder.recordEvent('referee_error', { phase: 'initial', detail: String(e && e.message ? e.message : e) });
      onEvent({ type: 'run:error', runId, detail: String(e && e.message ? e.message : e) });
      return null;
    }
  }
}

module.exports = {
  CodeForge,
  ProposalLedger,
  ProposalStateError,
  ForgeBusyError,
  ForgePausedError,
  MAX_ROUNDS,
  STOP_REASONS,
  isRegression,
  newlyBroken,
  fixedTests,
};
