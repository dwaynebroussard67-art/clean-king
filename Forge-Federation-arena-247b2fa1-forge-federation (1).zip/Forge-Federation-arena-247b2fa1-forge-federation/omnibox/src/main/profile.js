/**
 * profile.js — the one-time adoption of an OmniBox profile by Forge Flight,
 * and the boot watch that stands behind it.
 *
 * Electron names the user-data folder after the app's `name`, so the rename
 * from `omnibox` to `forgeflight` moves it: on a machine that ran OmniBox,
 * the first Forge Flight launch would otherwise start with an empty profile
 * — no logins (the `persist:omnibox` partition lives inside it), no passport,
 * no session, no picks, no anchors, no federation. Everything the person had
 * built would still be on disk, one folder over, and invisible.
 *
 * The rules, in order:
 *
 *   1. NEVER overwrite. If the new folder already holds anything, it is the
 *      profile now, and the old one is left exactly where it was. Adoption
 *      happens once, on a first launch, or not at all.
 *   2. MOVE, do not copy, when both folders are on the same volume — a
 *      profile can be gigabytes of Chromium cache, and two live copies of one
 *      cookie jar is how a person ends up logged out of the one they are
 *      using. When a rename across volumes is refused, fall back to a copy
 *      and leave the original in place, and say so.
 *   3. LEAVE A NOTE in the old location naming where the profile went, so the
 *      folder a person might go looking for explains itself.
 *   4. NEVER THROW. A failed adoption is reported on the returned record and
 *      the app starts with a fresh profile; the old one is untouched and the
 *      next launch tries again.
 *
 * Nothing in here reads the contents of the profile. It moves a directory.
 *
 * THE BOOT WATCH — adoption moved a profile an OLDER Chromium wrote into the
 * folder a NEWER Chromium opens at launch. Chromium usually migrates forward;
 * when it cannot, it dies inside its own storage layer (IndexedDB schema
 * errors, quota_database resets) before it can paint, or the moment a page
 * touches the old storage. A window that never lives cannot explain why it
 * died, so the only witness left is the boot itself:
 *
 *   - While a folder is an ADOPTED profile (a legacy sibling's note names
 *     it), each launch arms a boot mark before Electron opens any of it.
 *   - A launch that ends abnormally (crash, silent exit, task-kill — no
 *     graceful quit, no settle) leaves the mark behind. Two such endings in
 *     a row say the profile itself cannot open, and the next launch moves it
 *     aside to a sibling `forgeflight.old` and starts fresh.
 *   - A launch that quits gracefully, or that lives to the settle point
 *     (main clears the mark once a page has really loaded, or shortly after
 *     the window first shows), disarms the watch. One crash — a GPU fault, a
 *     power cut — must never throw a working profile away; only an adopted
 *     profile that NEVER survives a boot is quarantined.
 *
 * A profile Forge Flight created itself is never armed, because there is no
 * legacy note naming it — the watch is scoped to the one migration that
 * crosses Chromium generations. Nothing is deleted: the quarantined tree
 * keeps every cookie and file under `forgeflight.old`, and the legacy note
 * is rewritten to say where it went.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

const LEGACY_NAMES = ['omnibox', 'OmniBox'];
const NOTE = 'MOVED-TO-FORGE-FLIGHT.txt';
const BOOT_WATCH = 'boot-watch.json';
const QUARANTINE_BASE = 'forgeflight.old';

const eqPath = (a, b) => {
  const x = path.resolve(a);
  const y = path.resolve(b);
  return process.platform === 'win32' ? x.toLowerCase() === y.toLowerCase() : x === y;
};

/** Does a directory exist and hold at least one entry? */
function populated(dir) {
  try {
    return fs.statSync(dir).isDirectory() && fs.readdirSync(dir).length > 0;
  } catch {
    return false;
  }
}

/** The legacy profile folders that could exist beside `next`, in preference order. */
function legacyCandidates(next) {
  const parent = path.dirname(next);
  const out = [];
  for (const name of LEGACY_NAMES) {
    const p = path.join(parent, name);
    if (path.resolve(p) !== path.resolve(next) && populated(p) && !fs.existsSync(path.join(p, NOTE))) out.push(p);
  }
  return out;
}

/**
 * Adopt a legacy profile into `next` if — and only if — `next` is empty.
 *
 * @returns {{ action: 'kept'|'moved'|'copied'|'none'|'failed', from?: string, to: string, detail: string }}
 */
function adoptLegacyProfile(next, { now = () => new Date().toISOString() } = {}) {
  if (populated(next)) {
    return { action: 'kept', to: next, detail: 'Forge Flight already has a profile here; nothing was adopted.' };
  }
  const [from] = legacyCandidates(next);
  if (!from) {
    return { action: 'none', to: next, detail: 'No OmniBox profile to adopt.' };
  }

  try {
    fs.mkdirSync(path.dirname(next), { recursive: true });
    // An empty `next` may already exist (Electron sometimes touches it before
    // ready). rename() needs it gone.
    if (fs.existsSync(next)) fs.rmdirSync(next);
    fs.renameSync(from, next);
    leaveNote(from, next, now(), 'moved');
    return { action: 'moved', from, to: next, detail: `Adopted the OmniBox profile at ${from}.` };
  } catch (e) {
    // EXDEV: across volumes. Copy, keep the original, and say so.
    if (e && e.code === 'EXDEV') {
      try {
        fs.cpSync(from, next, { recursive: true, errorOnExist: false, force: false });
        leaveNote(from, next, now(), 'copied');
        return {
          action: 'copied',
          from,
          to: next,
          detail: `Copied the OmniBox profile from ${from} (different volume; the original was left in place).`,
        };
      } catch (e2) {
        return { action: 'failed', from, to: next, detail: `Could not copy the OmniBox profile: ${e2.message}` };
      }
    }
    return { action: 'failed', from, to: next, detail: `Could not move the OmniBox profile: ${e.message}` };
  }
}

function leaveNote(from, to, at, how) {
  try {
    fs.mkdirSync(from, { recursive: true });
    fs.writeFileSync(
      path.join(from, NOTE),
      [
        `OmniBox is now Forge Flight.`,
        `This profile was ${how} to:`,
        `  ${to}`,
        `on ${at}.`,
        ``,
        how === 'copied'
          ? `The original files are still here because the two folders are on different volumes. Forge Flight uses the copy; this folder can be deleted once you are satisfied.`
          : `This folder is empty apart from this note and can be deleted.`,
        ``,
      ].join('\n'),
      'utf8'
    );
  } catch {
    /* the note is a courtesy; failing to write it is not a failed adoption */
  }
}

// ---------------------------------------------------------------------------
// The boot watch
// ---------------------------------------------------------------------------

/** The legacy sibling whose note says its profile now lives at `next`, if any. */
function adoptedFromLegacyNote(next) {
  const parent = path.dirname(next);
  for (const name of LEGACY_NAMES) {
    const p = path.join(parent, name);
    if (eqPath(p, next)) continue;
    const note = path.join(p, NOTE);
    let text = '';
    try {
      text = fs.readFileSync(note, 'utf8');
    } catch {
      continue; // no note: not an adopted profile, or not adopted by us
    }
    const lines = text.split(/\r?\n/).map((l) => l.trim());
    if (lines.some((l) => eqPath(l, next))) return p;
  }
  return null;
}

function bootWatchPath(dir) {
  return path.join(dir, BOOT_WATCH);
}

/** { n: 1|2 } — how many armed boots in a row have died, or null. */
function readBootWatch(dir) {
  try {
    const raw = JSON.parse(fs.readFileSync(bootWatchPath(dir), 'utf8'));
    return raw && typeof raw === 'object' && raw.n ? { n: raw.n === 2 ? 2 : 1, at: raw.at || null } : null;
  } catch {
    return null;
  }
}

function writeBootWatch(dir, n, at) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(bootWatchPath(dir), JSON.stringify({ n, at: at || new Date().toISOString(), pid: process.pid }, null, 2), 'utf8');
    return true;
  } catch {
    return false;
  }
}

/** A boot that ended well clears the watch: this profile opens, it is fine. */
function clearBootWatch(dir) {
  try {
    fs.rmSync(bootWatchPath(dir), { force: true });
  } catch {
    /* nothing armed */
  }
}

/**
 * Move an adopted profile that Chromium cannot open aside, before Electron
 * opens any of it. `legacy` is the sibling folder whose note named `next`;
 * the note is rewritten to name the quarantine, so a fresh profile at `next`
 * is never mistaken for the adopted one again. Nothing is deleted.
 */
function quarantineAdopted(next, legacy, at) {
  const parent = path.dirname(next);
  let dest = path.join(parent, QUARANTINE_BASE);
  for (let i = 2; fs.existsSync(dest); i++) dest = path.join(parent, `${QUARANTINE_BASE}-${i}`);
  try {
    fs.renameSync(next, dest);
  } catch (e) {
    return { dest: null, detail: String((e && e.message) || e) };
  }
  try {
    // The legacy folder still exists (it held only the note); say where the
    // tree went and why, in the same file the adoption wrote.
    fs.mkdirSync(legacy, { recursive: true });
    fs.writeFileSync(
      path.join(legacy, NOTE),
      [
        `OmniBox profile.`,
        ``,
        `Forge Flight adopted this profile and then could not open it: two`,
        `launches in a row died before the profile proved it could start,`,
        `which is how an older Chromium profile fails inside a newer one.`,
        `The tree was moved aside, untouched, to:`,
        `  ${dest}`,
        `on ${at}.`,
        ``,
        `Forge Flight now runs on a fresh profile. Your cookies, passport and`,
        `session are all still in the folder above; nothing was deleted. If`,
        `you want them back, quit Forge Flight and move that folder into`,
        `place — or re-import the passport from it.`,
        ``,
      ].join('\n'),
      'utf8'
    );
  } catch {
    /* the note is a courtesy; a quarantine that cannot write it still stands */
  }
  return { dest, detail: dest };
}

/**
 * The per-boot watch on an adopted profile. Called at launch, before
 * Electron opens the folder:
 *
 *   - no legacy note names `next`  → nothing to do (`none`); a profile
 *     Forge Flight created itself is never armed, let alone quarantined.
 *   - the last TWO armed boots died → quarantine the tree and do not arm
 *     the fresh one (`quarantined`).
 *   - otherwise → arm this boot (`watching`, `watching-2`). If THIS boot
 *     dies, the mark stays and the count rises.
 *
 * `clearBootWatch` is the only thing that disarms, so a graceful quit or a
 * settled boot always counts as the profile proving itself.
 */
function guardAdoptedProfile(next, { now = () => new Date().toISOString() } = {}) {
  const legacy = adoptedFromLegacyNote(next);
  if (!legacy) return { action: 'none', to: next, detail: 'Not an adopted profile; no boot watch.' };

  const mark = readBootWatch(next);
  if (mark && mark.n >= 2) {
    const q = quarantineAdopted(next, legacy, now());
    if (q.dest) {
      return {
        action: 'quarantined',
        from: next,
        to: q.dest,
        detail: `Two launches died on the adopted OmniBox profile; moved it aside to ${q.dest}. Forge Flight starts fresh.`,
      };
    }
    // The rename failed (the folder may be locked by a still-running
    // process). Arm again and let the next launch retry rather than opening
    // the folder blindly.
    writeBootWatch(next, 2, now());
    return { action: 'quarantine-deferred', to: next, detail: `Could not move the poisoned profile aside: ${q.detail}` };
  }

  const n = mark ? Math.min(2, (mark.n || 1) + 1) : 1;
  if (!writeBootWatch(next, n, now())) {
    return { action: 'unwritable', to: next, detail: `Could not arm the boot watch at ${next}.` };
  }
  return {
    action: n === 2 ? 'watching-2' : 'watching',
    to: next,
    detail:
      n === 2
        ? `Last boot of the adopted profile died; a second death quarantines it to ${QUARANTINE_BASE}.`
        : `Adopted profile under boot watch (${QUARANTINE_BASE} after two deaths in a row).`,
  };
}

/** Arm the watch the very boot that adopted — see main.js. */
function armAdoptedProfile(next, { now = () => new Date().toISOString() } = {}) {
  if (!adoptedFromLegacyNote(next)) return false;
  return writeBootWatch(next, 1, now());
}

module.exports = {
  adoptLegacyProfile,
  legacyCandidates,
  populated,
  guardAdoptedProfile,
  armAdoptedProfile,
  clearBootWatch,
  adoptedFromLegacyNote,
  LEGACY_NAMES,
  NOTE,
  BOOT_WATCH,
};
