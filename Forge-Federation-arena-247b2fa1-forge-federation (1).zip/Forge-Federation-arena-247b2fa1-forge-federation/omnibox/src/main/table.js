/**
 * table.js — the fan-out engine and the conversation shapes.
 *
 * One prompt, many seats. The shape decides who hears what.
 *
 * Three rules are enforced here rather than written in a README, because a
 * rule that lives only in a README is not a rule:
 *
 *   1. USER-TRIGGERED ONLY. A run exists because a person pressed send. There
 *      is no scheduler, no polling, no background querying. Multi-round shapes
 *      declare their round count up front, are capped, and can be stopped.
 *   2. ONE SEAT PER HOST. Two tabs on the same site cannot both be seated.
 *      Forge Flight fans a prompt across *different* services, never across
 *      several accounts on one service.
 *   3. HUMAN PACING. Seats are staggered and a seat has a floor on how often
 *      it can be sent to. Forge Flight types at the speed of a person with a lot
 *      of tabs open, which is what it is.
 */

'use strict';

const MAX_ROUNDS = 4;
const STAGGER_MS = 260;
const MIN_SEAT_INTERVAL_MS = 1500;

// --------------------------------------------------------------------------
// Shapes. A shape is a function from (round, context) to a list of steps.
// Returning an empty list ends the run.
// --------------------------------------------------------------------------

const SHAPES = {
  solo: {
    label: 'Solo',
    rounds: 1,
    blurb: 'Just the tab you are looking at. An ordinary browser.',
    needs: 'focus',
    plan(round, { prompt, seats, focusId }) {
      if (round > 1) return [];
      const seat = seats.find((s) => s.id === focusId) || seats[0];
      return seat ? [{ seatId: seat.id, text: prompt, role: 'answer' }] : [];
    },
  },

  communal: {
    label: 'Communal',
    rounds: 1,
    blurb: 'Everyone at the table hears the same question at the same time.',
    plan(round, { prompt, seats }) {
      if (round > 1) return [];
      return seats.map((s) => ({ seatId: s.id, text: prompt, role: 'answer' }));
    },
  },

  sides: {
    label: 'Sides',
    rounds: 1,
    blurb: 'Split the table. One side argues for, the other against.',
    needs: 'assignments',
    plan(round, { prompt, seats, assignments }) {
      if (round > 1) return [];
      const steps = [];
      for (const s of seats) {
        const side = assignments[s.id];
        if (side !== 'A' && side !== 'B') continue;
        const framing =
          side === 'A'
            ? 'Argue the strongest case FOR the following. Give the best version of that case, then name its weakest point honestly.'
            : 'Argue the strongest case AGAINST the following. Give the best version of that case, then name its weakest point honestly.';
        steps.push({ seatId: s.id, text: `${framing}\n\n${prompt}`, role: side === 'A' ? 'for' : 'against' });
      }
      return steps;
    },
  },

  adversarial: {
    label: 'Adversarial',
    rounds: 2,
    blurb: 'One seat answers. The rest try to break the answer.',
    needs: 'subject',
    plan(round, { prompt, seats, subjectId, results }) {
      const subject = seats.find((s) => s.id === subjectId) || seats[0];
      if (!subject) return [];
      if (round === 1) return [{ seatId: subject.id, text: prompt, role: 'answer' }];
      if (round === 2) {
        const answer = results.get(subject.id);
        if (!answer || !answer.ok) return [];
        const body =
          `Here is a question and one answer to it. Find what is wrong with the answer: a factual error, a ` +
          `missing case, an assumption doing work it should not. If the answer is sound, say so and name the ` +
          `single strongest objection anyone could still raise.\n\n` +
          `QUESTION\n${prompt}\n\nANSWER (from ${subject.name})\n${clip(answer.text)}`;
        return seats.filter((s) => s.id !== subject.id).map((s) => ({ seatId: s.id, text: body, role: 'critique' }));
      }
      return [];
    },
  },

  relay: {
    label: 'Relay',
    rounds: MAX_ROUNDS,
    blurb: 'Hand the answer down the line. Each seat improves what it was given.',
    needs: 'order',
    plan(round, { prompt, seats, order, results }) {
      const line = (order && order.length ? order : seats.map((s) => s.id))
        .map((id) => seats.find((s) => s.id === id))
        .filter(Boolean);
      const seat = line[round - 1];
      if (!seat) return [];
      if (round === 1) return [{ seatId: seat.id, text: prompt, role: 'answer' }];
      const prev = line[round - 2];
      const answer = prev && results.get(prev.id);
      if (!answer || !answer.ok) return [];
      const body =
        `You are the next hand on this. Improve the draft below: keep what is right, fix what is wrong, and ` +
        `say in one line what you changed and why.\n\nTASK\n${prompt}\n\nDRAFT (from ${prev.name})\n${clip(answer.text)}`;
      return [{ seatId: seat.id, text: body, role: 'improve' }];
    },
  },

  interview: {
    label: 'Interview',
    rounds: 2,
    blurb: 'One seat asks the question it thinks matters. The rest answer that.',
    needs: 'subject',
    plan(round, { prompt, seats, subjectId, results }) {
      const asker = seats.find((s) => s.id === subjectId) || seats[0];
      if (!asker) return [];
      if (round === 1) {
        return [
          {
            seatId: asker.id,
            role: 'question',
            text:
              `Do not answer this yet. Read it, and reply with ONE question — the single question whose answer ` +
              `would change the most about how someone should think about it. Reply with the question only.\n\n${prompt}`,
          },
        ];
      }
      if (round === 2) {
        const q = results.get(asker.id);
        if (!q || !q.ok) return [];
        const body = `${clip(q.text, 1200)}\n\n(context: this question came out of — ${clip(prompt, 600)})`;
        return seats.filter((s) => s.id !== asker.id).map((s) => ({ seatId: s.id, text: body, role: 'answer' }));
      }
      return [];
    },
  },
};

function clip(s, n = 6000) {
  const t = String(s || '');
  return t.length <= n ? t : `${t.slice(0, n)}\n…[truncated by Forge Flight at ${n} characters]`;
}

// --------------------------------------------------------------------------
// The run
// --------------------------------------------------------------------------

let runSeq = 1;

class Table {
  /**
   * @param {{dispatch:(tabId:string, text:string, opts:object)=>Promise<object>,
   *          emit:(event:string, payload:object)=>void}} io
   */
  constructor(io) {
    this.io = io;
    this.runs = new Map();
    this.lastSentAt = new Map();
  }

  static shapes() {
    return Object.entries(SHAPES).map(([id, s]) => ({
      id,
      label: s.label,
      blurb: s.blurb,
      rounds: s.rounds,
      needs: s.needs || null,
    }));
  }

  /**
   * @param {{prompt:string, shape:string, seats:Array<{id:string,name:string,host:string}>,
   *          assignments?:object, subjectId?:string, order?:string[], focusId?:string}} spec
   */
  async run(spec) {
    const shape = SHAPES[spec.shape] || SHAPES.communal;
    const runId = `r${runSeq++}`;
    const state = {
      runId,
      shape: spec.shape,
      prompt: spec.prompt,
      startedAt: Date.now(),
      stopped: false,
      results: new Map(),
      seats: spec.seats,
    };
    this.runs.set(runId, state);

    this.io.emit('run:started', {
      runId,
      shape: spec.shape,
      shapeLabel: shape.label,
      prompt: spec.prompt,
      rounds: shape.rounds,
      seats: spec.seats.map((s) => ({ id: s.id, name: s.name })),
    });

    const ctx = {
      prompt: spec.prompt,
      seats: spec.seats,
      assignments: spec.assignments || {},
      subjectId: spec.subjectId,
      order: spec.order,
      focusId: spec.focusId,
      results: state.results,
    };

    for (let round = 1; round <= Math.min(shape.rounds, MAX_ROUNDS); round++) {
      if (state.stopped) break;
      let steps = [];
      try {
        steps = shape.plan(round, ctx) || [];
      } catch (e) {
        this.io.emit('run:error', { runId, round, detail: String(e.message || e) });
        break;
      }
      if (steps.length === 0) break;

      this.io.emit('round:started', { runId, round, steps: steps.map((s) => ({ seatId: s.seatId, role: s.role })) });

      const settled = await Promise.all(steps.map((step, i) => this.dispatchStep(state, round, step, i)));

      for (const r of settled) if (r) state.results.set(r.seatId, r);
      this.io.emit('round:finished', { runId, round });
    }

    const finished = {
      runId,
      shape: spec.shape,
      prompt: spec.prompt,
      elapsedMs: Date.now() - state.startedAt,
      stopped: state.stopped,
      results: [...state.results.values()],
    };
    this.io.emit('run:finished', finished);
    this.runs.delete(runId);
    return finished;
  }

  async dispatchStep(state, round, step, index) {
    if (state.stopped) return null;

    // Human pacing: stagger the table, and never hit one seat too fast.
    await sleep(index * STAGGER_MS);
    const last = this.lastSentAt.get(step.seatId) || 0;
    const wait = MIN_SEAT_INTERVAL_MS - (Date.now() - last);
    if (wait > 0) await sleep(wait);
    if (state.stopped) return null;
    this.lastSentAt.set(step.seatId, Date.now());

    const seat = state.seats.find((s) => s.id === step.seatId);
    this.io.emit('step:started', {
      runId: state.runId,
      round,
      seatId: step.seatId,
      seatName: seat ? seat.name : step.seatId,
      role: step.role,
      sent: step.text,
    });

    let res;
    try {
      res = await this.io.dispatch(step.seatId, step.text, { runId: state.runId, round, role: step.role });
    } catch (e) {
      res = { ok: false, reason: 'dispatch-error', detail: String(e.message || e) };
    }

    const out = {
      seatId: step.seatId,
      seatName: seat ? seat.name : step.seatId,
      round,
      role: step.role,
      sent: step.text,
      ...res,
    };
    this.io.emit('step:finished', { runId: state.runId, ...out });
    return out;
  }

  stop(runId) {
    const s = this.runs.get(runId);
    if (!s) return false;
    s.stopped = true;
    this.io.emit('run:stopped', { runId });
    return true;
  }

  stopAll() {
    for (const id of [...this.runs.keys()]) this.stop(id);
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms)));

module.exports = { Table, SHAPES, MAX_ROUNDS, clip };
