/**
 * pilots.js — four browser agents that actually DO things.
 *
 * The complaints that drove this file, answered in order:
 *   "there's no way to get them to do anything" — seats at the table only
 *     answer questions. A PILOT is different: it is given a goal, it opens a
 *     page, it clicks, it types, it reads what came back, and it keeps going
 *     until the goal is met or it hits its step budget.
 *   "they're supposed to go to our website and click on stuff" — yes. A
 *     pilot runs on a REAL Chromium tab, in the same persistent session as
 *     your seats, so it is logged in like you are.
 *   "just four of them" — MAX_ACTIVE = 4. The fifth launch is refused by
 *     name, and the UI shows the four seats to the pilots in the same order
 *     forever: P1, P2, P3, P4.
 *
 * THE SOUNDNESS RULE (same as everything else in this product)
 *   A pilot only ever has ONE verb per step, and the brain that picks the
 *   verb is the local model (or a seat you choose) — so its answer must be
 *   a small, strict JSON object. If the answer is not JSON, or names an
 *   action we do not allow, the pilot REFUSES the step and stops. It never
 *   guesses what a prose sentence "probably meant". A pilot that could not
 *   be read is reported as `bad-json`, never executed as something else.
 *
 * THE NO-GUESS RULE
 *   click and type REFUSE when more than one visible element matches the
 *   target (`ambiguous-click` / `ambiguous-type`, with the count named),
 *   unless the SOUND engine uniquely re-finds the element this flight already
 *   stamped (badge, unique strong id, or unique text). Structure, class and
 *   href never decide. suggest() is never applied. First-match-wins would
 *   send clicks into the wrong control the week a page grows a second "Send"
 *   button — the exact silent-wrong-grab failure this product exists to refuse.
 *
 * ALLOWED ACTIONS (closed set — anything else is refused by name)
 *   navigate {to}         load a new URL in the pilot's own tab
 *   click    {selector?, text?}  click the one visible match — several is a refusal
 *   type     {selector, text}    type into the one visible match — several is a refusal
 *   press    {key}         keydown+keyup on the focused element ('enter')
 *   wait     {ms}          let a page render (capped at 10s)
 *   done     {summary}     the goal is met; what the pilot found
 *
 * THE PIPE RULE
 *   The driver sees a capped observation (title, url, first ~900 characters)
 *   in memory so it can pick the next verb. The flight record on disk is a
 *   named play (page-change-outcome). It never writes page text, selectors,
 *   typed words, titles, or full URLs. Host is an evidence pointer, not a
 *   name. The UI log may show a short sentence; that sentence does not go
 *   to flight.jsonl.
 *
 * DRIVERS
 *   ask: async ({ system, prompt }) => { ok, text, ... }  — injected. In the
 *   app it is the local model when one is running, otherwise a seat you
 *   pick (the first seated one by default). If neither exists, a launch is
 *   refused with reason `no-driver` and the exact sentence on screen.
 */

'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

let ENGINE_SRC = null;
function engineSrc() {
  if (!ENGINE_SRC) {
    ENGINE_SRC = fs.readFileSync(path.join(__dirname, '../detector/reanchor.js'), 'utf8');
  }
  return ENGINE_SRC;
}

/** Run page-world code with the SOUND engine in scope as `R`. */
function withEngine(body) {
  return `(() => {
    if (!globalThis.__FORGEFLIGHT_REANCHOR__) {
      ${engineSrc()}
    }
    const R = globalThis.__FORGEFLIGHT_REANCHOR__;
    ${body}
  })()`;
}


const SCHEMA = 'forge.pilot.v1';
const MAX_ACTIVE = 4;
const MAX_STEPS = 12;
const MAX_LOG_LINES = 40;
const MAX_OBSERVATION = 900;
const MAX_GOAL = 400;
const MAX_WAIT_MS = 10000;

const ALLOWED_ACTIONS = ['navigate', 'click', 'type', 'press', 'wait', 'done'];
const ALLOWED_KEYS = {
  navigate: ['to'],
  click: ['selector', 'text'],
  type: ['selector', 'text'],
  press: ['key'],
  wait: ['ms'],
  done: ['summary'],
};

const newId = (p) => `${p}_${crypto.randomBytes(4).toString('hex')}`;

function isValidUrl(s) {
  let u;
  try {
    u = new URL(String(s));
  } catch {
    return false;
  }
  if (u.protocol === 'https:' || u.protocol === 'forgeflight:') return true;
  // Plain http only on loopback: a pilot navigating to an arbitrary
  // cleartext page would leak whatever it types to the network in the open.
  if (u.protocol === 'http:') {
    const h = u.hostname.toLowerCase();
    return h === 'localhost' || h === '127.0.0.1' || h === '[::1]' || h === '::1';
  }
  return false;
}

function clip(s, n) {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  return t.length <= n ? t : `${t.slice(0, n - 1)}…`;
}

/** The only interpretation of a model's answer. Returns a clean action or a
 *  named refusal. This is the entire gate between prose and behaviour. */
function parseAction(text) {
  const raw = String(text || '').trim();
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start === -1 || end <= start) return { rejected: true, reason: 'bad-json', detail: 'The driver did not return a JSON action.' };
  let j;
  try {
    j = JSON.parse(raw.slice(start, end + 1));
  } catch {
    return { rejected: true, reason: 'bad-json', detail: 'The driver returned unreadable JSON.' };
  }
  const action = j && j.action ? String(j.action).toLowerCase() : '';
  if (!ALLOWED_ACTIONS.includes(action)) {
    return {
      rejected: true,
      reason: 'unknown-action',
      detail: `Action "${action || '(none)'}" is not in the allowed set: ${ALLOWED_ACTIONS.join(', ')}.`,
    };
  }
  const allowed = ALLOWED_KEYS[action];
  for (const k of Object.keys(j)) {
    if (k === 'action' || k === 'reason') continue;
    if (!allowed.includes(k)) {
      return { rejected: true, reason: 'unknown-field', detail: `Action "${action}" does not take "${k}". Allowed: ${allowed.join(', ')}.` };
    }
  }
  switch (action) {
    case 'navigate': {
      const to = String(j.to || '').trim();
      if (!isValidUrl(to)) return { rejected: true, reason: 'bad-url', detail: `Cannot navigate to "${clip(to, 80)}" — only https, loopback http, and forgeflight pages.` };
      return { action, to };
    }
    case 'click': {
      const selector = String(j.selector || '').trim().slice(0, 200);
      const text = String(j.text || '').trim().slice(0, 120);
      if (!selector && !text) return { rejected: true, reason: 'no-target', detail: 'click needs a selector or the visible text to click.' };
      return { action, selector, text };
    }
    case 'type': {
      const selector = String(j.selector || '').trim().slice(0, 200);
      const text = String(j.text || '').slice(0, 4000);
      if (!selector || !text) return { rejected: true, reason: 'need-both', detail: 'type needs both selector and text.' };
      return { action, selector, text };
    }
    case 'press': {
      const key = String(j.key || 'enter').toLowerCase().slice(0, 20);
      if (!['enter', 'escape'].includes(key)) return { rejected: true, reason: 'bad-key', detail: `press supports enter or escape, not "${key}".` };
      return { action, key };
    }
    case 'wait': {
      const ms = Math.min(Math.max(Number(j.ms) || 500, 0), MAX_WAIT_MS);
      return { action, ms };
    }
    case 'done': {
      return { action, summary: clip(j.summary, 300) };
    }
    default:
      return { rejected: true, reason: 'unknown-action', detail: 'unreachable' };
  }
}

/** Map a clean action onto the page. All of it is user-triggered and happens
 *  in the pilot's own tab. Each helper returns { ok, text } where text is a
 *  short, human-readable sentence for the log. */
async function performAction(page, tabId, action) {
  switch (action.action) {
    case 'navigate': {
      await page.navigate(tabId, action.to);
      return { ok: true, text: `navigated to ${clip(action.to, 80)}` };
    }
    case 'wait': {
      await new Promise((r) => setTimeout(r, action.ms));
      return { ok: true, text: `waited ${action.ms}ms` };
    }
    case 'click': {
      const found = await page.evaluate(
        tabId,
        withEngine(`
          const visible = (el) => {
            if (!el) return false;
            const r = el.getBoundingClientRect();
            return r.width >= 2 && r.height >= 2;
          };
          const enabled = (el) => el.getAttribute('aria-disabled') !== 'true' && !el.disabled;
          const bySelector = ${JSON.stringify(action.selector || '')};
          let cands = [];
          if (bySelector) {
            try { cands = [...document.querySelectorAll(bySelector)]; } catch { return 'bad-selector'; }
          } else {
            const want = ${JSON.stringify(action.text || '')};
            const q = want.toLowerCase();
            const all = document.querySelectorAll('button, a, [role="button"], [role="link"], input[type="submit"], summary, label');
            const exact = [];
            const partial = [];
            for (const el of all) {
              const t = (el.textContent || el.value || '').replace(/\\s+/g, ' ').trim().toLowerCase();
              if (!t) continue;
              if (t === q) exact.push(el);
              else if (t.includes(q)) partial.push(el);
            }
            // An exact label match outranks partials — but exact matches
            // among themselves still have to be unique to be clickable.
            cands = exact.length ? exact : partial;
          }
          const seen = cands.filter(visible);
          if (!seen.length) return 'not-found';
          const live = seen.filter(enabled);
          if (!live.length) return 'disabled:' + seen.length;
          let el = null;
          if (live.length === 1) el = live[0];
          else if (globalThis.__FORGEFLIGHT_REANCHOR__) {
            const R = globalThis.__FORGEFLIGHT_REANCHOR__;
            const fp = globalThis.__FORGEFLIGHT_PILOT_FP__;
            const hit = fp ? R.reanchor(fp, document) : null;
            if (hit && live.indexOf(hit) !== -1) el = hit;
          }
          if (!el) return 'ambiguous:' + live.length;
          try {
            const R = globalThis.__FORGEFLIGHT_REANCHOR__;
            if (R) { R.stamp(el); globalThis.__FORGEFLIGHT_PILOT_FP__ = R.capture(el); }
          } catch (e) { /* badge is best-effort */ }
          el.click();
          el.focus();
          return live.length === 1 ? (bySelector ? 'selector' : 'text') : 'reanchor';
        `)
      );
      if (found === 'selector' || found === 'text' || found === 'reanchor') return { ok: true, text: `clicked ${found === 'text' ? '"' + clip(action.text, 40) + '"' : found === 'reanchor' ? 'the same control, re-found' : 'a matched element'}` };
      if (typeof found === 'string' && found.startsWith('ambiguous:')) {
        const n = found.slice('ambiguous:'.length);
        return { ok: false, reason: 'ambiguous-click', detail: `${n} visible elements match — the pilot refuses to guess which one to click. Name it more precisely.` };
      }
      if (typeof found === 'string' && found.startsWith('disabled:')) {
        return { ok: false, reason: 'disabled', detail: 'The matching control is disabled, so the pilot did not force it.' };
      }
      if (found === 'bad-selector') return { ok: false, reason: 'bad-selector', detail: `The selector does not parse: ${clip(action.selector, 60)}.` };
      return { ok: false, reason: 'not-found', detail: `Nothing matching was found to click (${clip(action.text || action.selector, 60)}).` };
    }
    case 'type': {
      const r = await page.evaluate(
        tabId,
        withEngine(`
          const visible = (el) => {
            if (!el) return false;
            const box = el.getBoundingClientRect();
            return box.width >= 2 && box.height >= 2;
          };
          const enabled = (el) => el.getAttribute('aria-disabled') !== 'true' && !el.disabled;
          let cands;
          try { cands = [...document.querySelectorAll(${JSON.stringify(action.selector)})]; }
          catch { return 'bad-selector'; }
          const seen = cands.filter(visible);
          if (!seen.length) return 'not-found';
          const live = seen.filter(enabled);
          if (!live.length) return 'disabled:' + seen.length;
          let el = null;
          if (live.length === 1) el = live[0];
          else if (globalThis.__FORGEFLIGHT_REANCHOR__) {
            const R = globalThis.__FORGEFLIGHT_REANCHOR__;
            const fp = globalThis.__FORGEFLIGHT_PILOT_FP__;
            const hit = fp ? R.reanchor(fp, document) : null;
            if (hit && live.indexOf(hit) !== -1) el = hit;
          }
          if (!el) return 'ambiguous:' + live.length;
          try {
            const R = globalThis.__FORGEFLIGHT_REANCHOR__;
            if (R) { R.stamp(el); globalThis.__FORGEFLIGHT_PILOT_FP__ = R.capture(el); }
          } catch (e) { /* badge is best-effort */ }
          el.focus();
          const set = (v) => {
            if (typeof el.value === 'string') { el.value = v; }
            else { el.textContent = v; }
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('blur', { bubbles: true }));
          };
          set(${JSON.stringify(action.text)});
          let readBack = typeof el.value === 'string' ? el.value : el.textContent || '';
          if (readBack.trim() !== ${JSON.stringify(action.text)}.trim()) return 'readback-mismatch';
          return live.length === 1 ? 'ok' : 'reanchor';
        `)
      );
      if (r === 'ok' || r === 'reanchor') return { ok: true, text: `typed ${clip(action.text, 40)} into ${clip(action.selector, 40)}` };
      if (r === 'readback-mismatch') return { ok: false, reason: 'readback-mismatch', detail: 'The field did not read back what was typed. Nothing was submitted.' };
      if (typeof r === 'string' && r.startsWith('ambiguous:')) {
        return { ok: false, reason: 'ambiguous-type', detail: `${r.slice('ambiguous:'.length)} visible fields match — the pilot refuses to guess which one to type into.` };
      }
      if (typeof r === 'string' && r.startsWith('disabled:')) {
        return { ok: false, reason: 'disabled', detail: 'The matching field is disabled, so the pilot did not type into it.' };
      }
      if (r === 'bad-selector') return { ok: false, reason: 'bad-selector', detail: `The selector does not parse: ${clip(action.selector, 60)}.` };
      return { ok: false, reason: 'not-found', detail: `No element matched ${clip(action.selector, 60)}.` };
    }
    case 'press': {
      const r = await page.evaluate(
        tabId,
        `(() => {
          const el = document.activeElement || document.body;
          const key = ${JSON.stringify(action.key)};
          const opts = { key, code: key === 'enter' ? 'Enter' : 'Escape', keyCode: key === 'enter' ? 13 : 27, bubbles: true };
          el.dispatchEvent(new KeyboardEvent('keydown', opts));
          el.dispatchEvent(new KeyboardEvent('keyup', opts));
          return el.tagName;
        })()`
      );
      return { ok: true, text: `pressed ${action.key} (${r})` };
    }
    case 'done': {
      return { ok: true, text: `done — ${action.summary || 'goal met'}` };
    }
    default:
      return { ok: false, reason: 'unknown-action', detail: 'unreachable' };
  }
}

/** The snapshot a driver sees after each step: where it is, and what the
 *  page says. Capped — the log is session memory, not an archive. */
function observePage(page, tabId) {
  return page.evaluate(
    tabId,
    `(() => ({
      url: location.href,
      title: document.title || '',
      text: (document.body ? document.body.innerText : '').replace(/\\s+/g, ' ').trim().slice(0, ${MAX_OBSERVATION}),
      inputs: [...document.querySelectorAll('input[type="text"], input[type="search"], input[type="email"], input[type="url"], textarea, [contenteditable="true"]')]
        .slice(0, 12).map((el, i) => (el.getAttribute('placeholder') || el.getAttribute('aria-label') || el.name || 'field' + (i + 1)))
    }))()`
  );
}

class PilotManager {
  /**
   * @param {{ask: Function, page: object, emit?: Function, sleep?: Function}} opts
   *   ask({system, prompt}) -> {ok:true,text}|{ok:false,reason,detail}
   *   page.navigate(tabId,url), page.evaluate(tabId,code) -> any
   */
  constructor({ ask, page, emit, sleep } = {}) {
    if (!ask) throw new Error('PilotManager needs an ask() driver.');
    if (!page || typeof page.navigate !== 'function' || typeof page.evaluate !== 'function') {
      throw new Error('PilotManager needs a page with navigate() and evaluate().');
    }
    this.ask = ask;
    this.page = page;
    this.emit = emit || (() => {});
    this.sleep = sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.tasks = new Map(); // id -> task
    this.running = 0;
  }

  _emit(kind, payload) {
    try {
      this.emit(kind, payload);
    } catch {
      /* a log consumer must never kill a flight */
    }
  }

  status() {
    return {
      schema: SCHEMA,
      maxActive: MAX_ACTIVE,
      maxSteps: MAX_STEPS,
      running: this.running,
      slots: Array.from({ length: MAX_ACTIVE }, (_, i) => {
        const t = [...this.tasks.values()].find((x) => x.slot === i + 1);
        return t ? t.public() : { slot: i + 1, state: 'idle' };
      }),
    };
  }

  launch({ goal, url, tabId } = {}) {
    const g = clip(goal, MAX_GOAL);
    if (!g) return { ok: false, reason: 'no-goal', detail: 'A pilot needs a goal.' };
    // A pilot with nowhere to fly is a launch bug, not a flight; refuse up
    // front so the slot is never occupied by a doomed task.
    if (!url && !tabId) {
      return { ok: false, reason: 'no-target', detail: 'Give the pilot a URL or a tab to fly.' };
    }
    if (this.running >= MAX_ACTIVE) {
      return { ok: false, reason: 'limit', detail: `Only ${MAX_ACTIVE} pilots fly at once. Stop one first.` };
    }
    const slot = this._freeSlot();
    if (slot === 0) return { ok: false, reason: 'limit', detail: 'No pilot slot is free.' };

    const task = {
      id: newId('pilot'),
      slot,
      goal: g,
      url: url && isValidUrl(url) ? url : null,
      tabId: tabId || null,
      state: 'flying',
      steps: 0,
      log: [],
      startedAt: new Date().toISOString(),
      finishedAt: null,
      stopRequested: false,
      result: null,
    };
    task.public = () => ({
      id: task.id,
      slot: task.slot,
      goal: task.goal,
      url: task.url,
      tabId: task.tabId,
      state: task.state,
      steps: task.steps,
      log: task.log.slice(-8).map((l) => ({ ...l })),
      startedAt: task.startedAt,
      finishedAt: task.finishedAt,
      result: task.result,
    });
    this.tasks.set(task.id, task);
    this.running++;
    this._log(task, 'started', `pilot ${slot} launched for: ${g}`);
    this._emit('pilot:started', task.public());
    this._fly(task).catch((e) => {
      this._finish(task, { ok: false, reason: 'internal', detail: String((e && e.message) || e) });
    });
    return { ok: true, pilot: task.public() };
  }

  stop(id) {
    const task = this.tasks.get(id);
    if (!task) return { ok: false, reason: 'unknown-pilot' };
    if (task.state !== 'flying') return { ok: false, reason: 'not-flying', state: task.state };
    task.stopRequested = true;
    this._log(task, 'stopping', 'stop requested — the pilot will halt after the current step');
    return { ok: true };
  }

  stopAll() {
    let n = 0;
    for (const t of this.tasks.values()) {
      if (t.state === 'flying') {
        t.stopRequested = true;
        n++;
      }
    }
    return { ok: true, stopping: n };
  }

  get(id) {
    const t = this.tasks.get(id);
    return t ? t.public() : null;
  }

  list() {
    return [...this.tasks.values()].map((t) => t.public()).slice(-MAX_ACTIVE * 3).reverse();
  }

  _freeSlot() {
    for (let i = 1; i <= MAX_ACTIVE; i++) {
      if (![...this.tasks.values()].some((t) => t.slot === i && t.state === 'flying')) return i;
    }
    return 0;
  }

  _log(task, kind, text) {
    task.log.push({ kind, at: new Date().toISOString(), text: clip(text, 220) });
    if (task.log.length > MAX_LOG_LINES) task.log = task.log.slice(-MAX_LOG_LINES);
  }

  /** url + length only. Never the words. The recorder hashes this, not the UI sentence. */
  _sight(obs) {
    if (!obs || typeof obs !== 'object') return null;
    const url = typeof obs.url === 'string' ? obs.url : '';
    if (!url) return null;
    const n = Number.isFinite(obs.n) ? obs.n : String(obs.text || '').length;
    return { url, n };
  }

  /**
   * One step to the chrome and to the flight recorder. `text` is UI-only —
   * it is not in the flight bag, and main must not write it to disk.
   */
  _emitStep(task, step, { action, text, verb, ok, reason, before, after } = {}) {
    const v = verb || action || 'none';
    this._emit('pilot:step', {
      id: task.id,
      slot: task.slot,
      step,
      action: action || v,
      text: text || '',
      tabId: task.tabId,
      flight: {
        verb: v,
        ok: !!ok,
        reason: reason || null,
        before: this._sight(before),
        after: this._sight(after),
      },
    });
  }

  _finish(task, result) {
    task.state = result.ok ? 'done' : 'stopped';
    task.finishedAt = new Date().toISOString();
    task.result = result;
    this.running = Math.max(0, this.running - 1);
    this._emit('pilot:finished', task.public());
  }

  async _askDriver(task, observation) {
    const system =
      'You are pilot ' + task.slot + ' in Forge Flight, a browser agent. You control ONE real browser tab. ' +
      'Your goal was given by a human. Decide the NEXT action only.\n' +
      'Return ONLY a JSON object, nothing else, no markdown. Allowed actions and their fields:\n' +
      '  {"action":"navigate","to":"https://..."}  {"action":"click","selector":"css"|"text":"visible text"}\n' +
      '  {"action":"type","selector":"css","text":"..."}  {"action":"press","key":"enter"|"escape"}\n' +
      '  {"action":"wait","ms":500}  {"action":"done","summary":"what you found"}\n' +
      'Prefer clicking by short visible text (e.g. "Send", "Next") over guessing selectors; ' +
      'but when several elements share a label, use a more specific CSS selector instead — a click that matches more than one element is refused. ' +
      'When the goal is met, return {"action":"done","summary":"..."}.';
    const prompt =
      `GOAL: ${task.goal}\n\nCURRENT PAGE\nurl: ${observation.url}\ntitle: ${observation.title}\n` +
      `visible text (first ${MAX_OBSERVATION} chars):\n${observation.text}\n\n` +
      'Next action JSON:';
    return this.ask({ system, prompt });
  }

  async _fly(task) {
    // 0) get a tab. If one was given, use it; else open the goal URL.
    if (!task.tabId && task.url && typeof this.page.open === 'function') {
      task.tabId = await this.page.open(task.url);
      if (!task.tabId) {
        this._log(task, 'refused', 'could not open a tab for the pilot');
        this._emitStep(task, 0, { verb: 'none', ok: false, reason: 'no-tab', before: null, after: null, text: 'could not open a tab' });
        return this._finish(task, { ok: false, reason: 'no-tab', detail: 'The pilot could not open its own tab.' });
      }
      task.url = null;
    }
    if (!task.tabId) {
      this._log(task, 'refused', 'no tab and no url to open — nothing to fly');
      this._emitStep(task, 0, { verb: 'none', ok: false, reason: 'no-tab', before: null, after: null, text: 'no tab' });
      return this._finish(task, { ok: false, reason: 'no-tab', detail: 'Give the pilot a URL or a tab to fly.' });
    }

    this._log(task, 'flying', `on tab ${task.tabId}`);
    let lastObs = null;
    for (let step = 1; step <= MAX_STEPS; step++) {
      if (task.stopRequested) {
        this._log(task, 'stopped', 'halted by the human');
        this._emitStep(task, step, {
          verb: 'none',
          ok: false,
          reason: 'stopped',
          before: lastObs,
          after: lastObs,
          text: 'halted by the human',
        });
        return this._finish(task, { ok: false, reason: 'stopped', detail: 'Stopped by the human.' });
      }
      let observation;
      try {
        observation = await observePage(this.page, task.tabId);
      } catch {
        this._log(task, 'refused', 'the page is gone or unreadable');
        this._emitStep(task, step, {
          verb: 'none',
          ok: false,
          reason: 'page-gone',
          before: lastObs,
          after: null,
          text: 'the page is gone or unreadable',
        });
        return this._finish(task, { ok: false, reason: 'page-gone', detail: 'The tab closed or the page became unreadable.' });
      }
      lastObs = observation;
      const drive = await this._askDriver(task, observation);
      if (!drive || !drive.ok) {
        const reason = (drive && drive.reason) || 'no-driver';
        this._log(task, 'refused', reason === 'no-driver' ? 'no driver — no local model and no seat to think with' : `driver failed: ${reason}`);
        this._emitStep(task, step, {
          verb: 'none',
          ok: false,
          reason,
          before: observation,
          after: observation,
          text: reason,
        });
        return this._finish(task, {
          ok: false,
          reason,
          detail: reason === 'no-driver' ? 'No driver available: no local model server and no seat to think with.' : (drive && drive.detail) || 'The driver could not answer.',
        });
      }

      const action = parseAction(drive.text);
      if (action.rejected) {
        this._log(task, 'refused', action.detail);
        this._emitStep(task, step, {
          verb: 'none',
          action: 'none',
          ok: false,
          reason: action.reason,
          before: observation,
          after: observation,
          text: action.detail,
        });
        return this._finish(task, { ok: false, reason: action.reason, detail: action.detail });
      }

      task.steps = step;
      const performed = await performAction(this.page, task.tabId, action);
      let after = observation;
      try {
        after = await observePage(this.page, task.tabId);
        lastObs = after;
      } catch {
        after = null;
      }
      if (action.action === 'done') {
        this._log(task, 'done', action.summary || 'goal met');
        this._emitStep(task, step, {
          action: 'done',
          verb: 'done',
          ok: true,
          reason: null,
          before: observation,
          after,
          text: action.summary || 'goal met',
        });
        return this._finish(task, { ok: true, reason: 'done', detail: action.summary || 'goal met', steps: step });
      }
      if (!performed.ok) {
        this._log(task, 'refused', `${performed.detail || performed.reason} — the pilot stops rather than improvise`);
        this._emitStep(task, step, {
          action: action.action,
          verb: action.action,
          ok: false,
          reason: performed.reason || 'action-failed',
          before: observation,
          after,
          text: performed.detail || performed.reason,
        });
        return this._finish(task, { ok: false, reason: performed.reason || 'action-failed', detail: performed.detail || 'The action failed.' });
      }
      this._log(task, 'step', `step ${step}: ${performed.text}`);
      this._emitStep(task, step, {
        action: action.action,
        verb: action.action,
        ok: true,
        reason: null,
        before: observation,
        after,
        text: performed.text,
      });
      await this.sleep(250); // human pacing — a browser agent that races is a bot
    }
    this._log(task, 'stopped', `step limit of ${MAX_STEPS} reached`);
    this._emitStep(task, MAX_STEPS + 1, {
      verb: 'none',
      ok: false,
      reason: 'step-limit',
      before: lastObs,
      after: lastObs,
      text: `step limit of ${MAX_STEPS} reached`,
    });
    return this._finish(task, { ok: false, reason: 'step-limit', detail: `Hit the ${MAX_STEPS}-step budget. Stop the pilot or give it a tighter goal.` });
  }
}

module.exports = { PilotManager, parseAction, performAction, MAX_ACTIVE, MAX_STEPS, ALLOWED_ACTIONS, SCHEMA };
