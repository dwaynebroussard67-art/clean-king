/**
 * localLLM.js — the local-model bridge: discovery + an OpenAI-compatible
 * streaming client, main-process only.
 *
 * This is the machinery behind forgeflight://local — the seat D ruled is
 * reserved for a local LLM. The posture is the app's posture: no API key,
 * no config file, no account. If a local OpenAI-compatible server is
 * running (Ollama on 11434, LM Studio on 1234 — both speak /v1), the local
 * seat answers; if nothing is there, the seat says so and refuses to send.
 *
 * Why the main process owns this: the page never touches the network. The
 * local page is chrome like the rest of Forge Flight — its CSP allows no
 * connects — and every request to the local server is made here, on
 * localhost only, with the sender verified to be the local seat before
 * anything is generated.
 *
 * The helmet: the caller passes the passport's boot block plus the
 * Federation carrier section as the system message, so the local model
 * wears the fighter's knowledge for the turn — adjudicated facts, the
 * carrier, exclusion audit and all. That is the two-part delivery's
 * immediate half, made concrete for the one seat whose context we control
 * end to end. Copilots get a short established-facts briefing instead.
 */

'use strict';

/** Ordered discovery list. FORGEFLIGHT_LOCAL_LLM_URL overrides everything
 *  (the OmniBox-era OMNIBOX_LOCAL_LLM_URL is still honoured, so an existing
 *  shell profile keeps working). */
function defaultEndpoints() {
  const override = process.env.FORGEFLIGHT_LOCAL_LLM_URL || process.env.OMNIBOX_LOCAL_LLM_URL;
  if (override) return [override];
  return ['http://127.0.0.1:11434', 'http://127.0.0.1:1234']; // Ollama, LM Studio
}

const DISCOVER_TIMEOUT_MS = 1200;
const GENERATE_TIMEOUT_MS = 240000;

async function fetchWithTimeout(url, opts = {}, timeoutMs = DISCOVER_TIMEOUT_MS) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: ac.signal });
  } finally {
    clearTimeout(timer);
  }
}

class LocalLLM {
  constructor(opts = {}) {
    this.endpoints = opts.endpoints || defaultEndpoints();
    this.discoverTimeout = opts.discoverTimeout ?? DISCOVER_TIMEOUT_MS;
    this.generateTimeout = opts.generateTimeout ?? GENERATE_TIMEOUT_MS;
    this.cached = null; // { endpoint, model }
    this.probedAt = 0;
  }

  /** Find a live OpenAI-compatible server and pick its first model.
   *  Cached briefly so the seat's status poll stays cheap. */
  async discover({ force = false } = {}) {
    const fresh = Date.now() - this.probedAt < 5000;
    if (!force && fresh) return this.cached;
    this.probedAt = Date.now();
    this.cached = null;
    for (const endpoint of this.endpoints) {
      try {
        const r = await fetchWithTimeout(`${endpoint.replace(/\/$/, '')}/v1/models`, {}, this.discoverTimeout);
        if (!r.ok) continue;
        const j = await r.json();
        const model = j && Array.isArray(j.data) && j.data[0] && j.data[0].id ? j.data[0].id : null;
        this.cached = { endpoint: endpoint.replace(/\/$/, ''), model };
        break;
      } catch {
        /* not there — try the next */
      }
    }
    return this.cached;
  }

  async status() {
    const found = await this.discover();
    return found
      ? { available: true, endpoint: found.endpoint, model: found.model }
      : { available: false, endpoints: this.endpoints };
  }

  /**
   * Stream a completion. `system` is the helmet (the boot block); `prompt`
   * is the user turn. Tokens reach `onToken` as they arrive; the resolved
   * value is the whole text, or a named refusal.
   *
   * @returns {Promise<{ok:true, text:string, model:string, endpoint:string}
   *                |{ok:false, reason:string, detail?:string}>}
   */
  async generate({ prompt, system, onToken, endpoint, model }) {
    const found = endpoint && model ? { endpoint, model } : await this.discover();
    if (!found) return { ok: false, reason: 'no-server' };
    const messages = [];
    if (system) messages.push({ role: 'system', content: system });
    messages.push({ role: 'user', content: String(prompt || '') });

    let res;
    try {
      res = await fetchWithTimeout(
        `${found.endpoint}/v1/chat/completions`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ model: found.model, messages, stream: true }),
        },
        this.generateTimeout
      );
    } catch (e) {
      this.probedAt = 0; // re-discover next time; the server may have gone away
      return { ok: false, reason: 'no-server', detail: String(e && e.message || e) };
    }
    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      return { ok: false, reason: 'server-error', detail: `HTTP ${res.status} ${detail.slice(0, 200)}` };
    }

    // Parse the SSE stream: `data: {...}` lines, `[DONE]` terminator.
    let text = '';
    let buf = '';
    try {
      for await (const chunk of res.body) {
        // The web stream may yield Uint8Array or a plain byte array depending
        // on the runtime; Buffer.from decodes either. A naive .toString() on
        // a plain array yields "100,97,116,97" — bytes as decimal, no text.
        buf += Buffer.from(chunk).toString('utf8');
        const lines = buf.split('\n');
        buf = lines.pop();
        for (const line of lines) {
          const s = line.trim();
          if (!s.startsWith('data:')) continue;
          const payload = s.slice(5).trim();
          if (payload === '[DONE]') continue;
          let j;
          try {
            j = JSON.parse(payload);
          } catch {
            continue; // a keepalive or a torn line — never fatal
          }
          const delta = j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content;
          if (delta) {
            text += delta;
            if (onToken) {
              try {
                onToken(delta, text);
              } catch {
                /* a consumer throwing must not kill the stream */
              }
            }
          }
        }
      }
    } catch (e) {
      return { ok: false, reason: 'stream-error', detail: String(e && e.message || e), text };
    }
    if (!text) return { ok: false, reason: 'empty-response', detail: 'The local server streamed no tokens.' };
    return { ok: true, text, model: found.model, endpoint: found.endpoint };
  }
}

module.exports = { LocalLLM, defaultEndpoints };
