/**
 * history.js — the places you went, for the address bar.
 *
 * Big browsers win on the address bar: you start typing the middle of a URL
 * and it offers the page you were on last week. That needs a local record
 * of where you went. This is that record, and nothing more.
 *
 * Rules, matching the session contract:
 *   - only RESTORABLE urls are kept (https, loopback http, forgeflight:// pages).
 *     file:, data:, javascript: and the like never enter here.
 *   - it stores url + title + when. Never a cookie, never text from a page,
 *     never a prompt, never a reply. A title is metadata a browser profile
 *     already has; it is not content.
 *   - capped at 200 entries, most recent first. This is a suggestion list,
 *     not an archive — an archive is what the passport is for.
 *   - written whole to one small JSON file, read defensively. A corrupt or
 *     missing file is an empty list, not an error.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { restorableURL } = require('./session.js');

const MAX_ENTRIES = 200;

function keyOf(url) {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}${u.pathname}`.toLowerCase();
  } catch {
    return String(url || '').toLowerCase();
  }
}

class RecentPages {
  constructor(dir, opts = {}) {
    this.dir = dir;
    this.file = path.join(dir, 'recent.json');
    this.max = opts.max || MAX_ENTRIES;
    this.entries = this.load();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const out = [];
      for (const e of Array.isArray(raw) ? raw : []) {
        const url = restorableURL(e && e.url);
        if (!url) continue;
        out.push({
          url,
          title: typeof e.title === 'string' ? e.title.slice(0, 200) : '',
          at: typeof e.at === 'string' ? e.at : '',
        });
        if (out.length >= this.max) break;
      }
      return out;
    } catch {
      return [];
    }
  }

  /** Record a visit. The same page updates its timestamp and moves to the
   *  top; it never duplicates. Failures to persist are never worth crashing
   *  the browser over. */
  add(url, title = '') {
    const clean = restorableURL(url);
    if (!clean) return;
    const key = keyOf(clean);
    const rest = this.entries.filter((e) => keyOf(e.url) !== key);
    this.entries = [{ url: clean, title: String(title || '').slice(0, 200), at: new Date().toISOString() }, ...rest].slice(0, this.max);
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.entries, null, 2), 'utf8');
    } catch {
      /* a suggestion list is not worth crashing over */
    }
  }

  /** Suggestions for what the address bar is pointing at. Prefix match on
   *  host first, then on any word of the url or title — the Chrome/Firefox
   *  behaviour of remembering "the middle" rather than only the start. */
  suggest(input, limit = 6) {
    const q = String(input || '').trim().toLowerCase();
    if (!q) return [];
    const words = q.split(/\s+/).filter(Boolean);
    const scored = this.entries
      .map((e) => {
        const host = e.url.match(/^[a-z]+:\/\/([^/]+)/i)?.[1].toLowerCase() || '';
        const body = `${e.url} ${e.title}`.toLowerCase();
        let score = 0;
        if (host.startsWith(q) || host.includes(q)) score += 4;
        if (e.url.toLowerCase().startsWith(q)) score += 3;
        if (e.title.toLowerCase().startsWith(q)) score += 2;
        if (words.every((w) => body.includes(w))) score += 1;
        return { ...e, score };
      })
      .filter((e) => e.score > 0)
      .sort((a, b) => b.score - a.score || (a.at < b.at ? 1 : -1))
      .slice(0, limit)
      .map(({ score, ...e }) => e);
    return scored;
  }

  recent(limit = 12) {
    return this.entries.slice(0, limit);
  }

  stats() {
    return { entries: this.entries.length, file: this.file };
  }
}

module.exports = { RecentPages, MAX_ENTRIES, keyOf };
