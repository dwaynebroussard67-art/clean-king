/**
 * picks.js — the composer you chose by hand, remembered per site.
 *
 * When two boxes on a page tie, Forge Flight refuses to guess and hands you a
 * "Pick the box" button. Until now that ruling lived only in the tab that
 * received it: `manualPick` in the seat preload is in-memory and dies on
 * navigation, and the record written to anchors.jsonl is an engine-training
 * log that nothing ever reads back (D15 — it is observations about pages,
 * not configuration). So resuming a session meant being asked to point at
 * the same box again, on a page you had already adjudicated.
 *
 * This is the missing half: a person's ruling, kept per host, and replayed
 * the next time that host is opened.
 *
 * Two boundaries, both deliberate:
 *
 *   1. It stores the JOIN KEY, not the element and not its text. A stamp's
 *      stability key hashes identity fields plus structural path, so the
 *      element can be found again on a fresh load — but the file carries no
 *      placeholder, no aria-label, no id, nothing a human or a model wrote.
 *      Page furniture stays out of here the same way it stays out of the
 *      passport.
 *
 *   2. It is a hint, never a verdict. A replayed pick is only applied to an
 *      element that is actually on the page and actually matches the key. If
 *      the site redesigned, the match fails, the pick is not applied, and the
 *      ordinary verdict stands — which for an ambiguous page means the
 *      refusal and the Pick button come back. Remembering your answer must
 *      never become a way to guess.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

/** hash32 in stamp.js is a 32-bit djb2-xor in hex. Bounded, hex, or refused. */
const KEY_RE = /^[0-9a-f]{1,16}$/;
/** structuralPath is `body>tag:1>tag:2` — tag names, sibling indices and
 *  separators, and nothing else can appear in it. The index is optional in the
 *  pattern because structuralPath omits it at the top of the tree. This bounds
 *  the string; it is not a signature, and the replay never trusts it. */
const PATH_RE = /^body(>[a-z0-9]+(:\d+)?){0,12}$/;
/** structuralPath is capped at eight hops, so a real path is well under this.
 *  The regex bounds the segment count; this bounds the segment length. */
const MAX_PATH = 300;
const MAX_HOSTS = 200;

class PickStore {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'picks.json');
    this.picks = this.load();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const out = {};
      if (raw && typeof raw === 'object') {
        for (const [host, p] of Object.entries(raw)) {
          const clean = PickStore.clean(host, p);
          if (clean) out[host] = clean;
        }
      }
      return out;
    } catch {
      return {};
    }
  }

  /** Reduce a record to the two fields that matter, or to nothing. */
  static clean(host, p) {
    if (typeof host !== 'string' || !host || host.length > 255) return null;
    if (!p || typeof p !== 'object') return null;
    const key = typeof p.stabilityKey === 'string' ? p.stabilityKey.toLowerCase() : '';
    if (!KEY_RE.test(key)) return null;
    // The path is not the join key — the stability key is — but a stamp from
    // stampOf always carries one, so a record without a recognizable path is
    // not a stamp we produced. Refusing it costs nothing: the seat simply
    // falls back to detection and, if the page is ambiguous, asks again.
    const pth = typeof p.path === 'string' && p.path.length <= MAX_PATH && PATH_RE.test(p.path) ? p.path : null;
    if (!pth) return null;
    return { stabilityKey: key, path: pth, savedAt: p.savedAt || null };
  }

  save() {
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.picks, null, 2), 'utf8');
      return true;
    } catch {
      return false;
    }
  }

  get(host) {
    return this.picks[host] || null;
  }

  /**
   * Remember a human ruling. `stamp` is the stamp of the element they
   * clicked, straight from stampOf() in the seat preload.
   */
  set(host, stamp) {
    const clean = PickStore.clean(host, stamp && { stabilityKey: stamp.stabilityKey, path: stamp.path, savedAt: new Date().toISOString() });
    if (!clean) return false;
    // Bounded: the newest ruling wins, and the file cannot grow without limit.
    if (!this.picks[host] && Object.keys(this.picks).length >= MAX_HOSTS) {
      const oldest = Object.entries(this.picks).sort((a, b) => ((a[1].savedAt || '') < (b[1].savedAt || '') ? -1 : 1))[0];
      if (oldest) delete this.picks[oldest[0]];
    }
    this.picks[host] = clean;
    return this.save();
  }

  clear(host) {
    if (!this.picks[host]) return false;
    delete this.picks[host];
    return this.save();
  }
}

module.exports = { PickStore, KEY_RE, PATH_RE, MAX_PATH };
