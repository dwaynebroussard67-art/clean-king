/**
 * operator.js — who is flying this cockpit.
 *
 * A release that names nobody is the machine approving itself. A release that
 * names a hardcoded constant ('D', 'operator', 'human') is the same thing in
 * a costume. The name lives in configuration — the environment, or a file in
 * the user data dir — never in the renderer.
 *
 * Every launch still asks. A name on disk is a memory, not a session. The
 * renderer may ASK to sign in; the main process is what writes the name and
 * what stamps it. A compromised chrome can at worst ask.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

function normalizeName(s) {
  const n = String(s || '')
    .trim()
    .replace(/\s+/g, ' ')
    .slice(0, 40);
  if (n.length < 2) return null;
  return n;
}

class OperatorStore {
  /**
   * @param {string} dir  userData
   * @param {NodeJS.ProcessEnv} [env]
   */
  constructor(dir, env = process.env) {
    this.file = path.join(dir, 'operator.json');
    this.env = env;
    this.sessionName = null;
    this.sessionAt = null;
  }

  envName() {
    return normalizeName(this.env.FORGEFLIGHT_OPERATOR || this.env.OMNIBOX_OPERATOR);
  }

  /** @returns {{name:string, source:'env'|'file'}|null} */
  get() {
    const fromEnv = this.envName();
    if (fromEnv) return { name: fromEnv, source: 'env' };
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const name = normalizeName(raw && raw.name);
      if (name) return { name, source: 'file' };
    } catch {
      /* first run, or a corrupt file — both mean "not configured" */
    }
    return null;
  }

  /** The name to stamp this launch, or null. Never a default. Never the file alone. */
  name() {
    return this.sessionName || null;
  }

  signedIn() {
    return this.sessionName ? { name: this.sessionName, at: this.sessionAt } : null;
  }

  status() {
    const configured = this.get();
    const session = this.signedIn();
    return {
      name: session ? session.name : null,
      signedIn: !!session,
      configured: configured ? configured.name : null,
      source: session ? (this.envName() ? 'env' : 'session') : configured ? configured.source : null,
      envLocked: !!this.envName(),
      at: session ? session.at : null,
    };
  }

  set(name) {
    const n = normalizeName(name);
    if (!n) {
      return { ok: false, reason: 'bad-name', detail: 'A name is at least two characters, at most forty.' };
    }
    if (this.envName()) {
      return {
        ok: false,
        reason: 'env-locked',
        detail: 'FORGEFLIGHT_OPERATOR is set. Unset it to change the name on disk.',
      };
    }
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify({ name: n }, null, 2), 'utf8');
    } catch (e) {
      return { ok: false, reason: 'unwritable', detail: String((e && e.message) || e) };
    }
    return { ok: true, name: n, source: 'file' };
  }

  /**
   * Start this launch. A name on disk is offered, not assumed. Env-locked
   * cockpits confirm the locked name; they cannot pick another.
   */
  signIn(name) {
    const env = this.envName();
    const typed = normalizeName(name);
    if (env) {
      if (typed && typed !== env) {
        return {
          ok: false,
          reason: 'env-locked',
          detail: `This cockpit is locked to ${env}. Unset FORGEFLIGHT_OPERATOR to fly as someone else.`,
        };
      }
      this.sessionName = env;
      this.sessionAt = new Date().toISOString();
      return { ok: true, name: env, source: 'env' };
    }
    // A name on disk is offered by the chrome, never assumed here. Empty
    // sign-in is not a session — that was the hole that let a remembered
    // name become this launch without anyone typing or confirming it.
    if (!typed) {
      return {
        ok: false,
        reason: 'not-signed-in',
        detail: 'Sign in with your name every launch. A name on disk is a memory, not this session.',
      };
    }
    const n = typed;
    const saved = this.set(n);
    if (!saved.ok) return saved;
    this.sessionName = n;
    this.sessionAt = new Date().toISOString();
    return { ok: true, name: n, source: 'session' };
  }
}

/**
 * Stamp a release. The renderer may send an `actor`; it is ignored.
 * Not signed in this launch → fail closed. Never a default name.
 */
function authorizeActor(store, { actor } = {}) {
  void actor;
  const n = store && typeof store.name === 'function' ? store.name() : null;
  if (!n) {
    return {
      ok: false,
      reason: 'not-signed-in',
      detail: 'Sign in with your name every launch. Until then nothing can be released.',
    };
  }
  return { ok: true, actor: n };
}

module.exports = { OperatorStore, normalizeName, authorizeActor };
