/**
 * main.js — Forge Flight.
 *
 * A browser whose tabs are seats. You open claude.ai in a tab and that tab IS
 * a seat — no boarding, no keys, no picker. Type once in the box at the
 * bottom and the whole table hears it.
 */

'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { app, BrowserWindow, ipcMain, shell, Menu, session, protocol, dialog } = require('electron');

// Must happen before app-ready: makes forgeflight:// a standard, secure scheme so
// the built-in start page behaves like a real page rather than an opaque blob.
protocol.registerSchemesAsPrivileged([
  { scheme: 'forgeflight', privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

const { TabManager, toURL, PARTITION } = require('./tabs.js');
const { SeatRegistry, hostOf } = require('./seats.js');
const { SessionStore, missingFrom, restorableURL } = require('./session.js');
const { PickStore } = require('./picks.js');
const { Table } = require('./table.js');
const { Passport } = require('../passport/index.js');
const { nominateEquation, renderEquation } = require('../passport/equation.js');
const { AnchorLog } = require('./anchors.js');
const { teachFromFile, LessonStore } = require('../field-evidence/teacher.js');
const { Federation } = require('../federation/store.js');
const { ProposalQueue } = require('../federation/queue.js');
const { Curator } = require('../federation/curator.js');
const { proposeSupportedClaims, bootPayload, renderSeatBriefing, copilotPrompt } = require('../federation/bridge.js');
const { OperatorStore, authorizeActor } = require('./operator.js');
const { captainDecide, applyHumanCaptain } = require('./captain.js');
const { WarDiary, captainHelmet } = require('./diary.js');
const { FlightLog } = require('./flight.js');
const { LocalLLM } = require('./localLLM.js');
const { PilotManager } = require('./pilots.js');
const { RecentPages } = require('./history.js');
const { adoptLegacyProfile, guardAdoptedProfile, armAdoptedProfile, clearBootWatch } = require('./profile.js');
const { ForgeController } = require('../forge/controller.js');
const { dispatchSend } = require('../forge/seat-adapter.js');

const CHROME_PRELOAD = path.join(__dirname, '..', 'preload', 'chrome.js');
const LOCAL_SEAT_PAGE = path.join(__dirname, '..', 'renderer', 'local-seat.html');
const RENDERER = path.join(__dirname, '..', 'renderer', 'index.html');
const HOME = 'forgeflight://start';
const LOCAL_SEAT_URL_RE = /^forgeflight:\/\/local\/?$/i;

let win = null;
let tabs = null;
let seats = null;
let table = null;
let passport = null;
let anchors = null; // engine-training records — deliberately NOT the passport
let lessonStore = null; // promoted seating lessons, never conversation text
let federation = null; // the carrier: equations only, append-only, never deleted
let queue = null; // the curator's ONLY write path
let curator = null; // mission control: sees everything, flies nothing
let operator = null; // who signs a Federation release — configuration, never a constant
let diary = null; // named plays the captain wears — never copilots, never essays
let flight = null; // named maneuvers the pilot flew — never selectors, never page words
let sessionStore = null; // the tab list to resume; deliberately NOT a credential store
let picks = null; // composer boxes a person chose by hand, per host
let recent = null; // places you went, for the address bar
let pilots = null; // four browser agents that actually do things
let forgeController = null; // the Code Forge: the relay that writes code

// Who sits where, mirrored up from the chrome so it survives a restart. Keyed
// by HOST: tab ids are handed out fresh every launch, and one seat per host is
// already the law, so the host is the only stable name a seat has.
let tableLayout = { assign: {}, order: [], subjectHost: null };
let booted = false; // never save a session before the first one has been read
let saveTimer = null;

const calls = new Map(); // callId -> { resolve, tabId, runId, seatName, host, prompt, chunks }
let callSeq = 1;
let pushTimer = null;
const pendingCaptain = new Map(); // runId -> { answers } — human takes the chair when the local model is away

// --------------------------------------------------------------------------
// State pushed to the chrome
// --------------------------------------------------------------------------

function snapshot() {
  const tabState = tabs.toJSON();
  const resolved = seats.resolve(tabState.tabs);
  return {
    ...tabState,
    rail: resolved.rail,
    seatCount: resolved.seats.length,
    shapes: Table.shapes(),
    passport: passport ? passport.stats() : null,
    session: sessionInfo(tabState.tabs),
    operator: operator ? operator.status() : null,
    diary: diary ? diary.stats() : null,
    flight: flight ? flight.stats() : null,
  };
}

function carrierFacts() {
  return federation && typeof federation.all === 'function' ? federation.all() : [];
}

/** Passport boot block plus the Federation carrier section. The helmet. */
function bootFor(query, tokenBudget = 1200) {
  try {
    return bootPayload(passport, federation, query || '', { tokenBudget });
  } catch {
    const b = passport ? passport.bootBlock(query || '', { tokenBudget }) : { text: '', admitted: [], excluded: [] };
    return { ...b, carrier: { admitted: [], excluded: [] } };
  }
}

function seatBriefing() {
  try {
    return renderSeatBriefing(carrierFacts());
  } catch {
    return '';
  }
}

function autoPropose() {
  if (!passport || !curator || !queue) {
    return { scanned: 0, proposed: [], skipped: [], detail: 'not-ready' };
  }
  try {
    return proposeSupportedClaims({ passport, curator, queue });
  } catch (e) {
    return { scanned: 0, proposed: [], skipped: [], detail: String((e && e.message) || e) };
  }
}

async function decideCaptain(prompt, results, { shape, consensus } = {}) {
  const answers = (results || [])
    .filter((r) => r && r.ok && r.text)
    .map((r) => ({ seatName: r.seatName, text: r.text, ok: true }));
  // A held unknown is a law we already flew. Do not wake the local model
  // to re-grade it. Defer and verdict still need the chair.
  if (diary) {
    try {
      const applied = diary.applyHeld({ shape, answers, consensus });
      if (applied && applied.ok) return applied;
    } catch {
      /* a diary miss must not block the chair */
    }
  }
  let ask = null;
  try {
    const st = await localLLM.status();
    if (st && st.available) {
      ask = ({ system, prompt: p }) => localLLM.generate({ prompt: p, system });
    }
  } catch {
    ask = null;
  }
  let helmet = '';
  try {
    // The captain wears named plays, not the passport notebook. Dumping
    // essays into this chair is the wrong memory and it blows the small
    // local model's budget. Copilots never see the diary or the flight record.
    helmet = captainHelmet({ diary, flight, briefing: seatBriefing() });
  } catch {
    helmet = '';
  }
  return captainDecide({ ask, prompt, answers, helmet });
}

function recordCaptainPlay({ runId, captain, shape, answers, consensus }) {
  if (!diary) return null;
  try {
    const r = diary.record({ shape, answers, consensus, captain, runId });
    return r && r.ok ? r.play : null;
  } catch {
    return null;
  }
}

/**
 * What the chrome needs to know about resuming: how many places are saved,
 * which of them are not open right now, and who was assigned which side.
 * `missing` is what makes the Resume button honest — it is only offered when
 * there is something to bring back.
 */
function sessionInfo(openTabs) {
  const saved = sessionStore ? sessionStore.get() : null;
  const open = (openTabs || []).map((t) => t.url);
  const missing = missingFrom(saved, open);
  return {
    savedAt: saved ? saved.savedAt : null,
    savedTabs: saved ? saved.tabs.length : 0,
    missing: missing.map((t) => ({ url: t.url, title: t.title })),
    assign: tableLayout.assign,
    order: tableLayout.order,
    subjectHost: tableLayout.subjectHost,
  };
}

function push() {
  if (!win || win.isDestroyed()) return;
  clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    if (!win || win.isDestroyed()) return;
    win.webContents.send('state', snapshot());
  }, 16);
}

// --------------------------------------------------------------------------
// Saving the session
// --------------------------------------------------------------------------

/** Queue a write. Debounced: a page that navigates a dozen times in a second
 *  is one change to the list of places you were. */
function saveSessionSoon() {
  if (!booted) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveSessionNow, 500);
}

function saveSessionNow() {
  clearTimeout(saveTimer);
  saveTimer = null;
  if (!sessionStore || !tabs) return;
  // Before the first load has settled there is no "what is open" yet, and
  // writing then would mark a session nobody had closed as closed.
  if (!booted) return;
  const list = tabs.tabs
    .map((t) => {
      let url = t.url;
      if ((!url || url === 'about:blank') && t.wc && !t.wc.isDestroyed()) {
        try {
          url = t.wc.getURL();
        } catch {
          url = '';
        }
      }
      return { url, title: t.title };
    })
    .filter((t) => restorableURL(t.url));

  // Emptying the table is not forgetting it. The last non-empty set stays on
  // disk, flagged, so the next launch does not reopen what you just closed on
  // purpose — but the Resume button can still bring it back, which is the
  // whole reason it exists.
  if (list.length === 0) {
    // Before this launch has signed in, "no tabs open" is the GATE, not a
    // table that was emptied. Flagging the last real session as closed-all
    // then would silently kill auto-resume for every gated launch.
    if (!operator || !operator.name()) return;
    const prev = sessionStore.get();
    if (prev) sessionStore.save({ ...prev, closedAll: true });
    else sessionStore.clear();
    return;
  }
  const active = tabs.active;
  sessionStore.save({
    version: 1,
    savedAt: new Date().toISOString(),
    tabs: list,
    activeUrl: active && restorableURL(active.url) ? active.url : list[0].url,
    assign: tableLayout.assign,
    order: tableLayout.order,
    subjectHost: tableLayout.subjectHost,
    closedAll: false,
  });
}

/**
 * Bring back whatever from the saved session is not open now.
 *
 * Additive on purpose: it never closes a tab you have open, and it never
 * reopens a site you already have a tab on, because one seat per host is the
 * law and a second tab there would only be blocked by the rail. What comes
 * back is the places; the seats reassemble themselves as each page loads and
 * the detector looks at it.
 */
function restoreSession() {
  // The gate decides when pages mount. Until this launch signs in there are
  // no tabs, and restoring into the gate would mount native views over it.
  if (!operator || !operator.name()) {
    return { ok: false, reason: 'not-signed-in', detail: 'Sign in first — a name on disk is a memory, not this launch.' };
  }
  const saved = sessionStore ? sessionStore.get() : null;
  if (!saved) return { ok: false, reason: 'no-session', detail: 'There is no saved session to resume.' };
  const missing = missingFrom(saved, tabs.tabs.map((t) => t.url));
  if (missing.length === 0) {
    return { ok: true, restored: 0, detail: 'Everything from your last session is already open.' };
  }
  tabs.restore(missing, { activeUrl: saved.activeUrl });
  saveSessionSoon();
  push();
  return {
    ok: true,
    restored: missing.length,
    detail:
      missing.length === 1
        ? 'Reopened one site from your last session.'
        : `Reopened ${missing.length} sites from your last session.`,
  };
}

/**
 * The first tabs of a signed-in launch: resume the saved session, or open
 * the start page when there is nothing to resume. Called only once this
 * launch has signed in — before that, no page view may mount at all, because
 * a native WebContentsView sits above the chrome HTML and would cover the
 * sign-in card and eat its clicks.
 */
function openInitialContent() {
  if (!tabs || tabs.tabs.length !== 0) return;
  const saved = sessionStore ? sessionStore.get() : null;
  if (saved && saved.tabs && saved.tabs.length && !saved.closedAll) {
    // Sign in once, open Forge Flight, and the table is already set: the
    // logins are in the profile, this puts the seats back.
    tabs.restore(saved.tabs, { activeUrl: saved.activeUrl });
  } else {
    tabs.open(HOME);
  }
}

function emit(event, payload) {
  if (win && !win.isDestroyed()) win.webContents.send('table', { event, payload });
}

function emitForge(event, payload) {
  if (win && !win.isDestroyed()) win.webContents.send('forge', { event, payload });
}

/** Re-read the refusal log and broadcast only promoted lessons. A pick is
 *  what forms an example; verdicts alone never retune weights. */
let reteachTimer = null;
function reteachSoon() {
  clearTimeout(reteachTimer);
  reteachTimer = setTimeout(reteachNow, 250);
}
function reteachNow() {
  if (!anchors || !lessonStore) return;
  try {
    const out = teachFromFile(anchors.logPath);
    // A broken chain is a named refusal, not a lesson. Keep whatever was
    // already promoted rather than retuning from a tampered log.
    if (out && out.refused) return;
    lessonStore.replace(out.lessons);
  } catch {
    return;
  }
  broadcastLessons();
}
function broadcastLessons() {
  if (!tabs || !lessonStore) return;
  const list = lessonStore.promoted();
  for (const t of tabs.tabs) {
    if (!t.wc || t.wc.isDestroyed()) continue;
    try {
      t.wc.send('seat:lessons', list);
    } catch {
      /* the tab may have closed mid-broadcast */
    }
  }
}

// --------------------------------------------------------------------------
// Dispatch — the bridge from the Table to a seat's page
// --------------------------------------------------------------------------

function dispatch(tabId, text, { runId, round, role }) {
  const tab = tabs.byId(tabId);
  if (!tab) return Promise.resolve({ ok: false, reason: 'tab-gone', detail: 'That tab was closed mid-run.' });

  const callId = `c${callSeq++}`;
  const host = hostOf(tab.url);
  return new Promise((resolve) => {
    const timer = setTimeout(
      () => {
        if (!calls.has(callId)) return;
        calls.delete(callId);
        resolve({
          ok: false,
          reason: 'no-answer',
          detail: 'The seat never reported back. It may have been navigated away mid-run.',
        });
      },
      5 * 60 * 1000
    );

    calls.set(callId, {
      resolve: (r) => {
        clearTimeout(timer);
        resolve(r);
      },
      tabId,
      runId,
      round: round || null,
      role: role || null,
      host,
      seatName: seats.nameFor(host),
      prompt: text,
    });

    const local = LOCAL_SEAT_URL_RE.test(tab.url);
    let outbound = text;
    if (!local) {
      const briefing = seatBriefing();
      if (briefing) outbound = copilotPrompt(text, briefing);
    }

    tab.wc.send('seat:send', { runId: callId, text: outbound, settleMs: 1400, timeoutMs: 240000 });
  });
}

// --------------------------------------------------------------------------
// IPC from a seat's preload
// --------------------------------------------------------------------------

function tabFromEvent(e) {
  return tabs ? tabs.tabs.find((t) => t.wc.id === e.sender.id) : null;
}

ipcMain.on('seat:status', (e, payload) => {
  const tab = tabFromEvent(e);
  if (!tab) return;
  const prevConfirmed = tab.seat && tab.seat.confirmed;
  tab.seat = {
    status: payload.status,
    detail: payload.detail || '',
    confidence: payload.confidence || 0,
    margin: payload.margin || 0,
    signals: payload.signals || null,
    candidates: payload.candidates || [],
    anchor: payload.anchor || null,
    sendAnchor: payload.sendAnchor || null,
    tiedOn: payload.tiedOn || [],
    manual: !!payload.manual,
    // A composer restored from a pick made on a previous load, and the case
    // where a remembered pick no longer matches anything on the page — the
    // rail says both by name rather than quietly seating or refusing.
    restored: !!payload.restored,
    pickMissing: !!payload.pickMissing,
    // `verdictReason` is WHY the page was refused; `trigger` is what made us
    // look. Conflating them made a document-field refusal render as "ambiguous".
    reason: payload.verdictReason || null,
    trigger: payload.reason || null,
  };
  // A human ruling survives re-detection only while it still judges the same
  // anchor. The page re-rendering around an unchanged composer keeps the
  // ruling; a changed winner retires it, because "k1 was right" says nothing
  // about k2. Navigation clears it outright (tabs.js resets seat on
  // did-navigate), as it should — a new page, a new claim.
  const newKey = tab.seat.anchor && tab.seat.anchor.stabilityKey;
  if (prevConfirmed && newKey && prevConfirmed.anchorKey === newKey) {
    tab.seat.confirmed = prevConfirmed;
  }
  // A tab that has ruled no longer needs a real box to be measured in — park
  // it and give the layout back to the active tab. See TabManager.layout().
  if (tabs) tabs.layout();
  // Engine-training record: the choice, the losers, and — when the winner or
  // the verdict changed on a URL we had already seen — the before/after pair.
  if (anchors) {
    try {
      anchors.verdict({ tabId: tab.id, url: tab.wc.getURL(), trigger: payload.reason || 'auto', payload });
    } catch {
      /* the training log must never break seating */
    }
  }
  push();
});

ipcMain.on('seat:state', (e, { runId, phase, strategy, via }) => {
  const call = calls.get(runId);
  if (!call) return;
  emit('seat:phase', { runId: call.runId, tabId: call.tabId, seatName: call.seatName, phase, strategy, via });
});

ipcMain.on('seat:chunk', (e, { runId, text }) => {
  const call = calls.get(runId);
  if (!call) return;
  emit('seat:chunk', { runId: call.runId, tabId: call.tabId, seatName: call.seatName, text });
});

ipcMain.on('seat:result', (e, payload) => {
  const call = calls.get(payload.runId);
  if (!call) return;
  calls.delete(payload.runId);
  // Outcome record: whether the world responded, never what was said.
  if (anchors) {
    try {
      const tab = tabs.byId(call.tabId);
      const last = anchors.lastVerdict.get(call.tabId);
      anchors.outcome({
        url: tab ? tab.wc.getURL() : null,
        runId: call.runId,
        round: call.round,
        role: call.role,
        seatName: call.seatName,
        anchorKey: last ? last.winnerKey : null,
        result: payload,
      });
    } catch {
      /* the training log must never break a run */
    }
  }
  call.resolve(payload);
});

ipcMain.on('seat:picked', (e, payload) => {
  const tab = tabFromEvent(e);
  if (anchors) {
    try {
      anchors.pick({ url: tab ? tab.wc.getURL() : null, payload });
    } catch {
      /* the training log must never break picking */
    }
  }
  // The same ruling, kept where a future load can use it: per host, keyed by
  // the stamp's stability key. picks.js keeps nothing else — no label, no
  // placeholder, no text.
  if (picks && tab && payload && payload.ok && payload.stamp) {
    try {
      picks.set(hostOf(tab.url), payload.stamp);
    } catch {
      /* a ruling that fails to persist costs you one click next time */
    }
  }
  // A pick on a refused page is the join the teacher waits for.
  reteachSoon();
  emit('seat:picked', payload);
  push();
});

// The tab-side agent asks, as early as it runs, whether a person has already
// adjudicated this site. The document's own URL is the authority — `tab.url`
// is only updated once the navigation event lands, which can be after the
// preload has already asked. The host travels with the answer so the tab can
// check it is being given a ruling that belongs to the page it is on.
ipcMain.on('seat:askPick', (e) => {
  const tab = tabFromEvent(e);
  if (!tab || !picks) return;
  let url = '';
  try {
    url = e.sender.getURL() || '';
  } catch {
    url = '';
  }
  if (!url || url === 'about:blank') url = tab.url;
  const host = hostOf(url);
  if (!host) return;
  const remembered = picks.get(host);
  if (remembered) e.sender.send('seat:rememberedPick', { stabilityKey: remembered.stabilityKey, host });
});

ipcMain.on('seat:askLessons', (e) => {
  if (!lessonStore) return;
  try {
    e.sender.send('seat:lessons', lessonStore.promoted());
  } catch {
    /* the tab may have closed before the list arrived */
  }
});

// "Unpick" retires the ruling for this site as well, so the next load starts
// from detection instead of replaying a choice just withdrawn.
ipcMain.on('seat:forgetPick', (e) => {
  const tab = tabFromEvent(e);
  if (!tab || !picks) return;
  picks.clear(hostOf(tab.url));
  push();
});

// --------------------------------------------------------------------------
// The local-model seat (forgeflight://local). The bridge answers nobody but
// that page, and the "model" is whatever OpenAI-compatible server is
// running on this machine. No key, no account, no remote endpoint.
// --------------------------------------------------------------------------

const localLLM = new LocalLLM();

ipcMain.handle('localLLM:status', () => localLLM.status());

ipcMain.handle('localLLM:generate', (e, { prompt }) => {
  // The bridge opens onto localhost only, and only for the local seat page.
  let senderUrl = '';
  try {
    senderUrl = e.sender.getURL();
  } catch {
    senderUrl = '';
  }
  if (!LOCAL_SEAT_URL_RE.test(senderUrl)) {
    return { ok: false, reason: 'not-local-seat', detail: 'The local bridge answers the local seat page only.' };
  }
  const text = String(prompt || '').trim();
  if (!text) return { ok: false, reason: 'empty-prompt' };
  // The helmet: the passport's boot block plus the Federation carrier
  // section. The local model is the one seat whose context we own end to
  // end, so it wears the full notebook. Copilots get a short briefing
  // instead — dumping this into a public chat box would leak the fighter.
  let system = '';
  try {
    system = passport ? bootFor(text, 1200).text : '';
  } catch {
    system = ''; // a boot-block failure must never stop the answer
  }
  return localLLM.generate({
    prompt: text,
    system,
    onToken: (delta) => {
      try {
        e.sender.send('localLLM:token', delta);
      } catch {
        /* the seat may have closed mid-stream */
      }
    },
  });
});

// --------------------------------------------------------------------------
// IPC from the chrome
// --------------------------------------------------------------------------

ipcMain.handle('chrome:ready', () => snapshot());

ipcMain.on('chrome:viewport', (e, rect) => {
  if (tabs) tabs.setBounds(rect);
});

ipcMain.on('chrome:pageVisible', (e, v) => {
  // The chrome may only show the page once this launch has signed in; while
  // the gate is up the page stays off no matter what the renderer asks.
  if (v && !(operator && operator.name())) return;
  if (tabs) tabs.setPageVisible(v);
});

ipcMain.handle('tab:new', (e, url) => {
  const t = tabs.open(url ? toURL(url) : HOME);
  return t ? t.id : null;
});
ipcMain.handle('tab:close', (e, id) => tabs.close(id));
ipcMain.handle('tab:activate', (e, id) => tabs.activate(id));
ipcMain.handle('tab:navigate', (e, { id, input }) => tabs.navigate(id, input));
ipcMain.handle('tab:back', (e, id) => tabs.back(id));
ipcMain.handle('tab:forward', (e, id) => tabs.forward(id));
ipcMain.handle('tab:reload', (e, id) => tabs.reload(id));
ipcMain.handle('tab:tearOff', (e, id) => {
  tabs.tearOff(id);
});
ipcMain.handle('tab:dock', (e, id) => {
  tabs.dock(id);
});
ipcMain.handle('tab:devtools', (e, id) => {
  const t = tabs.byId(id);
  if (t) t.wc.openDevTools({ mode: 'detach' });
});

// --------------------------------------------------------------------------
// Resuming
// --------------------------------------------------------------------------

ipcMain.handle('session:info', () => sessionInfo(tabs.toJSON().tabs));

/**
 * Reopen whatever from the saved session is not open now. Additive: it never
 * closes a tab you have open, and it never reopens a site you already have a
 * tab on — one seat per host means a second tab there would only be blocked.
 */
ipcMain.handle('session:restore', () => restoreSession());

/** Save now, on purpose, rather than waiting for the debounce. */
ipcMain.handle('session:save', () => {
  saveSessionNow();
  return { ok: true, tabs: sessionStore && sessionStore.get() ? sessionStore.get().tabs.length : 0 };
});

/** Who sits where, pushed up from the chrome so a restart can put them back. */
ipcMain.on('session:assign', (e, payload) => {
  const p = payload || {};
  const roles = new Set(['A', 'B', 'out']);
  const assign = {};
  if (p.assign && typeof p.assign === 'object') {
    for (const [host, role] of Object.entries(p.assign)) {
      if (typeof host === 'string' && host && roles.has(role)) assign[host] = role;
    }
  }
  const seated = new Set(seats.resolve(tabs.toJSON().tabs).rail.filter((r) => r.seated).map((r) => r.host));
  tableLayout = {
    assign,
    order: Array.isArray(p.order) ? p.order.filter((h) => seated.has(h)) : [],
    subjectHost: seated.has(p.subjectHost) ? p.subjectHost : null,
  };
  saveSessionSoon();
  push();
});

ipcMain.handle('seat:pick', (e, id) => {
  const t = tabs.byId(id);
  if (t) t.wc.send('seat:pick');
});
ipcMain.handle('seat:unpick', (e, id) => {
  const t = tabs.byId(id);
  if (t) t.wc.send('seat:unpick');
});
ipcMain.handle('seat:redetect', (e, id) => {
  const t = tabs.byId(id);
  if (t) t.wc.send('seat:redetect');
});
ipcMain.handle('seat:rename', (e, { host, name }) => {
  seats.rename(host, name);
  push();
});
ipcMain.handle('seat:mute', (e, { host, muted }) => {
  seats.setMuted(host, muted);
  push();
});
// A human ruling on the seated anchor: "box is right" / "wrong box". Keyed
// by the anchor's stability key so it joins the claim in the scorer.
ipcMain.handle('seat:confirm', (e, { id, confirmed }) => {
  const t = tabs.byId(id);
  const key = t && t.seat && t.seat.anchor ? t.seat.anchor.stabilityKey : null;
  if (!t || !key) return { ok: false, reason: 'not-seated' };
  if (anchors) {
    try {
      anchors.confirm({ url: t.wc.getURL(), anchorKey: key, confirmed: !!confirmed, source: 'sheet' });
    } catch {
      /* the training log must never break a ruling */
    }
  }
  t.seat.confirmed = { value: !!confirmed, anchorKey: key, at: new Date().toISOString() };
  push();
  return { ok: true, confirmed: !!confirmed };
});

// --------------------------------------------------------------------------
// The places you went — address-bar suggestions from local history only.
// --------------------------------------------------------------------------

ipcMain.handle('history:recent', (e, { limit } = {}) =>
  recent ? recent.recent(limit || 12) : []
);
ipcMain.handle('history:suggest', (e, { input, limit } = {}) =>
  recent ? recent.suggest(input, limit || 6) : []
);

// --------------------------------------------------------------------------
// The four pilots — launch, stop, watch. All of it is user-triggered.
// --------------------------------------------------------------------------

ipcMain.handle('pilot:launch', (e, { goal, url, tabId }) => {
  if (!pilots) return { ok: false, reason: 'not-ready' };
  const r = pilots.launch({ goal, url, tabId });
  push();
  return r;
});
ipcMain.handle('pilot:stop', (e, { id }) => {
  const r = pilots ? pilots.stop(id) : { ok: false, reason: 'not-ready' };
  push();
  return r;
});
ipcMain.handle('pilot:stopAll', () => {
  const r = pilots ? pilots.stopAll() : { ok: false, reason: 'not-ready' };
  push();
  return r;
});
ipcMain.handle('pilot:status', () => (pilots ? pilots.status() : null));
ipcMain.handle('pilot:list', () => (pilots ? pilots.list() : []));
ipcMain.handle('pilot:get', (e, { id }) => (pilots ? pilots.get(id) : null));

// --------------------------------------------------------------------------
// Rail context menu — right-click on a tab in the seat rail.
// --------------------------------------------------------------------------
ipcMain.on('rail:contextmenu', (e, { tabId }) => {
  const tab = tabs.byId(tabId);
  if (!tab) return;
  const seated = !!(tab.seat && tab.seat.status === 'seated');

  const menu = Menu.buildFromTemplate([
    { label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => tabs.open(HOME) },
    { label: 'Duplicate Tab', click: () => tabs.open(tab.url, { background: false }) },
    { label: 'Reload', click: () => tabs.reload(tabId) },
    { type: 'separator' },
    tab.torn
      ? { label: 'Bring Back to Forge Flight', click: () => tabs.dock(tabId) }
      : { label: 'Open in New Window', click: () => tabs.tearOff(tabId) },
    { type: 'separator' },
    {
      label: 'Rename / Mute Seat…',
      enabled: seated,
      click: () => win && win.webContents.send('rail:openSheet', { tabId }),
    },
    { type: 'separator' },
    { label: 'Close Tab', accelerator: 'CmdOrCtrl+W', click: () => tabs.close(tabId) },
  ]);
  menu.popup({ window: win });
});

ipcMain.handle('table:send', async (e, spec) => {
  const state = snapshot();
  const eligible = state.rail.filter((r) => r.seated);
  const chosen = spec.only && spec.only.length ? eligible.filter((r) => spec.only.includes(r.tabId)) : eligible;

  if (chosen.length === 0) {
    return {
      ok: false,
      reason: 'no-seats',
      detail:
        'Nothing at the table yet. Open an AI chat in a tab — it seats itself. ' +
        'If a tab looks like a chat but is not seated, the rail says why.',
    };
  }

  const run = await table.run({
    prompt: spec.prompt,
    shape: spec.shape || 'communal',
    seats: chosen.map((r) => ({ id: r.tabId, name: r.name, host: r.host })),
    assignments: spec.assignments,
    subjectId: spec.subjectId,
    order: spec.order,
    focusId: spec.focusId || tabs.activeId,
  });

  // Passport intake — every reply is a candidate memory, nothing more.
  // Each reply may also NOMINATE an equation (a structured reduction of the
  // sentence). Code decides whether to accept it; an unaccepted nomination
  // changes nothing. This is the "model nominates, code decides" pattern,
  // with the deterministic placeholder nominator standing in for a model.
  const withMemories = run.results.map((r) => {
    if (!r.ok || !r.text) return r;
    const seat = chosen.find((c) => c.tabId === r.seatId);
    let equation;
    try {
      equation = nominateEquation(r.text) || undefined;
    } catch {
      equation = undefined; // a nominator failure must never lose the memory
    }
    const memory = passport.ingestReply({
      seatName: r.seatName,
      host: seat ? seat.host : null,
      prompt: spec.prompt,
      text: r.text,
      runId: run.runId,
      round: r.round,
      role: r.role,
      equation,
    });
    return { ...r, memory: memory ? { id: memory.memory.id, claim: memory.claim } : null };
  });

  const consensus = passport.recordDisagreement(run.runId, withMemories);
  emit('run:consensus', { runId: run.runId, consensus });

  // Radio UP: supported equation claims may now be proposed. Additive —
  // a curator that is offline must not fail the run (D21).
  let radio = { scanned: 0, proposed: [], skipped: [] };
  try {
    radio = autoPropose();
  } catch {
    radio = { scanned: 0, proposed: [], skipped: [] };
  }

  // Captain's stick: local model if one answers; otherwise the human.
  // Never fuses. Never blocks the run.
  let captain = { awaitingHuman: true, reason: 'human-captain' };
  try {
    captain = await decideCaptain(spec.prompt, withMemories, { shape: spec.shape, consensus });
  } catch (e) {
    captain = { awaitingHuman: true, reason: 'human-captain', detail: String((e && e.message) || e) };
  }
  if (captain && captain.awaitingHuman) {
    pendingCaptain.set(run.runId, {
      answers: withMemories
        .filter((r) => r && r.ok && r.text)
        .map((r) => ({ seatName: r.seatName, text: r.text, ok: true })),
      shape: spec.shape,
      consensus,
    });
  }
  let play = null;
  if (captain && !captain.awaitingHuman) {
    play = recordCaptainPlay({
      runId: run.runId,
      captain,
      shape: spec.shape,
      answers: withMemories,
      consensus,
    });
  }
  emit('run:captain', { runId: run.runId, captain, play });
  push();
  return { ok: true, ...run, results: withMemories, consensus, radio, captain, play };
});

ipcMain.handle('table:stop', (e, runId) => (runId ? table.stop(runId) : table.stopAll()));

// --------------------------------------------------------------------------
// The Code Forge — the relay that writes code
// --------------------------------------------------------------------------

/** The seated tabs become forge seats. A seat is a live tab; its `send` is the
 *  table's own dispatch, so a forge seat reaches an AI exactly the way the
 *  table does. Built fresh on every launch — a seat is never a credential. */
function forgeSeatDescriptors() {
  const state = snapshot();
  return state.rail
    .filter((r) => r.seated)
    .map((r) => ({
      id: r.tabId,
      name: r.name,
      send: dispatchSend(dispatch, r.tabId, { runId: 'forge', role: 'forge' }),
    }));
}

/** The bench: a free, unmetered local model if one is running. The relay swaps
 *  it in when a seated provider runs dry — no key, no account, honest refusal
 *  when nothing is listening on the local server. */
function forgeBenchDescriptors() {
  return [
    {
      id: 'local',
      name: 'Local',
      send: async (prompt) => {
        try {
          const st = await localLLM.status();
          if (!st || !st.available) {
            return { ok: false, reason: 'local-model-offline', detail: 'no local server running (Ollama / LM Studio)' };
          }
          return localLLM.generate({ prompt });
        } catch (e) {
          return { ok: false, reason: 'local-model-error', detail: String((e && e.message) || e) };
        }
      },
    },
  ];
}

ipcMain.handle('forge:status', () => (forgeController ? forgeController.view() : null));

ipcMain.handle('forge:browse', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Choose a repository for the forge',
    properties: ['openDirectory'],
  });
  if (res.canceled || !res.filePaths.length) return null;
  return res.filePaths[0];
});

ipcMain.handle('forge:launch', async (e, spec = {}) => {
  if (!forgeController) return { ok: false, reason: 'not-ready' };
  const seats = forgeSeatDescriptors();
  if (seats.length === 0) {
    return {
      ok: false,
      reason: 'no_seats',
      detail: 'Nothing at the table yet. Open an AI chat in a tab — it seats itself.',
    };
  }
  const budget = spec.seatBudget && spec.seatBudget.maxCalls ? { maxCalls: Number(spec.seatBudget.maxCalls) } : undefined;
  return forgeController.launch({
    goal: (spec.goal && String(spec.goal)) || '',
    repoDir: (spec.repoDir && String(spec.repoDir)) || '',
    seats,
    bench: forgeBenchDescriptors(),
    maxRounds: spec.maxRounds ? Number(spec.maxRounds) : undefined,
    seatBudget: budget,
  });
});

ipcMain.handle('forge:stop', () => (forgeController ? forgeController.stop() : { ok: false, reason: 'not-ready' }));

ipcMain.handle('forge:resume', (e, opts = {}) => (forgeController ? forgeController.resume(opts) : { ok: false, reason: 'not-ready' }));

ipcMain.handle('forge:release', (e, { id } = {}) => (forgeController ? forgeController.release(id) : { ok: false, reason: 'not-ready' }));

ipcMain.handle('forge:reject', (e, { id, reason } = {}) => (forgeController ? forgeController.reject(id, reason) : { ok: false, reason: 'not-ready' }));

/** The human in the captain chair. Signed by this launch's operator. */
ipcMain.handle('table:captain', (e, { runId, decision, text, seat, reason } = {}) => {
  const who = authorizeActor(operator);
  if (!who.ok) return who;
  const pending = pendingCaptain.get(runId);
  if (!pending) {
    return { ok: false, reason: 'no-pending-captain', detail: 'There is no open captain decision for that run.' };
  }
  const captain = applyHumanCaptain({
    decision,
    text,
    seat,
    reason,
    answers: pending.answers,
    actor: who.actor,
  });
  let play = null;
  if (captain.ok) {
    pendingCaptain.delete(runId);
    play = recordCaptainPlay({
      runId,
      captain,
      shape: pending.shape,
      answers: pending.answers,
      consensus: pending.consensus,
    });
  }
  emit('run:captain', { runId, captain, play });
  push();
  return { ...captain, play };
});

ipcMain.handle('passport:boot', (e, { query, tokenBudget }) => {
  const b = bootFor(query || '', tokenBudget || 1200);
  return {
    text: b.text,
    admitted: (b.admitted || []).map((a) => ({
      id: a.memory.id,
      title: a.memory.title,
      content: a.memory.content,
      type: a.memory.type,
      status: a.claim.status,
      witnesses: a.claim.confirmationCount,
      weight: a.weight,
      pinned: a.pinned,
      similarity: a.similarity,
    })),
    excluded: (b.excluded || []).map((x) => ({ id: x.memory.id, title: x.memory.title, reason: x.reason, detail: x.detail })),
    tokensUsed: b.tokensUsed,
    tokenBudget: b.tokenBudget,
    carrier: b.carrier || { admitted: [], excluded: [] },
  };
});

ipcMain.handle('passport:list', () => {
  const rows = passport.rows().map(({ memory, claim }) => ({
    id: memory.id,
    title: memory.title,
    content: memory.content,
    type: memory.type,
    confidence: memory.confidence,
    pinned: memory.pinned,
    origin: memory.origin,
    adjudicated: !!memory.adjudicatedAt,
      createdAt: memory.createdAt,
      seat: memory.metadata && memory.metadata.seat,
      claim: {
        id: claim.id,
        status: claim.status,
        witnesses: claim.confirmationCount,
        form: claim.form || 'prose',
        equation: claim.equation ? renderEquation(claim.equation) : null,
      },
  }));
  rows.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  return { rows, stats: passport.stats() };
});

ipcMain.handle('passport:pin', (e, { id, pinned }) => {
  passport.boundary.pin(id, pinned);
  push();
});
ipcMain.handle('passport:adjudicate', (e, { id }) => {
  passport.boundary.adjudicate(id, { actor: 'human' });
  push();
});
ipcMain.handle('passport:retire', (e, { id }) => {
  passport.boundary.retire(id, { actor: 'human' });
  push();
});

// --------------------------------------------------------------------------
// The Federation, the curator, and the airlock
//
// The curator is a READER on the outbound side. It proposes; it never sends,
// never flies, never mounts a capability. Every handler below either reads,
// or writes to the proposal queue — with the single exception of
// `federation:release`, which is a HUMAN acting on a signed ticket.
// --------------------------------------------------------------------------

ipcMain.handle('federation:stats', () => ({
  federation: federation.stats(),
  queue: queue.stats(),
  health: curator.health(),
}));

ipcMain.handle('federation:facts', (e, { shelf, limit } = {}) =>
  federation
    .live({ shelf })
    .slice(0, limit || 200)
    .map((f) => ({
      id: f.id,
      signature: f.signature,
      shelf: f.shelf,
      rendered: f.rendered,
      target: f.target,
      status: f.status,
      distinct: f.distinct,
      witnesses: f.witnesses.map((w) => ({ kind: w.kind, nodeId: w.nodeId, at: w.at })),
      landedAt: f.landedAt,
      lastSeenAt: f.lastSeenAt,
    }))
);

ipcMain.handle('federation:queue', () => queue.all({ limit: 100 }));

/**
 * A human answers. The renderer may send an `actor`; it is ignored.
 * The name comes from configuration. No operator configured → fail closed.
 */
ipcMain.handle('federation:release', (e, { id, actor, note }) => {
  void actor;
  const who = authorizeActor(operator);
  if (!who.ok) return who;
  const item = queue.get(id);
  if (!item) return { ok: false, reason: 'unknown-proposal' };
  const decided = queue.release(id, { actor: who.actor, note });
  if (!decided.ok) return decided;

  // The release AUTHORISES. Landing is done here, by the app, on a signed
  // ticket — never by the curator.
  if (item.ask === 'transfer') {
    const landed = federation.land({
      shelf: item.shelf,
      equation: item.equation,
      witness: item.witness,
      nodeId: item.nodeId,
      reference: item.reference,
      target: item.target,
      actor: who.actor,
    });
    push();
    return { ok: true, released: decided.item, landed };
  }
  push();
  return { ok: true, released: decided.item };
});

ipcMain.handle('federation:refuse', (e, { id, actor, note }) => {
  void actor;
  const who = authorizeActor(operator);
  if (!who.ok) return who;
  const r = queue.refuse(id, { actor: who.actor, note });
  push();
  return r;
});

ipcMain.handle('federation:autoPropose', () => {
  const r = autoPropose();
  push();
  return r;
});

ipcMain.handle('operator:get', () => (operator ? operator.status() : null));
ipcMain.handle('operator:set', (e, { name }) => {
  if (!operator) return { ok: false, reason: 'not-ready' };
  const r = operator.set(name);
  push();
  return r;
});
ipcMain.handle('operator:signin', (e, { name } = {}) => {
  if (!operator) return { ok: false, reason: 'not-ready' };
  const r = operator.signIn(name);
  if (r.ok) {
    // The gate is down: pages may mount now. If nothing is open yet (the
    // usual case — the gate is up before any tab exists), put the seats
    // back or open the start page.
    if (tabs) tabs.setSignedIn(true);
    openInitialContent();
  }
  push();
  return r;
});

/** A named human marks a play held or broke. Unsigned is refused. */
ipcMain.handle('diary:mark', (e, { name, result } = {}) => {
  if (!diary) return { ok: false, reason: 'not-ready' };
  const who = authorizeActor(operator);
  if (!who.ok) return who;
  const r = diary.mark(name, result, who.actor);
  push();
  return r;
});

/** A named human marks a maneuver held or broke. Unsigned is refused. */
ipcMain.handle('flight:mark', (e, { name, result } = {}) => {
  if (!flight) return { ok: false, reason: 'not-ready' };
  const who = authorizeActor(operator);
  if (!who.ok) return who;
  const r = flight.mark(name, result, who.actor);
  push();
  return r;
});

ipcMain.handle('federation:rechecks', (e, { days } = {}) => {
  const props = curator.proposeRechecks({ days: days || 30 });
  push();
  return props;
});

/**
 * The airlock for a capability.
 *
 * A pilot has already cleared its own filter to get here; that is not a
 * grant. The curator checks the request against the LARGER base — what the
 * pilot cannot see — and either raises no objection, or denies it with the
 * exact constraint that failed and queues it for a human.
 */
ipcMain.handle('federation:review', (e, request) => {
  const r = curator.reviewCapability(request || {});
  push();
  return r;
});

/**
 * A fact wants to leave a cockpit and land on the carrier.
 *
 * A single node's `outcome` is the one witness kind nobody else can
 * re-derive, so it stays local until it is independently replicated or
 * paired with something structural. Replication is not agreement — five
 * nodes measuring is not five parties voting.
 */
ipcMain.handle('federation:propose', (e, spec) => {
  const r = curator.reviewTransfer(spec || {});
  push();
  return r;
});

ipcMain.handle('passport:export', async () => {
  const stamp = new Date().toISOString().slice(0, 10);
  const { canceled, filePath } = await dialog.showSaveDialog(win, {
    title: 'Export the passport',
    defaultPath: path.join(app.getPath('downloads'), `forgeflight-passport-${stamp}.json`),
    filters: [{ name: 'Forge Flight passport', extensions: ['json'] }],
  });
  if (canceled || !filePath) return { ok: false, reason: 'cancelled' };
  const bundle = passport.export();
  fs.writeFileSync(filePath, JSON.stringify(bundle, null, 2), 'utf8');
  return {
    ok: true,
    path: filePath,
    claims: bundle.claims.length,
    memories: bundle.memories.length,
  };
});

ipcMain.handle('passport:import', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(win, {
    title: 'Import a passport',
    properties: ['openFile'],
    filters: [{ name: 'Forge Flight passport', extensions: ['json'] }],
  });
  if (canceled || !filePaths || !filePaths[0]) return { ok: false, reason: 'cancelled' };
  let bundle;
  try {
    bundle = JSON.parse(fs.readFileSync(filePaths[0], 'utf8'));
  } catch (e) {
    return { ok: false, reason: 'unreadable', detail: `That file is not valid JSON: ${e.message}` };
  }
  const res = passport.importBundle(bundle);
  push();
  return res;
});

ipcMain.handle('shell:open', (e, url) => shell.openExternal(url));

// --------------------------------------------------------------------------
// Boot
// --------------------------------------------------------------------------

function registerStartPage() {
  // Microphone access for the chrome window's dictation buttons. The chrome
  // is local HTML on the default session (tabs live on PARTITION, below) —
  // scoped to 'media' only, and only for the chrome's own webContents, so a
  // seated page can never piggyback a mic request through this handler.
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(permission === 'media' && webContents.id === win?.webContents.id);
  });

  const ses = session.fromPartition(PARTITION);
  // Talk-to-text on the local-model seat page only. Provider pages never
  // get the microphone through us.
  ses.setPermissionRequestHandler((webContents, permission, callback) => {
    let url = '';
    try {
      url = webContents.getURL() || '';
    } catch {
      url = '';
    }
    callback(permission === 'media' && LOCAL_SEAT_URL_RE.test(url));
  });
  // A tiny built-in start page so a new tab is not a blank void, and the
  // local-model seat at forgeflight://local. Registered on the tab session
  // only; the chrome never loads remote content of any kind.
  ses.protocol.handle('forgeflight', (request) => {
    if (LOCAL_SEAT_URL_RE.test(request.url)) {
      const body = fs.readFileSync(LOCAL_SEAT_PAGE, 'utf8');
      return new Response(body, { headers: { 'content-type': 'text/html; charset=utf-8' } });
    }
    const body = `<!doctype html><meta charset=utf-8><title>New tab</title>
<style>
  :root{color-scheme:dark}
  body{margin:0;height:100vh;display:grid;place-items:center;background:#0d1014;color:#8b95a5;
       font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif}
  .w{text-align:center;max-width:460px;padding:0 24px}
  h1{font:600 13px/1 system-ui;letter-spacing:.22em;text-transform:uppercase;color:#4a5462;margin:0 0 20px}
  p{margin:0 0 10px}
  b{color:#ff5500;font-weight:600}
  code{color:#c8d0dc;background:#161b22;padding:2px 7px;border-radius:5px;font-size:13px}
</style>
<div class=w>
  <h1>Forge Flight</h1>
  <p>Open an AI chat in this tab. It takes a seat by itself.</p>
  <p>Then type once in the box at the bottom — <b>everyone at the table hears it</b>.</p>
  <p style="margin-top:22px;font-size:13px;color:#5a6474">Try <code>claude.ai</code> · <code>chatgpt.com</code> · <code>gemini.google.com</code> · or anything else with a chat box</p>
</div>`;
    return new Response(body, { headers: { 'content-type': 'text/html; charset=utf-8' } });
  });
}

function createWindow() {
  win = new BrowserWindow({
    width: 1440,
    height: 940,
    // Keep a usable lower bound for touch-sized preview windows. The native
    // phone builds live in mobile/, but this lets the same chrome be resized
    // below the desktop layout without clipping the dock.
    minWidth: 360,
    minHeight: 520,
    backgroundColor: '#0d1014',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: {
      preload: CHROME_PRELOAD,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  passport = new Passport(Passport.defaultDir(app));
  // Engine-training records: anchors, losers, outcomes, human picks. Their
  // own append-only file, next to but never inside the passport store.
  anchors = new AnchorLog(app.getPath('userData'));
  lessonStore = new LessonStore(app.getPath('userData'));
  federation = new Federation(Federation.defaultDir(app)).load();
  queue = new ProposalQueue(ProposalQueue.defaultDir(app)).load();
  curator = new Curator(federation, queue);
  operator = new OperatorStore(app.getPath('userData'));
  diary = new WarDiary(WarDiary.defaultDir(app)).load();
  flight = new FlightLog(FlightLog.defaultDir(app)).load();
  seats = new SeatRegistry(app.getPath('userData'));
  // The resume contract: which places were open, and which composer you chose
  // by hand on which site. URLs and stability keys — never a credential.
  sessionStore = new SessionStore(app.getPath('userData'));
  picks = new PickStore(app.getPath('userData'));
  // The places you went, for the address bar — and the four pilots.
  recent = new RecentPages(app.getPath('userData'));
  // The Code Forge. Its memory lives under userData/forge; its seats are the
  // tabs already at the table (built fresh on every launch, because a seat is
  // a live tab, not a credential).
  forgeController = new ForgeController({
    storeDir: path.join(app.getPath('userData'), 'forge'),
    emit: (m) => emitForge(m.event, m.payload),
  });
  const resumed = sessionStore.get();
  tableLayout = {
    assign: (resumed && resumed.assign) || {},
    order: (resumed && resumed.order) || [],
    subjectHost: (resumed && resumed.subjectHost) || null,
  };
  // Every tab change flows through emitChanged — opening, closing, activating,
  // navigating, a link that wants a new tab — so hooking it here catches all
  // of them instead of hoping each call site remembers to save.
  tabs = new TabManager(
    win,
    () => {
      push();
      saveSessionSoon();
    },
    (url, title) => {
      if (recent) recent.add(url, title);
    }
  );
  // A launch is signed in only after the operator confirms it. A window
  // re-created on macOS after the app is already signed in starts signed in;
  // the usual boot starts gated and is un-gated by operator:signin.
  tabs.setSignedIn(!!(operator && operator.name()));
  table = new Table({ dispatch, emit });
  try {
    reteachNow();
  } catch {
    /* an empty or unreadable log is not a seating failure */
  }

  // The pilots' brain: the local model if one answers, else the first open
  // seat. No model and no seat is a named refusal at launch, not a guess.
  const pilotAsk = async ({ system, prompt }) => {
    try {
      const st = await localLLM.status();
      if (st && st.available) {
        // The local model may wear the flight record. A seated copilot
        // never does — dumping named plays into a public chat box is the
        // leak this product refuses.
        let sys = system || '';
        try {
          if (flight && typeof flight.playbook === 'function') {
            const book = flight.playbook();
            if (book) sys = `${book}\n\n${sys}`;
          }
        } catch {
          /* a playbook miss must not stop the driver */
        }
        const r = await localLLM.generate({ prompt, system: sys });
        if (r && r.ok) return { ok: true, text: r.text };
        return {
          ok: false,
          reason: (r && r.reason) || 'no-answer',
          detail: (r && r.detail) || 'The local model did not answer.',
        };
      }
    } catch {
      /* fall through to a seat */
    }
    const thinker = tabs.tabs.find((t) => t.seat && t.seat.status === 'seated');
    if (!thinker) {
      return {
        ok: false,
        reason: 'no-driver',
        detail: 'No local model and no seat open to think with. Seat an AI or start a local server (Ollama / LM Studio).',
      };
    }
    const r = await dispatch(thinker.id, `${system || ''}\n\n${prompt}`, { runId: `pilot-${Date.now()}`, role: 'pilot' });
    if (r && r.ok) return { ok: true, text: r.text || r.reply || '' };
    return {
      ok: false,
      reason: (r && r.reason) || 'no-answer',
      detail: (r && r.detail) || 'The thinking seat did not answer.',
    };
  };

  // The pilots' hands: real tabs only. Every step is mirrored to the chrome
  // and to the flight recorder (verb + refusal, never targets or words).
  const pilotPage = {
    open: (url) => {
      const t = tabs.open(url, { background: false });
      return t ? t.id : null;
    },
    navigate: (tabId, url) => tabs.navigate(tabId, url),
    evaluate: (tabId, code) => {
      const t = tabs.byId(tabId);
      if (!t) throw new Error('tab-gone');
      return t.wc.executeJavaScript(code, true);
    },
  };
  const pilotEmit = (event, payload) => {
    if (win && !win.isDestroyed()) win.webContents.send(event, payload);
    const p = payload || {};
    // The flight bag is the only thing that goes to flight.jsonl. The UI
    // sentence on the payload stays off disk.
    if (event === 'pilot:step' && flight && p.flight) {
      try {
        const bag = p.flight;
        flight.record({
          before: bag.before,
          after: bag.after,
          verb: bag.verb,
          ok: bag.ok,
          reason: bag.reason,
          pilot: p.slot ? `P${p.slot}` : p.id || null,
          step: typeof p.step === 'number' ? p.step : null,
        });
      } catch {
        /* the flight record must never break a flight */
      }
    }
    if (!anchors) return;
    try {
      // The tab a step flew on: the payload names it; otherwise look the task up.
      const task = p.tabId ? null : pilots ? pilots.get(p.id) : null;
      const tabId = p.tabId || (task && task.tabId) || null;
      let url = null;
      try {
        const tab = tabId ? tabs.byId(tabId) : null;
        url = tab ? tab.wc.getURL() : null;
      } catch {
        url = null;
      }
      const slot = p.slot ? `P${p.slot}` : p.id || null;
      // Refusals now arrive on pilot:step with the bag, so finished must
      // not also stamp — the two would double-count.
      if (event === 'pilot:step') {
        const ok = p.flight ? !!p.flight.ok : true;
        const reason = p.flight ? p.flight.reason : null;
        anchors.pilotStep({ url, pilot: slot, step: p.step ?? null, verb: p.action || null, ok, reason });
      }
    } catch {
      /* the flight recorder must never break a flight */
    }
  };
  pilots = new PilotManager({ ask: pilotAsk, page: pilotPage, emit: pilotEmit });

  win.loadFile(RENDERER);
  win.webContents.on('did-finish-load', () => {
    // No page view mounts here anymore. On a first launch the gate is up and
    // there is no session yet — a native tab view opened now would sit above
    // the chrome HTML and cover the "Who is flying?" card, eating its clicks.
    // The first tabs come from openInitialContent(), which runs when this
    // launch signs in (operator:signin). A window re-created on macOS after
    // the app is already signed in restores straight away.
    if (operator && operator.name()) openInitialContent();
    // From here on, what is open is what gets saved. Before this point a save
    // would write an empty list over a session nobody had closed.
    booted = true;
    try {
      autoPropose();
    } catch {
      /* a radio failure at boot must never block the window */
    }
    saveSessionSoon();
    push();
  });

  win.on('resize', () => push());
  win.on('closed', () => {
    win = null;
  });

  // Keyboard, handled at the window level so it works with focus in a page.
  const accel = (input) => {
    const mod = process.platform === 'darwin' ? input.meta : input.control;
    if (!mod || input.type !== 'keyDown') return null;
    const k = input.key.toLowerCase();
    if (k === 't') return 'new-tab';
    if (k === 'w') return 'close-tab';
    if (k === 'l') return 'focus-address';
    if (k === 'k') return 'focus-forgeflight';
    if (k === 'r') return 'reload';
    if (k === '[') return 'back';
    if (k === ']') return 'forward';
    return null;
  };
  const handleAccel = (event, input) => {
    const action = accel(input);
    if (!action) return;
    // While the gate is up there is no page to reload or tab to close, and a
    // keyboard shortcut must not open one under the sign-in card.
    if (!operator || !operator.name()) return;
    event.preventDefault();
    if (action === 'new-tab') tabs.open(HOME);
    else if (action === 'close-tab' && tabs.activeId) tabs.close(tabs.activeId);
    else if (action === 'reload') tabs.reload(tabs.activeId);
    else if (action === 'back') tabs.back(tabs.activeId);
    else if (action === 'forward') tabs.forward(tabs.activeId);
    else win.webContents.send('accel', action);
  };
  win.webContents.on('before-input-event', handleAccel);
  const origOpen = tabs.open.bind(tabs);
  tabs.open = (url, o) => {
    const t = origOpen(url, o);
    if (!t) return null; // refused: this launch has not signed in yet
    t.wc.on('before-input-event', handleAccel);
    // The first real page to load is the first thing that could have touched
    // an adopted profile's Chromium storage. It surviving a load is the
    // profile proving it opens — clear the boot watch (profile.js).
    t.wc.on('did-stop-loading', () => {
      try {
        if (t.url && /^https?:/i.test(t.url)) clearBootWatch(app.getPath('userData'));
      } catch {
        /* a settle miss only costs a quarantine that never comes */
      }
    });
    return t;
  };
  win.once('ready-to-show', () => {
    // An adopted profile that can open proves it shortly after the window
    // shows. Past this point a crash is a crash, not a verdict on the
    // profile — clear the watch so one bad day cannot quarantine it.
    setTimeout(() => {
      try {
        clearBootWatch(app.getPath('userData'));
      } catch {
        /* nothing armed */
      }
    }, 90 * 1000);
  });

  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
      {
        label: 'File',
        submenu: [
          { label: 'New Tab', accelerator: 'CmdOrCtrl+T', click: () => tabs.open(HOME) },
          { label: 'Close Tab', accelerator: 'CmdOrCtrl+W', click: () => tabs.activeId && tabs.close(tabs.activeId) },
          { type: 'separator' },
          { label: 'Restore Last Session', click: () => restoreSession() },
          { type: 'separator' },
          { role: process.platform === 'darwin' ? 'close' : 'quit' },
        ],
      },
      { role: 'editMenu' },
      {
        label: 'View',
        submenu: [
          { label: 'Reload Page', accelerator: 'CmdOrCtrl+R', click: () => tabs.reload(tabs.activeId) },
          {
            label: 'Page Developer Tools',
            accelerator: 'CmdOrCtrl+Alt+I',
            click: () => {
              const t = tabs.active;
              if (t) t.wc.openDevTools({ mode: 'detach' });
            },
          },
          { label: 'Forge Flight Developer Tools', click: () => win.webContents.openDevTools({ mode: 'detach' }) },
          { type: 'separator' },
          { role: 'togglefullscreen' },
        ],
      },
    ])
  );
}

// An isolated profile for verification runs, so a test never reads or writes
// the profile a person is actually using.
if (process.env.FORGEFLIGHT_USER_DATA) app.setPath('userData', process.env.FORGEFLIGHT_USER_DATA);
else {
  // First launch after the rename: adopt the OmniBox profile (logins,
  // passport, session, picks, anchors, federation) rather than starting
  // empty beside it. Once, never overwriting, never fatal. See D26.
  //
  // Order matters. A legacy profile that an OLDER Chromium wrote can kill a
  // NEWER Chromium inside its storage layer, before or just after the window
  // shows — the adopted tree under %APPDATA% died on every launch on the
  // machine this was diagnosed on. The boot watch (profile.js) arms each
  // launch of an adopted profile, disarms on a graceful end or once a page
  // has really loaded, and after two deaths in a row quarantines the tree to
  // forgeflight.old so the next launch starts fresh instead of dying again.
  // That must run BEFORE Electron opens any of the folder.
  const ud = app.getPath('userData');
  const guard = guardAdoptedProfile(ud);
  if (guard.action !== 'none') console.log(`[profile] ${guard.action}: ${guard.detail}`);
  const adopted = adoptLegacyProfile(ud);
  if (adopted.action !== 'none' && adopted.action !== 'kept') console.log(`[profile] ${adopted.action}: ${adopted.detail}`);
  // The boot that just adopted arms the watch with count one: if THIS
  // profile cannot open, the death leaves the mark and the next launches
  // quarantine it instead of dying on it again.
  if ((adopted.action === 'moved' || adopted.action === 'copied') && armAdoptedProfile(ud)) {
    console.log('[profile] watching: adopted profile armed under the boot watch');
  }
}

app.whenReady().then(() => {
  registerStartPage();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// The session is written on a debounce; a quit should not lose the last half
// second of it, or the resume would be one tab behind what you were looking at.
app.on('before-quit', () => {
  try {
    saveSessionNow();
  } catch {
    /* the next launch simply resumes from an older list */
  }
  // A quit that ran to completion is a graceful end: the profile opened, so
  // the boot watch (profile.js) must not count this boot against it.
  try {
    clearBootWatch(app.getPath('userData'));
  } catch {
    /* nothing armed */
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

module.exports = { snapshot };
