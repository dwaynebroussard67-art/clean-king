/**
 * session.js — the resume contract: which tabs were at the table.
 *
 * Forge Flight already holds the logins. Every tab lives in one persistent
 * Chromium partition (`persist:omnibox`, see tabs.js), so a provider's
 * cookies and session tokens are on disk and waiting the next time the app
 * opens. What was missing was the list: nothing recorded which sites you had
 * open, so a restart meant reopening every AI by hand and letting each one
 * decide whether it still liked you.
 *
 * This file is that list and nothing more. It stores URLs — never a
 * credential, never a cookie, never a token, and never a prompt or a reply.
 * A session is a set of places, not a bag of secrets: restoring it means
 * asking Chromium to open those places again with the profile it already
 * has. If a provider revoked your login, the restored tab shows their login
 * page and the detector honestly refuses to seat it. Forge Flight cannot and does
 * not re-inject a session it was never given.
 *
 * The store is deliberately dumb: one small JSON file, written whole, read
 * defensively. A corrupt or missing file is a first run, not an error.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

const VERSION = 1;
/** A restored window that opens sixty tabs is not a feature, it is a fork bomb. */
const MAX_TABS = 30;
/** URLs beyond this are not a place you were, they are someone's payload. */
const MAX_URL_LENGTH = 2048;

/**
 * May this URL be reopened on a future launch?
 *
 * The allowlist is short on purpose. `https:` is the ordinary case. `http:`
 * is admitted for loopback only, so a local fixture or a dev server can be
 * resumed without ever writing a plaintext URL for a real site into the
 * file. `forgeflight:` is ours — the start page and the local-model seat.
 * Everything else is refused by name: `file:` would reopen a path, `data:`
 * and `blob:` would reopen a payload, and a `javascript:` URL would not be
 * a place at all.
 */
function restorableURL(input) {
  if (typeof input !== 'string' || !input || input.length > MAX_URL_LENGTH) return null;
  let u;
  try {
    u = new URL(input);
  } catch {
    return null;
  }
  const proto = u.protocol.toLowerCase();
  // Our scheme names two rooms — `forgeflight://start` and
  // `forgeflight://local` — and a bare `forgeflight:` names neither. It
  // parses, so it used to be admitted; what came back was a tab pointed at
  // nothing, which the protocol handler answers with the start page while
  // the session claims it restored somewhere the person had open. A place
  // needs a host.
  if (proto === 'forgeflight:') return u.host ? u.href : null;
  // A session saved by OmniBox names its own pages under the old scheme.
  // Those are the same two rooms; translate rather than drop. See D26.
  if (proto === 'omnibox:') return u.host ? `forgeflight:${u.href.slice('omnibox:'.length)}` : null;
  if (proto === 'https:') return u.href;
  if (proto === 'http:') {
    const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
    const loopback = h === 'localhost' || h === '::1' || /^127(\.\d+){3}$/.test(h) || h.endsWith('.localhost');
    return loopback ? u.href : null;
  }
  return null;
}

function hostOf(url) {
  try {
    return new URL(url).host.toLowerCase();
  } catch {
    return '';
  }
}

/**
 * Reduce anything found on disk to a session we are willing to act on.
 * Unknown keys are dropped rather than carried, and every URL is re-checked
 * through the same allowlist that wrote it — the file lives in userData, but
 * "we wrote it" is not the same as "it is still ours."
 */
function sanitizeSession(raw) {
  if (!raw || typeof raw !== 'object' || raw.version !== VERSION) return null;
  const tabs = [];
  const seen = new Set();
  for (const t of Array.isArray(raw.tabs) ? raw.tabs : []) {
    const url = restorableURL(t && typeof t === 'object' ? t.url : t);
    if (!url || seen.has(url)) continue;
    seen.add(url);
    tabs.push({
      url,
      title: typeof t.title === 'string' ? t.title.slice(0, 200) : '',
    });
    if (tabs.length >= MAX_TABS) break;
  }
  if (tabs.length === 0) return null;

  // Seat assignments are keyed by HOST, not by tab id: tab ids are handed out
  // fresh every launch, and one seat per host is already the law (seats.js),
  // so the host is the only stable name a seat has.
  const roles = new Set(['A', 'B', 'out']);
  const assign = {};
  if (raw.assign && typeof raw.assign === 'object') {
    for (const [host, role] of Object.entries(raw.assign)) {
      if (typeof host === 'string' && host && roles.has(role)) assign[host] = role;
    }
  }
  const assigned = new Set(Object.keys(assign));
  const order = Array.isArray(raw.order) ? raw.order.filter((h) => assigned.has(h)) : [];
  const subjectHost = assigned.has(raw.subjectHost) ? raw.subjectHost : null;

  const activeUrl = tabs.some((t) => t.url === raw.activeUrl) ? raw.activeUrl : tabs[0].url;
  return {
    version: VERSION,
    savedAt: raw.savedAt || null,
    tabs,
    activeUrl,
    assign,
    order,
    subjectHost,
    // True when the last thing you did was empty the table. The list stays on
    // disk — emptying it is not the same as forgetting it — but a launch will
    // not reopen what you closed on purpose. The Resume button still offers it.
    closedAll: raw.closedAll === true,
  };
}

/**
 * What in the saved session is not open right now?
 *
 * Compared by HOST for web pages, because the seat rule is per host: if you
 * already have a tab on chatgpt.com, reopening the one you had is not a
 * second seat, it is a duplicate the rail would immediately block. So a
 * session counts as resumed for that site when any tab on that site is open.
 * Forge Flight's own pages are compared exactly — `forgeflight://local` and
 * `forgeflight://start` are different rooms.
 */
function missingFrom(session, openUrls) {
  if (!session) return [];
  const open = Array.isArray(openUrls) ? openUrls : [];
  const openHosts = new Set();
  const openExact = new Set();
  for (const u of open) {
    if (typeof u !== 'string') continue;
    if (/^forgeflight:/i.test(u)) openExact.add(u.toLowerCase());
    else openHosts.add(hostOf(u));
  }
  const missing = [];
  for (const t of session.tabs) {
    if (/^forgeflight:/i.test(t.url)) {
      if (!openExact.has(t.url.toLowerCase())) missing.push(t);
    } else if (!openHosts.has(hostOf(t.url))) {
      missing.push(t);
    }
  }
  return missing;
}

class SessionStore {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'session.json');
    this.corrupt = 0;
    this.session = this.load();
  }

  /** Read the file. A missing, unreadable or malformed file is a first run. */
  load() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      const s = sanitizeSession(parsed);
      if (!s) this.corrupt++;
      return s;
    } catch {
      return null;
    }
  }

  /** Write the whole session. A failure to persist is never worth crashing over. */
  save(session) {
    const s = sanitizeSession(session);
    if (!s) return false;
    try {
      fs.mkdirSync(this.dir, { recursive: true });
      const tmp = `${this.file}.tmp`;
      // Write-then-rename: a quit that lands mid-write leaves the old session
      // intact instead of half of a new one.
      fs.writeFileSync(tmp, JSON.stringify(s, null, 2), 'utf8');
      fs.renameSync(tmp, this.file);
      this.session = s;
      return true;
    } catch {
      return false;
    }
  }

  /** Forget the session — used when the last tab is closed on purpose. */
  clear() {
    this.session = null;
    try {
      fs.rmSync(this.file, { force: true });
    } catch {
      /* nothing to forget */
    }
  }

  get() {
    return this.session;
  }
}

module.exports = { SessionStore, sanitizeSession, restorableURL, missingFrom, hostOf, MAX_TABS, VERSION };
