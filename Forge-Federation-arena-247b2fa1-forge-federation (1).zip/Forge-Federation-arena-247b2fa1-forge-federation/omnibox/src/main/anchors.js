/**
 * anchors.js — the engine-training record: an append-only log of anchor
 * choices, their losers, their outcomes, and human rulings.
 *
 * This is NOT the Memory Passport and must never become it. The passport
 * holds claims about the world, adjudicated under C1–C4; this file holds
 * observations about pages — which anchor Forge Flight acted on, what else it
 * could have chosen, whether the world responded, and when a person
 * overruled it. Mixing the two muddies both stores: a page observation is
 * not knowledge, and knowledge does not need a bounding box.
 *
 * The pipe rule, enforced rather than hoped for: anchors and outcomes only,
 * never conversation content. `sanitize()` strips any field whose name says
 * it could carry human or model text — prompt, reply, text, content — at any
 * depth, before anything is written. A record that arrives carrying a prompt
 * loses the prompt and keeps everything else; the log records that it did so.
 *
 * Same persistence posture as the passport (D10, D17): newline-delimited JSON,
 * append-only, hash-chained, human-readable, greppable, recoverable. A torn
 * final line is dropped on load and counted, not crashed on. A break in the
 * chain is reported, never hidden — the teacher refuses to learn from it.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { CHAIN_GENESIS, chainHash, verifyFile } = require('./chain.js');

/** The hashed body is the record without chain fields. Type stays at the
 *  top level so the teacher and scorer keep reading `rec.type` as they do. */
function bodyOf(rec) {
  const { prev, hash, ...body } = rec || {};
  return body;
}

function verifyAnchorLog(logPath) {
  return verifyFile(logPath, bodyOf);
}

/** Field names that can never cross into the oracle store. Matched on the
 *  KEY, at any depth, so a rename upstream cannot quietly reopen the pipe. */
const DENY_KEY = /^(prompt|prompts|reply|replies|text|texts|content|body|message|sent|chunks?|answer|answers|draft)$/i;

/** Cap any string that IS allowed: labels, placeholders, classes — page
 *  furniture, bounded so a hostile page cannot use them as a channel. */
const MAX_STRING = 160;

function sanitize(value, dropped) {
  if (Array.isArray(value)) return value.map((v) => sanitize(v, dropped));
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (DENY_KEY.test(k)) {
        dropped.push(k);
        continue;
      }
      out[k] = sanitize(v, dropped);
    }
    return out;
  }
  if (typeof value === 'string') return value.slice(0, MAX_STRING);
  return value;
}

class AnchorLog {
  constructor(dir) {
    this.dir = dir;
    this.logPath = path.join(dir, 'anchors.jsonl');
    this.corrupt = 0;
    this.droppedFields = 0;
    this.records = 0;
    this.head = CHAIN_GENESIS;
    this.chain = { head: CHAIN_GENESIS, chained: 0, legacy: 0, breaks: [], torn: false, ok: true };
    // tabId -> { url, status, verdictReason, winnerKey, confidence, margin }
    this.lastVerdict = new Map();
    this._refreshChain();
  }

  _refreshChain() {
    this.chain = verifyAnchorLog(this.logPath);
    this.head = this.chain.head;
  }

  /** The only write path to disk. Append-only; never rewrites a line. */
  append(rec) {
    const dropped = [];
    const clean = sanitize(rec, dropped);
    this.droppedFields += dropped.length;
    const payload = { at: new Date().toISOString(), ...clean };
    const prev = this.head;
    const hash = chainHash(prev, payload);
    fs.mkdirSync(this.dir, { recursive: true });
    fs.appendFileSync(this.logPath, JSON.stringify({ ...payload, prev, hash }) + '\n');
    this.head = hash;
    this.chain.head = hash;
    this.chain.chained += 1;
    this.records += 1;
    return { dropped };
  }

  verify() {
    const v = verifyAnchorLog(this.logPath);
    this.chain = v;
    this.head = v.head;
    return v;
  }

  /** Count lines without parsing the whole history into memory. */
  count() {
    if (!fs.existsSync(this.logPath)) return 0;
    let n = 0;
    for (const line of fs.readFileSync(this.logPath, 'utf8').split('\n')) {
      if (line.trim()) {
        try {
          JSON.parse(line);
          n++;
        } catch {
          this.corrupt++;
        }
      }
    }
    return n;
  }

  // ------------------------------------------------------------------ verdicts

  /**
   * A seat verdict, success or refusal. `stamp` fields arrive from the
   * renderer already stamped; this only trims to what the record needs.
   * Repeated identical verdicts from mutation re-detects are deduped per
   * tab: the log records changes, not churn.
   */
  verdict({ tabId, url, trigger, payload }) {
    const v = payload || {};
    const winner = v.anchor || null;
    const winnerKey = winner ? winner.stabilityKey : null;
    const prev = this.lastVerdict.get(tabId) || null;

    const changed =
      !prev ||
      prev.url !== url ||
      prev.status !== v.status ||
      prev.verdictReason !== (v.verdictReason || null) ||
      prev.winnerKey !== winnerKey ||
      !!v.manual !== !!prev.manual;

    // A before/after pair: same URL, a different winner or a flipped verdict
    // — a real mutation with a known-good before-state. This is the free
    // adversarial corpus nobody had to write.
    if (prev && prev.url === url && (prev.winnerKey !== winnerKey || prev.status !== v.status)) {
      this.append({
        type: 'anchor-change',
        url,
        trigger,
        before: { status: prev.status, verdictReason: prev.verdictReason, winnerKey: prev.winnerKey, confidence: prev.confidence, margin: prev.margin },
        after: { status: v.status, verdictReason: v.verdictReason || null, winnerKey, confidence: v.confidence || 0, margin: v.margin || 0 },
      });
    }

    this.lastVerdict.set(tabId, {
      url,
      status: v.status,
      verdictReason: v.verdictReason || null,
      winnerKey,
      confidence: v.confidence || 0,
      margin: v.margin || 0,
      manual: !!v.manual,
    });

    if (!changed) return false;
    this.append({
      type: 'verdict',
      url,
      trigger,
      status: v.status,
      verdictReason: v.verdictReason || null,
      manual: !!v.manual,
      confidence: v.confidence || 0,
      margin: v.margin || 0,
      tiedOn: v.tiedOn || [],
      lessonApplied: v.lessonApplied || null,
      winner,
      losers: (v.candidates || []).filter((c) => !winnerKey || c.stabilityKey !== winnerKey),
    });
    return true;
  }

  /** A step outcome: did the world respond, and with what named result.
   *  Carries the anchor's stability key so the engine can join outcome to
   *  anchor. Never the prompt, never the reply. */
  outcome({ url, runId, round, role, seatName, anchorKey, result }) {
    const r = result || {};
    this.append({
      type: 'outcome',
      url,
      runId,
      round: round || null,
      role: role || null,
      seatName: seatName || null,
      anchorKey: anchorKey || null,
      ok: !!r.ok,
      reason: r.ok ? (r.reason || 'settled') : r.reason || 'refused',
      strategy: r.strategy || null,
      via: r.via || null,
      elapsedMs: Number.isFinite(r.elapsedMs) ? Math.round(r.elapsedMs) : null,
    });
  }

  /** A human pointed at the right box by hand — a ruling on a live page. */
  pick({ url, payload }) {
    const p = payload || {};
    this.append({
      type: 'pick',
      url,
      ok: !!p.ok,
      stamp: p.stamp || null,
    });
  }

  /**
   * A pilot step: what the pilot tried and whether the world accepted it.
   * The verb is recorded (`click`), the target is not (no selectors, no
   * typed text, no page words) — exactly like every other record here, this
   * is behaviour evidence for training, never a transcript of the page.
   */
  pilotStep({ url, pilot, step, verb, ok, reason }) {
    this.append({
      type: 'pilot-step',
      url,
      pilot: pilot || null,
      step: typeof step === 'number' ? step : null,
      verb: verb || null,
      ok: !!ok,
      reason: reason || null,
    });
  }

  /**
   * A human ruling on a SEATED anchor: "this box is right" / "wrong box",
   * pressed in the seat sheet. Unlike `pick`, this does not name a
   * replacement — it judges the anchor Forge Flight already claimed, which is
   * what makes it the oracle for the confidently-wrong rate: the claim and
   * the ruling join on `anchorKey`, and only the person looking at the page
   * can write one.
   *
   * Returns false (and writes nothing joinable) when there is no anchor key
   * to judge — a ruling on nothing is not a ruling.
   */
  confirm({ url, anchorKey, confirmed, source }) {
    const key = typeof anchorKey === 'string' && anchorKey ? anchorKey : null;
    if (!key) return false;
    this.append({
      type: 'confirm',
      url: url || null,
      anchorKey: key,
      confirmed: !!confirmed,
      source: source || 'sheet',
    });
    return true;
  }
}

module.exports = { AnchorLog, sanitize, DENY_KEY, verifyAnchorLog, bodyOf, CHAIN_GENESIS, chainHash };
