/**
 * tabs.js — real browser tabs.
 *
 * Forge Flight IS the browser. Each tab is a Chromium WebContentsView living in
 * one shared persistent session, so a login is a login: you sign in once,
 * it sticks across restarts, and the provider sees an ordinary browser.
 * There is no extension, no bridge to a second browser, and no credential
 * ever touches Forge Flight's own storage.
 */

'use strict';

const path = require('node:path');

/**
 * Electron is required lazily, not at module load.
 *
 * `toURL` and every ordering rule in TabManager are plain JavaScript that
 * needs no browser, but a top-level `require('electron')` made this module
 * unloadable outside a packaged run — which is why `test/table.test.js`
 * could not even be imported under `node --test`, and why the shape tests,
 * the one-seat-per-host rule and the address-bar tests silently did not run.
 * The dependency is real where it is real (constructing a WebContentsView,
 * opening an external link, tearing a tab into its own window) and is
 * stated there instead. Line 270 already did exactly this for BrowserWindow.
 */
let _electron = null;
function electron() {
  if (!_electron) _electron = require('electron');
  return _electron;
}

const SEAT_PRELOAD = path.join(__dirname, '..', 'preload', 'seat.js');
// The local-model seat needs the seat machinery PLUS its narrow localhost
// bridge; one preload per webContents means it gets a wrapper that is both.
const LOCAL_SEAT_PRELOAD = path.join(__dirname, '..', 'preload', 'localSeat.js');
const LOCAL_SEAT_URL_RE = /^forgeflight:\/\/local\/?$/i;
// The partition NAME is the cookie jar, and the cookie jar IS the user's
// logins. It keeps its original name across the Forge Flight rename on
// purpose: renaming it would silently sign everyone out of every provider.
// A Chromium partition name is never shown to a person or a page. See D26.
const PARTITION = 'persist:omnibox';

let nextId = 1;

class Tab {
  constructor(manager, { url }) {
    this.id = `t${nextId++}`;
    this.manager = manager;
    this.url = url || 'about:blank';
    this.title = 'New tab';
    this.favicon = null;
    this.loading = false;
    this.canGoBack = false;
    this.canGoForward = false;

    // Seat state — owned by SeatRegistry, mirrored here for the UI payload.
    this.seat = { status: 'unknown', detail: '', confidence: 0, signals: null, candidates: [] };

    // Torn-off state. A torn tab's view lives in its own BrowserWindow's
    // contentView instead of the main window's — it stays in this.tabs and
    // stays a seat (dispatch() and the Table never look at where a view is
    // mounted), it just is not laid out or shown by the main window anymore.
    this.torn = false;
    this.tornWin = null;

    const { WebContentsView } = electron();
    this.view = new WebContentsView({
      webPreferences: {
        // The local seat's page is ours; it gets the seat machinery plus
        // its localhost bridge. Every other page gets the plain seat
        // preload and exposes nothing to the page.
        preload: LOCAL_SEAT_URL_RE.test(this.url || '') ? LOCAL_SEAT_PRELOAD : SEAT_PRELOAD,
        partition: PARTITION,
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false, // the preload needs require(); the page still gets nothing
        webviewTag: false,
        spellcheck: true,
      },
    });
    this.view.setBackgroundColor('#0d1014');
    this.wc = this.view.webContents;
    this.wireEvents();
  }

  wireEvents() {
    const wc = this.wc;
    const push = () => this.manager.emitChanged(this);

    wc.on('page-title-updated', (_e, title) => {
      this.title = title;
      push();
    });
    wc.on('page-favicon-updated', (_e, icons) => {
      this.favicon = icons && icons[0] ? icons[0] : null;
      push();
    });
    wc.on('did-start-loading', () => {
      this.loading = true;
      push();
    });
    wc.on('did-stop-loading', () => {
      this.loading = false;
      this.syncNav();
      // The places you went, for the address bar. URL + title only.
      if (this.manager.onHistory && /^(https?|forgeflight):/i.test(this.url || '')) {
        try {
          this.manager.onHistory(this.url, this.title || '');
        } catch {
          /* history must never break a page */
        }
      }
      push();
    });
    wc.on('did-navigate', (_e, url) => {
      this.url = url;
      this.seat = { status: 'unknown', detail: 'Looking at this page…', confidence: 0, signals: null, candidates: [] };
      this.syncNav();
      push();
    });
    wc.on('did-navigate-in-page', (_e, url, isMain) => {
      if (!isMain) return;
      this.url = url;
      this.syncNav();
      push();
    });
    wc.on('did-fail-load', (_e, code, desc, url, isMain) => {
      if (!isMain || code === -3) return; // -3 is a user abort
      this.loading = false;
      this.loadError = { code, desc, url };
      push();
    });

    // A link that wants a new window becomes a new tab, like any browser.
    wc.setWindowOpenHandler(({ url, disposition }) => {
      if (disposition === 'save-to-disk') return { action: 'allow' };
      if (/^https?:/i.test(url)) {
        this.manager.open(url, { background: disposition === 'background-tab' });
      } else {
        electron().shell.openExternal(url).catch(() => {});
      }
      return { action: 'deny' };
    });

    // Never let a page navigate the chrome itself.
    wc.on('will-navigate', (e, url) => {
      if (!/^(https?|about|file|data):/i.test(url)) {
        e.preventDefault();
        electron().shell.openExternal(url).catch(() => {});
      }
    });
  }

  syncNav() {
    this.canGoBack = this.wc.navigationHistory ? this.wc.navigationHistory.canGoBack() : this.wc.canGoBack();
    this.canGoForward = this.wc.navigationHistory
      ? this.wc.navigationHistory.canGoForward()
      : this.wc.canGoForward();
  }

  toJSON() {
    return {
      id: this.id,
      url: this.url,
      title: this.title || this.url,
      favicon: this.favicon,
      loading: this.loading,
      canGoBack: this.canGoBack,
      canGoForward: this.canGoForward,
      seat: this.seat,
      loadError: this.loadError || null,
      torn: !!this.torn,
    };
  }

  destroy() {
    try {
      this.wc.close();
    } catch {
      /* already gone */
    }
  }
}

class TabManager {
  constructor(win, onChange, onHistory) {
    this.win = win;
    this.onChange = onChange;
    this.onHistory = onHistory || null;
    this.tabs = [];
    this.activeId = null;
    // No box until the chrome says where the hole is. A page view that shows
    // before the viewport arrives would cover the seat rail and the dock.
    this.bounds = { x: 0, y: 0, width: 0, height: 0 };
    this.pageVisible = true;
    // Whether this launch has signed in. Until it has, no page view is
    // mounted at all: a native WebContentsView sits ABOVE the window's HTML,
    // so even an empty start page would cover the sign-in card and eat its
    // clicks. Main flips this on the operator:signin handshake.
    this.signedIn = false;
  }

  emitChanged() {
    if (this.onChange) this.onChange();
  }

  get active() {
    return this.tabs.find((t) => t.id === this.activeId) || null;
  }

  byId(id) {
    return this.tabs.find((t) => t.id === id) || null;
  }

  /** This launch signed in — the gate is down, pages may mount. */
  setSignedIn(v) {
    v = !!v;
    if (this.signedIn === v) return;
    this.signedIn = v;
    this.layout();
    this.emitChanged();
  }

  /**
   * Open a tab. Refused while the launch has not signed in: the caller gets
   * null and nothing is constructed, added, or loaded — not even a 0x0 view,
   * because a hidden view can still load a URL and touch the profile.
   */
  open(url, { background = false } = {}) {
    if (!this.signedIn) return null;
    const tab = new Tab(this, { url });
    this.tabs.push(tab);
    this.win.contentView.addChildView(tab.view);
    tab.view.setBounds({ x: 0, y: 0, width: 0, height: 0 }); // hidden until activated
    if (url && url !== 'about:blank') tab.wc.loadURL(url).catch(() => {});
    if (!background || !this.activeId) this.activate(tab.id);
    this.emitChanged();
    return tab;
  }

  activate(id) {
    const tab = this.byId(id);
    if (!tab) return;
    if (tab.torn) {
      // A torn tab lives in its own window — bring that window forward
      // instead of trying to seat it in the main content view.
      if (tab.tornWin && !tab.tornWin.isDestroyed()) tab.tornWin.focus();
      return;
    }
    this.activeId = id;
    this.layout();
    this.emitChanged();
  }

  /**
   * Reopen a saved session.
   *
   * Tabs open in the background: resuming eight AI chats should put the one
   * you were looking at in front, not strobe eight pages past you. Each page
   * loads into the same persistent partition it loaded into last time, so the
   * logins are already there — this is opening doors, not signing in.
   *
   * @param {Array<string|{url:string}>} entries
   * @param {{activeUrl?:string}} [opts]
   * @returns {Tab[]}
   */
  restore(entries, { activeUrl } = {}) {
    const opened = [];
    for (const entry of Array.isArray(entries) ? entries : []) {
      const url = typeof entry === 'string' ? entry : entry && entry.url;
      if (!url) continue;
      const t = this.open(url, { background: true });
      if (t) opened.push(t); // open() refuses while this launch is gated
    }
    const wanted = opened.find((t) => t.url === activeUrl) || opened[opened.length - 1];
    if (wanted) this.activate(wanted.id);
    this.emitChanged();
    return opened;
  }

  close(id) {
    const i = this.tabs.findIndex((t) => t.id === id);
    if (i === -1) return;
    const [tab] = this.tabs.splice(i, 1);
    const host = tab.torn && tab.tornWin && !tab.tornWin.isDestroyed() ? tab.tornWin : this.win;
    try {
      host.contentView.removeChildView(tab.view);
    } catch {
      /* view may already be detached */
    }
    if (tab.torn && tab.tornWin && !tab.tornWin.isDestroyed()) {
      tab.tornWin.removeAllListeners('closed');
      tab.tornWin.destroy();
    }
    tab.torn = false;
    tab.tornWin = null;
    tab.destroy();
    if (this.activeId === id) {
      const next = this.tabs[Math.min(i, this.tabs.length - 1)];
      this.activeId = next ? next.id : null;
    }
    this.layout();
    this.emitChanged();
  }

  setBounds(b) {
    this.bounds = { ...this.bounds, ...b };
    this.layout();
  }

  /**
   * Tear a tab off into its own window. The tab stays a seat — it stays in
   * this.tabs and dispatch()/the Table never check where a view is mounted —
   * it just is not driven by the main window's layout anymore.
   */
  tearOff(id) {
    const tab = this.byId(id);
    if (!tab || tab.torn) return null;
    const { BrowserWindow } = require('electron');
    const wasActive = this.activeId === id;

    try {
      this.win.contentView.removeChildView(tab.view);
    } catch {
      /* already detached */
    }

    const popped = new BrowserWindow({
      width: 1000,
      height: 720,
      title: tab.title || tab.url || 'Forge Flight seat',
      backgroundColor: '#0d1014',
    });
    popped.contentView.addChildView(tab.view);
    const resize = () => {
      if (tab.view.setBounds) {
        const b = popped.getContentBounds();
        tab.view.setBounds({ x: 0, y: 0, width: b.width, height: b.height });
      }
    };
    resize();
    popped.on('resize', resize);
    popped.once('closed', () => {
      if (!this.tabs.includes(tab)) return; // closed via tabs.close(), not the window chrome
      tab.torn = false;
      tab.tornWin = null;
      try {
        this.win.contentView.addChildView(tab.view);
      } catch {
        /* main window may itself be gone */
      }
      if (!this.activeId) this.activeId = tab.id;
      this.layout();
      this.emitChanged();
    });

    tab.torn = true;
    tab.tornWin = popped;

    if (wasActive) {
      const next = this.tabs.find((t) => t.id !== id && !t.torn);
      this.activeId = next ? next.id : null;
    }
    this.layout();
    this.emitChanged();
    return tab;
  }

  /** Bring a torn-off tab back into the main window and close its window. */
  dock(id) {
    const tab = this.byId(id);
    if (!tab || !tab.torn) return null;
    const popped = tab.tornWin;
    tab.torn = false;
    tab.tornWin = null;
    if (popped && !popped.isDestroyed()) {
      try {
        popped.contentView.removeChildView(tab.view);
      } catch {
        /* already detached */
      }
      popped.removeAllListeners('closed');
      popped.destroy();
    }
    try {
      this.win.contentView.addChildView(tab.view);
    } catch {
      /* already attached */
    }
    this.activate(tab.id);
    this.emitChanged();
    return tab;
  }

  /** Table view hides the page without unloading it — the seat keeps working. */
  setPageVisible(v) {
    this.pageVisible = !!v;
    this.layout();
  }

  /**
   * Lay the views out — and give an UNJUDGED background tab a real box.
   *
   * Every signal the detector uses is a layout fact: area, distance from the
   * bottom of the viewport, horizontal centrality. Chromium does not lay out
   * a view parked at 0x0, so those all read zero, every candidate scores
   * below the floor, and the tab can never take a seat.
   *
   * That is invisible when you open tabs one at a time — each is active as it
   * opens — and it is exactly what breaks a session restore, which opens
   * every tab in the background at once. Only the last one, the one that got
   * activated, ever seated.
   *
   * So a tab that has not yet produced a verdict gets the SAME box as the
   * active tab, and the active tab is raised above it in z-order by re-adding
   * its view. Once the tab has a verdict it is parked at 0x0 like any other
   * background tab, because it no longer needs to be measured. Off-screen
   * positioning was tried first and does not work — Chromium skips layout for
   * those too.
   *
   * The page is only ever ON SCREEN when this launch has signed in AND the
   * browse pane is showing AND the chrome has reported a real box. While the
   * sign-in gate is up — or the table/memory/carrier pane is showing — every
   * view stays at 0x0 and invisible, even an unjudged one. A view with a real
   * box and `visible` set sits ABOVE the window's HTML in its bounds and wins
   * hit-testing there, which is exactly the bug where the chrome was visible
   * but nothing could be clicked: measuring must never turn a hidden page
   * into a native lid over the chrome.
   */
  layout() {
    const { x, y, width, height } = this.bounds;
    const real = { x: Math.round(x), y: Math.round(y), width: Math.round(width), height: Math.round(height) };
    const zero = { x: 0, y: 0, width: 0, height: 0 };
    const pageOn = this.pageVisible && this.signedIn;
    const measurable = pageOn && real.width > 0 && real.height > 0;

    let measuring = 0;
    for (const t of this.tabs) {
      if (t.torn) continue; // its own window owns its bounds now
      const on = pageOn && t.id === this.activeId;
      const needsMeasuring = !on && measurable && this.awaitingVerdict(t);
      if (needsMeasuring) measuring++;
      t.view.setBounds(on || needsMeasuring ? real : zero);
      // A measuring tab must be laid out, not shown. It sits under the active
      // tab; setVisible(false) would take its layout away again.
      t.view.setVisible?.(on || needsMeasuring);
    }

    // Raise the active tab above anything being measured underneath it.
    //
    // ONLY when something is actually being measured. layout() runs on an
    // undebounced ResizeObserver, so it fires every frame of a window drag;
    // detaching and re-attaching a live WebContentsView at frame rate is a
    // repaint hitch you can see. In the steady state — every tab judged —
    // there is nothing underneath to be above, so this does not run at all.
    if (measuring && pageOn) {
      const active = this.byId(this.activeId);
      if (active) {
        try {
          this.win.contentView.removeChildView(active.view);
          this.win.contentView.addChildView(active.view);
        } catch {
          /* a view mid-teardown is not worth failing layout over */
        }
      }
    }
  }

  /** Has this tab said anything about itself yet? A tab still looking at its
   *  page needs a real box; one that has ruled does not. */
  awaitingVerdict(tab) {
    const status = tab && tab.seat && tab.seat.status;
    return !status || status === 'unknown';
  }

  navigate(id, input) {
    const tab = this.byId(id);
    if (!tab) return;
    tab.wc.loadURL(toURL(input)).catch(() => {});
  }

  back(id) {
    const t = this.byId(id);
    if (!t) return;
    t.wc.navigationHistory ? t.wc.navigationHistory.goBack() : t.wc.goBack();
  }

  forward(id) {
    const t = this.byId(id);
    if (!t) return;
    t.wc.navigationHistory ? t.wc.navigationHistory.goForward() : t.wc.goForward();
  }

  reload(id) {
    const t = this.byId(id);
    if (t) t.wc.reload();
  }

  toJSON() {
    return { tabs: this.tabs.map((t) => t.toJSON()), activeId: this.activeId, pageVisible: this.pageVisible };
  }
}

/** Address-bar input to a URL. A bare word is a search, a host is a host. */
function toURL(input) {
  const s = String(input || '').trim();
  if (!s) return 'about:blank';
  if (/^[a-z]+:\/\//i.test(s) || /^(about|data|file):/i.test(s)) return s;
  const looksLikeHost = /^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/i.test(s) || /^localhost(:\d+)?(\/.*)?$/i.test(s);
  if (looksLikeHost) return `https://${s}`;
  return `https://duckduckgo.com/?q=${encodeURIComponent(s)}`;
}

module.exports = { TabManager, Tab, toURL, PARTITION };
