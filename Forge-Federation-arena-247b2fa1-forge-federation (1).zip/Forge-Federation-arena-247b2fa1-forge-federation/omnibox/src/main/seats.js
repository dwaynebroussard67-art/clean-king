/**
 * seats.js — who is at the table.
 *
 * A seat is a tab that Forge Flight has identified as a chat surface. There is no
 * provider list in this file, no allowlist, and no API key. The rule that
 * decides whether a tab may be seated is structural, not commercial:
 *
 *   ONE SEAT PER HOST.
 *
 * Two tabs on the same site cannot both be seated. Forge Flight fans one prompt
 * across DIFFERENT services; it does not fan one prompt across several
 * accounts on one service, and the code — not a README — is what stops it.
 * The second tab is not broken, it is just not a seat, and the rail says why.
 *
 * Names stick per host, so renaming a seat once is renaming it forever.
 */

'use strict';

const fs = require('node:fs');
const path = require('node:path');

function hostOf(url) {
  try {
    return new URL(url).host.toLowerCase();
  } catch {
    return '';
  }
}

/** "chatgpt.com" -> "Chatgpt", "gemini.google.com" -> "Gemini", "x.ai" -> "X" */
function defaultName(host) {
  if (!host) return 'Seat';
  const bare = host.replace(/^www\./, '').split(':')[0];
  // An IP or a bare hostname has no brandable label — use it whole rather
  // than confidently naming a seat "127".
  if (/^\d+(\.\d+){3}$/.test(bare) || /^\[.*\]$/.test(bare) || !bare.includes('.')) {
    return bare.charAt(0).toUpperCase() + bare.slice(1);
  }
  const parts = bare.split('.');
  const known = new Set(['com', 'ai', 'io', 'app', 'dev', 'org', 'net', 'co', 'sh', 'me', 'chat', 'google', 'cloud']);
  const label = parts.find((p) => !known.has(p)) || parts[0];
  return label.charAt(0).toUpperCase() + label.slice(1);
}

class SeatRegistry {
  constructor(dir) {
    this.file = path.join(dir, 'seats.json');
    this.names = {}; // host -> name
    this.muted = {}; // host -> true (user said "never seat this site")
    this.load();
  }

  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.names = raw.names || {};
      this.muted = raw.muted || {};
    } catch {
      /* first run */
    }
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify({ names: this.names, muted: this.muted }, null, 2));
    } catch {
      /* a name that fails to persist is not worth crashing over */
    }
  }

  nameFor(host) {
    return this.names[host] || defaultName(host);
  }

  rename(host, name) {
    const n = String(name || '').trim().slice(0, 32);
    if (n) this.names[host] = n;
    else delete this.names[host];
    this.save();
  }

  setMuted(host, muted) {
    if (muted) this.muted[host] = true;
    else delete this.muted[host];
    this.save();
  }

  isMuted(host) {
    return !!this.muted[host];
  }

  /**
   * Decide the table from the current tab list. Pure function of tab state —
   * no hidden registry to drift out of sync with what is actually open.
   *
   * @param {Array} tabs  tab.toJSON() shapes
   * @returns {{seats:Array, rail:Array}}
   */
  resolve(tabs) {
    const claimedHost = new Map(); // host -> tabId that holds the seat
    const rail = [];

    for (const t of tabs) {
      // Forge Flight's own start page is not a candidate seat, and showing it in
      // the rail as "not a chat" is noise the user can do nothing with.
      // The local-model seat is the one forgeflight:// page that IS a seat.
      if ((/^forgeflight:/i.test(t.url) && !/^forgeflight:\/\/local\/?$/i.test(t.url)) || t.url === 'about:blank') continue;
      const host = hostOf(t.url);
      const name = this.nameFor(host);
      const entry = {
        tabId: t.id,
        host,
        name,
        title: t.title,
        url: t.url,
        favicon: t.favicon,
        status: t.seat.status,
        reason: t.seat.reason || null,
        detail: t.seat.detail,
        confidence: t.seat.confidence || 0,
        signals: t.seat.signals || null,
        candidates: t.seat.candidates || [],
        tiedOn: t.seat.tiedOn || [],
        manual: !!t.seat.manual,
        restored: !!t.seat.restored,
        pickMissing: !!t.seat.pickMissing,
        confirmed: t.seat.confirmed || null,
        seated: false,
        blocked: null,
        torn: !!t.torn,
      };

      if (this.isMuted(host)) {
        entry.blocked = 'muted';
        entry.detail = 'You told Forge Flight not to seat this site.';
      } else if (t.seat.status === 'seated') {
        if (claimedHost.has(host)) {
          entry.blocked = 'duplicate-host';
          entry.detail = `Another tab on ${host} already holds this seat. Forge Flight seats one tab per site.`;
        } else {
          claimedHost.set(host, t.id);
          entry.seated = true;
        }
      }
      rail.push(entry);
    }

    return { rail, seats: rail.filter((r) => r.seated) };
  }
}

module.exports = { SeatRegistry, hostOf, defaultName };
