/**
 * chain.js — D17's hash chain, extracted so anchors.jsonl and diary.jsonl
 * use the same algorithm the passport already ships.
 *
 * Every chained line carries `prev` (the hash of the line before it) and
 * `hash` (of its body, including `prev`). Editing, deleting, or splicing
 * the log after the fact is detectable by recomputation. A break is
 * REPORTED, never a crash.
 *
 * Body hashing is `sha256(prev + NUL + JSON.stringify(body))` — the
 * passport's construction-order stringify, not `JSON.stringify(obj,
 * Object.keys(obj).sort())`, which is a replacer allowlist at every
 * depth and would collapse nested payloads into identical hashes.
 *
 * Legacy lines (no prev, no hash) load as they always did. A torn final
 * line is dropped, not a break. A break in the middle is a break.
 */
'use strict';

const fs = require('node:fs');
const crypto = require('node:crypto');

const CHAIN_GENESIS = '0'.repeat(64);

function sha256(s) {
  return crypto.createHash('sha256').update(String(s), 'utf8').digest('hex');
}

function chainHash(prev, body) {
  return sha256(`${prev}\u0000${JSON.stringify(body)}`);
}

/**
 * @param {string} logPath
 * @param {(rec: object) => object} bodyOf  the object that was hashed
 * @returns {{ ok: boolean, head: string, chained: number, legacy: number,
 *             breaks: Array, torn: boolean }}
 */
function verifyFile(logPath, bodyOf) {
  const out = {
    ok: true,
    head: CHAIN_GENESIS,
    chained: 0,
    legacy: 0,
    breaks: [],
    torn: false,
  };
  if (!fs.existsSync(logPath)) return out;
  const lines = fs.readFileSync(logPath, 'utf8').split('\n');
  let expectedPrev = null;
  let sawChained = false;
  let idx = 0;
  for (let i = 0; i < lines.length; i++) {
    const s = lines[i].trim();
    if (!s) continue;
    idx++;
    let rec;
    try {
      rec = JSON.parse(s);
    } catch {
      const restEmpty = lines.slice(i + 1).every((l) => !String(l).trim());
      if (restEmpty) {
        out.torn = true;
        break;
      }
      out.breaks.push({ line: idx, kind: 'unparseable' });
      continue;
    }
    if (rec.hash === undefined && rec.prev === undefined) {
      if (sawChained) out.breaks.push({ line: idx, kind: 'legacy-after-chained' });
      else out.legacy++;
      continue;
    }
    sawChained = true;
    const wantPrev = expectedPrev === null ? CHAIN_GENESIS : expectedPrev;
    if (rec.prev !== wantPrev) {
      out.breaks.push({ line: idx, kind: 'prev-mismatch', expected: wantPrev, found: rec.prev });
    }
    const body = bodyOf(rec);
    const wantHash = chainHash(rec.prev === undefined ? wantPrev : rec.prev, body);
    if (rec.hash !== wantHash) {
      out.breaks.push({ line: idx, kind: 'hash-mismatch', expected: wantHash, found: rec.hash });
    }
    out.chained++;
    expectedPrev = rec.hash;
    out.head = rec.hash;
  }
  out.ok = out.breaks.length === 0;
  return out;
}

module.exports = { CHAIN_GENESIS, sha256, chainHash, verifyFile };
