/**
 * witness-plumbing.test.mjs — pilot cannot forge, plumbing can mint, gate enforces.
 *
 * The property this file exists to make true:
 *   A pilot-supplied witness is never trusted. The only witness the gate sees
 *   is one the harness plumbing minted from its own harnessId and its own ids.
 */

import assert from 'node:assert/strict'
import { createPlumbingWitness } from './witness.ts'
import { admit } from './gate.ts'
import { Collective } from './store.ts'
import { HarnessRuntime, InMemoryMissionStore } from '../harness/runtime.ts'
import { CapabilityRegistry } from '../harness/capabilities.ts'

let passed = 0, failed = 0
const failures = []
function test(name, fn) {
  try { fn(); passed++ }
  catch (e) { failed++; failures.push({ name, message: e?.stack ?? String(e) }) }
}
async function asyncTest(name, fn) {
  try { await fn(); passed++ }
  catch (e) { failed++; failures.push({ name, message: e?.stack ?? String(e) }) }
}

const baseWitness = (over = {}) => ({
  kind: 'outcome',
  reference: 'req_01H8XK4M2P',
  harnessId: 'harness-alpha',
  observedAt: '2026-08-17T04:00:00.000Z',
  ...over,
})
const baseFact = (over = {}) => ({
  subject: 'endpoint:api.example.com/v1/charges',
  predicate: 'accepts_field',
  value: 'amount',
  witness: baseWitness(),
  stability: 'contingent',
  ...over,
})

// ── Witness factory ───────────────────────────────────────────────────────
test('plumbing mints a valid outcome witness from harnessId + tool ids', () => {
  const w = createPlumbingWitness({ kind: 'outcome', harnessId: 'harness-xyz', reference: 'mission-1:req_abc', observedAt: '2026-08-19T00:00:00.000Z' })
  assert.equal(w.harnessId, 'harness-xyz')
  assert.equal(w.kind, 'outcome')
})

test('plumbing rejects empty reference — fabricated witness', () => {
  assert.throws(() => createPlumbingWitness({ kind: 'outcome', harnessId: 'h', reference: '' }), /WITNESS_REFERENCE_INVALID/)
})

test('plumbing rejects too-short reference', () => {
  assert.throws(() => createPlumbingWitness({ kind: 'outcome', harnessId: 'h', reference: 'ab' }), /WITNESS_REFERENCE_INVALID/)
})

test('contract witness requires a URL — plain string is not a contract', () => {
  assert.throws(() => createPlumbingWitness({ kind: 'contract', harnessId: 'h', reference: 'not-a-url' }), /must be a URL/)
  const w = createPlumbingWitness({ kind: 'contract', harnessId: 'h', reference: 'https://api.stripe.com/docs/charges' })
  assert.equal(w.kind, 'contract')
})

test('human witness must name a person — 12345 is not a person', () => {
  assert.throws(() => createPlumbingWitness({ kind: 'human', harnessId: 'h', reference: '12345' }), /must name a person/)
  const w = createPlumbingWitness({ kind: 'human', harnessId: 'h', reference: 'Dwayne Broussard' })
  assert.equal(w.reference, 'Dwayne Broussard')
})

test('structural witness accepts hash_ prefix', () => {
  const w = createPlumbingWitness({ kind: 'structural', harnessId: 'h', reference: 'hash_abc123' })
  assert.equal(w.kind, 'structural')
})

// ── Gate enforces plumbing witness ───────────────────────────────────────
test('gate refuses a pilot-submitted fact with empty witness reference', () => {
  const c = new Collective()
  const v = admit(baseFact({ witness: baseWitness({ reference: '' }) }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'UNWITNESSED')
})

test('gate refuses a well-formed lie with no witness at all', () => {
  const c = new Collective()
  const v = admit({ ...baseFact(), witness: undefined }, c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'UNWITNESSED')
})

test('gate admits a plumbing-minted witness', () => {
  const c = new Collective()
  const w = createPlumbingWitness({ kind: 'outcome', harnessId: 'harness-plumbing', reference: 'req_plumbing_1' })
  const v = admit(baseFact({ witness: w }), c)
  assert.equal(v.status, 'admitted')
})

test('2+1=4 is refused before it ever meets the store — self-inconsistent', () => {
  const c = new Collective()
  const w = createPlumbingWitness({ kind: 'outcome', harnessId: 'h', reference: 'req_test' })
  const v = admit(baseFact({ predicate: 'rate_limit_per_min', value: -5, witness: w }), c)
  assert.equal(v.status, 'refused')
  assert.equal(v.reason, 'SELF_INCONSISTENT')
})

test('consistent but unfounded new field — passes witness, passes consistency, is admitted (witness alone does not prove truth)', () => {
  // This is the "well-formed lie that contradicts nothing" — the gate's second choke point
  // is the witness, not truth. A new fact that contradicts nothing and carries a valid
  // plumbing witness IS admitted. That's correct — the defense against unfounded but
  // consistent facts is not the gate, it's that the plumbing only mints witnesses for
  // actions that actually happened (HTTP 200, DOM hash). A pilot that invents a fact
  // invents it without a plumbing witness, so it never reaches the gate with one.
  const c = new Collective()
  const w = createPlumbingWitness({ kind: 'outcome', harnessId: 'h', reference: 'req_real_action_42' })
  const v = admit(baseFact({ subject: 'endpoint:api.new.com/v1/new', value: 'new_field', witness: w }), c)
  assert.equal(v.status, 'admitted')
})

// ── Harness plumbing integration ─────────────────────────────────────────
await asyncTest('harness plumbing mints witness on tool execution — pilot never supplies it', async () => {
  const store = new InMemoryMissionStore()
  const harnessId = 'harness-test-plumbing'
  const runtime = new HarnessRuntime({
    store,
    harnessId,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
  })
  // Mount a trivial tool so executeAuthorized has something to run
  runtime.mount({
    id: 'test.echo',
    name: 'echo',
    description: 'echo',
    version: '1.0.0',
    tools: [{
      descriptor: { id: 'test.echo', name: 'echo', description: 'echo', risk: 'read', inputSchema: { type: 'object', properties: {}, additionalProperties: false }, requiresApproval: false },
      implementation: async (args) => ({ echoed: args }),
    }],
  })
  const mission = await runtime.createMission({
    goal: 'test witness plumbing',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['test.echo'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await runtime.bindNeuralink(mission.id)
  await runtime.beginPlanning(mission.id)

  // Pilot asks via handle — handle takes only args, no witness param exists
  const handles = await runtime.handlesFor(mission.id)
  const echoHandle = handles.find(h => h.capabilityId === 'test.echo')
  assert.ok(echoHandle, 'pilot handle not found')
  // Verify handle shape: invoke takes args only
  assert.equal(echoHandle.invoke.length, 1, 'handle.invoke must take only args — witness is not a pilot param')

  const result = await echoHandle.invoke({}) // no witness supplied — plumbing creates it
  assert.equal(result.status, 'succeeded')

  // The event spine must contain a plumbing witness with the harness's own id
  const events = await store.listEvents(mission.id)
  const invoked = events.find(e => e.type === 'tool_invoked')
  assert.ok(invoked, 'no tool_invoked event')
  const witness = invoked.payload.witness
  assert.ok(witness, 'no witness on tool_invoked — plumbing did not mint')
  assert.equal(witness.harnessId, harnessId, 'witness harnessId is not the plumbing harnessId — pilot forged?')
  assert.equal(witness.kind, 'outcome')
  assert.ok(witness.reference.includes(mission.id) && witness.reference.includes(String(invoked.payload.toolCallId)), 'witness reference must be plumbing ids, not pilot text')
  assert.equal(result.witness.harnessId, harnessId, 'result witness must match plumbing')
})

await asyncTest('50 forged pilots cannot bypass witness format — gate still refuses', async () => {
  const c = new Collective()
  // Admit a real fact via plumbing
  const realWitness = createPlumbingWitness({ kind: 'outcome', harnessId: 'real-harness', reference: 'req_real_1' })
  admit(baseFact({ subject: 'endpoint:quarantine.test/v1', predicate: 'accepts_field', value: 'field_a', witness: realWitness }), c)
  // 50 forged attempts with pilot-like references (too short / wrong kind)
  let admitted = 0
  for (let i = 0; i < 50; i++) {
    const forgedRef = i % 2 === 0 ? '' : 'ab' // empty or too short — fabricated
    try {
      const w = createPlumbingWitness({ kind: 'outcome', harnessId: `forged-${i}`, reference: forgedRef })
      const v = admit(baseFact({ subject: 'endpoint:quarantine.test/v1', predicate: 'accepts_field', value: `field_b_${i}`, witness: w }), c)
      if (v.status === 'admitted') admitted++
    } catch {
      // factory threw — correctly refused before gate
    }
  }
  assert.equal(admitted, 0, `${admitted} forged witnesses were admitted`)
})

console.log(`\nwitness-plumbing: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
