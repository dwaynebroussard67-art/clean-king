/**
 * witness-plumbing.ts — the harness's receipt printer.
 *
 * The pilot proposes, the plumbing receipts. This is the layer that makes
 * "the analyzer never records" true — the recorder is not another agent,
 * it's instrumentation that runs in the harness process, not the pilot.
 *
 * In production the HTTP layer would call `outcomeWitness()` with the real
 * status code it received, the DOM layer would call `structuralWitness()` with
 * the content hash it computed, etc. The pilot never sees these calls.
 *
 * For now this file re-exports the plumbing factories with a harness-bound
 * clock and id, so tool packs don't need to import from `collective/` and
 * so a boundary test can assert: pilot code imports from `harness/`, never
 * from `collective/witness`.
 */

import type { Witness, WitnessKind } from '../collective/types.ts'
import {
  createPlumbingWitness,
  outcomeWitness,
  structuralWitness,
  contractWitness,
  humanWitness,
  hashFetchBodyToRef,
  hashDomSnapshotToRef,
  hashToStructuralRef,
} from '../collective/witness.ts'

export {
  createPlumbingWitness,
  outcomeWitness,
  structuralWitness,
  contractWitness,
  humanWitness,
  hashFetchBodyToRef,
  hashDomSnapshotToRef,
  hashToStructuralRef,
}
export type { Witness, WitnessKind }

/**
 * A harness-scoped plumbing helper. One per HarnessRuntime, created from the
 * runtime's own harnessId and clock. Pilot handles never receive it.
 */
export class WitnessPlumbing {
  constructor(
    private readonly harnessId: string,
    private readonly clock: () => Date = () => new Date(),
  ) {}

  outcome(toolCallId: string, missionId: string): Witness {
    return outcomeWitness(this.harnessId, toolCallId, missionId, this.clock().toISOString())
  }

  structural(artifactRef: string): Witness {
    return structuralWitness(this.harnessId, artifactRef, this.clock().toISOString())
  }

  contract(docUrl: string): Witness {
    return contractWitness(this.harnessId, docUrl, this.clock().toISOString())
  }

  human(person: string): Witness {
    return humanWitness(this.harnessId, person, this.clock().toISOString())
  }

  /** Generic mint — plumbing only. Pilot code must never call this. */
  mint(kind: WitnessKind, reference: string): Witness {
    return createPlumbingWitness({ kind, harnessId: this.harnessId, reference, observedAt: this.clock().toISOString() })
  }

  // ── Content-addressed structural witnesses — raw bytes, not JSON.stringify(output) ──

  /** Hash raw fetch body bytes -> structural witness sha256:hex */
  structuralFromFetchBody(body: Uint8Array | Buffer | string): Witness {
    const ref = hashFetchBodyToRef(body as any)
    return structuralWitness(this.harnessId, ref, this.clock().toISOString())
  }

  /** Hash DOM snapshot text -> structural witness */
  structuralFromDomSnapshot(snapshot: string): Witness {
    const ref = hashDomSnapshotToRef(snapshot)
    return structuralWitness(this.harnessId, ref, this.clock().toISOString())
  }

  /** Hash arbitrary string content (page text) -> structural witness */
  structuralFromString(content: string): Witness {
    const ref = hashToStructuralRef(content)
    return structuralWitness(this.harnessId, ref, this.clock().toISOString())
  }

  /** Hash raw bytes (PNG, etc.) -> structural witness */
  structuralFromBytes(bytes: Uint8Array | Buffer): Witness {
    const ref = hashToStructuralRef(bytes as Uint8Array)
    return structuralWitness(this.harnessId, ref, this.clock().toISOString())
  }
}
