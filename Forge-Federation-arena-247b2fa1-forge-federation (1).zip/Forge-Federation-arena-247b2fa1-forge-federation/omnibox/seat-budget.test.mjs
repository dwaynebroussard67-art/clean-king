/**
 * seat-budget.test.mjs
 * Per-seat consumption governance.
 *
 * Structure: baseline cases (does it meter what it says it meters), then
 * attack probes (can a seat spend past its allowance, credit itself, or
 * silently keep flying after the provider cut it off).
 */

import assert from 'node:assert/strict'
import {
  SeatBudgetLedger,
  SeatBudgetExceededError,
  DEFAULT_TIERS,
  defaultAllowanceFor,
  isRateLimitError,
} from './seat-budget.ts'

let passed = 0
let failed = 0
const failures = []

function test(name, fn) {
  try {
    fn()
    passed++
  } catch (err) {
    failed++
    failures.push({ name, message: err.message })
  }
}

const rec = (over = {}) => ({
  seatIndex: 1,
  pilotId: 'p1',
  type: 'claude',
  missionId: 'm1',
  contentHash: 'sha256:' + 'a'.repeat(64),
  at: new Date().toISOString(),
  outcome: 'succeeded',
  tookMs: 10,
  usd: 0,
  ...over,
})

// ── Baseline ─────────────────────────────────────────────────────────────

test('a provisioned seat starts at zero', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 3, tier: 'test' })
  assert.deepEqual(l.usageFor(1), { calls: 0, usd: 0, spentOnFailure: 0 })
  assert.equal(l.remainingCalls(1), 3)
  assert.equal(l.status(1), 'ok')
})

test('charge increments calls and decrements remaining', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 3, tier: 'test' })
  l.charge(1)
  assert.equal(l.usageFor(1).calls, 1)
  assert.equal(l.remainingCalls(1), 2)
})

test('spending the last call leaves the seat exhausted, not negative', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 2, tier: 'test' })
  l.charge(1)
  l.charge(1)
  assert.equal(l.remainingCalls(1), 0)
  assert.equal(l.status(1), 'exhausted')
})

test('usd allowance is enforced alongside calls', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxUsd: 0.10, tier: 'test' })
  l.charge(1, 0.06)
  assert.equal(l.status(1), 'ok')
  assert.throws(() => l.charge(1, 0.06), SeatBudgetExceededError)
})

test('local pilots default to unmetered', () => {
  assert.equal(defaultAllowanceFor('local').maxCalls, undefined)
  const l = new SeatBudgetLedger()
  l.provisionFromType(0, 'local')
  assert.equal(l.status(0), 'unmetered')
})

test('hosted pilots default to a finite conservative allowance', () => {
  for (const type of ['claude', 'gemini', 'gpt']) {
    assert.equal(typeof DEFAULT_TIERS[type].maxCalls, 'number')
    assert.ok(DEFAULT_TIERS[type].maxCalls > 0)
  }
})

test('settle files an attributed record without charging again', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 5, tier: 'test' })
  l.charge(1)
  l.settle(rec())
  assert.equal(l.usageFor(1).calls, 1, 'settle must not charge a second time')
  assert.equal(l.recordsForSeat(1).length, 1)
})

test('snapshot reports every provisioned seat in seat order', () => {
  const l = new SeatBudgetLedger()
  l.provision(3, { maxCalls: 1, tier: 't3' })
  l.provision(1, { maxCalls: 1, tier: 't1' })
  assert.deepEqual(l.snapshot().map((s) => s.seatIndex), [1, 3])
})

// ── Attack probes ────────────────────────────────────────────────────────

test('ATTACK: a seat cannot spend past its allowance', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 2, tier: 'test' })
  l.charge(1)
  l.charge(1)
  assert.throws(() => l.charge(1), SeatBudgetExceededError)
})

test('ATTACK: a refused charge does not mutate usage', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 1, tier: 'test' })
  l.charge(1)
  const before = l.usageFor(1)
  assert.throws(() => l.charge(1), SeatBudgetExceededError)
  assert.deepEqual(l.usageFor(1), before, 'a refused charge must leave the ledger untouched')
})

test('ATTACK: a seat cannot credit itself with negative spend', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxUsd: 1, tier: 'test' })
  l.charge(1, 0.5)
  l.charge(1, -10)
  assert.ok(l.usageFor(1).usd >= 0.5, 'negative usd must not reduce recorded spend')
})

test('ATTACK: NaN spend does not corrupt the meter', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxUsd: 1, tier: 'test' })
  l.charge(1, Number.NaN)
  assert.equal(Number.isFinite(l.usageFor(1).usd), true)
})

test('ATTACK: a negative allowance grants nothing rather than everything', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: -5, tier: 'test' })
  assert.equal(l.remainingCalls(1), 0)
  assert.throws(() => l.charge(1), SeatBudgetExceededError)
})

test('ATTACK: a NaN allowance grants nothing rather than everything', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: Number.NaN, tier: 'test' })
  assert.throws(() => l.charge(1), SeatBudgetExceededError)
})

test('Infinity allowance is honestly encoded as no ceiling', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: Number.POSITIVE_INFINITY, tier: 'test' })
  assert.equal(l.remainingCalls(1), null)
  l.charge(1)
  assert.equal(l.status(1), 'unmetered')
})

test('ATTACK: a failed dispatch is not refunded', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 5, tier: 'test' })
  l.charge(1)
  l.settle(rec({ outcome: 'failed', error: 'network' }))
  assert.equal(l.usageFor(1).calls, 1, 'a failure must still be charged')
  assert.equal(l.usageFor(1).spentOnFailure, 1, 'failed spend must be visible as such')
})

test('ATTACK: 429 reconciles upward and exhausts the seat', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 50, tier: 'optimistic' })
  l.charge(1)
  assert.equal(l.status(1), 'ok')
  l.reconcileRateLimited(1)
  assert.equal(l.status(1), 'exhausted', '429 means the seat is done')
  assert.equal(l.remainingCalls(1), 0)
})

test('ATTACK: 429 never reconciles downward', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 2, tier: 'test' })
  l.charge(1)
  l.charge(1)
  const before = l.usageFor(1).calls
  l.reconcileRateLimited(1)
  assert.ok(l.usageFor(1).calls >= before, 'a 429 is never evidence that less was spent')
})

test('ATTACK: a 429 on an unmetered seat establishes a ceiling', () => {
  const l = new SeatBudgetLedger()
  l.provisionFromType(2, 'custom')
  assert.equal(l.status(2), 'unmetered')
  l.charge(2)
  l.reconcileRateLimited(2)
  assert.equal(l.status(2), 'exhausted', 'a seat that turned out to be metered must stop looking free')
})

test('ATTACK: an unmetered seat is still counted', () => {
  const l = new SeatBudgetLedger()
  l.provisionFromType(0, 'local')
  l.charge(0)
  l.charge(0)
  assert.equal(l.usageFor(0).calls, 2, 'measurement must not depend on enforceability')
})

test('an unmetered seat is never refused', () => {
  const l = new SeatBudgetLedger()
  l.provisionFromType(0, 'local')
  for (let i = 0; i < 200; i++) l.charge(0)
  assert.equal(l.status(0), 'unmetered')
})

test('an unprovisioned seat is metered but never refused', () => {
  const l = new SeatBudgetLedger()
  l.charge(4)
  assert.equal(l.usageFor(4).calls, 1)
  assert.equal(l.status(4), 'unmetered')
})

// ── The measurement join ─────────────────────────────────────────────────

test('records group by content hash so divergence is on identical input', () => {
  const l = new SeatBudgetLedger()
  const h = 'sha256:' + 'b'.repeat(64)
  l.settle(rec({ seatIndex: 1, contentHash: h }))
  l.settle(rec({ seatIndex: 2, pilotId: 'p2', type: 'gemini', contentHash: h }))
  const grouped = l.recordsByContentHash()
  assert.equal(grouped.get(h).length, 2)
})

test('ATTACK: unhashed records are excluded, not bucketed under a placeholder', () => {
  const l = new SeatBudgetLedger()
  l.settle(rec({ contentHash: null }))
  const grouped = l.recordsByContentHash()
  assert.equal(grouped.size, 0, 'an unhashed observation cannot be shown to be the same observation')
})

test('every record carries full attribution from the first row', () => {
  const l = new SeatBudgetLedger()
  l.settle(rec())
  const r = l.allRecords()[0]
  for (const field of ['seatIndex', 'pilotId', 'type', 'missionId', 'contentHash']) {
    assert.ok(field in r, `record must carry ${field}`)
  }
})

test('ATTACK: returned records are copies, not live references', () => {
  const l = new SeatBudgetLedger()
  l.settle(rec())
  l.allRecords()[0].seatIndex = 99
  assert.equal(l.allRecords()[0].seatIndex, 1, 'callers must not be able to edit the ledger through a getter')
})

test('ATTACK: returned usage is a copy, not a live reference', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 5, tier: 'test' })
  l.charge(1)
  const u = l.usageFor(1)
  u.calls = 999
  assert.equal(l.usageFor(1).calls, 1)
})

// ── Rate-limit recognition ───────────────────────────────────────────────

test('rate-limit errors are recognised across provider phrasings', () => {
  for (const m of [
    'HTTP 429 Too Many Requests',
    'rate_limit_exceeded',
    'You have exceeded your quota',
    'Rate limit reached for requests',
  ]) {
    assert.equal(isRateLimitError(new Error(m)), true, `should recognise: ${m}`)
  }
})

test('ATTACK: an ordinary error is not mistaken for a rate limit', () => {
  for (const m of ['ECONNREFUSED', 'invalid api key', 'HTTP 500 server error']) {
    assert.equal(isRateLimitError(new Error(m)), false, `should not match: ${m}`)
  }
})

test('reset clears the meter but keeps the allowance', () => {
  const l = new SeatBudgetLedger()
  l.provision(1, { maxCalls: 2, tier: 'test' })
  l.charge(1)
  l.charge(1)
  l.reset(1)
  assert.equal(l.status(1), 'ok')
  assert.equal(l.remainingCalls(1), 2)
})

// ── report ───────────────────────────────────────────────────────────────

if (failed > 0) {
  for (const f of failures) console.error(`  FAIL: ${f.name}\n        ${f.message}`)
  console.error(`\n${failed} failed, ${passed} passed`)
  process.exit(1)
}
console.log(`${passed} passed`)
