/**
 * OmniBox harness contracts.
 *
 * The model is the pilot. The harness owns the mission, flight state,
 * capabilities, approvals, checkpoints, outcomes, and promotion decisions.
 * Neuralink is the active memory interface between the harness and a Passport;
 * a Passport adapter must never be exposed directly to a pilot.
 */

export type MissionStatus =
  | 'CREATED'
  | 'NEURALINK_BOUND'
  | 'CONTEXT_READY'
  | 'PLANNING'
  | 'WAITING_APPROVAL'
  | 'RUNNING'
  | 'WAITING_EXTERNAL'
  | 'CONTEXT_UPDATED'
  | 'EVALUATING'
  | 'MEMORY_REVIEW'
  | 'SUCCEEDED'
  | 'FAILED'
  | 'CANCELLED';

export type TerminalMissionStatus = 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export type MemoryStatus = 'asserted' | 'evidenced' | 'adjudicated' | 'imported';

export type MissionConstraint = {
  id: string;
  text: string;
  kind?: 'must' | 'must_not' | 'preference' | 'boundary';
};

export type MissionBudget = {
  maxUsd?: number;
  maxToolCalls?: number;
  maxModelTurns?: number;
  deadlineAt?: string;
};

export type MissionAuthority = {
  actorId: string;
  allowedCapabilityIds: string[];
  autoApproveRiskAtMost?: ToolRisk;
};

export type SuccessCriteria = {
  id?: string;
  description: string;
  type?: 'output_contains' | 'tool_succeeded' | 'evidence_present' | 'human_confirmed';
  value?: string;
  checks?: string[];
};

export type MissionSpec = {
  passportId: string;
  goal: string;
  constraints?: MissionConstraint[];
  budget?: MissionBudget;
  authority: MissionAuthority;
  successCriteria?: SuccessCriteria[];
  metadata?: Record<string, unknown>;
};

export type MissionRecord = MissionSpec & {
  id: string;
  status: MissionStatus;
  revision: number;
  createdAt: string;
  updatedAt: string;
  contextDigest?: string;
  checkpoint?: Checkpoint;
};

export type Checkpoint = {
  status: MissionStatus;
  step: string;
  state: Record<string, unknown>;
  revision: number;
  capturedAt: string;
};

export type RunStatus = 'CREATED' | 'RUNNING' | 'WAITING_APPROVAL' | 'WAITING_EXTERNAL' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export type RunRecord = {
  id: string;
  missionId: string;
  attempt: number;
  status: RunStatus;
  state: Record<string, unknown>;
  checkpoint: Record<string, unknown>;
  idempotencyKey: string;
  createdAt: string;
  updatedAt: string;
};

export type MissionEvent = {
  id: string;
  missionId: string;
  runId?: string;
  sequence: number;
  type:
    | 'mission_created'
    | 'status_changed'
    | 'context_loaded'
    | 'pilot_observed'
    | 'tool_requested'
    | 'tool_invoked'
    | 'capability_gap'
    | 'tool_completed'
    | 'approval_requested'
    | 'approval_decided'
    | 'checkpoint_saved'
    | 'outcome_recorded'
    | 'memory_candidate'
    | 'memory_decision'
    | 'mission_completed';
  actor: string;
  payload: Record<string, unknown>;
  createdAt: string;
};

export type PassportMemory = {
  id: string;
  title: string;
  content: string;
  status: MemoryStatus;
  confidence?: number | null;
  pinned?: boolean;
  evidence?: string[];
  tags?: string[];
  updatedAt?: string;
  metadata?: Record<string, unknown>;
};

export type PassportContext = {
  passportId: string;
  identity: {
    name: string;
    preferredName?: string | null;
    timezone?: string | null;
    language?: string | null;
  };
  memories: PassportMemory[];
};

export type ContextMemory = PassportMemory & {
  includedBecause: 'pinned' | 'adjudicated' | 'evidenced';
};

export type ContextFrame = {
  schema: 'omnibox.context-frame.v1';
  missionId: string;
  passportId: string;
  goal: string;
  constraints: MissionConstraint[];
  identity: PassportContext['identity'];
  memories: ContextMemory[];
  observations?: ObservedHarnessEvent[];
  estimatedCharacters: number;
  digest: string;
  createdAt: string;
};

export type ObservedHarnessEvent = {
  type: 'pilot_response' | 'tool_result' | 'approval' | 'outcome' | 'error';
  source: string;
  content: string;
  evidence?: string[];
  importance?: 'low' | 'normal' | 'high';
  metadata?: Record<string, unknown>;
};

export type MemoryCandidate = {
  schema: 'omnibox.memory-candidate.v1';
  missionId: string;
  passportId: string;
  content: string;
  sourceEventIds: string[];
  evidence: string[];
  scope: string;
  outcomeStatus?: 'confirmed' | 'partial' | 'failed' | 'unknown';
  status: 'candidate';
  createdAt: string;
};

export type NeuralinkDecision =
  | { action: 'include'; reason: string }
  | { action: 'exclude'; reason: string }
  | { action: 'request_evidence'; reason: string }
  | { action: 'persist_candidate'; reason: string; candidate: MemoryCandidate }
  | { action: 'promote'; reason: string; candidate: MemoryCandidate }
  | { action: 'reject'; reason: string };

export type ToolRisk = 'read' | 'transform' | 'create' | 'update' | 'delete' | 'external_side_effect';

export type CapabilityDescriptor = {
  id: string;
  name: string;
  description: string;
  risk: ToolRisk;
  inputSchema: Record<string, unknown>;
  outputSchema?: Record<string, unknown>;
  requiresApproval: boolean;
  supportsDryRun?: boolean;
  supportsIdempotency?: boolean;
};

export type ToolCall = {
  id: string;
  missionId: string;
  capabilityId: string;
  arguments: Record<string, unknown>;
  argumentsDigest: string;
  requestedAt: string;
};

export type ApprovalDecision = {
  approvalId: string;
  toolCallId: string;
  decision: 'approve' | 'reject' | 'edit' | 'dry_run';
  actorId: string;
  editedArguments?: Record<string, unknown>;
  decidedAt: string;
};

export interface PassportAdapter {
  loadContext(input: {
    passportId: string;
    missionId: string;
    maxMemories: number;
  }): Promise<PassportContext>;
  persistMemoryCandidate(candidate: MemoryCandidate): Promise<{ memoryId: string }>;
}

export interface MissionStore {
  create(mission: MissionRecord): Promise<void>;
  get(id: string): Promise<MissionRecord | null>;
  save(mission: MissionRecord, expectedRevision?: number): Promise<void>;
  appendEvent(event: MissionEvent): Promise<MissionEvent>;
  listEvents(missionId: string): Promise<MissionEvent[]>;
}

export interface RunStore {
  createRun(run: RunRecord): Promise<void>;
  getRun(id: string): Promise<RunRecord | null>;
  getLatestRun(missionId: string): Promise<RunRecord | null>;
  saveRun(run: RunRecord): Promise<void>;
}

export interface ContextFrameStore {
  saveContextFrame(input: { runId: string; missionId: string; passportId: string; frame: ContextFrame }): Promise<void>;
  loadLatestContextFrame(runId: string): Promise<ContextFrame | null>;
}

export type HarnessClock = () => Date;

export const TERMINAL_STATUSES: readonly TerminalMissionStatus[] = [
  'SUCCEEDED',
  'FAILED',
  'CANCELLED',
];
