"use client";

import { useState } from "react";
import type { Memory, MemoryType } from "@/lib/types";
import { MEMORY_TYPES } from "@/lib/types";
import { X, Save, ShieldCheck, AlertTriangle } from "lucide-react";
import { epistemicOf } from "@/components/EpistemicBadge";

interface Props {
  passportId: string;
  memory?: Memory | null;
  onClose: () => void;
  onSaved: (m: Memory) => void;
}

export function MemoryEditor({ passportId, memory, onClose, onSaved }: Props) {
  const [type, setType] = useState<MemoryType>(
    (memory?.type as MemoryType) || "knowledge"
  );
  const [title, setTitle] = useState(memory?.title || "");
  const [content, setContent] = useState(memory?.content || "");
  const [confidence, setConfidence] = useState(
    memory?.confidence ?? 1.0
  );
  const [tagsInput, setTagsInput] = useState(
    (memory?.tags || []).join(", ")
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Adjudication is a separate act from editing, with its own required inputs.
  // Folding it into "save" would make verification a side effect of typing,
  // which is exactly how a checked claim stops meaning anything.
  const [adjudicating, setAdjudicating] = useState(false);
  const [adjEvidence, setAdjEvidence] = useState("");
  const [adjNote, setAdjNote] = useState("");

  const isEdit = !!memory;
  const currentStatus = memory ? epistemicOf(memory).status : "asserted";
  const contentChanged = !!memory && content !== memory.content;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);

    const tags = tagsInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    const payload: Record<string, unknown> = {
      type,
      title: title.trim(),
      content,
      confidence,
      tags,
    };

    // Only attach an adjudication when the user explicitly filled one in. The
    // server rejects an incomplete one rather than silently ignoring it, so
    // sending an empty object here would turn a save into an error.
    if (adjudicating && adjEvidence.trim() && adjNote.trim()) {
      payload.adjudication = {
        evidence: adjEvidence
          .split(/[\n,]/)
          .map((e) => e.trim())
          .filter(Boolean),
        note: adjNote.trim(),
      };
    }

    let res: Response;
    if (isEdit) {
      res = await fetch(`/api/memories/${memory.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      res = await fetch(`/api/passports/${passportId}/memories`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }

    const data = await res.json();
    if (!res.ok) {
      setError(data.error || "Save failed.");
      setSaving(false);
      return;
    }
    onSaved(data);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1a1f3a] border border-white/10 shadow-2xl animate-fade-in overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
          <h2 className="text-lg font-bold text-white">
            {isEdit ? "Edit Memory" : "Add Memory"}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Type selector */}
          <div>
            <label className="block text-xs text-slate-400 mb-2">
              Memory Type
            </label>
            <div className="flex flex-wrap gap-2">
              {MEMORY_TYPES.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setType(t.value)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition border"
                  style={{
                    backgroundColor:
                      type === t.value ? `${t.color}20` : "transparent",
                    borderColor:
                      type === t.value ? `${t.color}40` : "rgba(255,255,255,0.06)",
                    color: type === t.value ? t.color : "#94a3b8",
                  }}
                >
                  <span>{t.icon}</span>
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Forge Mode project context"
              required
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
            />
          </div>

          {/* Content */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Content
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Describe this memory in detail..."
              rows={5}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition resize-none"
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="forge, project, active"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
            />
          </div>

          {/* Confidence */}
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Confidence: {Math.round(confidence * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={confidence}
              onChange={(e) => setConfidence(parseFloat(e.target.value))}
              className="w-full accent-passport-500"
            />
          </div>

          {/* Adjudication */}
          {isEdit && (
            <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  Status:{" "}
                  <span className="text-slate-200">
                    {currentStatus === "adjudicated"
                      ? "checked against evidence"
                      : currentStatus === "evidenced"
                        ? "evidence attached, unverified"
                        : "asserted, no evidence"}
                  </span>
                </span>
                {currentStatus !== "adjudicated" && (
                  <button
                    type="button"
                    onClick={() => setAdjudicating((v) => !v)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/20 transition"
                  >
                    <ShieldCheck className="h-3.5 w-3.5" />
                    {adjudicating ? "Cancel check" : "Mark as checked"}
                  </button>
                )}
              </div>

              {currentStatus === "adjudicated" && contentChanged && (
                <p className="flex items-start gap-1.5 text-xs text-amber-300">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-px" />
                  Saving this edit revokes the existing check — the evidence was
                  verified against the previous wording.
                </p>
              )}

              {adjudicating && (
                <div className="space-y-2 pt-1">
                  <p className="text-[11px] text-slate-500">
                    A confidence number is an assertion. To mark this checked, say
                    where the evidence is and what you verified.
                  </p>
                  <input
                    type="text"
                    value={adjEvidence}
                    onChange={(e) => setAdjEvidence(e.target.value)}
                    placeholder="Evidence pointers — file path, URL, run id (comma separated)"
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none transition"
                  />
                  <input
                    type="text"
                    value={adjNote}
                    onChange={(e) => setAdjNote(e.target.value)}
                    placeholder="What did you check?"
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none transition"
                  />
                </div>
              )}
            </div>
          )}

          {error && (
            <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={saving || !title.trim()}
            className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-passport-600 to-passport-500 hover:from-passport-500 hover:to-passport-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-passport-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="h-4 w-4" />
            {saving ? "Saving…" : isEdit ? "Update Memory" : "Add Memory"}
          </button>
        </form>
      </div>
    </div>
  );
}
