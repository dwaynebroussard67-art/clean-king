#!/usr/bin/env bash
#
# push-to-github.sh — put Forge Flight on GitHub, one command, either way.
#
#   ./scripts/push-to-github.sh new       a fresh repo of its own
#   ./scripts/push-to-github.sh sub       a subfolder of an existing repo
#
# It shows you every command before it runs anything, and it never force-
# pushes, never rewrites history, and never touches a branch you did not name.
#
set -euo pipefail

MODE="${1:-}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BRANCH="${BRANCH:-forge-flight}"
SUBDIR="${SUBDIR:-browser}"
REPO="${REPO:-forge-flight}"

say()  { printf '\n\033[38;5;208m%s\033[0m\n' "$*"; }
note() { printf '  %s\n' "$*"; }
run()  { printf '\033[2m$ %s\033[0m\n' "$*"; eval "$@"; }

if ! command -v git >/dev/null; then
  echo "git is not installed." >&2; exit 1
fi

case "$MODE" in
new)
  say "New repository"
  note "Creates a repo called '$REPO' and pushes this folder to it as the first commit."
  note "Needs the GitHub CLI (gh) signed in, or an existing empty repo to point at."
  echo
  read -r -p "Go ahead? [y/N] " ok; [ "$ok" = y ] || exit 0

  cd "$HERE"
  [ -d .git ] || run git init -b main
  run git add -A
  run "git commit -m 'Forge Flight: a browser whose tabs are seats

A desktop browser where opening an AI in a tab seats it at a shared table,
with no provider list, no selectors and no configuration.

- Structural seat detection over named weighted signals; ambiguity is a
  first-class refusal with a manual-pick fix path, never a guess.
- Read-back verification before send: the composer must return exactly what
  was typed into it or nothing is sent.
- Selector-free streamed-reply capture, discriminated by time rather than size.
- Six conversation shapes; one seat per host; user-triggered only.
- The Memory Passport (C1-C4 + TrustGate) ported dependency-free.

npm run verify: 4 stages, all green.' || true"

  if command -v gh >/dev/null; then
    run "gh repo create \"$REPO\" --private --source=. --remote=origin --push"
    say "Done."
    run "gh repo view \"$REPO\" --web --json url -q .url || true"
  else
    say "The GitHub CLI is not installed."
    note "Create an empty PRIVATE repo on github.com, then run:"
    echo
    note "  git remote add origin git@github.com:<you>/$REPO.git"
    note "  git push -u origin main"
  fi
  ;;

sub)
  say "Subfolder of an existing repo"
  note "Copies this folder into <repo>/$SUBDIR on a new branch called '$BRANCH'."
  note "Run this from inside a clone of the repo you want it in, e.g."
  note "  cd ~/code/forge-flight && $HERE/scripts/push-to-github.sh sub"
  echo

  if ! git rev-parse --git-dir >/dev/null 2>&1; then
    echo "You are not inside a git repository. cd into your clone first." >&2; exit 1
  fi
  TARGET="$(git rev-parse --show-toplevel)/$SUBDIR"
  note "Target: $TARGET"
  if [ -e "$TARGET" ]; then
    echo "'$SUBDIR' already exists there. Set SUBDIR=<name> to use another folder." >&2; exit 1
  fi
  read -r -p "Go ahead? [y/N] " ok; [ "$ok" = y ] || exit 0

  run "git switch -c \"$BRANCH\""
  run "mkdir -p \"$TARGET\""
  # Everything except installed packages, build output and screenshots.
  run "rsync -a --exclude node_modules --exclude dist --exclude 'test/e2e/shots' --exclude .git \"$HERE\"/ \"$TARGET\"/"
  run "git add \"$SUBDIR\""
  run "git commit -m 'Add Forge Flight browser under $SUBDIR/

A desktop browser where opening an AI in a tab seats it at a shared table.
Structural seat detection with no provider list, read-back verification
before send, selector-free reply capture, six conversation shapes, and the
Memory Passport ported dependency-free. npm run verify is green.'"
  say "Committed on '$BRANCH'. Push it with:"
  note "  git push -u origin $BRANCH"
  note "Then open a PR, or merge it straight into main."
  ;;

*)
  cat <<'USAGE'
Usage:
  scripts/push-to-github.sh new      create a private repo of its own and push
  scripts/push-to-github.sh sub      add it as a subfolder of the repo you are in

Environment overrides:
  REPO=<name>      repo name for `new`      (default: forge-flight)
  SUBDIR=<name>    folder name for `sub`    (default: browser)
  BRANCH=<name>    branch name for `sub`    (default: forge-flight)
USAGE
  exit 1
  ;;
esac
