/**
 * verify.mjs — the whole gate, in order of cost.
 *
 *   1. syntax   every source file parses
 *   2. unit     passport, shapes, seat rules, address bar        (node:test)
 *   3. ui       detector + injector + watcher in real Chromium   (playwright)
 *   4. e2e      the real app, launched and used                  (electron)
 *
 * Any stage failing fails the gate. A stage whose tooling is missing is
 * reported as SKIPPED and does not silently pass — a gate that goes green
 * because a runner was absent is worse than no gate.
 */

import { spawnSync, execSync } from 'node:child_process';
import { readdirSync, statSync, existsSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join, extname } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const results = [];

/**
 * Is a binary actually present, as opposed to its package directory?
 *
 * `npm install` can succeed and still leave no Electron (a proxy that refuses
 * the release host) or no Chromium. A stage whose runner is absent must report
 * SKIP rather than FAIL, and checking for a directory reports neither
 * truthfully: it says "runnable" and then fails for a reason that has nothing
 * to do with the code under test.
 */
function electronBinary() {
  const dir = join(root, 'node_modules', 'electron');
  const pathFile = join(dir, 'path.txt');
  if (!existsSync(pathFile)) return process.env.ELECTRON_OVERRIDE_DIST_PATH || null;
  try {
    const exe = readFileSync(pathFile, 'utf8').trim();
    const p = join(dir, 'dist', exe);
    return existsSync(p) ? p : null;
  } catch {
    return null;
  }
}

function chromiumBinary() {
  const bases = [process.env.PLAYWRIGHT_BROWSERS_PATH, '/opt/pw-browsers', join(homedir(), '.cache', 'ms-playwright')].filter(
    Boolean
  );
  for (const base of bases) {
    if (!existsSync(base)) continue;
    for (const dir of readdirSync(base)) {
      if (!/^chromium(-headless-shell)?-\d+$/.test(dir)) continue;
      for (const rel of [
        'chrome-linux/chrome',
        'chrome-linux/headless_shell',
        'chrome-headless-shell-linux64/chrome-headless-shell',
      ]) {
        const p = join(base, dir, rel);
        if (existsSync(p)) return p;
      }
    }
  }
  return null;
}

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (name === 'node_modules' || name.startsWith('.')) continue;
    const p = join(dir, name);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (['.js', '.mjs'].includes(extname(p))) out.push(p);
  }
  return out;
}

// ---------------------------------------------------------------- 1. syntax
{
  const files = walk(root);
  const bad = [];
  for (const f of files) {
    const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
    if (r.status !== 0) bad.push(`${f}\n${(r.stderr || '').split('\n').slice(0, 3).join('\n')}`);
  }
  results.push({ stage: 'syntax', ok: bad.length === 0, detail: bad.length ? bad.join('\n') : `${files.length} files parse` });
}

// ------------------------------------------------------------------ 2. unit
{
  // test/table.test.js reaches into src/main/tabs.js for the address bar, and
  // that module requires('electron') at load — so the unit stage needs the
  // binary present even though it never launches it.
  if (!electronBinary()) {
    results.push({
      stage: 'unit',
      skipped: true,
      detail: 'electron binary missing (test/table.test.js loads src/main/tabs.js)',
    });
  } else {
    const r = spawnSync(process.execPath, ['--test', 'test/*.test.js', 'src/field-evidence/*.test.mjs'], {
      cwd: root,
      encoding: 'utf8',
      shell: true,
    });
    const pass = (r.stdout.match(/^# pass (\d+)/m) || [])[1];
    const fail = (r.stdout.match(/^# fail (\d+)/m) || [])[1];
    results.push({
      stage: 'unit',
      ok: r.status === 0,
      detail: `${pass || '?'} passed, ${fail || '?'} failed`,
      output: r.status === 0 ? '' : r.stdout,
    });
  }
}

// -------------------------------------------------------------------- 3. ui
{
  const has = existsSync(join(root, 'node_modules', 'playwright-core'));
  const browser = has ? chromiumBinary() : null;
  if (!has) results.push({ stage: 'ui', skipped: true, detail: 'playwright-core not installed' });
  else if (!browser) results.push({ stage: 'ui', skipped: true, detail: 'no Chromium binary (npx playwright install chromium)' });
  else {
    const r = spawnSync(process.execPath, ['test/ui/run-ui-tests.mjs'], { cwd: root, encoding: 'utf8' });
    const line = (r.stdout.match(/^(\d+) passed, (\d+) failed$/m) || []).slice(1).join(' passed, ');
    results.push({ stage: 'ui', ok: r.status === 0, detail: line ? `${line} failed` : 'no summary', output: r.status === 0 ? '' : r.stdout + r.stderr });
  }
}

// ------------------------------------------------------------------- 4. e2e
{
  const hasPw = existsSync(join(root, 'node_modules', 'playwright-core'));
  const hasEl = !!electronBinary();
  let display = !!process.env.DISPLAY;
  let runner = [process.execPath, ['test/e2e/run-e2e.mjs']];
  if (!display) {
    try {
      execSync('command -v xvfb-run', { stdio: 'ignore' });
      runner = ['xvfb-run', ['-a', process.execPath, 'test/e2e/run-e2e.mjs']];
      display = true;
    } catch {
      /* headless with no xvfb: cannot launch a window */
    }
  }
  if (!hasPw || !hasEl) results.push({ stage: 'e2e', skipped: true, detail: 'electron or playwright-core missing' });
  else if (!display) results.push({ stage: 'e2e', skipped: true, detail: 'no display and no xvfb-run' });
  else {
    const r = spawnSync(runner[0], runner[1], { cwd: root, encoding: 'utf8', timeout: 300000 });
    const line = (r.stdout.match(/^(\d+) passed, (\d+) failed$/m) || []).slice(1).join(' passed, ');
    results.push({ stage: 'e2e', ok: r.status === 0, detail: line ? `${line} failed` : 'no summary', output: r.status === 0 ? '' : r.stdout + r.stderr });
  }
}

// ----------------------------------------------------------------- report
console.log('\nForge Flight verification\n');
let failed = 0;
for (const r of results) {
  const mark = r.skipped ? '\x1b[33m SKIP \x1b[0m' : r.ok ? '\x1b[32m PASS \x1b[0m' : '\x1b[31m FAIL \x1b[0m';
  console.log(` ${mark} ${r.stage.padEnd(7)} ${r.detail}`);
  if (!r.ok && !r.skipped) {
    failed++;
    if (r.output) console.log(r.output.split('\n').slice(-30).join('\n'));
  }
}
console.log('');
process.exit(failed ? 1 : 0);
