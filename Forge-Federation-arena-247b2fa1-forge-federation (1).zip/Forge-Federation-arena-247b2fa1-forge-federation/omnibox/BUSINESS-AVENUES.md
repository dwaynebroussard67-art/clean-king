# Forge Flight — Ten Ways to Make It a Business (Without Squeezing the Little Guy)

*Grounded in what the product already is, not what it could be retconned into.*

---

## What we're actually monetizing

Forge Flight is three things, and they are worth money in three different ways:

1. **A multi-AI roundtable browser.** One prompt fanned to N providers, with honest
   refusal instead of guesswork. Worth money as *time saved and better answers*.
2. **A tamper-evident Memory Passport.** Hash-chained, append-only, witness-counted,
   contradiction-closed. Worth money as *provenance and trust*.
3. **The Federation.** Equations, not prose; a blind overseer; a human as the final
   release. Worth money as *governance and decision-logging*.

The one-line strategy that keeps all ten ideas honest:

> **Monetize the orchestration, the verification, and the paperwork — never the
> little guy's data, and never lock the core away from someone with one laptop.**

Core (the browser, the seats, the shapes, the local-only passport) stays free forever.
The paid surface is everything *around* a fact once it's been found: proving it,
sharing it, routing it, governing it, and teaching people to do it well.

---

## Avenue 1 — Freemium pro tier (one-time or ~$5/mo)

**What it is.** The classic single-player model. The free app keeps everything the
README promises: seats, all six shapes, the passport, local-only, no account. A paid
"Pilot" tier unlocks *power* features, not *trust* features:

- More simultaneous seats (free = 4, paid = 12+).
- Larger passport history window / more export formats (CSV, PDF, signed bundles).
- Roster features: named seats, saved table layouts, per-seat renames that sync.
- The Relay/Interview shapes are free; deeper multi-round orchestration is paid.

**Why it fits.** The free tier *is the marketing*. Every solo user who gets a
cross-provider contradiction on their first try is a warm lead for "more table."

**Why it's affordable for the little guy.** A **one-time $49** unlock or **$5/mo**.
No seats, no per-user math, no procurement. A freelancer pays once and it's a tool,
not a subscription they resent.

**The catch.** One-time pricing has a refresh problem — a $49 lifetime tier eventually
stops funding development. Solve with an *upgrade* ladder (Pilot → Pilot+ → Fleet),
not a rental tax on the existing tier.

---

## Avenue 2 — Proof-of-claim reports (the passport is a product)

**What it is.** Sell the Memory Passport as a *notarized receipt*, not a database.
A freelancer, small consultancy, or small-business owner runs a question across five
providers, and Forge Flight mints a **Claim Report**: a tamper-evident bundle showing
5 independent witnesses agreed, or naming exactly which seat contradicted the others,
with the hash chain proving the log hasn't been edited since.

**Why it fits.** This is the one thing the product already does that almost nobody
else can: *"five distinct witnesses or it stays provisional"* is a real evidentiary
standard, enforced in code (`src/passport/`), not a marketing claim. A lawyer,
bookkeeper, or engineer who shows a client "here's the signed proof of what the
models said and who disagreed" is selling something genuinely new.

**Why it's affordable.** **Pay-per-report** ($3–$9) or **$9/mo for unlimited local
reports**. The little guy pays only when they need to prove something, which is rare
and high-value.

**The catch.** You must be loud that a Claim Report is *provenance*, **not legal or
medical advice**. One reckless testimonial and regulators come for you. This is the
avenue with the most compliance homework and the highest ceiling.

---

## Avenue 3 — The small-team table (the "2–8 person shop" plan)

**What it is.** A collaboration tier for the people the phrase "the little guy"
actually describes: the 3-person law firm, the 5-person marketing agency, the solo
researcher with an assistant. A *shared table* where the team fans one brief across
providers, the **Sides/Adversarial** shapes run the internal debate, and the
Federation's **human-is-the-final-release** flow becomes the team's decision log.

**Why it fits.** The Federation already models this exactly — a curator that can only
propose, an overseer that can only decide, and a human outside the triangle who makes
the final call. That's a *governance* feature. Teams pay for governance.

**Why it's affordable.** **$8–$12/seat/mo with a hard cap at 8 seats**, and a
founder-friendly **flat $49/mo "whole shop"** option. No enterprise contract, no
"contact sales." The small team is the *target customer*, not a downgraded enterprise.

**The catch.** Collaboration is the biggest build of all ten ideas (sync, permissions,
shared passport, invite flow). It's an avenue for month 12+, not month 1. Keep the
local-first promise intact: the team plan can sync a *shared* ledger while individual
passports stay local.

---

## Avenue 4 — BYO-key routing with honest metering (pay for what you use, capped)

**What it is.** A paid *gateway*, not a reseller. Users bring their own AI provider
keys (OpenAI, Anthropic, etc.), and Forge Flight routes prompts through a thin hosted
relay that applies the **seat budget** the codebase already has (`seat-budget.ts`:
charge before dispatch, per-seat allowances, deliberate overcount, "no refunds on
failure"). The user sets a hard monthly dollar cap; when a seat's allowance is spent,
it's *ejected*, not billed.

**Why it fits.** This is the one genuinely ready-to-monetize subsystem. The metering
philosophy is already written and already sound: *"a thing that must show its work
cannot accumulate authority."* Turn the ledger into the invoice.

**Why it's affordable.** **BYO keys + a 5–10% routing margin** or **$4/mo flat + tiny
usage fee**. The little guy is not buying $20/mo of tokens from you — they're using
their own free tiers/credits, and paying you pennies to govern the spend. Hard caps
mean they *cannot* be surprised. That's the single most "little guy" pricing move
available: **guarantee no surprise bills.**

**The catch.** Hosting a relay means you now hold a proxy people run AI traffic
through — trust and uptime become your product. And you must be visibly neutral:
never route traffic to your own preferred provider. This is also where the
"no account" purity bends; you'll need *one* account for the caps, so be explicit
that the *relay* is optional and the local app never phones home without it.

---

## Avenue 5 — Self-hosted "Forge for Firms" (the open-core play)

**What it is.** A self-hosted server edition of the Federation + curator queue +
proposal log, sold to small consultancies, boutiques, and local governments who want
the multi-AI rig on their own hardware with their own data. The desktop app stays
free and open; the *server* (the carrier, the shared curator, the decision log) is the
commercial core.

**Why it fits.** The Federation is genuinely differentiated: equations instead of
prose, a blind overseer, a no-delete store. Institutions that can't ship their data to
SaaS (legal, healthcare, municipal) will pay to run that on-prem.

**Why it's affordable.** **One-time $499–$1,499 per site license** or **$99/mo**.
For a small firm this is cheaper than one billable hour per year. Self-host means
their data cost is zero and their trust cost is zero.

**The catch.** Support burden is real — self-hosted customers call you when their
server breaks. Price support separately or make it a membership (see Avenue 7). And
on-prem is the one place where "no credentials stored" needs real documentation,
because *they* now hold the credentials.

---

## Avenue 6 — The Second-Opinion service (pay-per-run red-team reports)

**What it is.** Productize the **Sides** and **Adversarial** shapes into a consumer
service: a small-business owner pastes a decision — a contract clause, a vendor quote,
a lease paragraph, a pricing proposal — and Forge Flight fans it to several models,
runs the adversarial shape (answer, then have the rest try to break it), and returns a
tamper-evident summary: *"3 agreed, 1 found this specific weakness, here's the hash."*

**Why it fits.** This is literally what the shapes were built for, and "the rest are
asked to break the answer" is a better second-opinion product than any single chatbot
can offer, because disagreement is the *feature*, not a bug to suppress.

**Why it's affordable.** **$5–$15 per run**, or **$19/mo for 5 runs**. The little guy
spends less than one takeout lunch to get N providers arguing about their contract.

**The catch.** This one needs the BYO-key plumbing (Avenue 4) or you're paying all
the model costs yourself. Run the math: at a few dollars of tokens per run you must
price at ~3× cost to stay solvent. And draw a hard line: **business second opinions,
not medical/legal advice** — same compliance line as Avenue 2.

---

## Avenue 7 — The Forge Flight Playbook (education & a paid community)

**What it is.** Sell the *method*, not the app. The refusal culture, the witness
model, the five-shapes decision toolkit, the "read-back before send" discipline — that
is a teachable skill. Package it as a low-cost course, a monthly membership with
live "run your decision through the table" sessions, and office-hours for the little
guys who adopted the tool and now want to be dangerous with it.

**Why it fits.** The app is genuinely a Trojan horse for a way of working: *"never
trust one AI, always name the refusal, always demand five witnesses."* That's a
philosophy small-business owners will pay to learn. And the product docs already read
like a manifesto — the curriculum is half-written.

**Why it's affordable.** **$49 course / $9/mo membership.** Cheaper than a book and
more useful. It also *funds* the free tier, which is the honest version of "community
supports the product."

**The catch.** Education is a services business wearing a product costume — it does
not scale like the others, and it consumes your time directly. Treat it as the
*nurture* engine that feeds Avenues 1, 3, and 6, not as the headline revenue.

---

## Avenue 8 — Seat packs & rubrics (a $9–$29 add-on store)

**What it is.** Sell curated, industry-tuned packs that plug into the existing
system: a **"Contract Review" pack** (which shapes to run, which seats to assign to
For/Against, which boot-block exclusions to enforce), a **"Due Diligence" pack**, a
**"Hiring Decision" pack**, a **"Vendor Quote" pack**. Creators publish packs, you
take a revenue share.

**Why it fits.** The shapes are general; the *tuning* — what to ask, which side each
provider should argue, what to exclude — is exactly the expertise a solo lawyer or
accountant already has and would sell. The passport and boot-block are already
built to carry the "exclusion audit" these packs need.

**Why it's affordable.** **$9–$29 one-time per pack.** A freelancer buys the one pack
for their industry and ignores the rest. No subscription, no lock-in.

**The catch.** A marketplace has two cold-start problems (creators and buyers) and a
quality problem (junk packs poison the trust brand). Gate it: only packs that pass
the same soundness review the product applies to everything else get listed.

---

## Avenue 9 — The neutral referee: provider scorecards & benchmarking

**What it is.** Forge Flight's refusal-honesty is the product here. Because the
detector contains **no provider names and no selector list**, the app can tell you —
impartially — *which providers it can seat today, which it refuses, and why*. Sell
that neutrality **to the providers and enterprises**, never to the user:

- A **"Seat Scorecard"** subscription for AI companies who want to know, continuously,
  whether their UI still seats cleanly (redesign detection as a service).
- A public **"who's actually compatible"** directory — free to users, with the
  provider paying for placement/verification.
- The `tools/probe.mjs` workflow already does this by hand; you'd be productizing it
  into a scheduled, reportable service.

**Why it fits.** "The referee charges the teams, not the audience." The user stays
free; the parties with a commercial interest in being seаtable pay for the audit.

**Why it's affordable for the little guy.** It's *free* for the little guy — that's
the whole point. The revenue comes from the providers.

**The catch.** This is the trust minefield. The moment a paying provider influences
the scorecard, the brand is dead. Structurally separate it: scorecards are computed by
the same soundness-first code, published regardless of who pays, and sponsors pay for
*distribution*, not *scores*. One misstep here poisons Avenues 2 and 6, so sequence
this *last* or keep the firewalls brutal.

---

## Avenue 10 — The honesty benchmark (opt-in aggregate, revenue-shared)

**What it is.** The codebase already separates engine-training records from
conversation text (`anchors.jsonl` — "prompts and replies are stripped by name").
That separation makes something rare possible: a **public "AI Agreement Benchmark"**
measuring, across providers, how often they *agree*, *contradict*, and *refuse* —
without ever seeing a user's words. Users opt in to contribute anonymized
agreement/refusal statistics; the benchmark is licensed to researchers, journalists,
and enterprises; a share of the proceeds funds the free tier (or goes back to
contributors).

**Why it fits.** Cross-provider agreement and contradiction *happening now* is exactly
the data this product uniquely generates, and it's data with genuine public value:
"how much do frontier models actually disagree with each other, measured
structurally?" The tamper-evident ethos means the benchmark can be *auditable* in a
way no vendor's self-reported benchmark is.

**Why it's affordable.** The little guy is **never charged and never identified**. The
customers are institutions. The money is in the aggregate, which is the only ethical
place for it to be.

**The catch.** This is a long, slow, reputation-gated play. It only works after the
app has a real user base, and only if opt-in is genuinely optional and genuinely
anonymous. But it's the one avenue that could eventually make the *free tier
self-funding* — which is the strongest possible answer to "affordable for the little
guy."

---

## The pricing floor — what "affordable" concretely means here

| Avenue | Little-guy price | Who actually pays |
|---|---|---|
| 1. Pro tier | $49 one-time / $5/mo | individual |
| 2. Claim reports | $3–$9 each / $9/mo | individual, freelancer |
| 3. Team table | $8–$12/seat, cap 8 / $49 flat | 2–8 person shop |
| 4. BYO-key gateway | ~5% margin + hard cap | individual, solo dev |
| 5. Self-host | $499–$1,499 / $99/mo | small firm, agency |
| 6. Second opinion | $5–$15/run / $19/mo | small business |
| 7. Playbook | $49 course / $9/mo | small business |
| 8. Packs | $9–$29 one-time | freelancer |
| 9. Scorecards | free to users | AI providers |
| 10. Benchmark | free to users | institutions |

Two things that must **never** be paid, or the brand collapses: the core
roundtable browser, and the local-only, no-account promise. Those are the trust
moat. Everything above monetizes the *edges* of that moat, not the water.

---

## If I had to sequence it

**Month 1–3:** Avenue 1 (pro tier) — it's a features-gate on top of what ships today.
**Month 3–6:** Avenue 4 (BYO-key gateway) — the metering is already written; it funds
Avenue 6 and makes surprise-bill-proof pricing real.
**Month 6–9:** Avenue 6 (second opinion) — builds on 4, and is the first "wow, that
paid for itself" moment a small business has.
**Month 6–12:** Avenue 2 (claim reports) — the highest ceiling; needs the most
compliance care, so start it early but ship it carefully.
**Month 12+:** Avenue 3 (team table), Avenue 5 (self-host), Avenue 8 (packs).
**Year 2+:** Avenue 10 (benchmark), then Avenue 9 (scorecards) — and only after the
neutrality firewall is proven, because those two can either crown you or kill you.

The quiet theme running through all ten: **Forge Flight's refusal to guess is the
business.** You don't sell a browser. You sell *"here's what several AIs said, here's
proof, here's who disagreed, and here's what I refused to pretend to know."* Every
avenue above is just a different way of charging for that sentence — and every one of
them leaves the little guy with a free, private, honest tool.
