/**
 * anchor-bridge.ts
 *
 * Routes browser.click and browser.type through the DOM re-anchor engine
 * (forge-reanchor-v8) so that a manoeuvre recorded against one version of
 * a page keeps working after a redesign. If the engine can't re-derive the
 * element soundly, the call is refused — not guessed.
 *
 * PRINCIPLE: the engine stores a descriptor (multi-signal weighted evidence)
 * instead of a raw CSS path. "Position is not identity." A CSS path breaks
 * the moment the site ships. A descriptor survives any structural change the
 * engine's signals can still see through.
 *
 * Keepalive rule (first lever, cheapest, highest precision):
 *   If exactly ONE element on the page carries the anchor's stable id
 *   (data-testid / id attribute), match on it immediately.
 *   If zero or more than one match → fall through to full multi-signal scorer.
 *
 * Output to the flight recorder:
 *   anchor_hit        — engine found the element, proceeded
 *   anchor_miss       — engine found nothing, call refused
 *   anchor_provisional — engine found something but flagged uncertainty
 *   anchor_reanchored — engine resolved via fallback signals (not keepalive)
 *   anchor_wrong_grab — post-click DOM inspection detected wrong element
 *                        (only catchable if the caller enables verification)
 *
 * How to wire:
 *   1. At startup, call AnchorBridge.setEngine(engine) with the loaded
 *      forge-reanchor-v8 instance.
 *   2. Replace BrowserPack.click() / BrowserPack.type() call sites with
 *      AnchorBridge.click() / AnchorBridge.type().
 *   3. Pass a FlightRecorder instance if you want events logged.
 *
 * The engine itself (forge-reanchor-v8.js) is NEVER distributed with this
 * file. It is loaded at runtime from the path the repo owner controls.
 * The corpus and mutation seeds stay in the vault.
 */

// ── Types ──────────────────────────────────────────────────────────────────

/**
 * Multi-signal element descriptor.
 * Mirrors the DOM engine's internal anchor format so we can call it directly.
 *
 * Priority order matches the engine's signal weights:
 *   ownId (1000) → traversal (900) → objectIdentity (850) →
 *   blockAnchorId (200) → text (200) → depth (180) →
 *   siblingIndex (150) → siblingOrder (120) → path (80) → tag (10)
 *
 * You don't need all fields. The engine accepts what it has and refuses if
 * evidence falls below the acceptance threshold.
 */
export interface ElementAnchor {
  // ── Keepalive signals (checked first — single-match is always trusted) ──
  /** data-testid attribute value, if the app emits one */
  testId?: string
  /** id attribute value */
  id?: string

  // ── Multi-signal corroboration ──
  /** Visible text of the element or its label */
  text?: string
  /** ARIA role: "button", "link", "input", "checkbox", etc. */
  role?: string
  /** Tag name: "button", "a", "input", "select", etc. */
  tag?: string
  /** CSS class names expected on the element (stable semantic classes only —
   *  not utility classes like "mb-4 text-sm" that change on every deploy) */
  stableClasses?: string[]
  /** Ancestor chain: nearest stable ancestor id or testId values,
   *  outermost last. Used as blockAnchorId signal. */
  ancestorIds?: string[]
  /** n-th matching element on the page (0-indexed). LAST RESORT ONLY.
   *  The engine still validates all other signals before trusting a
   *  position, and refuses if it is ambiguous. */
  nth?: number
  /** Original CSS path captured at record time. Used only as a tiebreaker
   *  signal, never as the sole basis for a match. */
  cssPath?: string
  /** URL of the page this descriptor was recorded on */
  recordedOn?: string
  /** ISO timestamp of the last time this anchor successfully resolved */
  lastSeen?: string
  /** Number of times this anchor has resolved without re-anchoring */
  hitCount?: number
  /** Number of times this anchor required re-anchoring to resolve */
  reanchorCount?: number
}

export type AnchorResult =
  | { status: 'hit';         element: FoundElement; method: 'keepalive' | 'full-score' }
  | { status: 'reanchored';  element: FoundElement; method: 'fallback'; confidence: number }
  | { status: 'provisional'; element: FoundElement; confidence: number }
  | { status: 'miss';        reason: AnchorRefusalReason }

export type AnchorRefusalReason =
  | 'ENTROPY_LOW'           // signals too common to be distinctive
  | 'AMBIGUOUS'             // 2+ candidates, can't choose
  | 'NO_CANDIDATES'         // nothing matched at all
  | 'ENGINE_OFFLINE'        // engine not loaded
  | 'BRIDGE_OFFLINE'        // browser bridge not connected
  | 'PROVISIONAL_REFUSED'   // engine flagged provisional, policy is to refuse
  | 'KEEPALIVE_MULTI_MATCH' // stable id matched more than one element

export interface FoundElement {
  /** The selector the engine resolved to — may differ from the recorded cssPath */
  resolvedSelector: string
  /** Snapshot of the element's attributes at resolve time */
  snapshot: {
    tag: string
    id?: string
    testId?: string
    text?: string
    role?: string
  }
}

export interface AnchorEvent {
  type: 'anchor_hit' | 'anchor_miss' | 'anchor_provisional' |
        'anchor_reanchored' | 'anchor_wrong_grab'
  anchor: ElementAnchor
  result: AnchorResult
  tool: 'browser.click' | 'browser.type'
  args: Record<string, unknown>
  timestamp: string
  missionId?: string
}

export interface FlightRecorder {
  record(event: AnchorEvent): void
}

// ── Re-anchor engine interface ─────────────────────────────────────────────
// The real engine is forge-reanchor-v8.js, loaded at runtime.
// This interface is the minimal surface we call.

export interface ReAnchorEngine {
  /** Attempt to locate the element described by `anchor` in the live DOM
   *  (accessed via the bridge). Returns an AnchorResult. */
  resolve(anchor: ElementAnchor, bridge: BrowserBridge): Promise<AnchorResult>
  /** Engine version string, e.g. "v8.0.0" */
  readonly version: string
}

export interface BrowserBridge {
  invoke(tool: string, args: Record<string, unknown>): Promise<unknown>
}

// ── Bridge between anchor resolution and browser-pack ─────────────────────

let _engine: ReAnchorEngine | null = null
let _bridge: BrowserBridge | null = null
let _recorder: FlightRecorder | null = null
let _provisionalPolicy: 'proceed' | 'refuse' = 'refuse'
let _activeMissionId: string | null = null

export const AnchorBridge = {

  // ── Configuration ──────────────────────────────────────────────────────

  setEngine(engine: ReAnchorEngine | null): void { _engine = engine },
  setBridge(bridge: BrowserBridge | null): void { _bridge = bridge },
  setRecorder(recorder: FlightRecorder | null): void { _recorder = recorder },
  setMissionId(missionId: string | null): void { _activeMissionId = missionId },

  /**
   * What to do when the engine returns PROVISIONAL (found something, not sure).
   * 'refuse' is the safe default — never act on uncertainty.
   * 'proceed' lets the element through and flags it in the recorder.
   * The adversarial gauntlet is run with 'refuse'; production can use either.
   */
  setProvisionalPolicy(policy: 'proceed' | 'refuse'): void {
    _provisionalPolicy = policy
  },

  engineVersion(): string | null {
    return _engine?.version ?? null
  },

  // ── Keepalive ──────────────────────────────────────────────────────────

  /**
   * The cheapest, highest-precision path. If the anchor has a stable id
   * (testId or id) and EXACTLY ONE element on the page carries it, that IS
   * the element — no scoring needed. Zero wrong-grabs by definition (a unique
   * id that matches exactly one element IS identity).
   *
   * If zero or 2+ match, return null and fall through to the engine.
   * This mirrors forge-keepalive.js exactly: "re-stamps only when exactly
   * ONE element carries the stored strong id, else stays lost."
   */
  async keepalive(
    anchor: ElementAnchor
  ): Promise<{ element: FoundElement } | null> {
    if (!_bridge) return null
    const stableId = anchor.testId ?? anchor.id
    if (!stableId) return null

    const attr = anchor.testId ? 'data-testid' : 'id'
    const selector = `[${attr}="${CSS.escape(stableId)}"]`

    try {
      const result = await _bridge.invoke('browser.query_all', { selector }) as
        Array<{ tag: string; id?: string; testId?: string; text?: string; role?: string }>

      if (!result || result.length !== 1) return null

      return {
        element: {
          resolvedSelector: selector,
          snapshot: result[0],
        },
      }
    } catch {
      return null
    }
  },

  // ── Core resolution ────────────────────────────────────────────────────

  /**
   * Resolve an anchor to a live element, using keepalive first then the
   * re-anchor engine. Returns an AnchorResult.
   *
   * This is the method browser.click and browser.type call instead of
   * using a raw CSS selector.
   */
  async resolve(
    anchor: ElementAnchor,
    tool: 'browser.click' | 'browser.type',
    toolArgs: Record<string, unknown>
  ): Promise<AnchorResult> {
    if (!_bridge) {
      const r: AnchorResult = { status: 'miss', reason: 'BRIDGE_OFFLINE' }
      _emit({ type: 'anchor_miss', anchor, result: r, tool, args: toolArgs })
      return r
    }

    // 1 — Keepalive: single-match stable id wins immediately
    const kl = await AnchorBridge.keepalive(anchor)
    if (kl) {
      const r: AnchorResult = {
        status: 'hit',
        element: kl.element,
        method: 'keepalive',
      }
      _emit({ type: 'anchor_hit', anchor, result: r, tool, args: toolArgs })
      return r
    }

    // 2 — Full engine
    if (!_engine) {
      // Engine not loaded. Fall back to raw cssPath if present, but log it
      // as a provisional so the flight recorder knows this wasn't hardened.
      if (anchor.cssPath) {
        const r: AnchorResult = {
          status: 'provisional',
          element: {
            resolvedSelector: anchor.cssPath,
            snapshot: { tag: 'unknown' },
          },
          confidence: 0.0,
        }
        _emit({ type: 'anchor_provisional', anchor, result: r, tool, args: toolArgs })
        return r
      }
      const r: AnchorResult = { status: 'miss', reason: 'ENGINE_OFFLINE' }
      _emit({ type: 'anchor_miss', anchor, result: r, tool, args: toolArgs })
      return r
    }

    const engineResult = await _engine.resolve(anchor, _bridge)

    if (engineResult.status === 'provisional' && _provisionalPolicy === 'refuse') {
      const r: AnchorResult = { status: 'miss', reason: 'PROVISIONAL_REFUSED' }
      _emit({ type: 'anchor_miss', anchor, result: r, tool, args: toolArgs })
      return r
    }

    const eventType =
      engineResult.status === 'hit'         ? 'anchor_hit' :
      engineResult.status === 'reanchored'   ? 'anchor_reanchored' :
      engineResult.status === 'provisional'  ? 'anchor_provisional' :
                                               'anchor_miss'

    _emit({ type: eventType, anchor, result: engineResult, tool, args: toolArgs })
    return engineResult
  },

  // ── Anchored click ────────────────────────────────────────────────────

  /**
   * Click an element by its descriptor. Refuses to click if the element
   * can't be resolved soundly.
   */
  async click(
    anchor: ElementAnchor,
    options?: { verify?: boolean }
  ): Promise<{ clicked: boolean; resolvedSelector: string } | { refused: true; reason: AnchorRefusalReason }> {
    const result = await AnchorBridge.resolve(anchor, 'browser.click', { anchor })

    if (result.status === 'miss') {
      return { refused: true, reason: result.reason }
    }

    const selector = result.element.resolvedSelector

    const clickResult = await _bridge!.invoke('browser.click', { selector }) as
      { clicked: boolean; element: string }

    if (options?.verify) {
      // Post-click: check the element that was actually clicked matches what
      // we expected. If not, emit anchor_wrong_grab so the flight recorder
      // knows the engine's resolution was correct but the click landed wrong
      // (e.g. page mutated between resolution and click).
      const wrongGrab = await _verifyClick(anchor, selector)
      if (wrongGrab) {
        _emit({
          type: 'anchor_wrong_grab',
          anchor,
          result,
          tool: 'browser.click',
          args: { anchor, selector },
        })
      }
    }

    return { clicked: clickResult.clicked, resolvedSelector: selector }
  },

  // ── Anchored type ─────────────────────────────────────────────────────

  /**
   * Type into an element by its descriptor. Refuses if the element can't
   * be resolved soundly.
   */
  async type(
    anchor: ElementAnchor,
    text: string,
    options?: { clearFirst?: boolean }
  ): Promise<{ typed: boolean; resolvedSelector: string } | { refused: true; reason: AnchorRefusalReason }> {
    const result = await AnchorBridge.resolve(anchor, 'browser.type', { anchor, text })

    if (result.status === 'miss') {
      return { refused: true, reason: result.reason }
    }

    const selector = result.element.resolvedSelector

    const typeResult = await _bridge!.invoke('browser.type', {
      selector,
      text,
      clearFirst: options?.clearFirst ?? true,
    }) as { typed: boolean }

    return { typed: typeResult.typed, resolvedSelector: selector }
  },
}

// ── Helpers ────────────────────────────────────────────────────────────────

function _emit(partial: Omit<AnchorEvent, 'timestamp' | 'missionId'>): void {
  if (!_recorder) return
  _recorder.record({
    ...partial,
    timestamp: new Date().toISOString(),
    missionId: _activeMissionId ?? undefined,
  })
}

async function _verifyClick(
  anchor: ElementAnchor,
  resolvedSelector: string
): Promise<boolean> {
  if (!_bridge) return false
  try {
    const clicked = await _bridge.invoke('browser.last_clicked', {}) as {
      tag?: string; id?: string; testId?: string; text?: string
    } | null

    if (!clicked) return false

    // If we had a testId or id and it doesn't match, that's a wrong grab
    if (anchor.testId && clicked.testId !== anchor.testId) return true
    if (anchor.id && clicked.id !== anchor.id) return true

    // Text mismatch (allowing prefix — text can be truncated in the DOM)
    if (anchor.text && clicked.text &&
        !clicked.text.toLowerCase().includes(anchor.text.toLowerCase().trim())) {
      return true
    }

    return false
  } catch {
    return false
  }
}

// CSS.escape polyfill — available in browsers but not in Node test harnesses
const CSS = {
  escape: (s: string) =>
    s.replace(/[^a-zA-Z0-9-_]/g, c => `\\${c}`),
}

// ── Updated browser-pack tool schemas ─────────────────────────────────────
// These replace the raw selectorSchema in browser-pack.ts.
// Pilots pass an anchor descriptor; the bridge resolves it before touching
// the page.

export const anchorSchema = {
  type: 'object',
  description:
    'Multi-signal element descriptor. The re-anchor engine will resolve this ' +
    'to a live element, surviving page redesigns. Prefer testId or id when ' +
    'the app emits them. Add text and role as corroborating signals.',
  properties: {
    testId:        { type: 'string', description: 'data-testid attribute value' },
    id:            { type: 'string', description: 'id attribute value' },
    text:          { type: 'string', description: 'Visible text of the element or its label' },
    role:          { type: 'string', description: 'ARIA role: button, link, input, checkbox, …' },
    tag:           { type: 'string', description: 'Tag name: button, a, input, select, …' },
    stableClasses: {
      type: 'array',
      items: { type: 'string' },
      description: 'Stable semantic CSS classes (not utility classes like "mb-4")',
    },
    ancestorIds: {
      type: 'array',
      items: { type: 'string' },
      description: 'Nearest stable ancestor id or testId values, outermost last',
    },
    nth:     { type: 'number', description: '0-indexed position. Last resort only.' },
    cssPath: { type: 'string', description: 'Original CSS path. Tiebreaker signal only.' },
  },
} as const

export const BROWSER_CLICK_ANCHORED = {
  id: 'browser.click',
  name: 'Click an element',
  description:
    'Click an element. Pass a descriptor with as many signals as you can observe ' +
    '(testId, id, text, role, tag). The re-anchor engine resolves it against the ' +
    'live page and refuses to click if it cannot do so soundly.',
  inputSchema: {
    type: 'object',
    required: ['anchor'],
    properties: {
      anchor: anchorSchema,
      verify: {
        type: 'boolean',
        description: 'If true, confirm after clicking that the right element was hit. Slower but catches page-mutation races.',
      },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}

export const BROWSER_TYPE_ANCHORED = {
  id: 'browser.type',
  name: 'Type into an input',
  description:
    'Type text into an element identified by a descriptor. The re-anchor engine ' +
    'resolves it soundly or refuses — it will never type into the wrong field.',
  inputSchema: {
    type: 'object',
    required: ['anchor', 'text'],
    properties: {
      anchor: anchorSchema,
      text:       { type: 'string', description: 'Text to type' },
      clearFirst: { type: 'boolean', description: 'Clear the field first. Default true.' },
    },
  },
  risk: 'transform',
  requiresApproval: false,
}
