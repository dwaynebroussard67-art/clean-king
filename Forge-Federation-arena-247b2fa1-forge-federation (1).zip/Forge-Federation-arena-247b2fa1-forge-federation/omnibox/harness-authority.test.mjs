// Run with: node --experimental-strip-types src/harness/harness-authority.test.mjs
//
// Authority-boundary gate for the harness.
//
// harness.test.mjs proves the state machine and Neuralink contract behave as
// specified. This file asks a different question: can the declared authority
// boundary actually be crossed? Every check below is written as an ATTACK --
// it passes when the attack is REFUSED. A failing check here is a live hole,
// not a style complaint.
//
// Status: 9/9 green. Every attack below succeeded before the executor landed.
// Keep them here as regression guards -- each one is a hole that was open, and
// the cheapest way to reopen it is to refactor without noticing.

import { HarnessRuntime, InMemoryMissionStore } from './runtime.ts';
import { CapabilityRegistry } from './capabilities.ts';

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { console.log(`  ✓ ${name}`); passed++; }
  else { console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); failed++; }
}

const passport = {
  async loadContext() {
    return { passportId: 'passport-1', memories: [], preferences: {}, decisions: [] };
  },
  async recordOutcome() {},
};

function registry() {
  const capabilities = new CapabilityRegistry();
  capabilities.register({
    id: 'fs.read', name: 'read a file', risk: 'read',
    inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    requiresApproval: false,
  });
  capabilities.register({
    id: 'fs.delete', name: 'delete a file', risk: 'delete',
    inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] },
    requiresApproval: true,
  });
  return capabilities;
}

async function boot(budget) {
  const store = new InMemoryMissionStore();
  const harness = new HarnessRuntime({ store, passport, capabilities: registry() });
  const mission = await harness.createMission({
    passportId: 'passport-1',
    goal: 'authority boundary probe',
    budget,
    authority: {
      actorId: 'pilot',
      allowedCapabilityIds: ['fs.read', 'fs.delete'],
      autoApproveRiskAtMost: 'read',
    },
  });
  await harness.bindNeuralink(mission.id);
  await harness.beginPlanning(mission.id);
  return { harness, mission, store };
}

console.log('\n1. A caller cannot escalate its own authority\n');

{
  // ATTACK: the requester sets dryRun on a delete capability it is not
  // authorised to auto-approve. Dry-run must be a harness-determined
  // execution mode, never a flag the requester supplies.
  const { harness, mission } = await boot();
  const result = await harness.requestTool({
    missionId: mission.id, id: 'atk-dry', capabilityId: 'fs.delete',
    // dryRun is no longer a parameter. Passing one must change nothing.
    arguments: { path: '/etc/passwd' }, dryRun: true,
  });
  check(
    'a caller-declared dryRun does not skip the approval gate on a delete',
    result.authorization.decision === 'require_approval',
    `got "${result.authorization.decision}"`,
  );
}

console.log('\n2. An approval authorises one specific request, and only that one\n');

{
  // ATTACK: approve an approval id and tool call id that were never issued.
  const { harness, mission } = await boot();
  await harness.requestTool({
    missionId: mission.id, id: 'tc-real', capabilityId: 'fs.delete',
    arguments: { path: '/tmp/scratch' },
  });
  let refused = false;
  try {
    await harness.decideApproval(mission.id, {
      approvalId: 'never-issued', toolCallId: 'never-requested',
      decision: 'approve', actorId: 'human',
    });
  } catch { refused = true; }
  check('an approval for a tool call that was never requested is refused', refused);
}

{
  // ATTACK: request a harmless delete, get it approved, then present the
  // approval alongside different arguments. argumentsDigest is computed in
  // createToolCall precisely so this is detectable -- it is currently never
  // compared, so this is a time-of-approval / time-of-use gap.
  const { harness, mission } = await boot();
  const benign = await harness.requestTool({
    missionId: mission.id, id: 'tc-benign', capabilityId: 'fs.delete',
    arguments: { path: '/tmp/scratch' },
  });
  await harness.decideApproval(mission.id, {
    approvalId: 'appr-1', toolCallId: 'tc-benign', decision: 'approve', actorId: 'human',
  });
  check(
    'the arguments digest changes when the arguments change',
    benign.toolCall.argumentsDigest
      !== (await import('./capabilities.ts')).createToolCall({
        id: 'tc-benign', missionId: mission.id, capabilityId: 'fs.delete',
        arguments: { path: '/etc/shadow' }, requestedAt: benign.toolCall.requestedAt,
      }).argumentsDigest,
  );

  // Re-presenting the same tool call id with different arguments must not be
  // treated as already-approved work. A hardening pass later closed this at an
  // earlier point than originally expected here: an id that already resolved
  // to an approved, unexecuted grant is refused for reuse outright, before
  // authorization is even consulted again. EXECUTION_REFUSED is the correct
  // outcome, not a weaker fallback -- 'deny' or 'require_approval' would have
  // meant a second live authorization got minted for a spent id.
  let outcome = 'allowed';
  try {
    const swapped = await harness.requestTool({
      missionId: mission.id, id: 'tc-benign', capabilityId: 'fs.delete',
      arguments: { path: '/etc/shadow' },
    });
    outcome = swapped.authorization.decision;
  } catch (error) {
    outcome = `threw:${error.code ?? error.name}`;
  }
  check(
    'a re-request under an approved id with different arguments is refused, not crashed',
    outcome === 'deny' || outcome === 'require_approval' || outcome === 'threw:EXECUTION_REFUSED',
    `got "${outcome}"`,
  );
}

console.log('\n2b. Approval is available for the whole mission, not just once\n');

{
  // The transition table allows PLANNING -> WAITING_APPROVAL but NOT
  // RUNNING -> WAITING_APPROVAL. Once a mission is RUNNING, any capability
  // that needs a human throws MissionStateError instead of gating. A mission
  // can therefore gate exactly one approval in its lifetime.
  const { harness, mission } = await boot();
  await harness.requestTool({
    missionId: mission.id, id: 'tc-first', capabilityId: 'fs.read', arguments: { path: '/tmp/a' },
  });
  let outcome = 'gated';
  try {
    const second = await harness.requestTool({
      missionId: mission.id, id: 'tc-second', capabilityId: 'fs.delete',
      arguments: { path: '/tmp/b' },
    });
    outcome = second.authorization.decision;
  } catch (error) {
    outcome = `threw:${error.code ?? error.name}`;
  }
  check(
    'an approval-requiring tool can still be gated once the mission is RUNNING',
    outcome === 'require_approval',
    `got "${outcome}"`,
  );
}

console.log('\n3. A terminal mission holds no tool authority\n');

{
  // ATTACK: cancel the mission, then use a granted read capability.
  // assertResumable() already exists in state-machine.ts and encodes exactly
  // this rule -- it currently has no call sites.
  const { harness, mission, store } = await boot();
  await harness.requestTool({
    missionId: mission.id, id: 'tc-a', capabilityId: 'fs.delete', arguments: { path: '/tmp/x' },
  });
  await harness.decideApproval(mission.id, {
    approvalId: 'appr-2', toolCallId: 'tc-a', decision: 'reject', actorId: 'human',
  });
  const cancelled = await store.get(mission.id);
  check('rejecting an approval cancels the mission', cancelled?.status === 'CANCELLED');

  let refused = false;
  try {
    await harness.requestTool({
      missionId: mission.id, id: 'tc-after', capabilityId: 'fs.read', arguments: { path: '/tmp/y' },
    });
  } catch { refused = true; }
  check('a cancelled mission refuses a granted read capability', refused);
}

console.log('\n4. Declared input schemas are enforced\n');

{
  // ATTACK: send arguments that do not satisfy the declared inputSchema.
  const { harness, mission } = await boot();
  let refused = false;
  try {
    const result = await harness.requestTool({
      missionId: mission.id, id: 'tc-junk', capabilityId: 'fs.read',
      arguments: { unexpected: [1, 2, {}], path: null },
    });
    refused = result.authorization.decision === 'deny';
  } catch { refused = true; }
  check('arguments that violate the declared inputSchema are refused', refused);
}

console.log('\n5. A refused request is still auditable\n');

{
  // Regression guard, not an attack. Budget denials ARE currently logged --
  // requestTool wraps ledger.consume in a try/catch that appends a
  // tool_requested event with budgetRejected before rethrowing. This check
  // exists so that behaviour cannot be silently lost in a later refactor.
  const { harness, mission, store } = await boot({ maxToolCalls: 1 });
  await harness.requestTool({
    missionId: mission.id, id: 'tc-1', capabilityId: 'fs.read', arguments: { path: '/tmp/a' },
  });
  try {
    await harness.requestTool({
      missionId: mission.id, id: 'tc-2', capabilityId: 'fs.read', arguments: { path: '/tmp/b' },
    });
  } catch { /* expected */ }
  const events = await store.listEvents(mission.id);
  check(
    'a budget-denied request writes an audit event',
    events.some((event) => event.payload?.budgetRejected === true),
  );
}

console.log(`\n${passed} passed, ${failed} failed`);
console.log(
  failed === 0
    ? 'The declared authority boundary held against every attack in this file.'
    : 'One or more attacks succeeded. Each failure above is a live authority hole.',
);
console.log(
  '\nCeiling: this file proves a grant is the only way IN to a tool. It cannot\n' +
  'see a pilot that holds its own credentials or imports a tool module directly.\n' +
  'That last step is an import-boundary check in CI, not a test here.',
);
process.exit(failed === 0 ? 0 : 1);
