/**
 * collective-admission.test.mjs — harness -> collective wiring
 *
 * Verifies:
 *  - http.fetch with bodyHash mints structural witness and admits returns_status fact
 *  - same URL same status corroborated, different status conflicts -> quarantine
 *  - browser.read_page / snapshot admit exists fact with structural witness
 *  - pilot never supplies fact or witness — plumbing derives from bytes it observed
 *  - refusal behavior unchanged: no fact admitted when tool fails
 */

import assert from 'node:assert/strict'
import { HarnessRuntime, InMemoryMissionStore } from '../harness/runtime.ts'
import { httpPack } from '../harness/packs/http-pack.ts'
import { browserPack, BrowserPack } from '../harness/packs/browser-pack.ts'
import { Collective } from './store.ts'

let passed = 0, failed = 0
const failures = []
function test(name, fn) { try { fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }
async function atest(name, fn) { try { await fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) } }

function mockFetch(bodyText, status = 200) {
  const bytes = new TextEncoder().encode(bodyText)
  return async () => ({
    status,
    statusText: status === 200 ? 'OK' : 'Not Found',
    headers: { get: () => 'text/plain', entries: function* () { yield ['content-type', 'text/plain'] } },
    body: {
      getReader() {
        let done = false
        return {
          read() {
            if (done) return Promise.resolve({ done: true })
            done = true
            return Promise.resolve({ done: false, value: bytes })
          },
        }
      },
    },
  })
}

function makeBridge(responses = {}) {
  return {
    invoke(tool, args) {
      const r = responses[tool]
      return Promise.resolve(typeof r === 'function' ? r(args) : r)
    },
  }
}

await atest('http.fetch admits returns_status fact into collective with structural witness', async () => {
  const origFetch = globalThis.fetch
  globalThis.fetch = mockFetch('hello body', 200)
  try {
    const collective = new Collective()
    const store = new InMemoryMissionStore()
    const rt = new HarnessRuntime({
      store,
      collective,
      passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
      harnessId: 'harness-collective-test',
    })
    rt.mount(httpPack())
    const mission = await rt.createMission({
      goal: 'test collective admission',
      passportId: 'p1',
      authority: { actorId: 'tester', allowedCapabilityIds: ['http.fetch'], autoApproveRiskAtMost: 'external_side_effect' },
    })
    await rt.bindNeuralink(mission.id)
    await rt.beginPlanning(mission.id)

    const result = await rt.runTool({ missionId: mission.id, capabilityId: 'http.fetch', arguments: { url: 'https://api.example.com/v1/charges' } })
    assert.equal(result.status, 'succeeded')
    assert.ok(result.structuralWitness, 'no structural witness')

    // collective should have one fact: endpoint returns_status 200
    assert.equal(collective.size(), 1, `collective size ${collective.size()} expected 1`)
    const facts = collective.bySubject('endpoint:https://api.example.com/v1/charges')
    assert.equal(facts.length, 1)
    assert.equal(facts[0].predicate, 'returns_status')
    assert.equal(facts[0].value, 200)
    assert.equal(facts[0].witnesses[0].kind, 'structural')
    assert.match(facts[0].witnesses[0].reference, /^sha256:[a-f0-9]{64}$/)

    // second fetch same URL same status same body -> fact already held, same harness same structural ref -> not double-counted (gate dedup)
    // Change second body to different bytes but same status -> different structural ref -> corroborates
    globalThis.fetch = mockFetch('hello body v2 different bytes', 200)
    const result2 = await rt.runTool({ missionId: mission.id, capabilityId: 'http.fetch', arguments: { url: 'https://api.example.com/v1/charges' } })
    assert.equal(collective.size(), 1, 'corroboration should not increase size for same endpoint+status')
    assert.equal(collective.bySubject('endpoint:https://api.example.com/v1/charges')[0].witnesses.length, 2, 'different body same status should corroborate with new structural witness')
  } finally {
    globalThis.fetch = origFetch
  }
})

await atest('different status for same endpoint are both held (returns_status is multi-valued), not conflict', async () => {
  const origFetch = globalThis.fetch
  const collective = new Collective()
  const store = new InMemoryMissionStore()
  const rt = new HarnessRuntime({
    store,
    collective,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
    harnessId: 'harness-conflict-test',
  })
  rt.mount(httpPack())

  // first 200
  globalThis.fetch = mockFetch('body', 200)
  const m = await rt.createMission({
    goal: 'conflict test',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['http.fetch'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await rt.bindNeuralink(m.id); await rt.beginPlanning(m.id)
  await rt.runTool({ missionId: m.id, capabilityId: 'http.fetch', arguments: { url: 'https://api.example.com/v1/conflict' } })

  // second 404 same endpoint -> NOT conflict because returns_status is multi-valued
  globalThis.fetch = mockFetch('not found', 404)
  await rt.runTool({ missionId: m.id, capabilityId: 'http.fetch', arguments: { url: 'https://api.example.com/v1/conflict' } })

  // Both statuses held
  assert.equal(collective.size(), 2, 'both 200 and 404 should be held (multi-valued)')
  assert.equal(collective.isQuarantined('endpoint:https://api.example.com/v1/conflict'), false, 'multi-valued predicate should not quarantine')

  // Now directly test conflict via single-valued predicate (rate_limit_per_min)
  const { admit } = await import('./gate.ts')
  const { createPlumbingWitness } = await import('./witness.ts')
  const w1 = createPlumbingWitness({ kind: 'structural', harnessId: 'h1', reference: 'sha256:' + 'a'.repeat(64) })
  const w2 = createPlumbingWitness({ kind: 'structural', harnessId: 'h2', reference: 'sha256:' + 'b'.repeat(64) })
  const v1 = admit({ subject: 'endpoint:https://api.example.com/v1/conflict', predicate: 'rate_limit_per_min', value: 60, witness: w1, stability: 'contingent' }, collective)
  assert.equal(v1.status, 'admitted')
  const v2 = admit({ subject: 'endpoint:https://api.example.com/v1/conflict', predicate: 'rate_limit_per_min', value: 120, witness: w2, stability: 'contingent' }, collective)
  assert.equal(v2.status, 'conflict')
  collective.recordConflict(v2.incumbent, v2.challenger)
  assert.equal(collective.isQuarantined('endpoint:https://api.example.com/v1/conflict'), true, 'single-valued conflict should quarantine')
  globalThis.fetch = origFetch
})

await atest('browser.read_page admits exists fact with structural witness', async () => {
  const bridge = makeBridge({
    'browser.read_page': { url: 'https://example.com/page', title: 'T', text: 'page content for collective' },
  })
  BrowserPack.setBridge(bridge)

  const collective = new Collective()
  const store = new InMemoryMissionStore()
  const rt = new HarnessRuntime({
    store,
    collective,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
    harnessId: 'harness-browser-collective',
  })
  rt.mount(browserPack())
  const m = await rt.createMission({
    goal: 'browser collective',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['browser.read_page'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await rt.bindNeuralink(m.id); await rt.beginPlanning(m.id)
  const result = await rt.runTool({ missionId: m.id, capabilityId: 'browser.read_page', arguments: {} })
  assert.ok(result.structuralWitness)
  assert.equal(collective.size(), 1)
  const facts = collective.bySubject('page:https://example.com/page')
  assert.equal(facts.length, 1)
  assert.equal(facts[0].predicate, 'exists')
})

await atest('no collective mounted still works — no admission attempted', async () => {
  const bridge = makeBridge({
    'browser.read_page': { url: 'https://example.com', title: 'T', text: 'hello' },
  })
  BrowserPack.setBridge(bridge)

  const store = new InMemoryMissionStore()
  const rt = new HarnessRuntime({
    store,
    passport: { loadContext: async () => ({ passportId: 'p1', identity: {}, memories: [], digest: 'x' }) },
    harnessId: 'harness-no-collective',
  })
  rt.mount(browserPack())
  const m = await rt.createMission({
    goal: 'no collective',
    passportId: 'p1',
    authority: { actorId: 'tester', allowedCapabilityIds: ['browser.read_page'], autoApproveRiskAtMost: 'external_side_effect' },
  })
  await rt.bindNeuralink(m.id); await rt.beginPlanning(m.id)
  const result = await rt.runTool({ missionId: m.id, capabilityId: 'browser.read_page', arguments: {} })
  assert.equal(result.status, 'succeeded')
  assert.equal(rt.getCollective(), undefined)
})

console.log(`\ncollective-admission: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
