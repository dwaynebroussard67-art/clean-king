/**
 * gate.ts — the only door into the collective.
 *
 * Four checks, in order, all deterministic. No model is consulted at any
 * point. A fact is admitted, corroborated, refused, or flagged as a
 * conflict. The gate never repairs, averages, or negotiates.
 *
 *   1. WELL-FORMED    — is this even a fact-shaped thing?
 *   2. WITNESSED      — can someone point at what made it true?
 *   3. SELF-CONSISTENT— is it internally possible on its own terms?
 *   4. CONSISTENT     — does it contradict anything already held?
 *
 * Check 2 is the one that stops a well-formed lie. Check 4 is the one that
 * stops a real observation from silently overwriting a real prior fact.
 * Neither alone is sufficient. Both, always, in this order.
 *
 * Ordering matters for cost, not just correctness: 1-3 are local to the
 * record, 4 requires a store lookup. Cheap checks first.
 *
 * Witness validation is shared with witness.ts — the gate and the plumbing
 * use one definition, so a fabricated witness cannot pass by exploiting a
 * mismatch between what the harness mints and what the gate checks.
 */

import { createHash } from 'crypto'
import type {
  FactRecord,
  EstablishedFact,
  AdmitVerdict,
  Predicate,
  FactValue,
  Witness,
  WitnessKind,
} from './types.ts'
import { validateWitnessReference } from './witness.ts'

// ── Predicate contracts ───────────────────────────────────────────────────
// Each predicate declares what value type it takes and which predicates it
// is mutually exclusive with. This table IS the contradiction logic — there
// is no reasoning, only a lookup.

interface PredicateContract {
  valueType: 'string' | 'number' | 'boolean'
  /** Predicates that cannot both hold for the same subject+value. */
  excludes: Predicate[]
  /** If true, a subject may hold only ONE fact with this predicate
   *  (e.g. rate_limit_per_min). A second, different value is a conflict.
   *  If false, many can coexist (e.g. accepts_field: many fields). */
  singleValued: boolean
  /** Optional extra validation on the value itself. */
  validate?: (v: FactValue) => string | null
}

export const PREDICATES: Record<Predicate, PredicateContract> = {
  accepts_field: {
    valueType: 'string',
    excludes: ['rejects_field'],
    singleValued: false,
  },
  rejects_field: {
    valueType: 'string',
    excludes: ['accepts_field', 'requires_field'],
    singleValued: false,
  },
  requires_field: {
    valueType: 'string',
    excludes: ['rejects_field'],
    singleValued: false,
  },
  field_type: {
    valueType: 'string',
    excludes: [],
    singleValued: true,
  },
  field_max_length: {
    valueType: 'number',
    excludes: [],
    singleValued: true,
    validate: v => (typeof v === 'number' && v >= 0 ? null : 'must be >= 0'),
  },
  field_min_length: {
    valueType: 'number',
    excludes: [],
    singleValued: true,
    validate: v => (typeof v === 'number' && v >= 0 ? null : 'must be >= 0'),
  },
  allows_method: {
    valueType: 'string',
    excludes: ['denies_method'],
    singleValued: false,
  },
  denies_method: {
    valueType: 'string',
    excludes: ['allows_method'],
    singleValued: false,
  },
  rate_limit_per_min: {
    valueType: 'number',
    excludes: [],
    singleValued: true,
    validate: v => (typeof v === 'number' && v > 0 ? null : 'must be > 0'),
  },
  returns_status: {
    valueType: 'number',
    excludes: [],
    singleValued: false,
    validate: v =>
      typeof v === 'number' && v >= 100 && v <= 599 ? null : 'not an HTTP status',
  },
  element_has_id: {
    valueType: 'string',
    excludes: ['element_absent'],
    singleValued: false,
  },
  element_absent: {
    valueType: 'string',
    excludes: ['element_has_id'],
    singleValued: false,
  },
  exists: {
    valueType: 'boolean',
    excludes: ['not_exists'],
    singleValued: true,
  },
  not_exists: {
    valueType: 'boolean',
    excludes: ['exists'],
    singleValued: true,
  },
}

// ── Witness rules ─────────────────────────────────────────────────────────
// Shared definition lives in witness.ts — gate and plumbing use one source
// so a forged witness cannot exploit a mismatch.

const WITNESS_KINDS: WitnessKind[] = ['outcome', 'structural', 'contract', 'human']

function checkWitness(w: Witness | undefined): string | null {
  if (!w || typeof w !== 'object') return 'no witness attached'
  if (!WITNESS_KINDS.includes(w.kind)) return `unknown witness kind: ${w.kind}`
  if (typeof w.harnessId !== 'string' || !w.harnessId.trim())
    return 'witness has no harness id'
  if (typeof w.observedAt !== 'string' || Number.isNaN(Date.parse(w.observedAt)))
    return 'witness observedAt is not a valid timestamp'
  const refProblem = validateWitnessReference(w.kind, w.reference)
  if (refProblem) return refProblem
  return null
}

// ── Fact identity ─────────────────────────────────────────────────────────

/**
 * Deterministic id over subject+predicate+value ONLY.
 * Deliberately excludes the witness: the same fact witnessed by two
 * different harnesses must produce the same id, so corroboration is a
 * lookup rather than a similarity judgement.
 */
export function factId(
  subject: string,
  predicate: Predicate,
  value: FactValue
): string {
  const canonical = JSON.stringify([subject, predicate, typeof value, value])
  return createHash('sha256').update(canonical).digest('hex').slice(0, 24)
}

// ── The store interface the gate needs ────────────────────────────────────
// Kept minimal and injected, so the gate is testable without a database
// and so the storage layer can be swapped without touching this logic.

export interface FactStore {
  get(id: string): EstablishedFact | undefined
  /** All held facts for a subject, any predicate. */
  bySubject(subject: string): EstablishedFact[]
  put(fact: EstablishedFact): void
  isQuarantined(subject: string): boolean
}

// ── The gate ──────────────────────────────────────────────────────────────

export function admit(record: FactRecord, store: FactStore): AdmitVerdict {
  // ── 1. WELL-FORMED ──────────────────────────────────────────────────────
  if (!record || typeof record !== 'object')
    return refuse('MALFORMED', 'record is not an object')

  if (typeof record.subject !== 'string' || !record.subject.trim())
    return refuse('MALFORMED', 'subject missing')

  const contract = PREDICATES[record.predicate]
  if (!contract)
    return refuse('UNKNOWN_PREDICATE', `"${record.predicate}" is not in the vocabulary`)

  if (typeof record.value !== contract.valueType)
    return refuse(
      'TYPE_MISMATCH',
      `${record.predicate} takes ${contract.valueType}, got ${typeof record.value}`
    )

  if (record.stability !== 'invariant' && record.stability !== 'contingent')
    return refuse('MALFORMED', 'stability must be invariant or contingent')

  // ── 2. WITNESSED ────────────────────────────────────────────────────────
  // Before anything else about truth: who says so, and how do we re-check?
  const witnessProblem = checkWitness(record.witness)
  if (witnessProblem) return refuse('UNWITNESSED', witnessProblem)

  // ── 3. SELF-CONSISTENT ──────────────────────────────────────────────────
  // Impossible on its own terms, before it ever meets the store.
  const valueProblem = contract.validate?.(record.value)
  if (valueProblem)
    return refuse('SELF_INCONSISTENT', `${record.predicate}: ${valueProblem}`)

  // ── 4. CONSISTENT WITH WHAT IS HELD ─────────────────────────────────────
  if (store.isQuarantined(record.subject))
    return refuse(
      'SUBJECT_QUARANTINED',
      `${record.subject} has an unresolved conflict; nothing enters until a human rules`
    )

  const id = factId(record.subject, record.predicate, record.value)

  // Already held? Corroborate — append the witness, change nothing else.
  // Note: corroboration does NOT increase confidence. The fact was already
  // established. More witnesses only make a future conflict cheaper to trace.
  const existing = store.get(id)
  if (existing) {
    const already = existing.witnesses.some(
      w => w.harnessId === record.witness.harnessId && w.reference === record.witness.reference
    )
    if (!already) existing.witnesses.push(record.witness)
    return { status: 'corroborated', fact: existing }
  }

  // Does it contradict something held about this subject?
  const held = store.bySubject(record.subject)

  for (const other of held) {
    // (a) Mutually exclusive predicates over the same value.
    //     "accepts_field: d" vs "rejects_field: d" — same subject, same value.
    if (contract.excludes.includes(other.predicate) && other.value === record.value) {
      return { status: 'conflict', incumbent: other, challenger: record }
    }

    // (b) Single-valued predicate already holds a different value.
    //     rate_limit_per_min cannot be both 60 and 120.
    if (
      contract.singleValued &&
      other.predicate === record.predicate &&
      other.value !== record.value
    ) {
      return { status: 'conflict', incumbent: other, challenger: record }
    }
  }

  // (c) Cross-predicate numeric coherence: min cannot exceed max.
  //     Checked after the loop because it needs the pair, not one fact.
  const numericProblem = checkNumericCoherence(record, held)
  if (numericProblem) {
    return { status: 'conflict', incumbent: numericProblem, challenger: record }
  }

  // ── Admitted ────────────────────────────────────────────────────────────
  const fact: EstablishedFact = {
    ...record,
    factId: id,
    witnesses: [record.witness],
    admittedAt: new Date().toISOString(),
  }
  store.put(fact)
  return { status: 'admitted', fact }
}

// ── Helpers ───────────────────────────────────────────────────────────────

function refuse(
  reason: Extract<AdmitVerdict, { status: 'refused' }>['reason'],
  detail: string
): AdmitVerdict {
  return { status: 'refused', reason, detail }
}

/**
 * min_length > max_length is impossible, but neither fact is wrong on its
 * own — it only shows up as a pair. Returns the incumbent it conflicts with,
 * or null.
 */
function checkNumericCoherence(
  record: FactRecord,
  held: EstablishedFact[]
): EstablishedFact | null {
  if (record.predicate === 'field_min_length') {
    const max = held.find(f => f.predicate === 'field_max_length')
    if (max && typeof max.value === 'number' && (record.value as number) > max.value) {
      return max
    }
  }
  if (record.predicate === 'field_max_length') {
    const min = held.find(f => f.predicate === 'field_min_length')
    if (min && typeof min.value === 'number' && (record.value as number) < min.value) {
      return min
    }
  }
  return null
}
