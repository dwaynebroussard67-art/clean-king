import { digest } from './neuralink.ts';
import type {
  CapabilityDescriptor,
  MissionAuthority,
  ToolCall,
  ToolRisk,
} from './contracts.ts';

const RISK_RANK: Record<ToolRisk, number> = {
  read: 0,
  transform: 1,
  create: 2,
  update: 3,
  delete: 4,
  external_side_effect: 5,
};

export type AuthorizationResult = {
  decision: 'allow' | 'require_approval' | 'deny';
  reason: string;
};

export class CapabilityRegistry {
  private readonly descriptors = new Map<string, CapabilityDescriptor>();

  register(descriptor: CapabilityDescriptor): void {
    if (this.descriptors.has(descriptor.id)) throw new Error(`capability already registered: ${descriptor.id}`);
    this.descriptors.set(descriptor.id, descriptor);
  }

  /** Is this capability known to the harness at all, pack-provided or not? */
  has(id: string): boolean {
    return this.descriptors.has(id);
  }

  get(id: string): CapabilityDescriptor {
    const descriptor = this.descriptors.get(id);
    if (!descriptor) throw new Error(`capability not found: ${id}`);
    return descriptor;
  }

  list(): CapabilityDescriptor[] {
    return [...this.descriptors.values()].sort((a, b) => a.id.localeCompare(b.id));
  }

  /**
   * Authorization is a pure function of the grant and the declared risk.
   *
   * There is deliberately no dry-run branch here. Dry run used to be a flag the
   * REQUESTER supplied, and it returned before the risk ceiling was consulted --
   * so a caller could declare a dry run, receive a non-approval decision, and
   * then perform the real side effect. Dry run is now an execution mode owned by
   * the harness (see ToolExecutor), it is fixed for the whole mission, and it
   * never lowers what a capability requires.
   */
  authorize(
    capabilityId: string,
    authority: MissionAuthority,
  ): AuthorizationResult {
    const descriptor = this.get(capabilityId);
    if (!authority.allowedCapabilityIds.includes(capabilityId)) {
      return { decision: 'deny', reason: 'capability is not granted to this mission authority' };
    }
    const ceiling = authority.autoApproveRiskAtMost;
    if (!descriptor.requiresApproval && ceiling && RISK_RANK[descriptor.risk] <= RISK_RANK[ceiling]) {
      return { decision: 'allow', reason: `risk ${descriptor.risk} is within the authority ceiling` };
    }
    if (!descriptor.requiresApproval && descriptor.risk === 'read') {
      return { decision: 'allow', reason: 'read capability does not change external state' };
    }
    return { decision: 'require_approval', reason: `risk ${descriptor.risk} requires a human approval` };
  }
}

export function createToolCall(input: {
  id: string;
  missionId: string;
  capabilityId: string;
  arguments: Record<string, unknown>;
  requestedAt: string;
}): ToolCall {
  return {
    ...input,
    argumentsDigest: digest(input.arguments),
  };
}
