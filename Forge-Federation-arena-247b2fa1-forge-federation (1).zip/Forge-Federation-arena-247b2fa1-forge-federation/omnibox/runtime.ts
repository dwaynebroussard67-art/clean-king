import { randomUUID } from 'node:crypto';
import type {
  ApprovalDecision,
  HarnessClock,
  MissionEvent,
  MissionRecord,
  MissionSpec,
  ContextFrameStore,
  MissionStore,
  RunRecord,
  RunStore,
  RunStatus,
  NeuralinkDecision,
  ObservedHarnessEvent,
  PassportAdapter,
  ContextFrame,
  ToolCall,
  CapabilityDescriptor,
} from './contracts.ts';
import { createMissionRecord, transitionMission, assertResumable, isTerminal } from './state-machine.ts';
import { NeuralinkSession } from './neuralink.ts';
import { CapabilityRegistry, createToolCall } from './capabilities.ts';
import { assertValid } from './schema.ts';
import {
  ToolExecutor,
  ExecutionRefused,
  type CapabilityHandle,
  type ExecutionMode,
  type ExecutionResult,
} from './executor.ts';
import { PackRegistry, type CapabilityPack, type Skill, type SkillStep } from './packs.ts';
import { FlightRecorder } from './flight-recorder.ts';
// The cockpit (COCKPIT-HANDOFF, step 2): seat state follows mission state.
// missionStarted flips seated -> flying; missionEnded flips flying -> seated
// and counts the mission. The cockpit is a passive observer here — it never
// affects a transition or an execution decision (C8: learning never triggers
// execution; cockpit wiring changes no authority).
import { neuralink as cockpit } from './cockpit.ts';
import {
  BudgetLedger,
  MissionComputer,
} from './mission-computer.ts';
import type {
  BudgetUsage,
  MissionEvaluation,
  MissionEvaluationInput,
  MissionPlan,
} from './mission-computer.ts';
import { createPlumbingWitness, structuralWitness } from '../collective/witness.ts';
import type { Witness } from '../collective/types.ts';
import { Collective } from '../collective/store.ts';
import { admit } from '../collective/gate.ts';
import { deriveFacts } from '../collective/collective-admission.ts';

function defaultClock(): Date {
  return new Date();
}

export class InMemoryMissionStore implements MissionStore, RunStore, ContextFrameStore {
  private readonly missions = new Map<string, MissionRecord>();
  private readonly runs = new Map<string, RunRecord>();
  private readonly frames = new Map<string, ContextFrame>();
  private readonly events = new Map<string, MissionEvent[]>();

  async create(mission: MissionRecord): Promise<void> {
    if (this.missions.has(mission.id)) throw new Error(`mission already exists: ${mission.id}`);
    this.missions.set(mission.id, mission);
    this.events.set(mission.id, []);
  }

  async get(id: string): Promise<MissionRecord | null> {
    return this.missions.get(id) ?? null;
  }

  async save(mission: MissionRecord, expectedRevision?: number): Promise<void> {
    const existing = this.missions.get(mission.id);
    if (!existing) throw new Error(`mission not found: ${mission.id}`);
    if (expectedRevision !== undefined && existing.revision !== expectedRevision) {
      throw new Error(`mission revision conflict: ${mission.id}`);
    }
    this.missions.set(mission.id, mission);
  }

  async createRun(run: RunRecord): Promise<void> {
    if (this.runs.has(run.id)) throw new Error(`run already exists: ${run.id}`);
    if (!this.missions.has(run.missionId)) throw new Error(`mission not found: ${run.missionId}`);
    this.runs.set(run.id, run);
  }

  async getRun(id: string): Promise<RunRecord | null> {
    return this.runs.get(id) ?? null;
  }

  async getLatestRun(missionId: string): Promise<RunRecord | null> {
    return [...this.runs.values()]
      .filter((run) => run.missionId === missionId)
      .sort((a, b) => b.attempt - a.attempt || b.createdAt.localeCompare(a.createdAt))[0] ?? null;
  }

  async saveRun(run: RunRecord): Promise<void> {
    if (!this.runs.has(run.id)) throw new Error(`run not found: ${run.id}`);
    this.runs.set(run.id, run);
  }

  async saveContextFrame(input: { runId: string; missionId: string; passportId: string; frame: ContextFrame }): Promise<void> {
    this.frames.set(input.runId, input.frame);
  }

  async loadLatestContextFrame(runId: string): Promise<ContextFrame | null> {
    return this.frames.get(runId) ?? null;
  }

  async appendEvent(event: MissionEvent): Promise<MissionEvent> {
    const events = this.events.get(event.missionId);
    if (!events) throw new Error(`mission not found: ${event.missionId}`);
    const existingById = events.find((existing) => existing.id === event.id);
    if (existingById) return existingById;
    const sequence = events.some((existing) => existing.sequence === event.sequence)
      ? events.reduce((max, existing) => Math.max(max, existing.sequence + 1), 0)
      : event.sequence;
    const stored = sequence === event.sequence ? event : { ...event, sequence };
    events.push(stored);
    return stored;
  }

  async listEvents(missionId: string): Promise<MissionEvent[]> {
    return [...(this.events.get(missionId) ?? [])].sort((a, b) => a.sequence - b.sequence);
  }
}

export type HarnessRuntimeOptions = {
  store: MissionStore & RunStore & ContextFrameStore;
  passport: PassportAdapter;
  capabilities?: CapabilityRegistry;
  executor?: ToolExecutor;
  clock?: HarnessClock;
  idFactory?: () => string;
  runIdFactory?: () => string;
  /**
   * Fixed for the whole harness, decided by the operator, never by a caller and
   * never per-request. In 'dry_run' every tool is asked to describe what it
   * WOULD do. It does not lower what any capability requires.
   */
  mode?: ExecutionMode;
  /** Stable identity for this harness instance — the witness's harnessId. Pilot never sees or supplies it. */
  harnessId?: string;
  /** Optional collective for auto-admission of facts derived from content hashes. Plumbing-only. */
  collective?: Collective;
};

/** A pending approval, bound to the exact arguments that were presented. */
type PendingApproval = {
  toolCallId: string;
  capabilityId: string;
  argumentsDigest: string;
  requestedAt: string;
};

/**
 * Small, framework-independent harness runtime. It is intentionally backed by
 * interfaces so the first tests can use in-memory adapters while production
 * replaces them with PostgreSQL-backed stores and an MCP capability registry.
 */
export class CapabilityUnavailable extends Error {
  readonly code = 'CAPABILITY_UNAVAILABLE';
  readonly capabilityId: string;
  readonly reason: 'not_mounted' | 'not_granted';

  constructor(capabilityId: string, reason: 'not_mounted' | 'not_granted') {
    // Deliberately phrased as a fact about the plane, not a rebuke of the
    // pilot. The pilot did nothing wrong by asking.
    super(`this harness does not carry ${capabilityId}; the request was recorded as a gap`);
    this.name = 'CapabilityUnavailable';
    this.capabilityId = capabilityId;
    this.reason = reason;
  }
}

export class HarnessRuntime {
  private readonly clock: HarnessClock;
  private readonly idFactory: () => string;
  private readonly runIdFactory: () => string;
  private readonly sessions = new Map<string, NeuralinkSession>();
  private readonly runIds = new Map<string, string>();
  private readonly missionComputer = new MissionComputer();
  private readonly plans = new Map<string, MissionPlan>();
  private readonly budgets = new Map<string, BudgetLedger>();
  private readonly options: HarnessRuntimeOptions;
  private readonly executor: ToolExecutor;
  private readonly packs: PackRegistry;
  private readonly mode: ExecutionMode;
  /** Stable harness identity — plumbing's signer for witnesses. Never supplied by a pilot. */
  private readonly harnessId: string;
  /** Optional collective — if present, structural witnesses auto-admit derived facts. Plumbing-only. */
  private readonly collective?: Collective;
  /** missionId -> toolCallId -> pending approval. Approvals are argument-bound. */
  private readonly pendingApprovals = new Map<string, Map<string, PendingApproval>>();
  private lastApprovedDigest: string | undefined;
  private readonly recorder = new FlightRecorder();

  constructor(options: HarnessRuntimeOptions) {
    this.options = options;
    this.clock = options.clock ?? defaultClock;
    this.idFactory = options.idFactory ?? randomUUID;
    this.runIdFactory = options.runIdFactory ?? randomUUID;
    this.executor = options.executor ?? new ToolExecutor();
    this.mode = options.mode ?? 'execute';
    this.harnessId = options.harnessId ?? `harness-${randomUUID().slice(0, 8)}`;
    this.collective = options.collective;
    if (!this.options.capabilities) this.options.capabilities = new CapabilityRegistry();
    this.packs = new PackRegistry(this.options.capabilities, this.executor);
  }

  /** Expose collective for inspection (read-only). Pilot never receives this. */
  getCollective(): Collective | undefined { return this.collective }

  /** The plumbing's identity — what every witness it mints carries. */
  getHarnessId(): string { return this.harnessId }

  /**
   * Mint a plumbing witness for a tool invocation. Pilot code never calls this.
   * The reference is `${missionId}:${toolCallId}` — the plumbing's own ids,
   * not anything the pilot supplied.
   */
  mintPlumbingWitness(toolCall: ToolCall, observedAt?: string): Witness {
    return createPlumbingWitness({
      kind: 'outcome',
      harnessId: this.harnessId,
      reference: `${toolCall.missionId}:${toolCall.id}`,
      observedAt: observedAt ?? this.clock().toISOString(),
    })
  }

  /** Mount a capability pack. Mounting says what EXISTS; it grants nothing. */
  mount(pack: CapabilityPack): void {
    this.packs.mount(pack);
  }

  listPacks() { return this.packs.listPacks(); }

  /** Everything mounted on this plane. Distinct from what a mission is granted. */
  listCapabilities() { return this.packs.listCapabilities(); }

  listSkills() { return this.packs.listSkills(); }

  /** Outstanding argument-bound approvals. A view, never a grant. */
  pendingApprovalsFor(missionId: string) {
    return [...this.pendingFor(missionId).values()].map((entry) => ({ ...entry }));
  }

  /** What this mission's authority actually reaches. A view, never a grant. */
  async capabilityManifest(missionId: string): Promise<CapabilityDescriptor[]> {
    const mission = await this.requireMission(missionId);
    return this.packs.manifestFor(mission.authority);
  }

  /** Skills whose every required capability is both mounted and granted. */
  async availableSkills(missionId: string): Promise<Skill[]> {
    const mission = await this.requireMission(missionId);
    return this.packs.runnableSkills(mission.authority);
  }

  /** Expand a skill template into concrete steps. Touches no tool. */
  planSkill(skillId: string, inputs: Record<string, unknown> = {}): SkillStep[] {
    return this.packs.planSkill(skillId, inputs);
  }

  /**
   * What a pilot is handed. Each handle can do exactly one thing: ask the
   * harness to run one granted capability on one mission. It carries no
   * implementation, no registry and no credentials, so a pilot given only
   * handles has no second path to a tool. That is the property the executor
   * exists to make true, and it is checkable in CI as a boundary rule: the
   * pilot module imports neither ToolExecutor nor any pack.
   */
  async handlesFor(missionId: string): Promise<CapabilityHandle[]> {
    const mission = await this.requireMission(missionId);
    return this.packs.manifestFor(mission.authority).map((descriptor) => ({
      capabilityId: descriptor.id,
      name: descriptor.name,
      description: descriptor.description,
      risk: descriptor.risk,
      inputSchema: descriptor.inputSchema,
      invoke: (args: Record<string, unknown>) => this.runTool({
        missionId,
        capabilityId: descriptor.id,
        arguments: args,
      }),
    }));
  }

  async createMission(spec: MissionSpec): Promise<MissionRecord> {
    const id = this.idFactory();
    const mission = createMissionRecord({ id, ...spec }, this.clock);
    await this.options.store.create(mission);
    await this.appendCreatedEvent(mission);
    const now = this.clock().toISOString();
    const run: RunRecord = {
      id: this.runIdFactory(),
      missionId: mission.id,
      attempt: 1,
      status: 'CREATED',
      state: {},
      checkpoint: {},
      idempotencyKey: `${mission.id}:attempt:1`,
      createdAt: now,
      updatedAt: now,
    };
    await this.options.store.createRun(run);
    this.runIds.set(mission.id, run.id);
    this.budgets.set(mission.id, new BudgetLedger(mission.budget ?? {}));
    return mission;
  }

  async bindNeuralink(missionId: string): Promise<{ mission: MissionRecord; context: ContextFrame }> {
    const mission = await this.requireMission(missionId);
    const bound = await this.advance(mission, 'NEURALINK_BOUND', 'harness');
    const plan = await this.getPlan(missionId);
    this.plans.set(missionId, plan);
    const plannedMission = {
      ...bound.mission,
      metadata: { ...bound.mission.metadata, missionPlan: plan },
    };
    await this.options.store.save(plannedMission, bound.mission.revision);
    const session = new NeuralinkSession(this.options.passport, {}, this.clock);
    const context = await session.bind(plannedMission);
    this.sessions.set(missionId, session);
    const run = await this.getRun(missionId);
    await this.options.store.saveContextFrame({
      runId: run.id,
      missionId,
      passportId: plannedMission.passportId,
      frame: context,
    });
    const ready = await this.advance(
      { ...plannedMission, contextDigest: context.digest },
      'CONTEXT_READY',
      'neuralink',
      { contextDigest: context.digest, step: 'context_compiled' },
    );
    return { mission: ready.mission, context };
  }

  async beginPlanning(missionId: string): Promise<MissionRecord> {
    await this.getPlan(missionId);
    return (await this.advance(await this.requireMission(missionId), 'PLANNING', 'harness')).mission;
  }

  async getPlan(missionId: string): Promise<MissionPlan> {
    const cached = this.plans.get(missionId);
    if (cached) return cached;
    const mission = await this.requireMission(missionId);
    const stored = mission.metadata?.missionPlan as MissionPlan | undefined;
    const plan = stored?.schema === 'omnibox.mission-plan.v1'
      ? stored
      : this.missionComputer.plan(mission, this.clock);
    this.plans.set(missionId, plan);
    if (!stored) {
      await this.options.store.save({
        ...mission,
        metadata: { ...mission.metadata, missionPlan: plan },
      }, mission.revision);
    }
    return plan;
  }

  async requestApproval(missionId: string, payload: Record<string, unknown>): Promise<MissionRecord> {
    return (await this.advance(
      await this.requireMission(missionId),
      'WAITING_APPROVAL',
      'policy',
      { ...payload, step: 'approval_requested' },
    )).mission;
  }

  async decideApproval(missionId: string, decision: ApprovalDecision): Promise<MissionRecord> {
    const mission = await this.requireMission(missionId);

    // A terminal mission cannot be decided on. Without this guard a decision
    // arriving after cancellation either crashed on an illegal transition
    // (CANCELLED has no outbound edges in the state machine) or, worse, could
    // have issued a live grant for a mission that no longer holds any tool
    // authority. executeAuthorized() would still refuse that grant -- but a
    // human approving something and being told it crashed, rather than that it
    // was refused, is its own failure.
    if (isTerminal(mission.status)) {
      this.pendingFor(missionId).delete(decision.toolCallId);
      this.executor.revoke(decision.toolCallId);
      throw new ExecutionRefused(
        `mission ${missionId} is ${mission.status}; no approval can be decided on a terminal mission`,
      );
    }

    // An approval authorizes ONE outstanding request. Without this check the
    // harness accepted an approvalId and toolCallId that were never issued and
    // advanced the mission to RUNNING on the strength of them.
    const outstanding = this.pendingFor(missionId).get(decision.toolCallId);
    if (!outstanding) {
      throw new ExecutionRefused(
        `no approval is outstanding for tool call ${decision.toolCallId} on mission ${missionId}`,
      );
    }

    const run = await this.getRun(missionId);
    const pending = ((run.state.pendingToolBudgets ?? {}) as Record<string, BudgetUsage>)[decision.toolCallId];
    if (decision.decision === 'approve' || decision.decision === 'edit') {
      if (pending) {
        const ledger = await this.budgetFor(mission);
        ledger.consume(pending);
        await this.persistBudget(missionId, ledger);
      }

      // An edit re-binds the grant to the arguments that were ACTUALLY
      // approved, not the ones that were requested. The digest is what the
      // executor checks, so an approval for a benign call can never be spent on
      // a different one.
      const approvedArguments = decision.editedArguments;
      const approvedDigest = approvedArguments
        ? createToolCall({
            id: outstanding.toolCallId,
            missionId,
            capabilityId: outstanding.capabilityId,
            arguments: approvedArguments,
            requestedAt: outstanding.requestedAt,
          }).argumentsDigest
        : outstanding.argumentsDigest;

      this.lastApprovedDigest = approvedDigest;
      this.executor.issue({
        toolCallId: outstanding.toolCallId,
        missionId,
        capabilityId: outstanding.capabilityId,
        argumentsDigest: approvedDigest,
        mode: this.mode,
        issuedAt: this.clock().toISOString(),
      });
    } else {
      this.lastApprovedDigest = undefined;
      this.executor.revoke(outstanding.toolCallId);
    }
    this.pendingFor(missionId).delete(decision.toolCallId);
    const latestRun = await this.getRun(missionId);
    const pendingToolBudgets = { ...((latestRun.state.pendingToolBudgets ?? {}) as Record<string, BudgetUsage>) };
    delete pendingToolBudgets[decision.toolCallId];
    await this.updateRunState(missionId, { pendingToolBudgets });
    const next = decision.decision === 'reject' ? 'CANCELLED' : 'RUNNING';
    const decidedPayload = {
      approvalId: decision.approvalId,
      toolCallId: decision.toolCallId,
      capabilityId: outstanding.capabilityId,
      decision: decision.decision,
      editedArguments: decision.editedArguments,
      approvedDigest: this.lastApprovedDigest,
      step: 'approval_decided',
    };

    // Two approvals can be outstanding at once (see requestTool). Deciding the
    // second one when the first has already moved the mission to RUNNING tried
    // RUNNING -> RUNNING, which is not a legal transition, and crashed.
    //
    // The fix cannot simply skip the whole step when no transition is needed:
    // the approval_decided EVENT still has to be written even when the STATUS
    // does not change, because auditToolAuthority() reads that event to learn
    // which digest the human actually approved. Skipping it silently broke the
    // audit trail for exactly the case this fix exists to handle -- caught by
    // this file's own test 2, not by inspection.
    if (mission.status === next) {
      await this.appendDecisionEvent(mission, decidedPayload);
      return mission;
    }
    // The digest of what the human actually approved. auditToolAuthority()
    // pairs this against the tool_invoked event, so an approval is only ever
    // spendable on the arguments it was given.
    return (await this.advance(mission, next, decision.actorId, decidedPayload)).mission;
  }

  /**
   * Write the approval_decided event without moving mission status. Used only
   * when the target status equals the current one, so there is nothing for
   * transitionMission() to legally transition -- the record still has to exist
   * on the spine, or a replay-based audit loses it silently.
   */
  private async appendDecisionEvent(mission: MissionRecord, payload: Record<string, unknown>): Promise<void> {
    const sequence = await this.nextEventSequence(mission.id);
    await this.options.store.appendEvent({
      id: `${mission.id}:event:${mission.revision}:${sequence}`,
      missionId: mission.id,
      runId: this.runIds.get(mission.id),
      sequence,
      type: 'status_changed',
      actor: payload.decision === 'reject' ? 'human' : String(payload.approvalId ?? 'human'),
      payload: { from: mission.status, to: mission.status, ...payload },
      createdAt: this.clock().toISOString(),
    });
  }

  async startRunning(missionId: string): Promise<MissionRecord> {
    const mission = await this.requireMission(missionId);
    return (await this.advance(mission, 'RUNNING', 'harness')).mission;
  }

  private async budgetFor(mission: MissionRecord): Promise<BudgetLedger> {
    const existing = this.budgets.get(mission.id);
    if (existing) return existing;
    const run = await this.getRun(mission.id);
    const initialUsage = (run.state.budgetUsage ?? {}) as {
      usd?: number;
      toolCalls?: number;
      modelTurns?: number;
    };
    const ledger = new BudgetLedger(mission.budget ?? {}, initialUsage);
    this.budgets.set(mission.id, ledger);
    return ledger;
  }

  private async persistBudget(missionId: string, ledger: BudgetLedger): Promise<void> {
    const run = await this.getRun(missionId);
    await this.options.store.saveRun({
      ...run,
      state: { ...run.state, budgetUsage: ledger.usage },
      updatedAt: this.clock().toISOString(),
    });
  }

  private async updateRunState(missionId: string, statePatch: Record<string, unknown>): Promise<void> {
    const run = await this.getRun(missionId);
    await this.options.store.saveRun({
      ...run,
      state: { ...run.state, ...statePatch },
      updatedAt: this.clock().toISOString(),
    });
  }

  async recordModelTurn(missionId: string, costUsd = 0): Promise<BudgetUsage> {
    const mission = await this.requireMission(missionId);
    const ledger = await this.budgetFor(mission);
    const usage = ledger.consume({ modelTurns: 1, usd: costUsd });
    await this.persistBudget(missionId, ledger);
    return usage;
  }

  async recordToolCost(missionId: string, costUsd: number): Promise<BudgetUsage> {
    const mission = await this.requireMission(missionId);
    const ledger = await this.budgetFor(mission);
    const usage = ledger.consume({ usd: costUsd });
    await this.persistBudget(missionId, ledger);
    return usage;
  }

  async requestTool(input: {
    missionId: string;
    id: string;
    capabilityId: string;
    arguments: Record<string, unknown>;
    requestedAt?: string;
    estimatedCostUsd?: number;
    /** What the pilot was trying to accomplish. Recorded when this is a gap. */
    intent?: string;
  }): Promise<{ toolCall: ToolCall; authorization: ReturnType<CapabilityRegistry['authorize']> }> {
    if (!this.options.capabilities) throw new Error('harness has no capability registry');
    const mission = await this.requireMission(input.missionId);

    // A terminal mission holds no tool authority. assertResumable() already
    // encoded this rule and had no call sites, so cancelling a mission stopped
    // its state transitions and left its tool grants intact -- an emergency stop
    // that did not stop anything that touches the world.
    if (isTerminal(mission.status)) {
      this.executor.revokeMission(mission.id);
      this.pendingApprovals.delete(mission.id);
      throw new ExecutionRefused(
        `mission ${mission.id} is ${mission.status}; a terminal mission holds no tool authority`,
      );
    }

    // A toolCallId in use for a request that is still awaiting a decision (or
    // already granted and not yet spent) must not be reusable for a DIFFERENT
    // request. Before this check, requesting the same id twice silently
    // overwrote the pending approval record -- a human who approved "SHARED"
    // believing they were reviewing the first request could unknowingly
    // authorize the second one instead. The executor's own argument-binding
    // refuses the mismatched original call when it is later presented, which
    // is the fail-safe outcome, but the SILENT REDIRECT of what the approval
    // actually covers is the real hole: nothing told the human their approval
    // had been repointed.
    if (this.pendingFor(mission.id).has(input.id) || this.executor.outstandingFor(mission.id).some((g) => g.toolCallId === input.id)) {
      throw new ExecutionRefused(
        `tool call id ${input.id} is already outstanding on this mission; requests must use a fresh id until the prior one is decided or spent`,
      );
    }

    // A pilot reaching for something this plane does not carry is not an error.
    // It is the clearest signal we get about what to build next, so it is
    // recorded on the mission's own spine and surfaced in the gap report.
    // The pilot is told "not available here", never "you may not".
    if (!this.packs.isMounted(input.capabilityId)) {
      await this.recordGap(mission.id, input.capabilityId, 'not_mounted', input.intent);
      throw new CapabilityUnavailable(input.capabilityId, 'not_mounted');
    }
    if (!mission.authority.allowedCapabilityIds.includes(input.capabilityId)) {
      await this.recordGap(mission.id, input.capabilityId, 'not_granted', input.intent);
    }

    // The declared inputSchema is enforced here, before authorization. An
    // unconstrained argument reaching a risk decision means the decision was
    // made about something nobody had checked.
    const descriptor = this.options.capabilities.get(input.capabilityId);
    assertValid(descriptor.inputSchema, input.arguments, `arguments for ${descriptor.id}`);

    const toolCall = createToolCall({
      id: input.id,
      missionId: input.missionId,
      capabilityId: input.capabilityId,
      arguments: input.arguments,
      requestedAt: input.requestedAt ?? this.clock().toISOString(),
    });
    const authorization = this.options.capabilities.authorize(
      input.capabilityId,
      mission.authority,
    );
    const estimatedCostUsd = Math.max(0, input.estimatedCostUsd ?? 0);
    try {
      if (authorization.decision === 'allow') {
        const ledger = await this.budgetFor(mission);
        ledger.consume({ toolCalls: 1, usd: estimatedCostUsd });
        await this.persistBudget(mission.id, ledger);
        // Mint the single-use, argument-bound grant. This is the only way a
        // tool becomes reachable, and it dies with these exact arguments.
        this.executor.issue({
          toolCallId: toolCall.id,
          missionId: mission.id,
          capabilityId: toolCall.capabilityId,
          argumentsDigest: toolCall.argumentsDigest,
          mode: this.mode,
          issuedAt: this.clock().toISOString(),
        });
      } else if (authorization.decision === 'require_approval') {
        this.pendingFor(mission.id).set(toolCall.id, {
          toolCallId: toolCall.id,
          capabilityId: toolCall.capabilityId,
          argumentsDigest: toolCall.argumentsDigest,
          requestedAt: toolCall.requestedAt,
        });
        const run = await this.getRun(mission.id);
        const pendingToolBudgets = {
          ...((run.state.pendingToolBudgets ?? {}) as Record<string, BudgetUsage>),
          [toolCall.id]: { toolCalls: 1, usd: estimatedCostUsd, modelTurns: 0 },
        };
        await this.updateRunState(mission.id, { pendingToolBudgets });
      }
    } catch (error) {
      const sequence = await this.nextEventSequence(mission.id);
      await this.options.store.appendEvent({
        id: `${mission.id}:tool:${sequence}:${toolCall.id}`,
        missionId: mission.id,
        runId: this.runIds.get(mission.id),
        sequence,
        type: 'tool_requested',
        actor: mission.authority.actorId,
        payload: {
          toolCall,
          authorization: { decision: 'deny', reason: error instanceof Error ? error.message : String(error) },
          budgetRejected: true,
        },
        createdAt: this.clock().toISOString(),
      });
      throw error;
    }
    const sequence = await this.nextEventSequence(mission.id);
    await this.options.store.appendEvent({
      id: `${mission.id}:tool:${sequence}:${toolCall.id}`,
      missionId: mission.id,
      runId: this.runIds.get(mission.id),
      sequence,
      type: 'tool_requested',
      actor: mission.authority.actorId,
      payload: { toolCall, authorization },
      createdAt: this.clock().toISOString(),
    });
    if (authorization.decision === 'require_approval') {
      // A mission can have more than one approval outstanding at once -- "delete
      // A" and "delete B" both needing a human is ordinary, not exceptional.
      // WAITING_APPROVAL -> WAITING_APPROVAL is not a legal transition (no
      // self-transitions), so advancing unconditionally here crashed the whole
      // harness on the second concurrent approval request. Only advance if this
      // is the first one outstanding; the mission is already in the right state
      // for every request after that.
      if (mission.status !== 'WAITING_APPROVAL') {
        await this.advance(mission, 'WAITING_APPROVAL', 'policy', {
          toolCallId: toolCall.id,
          capabilityId: input.capabilityId,
          step: 'approval_requested',
        });
      }
    } else if (authorization.decision === 'allow') {
      if (mission.status === 'PLANNING') await this.advance(mission, 'RUNNING', 'policy', { step: 'tool_authorized' });
    }
    return { toolCall, authorization };
  }

  private async recordGap(
    missionId: string,
    capabilityId: string,
    reason: 'not_mounted' | 'not_granted',
    intent?: string,
  ): Promise<void> {
    const observedAt = this.clock().toISOString();
    this.recorder.recordGap({ capabilityId, reason, intent, missionId, observedAt });
    const sequence = await this.nextEventSequence(missionId);
    await this.options.store.appendEvent({
      id: `${missionId}:gap:${sequence}:${capabilityId}`,
      missionId,
      runId: this.runIds.get(missionId),
      sequence,
      type: 'capability_gap',
      actor: 'pilot',
      payload: { capabilityId, reason, intent },
      createdAt: observedAt,
    });
  }

  /**
   * A pilot may ask for anything, including a skill this plane has never heard
   * of. Nothing is refused on the grounds of being unfamiliar -- it is recorded
   * as a gap and the pilot is told plainly that it is not carried here, so it
   * can fly the mission another way.
   */
  async requestSkill(missionId: string, skillId: string, intent?: string): Promise<Skill | null> {
    if (this.packs.hasSkill(skillId)) return this.packs.getSkill(skillId);
    await this.recordGap(missionId, `skill:${skillId}`, 'not_mounted', intent);
    return null;
  }

  /** What pilots reached for that this plane does not carry. The build queue. */
  capabilityGaps() { return this.recorder.gapReport(); }

  /** Sequences pilots actually flew, and whether they worked. */
  flownManoeuvres() { return this.recorder.manoeuvreReport(); }

  /**
   * Close the flight: read the mission's own event spine and let the plane
   * learn from it. Reading the spine rather than trusting live state means the
   * recorder can never know more than the audit trail.
   */
  async recordFlight(missionId: string) {
    const events = await this.options.store.listEvents(missionId);
    return this.recorder.ingestEvents(missionId, events);
  }

  /** Manoeuvres that have earned promotion into a skill the plane owns. */
  learnableSkills() { return this.recorder.promotable(); }

  /**
   * Promote an earned manoeuvre into a skill, and mount it so later missions
   * can fly it without being told the sequence. This is the plane learning to
   * fly itself. It is NOT the plane granting itself authority: every step still
   * passes the gate, and the skill carries no capability the mission was not
   * already given.
   */
  learnSkill(signature: string): { skill: Skill; evidence: string[] } {
    const learned = this.recorder.promote(signature);
    this.packs.mount({
      id: learned.skill.id,
      name: learned.skill.name,
      description: learned.skill.description,
      version: '1.0.0',
      tools: [],
      skills: [learned.skill],
    });
    return learned;
  }

  private pendingFor(missionId: string): Map<string, PendingApproval> {
    let existing = this.pendingApprovals.get(missionId);
    if (!existing) {
      existing = new Map();
      this.pendingApprovals.set(missionId, existing);
    }
    return existing;
  }

  /**
   * Invoke a tool. This is the whole point of the harness: authorization and
   * invocation in one path, so there is no arm-without-fire gap for a caller to
   * step into.
   *
   * Returns either the execution result, or the approval that is now blocking
   * it. A caller that receives `awaitingApproval` has NOT run anything.
   */
  async runTool(input: {
    missionId: string;
    capabilityId: string;
    arguments: Record<string, unknown>;
    id?: string;
    estimatedCostUsd?: number;
    /** What the pilot was trying to accomplish. Kept if this turns out to be a gap. */
    intent?: string;
  }): Promise<ExecutionResult> {
    const toolCallId = input.id ?? this.idFactory();
    const { toolCall, authorization } = await this.requestTool({
      missionId: input.missionId,
      id: toolCallId,
      capabilityId: input.capabilityId,
      arguments: input.arguments,
      estimatedCostUsd: input.estimatedCostUsd,
      intent: input.intent,
    });

    if (authorization.decision === 'deny') {
      throw new ExecutionRefused(authorization.reason);
    }
    if (authorization.decision === 'require_approval') {
      throw new ExecutionRefused(
        `capability ${input.capabilityId} is waiting on a human approval (tool call ${toolCall.id})`,
      );
    }
    return this.executeAuthorized(toolCall);
  }

  /**
   * Run a tool call whose grant has already been issued -- the resume path
   * after a human approves. Refuses if no grant is outstanding.
   *
   * WITNESS WIRING (fetch + DOM):
   *  - Every invocation mints an outcome witness `${missionId}:${toolCallId}`.
   *  - If the tool output carries a content-addressed ref (bodyHash, snapshotHash,
   *    contentHash, pngHash, or _structuralRef) that looks like `sha256:…`,
   *    the plumbing also mints a structural witness over that ref.
   *  - The structural ref is RAW BYTES HASH, never JSON.stringify(output).
   *  - Both witnesses are recorded on the tool_invoked event and returned to
   *    the caller. Pilot never supplies them.
   */
  async executeAuthorized(toolCall: ToolCall): Promise<ExecutionResult & { witness: Witness; witnesses: Witness[]; structuralWitness?: Witness }> {
    const mission = await this.requireMission(toolCall.missionId);
    if (isTerminal(mission.status)) {
      this.executor.revokeMission(mission.id);
      throw new ExecutionRefused(
        `mission ${mission.id} is ${mission.status}; a terminal mission holds no tool authority`,
      );
    }

    const result = await this.executor.execute(toolCall);
    // Plumbing-generated witness — never supplied by the pilot. The reference
    // is the plumbing's own `${missionId}:${toolCallId}`, not a pilot string.
    // This is the receipt the collective will later check.
    const witness = this.mintPlumbingWitness(toolCall, result.finishedAt)

    // Optional structural witness from content hash — body bytes / DOM snapshot / PNG bytes / page text.
    // The tool implementation returns _structuralRef or a specific hash field; plumbing validates format
    // and mints a witness over it. Raw bytes hashed, not JSON.stringify(output).
    let structural: Witness | undefined
    try {
      const out = result.output as any
      if (out && typeof out === 'object') {
        const candidateRef =
          (typeof out._structuralRef === 'string' ? out._structuralRef : null) ??
          (typeof out.bodyHash === 'string' ? out.bodyHash : null) ??
          (typeof out.snapshotHash === 'string' ? out.snapshotHash : null) ??
          (typeof out.contentHash === 'string' ? out.contentHash : null) ??
          (typeof out.pngHash === 'string' ? out.pngHash : null)
        if (candidateRef && /^sha256:[a-f0-9]{64}$/.test(candidateRef)) {
          structural = structuralWitness(this.harnessId, candidateRef, result.finishedAt)
        }
      }
    } catch {
      // Structural witness is best-effort — outcome witness is mandatory, structural optional.
      structural = undefined
    }

    const witnesses: Witness[] = structural ? [witness, structural] : [witness]

    // ── Collective auto-admission (fetch body bytes / DOM snapshot hashes) ──
    // If a collective is mounted, derive facts from the output that carry the
    // structural hash as receipt. This is plumbing-only: pilot never decides
    // what fact to admit, harness does from bytes it observed.
    // The fact's witness is the structural witness (content-addressed), not the
    // outcome witness (request id). Outcome witness proves action; structural
    // proves content.
    let admittedFacts: { factId: string; status: string }[] = []
    if (this.collective && result.status === 'succeeded') {
      try {
        const primaryWitness = structural ?? witness
        const derived = deriveFacts({
          capabilityId: toolCall.capabilityId,
          output: result.output as any,
          witness: primaryWitness,
        })
        for (const fact of derived) {
          try {
            const verdict = admit(fact, this.collective)
            if (verdict.status === 'admitted' || verdict.status === 'corroborated') {
              admittedFacts.push({ factId: (verdict as any).fact?.factId ?? '', status: verdict.status })
            } else if (verdict.status === 'conflict') {
              // Conflict quarantines subject — record via collective's own method
              this.collective.recordConflict(verdict.incumbent, verdict.challenger)
              admittedFacts.push({ factId: '', status: 'conflict' })
            } else if (verdict.status === 'refused') {
              admittedFacts.push({ factId: '', status: `refused:${(verdict as any).reason}` })
            }
          } catch {
            // Admission is best-effort — a malformed derived fact must not fail the tool call
          }
        }
      } catch {
        // Collective wiring failure must not fail the tool itself — flight recorder keeps flying
      }
    }

    const sequence = await this.nextEventSequence(mission.id);
    await this.options.store.appendEvent({
      id: `${mission.id}:invoked:${sequence}:${toolCall.id}`,
      missionId: mission.id,
      runId: this.runIds.get(mission.id),
      sequence,
      type: 'tool_invoked',
      actor: mission.authority.actorId,
      payload: {
        toolCallId: toolCall.id,
        capabilityId: toolCall.capabilityId,
        // The digest of what actually ran. Pairing this against the preceding
        // authorization event is the replayable proof that no side effect
        // happened without a matching grant.
        argumentsDigest: toolCall.argumentsDigest,
        mode: result.mode,
        status: result.status,
        error: result.error,
        startedAt: result.startedAt,
        finishedAt: result.finishedAt,
        // Plumbing witness — machine receipt that an action was taken and the
        // world responded. Pilot never touches this; the gate checks it.
        witness,
        structuralWitness: structural,
        witnesses,
        admittedFacts,
      },
      createdAt: this.clock().toISOString(),
    });
    return { ...result, witness, witnesses, structuralWitness: structural, admittedFacts } as any;
  }

  /**
   * Cancel a mission AND drop every tool grant it holds. The emergency stop.
   */
  async cancelMission(missionId: string, actorId: string, reason: string): Promise<MissionRecord> {
    const mission = await this.requireMission(missionId);
    const revoked = this.executor.revokeMission(missionId);
    this.pendingApprovals.delete(missionId);
    if (isTerminal(mission.status)) return mission;
    return (await this.advance(mission, 'CANCELLED', actorId, {
      reason, revokedGrants: revoked, step: 'mission_cancelled',
    })).mission;
  }

  /**
   * Replay the event spine and assert the property the executor exists for:
   * every invocation was preceded by an authorization for the same tool call
   * carrying the same arguments digest.
   */
  async auditToolAuthority(missionId: string): Promise<{
    ok: boolean;
    invocations: number;
    violations: { toolCallId: string; reason: string }[];
  }> {
    const events = await this.options.store.listEvents(missionId);
    const authorized = new Map<string, string>();
    const violations: { toolCallId: string; reason: string }[] = [];
    let invocations = 0;

    for (const event of events) {
      const payload = event.payload as Record<string, unknown>;
      if (event.type === 'tool_requested') {
        const call = payload.toolCall as ToolCall | undefined;
        const auth = payload.authorization as { decision?: string } | undefined;
        if (call && auth?.decision === 'allow') authorized.set(call.id, call.argumentsDigest);
      }
      if (event.type === 'approval_decided' || payload.step === 'approval_decided') {
        const toolCallId = payload.toolCallId as string | undefined;
        const digest = payload.approvedDigest as string | undefined;
        if (toolCallId && digest) authorized.set(toolCallId, digest);
      }
      if (event.type === 'tool_invoked') {
        invocations += 1;
        const toolCallId = String(payload.toolCallId);
        const digest = String(payload.argumentsDigest);
        const granted = authorized.get(toolCallId);
        if (!granted) {
          violations.push({ toolCallId, reason: 'invoked with no preceding authorization' });
        } else if (granted !== digest) {
          violations.push({ toolCallId, reason: 'invoked with arguments that were not the ones authorized' });
        }
      }
    }
    return { ok: violations.length === 0, invocations, violations };
  }

  async observe(missionId: string, event: ObservedHarnessEvent): Promise<NeuralinkDecision> {
    const session = await this.ensureNeuralink(missionId);
    const decision = session.observe(event);
    const mission = await this.requireMission(missionId);
    const sequence = await this.nextEventSequence(mission.id);
    await this.options.store.appendEvent({
      id: `${mission.id}:observation:${sequence}`,
      missionId: mission.id,
      runId: this.runIds.get(mission.id),
      sequence,
      type: 'pilot_observed',
      actor: event.source,
      payload: { ...event, decision },
      createdAt: this.clock().toISOString(),
    });
    return decision;
  }

  async markContextUpdated(missionId: string): Promise<MissionRecord> {
    return (await this.advance(await this.requireMission(missionId), 'CONTEXT_UPDATED', 'neuralink')).mission;
  }

  async resumeRunning(missionId: string): Promise<MissionRecord> {
    return (await this.advance(await this.requireMission(missionId), 'RUNNING', 'harness')).mission;
  }

  async beginEvaluation(missionId: string): Promise<MissionRecord> {
    return (await this.advance(await this.requireMission(missionId), 'EVALUATING', 'harness')).mission;
  }

  async beginMemoryReview(missionId: string): Promise<MissionRecord> {
    return (await this.advance(await this.requireMission(missionId), 'MEMORY_REVIEW', 'neuralink')).mission;
  }

  async complete(
    missionId: string,
    input: MissionEvaluationInput,
  ): Promise<{ mission: MissionRecord; evaluation: MissionEvaluation }> {
    const mission = await this.requireMission(missionId);
    const evaluation = this.missionComputer.evaluate(mission.successCriteria, input);
    if (evaluation.status === 'succeeded' || evaluation.status === 'failed') {
      const status = evaluation.status === 'succeeded' ? 'SUCCEEDED' : 'FAILED';
      const completed = await this.advance(mission, status, 'mission-computer', {
        step: 'mission_evaluated',
        evaluation,
      });
      return { mission: completed.mission, evaluation };
    }
    if (mission.status === 'EVALUATING') {
      const review = await this.advance(mission, 'MEMORY_REVIEW', 'mission-computer', {
        step: 'mission_inconclusive',
        evaluation,
      });
      return { mission: review.mission, evaluation };
    }
    return { mission, evaluation };
  }

  async getRun(missionId: string): Promise<RunRecord> {
    let runId = this.runIds.get(missionId);
    if (!runId) {
      const latest = await this.options.store.getLatestRun(missionId);
      if (latest) {
        runId = latest.id;
        this.runIds.set(missionId, runId);
        return latest;
      }
    }
    if (!runId) throw new Error(`run not found for mission: ${missionId}`);
    const run = await this.options.store.getRun(runId);
    if (!run) throw new Error(`run not found: ${runId}`);
    return run;
  }

  private async ensureNeuralink(missionId: string): Promise<NeuralinkSession> {
    const existing = this.sessions.get(missionId);
    if (existing) return existing;
    const mission = await this.requireMission(missionId);
    const run = await this.getRun(missionId);
    const session = new NeuralinkSession(this.options.passport, {}, this.clock);
    const frame = await this.options.store.loadLatestContextFrame(run.id);
    if (frame) session.restore(mission, frame);
    else await session.bind(mission);
    this.sessions.set(missionId, session);
    return session;
  }

  getNeuralink(missionId: string): NeuralinkSession {
    const session = this.sessions.get(missionId);
    if (!session) throw new Error(`Neuralink is not bound to mission: ${missionId}`);
    return session;
  }

  private async requireMission(id: string): Promise<MissionRecord> {
    const mission = await this.options.store.get(id);
    if (!mission) throw new Error(`mission not found: ${id}`);
    return mission;
  }

  private async nextEventSequence(missionId: string): Promise<number> {
    // Re-read the event spine on every allocation. The in-memory cache is only
    // an optimization hint; another runtime may have appended an event since
    // this process last advanced the mission.
    const events = await this.options.store.listEvents(missionId);
    const next = events.reduce((max, event) => Math.max(max, event.sequence + 1), 0);
    return next;
  }

  private async advance(
    mission: MissionRecord,
    status: MissionRecord['status'],
    actor: string,
    payload: Record<string, unknown> = {},
  ): Promise<{ mission: MissionRecord; event: MissionEvent }> {
    // Cockpit mission hooks — observed BEFORE the transition so the old
    // status is the truth about where the mission was, never the new one.
    const wasRunning = isRunningFamily(mission.status);
    if (isTerminal(status)) {
      cockpit.missionEnded(mission.id);
    } else if (!wasRunning && isRunningFamily(status)) {
      cockpit.missionStarted(mission.id);
    }

    const result = transitionMission(mission, status, actor, payload, this.clock);
    const sequence = await this.nextEventSequence(mission.id);
    let runId = this.runIds.get(mission.id);
    if (!runId) {
      const latest = await this.options.store.getLatestRun(mission.id);
      if (latest) {
        runId = latest.id;
        this.runIds.set(mission.id, runId);
      }
    }
    const event = runId
      ? { ...result.event, runId, sequence }
      : { ...result.event, sequence };
    await this.options.store.save(result.mission, mission.revision);
    await this.options.store.appendEvent(event);
    if (runId) {
      const run = await this.options.store.getRun(runId);
      if (run) {
        const now = this.clock().toISOString();
        await this.options.store.saveRun({
          ...run,
          status: runStatusForMission(status, run.status),
          state: { ...run.state, ...payload },
          checkpoint: result.mission.checkpoint?.state ?? run.checkpoint,
          updatedAt: now,
        });
      }
    }
    return { ...result, event };
  }

  private async appendCreatedEvent(mission: MissionRecord): Promise<void> {
    await this.options.store.appendEvent({
      id: `${mission.id}:created`,
      missionId: mission.id,
      sequence: 0,
      type: 'mission_created',
      actor: mission.authority.actorId,
      payload: {
        goal: mission.goal,
        passportId: mission.passportId,
        constraints: mission.constraints ?? [],
      },
      createdAt: mission.createdAt,
    });
  }
}

function runStatusForMission(missionStatus: MissionRecord['status'], current: RunStatus): RunStatus {
  if (missionStatus === 'WAITING_APPROVAL') return 'WAITING_APPROVAL';
  if (missionStatus === 'WAITING_EXTERNAL') return 'WAITING_EXTERNAL';
  if (missionStatus === 'SUCCEEDED') return 'SUCCEEDED';
  if (missionStatus === 'FAILED') return 'FAILED';
  if (missionStatus === 'CANCELLED') return 'CANCELLED';
  if (isRunningFamily(missionStatus)) return 'RUNNING';
  return current;
}

/** States in which a mission is considered in the air (cockpit flying). */
function isRunningFamily(status: MissionRecord['status']): boolean {
  return status === 'RUNNING' || status === 'CONTEXT_UPDATED'
    || status === 'EVALUATING' || status === 'MEMORY_REVIEW';
}
