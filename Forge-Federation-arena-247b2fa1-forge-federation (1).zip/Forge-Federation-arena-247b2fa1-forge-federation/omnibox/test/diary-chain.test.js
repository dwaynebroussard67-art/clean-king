'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { WarDiary, stripForbidden, MARK_RESULTS } = require('../src/main/diary.js');

function tmp() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ff-diary-chain-'));
}

const splitAnswers = [
  { seatName: 'Claude', ok: true, text: 'Paris' },
  { seatName: 'Gemini', ok: true, text: 'Lyon' },
];
const sameAnswers = [
  { seatName: 'Claude', ok: true, text: 'Paris' },
  { seatName: 'Gemini', ok: true, text: 'Paris' },
];

test('stripForbidden drops prompt/text/reply even when mixed into play data', () => {
  const out = stripForbidden({
    name: 'communal-split-unknown',
    prompt: 'secret question',
    text: 'secret answer',
    reply: 'nope',
    result: 'held',
    nested: { content: 'still secret', keep: 1 },
  });
  assert.equal(out.prompt, undefined);
  assert.equal(out.text, undefined);
  assert.equal(out.reply, undefined);
  assert.equal(out.nested.content, undefined);
  assert.equal(out.nested.keep, 1);
  assert.equal(out.name, 'communal-split-unknown');
});

test('an unsigned mark in the file is ignored on reload — the signature holds at restart', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  d.record({
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
    runId: 'r1',
  });
  assert.equal(d.list()[0].held, 0);
  fs.appendFileSync(
    d.logPath,
    JSON.stringify({
      schema: 'forgeflight.diary.v1',
      op: 'mark',
      data: { name: 'communal-same-defer', result: 'held' },
    }) + '\n'
  );
  const again = new WarDiary(dir).load();
  assert.equal(again.list()[0].held, 0, 'unsigned mark must not count after restart');
  assert.equal(MARK_RESULTS.has('open'), false);
});

test('apply() and mark() share the allowed set — open is not a mark', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  d.record({
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
    runId: 'r1',
  });
  const bad = d.mark('communal-same-defer', 'open', 'Ada');
  assert.equal(bad.ok, false);
  assert.equal(bad.reason, 'bad-result');
  fs.appendFileSync(
    d.logPath,
    JSON.stringify({
      schema: 'forgeflight.diary.v1',
      op: 'mark',
      data: { name: 'communal-same-defer', result: 'open', actor: 'Ada' },
    }) + '\n'
  );
  const again = new WarDiary(dir).load();
  assert.equal(again.list()[0].open, 1, 'the original play is still open once');
  assert.equal(again.list()[0].held, 0);
});

test('a signed mark survives restart', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  d.record({
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
    runId: 'r1',
  });
  d.mark('communal-same-defer', 'held', 'Ada');
  const again = new WarDiary(dir).load();
  assert.equal(again.list()[0].held, 1);
  assert.equal(again.verify().ok, true);
});

test('the diary log is hash-chained: a clean file verifies, an edit does not', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
    runId: 'r1',
  });
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'still no' },
    runId: 'r2',
  });
  const v = d.verify();
  assert.equal(v.ok, true);
  assert.equal(v.breaks.length, 0);
  assert.ok(v.chained >= 2);
  assert.notEqual(v.head, '0'.repeat(64));

  const lines = fs.readFileSync(d.logPath, 'utf8').split('\n').filter(Boolean);
  const target = JSON.parse(lines[0]);
  target.data.result = 'broke';
  lines[0] = JSON.stringify(target);
  fs.writeFileSync(d.logPath, lines.join('\n') + '\n');
  const broken = new WarDiary(dir).verify();
  assert.equal(broken.ok, false);
  assert.ok(
    broken.breaks.some((b) => b.kind === 'hash-mismatch'),
    JSON.stringify(broken.breaks)
  );
});

test('a torn last line in the diary still verifies; a forged append does not', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
    runId: 'r1',
  });
  fs.appendFileSync(d.logPath, '{"op":"mark","data":{"name":"communal-split-unknown"');
  const torn = d.verify();
  assert.equal(torn.ok, true, 'torn last line is tolerated');
  assert.equal(torn.torn, true);

  const dir2 = tmp();
  const d2 = new WarDiary(dir2).load();
  d2.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
    runId: 'r1',
  });
  fs.appendFileSync(
    d2.logPath,
    JSON.stringify({
      op: 'mark',
      data: { name: 'communal-split-unknown', result: 'held' },
      prev: 'fake',
      hash: 'fake',
    }) + '\n'
  );
  const forged = d2.verify();
  assert.equal(forged.ok, false);
  assert.ok(forged.breaks.length >= 1);
});
