'use strict';

/**
 * local.test.js — the local-model bridge (the reserved seat's machinery).
 *
 * Tested against a real OpenAI-compatible server running in-process over
 * node:http — the same wire format Ollama and LM Studio speak — including
 * SSE streaming, a torn SSE line split across TCP writes, the helmet
 * (boot-block system message), discovery, and the honest no-server refusal.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');

const { LocalLLM } = require('../src/main/localLLM.js');

function mockServer({ tornLine = false, models = [{ id: 'mock-model' }] } = {}) {
  const received = [];
  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      if (req.url === '/v1/models') {
        res.writeHead(200, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ data: models }));
        return;
      }
      if (req.url === '/v1/chat/completions') {
        received.push({ url: req.url, body: JSON.parse(body) });
        res.writeHead(200, { 'content-type': 'text/event-stream' });
        const chunks = [
          'data: {"choices":[{"delta":{"content":"The "}}]}\n\n',
          'data: {"choices":[{"delta":{"content":"local "}}]}\n\n',
          'data: {"choices":[{"delta":{"content":"model "}}]}\n\n',
          'data: {"choices":[{"delta":{"content":"answered."}}]}\n\n',
          'data: [DONE]\n\n',
        ];
        if (tornLine) {
          // Split one event across two writes: the parser must buffer.
          res.write(chunks[0].slice(0, 30));
          setTimeout(() => {
            res.write(chunks[0].slice(30));
            let i = 1;
            const iv = setInterval(() => {
              res.write(chunks[i]);
              if (++i >= chunks.length) {
                clearInterval(iv);
                res.end();
              }
            }, 5);
          }, 10);
        } else {
          let i = 0;
          const iv = setInterval(() => {
            res.write(chunks[i]);
            if (++i >= chunks.length) {
              clearInterval(iv);
              res.end();
            }
          }, 5);
        }
        return;
      }
      res.writeHead(404);
      res.end();
    });
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve({ server, received, port: server.address().port }));
  });
}

test('discovery finds the server and picks its first model', async () => {
  const { server, port } = await mockServer();
  const llm = new LocalLLM({ endpoints: [`http://127.0.0.1:${port}`] });
  const st = await llm.status();
  assert.equal(st.available, true);
  assert.equal(st.model, 'mock-model');
  assert.equal(st.endpoint, `http://127.0.0.1:${port}`);
  server.close();
  if (server.closeAllConnections) server.closeAllConnections();
});

test('generate streams tokens and returns the whole text; the helmet is the system message', async () => {
  const { server, received, port } = await mockServer();
  const llm = new LocalLLM({ endpoints: [`http://127.0.0.1:${port}`] });
  const tokens = [];
  const r = await llm.generate({
    prompt: 'what is the shape of the table',
    system: '=== MEMORY PASSPORT ===\nadmitted 1 of 1\n--- not shown ---',
    onToken: (delta) => tokens.push(delta),
  });
  assert.equal(r.ok, true);
  assert.equal(r.text, 'The local model answered.');
  assert.ok(tokens.length >= 4, 'every token arrived as it streamed');

  const sent = received[0].body;
  assert.equal(sent.stream, true, 'streams by default');
  assert.equal(sent.messages[0].role, 'system');
  assert.match(sent.messages[0].content, /MEMORY PASSPORT/);
  assert.match(sent.messages[0].content, /not shown/);
  assert.equal(sent.messages[1].role, 'user');
  assert.equal(sent.messages[1].content, 'what is the shape of the table');
  assert.equal(sent.model, 'mock-model');
  server.close();
  if (server.closeAllConnections) server.closeAllConnections();
});

test('a torn SSE line split across writes is buffered, not lost', async () => {
  const { server, port } = await mockServer({ tornLine: true });
  const llm = new LocalLLM({ endpoints: [`http://127.0.0.1:${port}`] });
  const r = await llm.generate({ prompt: 'hello', system: null });
  assert.equal(r.ok, true);
  assert.equal(r.text, 'The local model answered.');
  server.close();
  if (server.closeAllConnections) server.closeAllConnections();
});

test('no server anywhere is an honest named refusal, fast', async () => {
  const llm = new LocalLLM({ endpoints: ['http://127.0.0.1:1'], discoverTimeout: 300 });
  const t0 = Date.now();
  const st = await llm.status();
  assert.equal(st.available, false);
  const r = await llm.generate({ prompt: 'hello' });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'no-server');
  assert.ok(Date.now() - t0 < 5000, 'fails fast, does not hang');
});

test('a generate without a system message sends only the user turn', async () => {
  const { server, received, port } = await mockServer();
  const llm = new LocalLLM({ endpoints: [`http://127.0.0.1:${port}`] });
  await llm.generate({ prompt: 'bare', system: null });
  assert.equal(received[0].body.messages.length, 1);
  assert.equal(received[0].body.messages[0].role, 'user');
  server.close();
  if (server.closeAllConnections) server.closeAllConnections();
});
