/**
 * forge-store.test.js — persistence, pinned down.
 *
 * The claim under test: a paused relay survives a restart. The memory (the
 * hash-chained recorder), the meter (budget), the staged proposals, and the
 * suspended flight all round-trip through ForgeStore, and a new forge adopts
 * the loaded state and resumes the SAME run to green. The attacks: tamper with
 * the recorder file and the chain reports a break (never throws); tear a line
 * and it is dropped and counted (never a crash); a corrupt state file degrades
 * to defaults.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { CodeForge, ForgeStore } = require('../src/forge/index.js');

let tmpRoot = null;
function tmpdir() {
  if (!tmpRoot) tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-store-'));
  return fs.mkdtempSync(path.join(tmpRoot, 'run-'));
}

// ── The failing-test tree language (same as the other forge suites) ───────

function failingOf(tree) {
  const out = [];
  const re = /F\(([^)]*)\)/g;
  let m;
  while ((m = re.exec(String(tree))) !== null) out.push(m[1]);
  return out.sort();
}

function treeOf(names) {
  return names.slice().sort().map((n) => `F(${n})`).join(' ');
}

function setsEqual(a, b) {
  return a.size === b.size && [...a].every((x) => b.has(x));
}

function referee() {
  return {
    async verdict(tree) {
      const failing = failingOf(tree);
      return failing.length === 0 ? { status: 'green' } : { status: 'red', failing };
    },
  };
}

function apply() {
  return (tree, patch) => {
    const cur = new Set(failingOf(tree));
    const next = new Set(cur);
    for (const t of String(patch).split(/\s+/).filter(Boolean)) {
      if (t.startsWith('-F(')) next.delete(t.slice(3, -1));
      else if (t.startsWith('+F(')) next.add(t.slice(3, -1));
      else return { ok: false, reason: `unparseable patch token: ${t}` };
    }
    if (setsEqual(cur, next)) return { ok: true, changed: false, tree };
    return { ok: true, changed: true, tree: treeOf([...next]) };
  };
}

function smartSeat(id) {
  return {
    id,
    label: id,
    propose: async (ctx) => {
      const failing = failingOf(ctx.tree);
      if (!failing.length) return { kind: 'pass', reason: 'nothing failing' };
      return { kind: 'proposal', patch: `-F(${failing[0]})`, summary: `fix ${failing[0]}`, toolSequence: ['forge.run_tests'] };
    },
  };
}

function spec(over = {}) {
  return {
    goal: 'make the tests pass',
    trunk: treeOf(['t0', 't1', 't2']),
    seats: [smartSeat('s1')],
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    bench: [],
    referee: referee(),
    apply: apply(),
    ...over,
  };
}

// ── The round-trip ────────────────────────────────────────────────────────

test('a paused relay survives save/load and resumes the same run to green', () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec({
    seats: [smartSeat('s1'), smartSeat('s2')],
    budget: { s1: { maxCalls: 1, tier: 'free' }, s2: { maxCalls: 1, tier: 'free' } },
  }));

  return (async () => {
    const res1 = await forge.run();
    assert.equal(res1.stopReason, 'paused');
    assert.equal(res1.resumable, true);
    assert.equal(forge.isPaused, true);

    // Persist.
    store.save(forge.snapshot());

    // "Restart": a brand-new forge (seats re-seated by the operator), adopting
    // the loaded state.
    const forge2 = new CodeForge(spec({
      seats: [smartSeat('s1'), smartSeat('s2')],
      budget: { s1: { maxCalls: 1, tier: 'free' }, s2: { maxCalls: 1, tier: 'free' } },
    }));
    const loaded = store.load();
    assert.equal(loaded.corrupt, 0);
    assert.equal(loaded.chain.breaks.length, 0);
    assert.equal(loaded.recorder.count, forge.recorder.count);
    // Both seats hit their allowance — the run paused at the round boundary
    // before either could be charged again.
    assert.equal(loaded.budget.status('s1'), 'exhausted');
    assert.equal(loaded.budget.status('s2'), 'exhausted');
    assert.equal(loaded.budget.usageFor('s1').calls, 1);
    forge2.adopt(loaded);

    // Same flight, same runId, resumed to green.
    assert.equal(forge2.isPaused, true);
    forge2.resetBudgets();
    const res2 = await forge2.resume();
    assert.equal(res2.runId, res1.runId);
    assert.equal(res2.stopReason, 'goal_reached');
    assert.equal(res2.roundsRun, 2);
  })();
});

test('a staged proposal survives save/load and can still be released', async () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec({ trunk: 'F(auth)', seats: [smartSeat('s1')], budget: undefined, bench: undefined }));
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.ok(r.proposal);

  store.save(forge.snapshot());

  const forge2 = new CodeForge(spec({ trunk: 'F(auth)', seats: [smartSeat('s1')], budget: undefined, bench: undefined }));
  const loaded = store.load();
  assert.equal(loaded.proposals.staged().length, 1);
  forge2.adopt(loaded);
  assert.equal(forge2.proposals.staged().length, 1);
  forge2.proposals.release(r.proposal.id);
  assert.equal(forge2.proposals.entries[0].status, 'released');
});

test('the recorder chain re-verifies cleanly on load', async () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec());
  await forge.run();
  store.save(forge.snapshot());

  const loaded = store.load();
  assert.equal(loaded.chain.chained, forge.recorder.count);
  assert.equal(loaded.chain.breaks.length, 0);
});

// ── Attacks ───────────────────────────────────────────────────────────────

test('ATTACK: tampering with the recorder file is reported as a chain break, never a throw', async () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec());
  await forge.run();
  store.save(forge.snapshot());

  // Edit the past: flip an attempt's status in the persisted log.
  const p = path.join(dir, 'recorder.jsonl');
  const lines = fs.readFileSync(p, 'utf8').split('\n').filter((l) => l.trim());
  const edited = lines.map((l) => {
    const rec = JSON.parse(l);
    if (rec.op === 'attempt') rec.data.status = 'green';
    return JSON.stringify(rec);
  });
  fs.writeFileSync(p, edited.join('\n') + '\n');

  const loaded = store.load();
  assert.ok(loaded.chain.breaks.length > 0);
  assert.ok(loaded.recorder.count > 0); // still readable, still loaded
});

test('ATTACK: a torn line is dropped and counted, never a crash', async () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec());
  await forge.run();
  store.save(forge.snapshot());

  const p = path.join(dir, 'recorder.jsonl');
  const good = fs.readFileSync(p, 'utf8');
  fs.writeFileSync(p, good + '{ this is not json\n');

  const loaded = store.load();
  assert.equal(loaded.corrupt, 1);
  assert.equal(loaded.chain.breaks.length, 0); // the garbage is dropped, not chained
  assert.equal(loaded.recorder.count, forge.recorder.count);
});

test('ATTACK: a corrupt state file degrades to defaults and is counted', async () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec());
  await forge.run();
  store.save(forge.snapshot());

  fs.writeFileSync(path.join(dir, 'state.json'), 'not json at all\n');

  const loaded = store.load();
  assert.equal(loaded.corrupt, 1);
  assert.equal(loaded.flight, null);
  assert.equal(loaded.budget.usageFor('s1').calls, 0); // defaults
});

test('the ejected-set round-trips: an ejected seat stays ejected after load', () => {
  const dir = tmpdir();
  const store = new ForgeStore(dir);
  const forge = new CodeForge(spec({ trunk: 'F(auth) F(login)', budget: { s1: { maxCalls: 1, tier: 'free' } }, seats: [smartSeat('s1')], bench: [smartSeat('b1')] }));
  return (async () => {
    await forge.run(); // s1 fixes auth, is ejected on its second charge, b1 replaces it and fixes login
    assert.equal(forge.budget.ejected('s1'), true);
    store.save(forge.snapshot());
    const loaded = store.load();
    assert.equal(loaded.budget.ejected('s1'), true);
    assert.equal(loaded.budget.usageFor('s1').calls, 1); // billed once, never again
  })();
});

test('a store refuses to construct without a directory', () => {
  assert.throws(() => new ForgeStore(null), /directory is required/);
});
