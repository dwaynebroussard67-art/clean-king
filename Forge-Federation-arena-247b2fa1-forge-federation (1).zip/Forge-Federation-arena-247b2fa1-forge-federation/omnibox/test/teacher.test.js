'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { COMPOSER_WEIGHTS } = require('../src/detector/signals.js');
const T = require('../src/field-evidence/teacher.js');

function sig(overrides) {
  const s = {};
  for (const k of Object.keys(COMPOSER_WEIGHTS)) s[k] = 0;
  return Object.assign(s, overrides);
}

function cand(stabilityKey, signals, extra) {
  return Object.assign({ stabilityKey, signals: sig(signals), score: 0.5, tag: 'textarea' }, extra || {});
}

function verdict(url, tiedOn, crowd, extra) {
  return Object.assign(
    {
      type: 'verdict',
      url,
      status: 'refused',
      verdictReason: 'ambiguous',
      tiedOn,
      winner: null,
      losers: crowd,
    },
    extra || {},
  );
}

function pick(url, stabilityKey) {
  return { type: 'pick', url, ok: true, stamp: { stabilityKey } };
}

function hostUrl(host, path) {
  return `https://${host}${path || '/chat'}`;
}

function threeHosts(tiedOn, discriminator, extraSig) {
  const hosts = ['a.example', 'b.example', 'c.example'];
  const recs = [];
  hosts.forEach((h, i) => {
    const url = hostUrl(h, `/p${i}`);
    const winner = cand('win', { [discriminator]: 0.9, ...(extraSig || {}) });
    const loser = cand('lose', { [discriminator]: 0.1, ...(extraSig || {}) });
    recs.push(verdict(url, tiedOn, [winner, loser]));
    recs.push(pick(url, 'win'));
  });
  return recs;
}

const TIE = ['askIntent'];
const DISC = 'sendAffinity';

describe('teacher: join', () => {
  it('does not treat confirm as a discriminator example', () => {
    const url = hostUrl('a.example');
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([
      verdict(url, TIE, crowd),
      { type: 'confirm', url, ok: true, stamp: { stabilityKey: 'win' } },
    ]);
    assert.equal(out.stats.examples, 0);
  });

  it('joins a later pick on the same URL to the last ambiguous refusal', () => {
    const url = hostUrl('a.example');
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([verdict(url, TIE, crowd), pick(url, 'win')]);
    assert.equal(out.stats.examples, 1);
    assert.equal(out.examples[0].discriminator, DISC);
    assert.equal(out.examples[0].host, 'a.example');
  });

  it('does not join a pick to a different URL', () => {
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([
      verdict(hostUrl('a.example'), TIE, crowd),
      pick(hostUrl('b.example'), 'win'),
    ]);
    assert.equal(out.stats.examples, 0);
  });

  it('a later seated verdict without a pick abandons the pending refusal', () => {
    const url = hostUrl('a.example');
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([
      verdict(url, TIE, crowd),
      { type: 'verdict', url, status: 'seated', verdictReason: 'ok' },
      pick(url, 'win'),
    ]);
    assert.equal(out.stats.examples, 0);
    assert.equal(out.unresolved, 1);
  });

  it('counts unresolved refusals without teaching a negative lesson', () => {
    const url = hostUrl('a.example');
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([verdict(url, TIE, crowd)]);
    assert.equal(out.unresolved, 1);
    assert.equal(out.stats.examples, 0);
    assert.equal(out.lessons.length, 0);
  });

  it('a pick whose stamp matches no refusal candidate is not an example', () => {
    const url = hostUrl('a.example');
    const crowd = [cand('win', { sendAffinity: 0.9 }), cand('lose', { sendAffinity: 0.1 })];
    const out = T.teach([verdict(url, TIE, crowd), pick(url, 'ghost')]);
    assert.equal(out.stats.examples, 0);
  });
});

describe('teacher: discriminator', () => {
  it('ignores signals already named in tiedOn', () => {
    const winner = cand('win', { askIntent: 0.9, sendAffinity: 0.9 });
    const loser = cand('lose', { askIntent: 0.9, sendAffinity: 0.1 });
    assert.equal(T.pickDiscriminator(winner, [loser], TIE), DISC);
    assert.equal(T.pickDiscriminator(winner, [loser], ['askIntent', 'sendAffinity']), null);
  });

  it('returns null when no named signal uniquely separates', () => {
    const winner = cand('win', { sendAffinity: 0.4 });
    const loser = cand('lose', { sendAffinity: 0.4 });
    assert.equal(T.pickDiscriminator(winner, [loser], TIE), null);
  });

  it('will not treat class, href or sibling index as a discriminator', () => {
    const winner = cand('win', { sendAffinity: 0.4 });
    winner.className = 'composer';
    winner.href = '/chat';
    const loser = cand('lose', { sendAffinity: 0.4 });
    assert.equal(T.pickDiscriminator(winner, [loser], TIE), null);
  });

  it('a loser missing the signal entirely must not produce a discriminator', () => {
    const winner = cand('win', { sendAffinity: 0.9 });
    const loser = cand('lose', { sendAffinity: 0.1 });
    delete loser.signals.sendAffinity;
    assert.equal(T.pickDiscriminator(winner, [loser], TIE), null);
  });
});

describe('teacher: unanimity', () => {
  it('stays provisional under three hosts until the bar is met', () => {
    const recs = threeHosts(TIE, DISC).slice(0, 4); // two hosts
    const out = T.teach(recs);
    assert.equal(out.lessons.length, 1);
    assert.equal(out.lessons[0].status, 'provisional');
    assert.equal(out.lessons[0].discriminator, DISC);
    assert.equal(out.lessons[0].hosts, 2);
  });

  it('promotes only when three distinct hosts share one discriminator', () => {
    const out = T.teach(threeHosts(TIE, DISC));
    assert.equal(out.lessons.length, 1);
    assert.equal(out.lessons[0].status, 'promoted');
    assert.equal(out.lessons[0].hosts, 3);
    assert.equal(out.lessons[0].discriminator, DISC);
  });

  it('blocks the whole set on a mixed discriminator', () => {
    const recs = threeHosts(TIE, DISC);
    recs[0] = verdict(hostUrl('a.example', '/p0'), TIE, [
      cand('win', { multiline: 0.9 }),
      cand('lose', { multiline: 0.1 }),
    ]);
    const out = T.teach(recs);
    assert.equal(out.lessons[0].status, 'blocked');
    assert.equal(out.lessons[0].blockedReason, 'contradiction');
    assert.equal(out.lessons[0].discriminator, null);
  });

  it('blocks unexplained (null discriminator) rather than promoting a guess', () => {
    const recs = threeHosts(TIE, DISC);
    recs[0] = verdict(hostUrl('a.example', '/p0'), TIE, [
      cand('win', { sendAffinity: 0.4 }),
      cand('lose', { sendAffinity: 0.4 }),
    ]);
    const out = T.teach(recs);
    assert.equal(out.lessons[0].status, 'blocked');
    assert.equal(out.lessons[0].blockedReason, 'contradiction');
  });

  it('blocks a fully unexplained set rather than guessing a signal', () => {
    const recs = threeHosts(TIE, DISC).map((r) => {
      if (r.type !== 'verdict') return r;
      return verdict(r.url, TIE, [cand('win', { sendAffinity: 0.4 }), cand('lose', { sendAffinity: 0.4 })]);
    });
    const out = T.teach(recs);
    assert.equal(out.lessons[0].status, 'blocked');
    assert.equal(out.lessons[0].blockedReason, 'unexplained');
    assert.equal(out.lessons[0].discriminator, null);
  });

  it('never writes conversation text into a lesson', () => {
    const recs = threeHosts(TIE, DISC);
    recs[0].text = 'secret prompt';
    recs[1].prompt = 'do not store me';
    const out = T.teach(recs);
    const blob = JSON.stringify(out.lessons);
    assert.equal(blob.includes('secret'), false);
    assert.equal(blob.includes('prompt'), false);
    assert.equal(blob.includes('do not store'), false);
  });
});

describe('teacher: apply', () => {
  const lesson = {
    tiedOn: TIE,
    discriminator: DISC,
    status: 'promoted',
    n: 3,
    hosts: 3,
  };

  it('refuses to apply a provisional lesson', () => {
    const crowd = [cand('a', { sendAffinity: 0.9 }), cand('b', { sendAffinity: 0.1 })];
    const hit = T.applyLesson(crowd, TIE, [{ ...lesson, status: 'provisional' }]);
    assert.equal(hit, null);
  });

  it('refuses to apply a blocked lesson', () => {
    const crowd = [cand('a', { sendAffinity: 0.9 }), cand('b', { sendAffinity: 0.1 })];
    const hit = T.applyLesson(crowd, TIE, [{ ...lesson, status: 'blocked' }]);
    assert.equal(hit, null);
  });

  it('applies only when the discriminator uniquely separates with margin ≥ MIN_MARGIN', () => {
    const crowd = [cand('a', { sendAffinity: 0.9 }, { score: 0.5 }), cand('b', { sendAffinity: 0.1 }, { score: 0.5 })];
    const hit = T.applyLesson(crowd, TIE, [lesson]);
    assert.ok(hit);
    assert.equal(hit.winner.stabilityKey, 'a');
    assert.ok(hit.margin >= T.MIN_MARGIN);
  });

  it('leaves the refusal standing when the margin is too thin', () => {
    const crowd = [cand('a', { sendAffinity: 0.5 }), cand('b', { sendAffinity: 0.45 })];
    const hit = T.applyLesson(crowd, TIE, [lesson]);
    assert.equal(hit, null);
  });

  it('does not apply a lesson for a different tie', () => {
    const crowd = [cand('a', { sendAffinity: 0.9 }), cand('b', { sendAffinity: 0.1 })];
    const hit = T.applyLesson(crowd, ['multiline'], [lesson]);
    assert.equal(hit, null);
  });

  it('does not apply when two candidates share the discriminator', () => {
    const crowd = [
      cand('a', { sendAffinity: 0.9 }),
      cand('b', { sendAffinity: 0.9 }),
      cand('c', { sendAffinity: 0.1 }),
    ];
    const hit = T.applyLesson(crowd, TIE, [lesson]);
    assert.equal(hit, null);
  });

  it('does not pick a candidate below the score floor', () => {
    const crowd = [
      cand('a', { sendAffinity: 0.5 }, { score: 0.5 }),
      cand('b', { sendAffinity: 0.1 }, { score: 0.5 }),
      cand('c', { sendAffinity: 0.9 }, { score: 0.2 }),
    ];
    const hit = T.applyLesson(crowd, TIE, [lesson], { minScore: 0.42, minMargin: 0.12 });
    assert.ok(hit);
    assert.equal(hit.winner.stabilityKey, 'a');
  });

  it('does not seat a third-place candidate that was never in the tie', () => {
    const crowd = [
      cand('a', { sendAffinity: 0.5 }, { score: 0.6 }),
      cand('b', { sendAffinity: 0.5 }, { score: 0.5 }),
      cand('c', { sendAffinity: 0.9 }, { score: 0.43 }),
    ];
    const hit = T.applyLesson(crowd, TIE, [lesson], { minScore: 0.42, minMargin: 0.12 });
    assert.equal(hit, null);
  });

  it('a three-way close crowd may still be broken if the discriminator uniquely separates all of them', () => {
    const crowd = [
      cand('a', { sendAffinity: 0.4 }, { score: 0.6 }),
      cand('b', { sendAffinity: 0.2 }, { score: 0.55 }),
      cand('c', { sendAffinity: 0.9 }, { score: 0.5 }),
    ];
    const hit = T.applyLesson(crowd, TIE, [lesson], { minScore: 0.42, minMargin: 0.12 });
    assert.ok(hit);
    assert.equal(hit.winner.stabilityKey, 'c');
  });

  it('refuses to apply when a tied candidate is missing the discriminator', () => {
    const a = cand('a', { sendAffinity: 0.9 }, { score: 0.5 });
    const b = cand('b', { sendAffinity: 0.1 }, { score: 0.5 });
    delete b.signals.sendAffinity;
    const hit = T.applyLesson([a, b], TIE, [lesson], { minScore: 0.42, minMargin: 0.12 });
    assert.equal(hit, null);
  });
});

describe('teacher: persist', () => {
  it('writes a bounded json file, never jsonl, never text fields', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff-lessons-'));
    const store = new T.LessonStore(dir);
    store.replace([
      {
        tiedOn: TIE,
        discriminator: DISC,
        status: 'promoted',
        n: 3,
        hosts: 3,
        text: 'drop me',
        prompt: 'drop me too',
      },
    ]);
    const file = path.join(dir, 'lessons.json');
    assert.equal(fs.existsSync(file), true);
    assert.equal(fs.existsSync(path.join(dir, 'lessons.jsonl')), false);
    const raw = fs.readFileSync(file, 'utf8');
    assert.equal(raw.includes('drop me'), false);
    const again = new T.LessonStore(dir);
    assert.equal(again.promoted().length, 1);
    assert.equal(again.promoted()[0].discriminator, DISC);
  });

  it('reads a jsonl log and never promotes a provisional lesson from it', () => {
    const recs = threeHosts(TIE, DISC).slice(0, 4);
    const text = recs.map((r) => JSON.stringify(r)).join('\n');
    const out = T.teachFromText(text);
    assert.equal(out.lessons[0].status, 'provisional');
    const hit = T.applyLesson(
      [cand('a', { sendAffinity: 0.9 }), cand('b', { sendAffinity: 0.1 })],
      TIE,
      out.lessons,
    );
    assert.equal(hit, null);
  });
});

describe('teacher: does not retune detection', () => {
  it('refuses to teach from a broken chain and names the break', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff-teach-chain-'));
    const { AnchorLog } = require('../src/main/anchors.js');
    const log = new AnchorLog(dir);
    for (const rec of threeHosts(TIE, DISC)) log.append(rec);
    const promoted = T.teachFromFile(log.logPath);
    assert.equal(promoted.refused, undefined);
    assert.equal(promoted.lessons[0].status, 'promoted');

    fs.appendFileSync(
      log.logPath,
      JSON.stringify({ type: 'pick', url: 'https://evil.example/chat', ok: true, prev: 'wrong', hash: 'wrong' }) + '\n'
    );
    const refused = T.teachFromFile(log.logPath);
    assert.equal(refused.refused, true);
    assert.equal(refused.reason, 'chain-break');
    assert.match(refused.detail, /Integrity failure/);
    assert.equal(refused.lessons.length, 0);
    assert.equal(refused.stats.promoted, 0);
  });

  it('uses the same margin floor as detect, and leaves COMPOSER_WEIGHTS alone', () => {
    const { CONFIG } = require('../src/detector/detect.js');
    assert.equal(T.MIN_MARGIN, CONFIG.MIN_MARGIN);
    const before = { ...COMPOSER_WEIGHTS };
    T.teach(threeHosts(TIE, DISC));
    assert.deepEqual(COMPOSER_WEIGHTS, before);
  });
});
