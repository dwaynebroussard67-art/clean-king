'use strict';

/**
 * The SOUND find. Unique badge, unique strong id, or unique text.
 * Structure, class, href never commit. A crowd is a miss, never a first match.
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  stamp,
  capture,
  find,
  reanchor,
  suggest,
  normalizeText,
  version,
  OWN_PREFIX,
} = require('../src/detector/reanchor.js');

function el(tag, attrs = {}, children = [], text = '') {
  const n = {
    nodeType: 1,
    tagName: String(tag).toUpperCase(),
    attrs: { ...attrs },
    children: [],
    childNodes: [],
    shadowRoot: null,
    _text: text,
    getAttribute(k) {
      const v = this.attrs[k];
      return v == null ? null : String(v);
    },
    setAttribute(k, v) {
      this.attrs[k] = String(v);
    },
    get textContent() {
      return this._text + this.children.map((c) => c.textContent).join('');
    },
    set textContent(v) {
      this._text = String(v);
      this.children = [];
      this.childNodes = [];
    },
  };
  for (const c of children) {
    n.children.push(c);
    n.childNodes.push(c);
  }
  return n;
}

function doc(root) {
  return { documentElement: root };
}

test('the engine names itself v8', () => {
  assert.equal(version, 'v8.0.0');
});

test('tier 1: a badge is unique by construction and survives a sibling rotation', () => {
  const a = el('button', { id: 'go' }, [], 'Go');
  const b = el('button', { id: 'stop' }, [], 'Stop');
  const root = el('div', {}, [a, b]);
  const id = stamp(a);
  assert.ok(id.startsWith(OWN_PREFIX));
  const fp = capture(a);
  root.children.reverse();
  root.childNodes = [...root.children];
  assert.equal(find(fp, doc(root)), a);
  assert.equal(reanchor(fp, doc(root)), a);
});

test('tier 2: a strong id commits only when it is the only one in the document', () => {
  const a = el('input', { name: 'prompt', id: 'box' });
  const b = el('input', { name: 'other' });
  const root = el('form', {}, [a, b]);
  stamp(a);
  const fp = capture(a);
  fp.ownId = null; // badge gone — a remount
  a.attrs['data-frg-id'] = undefined;
  a.setAttribute('id', 'box');
  assert.equal(find(fp, doc(root)), a);

  const twin = el('input', { name: 'prompt', id: 'box2' });
  root.children.push(twin);
  root.childNodes = [...root.children];
  // name=prompt is now on two elements; id=box is still unique
  const byName = { ownId: null, strong: { name: 'prompt' }, weak: {}, text: '', tag: 'input' };
  assert.equal(find(byName, doc(root)), null, 'a duplicated strong signal is a miss, never first-match');
  const byId = { ownId: null, strong: { id: 'box' }, weak: {}, text: '', tag: 'input' };
  assert.equal(find(byId, doc(root)), a);
});

test('tier 3: unique text commits; colliding text does not', () => {
  const a = el('button', { class: 'btn' }, [], 'Send');
  const b = el('button', { class: 'btn' }, [], 'Cancel');
  const root = el('div', {}, [a, b]);
  const fp = { ownId: null, strong: {}, weak: { class: 'btn' }, text: 'Send', tag: 'button' };
  assert.equal(find(fp, doc(root)), a);

  b._text = 'Send';
  assert.equal(find(fp, doc(root)), null, 'two Sends is a miss, not the first Send');
});

test('tier 3 strips bidi marks so a wrap-only mutation still matches', () => {
  const a = el('span', {}, [], 'Hello');
  const root = el('div', {}, [a]);
  const fp = capture(a);
  fp.ownId = null;
  a._text = '\u202EHello\u202C';
  assert.equal(normalizeText(a.textContent), 'Hello');
  assert.equal(find(fp, doc(root)), a);
});

test('class, href, src, and sibling index never commit', () => {
  const a = el('a', { href: '/x', class: 'nav' }, [], 'Home');
  const b = el('a', { href: '/x', class: 'nav' }, [], 'Away');
  const root = el('nav', {}, [a, b]);
  const fp = {
    ownId: null,
    strong: {},
    weak: { href: '/x' },
    text: '',
    tag: 'a',
  };
  assert.equal(find(fp, doc(root)), null, 'href is weak: never a commit');

  // A structural first-child grab would return `a` after rotation of identical
  // empty-text nodes. The engine has no tag+index path, so it misses.
  const c1 = el('li', { class: 'item' });
  const c2 = el('li', { class: 'item' });
  const list = el('ul', {}, [c1, c2]);
  const first = { ownId: null, strong: {}, weak: {}, text: '', tag: 'li' };
  assert.equal(find(first, doc(list)), null);
  list.children.reverse();
  list.childNodes = [...list.children];
  assert.equal(find(first, doc(list)), null, 'child rotation cannot produce a wrong grab because structure is not a commit');
});

test('suggest is unconfirmed and find never calls it', () => {
  const a = el('a', { href: '/same' }, [], 'One');
  const b = el('a', { href: '/same' }, [], 'Two');
  const root = el('div', {}, [a, b]);
  const fp = { ownId: null, strong: {}, weak: { href: '/same' }, text: 'One', tag: 'a' };
  const hint = suggest(fp, doc(root));
  assert.equal(hint.confirmed, false);
  assert.ok(hint.element);
  // find still requires uniqueness of a COMMIT signal. href is not one.
  // text+tag "One" is unique, so find may hit via tier 3 — that is a commit
  // on text, not on the suggestion.
  assert.equal(find(fp, doc(root)), a);
  const weakOnly = { ownId: null, strong: {}, weak: { href: '/same' }, text: '', tag: 'a' };
  assert.equal(find(weakOnly, doc(root)), null);
  const hinted = suggest(weakOnly, doc(root));
  assert.equal(hinted.confirmed, false);
});

test("a page id that merely starts with frg- is the page's, not a stamp", () => {
  const a = el('textarea', { id: 'frg-composer' }, [], '');
  const root = el('form', {}, [a]);
  const id = stamp(a);
  assert.ok(id.startsWith(OWN_PREFIX));
  assert.equal(a.getAttribute('id'), 'frg-composer', "the page's own id is not overwritten");
  assert.equal(a.getAttribute('data-frg-id'), id);
  const fp = capture(a);
  assert.equal(fp.ownId, id);
  assert.equal(fp.strong.id, 'frg-composer', 'the page id remains a strong signal, not our badge');
  assert.equal(find(fp, doc(root)), a);
});

test('a missing fingerprint or scope is a miss, never a throw', () => {
  assert.equal(find(null, doc(el('div'))), null);
  assert.equal(find({ ownId: 'frg-nope', strong: {}, weak: {}, text: '', tag: 'div' }, null), null);
  assert.equal(stamp(null), undefined);
  assert.equal(capture(null), null);
});

const detect = require('../src/detector/detect.js');
const { PickStore } = require('../src/main/picks.js');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

test('detect.reanchorEditable is a miss on nothing, never a throw, and never a guess', () => {
  assert.equal(detect.reanchorEditable(null, null), null);
  assert.equal(detect.reanchorEditable({}, { ownId: 'frg-x', strong: {}, weak: {}, text: '', tag: 'div' }), null);
});

test('a remembered pick on disk is still only a join key — no composer text, no engine id', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ff-reanchor-picks-'));
  const store = new PickStore(dir);
  store.set('chat.example', {
    stabilityKey: 'abcdef0123456789',
    path: 'body>form:1>textarea',
    id: 'frg-should-not-land',
    textContent: 'secret prompt',
    ariaLabel: 'Message',
  });
  const raw = JSON.parse(fs.readFileSync(path.join(dir, 'picks.json'), 'utf8'));
  const rec = raw['chat.example'];
  assert.equal(rec.stabilityKey, 'abcdef0123456789');
  assert.equal(rec.path, 'body>form:1>textarea');
  assert.equal(rec.id, undefined);
  assert.equal(rec.textContent, undefined);
  assert.equal(rec.ariaLabel, undefined);
  assert.deepEqual(Object.keys(rec).sort(), ['path', 'savedAt', 'stabilityKey']);
});
