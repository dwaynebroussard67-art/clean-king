'use strict';

/**
 * equation.test.js — the equation form of claim identity (D16).
 *
 * The headline test is the measured blocker from the record: three phrasings
 * of one fact, three claims, one witness each, nothing ever promotes. Under
 * the equation form they are ONE claim, and the witness counting that the
 * passport exists for finally engages.
 *
 * Just as important, the safety rules:
 *   - a different object is a DIFFERENT claim, never a merge
 *   - time and units partition identity
 *   - an unclean or ungrounded nomination keeps the prose form and merges
 *     with nothing
 *   - a malformed nomination is refused by the boundary, by name
 *   - an imported equation is a re-nomination, not a carried identity
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const {
  canonicalEquation,
  equationSignature,
  renderEquation,
  acceptEquation,
  nominateEquation,
  normalizeField,
} = require('../src/passport/equation.js');
const { claimSignature } = require('../src/passport/core.js');
const { Passport } = require('../src/passport/index.js');
const { WriteBoundaryError } = require('../src/passport/writeBoundary.js');

// ------------------------------------------------------------- canonical form

test('normalisation strips articles, punctuation and case', () => {
  assert.equal(normalizeField('  The France. '), 'france');
  assert.equal(normalizeField('“Paris”'), 'paris');
  assert.equal(normalizeField("France's"), "france's");
});

test('the three measured phrasings are one canonical equation', () => {
  const a = acceptEquation(nominateEquation('The capital of France is Paris.'), 'The capital of France is Paris.');
  const b = acceptEquation(nominateEquation('Paris is the capital of France.'), 'Paris is the capital of France.');
  const c = acceptEquation(nominateEquation('France has Paris as its capital.'), 'France has Paris as its capital.');
  assert.ok(a && !a.rejected && b && !b.rejected && c && !c.rejected);
  assert.deepEqual(a, b);
  assert.deepEqual(a, c);
  assert.equal(equationSignature(a, 'global'), equationSignature(b, 'global'));
  assert.equal(equationSignature(a, 'global'), equationSignature(c, 'global'));
});

test("the possessive shape reduces too: France's capital is Paris", () => {
  const n = nominateEquation("France's capital is Paris");
  assert.ok(n, 'nominated');
  const a = acceptEquation(n, "France's capital is Paris");
  const b = acceptEquation(nominateEquation('The capital of France is Paris.'), 'The capital of France is Paris.');
  assert.deepEqual(a, b);
});

test('the equation renders as predicate(subject) = object', () => {
  const a = acceptEquation(nominateEquation('The capital of France is Paris.'), 'The capital of France is Paris.');
  assert.equal(renderEquation(a), 'capital(france) = paris');
  const withTime = canonicalEquation({ subject: 'france', predicate: 'capital', object: 'paris', time: '2026' });
  assert.equal(renderEquation(withTime), 'capital(france) = paris [as of 2026]');
});

// ----------------------------------------------------------- identity is conjunctive

test('a different object is a different claim, never a merge', () => {
  const paris = equationSignature(canonicalEquation({ subject: 'france', predicate: 'capital', object: 'paris' }));
  const lyon = equationSignature(canonicalEquation({ subject: 'france', predicate: 'capital', object: 'lyon' }));
  assert.notEqual(paris, lyon);
});

test('a different subject or predicate is a different claim', () => {
  const base = canonicalEquation({ subject: 'france', predicate: 'capital', object: 'paris' });
  assert.notEqual(equationSignature(base), equationSignature({ ...base, subject: 'japan' }));
  assert.notEqual(equationSignature(base), equationSignature({ ...base, predicate: 'largest city' }));
});

test('time and units partition identity', () => {
  const base = canonicalEquation({ subject: 'france', predicate: 'capital', object: 'paris' });
  assert.notEqual(equationSignature(base), equationSignature({ ...base, time: '1900' }));
  assert.notEqual(equationSignature(base), equationSignature({ ...base, units: 'km' }));
  assert.equal(
    equationSignature({ ...base, time: '1900' }),
    equationSignature({ ...base, time: '1900' })
  );
});

test('scope partitions equation identity exactly as it does prose', () => {
  const eq = canonicalEquation({ subject: 'france', predicate: 'capital', object: 'paris' });
  assert.notEqual(equationSignature(eq, 'global'), equationSignature(eq, 'work'));
});

test('an equation signature can never collide with a prose signature', () => {
  const eq = canonicalEquation({ subject: 'a', predicate: 'b', object: 'c' });
  assert.notEqual(equationSignature(eq), claimSignature('a|b|c'));
});

// ------------------------------------------------------- code decides: grounding

test('a nomination whose subject or object is absent from the prose is rejected', () => {
  const v = acceptEquation({ subject: 'france', predicate: 'capital', object: 'tokyo' }, 'The capital of France is Paris.');
  assert.equal(v.rejected, true);
  assert.equal(v.reason, 'ungrounded');
});

test('an oversized field is not a reduction and is rejected', () => {
  const prose = `The capital of France is ${'x'.repeat(400)}.`;
  const v = acceptEquation({ subject: 'france', predicate: 'capital', object: 'x'.repeat(400) }, prose);
  assert.equal(v.rejected, true);
  assert.equal(v.reason, 'shape');
});

// ------------------------------------------------------------- the placeholder nominator

test('the nominator declines what it does not cleanly recognise', () => {
  assert.equal(nominateEquation('What a great question, let me think about that.'), null);
  assert.equal(nominateEquation(''), null);
});

// ----------------------------------------------------- the boundary decides

function tmpPassport() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-eq-'));
  return new Passport(dir);
}

test('two seats phrasing one fact differently land on ONE claim with TWO witnesses', () => {
  const p = tmpPassport();
  const a = p.ingestReply({
    seatName: 'Claude', host: 'claude.ai', prompt: 'capital of france?',
    text: 'The capital of France is Paris.', runId: 'r1', round: 1,
    equation: nominateEquation('The capital of France is Paris.'),
  });
  const b = p.ingestReply({
    seatName: 'Chatgpt', host: 'chatgpt.com', prompt: 'capital of france?',
    text: 'Paris is the capital of France.', runId: 'r1', round: 2,
    equation: nominateEquation('Paris is the capital of France.'),
  });
  assert.ok(a && b);
  assert.equal(a.claim.id, b.claim.id, 'same claim');
  assert.equal(a.claim.form, 'equation');
  assert.equal(b.claim.confirmationCount, 2, 'two distinct witnesses stacked');
  assert.equal(renderEquation(b.claim.equation), 'capital(france) = paris');
});

test('cross-agreement fires when phrasings collapse to one claim', () => {
  const p = tmpPassport();
  const results = [
    {
      ok: true,
      seatId: 1, seatName: 'Claude', round: 1, role: 'answer',
      text: 'The capital of France is Paris.',
      memory: p.ingestReply({ seatName: 'Claude', host: 'claude.ai', prompt: 'q', text: 'The capital of France is Paris.', runId: 'r9', round: 1, equation: nominateEquation('The capital of France is Paris.') }),
    },
    {
      ok: true,
      seatId: 2, seatName: 'Gemini', round: 2, role: 'answer',
      text: 'France has Paris as its capital.',
      memory: p.ingestReply({ seatName: 'Gemini', host: 'gemini.google.com', prompt: 'q', text: 'France has Paris as its capital.', runId: 'r9', round: 2, equation: nominateEquation('France has Paris as its capital.') }),
    },
  ].map((r) => ({ ...r, memory: r.memory ? { claim: r.memory.claim } : null }));
  const c = p.recordDisagreement('r9', results);
  assert.equal(c.kind, 'cross_agreement', `got ${c.kind}`);
  assert.equal(c.agreementCount, 2);
});

test('an unaccepted nomination keeps the prose form and merges with nothing', () => {
  const p = tmpPassport();
  const a = p.ingestReply({
    seatName: 'Claude', host: 'claude.ai', prompt: 'q',
    text: 'What a great question, let me think about that.', runId: 'r1', round: 1,
    equation: { subject: 'france', predicate: 'capital', object: 'paris' }, // ungrounded nomination
  });
  assert.ok(a);
  assert.equal(a.claim.form, 'prose', 'rejected nomination keeps prose form');
  assert.equal(a.claim.equation, null);
  assert.equal(a.memory.metadata.equation_rejected, 'ungrounded', 'the rejection reason is visible');
  // A later real equation on the same topic does NOT merge into the prose claim.
  const b = p.ingestReply({
    seatName: 'Chatgpt', host: 'chatgpt.com', prompt: 'q',
    text: 'The capital of France is Paris.', runId: 'r1', round: 2,
    equation: nominateEquation('The capital of France is Paris.'),
  });
  assert.notEqual(a.claim.id, b.claim.id, 'prose and equation forms never merge');
});

test('a structurally malformed nomination is refused by name', () => {
  const p = tmpPassport();
  assert.throws(
    () =>
      p.boundary.propose({
        type: 'fact',
        title: 't',
        content: 'The capital of France is Paris.',
        confidence: 0.4,
        tags: [],
        metadata: {
          witness_kind: 'outcome',
          reference: 'test',
          equation: { subject: 'france', predicate: 'capital' }, // no object
        },
      }),
    (e) => e instanceof WriteBoundaryError && e.field === 'metadata.equation.object'
  );
  assert.throws(
    () =>
      p.boundary.propose({
        type: 'fact',
        title: 't',
        content: 'x',
        confidence: 0.4,
        tags: [],
        metadata: { witness_kind: 'outcome', reference: 'test', equation: { subject: 'a', predicate: 'b', object: 'c', status: 'supported' } },
      }),
    (e) => e instanceof WriteBoundaryError && e.field === 'metadata.equation.status'
  );
});

test('prose identity is unchanged — existing stores replay identically', () => {
  const p = tmpPassport();
  const a = p.ingestReply({ seatName: 'A', host: 'a.com', prompt: 'q', text: 'the sky is blue', runId: 'r1', round: 1 });
  assert.equal(a.claim.form, 'prose');
  assert.equal(a.claim.signature, claimSignature('the sky is blue'));
});

// ------------------------------------------------------------- portability

test('an equation crosses a file boundary as a re-nomination, not an identity', () => {
  const p = tmpPassport();
  p.ingestReply({ seatName: 'A', host: 'a.com', prompt: 'q', text: 'The capital of France is Paris.', runId: 'r1', round: 1, equation: nominateEquation('The capital of France is Paris.') });
  const bundle = JSON.parse(JSON.stringify(p.export()));
  assert.equal(bundle.claims[0].form, 'equation');

  // The attack: edit the file so the equation claims something the text never said.
  bundle.claims[0].equation = { subject: 'france', predicate: 'capital', object: 'tokyo' };
  const q = tmpPassport();
  const r = q.importBundle(bundle);
  assert.equal(r.ok, true);
  const claim = [...q.store.claims.values()][0];
  assert.equal(claim.form, 'prose', 'the forged equation was not accepted');
  assert.equal(claim.equation, null);

  // Without the edit, the same import re-derives the SAME equation claim.
  const clean = JSON.parse(JSON.stringify(p.export()));
  const s = tmpPassport();
  s.importBundle(clean);
  const same = [...s.store.claims.values()][0];
  assert.equal(same.form, 'equation');
  assert.equal(renderEquation(same.equation), 'capital(france) = paris');
});
