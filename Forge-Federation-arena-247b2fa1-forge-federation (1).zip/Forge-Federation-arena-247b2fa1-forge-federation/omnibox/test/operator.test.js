'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { OperatorStore, normalizeName, authorizeActor } = require('../src/main/operator.js');

function tmp() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ff-op-'));
}

test('normalizeName refuses a one-letter label and a blank', () => {
  assert.equal(normalizeName('D'), null);
  assert.equal(normalizeName(' '), null);
  assert.equal(normalizeName('Ada'), 'Ada');
});

test('a name on disk is not this launch — sign in every time', () => {
  const store = new OperatorStore(tmp(), {});
  assert.equal(store.get(), null);
  assert.equal(store.name(), null);
  const r = authorizeActor(store, { actor: 'Mallory' });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'not-signed-in');
});

test('set remembers a name; authorize still waits for sign-in', () => {
  const store = new OperatorStore(tmp(), {});
  const set = store.set('Ada');
  assert.equal(set.ok, true);
  assert.equal(store.get().name, 'Ada');
  assert.equal(store.name(), null);
  assert.equal(store.status().signedIn, false);
  assert.equal(store.status().configured, 'Ada');
  const closed = authorizeActor(store, { actor: 'Mallory' });
  assert.equal(closed.ok, false);
  assert.equal(closed.reason, 'not-signed-in');
});

test('the renderer-supplied actor is ignored; this launch\'s signed name is what signs', () => {
  const store = new OperatorStore(tmp(), {});
  store.set('Ada');
  const inr = store.signIn('Ada');
  assert.equal(inr.ok, true);
  const r = authorizeActor(store, { actor: 'Mallory' });
  assert.equal(r.ok, true);
  assert.equal(r.actor, 'Ada');
});

test('a name on disk does not become this launch unless it is typed', () => {
  const store = new OperatorStore(tmp(), {});
  store.set('Ada');
  const silent = store.signIn();
  assert.equal(silent.ok, false);
  assert.equal(silent.reason, 'not-signed-in');
  assert.equal(store.name(), null);
  const typed = store.signIn('Ada');
  assert.equal(typed.ok, true);
  assert.equal(store.name(), 'Ada');
});

test('a new name typed at the gate starts the launch and is remembered', () => {
  const other = new OperatorStore(tmp(), {});
  const typed = other.signIn('Grace');
  assert.equal(typed.ok, true);
  assert.equal(other.get().name, 'Grace');
  assert.equal(other.name(), 'Grace');
});

test('FORGEFLIGHT_OPERATOR locks the name; even then this launch must confirm', () => {
  const dir = tmp();
  const store = new OperatorStore(dir, { FORGEFLIGHT_OPERATOR: 'Grace' });
  assert.equal(store.name(), null);
  assert.equal(store.status().configured, 'Grace');
  assert.equal(store.status().envLocked, true);
  assert.equal(store.get().source, 'env');
  const set = store.set('Ada');
  assert.equal(set.ok, false);
  assert.equal(set.reason, 'env-locked');
  const wrong = store.signIn('Ada');
  assert.equal(wrong.ok, false);
  assert.equal(wrong.reason, 'env-locked');
  const ok = store.signIn();
  assert.equal(ok.ok, true);
  assert.equal(ok.name, 'Grace');
  assert.equal(store.name(), 'Grace');
});

test('OMNIBOX_OPERATOR is still honoured when the new variable is unset', () => {
  const store = new OperatorStore(tmp(), { OMNIBOX_OPERATOR: 'Ada' });
  assert.equal(store.name(), null);
  assert.equal(store.signIn().ok, true);
  assert.equal(store.name(), 'Ada');
});

test('a one-letter set is refused so D cannot sneak in as a name of convenience', () => {
  const store = new OperatorStore(tmp(), {});
  const r = store.set('D');
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'bad-name');
  assert.equal(store.name(), null);
});
