/**
 * forge.test.js — the Code Forge loop, pinned down.
 *
 * Structure mirrors the engine's own test files: baseline cases first (does the
 * loop do what it says it does), then attack probes (can a seat spend past its
 * cap, force a release, break a passing test, or tamper with the memory).
 *
 * The tree is a tiny language: `F(name)` is a failing test. A patch removes
 * failing tests with `-F(name)` and adds them with `+F(name)`. Green is a tree
 * with no `F(...)` tokens. The referee parses it; `apply` applies it. Real
 * code is opaque to the loop, so the same loop runs unchanged over real trees.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');

const {
  CodeForge,
  ForgeRecorder,
  ForgeBudget,
  BudgetExceededError,
  ProposalStateError,
  MAX_ROUNDS,
  PROMOTE_AFTER,
  chainHash,
  CHAIN_GENESIS,
  isRegression,
  newlyBroken,
  fixedTests,
} = require('../src/forge/index.js');

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

// ── The failing-test tree language ────────────────────────────────────────

function failingOf(tree) {
  if (typeof tree !== 'string') return [];
  const out = [];
  const re = /F\(([^)]*)\)/g;
  let m;
  while ((m = re.exec(tree)) !== null) out.push(m[1]);
  return out.sort();
}

function treeOf(names) {
  return names.length ? names.slice().sort().map((n) => `F(${n})`).join(' ') : '';
}

const setsEqual = (a, b) => a.size === b.size && [...a].every((x) => b.has(x));

function referee(over = {}) {
  return {
    async verdict(tree) {
      if (over.verdict) return over.verdict(tree);
      const failing = failingOf(tree);
      if (failing.length === 0) return { status: 'green' };
      return { status: 'red', failing };
    },
  };
}

function apply(over = {}) {
  return (tree, patch) => {
    if (over.apply) return over.apply(tree, patch);
    const cur = new Set(failingOf(tree));
    const remove = [];
    const add = [];
    for (const t of String(patch).split(/\s+/).filter(Boolean)) {
      if (t.startsWith('-F(')) remove.push(t.slice(3, -1));
      else if (t.startsWith('+F(')) add.push(t.slice(3, -1));
      else return { ok: false, reason: `unparseable patch token: ${t}` };
    }
    const next = new Set(cur);
    for (const r of remove) next.delete(r);
    for (const a of add) next.add(a);
    if (setsEqual(cur, next)) return { ok: true, changed: false, tree };
    return { ok: true, changed: true, tree: treeOf([...next]) };
  };
}

function seat(id, replies, calls) {
  let i = 0;
  return {
    id,
    label: id,
    propose: async (ctx) => {
      if (calls) calls.push({ ctx });
      const r = typeof replies === 'function' ? replies(ctx, i) : replies[Math.min(i, replies.length - 1)];
      i += 1;
      return r;
    },
  };
}

function baseSpec(over = {}) {
  return {
    goal: 'make the tests pass',
    trunk: 'F(auth) F(login)',
    seats: [],
    referee: referee(),
    apply: apply(),
    ...over,
  };
}

// ── Recorder: the chain and the memory ────────────────────────────────────

test('a fresh recorder starts at genesis and chains each record', () => {
  const r = new ForgeRecorder();
  assert.equal(r.head, CHAIN_GENESIS);
  const rec = r.recordAttempt({ round: 1, seatId: 's1', patchDigest: 'd1', summary: 'x', status: 'red', failing: ['auth'] });
  assert.equal(rec.prev, CHAIN_GENESIS);
  assert.equal(rec.hash, chainHash(CHAIN_GENESIS, 'attempt', rec.data));
  assert.notEqual(r.head, CHAIN_GENESIS);
});

test('verify reports zero breaks on a clean chain', () => {
  const r = new ForgeRecorder();
  r.recordAttempt({ round: 1, seatId: 's1', patchDigest: 'd1', summary: 'x', status: 'red', failing: ['auth'] });
  r.recordRefusal({ round: 1, seatId: 's2', reason: 'pass' });
  const v = r.verify();
  assert.equal(v.breaks.length, 0);
  assert.equal(v.chained, 2);
});

test('ATTACK: tampering with a record is detected, not thrown', () => {
  const r = new ForgeRecorder();
  r.recordAttempt({ round: 1, seatId: 's1', patchDigest: 'd1', summary: 'x', status: 'red', failing: ['auth'] });
  r.recordAttempt({ round: 1, seatId: 's2', patchDigest: 'd2', summary: 'y', status: 'red', failing: ['auth'] });
  r.records[0].data.status = 'green'; // edit the past
  const v = r.verify();
  assert.equal(v.breaks.length, 1);
  assert.equal(v.breaks[0].index, 0);
});

test('alreadyTried is true only after an attempt with that digest', () => {
  const r = new ForgeRecorder();
  assert.equal(r.alreadyTried('d1'), false);
  r.recordAttempt({ round: 1, seatId: 's1', patchDigest: 'd1', summary: 'x', status: 'red', failing: [] });
  assert.equal(r.alreadyTried('d1'), true);
  r.recordRefusal({ round: 1, seatId: 's2', reason: 'pass' });
  assert.equal(r.alreadyTried('d2'), false);
});

test('failureMemory is derived from the chain, most recent last, capped', () => {
  const r = new ForgeRecorder();
  r.recordAttempt({ round: 1, seatId: 's1', patchDigest: 'd1', summary: 'x', status: 'red', failing: ['auth', 'login'] });
  r.recordRegression({ round: 1, seatId: 's2', patchDigest: 'd2', broke: ['login'], whileFixing: ['auth'] });
  r.recordRefusal({ round: 2, seatId: 's1', reason: 'pass' });
  const mem = r.failureMemory(2);
  assert.equal(mem.length, 2);
  assert.match(mem[0].reason, /regression: broke login while fixing auth/);
  assert.match(mem[1].reason, /refused: pass/);
});

test('a maneuver is not a skill until PROMOTE_AFTER clean successes', () => {
  const r = new ForgeRecorder();
  const seq = ['forge.read_file', 'forge.write_file', 'forge.run_tests'];
  for (let i = 0; i < PROMOTE_AFTER - 1; i++) r.recordManoeuvre(seq, true);
  assert.deepEqual(r.promotedSequences(), []);
  r.recordManoeuvre(seq, true);
  assert.deepEqual(r.promotedSequences(), [seq]);
});

test('one failure blocks promotion forever', () => {
  const r = new ForgeRecorder();
  const seq = ['forge.read_file', 'forge.run_tests'];
  for (let i = 0; i < PROMOTE_AFTER; i++) r.recordManoeuvre(seq, true);
  r.recordManoeuvre(seq, false);
  assert.deepEqual(r.promotedSequences(), []);
});

test('a single call is not a skill', () => {
  const r = new ForgeRecorder();
  r.recordManoeuvre(['forge.read_file'], true);
  assert.equal(r.manoeuvres.size, 0);
});

// ── Budget: charge before dispatch, no refunds, unknown does not eject ────

test('an unmetered seat is counted but never ejected', () => {
  const b = new ForgeBudget();
  const u = b.chargeBeforeDispatch('s1');
  assert.equal(u.calls, 1);
  assert.equal(b.status('s1'), 'unmetered');
});

test('charge decrements remaining and throws when exhausted', () => {
  const b = new ForgeBudget();
  b.provision('s1', { maxCalls: 2, tier: 'test' });
  b.chargeBeforeDispatch('s1');
  assert.equal(b.remainingCalls('s1'), 1);
  b.chargeBeforeDispatch('s1');
  assert.throws(() => b.chargeBeforeDispatch('s1'), BudgetExceededError);
  assert.equal(b.usageFor('s1').calls, 2); // the third charge was refused, not counted
});

test('ATTACK: an exhausted seat cannot spend past its cap', () => {
  const b = new ForgeBudget();
  b.provision('s1', { maxCalls: 1, tier: 'test' });
  b.chargeBeforeDispatch('s1');
  for (let i = 0; i < 5; i++) {
    assert.throws(() => b.chargeBeforeDispatch('s1'), BudgetExceededError);
  }
  assert.equal(b.usageFor('s1').calls, 1);
});

test('no refunds: a failed dispatch is still charged, but counted honestly', () => {
  const b = new ForgeBudget();
  b.provision('s1', { maxCalls: 3, tier: 'test' });
  b.chargeBeforeDispatch('s1');
  b.markFailed('s1');
  b.markFailed('s1');
  assert.equal(b.usageFor('s1').calls, 1);
  assert.equal(b.usageFor('s1').spentOnFailure, 2);
});

test('reset clears the meter but keeps the allowance', () => {
  const b = new ForgeBudget();
  b.provision('s1', { maxCalls: 1, tier: 'test' });
  b.chargeBeforeDispatch('s1');
  b.reset('s1');
  assert.equal(b.remainingCalls('s1'), 1);
  assert.equal(b.usageFor('s1').calls, 0);
});

test('allExhausted is true only when no seat can fly', () => {
  const b = new ForgeBudget();
  b.provision('s1', { maxCalls: 1, tier: 'test' });
  assert.equal(b.allExhausted(['s1']), false);
  b.chargeBeforeDispatch('s1');
  assert.equal(b.allExhausted(['s1']), true);
});

// ── Regression arithmetic ─────────────────────────────────────────────────

test('isRegression: breaking a passing test is a regression', () => {
  const prev = { status: 'red', failing: ['auth', 'login'] };
  const next = { status: 'red', failing: ['auth', 'login', 'checkout'] };
  assert.equal(isRegression(prev, next), true);
  assert.deepEqual(newlyBroken(prev, next), ['checkout']);
  assert.deepEqual(fixedTests(prev, next), []);
});

test('isRegression: fixing a test without breaking one is not', () => {
  const prev = { status: 'red', failing: ['auth', 'login'] };
  const next = { status: 'red', failing: ['auth'] };
  assert.equal(isRegression(prev, next), false);
  assert.deepEqual(fixedTests(prev, next), ['login']);
});

test('isRegression: green to red is a regression; no baseline is not', () => {
  assert.equal(isRegression({ status: 'green' }, { status: 'red', failing: ['auth'] }), true);
  assert.equal(isRegression(null, { status: 'red', failing: ['auth'] }), false);
});

// ── The loop: baseline ────────────────────────────────────────────────────

test('goal_reached stages the winning patch and never auto-releases it', async () => {
  const spec = baseSpec({
    trunk: 'F(auth)',
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'drop auth', toolSequence: ['forge.run_tests'] }])],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.equal(r.proposal.status, 'staged');
  assert.match(r.proposal.branch, /^forge\//);
  assert.equal(r.proposal.seatId, 's1');
  assert.equal(forge.proposals.staged().length, 1);
  // The human, and only the human, releases.
  forge.proposals.release(r.proposal.id);
  assert.equal(forge.proposals.entries[0].status, 'released');
  assert.throws(() => forge.proposals.release(r.proposal.id), ProposalStateError);
});

test('the relay hands the prior seat and its tree to the next seat', async () => {
  const seen = [];
  const spec = baseSpec({
    trunk: 'F(auth) F(login)',
    seats: [
      seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'fixed auth' }]),
      seat('s2', (ctx) => {
        seen.push(ctx);
        return { kind: 'proposal', patch: '-F(login)', summary: 'finish' };
      }),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.equal(seen[0].priorSeat.id, 's1');
  assert.equal(seen[0].priorSeat.summary, 'fixed auth');
  assert.equal(seen[0].tree, 'F(login)'); // the tree the prior seat produced
});

test('failure memory loops back into the next round', async () => {
  const seen = [];
  const spec = baseSpec({
    trunk: 'F(auth) F(login)',
    seats: [
      seat('s1', (ctx, i) => {
        if (i === 0) return { kind: 'proposal', patch: '-F(auth)', summary: 'one down' };
        seen.push(ctx);
        return { kind: 'pass', reason: 'done enough' };
      }),
      seat('s2', [{ kind: 'pass', reason: 'watching' }]),
    ],
  });
  const forge = new CodeForge(spec);
  await forge.run();
  assert.ok(seen.length > 0);
  assert.ok(seen[0].failures.some((f) => /tests still failing: login/.test(f.reason)));
});

test('a regression is reverted and recorded, never accepted', async () => {
  const spec = baseSpec({
    trunk: 'F(auth) F(login)',
    seats: [
      seat('s1', [
        { kind: 'proposal', patch: '-F(auth)', summary: 'fix auth' },
        { kind: 'pass', reason: 'nothing more' },
      ]),
      seat('s2', [
        { kind: 'proposal', patch: '-F(login) +F(newbug)', summary: 'broke something' },
        { kind: 'pass', reason: 'done' },
      ]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  // The regression never advanced the tree: login is still the failing set.
  assert.equal(r.lastVerdict.failing.join(','), 'login');
  assert.ok(r.failureMemory.some((f) => /regression: broke newbug while fixing login/.test(f.reason)));
  // The chain shows the regression as a named record.
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'regression'));
});

test('round_cap stops a run that never goes green', async () => {
  // Strictly shrinking progress, never green within the cap: 6 failing, remove
  // one per round across MAX_ROUNDS rounds.
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2', 't3', 't4', 't5']),
    seats: [seat('s1', (ctx, i) => ({ kind: 'proposal', patch: `-F(t${i})`, summary: 'shrink' }))],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'round_cap');
  assert.equal(r.roundsRun, MAX_ROUNDS);
});

test('a full round of refusals is a stall, not a hang', async () => {
  const spec = baseSpec({
    seats: [seat('s1', [{ kind: 'pass', reason: 'out of depth' }]), seat('s2', [{ kind: 'pass', reason: 'watching' }])],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  assert.equal(r.roundsRun, 1);
});

test('an already-green trunk is refused by name, before any dispatch', async () => {
  const calls = [];
  const spec = baseSpec({
    trunk: '',
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(nothing)', summary: 'x' }], calls)],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'already_green');
  assert.equal(calls.length, 0);
  assert.equal(r.budget.s1.calls, 0);
});

test('an unrunnable trunk is a no_harness stop, not a guess', async () => {
  const spec = baseSpec({
    referee: referee({ verdict: async () => ({ status: 'unrunnable', reason: 'no test runner found' }) }),
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'x' }])],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'no_harness');
  assert.equal(r.roundsRun, 0);
});

test('the operator can stop the loop before it dispatches', async () => {
  const calls = [];
  const spec = baseSpec({
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'x' }], calls)],
  });
  const forge = new CodeForge(spec);
  const p = forge.run();
  forge.stop();
  const r = await p;
  assert.equal(r.stopReason, 'cancelled');
  assert.equal(calls.length, 0);
});

test('budget_exhausted stops the loop when no seat can fly', async () => {
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2', 't3', 't4']),
    budget: { s1: { maxCalls: 1, tier: 'test' }, s2: { maxCalls: 1, tier: 'test' } },
    seats: [
      seat('s1', [{ kind: 'proposal', patch: '-F(t0)', summary: 'one' }]),
      seat('s2', [{ kind: 'proposal', patch: '-F(t1)', summary: 'two' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'budget_exhausted');
});

test('a redundant patch is refused and does not re-advance the tree', async () => {
  const spec = baseSpec({
    trunk: 'F(auth) F(login)',
    seats: [
      seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'fix auth' }]),
      seat('s2', [{ kind: 'proposal', patch: '-F(auth)', summary: 'same again' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  assert.equal(r.lastVerdict.failing.join(','), 'login');
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'refusal' && rec.data.reason === 'redundant'));
});

// ── The loop: attack probes ───────────────────────────────────────────────

test('ATTACK: a seat cannot force a release — the loop only stages', async () => {
  const spec = baseSpec({
    trunk: 'F(auth)',
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'fix', toolSequence: ['forge.run_tests'] }])],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.ok(forge.proposals.entries.every((e) => e.status === 'staged'));
});

test('ATTACK: an exhausted seat is ejected on the next charge, not billed again', async () => {
  const proposeCount = { s1: 0 };
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2', 't3', 't4', 't5']),
    budget: { s1: { maxCalls: 1, tier: 'test' } },
    seats: [
      seat('s1', () => {
        proposeCount.s1 += 1;
        return { kind: 'proposal', patch: '-F(t0)', summary: 'only once' };
      }),
      seat('s2', (ctx, i) => ({ kind: 'proposal', patch: `-F(t${i + 1})`, summary: 'keep going' })),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'round_cap');
  assert.equal(proposeCount.s1, 1);
  assert.equal(r.budget.s1.calls, 1);
  assert.ok(forge.budget.ejected('s1'));
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'refusal' && rec.data.seatId === 's1' && rec.data.reason === 'budget_exhausted'));
});

test('ATTACK: a seat that throws is a named refusal, not a crash', async () => {
  const spec = baseSpec({
    seats: [
      seat('s1', async () => { throw new Error('seat blew up'); }),
      seat('s2', [{ kind: 'pass', reason: 'watching' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'refusal' && rec.data.reason === 'seat_error'));
  assert.equal(r.budget.s1.spentOnFailure, 1);
});

test('a referee that throws is an error stop, not an unhandled throw', async () => {
  const spec = baseSpec({
    referee: referee({ verdict: async (tree) => {
      if (tree !== spec.trunk) throw new Error('runner segfaulted');
      return { status: 'red', failing: ['auth', 'login'] };
    } }),
    seats: [seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'x' }])],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'error');
});

test('named refusals: bad_shape, does_not_apply, and no_change do not advance the tree', async () => {
  const spec = baseSpec({
    trunk: 'F(auth)',
    seats: [
      seat('s1', [{ kind: 'bad_shape', detail: 'returned prose instead of a patch' }]),
      seat('s2', [{ kind: 'proposal', patch: 'garbage', summary: 'not a patch' }]),
      seat('s3', [{ kind: 'proposal', patch: '-F(doesnotexist)', summary: 'no-op' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  const reasons = forge.recorder.records.filter((rec) => rec.op === 'refusal').map((rec) => rec.data.reason);
  assert.ok(reasons.includes('bad_shape'));
  assert.ok(reasons.includes('does_not_apply'));
  assert.ok(reasons.includes('no_change'));
  assert.equal(r.lastVerdict.failing.join(','), 'auth');
});

test('an empty_response is recorded as an attempt and does not advance', async () => {
  const spec = baseSpec({
    referee: referee({ verdict: async (tree) => {
      if (tree === spec.trunk) return { status: 'red', failing: ['auth'] };
      return { status: 'empty_response', reason: 'only furniture grew' };
    } }),
    seats: [
      seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'x' }]),
      seat('s2', [{ kind: 'pass', reason: 'done' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'attempt' && rec.data.status === 'empty_response'));
  assert.equal(r.lastVerdict.failing.join(','), 'auth');
});

test('the round cap cannot be raised above the engine ceiling', () => {
  const forge = new CodeForge(baseSpec({ seats: [seat('s1', [])], maxRounds: 99 }));
  assert.equal(forge.maxRounds, MAX_ROUNDS);
});

test('a patch that breaks the build is a regression, not progress', async () => {
  const spec = baseSpec({
    trunk: 'F(auth)',
    referee: referee({ verdict: async (tree) => {
      if (tree === spec.trunk) return { status: 'red', failing: ['auth'] };
      return { status: 'red', failing: [], brokenBuild: true, reason: 'SyntaxError: unexpected token' };
    } }),
    seats: [
      seat('s1', [{ kind: 'proposal', patch: '-F(auth)', summary: 'breaks the build' }]),
      seat('s2', [{ kind: 'pass', reason: 'watching' }]),
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'stalled');
  assert.equal(r.lastVerdict.failing.join(','), 'auth');
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'regression' && (rec.data.broke || []).includes('build')));
  assert.ok(r.failureMemory.some((f) => /regression: broke build while fixing auth/.test(f.reason)));
});

test('a forge without seats or a referee refuses to construct', () => {
  assert.throws(() => new CodeForge({ goal: 'x', trunk: '', apply: () => ({}) }), /at least one seat/);
  assert.throws(() => new CodeForge({ goal: 'x', trunk: '', seats: [seat('s1', [])] }), /referee/);
});

test('a forge refuses to run twice at once', async () => {
  const spec = baseSpec({
    trunk: 'F(auth)',
    seats: [seat('s1', [async () => { await delay(20); return { kind: 'proposal', patch: '-F(auth)', summary: 'x' }; }])],
  });
  const forge = new CodeForge(spec);
  const p = forge.run();
  await assert.rejects(() => forge.run(), /FORGE_BUSY/);
  await p;
});
