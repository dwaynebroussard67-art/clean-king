/**
 * Federation.test.js — the carrier, the curator, and the airlock.
 *
 * The properties under test, in the order they matter:
 *   the entry rule cannot be widened to include agreement
 *   the curator cannot write anywhere but the queue
 *   a denial always names the broken constraint and the variable
 *   the human is outside the triangle and cannot be anonymous
 *   nothing is ever deleted
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { Federation, WITNESS_KINDS, PROMOTION_THRESHOLD } = require('../src/federation/store.js');
const { ProposalQueue } = require('../src/federation/queue.js');
const { Curator, checkPrecondition, overseer } = require('../src/federation/curator.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-fed-'));
const fresh = () => {
  const dir = tmp();
  const c = new Federation(dir).load();
  const q = new ProposalQueue(dir).load();
  return { dir, c, q, cur: new Curator(c, q) };
};

const eq = (subject, predicate, object, extra = {}) => ({ subject, predicate, object, ...extra });
const world = (o = {}) => ({ shelf: 'world', witness: 'structural', nodeId: 'n1', reference: 'ref', ...o });
const ops = (o = {}) => ({ shelf: 'operational', witness: 'structural', nodeId: 'n1', reference: 'ref', target: 'claude.ai', ...o });

// ---------------------------------------------------------------- entry rule

test('agreement is not a witness kind and the store says so by name', () => {
  const { c } = fresh();
  assert.ok(!WITNESS_KINDS.includes('agreement'));
  assert.ok(!WITNESS_KINDS.includes('consensus'));
  assert.ok(!WITNESS_KINDS.includes('vote'));
  const r = c.land(world({ witness: 'agreement', equation: eq('france', 'capital', 'paris') }));
  assert.equal(r.rejected, true);
  assert.equal(r.reason, 'witness');
  assert.match(r.detail, /Agreement between nodes is not a witness kind/);
});

test('only equations land — prose that does not reduce stays in the cockpit', () => {
  const { c } = fresh();
  const r = c.land(world({ equation: { subject: 'france', predicate: '', object: 'paris' } }));
  assert.equal(r.rejected, true);
  assert.equal(r.reason, 'not-an-equation');
});

test('every witness names a node and an evidence pointer', () => {
  const { c } = fresh();
  assert.equal(c.land(world({ nodeId: '', equation: eq('a', 'b', 'c') })).reason, 'nodeId');
  assert.equal(c.land(world({ reference: '', equation: eq('a', 'b', 'c') })).reason, 'reference');
  assert.equal(c.land(world({ witness: 'human', actor: '', equation: eq('a', 'b', 'c') })).reason, 'actor');
});

test('an operational fact must name the target it is scoped to', () => {
  const { c } = fresh();
  const r = c.land({ shelf: 'operational', witness: 'structural', nodeId: 'n1', reference: 'r', equation: eq('a', 'b', 'c') });
  assert.equal(r.reason, 'target');
});

test('one node repeating itself is one witness, not five', () => {
  const { c } = fresh();
  const spec = world({ equation: eq('france', 'capital', 'paris') });
  for (let i = 0; i < 5; i++) c.land(spec);
  const f = c.live()[0];
  assert.equal(f.distinct, 1, 'repetition is not evidence');
  assert.equal(f.status, 'provisional');
});

test('five DISTINCT witnesses promote a world claim', () => {
  const { c } = fresh();
  for (let i = 1; i <= PROMOTION_THRESHOLD; i++) {
    c.land(world({ nodeId: `n${i}`, reference: `r${i}`, equation: eq('france', 'capital', 'paris') }));
  }
  assert.equal(c.live()[0].status, 'established');
  assert.equal(c.live()[0].distinct, 5);
});

// ------------------------------------------------------- the two shelves

test('a contradiction CLOSES a world claim, permanently', () => {
  const { c } = fresh();
  c.land(world({ equation: eq('france', 'capital', 'paris') }));
  const r = c.contradict(world({ nodeId: 'n2', reference: 'r2', equation: eq('france', 'capital', 'lyon') }));
  assert.equal(r.contradicted.status, 'closed');
  assert.ok(r.contradicted.closedAt);
  // and it does not reopen on a repeat
  const again = c.land(world({ nodeId: 'n3', reference: 'r3', equation: eq('france', 'capital', 'paris') }));
  assert.equal(again.rejected, true);
  assert.equal(again.reason, 'closed');
});

test('a contradiction SUPERSEDES an operational fact — the target moved', () => {
  const { c } = fresh();
  c.land(ops({ equation: eq('claude.ai', 'composer', 'prompt-input') }));
  const r = c.contradict(ops({ nodeId: 'n2', reference: 'r2', equation: eq('claude.ai', 'composer', 'new-input') }));
  assert.equal(r.contradicted.status, 'superseded');
  assert.equal(r.contradicted.supersededBy, r.fact.id);
  assert.ok(r.contradicted.closedAt, 'the old record stays, marked');
  // nothing was deleted
  assert.equal(c.facts.size, 2);
});

test('nothing is ever deleted — the store exposes no delete at all', () => {
  const { c } = fresh();
  assert.equal(typeof c.delete, 'undefined');
  assert.equal(typeof c.remove, 'undefined');
  assert.equal(typeof c.erase, 'undefined');
});

test('the chain catches an edit to history', () => {
  const { dir, c } = fresh();
  c.land(world({ equation: eq('a', 'b', 'c') }));
  c.land(world({ nodeId: 'n2', reference: 'r2', equation: eq('d', 'e', 'f') }));
  assert.equal(c.verify().breaks.length, 0);

  const p = path.join(dir, 'federation.jsonl');
  const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
  const tampered = JSON.parse(lines[0]);
  tampered.data.status = 'established';
  lines[0] = JSON.stringify(tampered);
  fs.writeFileSync(p, lines.join('\n') + '\n');

  const reopened = new Federation(dir).load();
  assert.ok(reopened.chain.breaks.length > 0, 'the edit is detected');
  assert.equal(reopened.chain.breaks[0].line, 1);
});

// ----------------------------------------------------------- the overseer

test('checkPrecondition names the variable and both sides', () => {
  const { c } = fresh();
  c.land(ops({ equation: eq('claude.ai', 'rate_limit', '0') }));
  const r = checkPrecondition(c, 'operational', eq('claude.ai', 'rate_limit', '100'));
  assert.equal(r.verdict, 'unsatisfied');
  assert.equal(r.variable, 'rate_limit(claude.ai)');
  assert.equal(r.expected, '100');
  assert.equal(r.actual, '0');
  assert.equal(r.witnesses, 1);
});

test('the overseer never sees prose — it takes equations and returns a ruling', () => {
  const { c } = fresh();
  c.land(ops({ equation: eq('claude.ai', 'rate_limit', '0') }));
  const r = overseer(c, { shelf: 'operational', preconditions: [eq('claude.ai', 'rate_limit', '100')] });
  assert.equal(r.ruling, 'blocked');
  assert.equal(r.broken.length, 1);
  const clear = overseer(c, { shelf: 'operational', preconditions: [eq('claude.ai', 'rate_limit', '0')] });
  assert.equal(clear.ruling, 'clear');
});

test('the Federation holding nothing is "unproven", never a denial', () => {
  const { c } = fresh();
  const r = overseer(c, { shelf: 'operational', preconditions: [eq('unknown.site', 'rate_limit', '5')] });
  assert.equal(r.ruling, 'unproven', 'absence of evidence is not evidence');
});

// ------------------------------------------------------------ the curator

test('a clear request passes untouched and never reaches a human', () => {
  const { cur, q } = fresh();
  const r = cur.reviewCapability({ pilot: 'seat-1', capability: 'browser.fetch', preconditions: [] });
  assert.equal(r.decision, 'no-objection');
  assert.equal(r.needsHuman, false);
  assert.equal(q.open().length, 0, 'nothing was queued');
});

test('THE DENIAL NOTICE: names the constraint, the variable, and the evidence', () => {
  const { c, cur, q } = fresh();
  for (const n of ['n1', 'n2', 'n3']) {
    c.land(ops({ nodeId: n, reference: `r-${n}`, witness: 'outcome', equation: eq('claude.ai', 'rate_limit', '0') }));
  }
  const r = cur.reviewCapability({
    pilot: 'Pilot 3',
    capability: 'browser.fetch',
    preconditions: [eq('claude.ai', 'rate_limit', '100')],
  });
  assert.equal(r.decision, 'denied-pending-human');
  assert.equal(r.needsHuman, true);
  assert.match(r.notice, /Pilot 3 requested browser\.fetch/);
  assert.match(r.notice, /rate_limit\(claude\.ai\) fails/);
  assert.match(r.notice, /3 witnesses/);
  assert.match(r.notice, /Denied pending your call/);
  assert.equal(q.open().length, 1, 'and it is queued for a human');
});

test('the curator cannot object without pointing at a broken constraint', () => {
  const { cur } = fresh();
  // No preconditions, empty Federation: there is nothing it CAN object with.
  const r = cur.reviewCapability({ pilot: 'p', capability: 'anything', preconditions: [] });
  assert.equal(r.decision, 'no-objection');
  // Malformed preconditions are refused as uncheckable, not denied on judgment.
  const m = cur.reviewCapability({ pilot: 'p', capability: 'x', preconditions: [{ subject: 'a' }] });
  assert.equal(m.decision, 'refused');
  assert.match(m.notice, /nothing was denied on judgment/);
});

test('THE CURATOR WRITES ONLY TO THE QUEUE — never to the Federation', () => {
  const { c, cur } = fresh();
  const before = c.facts.size;
  const beforeEvents = c.events.length;
  c.land(ops({ equation: eq('claude.ai', 'rate_limit', '0') }));
  const after = c.facts.size;

  cur.reviewCapability({ pilot: 'p', capability: 'x', preconditions: [eq('claude.ai', 'rate_limit', '9')] });
  cur.reviewTransfer({ shelf: 'world', equation: eq('a', 'b', 'c'), witness: 'structural', nodeId: 'n', reference: 'r' });
  cur.proposeRechecks({ days: 0 });

  assert.equal(c.facts.size, after, 'the curator landed nothing');
  assert.equal(c.events.length, beforeEvents, 'the curator wrote no events');
  assert.ok(after > before);
});

test('a transfer is proposed as a delta of equations, not a story', () => {
  const { cur, q } = fresh();
  const r = cur.reviewTransfer({
    shelf: 'world',
    equation: eq('france', 'capital', 'paris'),
    witness: 'outcome',
    nodeId: 'n1',
    reference: 'run:r1',
    replication: 3,
  });
  assert.equal(r.needsHuman, true);
  assert.equal(r.rendered, 'capital(france) = paris');
  assert.match(r.notice, /capital\(france\) = paris wants to land/);
  assert.match(r.notice, /replicated by 3 distinct nodes/);
  assert.equal(q.open().length, 1);
});

test('a transfer that conflicts says exactly what it would do', () => {
  const { c, cur } = fresh();
  c.land(world({ equation: eq('france', 'capital', 'paris') }));
  const r = cur.reviewTransfer({
    shelf: 'world',
    equation: eq('france', 'capital', 'lyon'),
    witness: 'structural',
    nodeId: 'n2',
    reference: 'r2',
  });
  assert.ok(r.conflict);
  assert.equal(r.conflict.variable, 'capital(france)');
  assert.match(r.notice, /CONFLICT on capital\(france\)/);
  assert.match(r.notice, /closes the old claim permanently/);
});

test('prose never crosses the radio', () => {
  const { cur } = fresh();
  const r = cur.reviewTransfer({ shelf: 'world', equation: { subject: 'only a subject' } });
  assert.equal(r.decision, 'refused');
  assert.match(r.notice, /stays in the cockpit/);
});

// --------------------------------------------------------- staleness

test('the curator asks for a recheck and never expires anything itself', () => {
  const { c, cur } = fresh();
  const old = new Date(Date.now() - 90 * 86400000).toISOString();
  c.land(ops({ equation: eq('claude.ai', 'composer', 'prompt-input'), at: old }));
  const before = c.live()[0].status;
  const props = cur.proposeRechecks({ days: 30 });
  assert.equal(props.length, 1);
  assert.equal(props[0].ask, 'recheck');
  assert.ok(props[0].ageDays >= 89);
  assert.match(props[0].notice, /Nothing is deleted/);
  assert.equal(c.live()[0].status, before, 'the fact is untouched');
});

// ------------------------------------------------------------- the human

test('a release names the human, or it is refused', () => {
  const { cur, q } = fresh();
  const p = cur.reviewTransfer({ shelf: 'world', equation: eq('a', 'b', 'c'), witness: 'structural', nodeId: 'n', reference: 'r' });
  const anon = q.release(p.id, { actor: '' });
  assert.equal(anon.ok, false);
  assert.equal(anon.reason, 'unsigned');
  assert.match(anon.detail, /the machine approving itself/);

  const signed = q.release(p.id, { actor: 'D', note: 'checked it' });
  assert.equal(signed.ok, true);
  assert.equal(q.get(p.id).state, 'released');
  assert.equal(q.get(p.id).actor, 'D');
});

test('a decided proposal cannot be decided twice', () => {
  const { cur, q } = fresh();
  const p = cur.reviewTransfer({ shelf: 'world', equation: eq('a', 'b', 'c'), witness: 'structural', nodeId: 'n', reference: 'r' });
  q.release(p.id, { actor: 'D' });
  const second = q.refuse(p.id, { actor: 'D' });
  assert.equal(second.ok, false);
  assert.equal(second.reason, 'already-decided');
});

test('a withdrawn proposal stays in the record', () => {
  const { dir, cur, q } = fresh();
  const p = cur.reviewTransfer({ shelf: 'world', equation: eq('a', 'b', 'c'), witness: 'structural', nodeId: 'n', reference: 'r' });
  q.withdraw(p.id, { reason: 'superseded by a better one' });
  assert.equal(q.get(p.id).state, 'withdrawn');
  const reopened = new ProposalQueue(dir).load();
  assert.equal(reopened.get(p.id).state, 'withdrawn', 'the withdrawal survived a reload');
  assert.equal(reopened.get(p.id).withdrawReason, 'superseded by a better one');
});

test('releasing does not perform the action — it only authorises it', () => {
  const { c, cur, q } = fresh();
  const p = cur.reviewTransfer({ shelf: 'world', equation: eq('a', 'b', 'c'), witness: 'structural', nodeId: 'n', reference: 'r' });
  const before = c.facts.size;
  q.release(p.id, { actor: 'D' });
  assert.equal(c.facts.size, before, 'the queue landed nothing; the Federation did not move');
});

// --------------------------------------------------------------- the alarm

test('the queue size is a measurable alarm, not a feeling', () => {
  const { cur, q } = fresh();
  assert.equal(cur.health().healthy, true);
  for (let i = 0; i < 15; i++) {
    cur.reviewTransfer({ shelf: 'world', equation: eq(`s${i}`, 'p', 'o'), witness: 'structural', nodeId: 'n', reference: `r${i}` });
  }
  const h = cur.health();
  assert.equal(h.healthy, false);
  assert.equal(h.open, 15);
  assert.match(h.detail, /funnel upstream has stopped working/);
});
