'use strict';

const test = require('node:test');
const assert = require('node:assert');

const { Table, SHAPES, MAX_ROUNDS } = require('../src/main/table.js');
const { toURL } = require('../src/main/tabs.js');
const { SeatRegistry, defaultName, hostOf } = require('../src/main/seats.js');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const seats = [
  { id: 't1', name: 'Alpha', host: 'alpha.example' },
  { id: 't2', name: 'Beta', host: 'beta.example' },
  { id: 't3', name: 'Gamma', host: 'gamma.example' },
];

/** Run a shape against a fake dispatch that echoes, and collect what was
 *  actually said to whom, in what order. */
async function drive(shape, spec = {}) {
  const sent = [];
  const io = {
    dispatch: async (seatId, text) => {
      sent.push({ seatId, text });
      return { ok: true, text: `${seatId} says something about ${text.slice(-24)}` };
    },
    emit: (event, payload) => events.push({ event, payload }),
  };
  const events = [];
  const table = new Table(io);
  const run = await table.run({ prompt: 'is it raining', shape, seats, ...spec });
  return { sent, events, run };
}

test('shapes — every shape declares itself and is capped', () => {
  for (const [id, s] of Object.entries(SHAPES)) {
    assert.ok(s.label, `${id} has a label`);
    assert.ok(s.blurb && s.blurb.length > 10, `${id} explains itself to the user`);
    assert.ok(s.rounds >= 1 && s.rounds <= MAX_ROUNDS, `${id} declares a bounded round count`);
    assert.equal(typeof s.plan, 'function');
  }
  const listed = Table.shapes().map((s) => s.id);
  assert.deepEqual(listed.sort(), Object.keys(SHAPES).sort(), 'the UI is offered exactly the shapes that exist');
});

test('communal — one prompt, everyone, unmodified', async () => {
  const { sent } = await drive('communal');
  assert.equal(sent.length, 3);
  assert.ok(sent.every((s) => s.text === 'is it raining'), 'nobody gets a framing they did not ask for');
  assert.deepEqual(sent.map((s) => s.seatId).sort(), ['t1', 't2', 't3']);
});

test('solo — only the tab you are looking at', async () => {
  const { sent } = await drive('solo', { focusId: 't2' });
  assert.equal(sent.length, 1);
  assert.equal(sent[0].seatId, 't2');
});

test('sides — the table splits and each side is told which case it argues', async () => {
  const { sent } = await drive('sides', { assignments: { t1: 'A', t2: 'B', t3: 'sit-out' } });
  assert.equal(sent.length, 2, 'a sitting-out seat is not sent to');
  const a = sent.find((s) => s.seatId === 't1').text;
  const b = sent.find((s) => s.seatId === 't2').text;
  assert.match(a, /case FOR/);
  assert.match(b, /case AGAINST/);
  assert.ok(a.endsWith('is it raining') && b.endsWith('is it raining'), 'the question survives the framing');
  assert.match(a, /weakest point honestly/, 'each side is asked to name its own weak point');
});

test('adversarial — one answers in round 1, the rest attack it in round 2', async () => {
  const { sent, run } = await drive('adversarial', { subjectId: 't1' });
  assert.equal(sent.length, 3);
  assert.equal(sent[0].seatId, 't1', 'the subject goes first, alone');
  const critiques = sent.slice(1);
  assert.deepEqual(critiques.map((c) => c.seatId).sort(), ['t2', 't3']);
  for (const c of critiques) {
    assert.match(c.text, /ANSWER \(from Alpha\)/, "the critics are shown the subject's actual answer");
    assert.match(c.text, /If the answer is sound, say so/, 'a critic may find nothing wrong and say so');
  }
  assert.equal(run.results.length, 3);
});

test('relay — the draft moves down the line and each hand sees the last one', async () => {
  const { sent } = await drive('relay', { order: ['t3', 't1', 't2'] });
  assert.deepEqual(sent.map((s) => s.seatId), ['t3', 't1', 't2'], 'order is honoured exactly');
  assert.equal(sent[0].text, 'is it raining');
  assert.match(sent[1].text, /DRAFT \(from Gamma\)/);
  assert.match(sent[2].text, /DRAFT \(from Alpha\)/);
  assert.match(sent[1].text, /say in one line what you changed/);
});

test('interview — round 1 asks for a question, round 2 puts it to the table', async () => {
  const { sent } = await drive('interview', { subjectId: 't2' });
  assert.equal(sent[0].seatId, 't2');
  assert.match(sent[0].text, /Do not answer this yet/);
  assert.match(sent[0].text, /Reply with the question only/);
  assert.equal(sent.length, 3);
  for (const s of sent.slice(1)) assert.match(s.text, /t2 says something about/, "the asker's question is what gets asked");
});

test('a run that loses its subject ends cleanly instead of throwing', async () => {
  const io = {
    dispatch: async () => ({ ok: false, reason: 'tab-gone' }),
    emit: () => {},
  };
  const run = await new Table(io).run({ prompt: 'x', shape: 'adversarial', seats, subjectId: 't1' });
  assert.equal(run.results.length, 1, 'round 2 does not run against a failed round 1');
  assert.equal(run.results[0].ok, false);
});

test('a run emits a start, a finish, and a step event per dispatch', async () => {
  const { events, sent } = await drive('communal');
  const kinds = events.map((e) => e.event);
  assert.ok(kinds.includes('run:started'));
  assert.ok(kinds.includes('run:finished'));
  assert.equal(kinds.filter((k) => k === 'step:started').length, sent.length);
  assert.equal(kinds.filter((k) => k === 'step:finished').length, sent.length);
});

test('stop halts a run in progress', async () => {
  let calls = 0;
  let table;
  const io = {
    dispatch: async () => {
      calls++;
      table.stop(`r${tableRunId}`);
      return { ok: true, text: 'ok' };
    },
    emit: (event, payload) => {
      if (event === 'run:started') tableRunId = Number(payload.runId.slice(1));
    },
  };
  let tableRunId = 0;
  table = new Table(io);
  const run = await table.run({ prompt: 'x', shape: 'relay', seats, order: ['t1', 't2', 't3'] });
  assert.ok(run.stopped, 'the run reports that it was stopped');
  assert.ok(calls < 3, `stopped after ${calls} dispatches instead of running all three`);
});

// ===========================================================================
test('one seat per host — a second tab on a seated site is not a second seat', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-seats-'));
  const reg = new SeatRegistry(dir);
  const tabs = [
    { id: 'a', url: 'https://chat.example/x', title: 'A', favicon: null, seat: { status: 'seated', confidence: 0.9 } },
    { id: 'b', url: 'https://chat.example/y', title: 'B', favicon: null, seat: { status: 'seated', confidence: 0.9 } },
    { id: 'c', url: 'https://other.example/', title: 'C', favicon: null, seat: { status: 'seated', confidence: 0.8 } },
  ];
  const { seats: s, rail } = reg.resolve(tabs);
  assert.equal(s.length, 2, 'two sites, two seats — not three tabs, three seats');
  const blocked = rail.find((r) => r.blocked === 'duplicate-host');
  assert.ok(blocked, 'the second tab on that host is blocked, by name');
  assert.match(blocked.detail, /one tab per site/i, 'and it says why in plain words');
});

test('muting a site keeps it out of the table permanently', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-seats-'));
  const reg = new SeatRegistry(dir);
  reg.setMuted('chat.example', true);
  const { seats: s } = reg.resolve([
    { id: 'a', url: 'https://chat.example/x', title: 'A', favicon: null, seat: { status: 'seated', confidence: 1 } },
  ]);
  assert.equal(s.length, 0);
  assert.ok(new SeatRegistry(dir).isMuted('chat.example'), 'and it survives a restart');
});

test('names stick to the host, and a host with no brand is not given one', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-seats-'));
  const reg = new SeatRegistry(dir);
  assert.equal(defaultName('chatgpt.com'), 'Chatgpt');
  assert.equal(defaultName('gemini.google.com'), 'Gemini');
  assert.equal(defaultName('127.0.0.1:8080'), '127.0.0.1', 'an IP is not named "127"');
  assert.equal(defaultName('localhost:3000'), 'Localhost');
  reg.rename('chatgpt.com', 'The Other One');
  assert.equal(new SeatRegistry(dir).nameFor('chatgpt.com'), 'The Other One');
});

test('the address bar tells a host from a search', () => {
  assert.equal(toURL('claude.ai'), 'https://claude.ai');
  assert.equal(toURL('https://x.com/a'), 'https://x.com/a');
  assert.equal(toURL('localhost:3000'), 'https://localhost:3000');
  assert.match(toURL('how tall is everest'), /^https:\/\/duckduckgo\.com\/\?q=how%20tall/);
  assert.equal(toURL(''), 'about:blank');
  assert.equal(hostOf('https://a.b.c/d'), 'a.b.c');
});

// ===========================================================================
// D25 — a background tab needs a real box, or it can never take a seat.
//
// The bug session-restore shipped with: relaunching brought back ONE seat out
// of three. The cause was not in the session code. Every signal the detector
// uses is a layout fact — area, distance from the bottom of the viewport,
// horizontal centrality — and Chromium does not lay out a view parked at 0x0.
// So a backgrounded tab read zero on every signal, fell below the floor, and
// could never seat. Only the tab that happened to be activated came back.
//
// Invisible when you open tabs one at a time, because each is active as it
// opens. Fatal to a restore, which backgrounds them all at once.
//
// The fix: a tab that has not yet produced a verdict gets the SAME box as the
// active tab (so it can be measured), with the active tab raised above it in
// z-order. Once it rules, it is parked at 0x0 like any other background tab.
//
// These tests assert the property that actually matters — every restored tab
// is measurable — rather than the z-order detail, which is a consequence.
// A test that only checked stacking would pass on the broken version.
// ===========================================================================

const { TabManager } = require('../src/main/tabs.js');

/** A window that records the child-view stack the way Electron maintains it:
 *  addChildView on an existing child moves it to the top. */
function fakeWindow() {
  const stack = [];
  return {
    stack,
    contentView: {
      addChildView(v) {
        const i = stack.indexOf(v);
        if (i !== -1) stack.splice(i, 1);
        stack.push(v);
      },
      removeChildView(v) {
        const i = stack.indexOf(v);
        if (i !== -1) stack.splice(i, 1);
      },
    },
  };
}

/** A TabManager whose tabs are inert stand-ins: real layout logic, no Chromium. */
function headlessTabs() {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  // TabManager now starts gated: no page view may mount before this launch
  // signs in (see test/gate.test.js). These D25 tests drive a signed-in
  // launch — the state a restore actually happens in.
  mgr.setSignedIn(true);
  let n = 0;
  mgr.open = function open(url, { background = false } = {}) {
    const view = {
      id: `v${++n}`,
      bounds: null,
      visible: null,
      setBounds(b) {
        this.bounds = b;
      },
      setVisible(v) {
        this.visible = v;
      },
    };
    const tab = {
      id: `t${n}`,
      url,
      title: url,
      // A freshly opened tab has said nothing about itself yet — exactly the
      // state awaitingVerdict() is about.
      seat: { status: 'unknown' },
      view,
      destroy() {},
    };
    this.tabs.push(tab);
    win.contentView.addChildView(view);
    view.setBounds({ x: 0, y: 0, width: 0, height: 0 });
    if (!background || !this.activeId) this.activate(tab.id);
    this.emitChanged();
    return tab;
  };
  return { mgr, win };
}

const BOX = { x: 0, y: 96, width: 1200, height: 600 };
const isZero = (b) => b.width === 0 && b.height === 0;
const measurable = (t) => !isZero(t.view.bounds) && t.view.visible === true;

test('D25 — every tab restored in the background gets a real box, so every one can seat', () => {
  const { mgr } = headlessTabs();
  mgr.setBounds(BOX);
  mgr.restore(['https://a.example/', 'https://b.example/', 'https://c.example/'], {
    activeUrl: 'https://a.example/',
  });

  // THE regression. On the broken version two of these are 0x0 and can never
  // produce a verdict, which is why restore came back with one seat of three.
  for (const t of mgr.tabs) {
    assert.ok(
      measurable(t),
      `${t.url} was parked at ${JSON.stringify(t.view.bounds)} — Chromium will not lay it out, so it can never seat`
    );
    assert.deepEqual(t.view.bounds, BOX, 'a measuring tab gets the same box as the active tab');
  }
});

test('D25 — the tab you were looking at is still the one on top while the others measure', () => {
  const { mgr, win } = headlessTabs();
  mgr.setBounds(BOX);
  mgr.restore(['https://a/', 'https://b/', 'https://c/', 'https://d/', 'https://e/'], { activeUrl: 'https://a/' });

  const active = mgr.byId(mgr.activeId);
  assert.equal(active.url, 'https://a/', 'the saved active tab is the active one');
  assert.equal(
    win.stack[win.stack.length - 1],
    active.view,
    'the active view is raised above the tabs being measured underneath it'
  );
});

test('D25 — a tab that has ruled is parked again; it no longer needs measuring', () => {
  const { mgr } = headlessTabs();
  mgr.setBounds(BOX);
  mgr.restore(['https://a/', 'https://b/', 'https://c/'], { activeUrl: 'https://a/' });

  const b = mgr.tabs.find((t) => t.url === 'https://b/');
  const c = mgr.tabs.find((t) => t.url === 'https://c/');
  assert.ok(measurable(b) && measurable(c), 'both start out measurable');

  // b rules: it is a chat. c refuses. Both are now judged.
  b.seat = { status: 'seated', confidence: 0.9 };
  c.seat = { status: 'refused', reason: 'no-candidates' };
  mgr.layout();

  assert.ok(isZero(b.view.bounds), 'a seated background tab costs nothing to keep');
  assert.ok(isZero(c.view.bounds), 'and neither does a refused one — the verdict is what matters, not the outcome');
  assert.equal(b.view.visible, false);
  assert.equal(c.view.visible, false);

  const active = mgr.byId(mgr.activeId);
  assert.deepEqual(active.view.bounds, BOX, 'the active tab still has the page');
  assert.equal(active.view.visible, true);
});

test('D25 — a tab whose verdict is reset gets its box back', () => {
  // Navigating resets a tab to `unknown` (tabs.js did-navigate). It has to
  // become measurable again or the new page can never seat.
  const { mgr } = headlessTabs();
  mgr.setBounds(BOX);
  mgr.restore(['https://a/', 'https://b/'], { activeUrl: 'https://a/' });

  const b = mgr.tabs.find((t) => t.url === 'https://b/');
  b.seat = { status: 'seated', confidence: 0.9 };
  mgr.layout();
  assert.ok(isZero(b.view.bounds), 'parked once judged');

  b.seat = { status: 'unknown', detail: 'Looking at this page…' };
  mgr.layout();
  assert.ok(measurable(b), 'and measurable again the moment it has something new to judge');
});

test('D25 — measuring never happens when there is no box to measure in', () => {
  // Before the chrome reports its bounds, and while the table view is up,
  // there is no real box. Handing tabs a 0x0 "real" box would be pointless
  // churn, and raising the active view every frame is a visible repaint hitch.
  const { mgr, win } = headlessTabs();
  mgr.setBounds({ x: 0, y: 0, width: 0, height: 0 });
  mgr.restore(['https://a/', 'https://b/', 'https://c/'], { activeUrl: 'https://a/' });
  for (const t of mgr.tabs) assert.ok(isZero(t.view.bounds), 'nothing is measured into a zero-size window');

  mgr.setBounds(BOX);
  mgr.setPageVisible(false); // the table pane is showing; no page is on screen
  const stackBefore = win.stack.slice();
  mgr.layout();
  assert.deepEqual(win.stack, stackBefore, 'no re-parenting churn while no page is visible');
});

test('D25 — restore still puts the right tab in front, and falls back when it is gone', () => {
  const { mgr } = headlessTabs();
  mgr.setBounds(BOX);
  mgr.restore(['https://a/', 'https://b/', 'https://c/'], { activeUrl: 'https://b/' });
  assert.equal(mgr.byId(mgr.activeId).url, 'https://b/');

  const { mgr: m2 } = headlessTabs();
  m2.setBounds(BOX);
  m2.restore(['https://a/', 'https://b/'], { activeUrl: 'https://vanished/' });
  assert.equal(m2.byId(m2.activeId).url, 'https://b/', 'a saved active URL that is gone falls back to the last opened');
});
