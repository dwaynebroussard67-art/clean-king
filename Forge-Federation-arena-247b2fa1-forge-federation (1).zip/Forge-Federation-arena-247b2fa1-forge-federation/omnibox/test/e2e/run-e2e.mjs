/**
 * run-e2e.mjs — launch the real Forge Flight and use it.
 *
 * This drives the shipped application: the actual Electron main process, the
 * actual tab views, the actual seat preload running inside real pages, the
 * actual chrome UI. Nothing is stubbed. Two fixture chat apps are served on
 * two distinct hosts so the one-seat-per-host rule is exercised rather than
 * assumed, then a prompt is typed into the forgeflight and both replies are
 * verified to have come back and landed in the Passport.
 */

import { _electron as electron } from 'playwright-core';
import { createServer } from 'node:http';
import { readFileSync, writeFileSync, existsSync, mkdirSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join, extname } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const fixtures = resolve(root, 'test/fixtures');
const shots = resolve(root, 'test/e2e/shots');

let passed = 0;
let failed = 0;
const failures = [];
const check = (name, cond, detail) => {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
};

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8' };

function serve(port) {
  return new Promise((res) => {
    const s = createServer((req, rep) => {
      const name = decodeURIComponent(req.url.split('?')[0]).replace(/^\//, '') || 'index.html';
      const file = join(fixtures, name);
      if (!file.startsWith(fixtures) || !existsSync(file)) {
        rep.writeHead(404).end('nope');
        return;
      }
      rep.writeHead(200, { 'content-type': MIME[extname(file)] || 'text/plain' });
      rep.end(readFileSync(file));
    });
    s.listen(port, '0.0.0.0', () => res(s));
  });
}

async function openTabAt(page, url) {
  await page.click('#newTab');
  await page.fill('#addr', url);
  await page.press('#addr', 'Enter');
}

/**
 * Every launch begins gated: "Who is flying?" is up until a name is typed
 * and Enter pressed. A name on disk is a memory, not this session — even a
 * remembered name must be confirmed. This is also where the click-through
 * bug lived: a native tab view mounted while the gate was up covered the
 * card and ate every click. The gate must therefore be exercised exactly the
 * way a person hits it.
 */
async function signInThroughGate(page, name = 'e2e-pilot') {
  // The chrome must have finished booting (the first state push rendered the
  // gate) before typing — the Enter handler is attached by chrome.js.
  await page.waitForSelector('#gate:not([hidden])', { timeout: 20000 });
  await page.waitForFunction(() => document.body.classList.contains('gated'), null, { timeout: 10000 });
  await page.fill('#gateName', name);
  await page.press('#gateName', 'Enter');
  await page.waitForFunction(() => document.getElementById('gate').hidden, null, { timeout: 10000 });
}

async function railRows(page) {
  return page.$$eval('#railBody .seat', (nodes) =>
    nodes.map((n) => ({
      name: n.querySelector('.nm')?.textContent || '',
      status: n.querySelector('.st')?.textContent || '',
      detail: n.querySelector('.row2')?.textContent || '',
      cls: n.className,
    }))
  );
}

async function main() {
  mkdirSync(shots, { recursive: true });
  const PORT = 39411;
  const server = await serve(PORT);
  const A = `http://127.0.0.1:${PORT}/contenteditable-chat.html`;
  const B = `http://localhost:${PORT}/textarea-chat.html`;
  const C = `http://127.0.0.1:${PORT}/no-composer.html`; // same host as A: duplicate + not a chat

  console.log('\nForge Flight end-to-end (real Electron, real pages)\n');

  const userDataDir = mkdtempSync(join(tmpdir(), 'forgeflight-e2e-'));
  const app = await electron.launch({
    args: [root, '--no-sandbox', '--disable-gpu'],
    // A throwaway profile: this run must not see anything a previous run left
    // behind, and must not touch a real user's passport.
    env: { ...process.env, FORGEFLIGHT_E2E: '1', FORGEFLIGHT_USER_DATA: userDataDir },
  });
  const page = await app.firstWindow();
  await page.waitForSelector('#railBody', { timeout: 20000 });

  // ------------------------------------------------------------------ boot
  console.log('boot — the gate');
  check('the chrome window came up', (await page.title()) === 'Forge Flight', await page.title());
  check('the sign-in gate is up and asking who is flying', await page.isVisible('#gate'));
  check('no page view exists behind the gate', (await page.$$('#tabs .tab')).length === 0);

  // THE regression: a raw click where the New Tab button sits must do
  // nothing while the gate is up. Before the fix a native page view was
  // mounted over the card and the chrome could not be touched at all.
  {
    const box = await page.locator('#newTab').boundingBox();
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
    await page.waitForTimeout(400);
    check(
      'a click on the chrome behind the gate does nothing',
      (await page.$$('#tabs .tab')).length === 0 && (await page.isVisible('#gate')),
      'the chrome took the click while gated'
    );
  }
  await page.waitForFunction(() => document.activeElement && document.activeElement.id === 'gateName', null, {
    timeout: 10000,
  });
  check('the gate input holds the keyboard', true);
  await page.screenshot({ path: join(shots, '00-gate.png') });

  console.log('signing in');
  await signInThroughGate(page);
  check('signing in with a name drops the gate', !(await page.isVisible('#gate')));
  check('the start page opened once the gate left', (await page.$$('#tabs .tab')).length >= 1);
  await page.click('#viewMemory');
  await page.waitForTimeout(400);
  check(
    'the passport starts empty on a fresh profile',
    (await page.$$eval('#memList .mem', (n) => n.length)) === 0,
    await page.textContent('#memStats')
  );
  await page.click('#viewBrowse');
  check('the dock says there are no seats yet', (await page.textContent('#dockHint')).includes('No seats'));
  await page.screenshot({ path: join(shots, '01-empty.png') });

  // ------------------------------------------------------------- auto-seat
  console.log('opening two chat pages on two different hosts');
  await openTabAt(page, A);
  await page.waitForFunction(() => document.querySelectorAll('#railBody .seat.seated').length >= 1, null, {
    timeout: 20000,
  });
  check('the first chat page seated itself with no configuration', true);

  await openTabAt(page, B);
  await page.waitForFunction(() => document.querySelectorAll('#railBody .seat.seated').length >= 2, null, {
    timeout: 20000,
  });
  const seatCount = await page.textContent('#seatCount');
  check('two seats are at the table', seatCount.trim() === '2', seatCount);

  // ---------------------------------------------------- refusals + one/host
  console.log('opening a page that is not a chat, on a host that is already seated');
  await openTabAt(page, C);
  await page.waitForTimeout(2500);
  const rows = await railRows(page);
  check('the non-chat page did not seat itself', rows.some((r) => /not a chat/.test(r.status)), JSON.stringify(rows));
  check(
    'the label a person reads matches the verdict, not a coarse status',
    rows.every((r) => !/ambiguous/.test(r.status) || /scored within/.test(r.detail || '')),
    JSON.stringify(rows.map((r) => [r.status, (r.detail || '').slice(0, 40)]))
  );
  check('still exactly two seats', (await page.textContent('#seatCount')).trim() === '2');
  await page.screenshot({ path: join(shots, '02-seated.png') });

  // ------------------------------------------------------------- the table
  console.log('asking the table');
  await page.fill('#prompt', 'what is the shape of the table');
  check('send is enabled once there are seats and text', !(await page.isDisabled('#send')));
  await page.press('#prompt', 'Enter');

  await page.waitForSelector('#runs .run', { timeout: 10000 });
  check('the view switched to the table by itself', await page.isVisible('#paneTable'));
  await page.waitForTimeout(700);
  await page.screenshot({ path: join(shots, '03-streaming.png') });

  await page.waitForFunction(
    () => {
      const cols = document.querySelectorAll('#runs .run .colfoot');
      return cols.length >= 2 && [...cols].every((c) => c.textContent.trim().length > 0);
    },
    null,
    { timeout: 45000 }
  );

  const cols = await page.$$eval('#runs .run .col', (nodes) =>
    nodes.map((n) => ({
      name: n.querySelector('.nm')?.textContent || '',
      text: n.querySelector('.colbody')?.textContent || '',
      failed: n.querySelector('.colbody')?.classList.contains('failed'),
      foot: n.querySelector('.colfoot')?.textContent || '',
    }))
  );
  check('both seats answered', cols.length === 2, JSON.stringify(cols.map((c) => c.name)));
  check('neither answer is a refusal', cols.every((c) => !c.failed), JSON.stringify(cols));
  check(
    'both answers echo the prompt back',
    cols.every((c) => /shape of the table/i.test(c.text)),
    cols.map((c) => c.text.slice(0, 60)).join(' | ')
  );
  check(
    'the captured reply is the reply, not an echo of the prompt',
    cols.every((c) => !/^what is the shape of the table/i.test(c.text.trim())),
    cols.map((c) => c.text.slice(0, 50)).join(' | ')
  );
  check(
    'each column reports how it typed',
    cols.every((c) => /native-setter|paste-event|exec-command|before-input|direct/.test(c.foot)),
    cols.map((c) => c.foot).join(' | ')
  );
  await page.screenshot({ path: join(shots, '04-answers.png') });

  // ------------------------------------------------------------- assignments
  console.log('picking who argues which side');
  {
    await page.selectOption('#shape', 'sides');
    await page.waitForTimeout(400);
    const pills = await page.$$eval('#railBody .seat.seated .assign .pill', (n) => n.map((x) => x.textContent));
    check('every seat gets For / Against / Sit out', pills.length === 6, JSON.stringify(pills));
    check('and it defaults to a split rather than making you assign first',
      (await page.$$eval('#railBody .seat.seated .assign .pill.on', (n) => n.map((x) => x.textContent))).join(',') === 'For,Against');

    // Sit the second seat out and confirm the dock says so before sending.
    await page.click('#railBody .seat.seated:nth-of-type(2) .assign .pill:nth-child(3)');
    await page.waitForTimeout(250);
    check('the dock counts who will actually receive it',
      /1 of 2 seat/.test(await page.textContent('#dockHint')), await page.textContent('#dockHint'));

    await page.fill('#prompt', 'is a hotdog a sandwich');
    await page.press('#prompt', 'Enter');
    await page.waitForFunction(
      () => {
        const f = document.querySelectorAll('#runs .run:first-child .colfoot');
        return f.length >= 1 && [...f].every((c) => c.textContent.trim().length > 0);
      },
      null,
      { timeout: 45000 }
    );
    const cols = await page.$$eval('#runs .run:first-child .col', (n) =>
      n.map((x) => ({ role: x.querySelector('.rl').textContent, text: x.querySelector('.colbody').textContent }))
    );
    check('only the seat that was not sitting out was sent to', cols.length === 1, JSON.stringify(cols.map((c) => c.role)));
    check('and it was told which case to argue', /^(for|against)$/.test(cols[0].role), cols[0].role);
    check('the framing reached the page, not just the engine', /case (FOR|AGAINST)/i.test(cols[0].text), cols[0].text.slice(0, 90));

    // Put everyone back in for the rest of the run.
    await page.click('#railBody .seat.seated:nth-of-type(2) .assign .pill:nth-child(2)');
    await page.selectOption('#shape', 'communal');
    await page.waitForTimeout(250);
  }

  // ----------------------------------------------------------------- frames
  console.log('a chat embedded in a same-origin frame');
  {
    await page.click('#viewBrowse');
    // A third loopback host, so this exercises frame piercing rather than
    // tripping the one-seat-per-host rule on a host that is already seated.
    await openTabAt(page, `http://127.0.0.2:${PORT}/iframe-host.html`);
    await page.waitForTimeout(4500);
    const rows = await railRows(page);
    const embedded = rows.find((r) => /Embedded Chat/.test(r.detail || ''));
    check('Forge Flight reaches into the frame and seats it', !!embedded, JSON.stringify(rows));
    check('it is a real seat, not a refusal', !!embedded && /seated/.test(embedded.status), embedded && embedded.status);
    // Same host as the first chat, so the one-seat-per-host rule must hold.
    check('and it becomes the third seat', (await page.textContent('#seatCount')).trim() === '3');

    // The whole cycle through a frame: type into the frame's composer and
    // capture the reply out of the frame's own document.
    await page.fill('#prompt', 'can you hear me through the frame');
    await page.press('#prompt', 'Enter');
    await page.waitForFunction(
      () => {
        const f = document.querySelectorAll('#runs .run:first-child .colfoot');
        return f.length >= 3 && [...f].every((c) => c.textContent.trim().length > 0);
      },
      null,
      { timeout: 45000 }
    );
    const framed = await page.$$eval('#runs .run:first-child .col', (n) =>
      n.map((x) => ({
        name: x.querySelector('.nm').textContent,
        text: x.querySelector('.colbody').textContent,
        failed: x.querySelector('.colbody').classList.contains('failed'),
      }))
    );
    const inFrame = framed.find((c) => /127\.0\.0\.2/.test(c.name));
    check('the embedded seat answered', !!inFrame && !inFrame.failed, JSON.stringify(framed.map((c) => c.name)));
    check(
      'and the reply came out of the frame, not the host page',
      !!inFrame && /hear me through the frame/.test(inFrame.text),
      (inFrame && inFrame.text.slice(0, 90)) || ''
    );
  }

  // ------------------------------------------------------ engine-training log
  // The anchor log is not the passport: it lives in its own append-only file
  // and the whole point of the pipe rule is visible here — after three real
  // runs, it holds anchors, losers and outcomes, and none of the prompts.
  console.log('the engine-training record');
  {
    const anchorsPath = join(userDataDir, 'anchors.jsonl');
    check('the anchor log exists next to the passport', existsSync(anchorsPath), anchorsPath);
    const recs = existsSync(anchorsPath)
      ? readFileSync(anchorsPath, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
      : [];
    const verdicts = recs.filter((r) => r.type === 'verdict');
    const outcomes = recs.filter((r) => r.type === 'outcome');
    check('seated tabs recorded their anchor with losers attached', verdicts.some((r) => r.winner && r.winner.stabilityKey && Array.isArray(r.losers)), JSON.stringify(verdicts.length));
    check('answers were recorded as outcomes with the anchor join key', outcomes.some((r) => r.ok && r.anchorKey), JSON.stringify(outcomes.length));
    check(
      'no prompt or reply text crossed into the training record',
      !/shape of the table|hotdog|hear me through the frame/.test(JSON.stringify(recs)),
      'conversation text found in anchors.jsonl'
    );
  }

  // -------------------------------------------------------------- passport
  console.log('the passport');
  await page.click('#viewMemory');
  await page.waitForTimeout(600);
  const stats = await page.textContent('#memStats');
  check('replies landed in the passport as candidate memories', /claims/.test(stats) && !/^0 claims/.test(stats), stats);
  // One memory per successful reply: two from the first communal run, one from
  // the sides run (the other seat sat out), three from the frame run.
  const mems = await page.$$eval('#memList .mem', (n) => n.length);
  check('one candidate memory per successful reply', mems === 6, String(mems));
  const seatsNamed = await page.$$eval('#memList .mem .f', (n) => n.map((x) => x.textContent));
  check('each memory names the seat that produced it', seatsNamed.every((t) => t.length > 8), JSON.stringify(seatsNamed.slice(0, 2)));
  check(
    'they enter provisional, never supported',
    (await page.$$eval('#memList .mem', (n) => n.map((x) => x.className))).every((c) => /provisional/.test(c))
  );

  await page.fill('#memQuery', 'shape of the table');
  await page.click('#memBoot');
  await page.waitForTimeout(500);
  const boot = await page.textContent('#bootBlock');
  check('a boot block renders', /MEMORY PASSPORT/.test(boot), boot.slice(0, 80));
  check('the boot block always carries the exclusion audit', /--- not shown ---/.test(boot));
  check('the status ceiling is stated in the read shape', /status ceiling is `supported`/.test(boot));
  await page.screenshot({ path: join(shots, '05-passport.png') });

  // --------------------------------------------------------- carry it away
  console.log('exporting and importing the passport');
  {
    const out = join(tmpdir(), `forgeflight-passport-${Date.now()}.json`);
    await app.evaluate(({ dialog }, p) => {
      dialog.showSaveDialog = async () => ({ canceled: false, filePath: p });
      dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [p] });
    }, out);

    await page.click('#memExport');
    await page.waitForTimeout(700);
    check('export reports what it wrote', /Saved \d+ memories/.test(await page.textContent('#memNote')), await page.textContent('#memNote'));
    check('and the file is really there', existsSync(out));

    const bundle = JSON.parse(readFileSync(out, 'utf8'));
    check('the export declares its schema', bundle.schema === 'forgeflight.passport.v1', bundle.schema);
    check('and says out loud that status does not travel', /re-derives them from scratch/.test(bundle.note || ''), bundle.note);

    // The attack: promote everything in the file, then import it.
    for (const c of bundle.claims) {
      c.status = 'supported';
      c.confirmationCount = 99;
      c.promotedAt = new Date().toISOString();
    }
    for (const m of bundle.memories) {
      m.pinned = true;
      m.adjudicatedAt = new Date().toISOString();
    }
    writeFileSync(out, JSON.stringify(bundle));

    const before = await page.$$eval('#memList .mem', (n) => n.length);
    await page.click('#memImport');
    await page.waitForTimeout(1000);
    const note = await page.textContent('#memNote');
    check('import reports what it left behind', /cannot cross a file boundary/.test(note), note);
    check('and names the status it refused to carry', /status/.test(note), note);

    const after = await page.$$eval('#memList .mem', (n) => n.length);
    check('the memories did come across', after > before, `${before} -> ${after}`);
    const classes = await page.$$eval('#memList .mem', (n) => n.map((x) => x.className));
    check('but every one of them is provisional, not supported', classes.every((c) => /provisional/.test(c)), JSON.stringify([...new Set(classes)]));
  }

  // -------------------------------------------------------- refusal detail
  console.log('a refusal explains itself');
  await page.click('#viewBrowse');
  const refusedIdx = (await railRows(page)).findIndex((r) => /not a chat|ambiguous|form|frame|nothing/.test(r.status));
  if (refusedIdx >= 0) {
    await page.click(`#railBody .seat:nth-of-type(${refusedIdx + 1})`);
    await page.waitForSelector('.sheetcard', { timeout: 5000 });
    const sheet = await page.textContent('#sheetBody');
    check('the sheet says why in words a person can act on', sheet.length > 40, sheet.slice(0, 90));
    check('and offers a way to fix it', (await page.$$('.sheetacts .btn')).length >= 2);
    await page.screenshot({ path: join(shots, '06-refusal.png') });
    await page.click('#sheetClose');
  } else {
    check('a refused seat was present to inspect', false, 'no refused row found');
  }

  // ------------------------------------------------------------- resuming
  // The logins were always in the persistent partition; all a restart was
  // missing is the list of places. So: write the session, quit, relaunch on
  // the same profile, and require the table to be back with nothing opened by
  // hand — then empty it and require the Resume button to bring it back.
  console.log('resuming the session');
  {
    const sessionPath = join(userDataDir, 'session.json');
    await page.evaluate(() => window.forgeflight.session.save());
    await page.waitForTimeout(400);
    check('the session was written into the profile', existsSync(sessionPath), sessionPath);

    const raw = existsSync(sessionPath) ? readFileSync(sessionPath, 'utf8') : '';
    const saved = raw ? JSON.parse(raw) : { tabs: [] };
    const urls = saved.tabs.map((t) => t.url);
    check('it saved the places that were open', urls.length >= 3, JSON.stringify(urls));
    check(
      'every saved URL is one the allowlist admits',
      urls.every((u) => /^(https:|http:\/\/(127\.|localhost)|forgeflight:)/.test(u)),
      JSON.stringify(urls)
    );
    check(
      'and the file is a list of places — no credential, no conversation',
      !/cookie|token|password|authorization|hotdog|shape of the table/i.test(raw),
      'a secret or conversation text found in session.json'
    );
    check('who sat on which side was saved by host', saved.assign && Object.keys(saved.assign).length >= 1, JSON.stringify(saved.assign));

    const seatsBefore = (await page.textContent('#seatCount')).trim();
    await app.close();

    // Same profile, new process. Nothing below opens a tab by hand.
    const app2 = await electron.launch({
      args: [root, '--no-sandbox', '--disable-gpu'],
      env: { ...process.env, FORGEFLIGHT_E2E: '1', FORGEFLIGHT_USER_DATA: userDataDir },
    });
    const page2 = await app2.firstWindow();
    await page2.waitForSelector('#railBody', { timeout: 20000 });
    // The relaunch is gated too — a name on disk is a memory, not a session.
    // Signing in is what releases the restore of the saved session.
    await signInThroughGate(page2);
    await page2.waitForFunction(() => document.querySelectorAll('#railBody .seat.seated').length >= 2, null, {
      timeout: 30000,
    });
    check('a relaunch put the seats back at the table with nothing opened by hand', true);
    // A frame-hosted chat takes longer to seat than a top-level one: the outer
    // document loads, then the frame, then the detector reaches into it. Wait
    // for the count to settle rather than reading it the instant the second
    // seat lands.
    await page2
      .waitForFunction(
        (want) => document.querySelectorAll('#railBody .seat.seated').length >= Number(want),
        seatsBefore,
        { timeout: 30000 }
      )
      .catch(() => {});
    const seatsAfter = (await page2.textContent('#seatCount')).trim();
    check('the same number of seats came back', seatsAfter === seatsBefore, `${seatsBefore} -> ${seatsAfter}`);
    check('the resume button is quiet once the session is open', await page2.isDisabled('#resumeBtn'));
    await page2.selectOption('#shape', 'sides');
    await page2.waitForTimeout(400);
    // What must survive is that every host that WAS assigned a side gets that
    // side back — keyed by host, not by position in the rail. A seat that
    // joined after the assignment was made has no saved side and correctly
    // takes the default; requiring the counts to match would fail on that,
    // and would have been passing only because a restored seat was missing.
    const sides = await page2.$$eval('#railBody .seat.seated', (rows) =>
      rows.map((r) => ({
        host: r.dataset.host || '',
        side: (r.querySelector('.assign .pill.on') || {}).textContent || '',
      }))
    );
    const label = (v) => (v === 'A' ? 'For' : v === 'B' ? 'Against' : 'Sit out');
    const savedAssign = saved.assign || {};
    const mismatches = Object.entries(savedAssign).filter(([host, v]) => {
      const row = sides.find((s) => s.host === host);
      return !row || row.side !== label(v);
    });
    check(
      'who argued which side came back as it was assigned',
      Object.keys(savedAssign).length > 0 && mismatches.length === 0,
      JSON.stringify({ restored: sides, saved: savedAssign, mismatches })
    );
    await page2.screenshot({ path: join(shots, '07-resumed.png') });

    // ------------------------------------------------------- the carrier
    console.log('the carrier — mission control, and the human outside the triangle');
    {
      await page2.click('#viewCarrier');
      await page2.waitForTimeout(500);
      check('the carrier pane opens', await page2.isVisible('#paneCarrier'));
      const empty = await page2.textContent('#carList');
      check('an empty queue says so, and says why that is the system working', /residue/.test(empty), empty.slice(0, 80));

      // Land a fact, then ask for a capability whose precondition it breaks.
      await page2.evaluate(async () => {
        // A transfer proposal, released by a named human — that is the only
        // way anything lands.
        const p = await window.forgeflight.federation.propose({
          shelf: 'operational',
          equation: { subject: 'claude.ai', predicate: 'rate_limit', object: '0' },
          witness: 'outcome',
          nodeId: 'node-a',
          reference: 'run:e2e',
          target: 'claude.ai',
          replication: 3,
        });
        await window.forgeflight.federation.release(p.id, 'e2e-human', 'checked');
      });
      await page2.waitForTimeout(300);

      const stats = await page2.evaluate(() => window.forgeflight.federation.stats());
      check('a released transfer landed on the carrier', stats.federation.live === 1, JSON.stringify(stats.federation.byShelf));
      check('and the chain over the carrier is intact', stats.federation.chain.breaks.length === 0);

      const review = await page2.evaluate(() =>
        window.forgeflight.federation.review({
          pilot: 'Pilot 3',
          capability: 'browser.fetch',
          shelf: 'operational',
          preconditions: [{ subject: 'claude.ai', predicate: 'rate_limit', object: '100' }],
        })
      );
      check('a request that breaks a constraint is denied, not granted', review.decision === 'denied-pending-human', review.decision);
      check('THE DENIAL NAMES THE VARIABLE', /rate_limit\(claude\.ai\) fails/.test(review.notice || ''), (review.notice || '').slice(0, 120));
      check('and names the evidence behind it', /witness/.test(review.notice || ''));

      await page2.click('#viewCarrier');
      await page2.waitForTimeout(400);
      const queueText = await page2.textContent('#carList');
      check('the denial is waiting on a human in the queue', /browser\.fetch/.test(queueText), queueText.slice(0, 100));
      check('and the carrier tab carries the count', !(await page2.isHidden('#carrierBadge')));

      // The human answers. This launch signed in at the gate as 'e2e-pilot',
      // and main stamps releases with that name — the name a page passes is
      // ignored, so a page can neither release unsigned nor sign as someone
      // else. (An unsigned release cannot be produced mid-session at all:
      // the gate is what lets the rest of the chrome exist.)
      const forged = await page2.evaluate(async () => {
        const q = await window.forgeflight.federation.queue();
        const open = q.find((i) => i.state === 'open');
        return window.forgeflight.federation.release(open.id, 'not-the-operator', 'checked');
      });
      check('a release is authorised, not vetoed, by a name the page types', forged.ok === true, JSON.stringify(forged || {}).slice(0, 90));

      // The Release button in the queue UI is the same path, driven by hand.
      await page2.click('#carList .mem .f button');
      await page2.waitForTimeout(400);
      const after = await page2.evaluate(() => window.forgeflight.federation.queue());
      const released = after.find((i) => i.state === 'released');
      check(
        'the release names the human who signed in at the gate, not the page',
        !!released && released.actor === 'e2e-pilot',
        JSON.stringify(released || {}).slice(0, 90)
      );

      // The two shelves, and the explainer.
      await page2.click('#carOps');
      await page2.waitForTimeout(300);
      check('the operational shelf shows the fact scoped to its target', /claude\.ai/.test(await page2.textContent('#carList')));
      await page2.click('#carWorld');
      await page2.waitForTimeout(300);
      check('the world shelf explains its own clock', /one contradiction closes/.test(await page2.textContent('#carList')));
      await page2.click('#carExplainToggle');
      await page2.waitForTimeout(200);
      const explain = await page2.textContent('#carExplainBox');
      check('the pane says the human is outside the triangle', /outside/.test(explain));
      check('and why a denial is safe to trust', /named broken constraint/.test(explain));
      await page2.screenshot({ path: join(shots, '08-carrier.png') });
    }

    // Empty the table by hand, then ask for it back.
    for (let guard = 0; guard < 12; guard++) {
      const x = await page2.$('#tabs .tab .x');
      if (!x) break;
      await x.click();
      await page2.waitForTimeout(250);
    }
    await page2.waitForTimeout(900);
    check('the table can be emptied', (await page2.textContent('#seatCount')).trim() === '0', await page2.textContent('#seatCount'));
    check('and emptying it offers the session back rather than forgetting it', !(await page2.isDisabled('#resumeBtn')));
    await page2.click('#resumeBtn');
    await page2.waitForFunction(() => document.querySelectorAll('#railBody .seat.seated').length >= 2, null, {
      timeout: 30000,
    });
    check('the Resume button brought the seats back', true);
    check(
      'and everything from the session is open again, so it goes quiet',
      await page2.isDisabled('#resumeBtn')
    );
    await page2.screenshot({ path: join(shots, '08-resume-button.png') });

    await app2.close();
  }

  server.close();

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) console.log('  - ' + f);
    process.exit(1);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
