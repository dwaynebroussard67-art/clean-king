'use strict';

/**
 * chain.test.js — D17: the event trail is hash-chained and tamper-evident.
 *
 * Append-only used to be a discipline. Now every line carries the hash of
 * the line before it, so editing, deleting, or splicing the log after the
 * fact is detectable by recomputation. What these tests pin down:
 *
 *   - a store that behaves normally verifies clean, on disk and on reopen
 *   - an edited middle line is caught (hash mismatch)
 *   - a deleted middle line is caught (prev mismatch)
 *   - a torn final line is still dropped, and the chain up to it verifies
 *   - legacy logs from before the chain load untouched, and new lines chain
 *   - the store never refuses to load over a break — it reports
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const { PassportStore } = require('../src/passport/store.js');
const { Passport } = require('../src/passport/index.js');

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-chain-'));
}

function goodPassport(dir, n = 3) {
  const p = new Passport(dir);
  for (let i = 0; i < n; i++) {
    p.propose({
      type: 'fact',
      title: `t${i}`,
      content: `proposition number ${i}`,
      confidence: 0.5,
      tags: [],
      metadata: { witness_kind: 'outcome', reference: `r${i}` },
    });
  }
  return p;
}

test('a well-behaved store verifies clean', () => {
  const dir = tmpDir();
  const p = goodPassport(dir, 4);
  const v = p.store.verify();
  assert.equal(v.breaks.length, 0);
  assert.equal(v.chained, v.chained); // chained lines exist
  assert.ok(v.chained >= 4, 'every write chained');
  assert.notEqual(v.head, '0'.repeat(64), 'head advanced past genesis');
});

test('the chain survives close and reopen, and continues', () => {
  const dir = tmpDir();
  goodPassport(dir, 3);
  const again = new Passport(dir);
  const headBefore = again.store.head;
  again.propose({
    type: 'fact',
    title: 'more',
    content: 'a fourth proposition',
    confidence: 0.5,
    tags: [],
    metadata: { witness_kind: 'outcome', reference: 'r9' },
  });
  const v = again.store.verify();
  assert.equal(v.breaks.length, 0);
  assert.notEqual(v.head, headBefore, 'head moved on');
  assert.ok(v.chained >= 12, 'the whole file is one chain'); // 3 proposals x 3 lines, + 1 proposal
});

test('editing a middle line after the fact is detected', () => {
  const dir = tmpDir();
  goodPassport(dir, 5);
  const lines = fs.readFileSync(path.join(dir, 'passport.jsonl'), 'utf8').split('\n').filter(Boolean);
  const target = JSON.parse(lines[2]);
  target.data.content = 'quietly rewritten history';
  lines[2] = JSON.stringify(target);
  fs.writeFileSync(path.join(dir, 'passport.jsonl'), lines.join('\n') + '\n');

  const v = new PassportStore(dir).verify();
  assert.ok(v.breaks.some((b) => b.kind === 'hash-mismatch' && b.line === 3), JSON.stringify(v.breaks));
});

test('deleting a middle line is detected', () => {
  const dir = tmpDir();
  goodPassport(dir, 5);
  const file = path.join(dir, 'passport.jsonl');
  const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
  lines.splice(3, 1); // remove the 4th line entirely
  fs.writeFileSync(file, lines.join('\n') + '\n');

  const v = new PassportStore(dir).verify();
  assert.ok(v.breaks.some((b) => b.kind === 'prev-mismatch'), JSON.stringify(v.breaks));
});

test('a torn final line is dropped and everything before it still verifies', () => {
  const dir = tmpDir();
  goodPassport(dir, 3);
  const file = path.join(dir, 'passport.jsonl');
  fs.appendFileSync(file, '{"op":"event","data":{"kind":"tor');
  const p = new Passport(dir);
  assert.ok(p.store.corrupt >= 1, 'torn line counted as corrupt');
  assert.equal(p.store.chain.breaks.filter((b) => b.kind !== 'unparseable').length, 0);
});

test('legacy logs from before the chain load untouched and chain from genesis', () => {
  const dir = tmpDir();
  const file = path.join(dir, 'passport.jsonl');
  // Hand-write a legacy (pre-D17, unchained) log.
  const legacy = [
    { op: 'claim', data: { id: 'claim_legacy1', signature: 'sig1', proposition: 'old line', scope: 'global', status: 'provisional', confirmationCount: 1, contradictionCount: 0, witnessSignatures: ['w1'], derivedFrom: [] } },
    { op: 'memory', data: { id: 'mem_legacy1', claimId: 'claim_legacy1', type: 'fact', title: 't', content: 'old line', confidence: 0.5, tags: [], metadata: {}, pinned: false, origin: 'local', createdAt: '2026-01-01T00:00:00Z', updatedAt: '2026-01-01T00:00:00Z', retiredAt: null } },
  ];
  fs.writeFileSync(file, legacy.map((r) => JSON.stringify(r)).join('\n') + '\n');

  const p = new Passport(dir);
  assert.equal(p.store.chain.legacy, 2, 'legacy lines counted, not chained');
  assert.equal(p.store.chain.breaks.length, 0);
  assert.ok(p.store.getClaim('claim_legacy1'), 'legacy data still loads');

  // New writes chain from genesis and verify clean.
  p.propose({
    type: 'fact',
    title: 'new',
    content: 'a post-legacy proposition',
    confidence: 0.5,
    tags: [],
    metadata: { witness_kind: 'outcome', reference: 'new' },
  });
  const v = p.store.verify();
  assert.equal(v.breaks.length, 0);
  assert.equal(v.chained, 3, 'claim + memory + created-event lines for the new proposal');
  assert.equal(v.legacy, 2);
});

test('the store reports a break in stats rather than refusing to load', () => {
  const dir = tmpDir();
  goodPassport(dir, 3);
  const file = path.join(dir, 'passport.jsonl');
  const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
  const target = JSON.parse(lines[1]);
  target.data.confidence = 0.99;
  lines[1] = JSON.stringify(target);
  fs.writeFileSync(file, lines.join('\n') + '\n');

  const p = new Passport(dir);
  assert.ok(p.store.stats().chain.breaks >= 1, 'stats carries the break');
  assert.ok(p.store.claims.size >= 3, 'the store still loaded its data');
});

test('an export notes the chain head so a bundle can point at its trail', () => {
  const dir = tmpDir();
  const p = goodPassport(dir, 2);
  const b = p.export();
  assert.equal(b.chain.head, p.store.chain.head);
  assert.equal(typeof b.chain.head, 'string');
  assert.equal(b.chain.head.length, 64);
});
