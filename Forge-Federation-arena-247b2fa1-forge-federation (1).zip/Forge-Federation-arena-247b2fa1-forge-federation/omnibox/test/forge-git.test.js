/**
 * forge-git.test.js — the git adapter and the build/test referee, pinned down.
 *
 * These are the two seams that turn the pure loop into a machine that drives a
 * real repository: GitForgeRepo (tree = commit SHA, dedicated worktree, no
 * native modules) and BuildRunnerReferee (a test run becomes green / red /
 * broken-build / unrunnable). The last test is the money demo: a broken repo,
 * a failing test, a seat that proposes a real diff, the loop goes green, and
 * the human is the only one who can merge.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const { CodeForge } = require('../src/forge/index.js');
const { GitForgeRepo, GitForgeError } = require('../src/forge/git.js');
const { BuildRunnerReferee, shellRunner, parseFailing } = require('../src/forge/referee.js');

let tmpRoot = null;
function tmpdir() {
  if (!tmpRoot) tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-git-'));
  return fs.mkdtempSync(path.join(tmpRoot, 'repo-'));
}

function sh(cwd, args) {
  return execFileSync('git', args, { cwd, encoding: 'utf8' });
}

function initRepo() {
  const dir = tmpdir();
  sh(dir, ['init', '-q', '-b', 'main']);
  sh(dir, ['config', 'user.name', 'Forge Test']);
  sh(dir, ['config', 'user.email', 'forge@test.local']);
  return dir;
}

// ── parseFailing ──────────────────────────────────────────────────────────

test('parseFailing recognises TAP, Jest and Mocha failure lines', () => {
  const out = [
    'ok 1 - subtract works',
    'not ok 2 - add returns the sum',
    'not ok 3 - multiply # SKIP',
    'not ok 4 - divide # TODO',
    '✕ login renders',
    '✗ checkout does not crash',
    'FAIL src/auth.test.js › signup › rejects a blank email',
    '  1) forgot password:',
    '  2) two factor:',
  ].join('\n');
  const names = parseFailing(out);
  assert.deepEqual(names, [
    'add returns the sum',
    'login renders',
    'checkout does not crash',
    'forgot password',
    'two factor',
    'src/auth.test.js',
  ]);
});

test('parseFailing is conservative: unparseable output yields nothing', () => {
  assert.deepEqual(parseFailing('Segmentation fault (core dumped)'), []);
  assert.deepEqual(parseFailing(''), []);
});

test('shellRunner maps a missing command to RUNNER_MISSING', () => {
  const run = shellRunner('definitely-not-a-real-command-xyz');
  let code = null;
  try {
    run('/tmp');
  } catch (e) {
    code = e.code;
  }
  assert.equal(code, 'RUNNER_MISSING');
});

// ── BuildRunnerReferee ────────────────────────────────────────────────────

test('referee: green when exit 0, red with named failures when non-zero', async () => {
  const green = new BuildRunnerReferee({ run: () => ({ code: 0, stdout: 'ok 1 - works\n', stderr: '' }) });
  assert.deepEqual(await green.verdict(), { status: 'green' });

  const red = new BuildRunnerReferee({
    run: () => ({ code: 1, stdout: 'not ok 1 - add returns the sum\n', stderr: '' }),
  });
  assert.deepEqual(await red.verdict(), { status: 'red', failing: ['add returns the sum'] });
});

test('referee: a non-zero exit with no named failure is a broken build', async () => {
  const r = new BuildRunnerReferee({
    run: () => ({ code: 1, stdout: '', stderr: 'SyntaxError: Unexpected token' }),
  });
  const v = await r.verdict();
  assert.equal(v.status, 'red');
  assert.equal(v.brokenBuild, true);
  assert.deepEqual(v.failing, []);
});

test('referee: a missing runner is unrunnable, not a crash', async () => {
  const r = new BuildRunnerReferee({ run: () => {
    const e = new Error('runner not found');
    e.code = 'RUNNER_MISSING';
    throw e;
  } });
  const v = await r.verdict();
  assert.equal(v.status, 'unrunnable');
});

// ── GitForgeRepo ──────────────────────────────────────────────────────────

test('git adapter: worktree + branch, apply a real diff, leave the main repo alone', () => {
  const repo = initRepo();
  const buggy = 'function add(a,b){return a-b;}\n';
  const fixed = 'function add(a,b){return a+b;}\n';
  fs.writeFileSync(path.join(repo, 'app.js'), buggy);
  sh(repo, ['add', '-A']);
  sh(repo, ['commit', '-qm', 'base']);

  const g = new GitForgeRepo({ repoDir: repo, base: 'main' }).setup();
  const trunk = g.trunk();
  assert.ok(/^[0-9a-f]{40}$/.test(trunk));

  // Produce a real diff the way a seat's tooling would.
  fs.writeFileSync(path.join(repo, 'app.js'), fixed);
  const diff = sh(repo, ['diff']);
  fs.writeFileSync(path.join(repo, 'app.js'), buggy); // revert the main repo

  const res = g.apply(trunk, diff);
  assert.equal(res.ok, true);
  assert.equal(res.changed, true);
  assert.notEqual(res.tree, trunk);
  assert.equal(fs.readFileSync(path.join(g.worktreeDir, 'app.js'), 'utf8'), fixed);
  assert.equal(fs.readFileSync(path.join(repo, 'app.js'), 'utf8'), buggy); // untouched
  g.dispose();
});

test('git adapter: a patch that does not apply is refused with a reason', () => {
  const repo = initRepo();
  fs.writeFileSync(path.join(repo, 'app.js'), 'x\n');
  sh(repo, ['add', '-A']);
  sh(repo, ['commit', '-qm', 'base']);
  const g = new GitForgeRepo({ repoDir: repo, base: 'main' }).setup();
  const res = g.apply(g.trunk(), 'this is not a unified diff');
  assert.equal(res.ok, false);
  assert.ok(res.reason);
  g.dispose();
});

test('git adapter: a new-file patch applies and commits', () => {
  const repo = initRepo();
  fs.writeFileSync(path.join(repo, 'a.txt'), 'a\n');
  sh(repo, ['add', '-A']);
  sh(repo, ['commit', '-qm', 'base']);
  const g = new GitForgeRepo({ repoDir: repo, base: 'main' }).setup();
  const patch = [
    'diff --git a/new.txt b/new.txt',
    'new file mode 100644',
    'index 0000000..3b18e51',
    '--- /dev/null',
    '+++ b/new.txt',
    '@@ -0,0 +1 @@',
    '+hello',
    '',
  ].join('\n');
  const res = g.apply(g.trunk(), patch);
  assert.equal(res.ok, true);
  assert.equal(res.changed, true);
  assert.equal(fs.readFileSync(path.join(g.worktreeDir, 'new.txt'), 'utf8'), 'hello\n');
  g.dispose();
});

test('git adapter: the same branch refuses a second setup', () => {
  const repo = initRepo();
  fs.writeFileSync(path.join(repo, 'a.txt'), 'a\n');
  sh(repo, ['add', '-A']);
  sh(repo, ['commit', '-qm', 'base']);
  const g = new GitForgeRepo({ repoDir: repo, base: 'main' }).setup();
  assert.throws(() => new GitForgeRepo({ repoDir: repo, base: 'main', branch: g.branch }).setup(), GitForgeError);
  g.dispose();
});

// ── The money demo: loop → git → referee, end to end ─────────────────────

test('end to end: broken repo, failing test, a seat proposes a real fix, green verdict, human releases', async () => {
  const repo = initRepo();
  const buggyApp = 'function add(a,b){return a-b;}\nmodule.exports = add;\n';
  const fixedApp = 'function add(a,b){return a+b;}\nmodule.exports = add;\n';
  fs.writeFileSync(path.join(repo, 'app.js'), buggyApp);
  fs.writeFileSync(
    path.join(repo, 'test.sh'),
    "#!/bin/sh\nnode -e \"const add=require('./app.js'); if(add(2,3)!==5){console.log('not ok 1 - add returns the sum');process.exit(1)} console.log('ok 1 - add returns the sum')\"\n",
  );
  sh(repo, ['add', '-A']);
  sh(repo, ['commit', '-qm', 'base']);

  const g = new GitForgeRepo({ repoDir: repo, base: 'main' }).setup();

  // The seat's proposal: the real fix diff (a real seat produces this with its tools).
  fs.writeFileSync(path.join(repo, 'app.js'), fixedApp);
  const fixDiff = sh(repo, ['diff']);
  fs.writeFileSync(path.join(repo, 'app.js'), buggyApp); // revert the main repo

  const events = [];
  const spec = {
    goal: 'make add(2, 3) return 5',
    trunk: g.trunk(),
    seats: [
      {
        id: 'claude',
        label: 'claude',
        propose: async () => ({
          kind: 'proposal',
          patch: fixDiff,
          summary: 'change the minus to a plus',
          toolSequence: ['forge.run_tests'],
        }),
      },
    ],
    referee: {
      async verdict(sha) {
        g.checkout(sha);
        const build = new BuildRunnerReferee({ run: shellRunner('sh', ['test.sh']), dir: g.worktreeDir });
        return build.verdict();
      },
    },
    apply: (tree, patch) => g.apply(tree, patch),
    proposalBranch: () => g.branch,
    onEvent: (e) => events.push(e),
  };

  try {
    const forge = new CodeForge(spec);
    const r = await forge.run();

    assert.equal(r.stopReason, 'goal_reached');
    assert.ok(r.proposal);
    assert.equal(r.proposal.status, 'staged');
    assert.equal(r.proposal.branch, g.branch);
    assert.equal(fs.readFileSync(path.join(g.worktreeDir, 'app.js'), 'utf8'), fixedApp);
    // Nothing is released yet: the base still has the bug.
    assert.equal(fs.readFileSync(path.join(repo, 'app.js'), 'utf8'), buggyApp);
    assert.ok(events.some((e) => e.type === 'goal:reached'));

    // The human, and only the human, releases.
    const rel = g.releaseToBase(g.branch, 'accept the fix');
    assert.equal(rel.ok, true);
    assert.equal(fs.readFileSync(path.join(repo, 'app.js'), 'utf8'), fixedApp);
  } finally {
    g.dispose();
  }
});
