/**
 * history.test.js — the address bar's memory: only restorable places, capped,
 * never a credential, and suggestions that match "the middle" not just the start.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { RecentPages, MAX_ENTRIES } = require('../src/main/history.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'forge-hist-'));

test('only restorable URLs are ever recorded', () => {
  const h = new RecentPages(tmp());
  h.add('https://claude.ai/', 'Claude');
  h.add('http://localhost:4173/', 'Pocket');
  h.add('file:///etc/passwd', 'bad');
  h.add('javascript:alert(1)', 'worse');
  h.add('data:text/html,hi', 'payload');
  h.add('https://example.com/login?token=secret', 'token in query is fine to store as a URL');
  const urls = h.recent(10).map((e) => e.url);
  assert.ok(urls.includes('https://claude.ai/'));
  assert.ok(urls.includes('http://localhost:4173/'));
  assert.ok(!urls.some((u) => u.startsWith('file:')));
  assert.ok(!urls.some((u) => u.startsWith('javascript:')));
  assert.ok(!urls.some((u) => u.startsWith('data:')));
});

test('repeats move to the top instead of duplicating', () => {
  const h = new RecentPages(tmp());
  h.add('https://a.example/', 'A');
  h.add('https://b.example/', 'B');
  h.add('https://a.example/', 'A');
  const list = h.recent(5);
  assert.equal(list.length, 2);
  assert.equal(list[0].url, 'https://a.example/');
});

test('suggestions match the middle of a url or the title, like the big browsers', () => {
  const h = new RecentPages(tmp());
  h.add('https://chatgpt.com/c/abc123', 'Build a rocket');
  h.add('https://arena.ai/chat', 'Talk to the table');
  const mid = h.suggest('rocket');
  assert.equal(mid.length, 1);
  assert.equal(mid[0].url, 'https://chatgpt.com/c/abc123');
  const host = h.suggest('arena');
  assert.equal(host.length, 1);
  assert.equal(host[0].url, 'https://arena.ai/chat');
  assert.equal(h.suggest('zzz-nothing').length, 0);
  assert.equal(h.suggest('').length, 0);
});

test('the file is a list of places and nothing more', () => {
  const dir = tmp();
  const h = new RecentPages(dir);
  h.add('https://claude.ai/', 'Claude');
  const raw = fs.readFileSync(path.join(dir, 'recent.json'), 'utf8');
  for (const word of ['cookie', 'token', 'password', 'prompt', 'reply', 'secret']) {
    assert.ok(!raw.toLowerCase().includes(word), `no ${word} in history`);
  }
});

test('a corrupt file is an empty list, not a crash', () => {
  const dir = tmp();
  fs.writeFileSync(path.join(dir, 'recent.json'), '{not-json', 'utf8');
  const h = new RecentPages(dir);
  assert.deepEqual(h.recent(5), []);
});

test('the cap holds and old entries fall off', () => {
  const h = new RecentPages(tmp(), { max: 5 });
  for (let i = 0; i < 10; i++) h.add(`https://site${i}.example/`, `Site ${i}`);
  assert.equal(h.recent(20).length, 5);
  assert.equal(MAX_ENTRIES, 200);
});

test('forgeflight pages are allowed in history', () => {
  const h = new RecentPages(tmp());
  h.add('forgeflight://local', 'Local model');
  assert.equal(h.recent(1)[0].url, 'forgeflight://local');
});
