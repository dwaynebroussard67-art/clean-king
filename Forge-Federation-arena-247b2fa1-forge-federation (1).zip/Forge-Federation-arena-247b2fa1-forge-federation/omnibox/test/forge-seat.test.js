/**
 * forge-seat.test.js — the seat adapter, pinned down.
 *
 * The claim under test: a seated AI (a chat tab) becomes a forge seat. The
 * forge's context becomes a prompt the AI can act on; the AI's reply — a diff
 * plus a summary, an explicit PASS, or prose with no diff — becomes a proposal
 * or a named refusal. The last test runs the whole chain: a real repo, a real
 * test runner, and a seat whose `send` is stubbed to return a real diff.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const {
  CodeForge,
  buildProposalPrompt,
  parseProposalReply,
  forgeSeat,
  dispatchSend,
  looksLikeDiff,
  extractSummary,
  GitForgeRepo,
  BuildRunnerReferee,
  shellRunner,
} = require('../src/forge/index.js');

// ── The prompt ────────────────────────────────────────────────────────────

test('the prompt carries the goal, the failures, and the prior hand', () => {
  const p = buildProposalPrompt(
    {
      goal: 'make add(2,3) return 5',
      failures: [{ reason: 'tests still failing: add returns the sum' }],
      priorSeat: { id: 'claude', summary: 'changed the minus to a plus' },
    },
    {},
  );
  assert.match(p, /TASK/);
  assert.match(p, /make add\(2,3\) return 5/);
  assert.match(p, /WHAT HAS BEEN TRIED AND DID NOT WORK/);
  assert.match(p, /tests still failing: add returns the sum/);
  assert.match(p, /WHAT THE PREVIOUS SEAT CHANGED/);
  assert.match(p, /changed the minus to a plus/);
  assert.match(p, /REPLY FORMAT/);
  assert.match(p, /PASS: <reason>/);
});

test('a first hand is told it is the first hand, with no prior or replacement section', () => {
  const p = buildProposalPrompt({ goal: 'g', failures: [], knownGoodSequences: [] }, {});
  assert.match(p, /nothing yet — you are the first hand on this tree\./);
  assert.doesNotMatch(p, /You replaced/);
  assert.doesNotMatch(p, /PATTERNS THAT HAVE WORKED/);
});

test('a replacement seat is told whom it replaced and when', () => {
  const p = buildProposalPrompt({ goal: 'g', failures: [], replacedSeat: 'gemini', joinedAt: 3 }, {});
  assert.match(p, /You replaced "gemini" in this relay at round 3\./);
});

test('the prompt folds in gathered context: failing output and relevant files', () => {
  const p = buildProposalPrompt(
    { goal: 'g', failures: [] },
    { failingTests: 'not ok 1 - add returns the sum', files: [{ path: 'app.js', content: 'function add(a,b){return a-b;}' }] },
  );
  assert.match(p, /CURRENT TEST OUTPUT/);
  assert.match(p, /not ok 1 - add returns the sum/);
  assert.match(p, /RELEVANT FILES/);
  assert.match(p, /--- app\.js ---/);
  assert.match(p, /return a-b/);
});

// ── The parser ────────────────────────────────────────────────────────────

test('a fenced diff with a Summary line is a proposal', () => {
  const reply = [
    'Here is the fix.',
    '',
    '```diff',
    'diff --git a/app.js b/app.js',
    '--- a/app.js',
    '+++ b/app.js',
    '@@ -1,1 +1,1 @@',
    '-function add(a,b){return a-b;}',
    '+function add(a,b){return a+b;}',
    '```',
    '',
    'Summary: change the minus to a plus',
  ].join('\n');
  const r = parseProposalReply(reply);
  assert.equal(r.kind, 'proposal');
  assert.match(r.patch, /^diff --git /);
  assert.ok(r.patch.endsWith('\n'), 'a diff must end with a newline or git apply rejects it');
  assert.equal(r.summary, 'change the minus to a plus');
  assert.deepEqual(r.toolSequence, []);
});

test('PASS becomes a named pass, with and without a reason', () => {
  assert.equal(parseProposalReply('PASS: out of context').kind, 'pass');
  assert.equal(parseProposalReply('PASS: out of context').reason, 'out of context');
  assert.equal(parseProposalReply('PASS').kind, 'pass');
  assert.equal(parseProposalReply('PASS').reason, 'the seat declined without a reason');
});

test('an empty reply is bad_shape', () => {
  const r = parseProposalReply('   ');
  assert.equal(r.kind, 'bad_shape');
});

test('prose with no diff is bad_shape, never guessed into a patch', () => {
  const r = parseProposalReply('I think the bug is in the add function. You should look at the subtraction.');
  assert.equal(r.kind, 'bad_shape');
  assert.match(r.detail, /no unified diff/);
});

test('a raw, unfenced diff is still a proposal', () => {
  const reply = [
    'diff --git a/app.js b/app.js',
    '--- a/app.js',
    '+++ b/app.js',
    '@@ -1,1 +1,1 @@',
    '-function add(a,b){return a-b;}',
    '+function add(a,b){return a+b;}',
    'Summary: fix the sign',
  ].join('\n');
  const r = parseProposalReply(reply);
  assert.equal(r.kind, 'proposal');
  assert.match(r.patch, /^diff --git /);
  assert.equal(r.summary, 'fix the sign');
});

test('a diff larger than the cap is refused by name, not truncated', () => {
  const big = ['```diff', 'diff --git a/x b/x', '--- a/x', '+++ b/x', '@@ -0,0 +1,100000 @@'];
  for (let i = 0; i < 100000; i++) big.push(`+line ${i}`);
  big.push('```');
  const r = parseProposalReply(big.join('\n'), { maxPatchChars: 1000 });
  assert.equal(r.kind, 'bad_shape');
  assert.match(r.detail, /reply_too_large/);
});

test('looksLikeDiff accepts real diffs and refuses prose', () => {
  assert.equal(looksLikeDiff('diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -1 +1 @@\n-x\n+y'), true);
  assert.equal(looksLikeDiff('--- a/x\n+++ b/x\n@@ -1 +1 @@\n-x\n+y'), true);
  assert.equal(looksLikeDiff('here is some prose\nabout the code\n'), false);
});

test('extractSummary falls back to the first non-diff line', () => {
  assert.equal(extractSummary('Fixed the off-by-one.\n\ndiff --git a/x b/x\n--- a/x\n+++ b/x'), 'Fixed the off-by-one.');
});

// ── The seat ──────────────────────────────────────────────────────────────

test('forgeSeat maps send results: ok→proposal, not-ok→pass, throw→pass', async () => {
  const reply = ['```diff', 'diff --git a/x b/x', '--- a/x', '+++ b/x', '@@ -1 +1 @@', '-x', '+y', '```', '', 'Summary: fix it'].join('\n');

  const okSeat = forgeSeat({ id: 't1', name: 'claude', send: async () => ({ ok: true, text: reply }) });
  const okReply = await okSeat.propose({ goal: 'g', failures: [] });
  assert.equal(okReply.kind, 'proposal');

  const downSeat = forgeSeat({ id: 't2', send: async () => ({ ok: false, reason: 'no-answer', detail: 'gone' }) });
  const downReply = await downSeat.propose({ goal: 'g', failures: [] });
  assert.equal(downReply.kind, 'pass');
  assert.equal(downReply.reason, 'no-answer');

  const throwSeat = forgeSeat({ id: 't3', send: async () => { throw new Error('boom'); } });
  const throwReply = await throwSeat.propose({ goal: 'g', failures: [] });
  assert.equal(throwReply.kind, 'pass');
  assert.equal(throwReply.reason, 'seat_error');
});

test('forgeSeat passes the built prompt through send', async () => {
  let seen = null;
  const seat = forgeSeat({
    id: 't1',
    send: async (prompt) => {
      seen = prompt;
      return { ok: false, reason: 'no-answer' };
    },
  });
  await seat.propose({ goal: 'the goal', failures: [] });
  assert.match(seen, /the goal/);
  assert.match(seen, /REPLY FORMAT/);
});

test('a seat refuses to construct without an id or a send function', () => {
  assert.throws(() => forgeSeat({ send: async () => ({}) }), /id is required/);
  assert.throws(() => forgeSeat({ id: 't1' }), /send function is required/);
});

test('dispatchSend curries a dispatch to one seat', async () => {
  const calls = [];
  const dispatch = (id, text, opts) => {
    calls.push({ id, text, opts });
    return Promise.resolve({ ok: true, text: 'x' });
  };
  const send = dispatchSend(dispatch, 'tab-7', { role: 'forge' });
  await send('hello');
  assert.equal(calls.length, 1);
  assert.equal(calls[0].id, 'tab-7');
  assert.equal(calls[0].text, 'hello');
  assert.equal(calls[0].opts.role, 'forge');
});

// ── The whole chain: seat → forge → git → referee ────────────────────────

test('integration: a seat reply (a real diff) drives the forge to green, and the human releases', async () => {
  // A real repo with a failing test.
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-seat-'));
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 'Forge Test'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 'forge@test.local'], { cwd: dir });

  const buggy = 'function add(a,b){return a-b;}\nmodule.exports = add;\n';
  const fixed = 'function add(a,b){return a+b;}\nmodule.exports = add;\n';
  fs.writeFileSync(path.join(dir, 'app.js'), buggy);
  fs.writeFileSync(
    path.join(dir, 'test.sh'),
    "#!/bin/sh\nnode -e \"const add=require('./app.js'); if(add(2,3)!==5){console.log('not ok 1 - add returns the sum');process.exit(1)} console.log('ok 1 - add returns the sum')\"\n",
  );
  execFileSync('git', ['add', '-A'], { cwd: dir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir });

  const g = new GitForgeRepo({ repoDir: dir, base: 'main' }).setup();

  // The seat's "AI reply": a canned diff (a real model produces this from the
  // prompt). The send stub first confirms the prompt carried the goal.
  const reply = [
    '```diff',
    'diff --git a/app.js b/app.js',
    '--- a/app.js',
    '+++ b/app.js',
    '@@ -1,2 +1,2 @@',
    '-function add(a,b){return a-b;}',
    '+function add(a,b){return a+b;}',
    ' module.exports = add;',
    '```',
    '',
    'Summary: change the minus to a plus',
  ].join('\n');

  const seenPrompts = [];
  const seat = forgeSeat({
    id: 'tab-claude',
    name: 'claude',
    send: async (prompt) => {
      seenPrompts.push(prompt);
      return { ok: true, text: reply };
    },
    gatherContext: async () => ({ files: [{ path: 'app.js', content: buggy }] }),
  });

  const events = [];
  const spec = {
    goal: 'make add(2, 3) return 5',
    trunk: g.trunk(),
    seats: [seat],
    referee: {
      async verdict(sha) {
        g.checkout(sha);
        const build = new BuildRunnerReferee({ run: shellRunner('sh', ['test.sh']), dir: g.worktreeDir });
        return build.verdict();
      },
    },
    apply: (tree, patch) => g.apply(tree, patch),
    proposalBranch: () => g.branch,
    onEvent: (e) => events.push(e),
  };

  try {
    const forge = new CodeForge(spec);
    const r = await forge.run();

    assert.equal(r.stopReason, 'goal_reached');
    assert.ok(r.proposal);
    assert.equal(r.proposal.status, 'staged');
    assert.equal(r.proposal.seatId, 'tab-claude');
    assert.match(r.proposal.summary, /minus to a plus/);
    // The seat was shown a prompt carrying the task.
    assert.match(seenPrompts[0], /make add\(2, 3\) return 5/);

    // The base is still buggy until the human releases.
    assert.equal(fs.readFileSync(path.join(dir, 'app.js'), 'utf8'), buggy);
    g.releaseToBase(g.branch, 'accept the fix');
    assert.equal(fs.readFileSync(path.join(dir, 'app.js'), 'utf8'), fixed);
  } finally {
    g.dispose();
  }
});
