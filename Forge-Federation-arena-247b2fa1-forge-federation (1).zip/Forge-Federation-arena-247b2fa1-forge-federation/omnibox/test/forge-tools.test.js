/**
 * forge-tools.test.js — the capability gate, the bounded toolbox, and the tool
 * pilot, pinned down.
 *
 * The claim under test: a forge seat can fly tools — read, write, run tests —
 * through a risk gate that denies what it was not granted and asks the operator
 * for anything above the auto-approve ceiling; and every filesystem tool is
 * bound to the worktree, so a code pilot is not a root shell. The last test
 * runs the whole chain with a REAL repo: the pilot writes the fix and runs the
 * tests itself, the loop applies and re-verifies, and the human releases.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const {
  CodeForge,
  RISK_RANK,
  authorize,
  DEFAULT_FORGE_AUTHORITY,
  CapabilityGate,
  safeRelPath,
  ForgeToolbox,
  parseToolReply,
  toolPilotSeat,
  GitForgeRepo,
  BuildRunnerReferee,
  shellRunner,
} = require('../src/forge/index.js');

function tmpdir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'forge-tools-'));
}

// ── Risk and authorization ────────────────────────────────────────────────

test('the risk ranks are ordered read < transform < create < update < delete < external_side_effect', () => {
  const r = RISK_RANK;
  assert.ok(r.read < r.transform);
  assert.ok(r.transform < r.create);
  assert.ok(r.create < r.update);
  assert.ok(r.update < r.delete);
  assert.ok(r.delete < r.external_side_effect);
});

test('authorize: within the ceiling is allowed, above it requires approval, ungranted is denied', () => {
  const authority = { allowedCapabilityIds: ['forge.read_file', 'forge.run_tests'], autoApproveRiskAtMost: 'update' };
  assert.deepEqual(authorize('forge.read_file', 'read', authority), { decision: 'allow', reason: 'within_authority' });
  assert.deepEqual(authorize('forge.run_tests', 'external_side_effect', authority), { decision: 'require_approval', reason: 'risk_exceeds_auto_approve' });
  assert.deepEqual(authorize('forge.write_file', 'update', authority), { decision: 'deny', reason: 'capability_not_granted' });
});

test('the default forge authority auto-approves up to update and gates run_tests', () => {
  const g = new CapabilityGate();
  assert.equal(g.authorize('forge.read_file', 'read').decision, 'allow');
  assert.equal(g.authorize('forge.write_file', 'update').decision, 'allow');
  assert.equal(g.authorize('forge.run_tests', 'external_side_effect').decision, 'require_approval');
});

// ── Path containment ──────────────────────────────────────────────────────

test('safeRelPath: a normal relative path resolves inside the worktree', () => {
  const s = safeRelPath('/work/app', 'src/lib.js');
  assert.equal(s.ok, true);
  assert.equal(s.resolved, path.resolve('/work/app/src/lib.js'));
});

test('safeRelPath refuses absolute paths, traversal, and escapes', () => {
  assert.equal(safeRelPath('/work/app', '/etc/passwd').reason, 'absolute_path_refused');
  assert.equal(safeRelPath('/work/app', '../../etc/passwd').reason, 'traversal_refused');
  assert.equal(safeRelPath('/work/app', '../other').reason, 'traversal_refused');
  assert.equal(safeRelPath('/work/app', '').reason, 'path_required');
});

// ── The toolbox ───────────────────────────────────────────────────────────

test('the toolbox reads, writes, and refuses to escape the worktree', async () => {
  const dir = tmpdir();
  const tb = new ForgeToolbox({ worktreeDir: dir, runTests: () => ({ code: 0, stdout: 'ok 1 - works\n', stderr: '' }) });

  const w = await tb.execute('forge.write_file', { path: 'src/a.js', content: 'const a = 1;\n' });
  assert.equal(w.ok, true);
  assert.equal(fs.readFileSync(path.join(dir, 'src/a.js'), 'utf8'), 'const a = 1;\n');

  const r = await tb.execute('forge.read_file', { path: 'src/a.js' });
  assert.equal(r.ok, true);
  assert.equal(r.result.content, 'const a = 1;\n');

  const t = await tb.execute('forge.run_tests', {});
  assert.equal(t.ok, true);
  assert.equal(t.result.code, 0);

  // The boundary: an escape is refused, and the file outside is untouched.
  const escape = await tb.execute('forge.read_file', { path: '../../etc/passwd' });
  assert.equal(escape.ok, false);
  assert.equal(escape.reason, 'traversal_refused');
});

test('the toolbox refuses a missing file, a missing runner, and an unknown tool', async () => {
  const dir = tmpdir();
  const tb = new ForgeToolbox({ worktreeDir: dir }); // no runTests
  assert.equal((await tb.execute('forge.read_file', { path: 'nope.js' })).reason, 'file_not_found');
  assert.equal((await tb.execute('forge.run_tests', {})).reason, 'no_test_runner');
  assert.equal((await tb.execute('forge.not_a_tool', {})).reason, 'unknown_tool');
});

test('git_diff captures a change including a new file', async () => {
  const dir = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 't'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir });
  fs.writeFileSync(path.join(dir, 'a.txt'), 'a\n');
  execFileSync('git', ['add', '-A'], { cwd: dir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir });

  const tb = new ForgeToolbox({ worktreeDir: dir });
  await tb.execute('forge.write_file', { path: 'b.txt', content: 'b\n' });
  const d = await tb.execute('forge.git_diff', {});
  assert.equal(d.ok, true);
  assert.match(d.result.diff, /b\.txt/); // the new file appears in the diff
  assert.ok(d.result.diff.endsWith('\n'));
});

// ── The tool reply parser ─────────────────────────────────────────────────

test('parseToolReply extracts strict JSON with a tools array, tolerating braces in strings', () => {
  const reply = 'Sure. ```json\n{"summary":"fix","tools":[{"tool":"forge.write_file","args":{"path":"a.js","content":"if (x) { y(); }"}}]}\n```';
  const j = parseToolReply(reply);
  assert.ok(j);
  assert.equal(j.tools[0].tool, 'forge.write_file');
  assert.equal(j.tools[0].args.content, 'if (x) { y(); }');
});

test('parseToolReply returns null for a diff reply or empty tools', () => {
  assert.equal(parseToolReply('diff --git a/x b/x\n--- a/x\n+++ b/x'), null);
  assert.equal(parseToolReply('{"summary":"x","tools":[]}'), null);
  assert.equal(parseToolReply('no json here'), null);
});

// ── The tool pilot ────────────────────────────────────────────────────────

function toolReply(tools, summary) {
  return { ok: true, text: JSON.stringify({ summary: summary || 'fix', tools }) };
}

test('a tool reply flies through the gate and becomes a proposal with a toolSequence', async () => {
  const dir = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 't'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 't@t'], { cwd: dir });
  fs.writeFileSync(path.join(dir, 'a.txt'), 'a\n');
  execFileSync('git', ['add', '-A'], { cwd: dir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir });

  const toolbox = new ForgeToolbox({ worktreeDir: dir, runTests: () => ({ code: 0, stdout: '', stderr: '' }) });
  const approvals = [];
  const seat = toolPilotSeat({
    id: 'p1',
    name: 'pilot',
    send: async () => toolReply([
      { tool: 'forge.write_file', args: { path: 'a.txt', content: 'changed\n' } },
      { tool: 'forge.run_tests', args: {} },
    ], 'changed a'),
    toolbox,
    approve: async (c) => { approvals.push(c.toolId); return true; },
  });

  const reply = await seat.propose({ goal: 'g', tree: 'HEAD', failures: [] });
  assert.equal(reply.kind, 'proposal');
  assert.match(reply.patch, /a\.txt/);
  assert.deepEqual(reply.toolSequence, ['forge.write_file', 'forge.run_tests']);
  assert.deepEqual(approvals, ['forge.run_tests']); // only run_tests asked the operator
});

test('a run_tests without approval is refused by name, before it executes', async () => {
  const dir = tmpdir();
  const executed = [];
  const toolbox = new ForgeToolbox({ worktreeDir: dir, runTests: () => { executed.push(1); return { code: 0, stdout: '', stderr: '' }; } });
  const seat = toolPilotSeat({
    id: 'p1',
    send: async () => toolReply([{ tool: 'forge.run_tests', args: {} }]),
    toolbox,
    approve: async () => false, // the operator said no
  });
  const reply = await seat.propose({ goal: 'g', tree: 'HEAD', failures: [] });
  assert.equal(reply.kind, 'pass');
  assert.equal(reply.reason, 'approval_required');
  assert.equal(executed.length, 0); // never ran
});

test('an ungranted tool is denied, never executed', async () => {
  const dir = tmpdir();
  const gate = new CapabilityGate({ allowedCapabilityIds: ['forge.read_file'], autoApproveRiskAtMost: 'read' });
  const toolbox = new ForgeToolbox({ worktreeDir: dir });
  const seat = toolPilotSeat({
    id: 'p1',
    send: async () => toolReply([{ tool: 'forge.write_file', args: { path: 'x.txt', content: 'x' } }]),
    toolbox,
    gate,
  });
  const reply = await seat.propose({ goal: 'g', tree: 'HEAD', failures: [] });
  assert.equal(reply.kind, 'pass');
  assert.equal(reply.reason, 'denied');
  assert.equal(fs.existsSync(path.join(dir, 'x.txt')), false);
});

test('a path escape inside a tool reply is refused by name', async () => {
  const dir = tmpdir();
  const toolbox = new ForgeToolbox({ worktreeDir: dir });
  const seat = toolPilotSeat({
    id: 'p1',
    send: async () => toolReply([{ tool: 'forge.write_file', args: { path: '../../escape.txt', content: 'x' } }]),
    toolbox,
  });
  const reply = await seat.propose({ goal: 'g', tree: 'HEAD', failures: [] });
  assert.equal(reply.kind, 'pass');
  assert.equal(reply.reason, 'traversal_refused');
});

test('a diff reply (no tools) falls back to a plain proposal', async () => {
  const dir = tmpdir();
  const toolbox = new ForgeToolbox({ worktreeDir: dir });
  const seat = toolPilotSeat({
    id: 'p1',
    send: async () => ({ ok: true, text: ['```diff', 'diff --git a/x b/x', '--- a/x', '+++ b/x', '@@ -1 +1 @@', '-x', '+y', '```', 'Summary: fix'].join('\n') }),
    toolbox,
  });
  const reply = await seat.propose({ goal: 'g', tree: 'HEAD', failures: [] });
  assert.equal(reply.kind, 'proposal');
  assert.match(reply.patch, /^diff --git /);
  assert.deepEqual(reply.toolSequence, []);
});

test('a tool pilot refuses to construct without an id, send, or toolbox', () => {
  const dir = tmpdir();
  assert.throws(() => toolPilotSeat({ send: async () => ({}), toolbox: new ForgeToolbox({ worktreeDir: dir }) }), /id is required/);
  assert.throws(() => toolPilotSeat({ id: 'p', toolbox: new ForgeToolbox({ worktreeDir: dir }) }), /send function/);
  assert.throws(() => toolPilotSeat({ id: 'p', send: async () => ({}) }), /ForgeToolbox is required/);
});

// ── The whole chain: a tool-flying pilot drives the forge to green ───────

test('integration: the pilot writes the fix and runs the tests; the loop re-verifies; the human releases', async () => {
  const dir = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 'Forge Test'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 'forge@test.local'], { cwd: dir });

  const buggy = 'function add(a,b){return a-b;}\nmodule.exports = add;\n';
  const fixed = 'function add(a,b){return a+b;}\nmodule.exports = add;\n';
  fs.writeFileSync(path.join(dir, 'app.js'), buggy);
  fs.writeFileSync(
    path.join(dir, 'test.sh'),
    "#!/bin/sh\nnode -e \"const add=require('./app.js'); if(add(2,3)!==5){console.log('not ok 1 - add returns the sum');process.exit(1)} console.log('ok 1 - add returns the sum')\"\n",
  );
  execFileSync('git', ['add', '-A'], { cwd: dir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir });

  const g = new GitForgeRepo({ repoDir: dir, base: 'main' }).setup();

  const toolbox = new ForgeToolbox({
    worktreeDir: g.worktreeDir,
    runTests: () => shellRunner('sh', ['test.sh'])(g.worktreeDir),
  });

  const seenPrompts = [];
  const pilot = toolPilotSeat({
    id: 'tab-pilot',
    name: 'pilot',
    send: async (prompt) => {
      seenPrompts.push(prompt);
      return toolReply([
        { tool: 'forge.write_file', args: { path: 'app.js', content: fixed } },
        { tool: 'forge.run_tests', args: {} },
      ], 'change the minus to a plus');
    },
    toolbox,
    approve: async ({ toolId }) => toolId === 'forge.run_tests',
    checkout: (sha) => g.checkout(sha),
    gatherContext: async () => ({ files: [{ path: 'app.js', content: buggy }] }),
  });

  const events = [];
  const spec = {
    goal: 'make add(2, 3) return 5',
    trunk: g.trunk(),
    seats: [pilot],
    referee: {
      async verdict(sha) {
        g.checkout(sha);
        const build = new BuildRunnerReferee({ run: shellRunner('sh', ['test.sh']), dir: g.worktreeDir });
        return build.verdict();
      },
    },
    apply: (tree, patch) => g.apply(tree, patch),
    proposalBranch: () => g.branch,
    onEvent: (e) => events.push(e),
  };

  try {
    const forge = new CodeForge(spec);
    const r = await forge.run();

    assert.equal(r.stopReason, 'goal_reached');
    assert.ok(r.proposal);
    assert.equal(r.proposal.status, 'staged');
    assert.equal(r.proposal.seatId, 'tab-pilot');
    assert.match(r.proposal.summary, /minus to a plus/);
    assert.match(seenPrompts[0], /AVAILABLE TOOLS/);
    assert.match(seenPrompts[0], /forge\.run_tests/);
    // The flown tool sequence was recorded in the hash-chained memory.
    const attempt = forge.recorder.records.find((rec) => rec.op === 'attempt' && rec.data.status === 'green');
    assert.ok(attempt);
    assert.ok(attempt.data.toolSequence.includes('forge.write_file'));
    assert.ok(attempt.data.toolSequence.includes('forge.run_tests'));

    // The loop's referee is the authority; the base stays buggy until released.
    assert.equal(fs.readFileSync(path.join(dir, 'app.js'), 'utf8'), buggy);
    g.releaseToBase(g.branch, 'accept the fix');
    assert.equal(fs.readFileSync(path.join(dir, 'app.js'), 'utf8'), fixed);
  } finally {
    g.dispose();
  }
});
