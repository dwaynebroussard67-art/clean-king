/**
 * forge-controller.test.js — the ForgeController, owned end to end.
 *
 * The claim under test: the thing that owns the forge can launch a run over a
 * real repo, stream events, pause and resume, and let the human release or
 * reject — while the memory persists to the store. Seats arrive as
 * { id, name, send } descriptors (the production glue lives in main.js), so the
 * controller stays pure and fully testable here.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const { ForgeController, detectTestCommand } = require('../src/forge/index.js');

let tmpRoot = null;
function tmpdir() {
  if (!tmpRoot) tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-ctl-'));
  return fs.mkdtempSync(path.join(tmpRoot, 'run-'));
}

function toolReply(tools, summary) {
  return { ok: true, text: JSON.stringify({ summary: summary || 'fix', tools }) };
}

/** A seat stub that writes `fixed` to app.js and runs the tests. */
function smartPilotSeat(id, fixed) {
  return {
    id,
    name: id,
    send: async () =>
      toolReply(
        [
          { tool: 'forge.write_file', args: { path: 'app.js', content: fixed } },
          { tool: 'forge.run_tests', args: {} },
        ],
        'change the minus to a plus',
      ),
  };
}

/** A repo with a failing test (test.sh), as the production setup would have. */
function buggyRepo() {
  const dir = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: dir });
  execFileSync('git', ['config', 'user.name', 'Forge Test'], { cwd: dir });
  execFileSync('git', ['config', 'user.email', 'forge@test.local'], { cwd: dir });
  fs.writeFileSync(path.join(dir, 'app.js'), 'function add(a,b){return a-b;}\nmodule.exports = add;\n');
  fs.writeFileSync(
    path.join(dir, 'test.sh'),
    "#!/bin/sh\nnode -e \"const add=require('./app.js'); if(add(2,3)!==5){console.log('not ok 1 - add returns the sum');process.exit(1)} console.log('ok 1 - add returns the sum')\"\n",
  );
  execFileSync('git', ['add', '-A'], { cwd: dir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: dir });
  return dir;
}

// ── detectTestCommand ─────────────────────────────────────────────────────

test('detectTestCommand recognises each repo marker, and refuses to guess', () => {
  const cases = [
    ['package.json', { command: 'npm', args: ['test'] }],
    ['test.sh', { command: 'sh', args: ['test.sh'] }],
    ['Makefile', { command: 'make', args: ['test'] }],
    ['Cargo.toml', { command: 'cargo', args: ['test'] }],
    ['go.mod', { command: 'go', args: ['test', './...'] }],
    ['pyproject.toml', { command: 'pytest', args: [] }],
    ['setup.py', { command: 'pytest', args: [] }],
  ];
  for (const [file, expected] of cases) {
    const d = tmpdir();
    fs.writeFileSync(path.join(d, file), '');
    const got = detectTestCommand(d);
    assert.equal(got.command, expected.command, `${file} command`);
    assert.deepEqual(got.args, expected.args, `${file} args`);
  }
  const empty = tmpdir();
  assert.equal(detectTestCommand(empty), null);
});

test('a controller refuses to construct without a storeDir', () => {
  assert.throws(() => new ForgeController({}), /storeDir is required/);
});

// ── Launch → green → release ──────────────────────────────────────────────

test('full lifecycle: launch drives a real repo to green, and the human releases', async () => {
  const repoDir = buggyRepo();
  const storeDir = path.join(tmpdir(), 'store');
  const events = [];
  const c = new ForgeController({ storeDir, emit: (m) => events.push(m.event) });

  const r = await c.launch({
    goal: 'make add(2,3) return 5',
    repoDir,
    seats: [smartPilotSeat('claude', 'function add(a,b){return a+b;}\nmodule.exports = add;\n')],
    bench: [],
  });
  assert.equal(r.ok, true);
  assert.ok(r.branch.startsWith('forge/'));

  const result = await c.whenIdle();
  assert.equal(result.stopReason, 'goal_reached');
  assert.equal(c.active, false);
  assert.equal(c.paused, false);

  const view = c.view();
  assert.equal(view.active, false);
  assert.equal(view.lastResult.stopReason, 'goal_reached');
  assert.equal(view.proposals.length, 1);
  assert.equal(view.proposals[0].status, 'staged');
  assert.ok(events.includes('goal:reached'));

  // The base is still buggy until the human releases.
  assert.match(fs.readFileSync(path.join(repoDir, 'app.js'), 'utf8'), /return a-b/);

  const rel = c.release(view.proposals[0].id);
  assert.equal(rel.ok, true);
  assert.match(fs.readFileSync(path.join(repoDir, 'app.js'), 'utf8'), /return a\+b/);
  assert.equal(c.view().proposals[0].status, 'released');
});

test('reject: the human refuses, nothing is merged, the record stands', async () => {
  const repoDir = buggyRepo();
  const storeDir = path.join(tmpdir(), 'store');
  const c = new ForgeController({ storeDir });
  await c.launch({
    goal: 'make add(2,3) return 5',
    repoDir,
    seats: [smartPilotSeat('claude', 'function add(a,b){return a+b;}\nmodule.exports = add;\n')],
    bench: [],
  });
  await c.whenIdle();
  const id = c.view().proposals[0].id;

  const rej = c.reject(id, 'not ready to merge');
  assert.equal(rej.ok, true);
  assert.equal(c.view().proposals[0].status, 'rejected');
  assert.match(fs.readFileSync(path.join(repoDir, 'app.js'), 'utf8'), /return a-b/); // untouched

  // A rejected proposal cannot be released.
  const rel = c.release(id);
  assert.equal(rel.ok, false);
  assert.equal(rel.reason, 'not_staged');
});

// ── Pause and resume through the controller ───────────────────────────────

test('pause and resume: the run suspends on exhaustion and resumes to green', async () => {
  const repoDir = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: repoDir });
  execFileSync('git', ['config', 'user.name', 't'], { cwd: repoDir });
  execFileSync('git', ['config', 'user.email', 't@t'], { cwd: repoDir });
  // Two failing tests (t0, t1); the seat fixes one more per call.
  const srcFor = (n) => {
    const map = ['t0', 't1'].map((k, i) => `${k}:${i < n ? 1 : 0}`).join(', ');
    return `function t(x){ return { ${map} }[x] || 0; }\nmodule.exports = t;\n`;
  };
  fs.writeFileSync(path.join(repoDir, 'app.js'), srcFor(0));
  fs.writeFileSync(
    path.join(repoDir, 'test.sh'),
    "#!/bin/sh\nnode -e \"const t=require('./app.js'); let bad=0; for (const k of ['t0','t1']) if(!t(k)){ console.log('not ok - '+k); bad++ } if(bad) process.exit(1); console.log('ok - all')\"\n",
  );
  execFileSync('git', ['add', '-A'], { cwd: repoDir });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: repoDir });

  const storeDir = path.join(tmpdir(), 'store');
  const c = new ForgeController({ storeDir });

  let calls = 0;
  const seat = {
    id: 's1',
    name: 's1',
    send: async () => {
      calls += 1;
      return toolReply(
        [
          { tool: 'forge.write_file', args: { path: 'app.js', content: srcFor(calls) } },
          { tool: 'forge.run_tests', args: {} },
        ],
        'shrink',
      );
    },
  };

  const r = await c.launch({ goal: 'make the tests pass', repoDir, seats: [seat], bench: [], seatBudget: { maxCalls: 1 } });
  assert.equal(r.ok, true);
  const first = await c.whenIdle();
  assert.equal(first.stopReason, 'paused');
  assert.equal(c.paused, true);

  // A paused controller refuses to launch a fresh run.
  const again = await c.launch({ goal: 'x', repoDir, seats: [seat], bench: [] });
  assert.equal(again.ok, false);
  assert.equal(again.reason, 'paused');

  const res = await c.resume({ resetBudgets: true });
  assert.equal(res.ok, true);
  const second = await c.whenIdle();
  assert.equal(second.stopReason, 'goal_reached');
  assert.equal(c.paused, false);
});

// ── Named refusals ────────────────────────────────────────────────────────

test('launch refuses, by name: no goal, no repo, no seats, no test command', async () => {
  const storeDir = path.join(tmpdir(), 'store');
  const c = new ForgeController({ storeDir });
  const seat = smartPilotSeat('claude', 'x');

  assert.equal((await c.launch({ repoDir: '/x', seats: [seat], bench: [] })).reason, 'goal_required');
  assert.equal((await c.launch({ goal: 'g', seats: [seat], bench: [] })).reason, 'repo_required');
  assert.equal((await c.launch({ goal: 'g', repoDir: '/x' })).reason, 'no_seats');

  // A committed repo with no recognisable test command.
  const noTests = tmpdir();
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: noTests });
  execFileSync('git', ['config', 'user.name', 't'], { cwd: noTests });
  execFileSync('git', ['config', 'user.email', 't@t'], { cwd: noTests });
  fs.writeFileSync(path.join(noTests, 'README.md'), 'nothing\n');
  execFileSync('git', ['add', '-A'], { cwd: noTests });
  execFileSync('git', ['commit', '-qm', 'base'], { cwd: noTests });
  assert.equal((await c.launch({ goal: 'g', repoDir: noTests, seats: [seat], bench: [] })).reason, 'no_test_command');

  const notRepo = tmpdir();
  const r = await c.launch({ goal: 'g', repoDir: notRepo, seats: [seat], bench: [] });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'repo_error');
});

test('release/reject with no run, or a missing id, are named refusals', async () => {
  const c = new ForgeController({ storeDir: path.join(tmpdir(), 'store') });
  assert.equal(c.release('nope').reason, 'no_run');
  assert.equal(c.reject('nope').reason, 'no_run');

  const repoDir = buggyRepo();
  await c.launch({
    goal: 'g',
    repoDir,
    seats: [smartPilotSeat('claude', 'function add(a,b){return a+b;}\nmodule.exports = add;\n')],
    bench: [],
  });
  await c.whenIdle();
  assert.equal(c.release('proposal_missing').reason, 'not_found');
  assert.equal(c.reject('proposal_missing').reason, 'not_found');
});

// ── Persistence through the controller ────────────────────────────────────

test('the memory persists: a second controller sees the saved proposals and chain', async () => {
  const repoDir = buggyRepo();
  const storeDir = path.join(tmpdir(), 'store');
  const c1 = new ForgeController({ storeDir });
  await c1.launch({
    goal: 'make add(2,3) return 5',
    repoDir,
    seats: [smartPilotSeat('claude', 'function add(a,b){return a+b;}\nmodule.exports = add;\n')],
    bench: [],
  });
  await c1.whenIdle();

  const c2 = new ForgeController({ storeDir });
  const view = c2.view();
  assert.equal(view.saved.proposals.length, 1);
  assert.equal(view.saved.proposals[0].status, 'staged');
  assert.equal(view.saved.chainBreaks, 0);
  assert.equal(view.saved.corrupt, 0);
});
