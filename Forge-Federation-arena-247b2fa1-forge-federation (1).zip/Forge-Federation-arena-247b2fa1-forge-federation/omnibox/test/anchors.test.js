'use strict';

/**
 * anchors.test.js — the engine-training record and its pipe rule.
 *
 * The one law under test: anchors and outcomes only, never conversation
 * content. Plus the before/after pairing that makes a redetect on a known
 * URL into a real mutation record, and the dedup that keeps mutation
 * re-detects from flooding the log.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const { AnchorLog, sanitize, verifyAnchorLog, CHAIN_GENESIS } = require('../src/main/anchors.js');
const { chainHash } = require('../src/main/chain.js');

function tmpLog() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-anchors-'));
  return { dir, log: new AnchorLog(dir) };
}

function readLines(log) {
  return fs.readFileSync(log.logPath, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
}

// ---------------------------------------------------------------- the pipe rule

test('sanitize strips prompt/reply/text at any depth', () => {
  const dropped = [];
  const out = sanitize(
    {
      prompt: 'what is the shape of the table',
      nested: { reply: 'a round table', keep: 'yes', deeper: [{ text: 'echo', box: { x: 1 } }] },
      winner: { tag: 'div', stabilityKey: 'abc' },
    },
    dropped
  );
  assert.deepEqual(dropped.sort(), ['prompt', 'reply', 'text']);
  assert.equal(out.prompt, undefined);
  assert.equal(out.nested.reply, undefined);
  assert.equal(out.nested.deeper[0].text, undefined);
  assert.equal(out.nested.deeper[0].box.x, 1);
  assert.equal(out.winner.tag, 'div');
  assert.equal(out.nested.keep, 'yes');
});

test('sanitize caps allowed strings so a page cannot use them as a channel', () => {
  const out = sanitize({ ariaLabel: 'x'.repeat(5000) }, []);
  assert.ok(out.ariaLabel.length <= 160);
});

test('append drops denied fields and still writes the rest', () => {
  const { log } = tmpLog();
  log.append({ type: 'outcome', ok: true, prompt: 'secret', reason: 'settled', elapsedMs: 1200 });
  const [rec] = readLines(log);
  assert.equal(rec.prompt, undefined);
  assert.equal(rec.reason, 'settled');
  assert.equal(rec.elapsedMs, 1200);
  assert.ok(rec.at, 'every record is timestamped');
});

// ------------------------------------------------------------------- verdicts

test('a verdict records winner and losers with stamps', () => {
  const { log } = tmpLog();
  log.verdict({
    tabId: 1,
    url: 'https://example.chat/',
    trigger: 'load',
    payload: {
      status: 'seated',
      confidence: 0.9,
      margin: 0.2,
      anchor: { tag: 'div', stabilityKey: 'k1', score: 0.9 },
      candidates: [
        { tag: 'div', stabilityKey: 'k1', score: 0.9 },
        { tag: 'textarea', stabilityKey: 'k2', score: 0.7 },
      ],
    },
  });
  const [rec] = readLines(log);
  assert.equal(rec.type, 'verdict');
  assert.equal(rec.url, 'https://example.chat/');
  assert.equal(rec.winner.stabilityKey, 'k1');
  assert.equal(rec.losers.length, 1, 'the winner is not also listed as a loser');
  assert.equal(rec.losers[0].stabilityKey, 'k2');
});

test('identical repeat verdicts are deduped, changed ones are written', () => {
  const { log } = tmpLog();
  const payload = { status: 'seated', confidence: 0.9, anchor: { stabilityKey: 'k1' }, candidates: [] };
  log.verdict({ tabId: 1, url: 'https://a.chat/', trigger: 'load', payload });
  log.verdict({ tabId: 1, url: 'https://a.chat/', trigger: 'mutation', payload });
  log.verdict({ tabId: 1, url: 'https://a.chat/', trigger: 'mutation', payload });
  assert.equal(log.count(), 1, 'mutation churn with no change writes nothing');

  log.verdict({
    tabId: 1,
    url: 'https://a.chat/',
    trigger: 'mutation',
    payload: { status: 'seated', confidence: 0.88, anchor: { stabilityKey: 'k2' }, candidates: [] },
  });
  const lines = readLines(log);
  assert.equal(lines.length, 3); // verdict + anchor-change + verdict
  assert.equal(lines[1].type, 'anchor-change');
  assert.equal(lines[1].before.winnerKey, 'k1');
  assert.equal(lines[1].after.winnerKey, 'k2');
});

test('a refusal after a seat is an anchor-change pair', () => {
  const { log } = tmpLog();
  log.verdict({ tabId: 2, url: 'https://b.chat/', trigger: 'load', payload: { status: 'seated', anchor: { stabilityKey: 'k1' }, candidates: [] } });
  log.verdict({ tabId: 2, url: 'https://b.chat/', trigger: 'mutation', payload: { status: 'refused', verdictReason: 'ambiguous', candidates: [{ stabilityKey: 'k9' }] } });
  const lines = readLines(log);
  const change = lines.find((l) => l.type === 'anchor-change');
  assert.ok(change, 'the flip was paired');
  assert.equal(change.before.status, 'seated');
  assert.equal(change.after.status, 'refused');
  assert.equal(change.after.verdictReason, 'ambiguous');
});

test('a verdict change on a different URL is not an anchor-change', () => {
  const { log } = tmpLog();
  log.verdict({ tabId: 3, url: 'https://c.chat/1', trigger: 'load', payload: { status: 'seated', anchor: { stabilityKey: 'k1' }, candidates: [] } });
  log.verdict({ tabId: 3, url: 'https://c.chat/2', trigger: 'load', payload: { status: 'seated', anchor: { stabilityKey: 'k2' }, candidates: [] } });
  const lines = readLines(log);
  assert.ok(!lines.some((l) => l.type === 'anchor-change'), 'different URL is a new page, not a mutation');
});

// ------------------------------------------------------------------- outcomes

test('an outcome record carries the named result and the anchor join key, never the text', () => {
  const { log } = tmpLog();
  log.outcome({
    url: 'https://a.chat/',
    runId: 'r1',
    round: 2,
    role: 'B',
    seatName: 'Chatgpt',
    anchorKey: 'k1',
    result: { ok: true, reason: 'settled', text: 'the whole reply', elapsedMs: 3210.7, strategy: 'native-setter', via: 'button' },
  });
  const [rec] = readLines(log);
  assert.equal(rec.type, 'outcome');
  assert.equal(rec.ok, true);
  assert.equal(rec.reason, 'settled');
  assert.equal(rec.anchorKey, 'k1');
  assert.equal(rec.round, 2);
  assert.equal(rec.elapsedMs, Math.round(3210.7), 'elapsed time is a rounded integer');
  assert.equal(rec.text, undefined, 'the reply never crosses into the training record');
  assert.equal(rec.prompt, undefined);
});

test('a refused outcome keeps its named reason', () => {
  const { log } = tmpLog();
  log.outcome({ url: 'https://a.chat/', runId: 'r1', result: { ok: false, reason: 'readback-mismatch' } });
  const [rec] = readLines(log);
  assert.equal(rec.ok, false);
  assert.equal(rec.reason, 'readback-mismatch');
});

// ---------------------------------------------------------------- human picks

test('a human pick is recorded as a ruling with the picked stamp', () => {
  const { log } = tmpLog();
  log.pick({ url: 'https://d.chat/', payload: { ok: true, tag: 'div', stamp: { stabilityKey: 'k7', pickedBy: 'human' } } });
  const [rec] = readLines(log);
  assert.equal(rec.type, 'pick');
  assert.equal(rec.stamp.stabilityKey, 'k7');
});

test('a human confirm is recorded as a ruling on the claimed anchor key', () => {
  const { log } = tmpLog();
  assert.equal(log.confirm({ url: 'https://d.chat/', anchorKey: 'k7', confirmed: false }), true);
  const [rec] = readLines(log);
  assert.equal(rec.type, 'confirm');
  assert.equal(rec.anchorKey, 'k7');
  assert.equal(rec.confirmed, false);
});

test('a confirm with no anchor key writes nothing joinable', () => {
  const { log } = tmpLog();
  assert.equal(log.confirm({ url: 'https://d.chat/', anchorKey: null, confirmed: true }), false);
  assert.equal(log.count(), 0);
});

// ------------------------------------------------------------- the file itself

test('the log is append-only JSONL and survives reopen', () => {
  const { dir, log } = tmpLog();
  log.append({ type: 'verdict', url: 'https://x/', status: 'seated' });
  log.append({ type: 'outcome', ok: true });
  const reopened = new AnchorLog(dir);
  assert.equal(reopened.count(), 2);
  const before = fs.readFileSync(log.logPath, 'utf8');
  reopened.append({ type: 'pick', ok: true });
  const after = fs.readFileSync(log.logPath, 'utf8');
  assert.ok(after.startsWith(before), 'existing lines are never rewritten');
});

// ===========================================================================
// The pipe rule, fuzzed.
//
// DENY_KEY is a security boundary: it is what stops a prompt or a reply from
// crossing into a store that is not the Memory Passport, at any depth,
// forever, on an append-only file that is never rewritten. The tests above
// prove it works on three hand-written shapes. A boundary is not proven by
// three shapes.
//
// So: generate records with arbitrarily nested, arbitrarily cased,
// arbitrarily positioned denied keys and assert the invariant globally —
// after sanitize, NO key anywhere in the output matches DENY_KEY, and the
// count of dropped keys equals the count that went in. The generator is
// seeded, so a failure is reproducible from the number printed with it.
// ===========================================================================

const { DENY_KEY } = require('../src/main/anchors.js');

/** A tiny deterministic PRNG. A fuzz failure nobody can reproduce is a
 *  rumour, so the seed goes in the assertion message. */
function rng(seed) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 0x100000000;
  };
}

const DENIED_BASES = [
  'prompt', 'prompts', 'reply', 'replies', 'text', 'texts', 'content',
  'body', 'message', 'sent', 'chunk', 'chunks', 'answer', 'answers', 'draft',
];
/** Keys that LOOK dangerous but are page furniture the log needs. A rule
 *  that eats these is as broken as one that leaks: `contentEditable` is how
 *  a candidate says what kind of editable it is. */
const ALLOWED_LOOKALIKES = [
  'contentEditable', 'textContent_ish', 'bodyClass', 'messageBoxLabel',
  'promptness', 'replyish', 'ariaLabel', 'placeholder', 'stabilityKey',
  'answered', 'draftable', 'sentAt', 'textual', 'subtext', 'contents',
];

/** Randomly re-case a name: PROMPT, Prompt, pRoMpT — the rule is /i, and a
 *  future edit that drops the flag must fail here loudly. */
function recase(name, rand) {
  return [...name].map((ch) => (rand() < 0.5 ? ch.toUpperCase() : ch.toLowerCase())).join('');
}

/** Walk any value and collect every object key at every depth. */
function allKeys(value, out = []) {
  if (Array.isArray(value)) {
    for (const v of value) allKeys(v, out);
  } else if (value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value)) {
      out.push(k);
      allKeys(v, out);
    }
  }
  return out;
}

/** Build a random record, returning it alongside how many denied keys it
 *  contains — the oracle the fuzz asserts against. */
function makeRecord(rand, depth = 0) {
  const node = {};
  let denied = 0;
  const fields = 1 + Math.floor(rand() * 5);
  for (let i = 0; i < fields; i++) {
    const roll = rand();
    let key;
    if (roll < 0.4) {
      key = recase(DENIED_BASES[Math.floor(rand() * DENIED_BASES.length)], rand);
    } else if (roll < 0.7) {
      key = ALLOWED_LOOKALIKES[Math.floor(rand() * ALLOWED_LOOKALIKES.length)];
    } else {
      key = `k${Math.floor(rand() * 1000)}`;
    }
    // A repeated key is one property, not two — count only what lands.
    if (Object.prototype.hasOwnProperty.call(node, key)) continue;
    if (DENY_KEY.test(key)) denied++;

    const shape = rand();
    if (depth < 5 && shape < 0.3) {
      const child = makeRecord(rand, depth + 1);
      node[key] = child.value;
      // A denied key's whole subtree is cut, so anything under it is not
      // counted: sanitize never descends into what it drops.
      if (!DENY_KEY.test(key)) denied += child.denied;
    } else if (depth < 5 && shape < 0.5) {
      const n = 1 + Math.floor(rand() * 3);
      const arr = [];
      let sub = 0;
      for (let j = 0; j < n; j++) {
        const child = makeRecord(rand, depth + 1);
        arr.push(child.value);
        sub += child.denied;
      }
      node[key] = arr;
      if (!DENY_KEY.test(key)) denied += sub;
    } else {
      node[key] = rand() < 0.5 ? 'a-string-of-page-furniture' : Math.floor(rand() * 1e6);
    }
  }
  return { value: node, denied };
}

test('fuzz — no key matching the pipe rule survives sanitize, at any depth or casing', () => {
  for (let seed = 1; seed <= 400; seed++) {
    const rand = rng(seed * 2654435761);
    const { value, denied } = makeRecord(rand);
    const dropped = [];
    const out = sanitize(value, dropped);

    const survivors = allKeys(out).filter((k) => DENY_KEY.test(k));
    assert.deepEqual(survivors, [], `seed ${seed}: keys survived the pipe rule: ${survivors.join(', ')}`);
    assert.equal(dropped.length, denied, `seed ${seed}: dropped count does not match what went in`);
    assert.ok(dropped.every((k) => DENY_KEY.test(k)), `seed ${seed}: something was dropped that was not denied`);
  }
});

test('fuzz — page furniture the log actually needs is never eaten by the rule', () => {
  for (const key of ALLOWED_LOOKALIKES) {
    const dropped = [];
    const out = sanitize({ [key]: 'kept', winner: { [key]: 'kept too' } }, dropped);
    assert.equal(dropped.length, 0, `${key} was dropped — the rule is over-broad`);
    assert.equal(out[key], 'kept');
    assert.equal(out.winner[key], 'kept too');
  }
});

test('the pipe rule is case-insensitive on every denied name, spelled every way', () => {
  const rand = rng(20260904);
  for (const base of DENIED_BASES) {
    for (const spelling of [base, base.toUpperCase(), base[0].toUpperCase() + base.slice(1), recase(base, rand)]) {
      const dropped = [];
      const out = sanitize({ [spelling]: 'the whole conversation' }, dropped);
      assert.deepEqual(Object.keys(out), [], `${spelling} was not stripped`);
      assert.deepEqual(dropped, [spelling]);
    }
  }
});

test('the shapes named in the brief are stripped: Prompt, REPLY_TEXT-ish, nested.chunks[0].content', () => {
  const dropped = [];
  const out = sanitize(
    {
      Prompt: 'what is the shape of the table',
      REPLY: 'a round one',
      nested: {
        chunks: [{ content: 'streamed reply text', box: { x: 1, y: 2 } }],
        deeper: { level: { Message: 'hi', TEXT: 'bye', keep: 'furniture' } },
      },
      losers: [{ tag: 'div', Content: 'a reply', stabilityKey: 'k2' }],
    },
    dropped
  );

  assert.equal(out.Prompt, undefined);
  assert.equal(out.REPLY, undefined);
  assert.equal(out.nested.chunks, undefined, 'the chunks array goes whole — its contents never had to be inspected');
  assert.equal(out.nested.deeper.level.Message, undefined);
  assert.equal(out.nested.deeper.level.TEXT, undefined);
  assert.equal(out.nested.deeper.level.keep, 'furniture', 'and the furniture beside it survives');
  assert.equal(out.losers[0].Content, undefined);
  assert.equal(out.losers[0].stabilityKey, 'k2', 'the join key is the point of the record');
  assert.deepEqual(dropped.sort(), ['Content', 'Message', 'Prompt', 'REPLY', 'TEXT', 'chunks']);

  // REPLY_TEXT is a compound name, not one of the denied words. It is NOT
  // stripped, and that is the honest boundary: the rule matches whole key
  // names so it cannot swallow `contentEditable` or `stabilityKey`. Recorded
  // here so the limit is a decision on the record rather than a surprise.
  const d2 = [];
  const o2 = sanitize({ REPLY_TEXT: 'x' }, d2);
  assert.equal(o2.REPLY_TEXT, 'x');
  assert.deepEqual(d2, []);
});

test('a fuzzed record written to disk carries no denied key into the file', () => {
  const { log } = tmpLog();
  let expected = 0;
  for (let seed = 1; seed <= 60; seed++) {
    const { value, denied } = makeRecord(rng(seed * 40503));
    log.append({ type: 'verdict', url: 'https://fuzz.example/', ...value });
    expected += denied;
  }
  const lines = readLines(log);
  assert.equal(lines.length, 60);
  for (const [i, rec] of lines.entries()) {
    const survivors = allKeys(rec).filter((k) => DENY_KEY.test(k));
    assert.deepEqual(survivors, [], `line ${i} carried ${survivors.join(', ')} to disk`);
  }
  assert.equal(log.droppedFields, expected, 'the log counts every field it refused');
});

test('a pilot step records the verb and the refusal, never the target or the words', () => {
  const { log } = tmpLog();
  log.pilotStep({ url: 'https://x.example/', pilot: 'p1', step: 2, verb: 'click', ok: false, reason: 'ambiguous-click' });
  const [rec] = readLines(log);
  assert.equal(rec.type, 'pilot-step');
  assert.equal(rec.verb, 'click');
  assert.equal(rec.ok, false);
  assert.equal(rec.reason, 'ambiguous-click');
  assert.ok(!('selector' in rec) && !('text' in rec) && !('target' in rec));
});

test('the anchor log is hash-chained: a clean file verifies', () => {
  const { log } = tmpLog();
  log.append({ type: 'verdict', url: 'https://x/', status: 'seated' });
  log.append({ type: 'outcome', ok: true });
  const v = log.verify();
  assert.equal(v.ok, true);
  assert.equal(v.breaks.length, 0);
  assert.equal(v.chained, 2);
  assert.notEqual(v.head, CHAIN_GENESIS);
  const lines = readLines(log);
  assert.ok(lines[0].prev);
  assert.ok(lines[0].hash);
  assert.equal(lines[1].prev, lines[0].hash);
});

test('two records that differ only in a nested field hash differently', () => {
  const a = { type: 'pick', nested: { value: 'A' } };
  const b = { type: 'pick', nested: { value: 'B' } };
  assert.notEqual(chainHash(CHAIN_GENESIS, a), chainHash(CHAIN_GENESIS, b));
});

test('editing an anchor record in place breaks the chain', () => {
  const { log } = tmpLog();
  log.append({ type: 'pick', url: 'https://a.example/', ok: true });
  log.append({ type: 'pick', url: 'https://b.example/', ok: true });
  const lines = fs.readFileSync(log.logPath, 'utf8').split('\n').filter(Boolean);
  const parsed = JSON.parse(lines[0]);
  parsed.ok = false;
  lines[0] = JSON.stringify(parsed);
  fs.writeFileSync(log.logPath, lines.join('\n') + '\n');
  const v = log.verify();
  assert.equal(v.ok, false);
  assert.ok(v.breaks.some((b) => b.kind === 'hash-mismatch'), JSON.stringify(v.breaks));
});

test('a forged append after a legitimate record breaks the chain', () => {
  const { log } = tmpLog();
  log.append({ type: 'pick', url: 'https://a.example/', ok: true });
  fs.appendFileSync(
    log.logPath,
    JSON.stringify({ type: 'pick', url: 'https://evil.example/', ok: true, prev: 'fakehash', hash: 'fakehash' }) + '\n'
  );
  const v = verifyAnchorLog(log.logPath);
  assert.equal(v.ok, false);
  assert.equal(typeof v.breaks[0].line, 'number');
});

test('a torn last line in the anchor log still verifies', () => {
  const { log } = tmpLog();
  log.append({ type: 'pick', url: 'https://a.example/', ok: true });
  fs.appendFileSync(log.logPath, '{"type":"pick","val":');
  const v = log.verify();
  assert.equal(v.ok, true);
  assert.equal(v.torn, true);
  assert.equal(v.chained, 1);
});

test('legacy unchained anchor lines load and new writes chain from genesis', () => {
  const { dir, log } = tmpLog();
  fs.writeFileSync(
    log.logPath,
    JSON.stringify({ type: 'verdict', url: 'https://old.example/', status: 'seated' }) + '\n'
  );
  const again = new AnchorLog(dir);
  const v = again.verify();
  assert.equal(v.legacy, 1);
  assert.equal(v.chained, 0);
  assert.equal(v.ok, true);
  again.append({ type: 'pick', ok: true });
  const v2 = again.verify();
  assert.equal(v2.ok, true);
  assert.equal(v2.legacy, 1);
  assert.equal(v2.chained, 1);
});

test('reopening an anchor log continues the chain', () => {
  const { dir, log } = tmpLog();
  log.append({ type: 'verdict', url: 'https://x/', status: 'seated' });
  const head = log.head;
  const again = new AnchorLog(dir);
  again.append({ type: 'outcome', ok: true });
  const v = again.verify();
  assert.equal(v.ok, true);
  assert.equal(v.chained, 2);
  assert.notEqual(again.head, head);
});

test('a hostile record cannot smuggle text through a key that only looks structural', () => {
  const dropped = [];
  const out = sanitize(
    {
      // A page controls its own attribute names, so the values of ALLOWED
      // keys are the remaining channel — and they are capped, not trusted.
      ariaLabel: 'x'.repeat(10000),
      placeholder: 'y'.repeat(10000),
      classes: 'z'.repeat(10000),
      nested: [{ label: 'w'.repeat(10000) }],
    },
    dropped
  );
  for (const v of [out.ariaLabel, out.placeholder, out.classes, out.nested[0].label]) {
    assert.ok(v.length <= 160, `an allowed string was not capped: ${v.length}`);
  }
});
