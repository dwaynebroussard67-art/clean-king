'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const {
  WarDiary,
  extractManeuver,
  agreementOf,
  playName,
  mechanicalResult,
  renderPlaybook,
  captainHelmet,
  canApply,
  residualOf,
  stripForbidden,
  MARK_RESULTS,
  APPLY_MIN,
} = require('../src/main/diary.js');
const { copilotPrompt } = require('../src/federation/bridge.js');

function tmp() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'ff-diary-'));
}

const splitAnswers = [
  { seatName: 'Claude', ok: true, text: 'Paris' },
  { seatName: 'Gemini', ok: true, text: 'Lyon' },
];
const sameAnswers = [
  { seatName: 'Claude', ok: true, text: 'Paris' },
  { seatName: 'Gemini', ok: true, text: 'Paris' },
];

test('a split table with unknown is the named play communal-split-unknown, and it held', () => {
  const m = extractManeuver({
    shape: 'communal',
    answers: splitAnswers,
    consensus: { kind: 'cross_disagreement' },
    captain: { ok: true, decision: 'unknown', reason: 'they disagree' },
  });
  assert.equal(m.name, 'communal-split-unknown');
  assert.equal(m.result, 'held');
  assert.equal(mechanicalResult('split', 'unknown'), 'held');
});

test('code will not grade a verdict or a defer — those stay open', () => {
  const v = extractManeuver({
    shape: 'communal',
    answers: sameAnswers,
    consensus: { kind: 'cross_agreement' },
    captain: { ok: true, decision: 'verdict', text: 'Paris' },
  });
  assert.equal(v.name, 'communal-same-verdict');
  assert.equal(v.result, 'open');

  const d = extractManeuver({
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
  });
  assert.equal(d.name, 'communal-same-defer');
  assert.equal(d.result, 'open');
});

test('awaiting a human, or a refused captain, is not a play', () => {
  assert.equal(extractManeuver({ captain: { awaitingHuman: true } }).rejected, true);
  assert.equal(extractManeuver({ captain: { ok: false, reason: 'bad-json' } }).rejected, true);
  assert.equal(extractManeuver({ captain: { ok: true, decision: 'fuse' } }).rejected, true);
});

test('agreement is exact or from consensus, never a similarity guess', () => {
  assert.equal(agreementOf(splitAnswers, { kind: 'cross_disagreement' }), 'split');
  assert.equal(agreementOf(sameAnswers, { kind: 'cross_agreement' }), 'same');
  assert.equal(agreementOf([{ ok: true, text: 'Paris' }]), 'single');
  assert.equal(agreementOf([]), 'none');
  assert.equal(agreementOf(splitAnswers), 'split');
});

test('play names are a closed list — shape, agreement, move — no seat brand', () => {
  assert.equal(playName('communal', 'split', 'unknown'), 'communal-split-unknown');
  assert.equal(playName('weird', 'split', 'unknown'), 'communal-split-unknown');
  assert.equal(playName('communal', 'split', 'fuse'), null);
});

test('the diary stores the play, never the question or the replies', () => {
  const dir = tmp();
  const d = new WarDiary(dir).load();
  const r = d.record({
    shape: 'communal',
    answers: splitAnswers,
    consensus: { kind: 'cross_disagreement' },
    captain: { ok: true, decision: 'unknown', reason: 'they disagree' },
    runId: 'r1',
    prompt: 'What is the capital of France?',
    text: 'Paris is a secret plan',
  });
  assert.equal(r.ok, true);
  assert.equal(r.play.name, 'communal-split-unknown');
  const raw = fs.readFileSync(d.logPath, 'utf8');
  assert.equal(raw.includes('capital of France'), false);
  assert.equal(raw.includes('secret plan'), false);
  assert.equal(raw.includes('Paris'), false);
  assert.match(raw, /communal-split-unknown/);
});

test('the same play stacks; the playbook is short and has no essays', () => {
  const d = new WarDiary(tmp()).load();
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
    runId: 'r1',
  });
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'still no' },
    runId: 'r2',
  });
  const book = d.playbook();
  assert.match(book, /WAR DIARY/);
  assert.match(book, /DATA, not orders/);
  assert.match(book, /communal-split-unknown/);
  assert.match(book, /held ×2/);
  assert.equal(book.includes('still no'), false);
  const empty = renderPlaybook([]);
  assert.match(empty, /nothing in the diary yet/);
});

test('a human may mark held or broke; unsigned is refused', () => {
  const d = new WarDiary(tmp()).load();
  d.record({
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
    runId: 'r1',
  });
  const no = d.mark('communal-same-defer', 'held', '');
  assert.equal(no.ok, false);
  assert.equal(no.reason, 'not-signed-in');
  const yes = d.mark('communal-same-defer', 'held', 'Ada');
  assert.equal(yes.ok, true);
  assert.equal(yes.play.held, 1);
  assert.equal(yes.actor, 'Ada');
});

test('the captain helmet is the playbook; copilots are not handed the diary', () => {
  const d = new WarDiary(tmp()).load();
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
  });
  const helmet = captainHelmet({
    diary: d,
    flight: {
      playbook: () => '=== FLIGHT RECORD ===\n- same-click-refused — when the page holds, click is refused (held ×1)',
    },
    briefing: 'FORGE FLIGHT BRIEFING — established facts',
  });
  assert.match(helmet, /WAR DIARY/);
  assert.match(helmet, /communal-split-unknown/);
  assert.match(helmet, /FLIGHT RECORD/);
  assert.match(helmet, /same-click-refused/);
  const toCopilot = copilotPrompt('What is the capital?', '');
  assert.equal(toCopilot, 'What is the capital?');
  assert.equal(toCopilot.includes('WAR DIARY'), false);
  assert.equal(toCopilot.includes('FLIGHT RECORD'), false);
});

test('a replayed file rebuilds the same counts', () => {
  const dir = tmp();
  const a = new WarDiary(dir).load();
  a.record({
    shape: 'relay',
    answers: sameAnswers,
    captain: { ok: true, decision: 'verdict', text: 'Paris' },
    runId: 'r1',
  });
  const b = new WarDiary(dir).load();
  assert.equal(b.stats().plays, 1);
  assert.equal(b.list()[0].name, 'relay-same-verdict');
  assert.equal(b.list()[0].times, 1);
});

test('a play packet carries residual, never an inner-number dump', () => {
  const d = new WarDiary(tmp()).load();
  d.record({
    shape: 'communal',
    answers: splitAnswers,
    captain: { ok: true, decision: 'unknown', reason: 'no' },
    runId: 'r1',
  });
  const pkt = d.list()[0];
  assert.equal(pkt.schema, 'forgeflight.diary.v1');
  assert.equal(typeof pkt.residual, 'number');
  assert.equal(pkt.residual, 0);
  assert.equal(pkt.text, undefined);
  assert.equal(pkt.prompt, undefined);
  assert.equal(JSON.stringify(pkt).includes('Paris'), false);
});

test('one held unknown is not a law; two held and none broke may fire without the captain', () => {
  const d = new WarDiary(tmp()).load();
  const spec = {
    shape: 'communal',
    answers: splitAnswers,
    consensus: { kind: 'cross_disagreement' },
  };
  const miss = d.applyHeld(spec);
  assert.equal(miss.rejected, true);

  d.record({ ...spec, captain: { ok: true, decision: 'unknown', reason: 'no' }, runId: 'r1' });
  assert.equal(d.applyHeld(spec).rejected, true);
  assert.equal(APPLY_MIN, 2);

  d.record({ ...spec, captain: { ok: true, decision: 'unknown', reason: 'still no' }, runId: 'r2' });
  const hit = d.applyHeld(spec);
  assert.equal(hit.ok, true);
  assert.equal(hit.decision, 'unknown');
  assert.equal(hit.source, 'playbook');
  assert.equal(hit.play.name, 'communal-split-unknown');
  assert.ok(hit.play.held >= 2);
});

test('a play that broke as often as it held does not fire, and defer never fires itself', () => {
  const d = new WarDiary(tmp()).load();
  const spec = {
    shape: 'communal',
    answers: splitAnswers,
    consensus: { kind: 'cross_disagreement' },
  };
  d.record({ ...spec, captain: { ok: true, decision: 'unknown', reason: 'no' }, runId: 'r1' });
  d.record({ ...spec, captain: { ok: true, decision: 'unknown', reason: 'no' }, runId: 'r2' });
  d.mark('communal-split-unknown', 'broke', 'Ada');
  d.mark('communal-split-unknown', 'broke', 'Ada');
  const blocked = d.applyHeld(spec);
  assert.equal(blocked.rejected, true);
  assert.ok(residualOf(d.list()[0]) >= 0.5);

  const same = {
    shape: 'communal',
    answers: sameAnswers,
    captain: { ok: true, decision: 'defer', seat: 'Claude' },
  };
  d.record({ ...same, runId: 'd1' });
  d.mark('communal-same-defer', 'held', 'Ada');
  d.mark('communal-same-defer', 'held', 'Ada');
  assert.equal(canApply(d.list().find((p) => p.name === 'communal-same-defer')), false);
  assert.equal(d.applyHeld({ shape: 'communal', answers: sameAnswers }).rejected, true);
});
