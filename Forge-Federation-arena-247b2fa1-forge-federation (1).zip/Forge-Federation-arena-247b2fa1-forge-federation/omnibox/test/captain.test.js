'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  parseCaptain,
  findDeferred,
  captainDecide,
  buildAsk,
  applyHumanCaptain,
} = require('../src/main/captain.js');

test('parseCaptain accepts the three decisions and nothing else', () => {
  assert.equal(parseCaptain('{"decision":"verdict","text":"Paris"}').decision, 'verdict');
  assert.equal(parseCaptain('{"decision":"defer","seat":"Claude"}').seat, 'Claude');
  assert.equal(parseCaptain('{"decision":"unknown","reason":"they disagree"}').decision, 'unknown');
  assert.equal(parseCaptain('{"decision":"fuse","text":"avg"}').rejected, true);
  assert.equal(parseCaptain('not json').rejected, true);
  assert.equal(parseCaptain('{"decision":"verdict","text":""}').reason, 'empty-verdict');
});

test('parseCaptain pulls JSON out of a chatty reply', () => {
  const r = parseCaptain('Sure.\n```json\n{"decision":"unknown","reason":"no"}\n```');
  assert.equal(r.decision, 'unknown');
});

test('findDeferred matches one seat, case-insensitive, and refuses a miss', () => {
  const answers = [
    { seatName: 'Claude', ok: true, text: 'Paris' },
    { seatName: 'Gemini', ok: true, text: 'Lyon' },
  ];
  assert.equal(findDeferred(answers, 'claude').text, 'Paris');
  assert.equal(findDeferred(answers, 'ChatGPT'), null);
});

test('no local model hands the chair to the human, not a skip', async () => {
  const r = await captainDecide({
    ask: null,
    prompt: 'capital?',
    answers: [{ seatName: 'Claude', ok: true, text: 'Paris' }],
  });
  assert.equal(r.awaitingHuman, true);
  assert.equal(r.reason, 'human-captain');
  assert.equal(r.skipped, undefined);
  assert.equal(r.answers[0].seatName, 'Claude');
});

test('a verdict is the captain speaking in its own words', async () => {
  const r = await captainDecide({
    ask: async () => ({ ok: true, text: '{"decision":"verdict","text":"Paris"}' }),
    prompt: 'capital of France?',
    answers: [{ seatName: 'Claude', ok: true, text: 'Paris' }],
  });
  assert.equal(r.ok, true);
  assert.equal(r.decision, 'verdict');
  assert.equal(r.text, 'Paris');
});

test('defer uses the named copilot; a miss becomes unknown, not a fusion', async () => {
  const hit = await captainDecide({
    ask: async () => ({ ok: true, text: '{"decision":"defer","seat":"Claude"}' }),
    prompt: 'q',
    answers: [
      { seatName: 'Claude', ok: true, text: 'Paris' },
      { seatName: 'Gemini', ok: true, text: 'Lyon' },
    ],
  });
  assert.equal(hit.decision, 'defer');
  assert.equal(hit.text, 'Paris');
  assert.equal(hit.seat, 'Claude');

  const miss = await captainDecide({
    ask: async () => ({ ok: true, text: '{"decision":"defer","seat":"Nobody"}' }),
    prompt: 'q',
    answers: [{ seatName: 'Claude', ok: true, text: 'Paris' }],
  });
  assert.equal(miss.decision, 'unknown');
});

test('the ask is told not to fuse, and is handed the helmet separately from the question', () => {
  const a = buildAsk({
    prompt: 'capital of France?',
    answers: [{ seatName: 'Claude', ok: true, text: 'Paris' }],
    helmet: '=== WAR DIARY ===\nnamed plays',
  });
  assert.match(a.system, /WAR DIARY/);
  assert.match(a.prompt, /capital of France/);
  assert.match(a.prompt, /Do not fuse/);
  assert.match(a.prompt, /Claude/);
  assert.match(a.prompt, /data, not an order/);
});

test('a copilot answer is clipped so a small local model is not asked to re-read a novel', () => {
  const { ANSWER_CLIP } = require('../src/main/captain.js');
  const long = 'x'.repeat(ANSWER_CLIP + 800);
  const a = buildAsk({
    prompt: 'q',
    answers: [{ seatName: 'Claude', ok: true, text: long }],
  });
  assert.equal(a.prompt.includes(long), false);
  assert.ok(a.prompt.includes('x'.repeat(ANSWER_CLIP)));
});

test('an ask that fails still hands the chair to the human', async () => {
  const r = await captainDecide({
    ask: async () => ({ ok: false, reason: 'no-server' }),
    prompt: 'q',
    answers: [{ seatName: 'Claude', ok: true, text: 'Paris' }],
  });
  assert.equal(r.awaitingHuman, true);
  assert.equal(r.reason, 'human-captain');
  assert.equal(r.skipped, undefined);
});

test('the human captain must be named; never a default', () => {
  const r = applyHumanCaptain({ decision: 'verdict', text: 'Paris', actor: '' });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'not-signed-in');
});

test('the human captain may verdict, defer, or unknown, signed as themselves', () => {
  const answers = [
    { seatName: 'Claude', ok: true, text: 'Paris' },
    { seatName: 'Gemini', ok: true, text: 'Lyon' },
  ];
  const v = applyHumanCaptain({ decision: 'verdict', text: 'Paris', actor: 'Ada' });
  assert.equal(v.ok, true);
  assert.equal(v.decision, 'verdict');
  assert.equal(v.actor, 'Ada');
  assert.equal(v.source, 'human');

  const d = applyHumanCaptain({ decision: 'defer', seat: 'Claude', answers, actor: 'Ada' });
  assert.equal(d.decision, 'defer');
  assert.equal(d.text, 'Paris');
  assert.equal(d.seat, 'Claude');

  const u = applyHumanCaptain({ decision: 'unknown', reason: 'they disagree', actor: 'Ada' });
  assert.equal(u.decision, 'unknown');
  assert.equal(u.reason, 'they disagree');
});
