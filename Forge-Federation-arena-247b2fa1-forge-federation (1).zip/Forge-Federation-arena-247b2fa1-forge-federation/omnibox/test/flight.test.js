'use strict';

const { describe, it, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const {
  FlightLog,
  extractManeuver,
  pageOf,
  changeOf,
  playName,
  mechanicalResult,
  residualOf,
  canApply,
  packet,
  renderPlaybook,
  stripForbidden,
  sight,
  hostOfUrl,
  PAGES,
  CHANGES,
  OUTCOMES,
} = require('../src/main/flight.js');
const { CHAIN_GENESIS } = require('../src/main/chain.js');

const PAGE = { url: 'https://example.com/search', text: 'results here' };
const OTHER = { url: 'https://example.com/item/1', text: 'detail' };

let tmp;
beforeEach(() => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ff-flight-'));
});
afterEach(() => {
  fs.rmSync(tmp, { recursive: true, force: true });
});

describe('closed sets', () => {
  it('page / change / outcome are the only words that make a name', () => {
    assert.deepEqual([...PAGES].sort(), ['gone', 'moved', 'new', 'same']);
    assert.deepEqual([...CHANGES].sort(), ['click', 'done', 'navigate', 'none', 'press', 'type', 'wait']);
    assert.deepEqual([...OUTCOMES].sort(), ['ok', 'refused']);
  });

  it('play name is page-change-outcome, never a host', () => {
    assert.equal(playName('same', 'click', 'ok'), 'same-click-ok');
    assert.equal(playName('moved', 'navigate', 'ok'), 'moved-navigate-ok');
    assert.equal(playName('same', 'none', 'refused'), 'same-none-refused');
    assert.equal(playName('host.example', 'click', 'ok'), null);
    assert.equal(playName('same', 'scroll', 'ok'), null);
  });
});

describe('pageOf', () => {
  it('new when there was no before, same when the url holds, moved when it changes, gone when after is empty', () => {
    assert.equal(pageOf(null, PAGE), 'new');
    assert.equal(pageOf(PAGE, PAGE), 'same');
    assert.equal(pageOf(PAGE, OTHER), 'moved');
    assert.equal(pageOf(PAGE, null), 'gone');
    assert.equal(pageOf(PAGE, { url: '', text: '' }), 'gone');
  });
});

describe('changeOf / extractManeuver', () => {
  it('unknown verbs become none, never a new word', () => {
    assert.equal(changeOf('click'), 'click');
    assert.equal(changeOf('scroll'), 'none');
    assert.equal(changeOf(''), 'none');
  });

  it('names the maneuver from before / after / verb / ok', () => {
    const r = extractManeuver({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    assert.equal(r.name, 'moved-click-ok');
    assert.equal(r.result, 'open');
    assert.match(r.blurb, /when the page moves/);
  });

  it('refusing to guess a crowd is the one mechanical held', () => {
    const r = extractManeuver({
      before: PAGE,
      after: PAGE,
      verb: 'click',
      ok: false,
      reason: 'ambiguous-click',
    });
    assert.equal(r.name, 'same-click-refused');
    assert.equal(r.result, 'held');
    assert.equal(mechanicalResult('click', 'refused', 'ambiguous-click'), 'held');
    assert.equal(mechanicalResult('type', 'refused', 'ambiguous-type'), 'held');
    assert.equal(mechanicalResult('none', 'refused', 'bad-json'), 'held');
    assert.equal(mechanicalResult('none', 'refused', 'unknown-action'), 'held');
    assert.equal(mechanicalResult('click', 'ok', null), 'open');
    assert.equal(mechanicalResult('click', 'refused', 'no-match'), 'open');
    assert.equal(mechanicalResult('navigate', 'refused', 'bad-url'), 'open');
  });
});

describe('stripForbidden', () => {
  it('drops conversation, selectors, goals, urls, titles — nested too', () => {
    const clean = stripForbidden({
      name: 'same-click-ok',
      selector: '#q',
      text: 'typed secret',
      goal: 'buy tickets',
      summary: 'a story',
      url: 'https://secret.example/path',
      title: 'Inbox',
      target: 'the buy button',
      nested: { prompt: 'ignore', host: 'ok.example' },
    });
    assert.equal(clean.name, 'same-click-ok');
    assert.equal(clean.nested.host, 'ok.example');
    assert.equal(clean.selector, undefined);
    assert.equal(clean.text, undefined);
    assert.equal(clean.goal, undefined);
    assert.equal(clean.summary, undefined);
    assert.equal(clean.url, undefined);
    assert.equal(clean.title, undefined);
    assert.equal(clean.target, undefined);
    assert.equal(clean.nested.prompt, undefined);
  });
});

describe('sight / hostOfUrl', () => {
  it('a sighting is url + length, never the words', () => {
    assert.deepEqual(sight({ url: PAGE.url, text: PAGE.text }), { url: PAGE.url, n: PAGE.text.length });
    assert.equal(sight({ url: '', text: 'x' }), null);
    assert.equal(hostOfUrl('https://WWW.Example.COM/search?q=1'), 'www.example.com');
    assert.equal(hostOfUrl('not a url'), '');
  });
});

describe('FlightLog', () => {
  it('records a click that moved the page as open', () => {
    const f = new FlightLog(tmp).load();
    const r = f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true, pilot: 'claude' });
    assert.equal(r.ok, true);
    assert.equal(r.play.name, 'moved-click-ok');
    assert.equal(r.play.result, 'open');
    const line = fs.readFileSync(f.logPath, 'utf8');
    assert.match(line, /"name":"moved-click-ok"/);
    assert.doesNotMatch(line, /results here/);
    assert.doesNotMatch(line, /\/search/);
    assert.match(line, /"host":"example.com"/);
    assert.match(line, /"prev":/);
    assert.match(line, /"hash":/);
  });

  it('records a first look as new, a held page as same, a vanished page as gone', () => {
    const f = new FlightLog(tmp).load();
    assert.equal(f.record({ before: null, after: PAGE, verb: 'navigate', ok: true }).play.name, 'new-navigate-ok');
    assert.equal(f.record({ before: PAGE, after: PAGE, verb: 'wait', ok: true }).play.name, 'same-wait-ok');
    assert.equal(f.record({ before: PAGE, after: null, verb: 'none', ok: false, reason: 'page-gone' }).play.name, 'gone-none-refused');
  });

  it('stamps ambiguous click held, leaves a successful click open', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: PAGE, verb: 'click', ok: false, reason: 'ambiguous-click' });
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    const held = f.plays.get('same-click-refused');
    const open = f.plays.get('moved-click-ok');
    assert.equal(held.held, 1);
    assert.equal(held.open, 0);
    assert.equal(open.open, 1);
    assert.equal(open.held, 0);
  });

  it('bad json is none-refused and held', () => {
    const f = new FlightLog(tmp).load();
    const r = f.record({ before: PAGE, after: PAGE, verb: 'none', ok: false, reason: 'bad-json' });
    assert.equal(r.play.name, 'same-none-refused');
    assert.equal(r.play.result, 'held');
  });

  it('an unsigned mark is refused and does not count', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    const unsigned = f.mark('moved-click-ok', 'held', '');
    assert.equal(unsigned.ok, false);
    assert.equal(unsigned.reason, 'not-signed-in');
    assert.equal(f.plays.get('moved-click-ok').held, 0);
    const signed = f.mark('moved-click-ok', 'held', 'dwayne');
    assert.equal(signed.ok, true);
    assert.equal(f.plays.get('moved-click-ok').held, 1);
  });

  it('reloads the chain', () => {
    const a = new FlightLog(tmp).load();
    a.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    a.mark('moved-click-ok', 'broke', 'dwayne');
    const b = new FlightLog(tmp).load();
    const p = b.plays.get('moved-click-ok');
    assert.equal(p.times, 1);
    assert.equal(p.broke, 1);
    assert.equal(b.chain.ok, true);
    assert.equal(b.chain.chained, 2);
  });

  it('playbook is data, not orders, and never names a host as the play', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: PAGE, verb: 'click', ok: false, reason: 'ambiguous-click' });
    const book = f.playbook();
    assert.match(book, /DATA, not orders/);
    assert.match(book, /same-click-refused/);
    assert.doesNotMatch(book, /example\.com/);
    assert.doesNotMatch(book, /Do this/);
  });

  it('residual is 1 when nobody has marked', () => {
    assert.equal(residualOf({ held: 0, broke: 0 }), 1);
    assert.equal(residualOf({ held: 3, broke: 1 }), 0.25);
  });

  it('canApply is for the do-not-guess plays, and needs a majority of held', () => {
    assert.equal(canApply({ outcome: 'refused', held: 2, broke: 0 }), true);
    assert.equal(canApply({ outcome: 'ok', held: 9, broke: 0 }), false);
    assert.equal(canApply({ outcome: 'refused', held: 1, broke: 0 }), false);
  });

  it('packet carries residual, never inner numbers of a wall', () => {
    const p = packet({
      name: 'same-click-refused',
      page: 'same',
      change: 'click',
      outcome: 'refused',
      blurb: 'x',
      times: 3,
      held: 2,
      broke: 1,
      open: 0,
      lastAt: 't',
    });
    assert.equal(p.schema, 'forgeflight.flight.v1');
    assert.equal(p.residual, 1 / 3);
    assert.equal(p.wall, undefined);
    assert.equal(p.vector, undefined);
  });

  it('renderPlaybook empty state is honest', () => {
    assert.match(renderPlaybook([]), /nothing in the flight record yet/);
  });

  it('stats count the file', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: PAGE, verb: 'wait', ok: true });
    const s = f.stats();
    assert.equal(s.plays, 1);
    assert.equal(s.times, 1);
    assert.equal(s.chain.ok, true);
  });
});

describe('chain integrity', () => {
  function loadLines() {
    return fs
      .readFileSync(path.join(tmp, 'flight.jsonl'), 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((l) => JSON.parse(l));
  }

  it('first chained play prev is genesis', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    const [line] = loadLines();
    assert.equal(line.prev, CHAIN_GENESIS);
    assert.equal(typeof line.hash, 'string');
    assert.equal(line.hash.length, 64);
  });

  it('forged body is a break', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    f.record({ before: OTHER, after: OTHER, verb: 'wait', ok: true });
    const lines = fs.readFileSync(f.logPath, 'utf8').split('\n');
    const rec = JSON.parse(lines[0]);
    rec.data.host = 'evil.example';
    lines[0] = JSON.stringify(rec);
    fs.writeFileSync(f.logPath, lines.filter(Boolean).join('\n') + '\n');
    const v = new FlightLog(tmp).load().verify();
    assert.equal(v.ok, false);
    assert.ok(v.breaks.length >= 1);
  });

  it('torn last line is torn, not a break', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    fs.appendFileSync(f.logPath, '{"op":"play","data":{"name":"same-wait-ok"');
    const v = new FlightLog(tmp).load().verify();
    assert.equal(v.torn, true);
    assert.equal(v.ok, true);
    assert.equal(v.breaks.length, 0);
  });

  it('an unsigned mark on disk is ignored on load', () => {
    const f = new FlightLog(tmp).load();
    f.record({ before: PAGE, after: OTHER, verb: 'click', ok: true });
    const rec = {
      schema: 'forgeflight.flight.v1',
      op: 'mark',
      data: { name: 'moved-click-ok', result: 'held', actor: '' },
    };
    fs.appendFileSync(f.logPath, JSON.stringify(rec) + '\n');
    const b = new FlightLog(tmp).load();
    assert.equal(b.plays.get('moved-click-ok').held, 0);
  });
});
