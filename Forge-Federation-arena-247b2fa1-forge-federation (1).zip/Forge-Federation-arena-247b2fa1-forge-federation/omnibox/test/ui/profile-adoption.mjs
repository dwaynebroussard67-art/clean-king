/**
 * profile-adoption.mjs — the D26 rename migration, against a REAL browser.
 *
 * `test/rename.test.js` exercises `adoptLegacyProfile()` against directories
 * this repository furnished itself: files with the right names and plausible
 * bytes. Those 11 checks cover the policy — never overwrite, never adopt
 * twice, never throw, leave a note — and they are the right tests for that.
 *
 * What they cannot cover is the only question a user actually asks: *am I
 * still signed in?* A migration can satisfy every policy rule and still lose
 * a session, because "the files moved" and "Chromium can still read the jar"
 * are different claims. The second one needs a browser.
 *
 * So this runner does the end-to-end thing:
 *
 *   1. launch a real Chromium against a profile directory named `omnibox`;
 *   2. have a real origin set a real cookie and real localStorage in it;
 *   3. shut it down cleanly, so the jar is flushed and the lock released;
 *   4. run adoptLegacyProfile() into the `forgeflight` directory;
 *   5. launch a real Chromium against THAT directory and confirm the cookie
 *      and localStorage are still there — i.e. the login survived the rename.
 *
 * Plus the failure modes that only exist with real profiles on disk: a
 * populated destination must never be clobbered, a second run must be a
 * no-op, and — the case a move-based migration has to get right — the
 * `Default/` subdirectory a real Chromium actually writes its session into
 * must arrive intact, not flattened or half-copied.
 *
 * This is a regression sentinel, not a proof of a bug. The migration is
 * known to work; this is what stops it quietly breaking when someone edits
 * profile.js or Chromium changes its on-disk layout.
 *
 *   node test/ui/profile-adoption.mjs
 *   FORGEFLIGHT_CHROMIUM=/path/to/chrome node test/ui/profile-adoption.mjs
 */

import { chromium } from 'playwright-core';
import { createServer } from 'node:http';
import { mkdtempSync, mkdirSync, existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { createRequire } from 'node:module';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const require = createRequire(import.meta.url);
const { adoptLegacyProfile, NOTE } = require(resolve(root, 'src/main/profile.js'));

function chromiumPath() {
  if (process.env.FORGEFLIGHT_CHROMIUM) return process.env.FORGEFLIGHT_CHROMIUM;
  if (process.env.OMNIBOX_CHROMIUM) return process.env.OMNIBOX_CHROMIUM;
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers';
  if (!existsSync(base)) return undefined;
  const dir = readdirSync(base).find((d) => /^chromium-\d+$/.test(d));
  if (!dir) return undefined;
  for (const p of [join(base, dir, 'chrome-linux', 'chrome'), join(base, dir, 'chrome-linux', 'headless_shell')]) {
    if (existsSync(p)) return p;
  }
  return undefined;
}

let passed = 0;
let failed = 0;
const failures = [];
const check = (name, cond, detail) => {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
};

/** A tiny origin to hold a session against. A cookie needs a real site. */
function serve(port) {
  return new Promise((res) => {
    const s = createServer((req, rep) => {
      rep.writeHead(200, {
        'content-type': 'text/html; charset=utf-8',
        // The shape a provider's session cookie actually has.
        'set-cookie': 'ff_session=abc123-session-token; Path=/; Max-Age=86400; SameSite=Lax',
      });
      rep.end('<!doctype html><title>provider</title><h1>signed in</h1>');
    });
    s.listen(port, '127.0.0.1', () => res(s));
  });
}

const exe = chromiumPath();
const launch = (dir) =>
  chromium.launchPersistentContext(dir, { executablePath: exe, args: ['--no-sandbox'], headless: true });

/** A real Chromium may keep the jar in the profile root or under Default/. */
const jarSomewhere = (dir) =>
  ['', 'Default'].some((r) => ['Cookies', join('Network', 'Cookies')].some((n) => existsSync(join(dir, r, n))));

async function main() {
  console.log(`\nForge Flight — D26 profile adoption against a real browser (chromium: ${exe || 'bundled'})\n`);

  const PORT = 39517;
  const ORIGIN = `http://127.0.0.1:${PORT}/`;
  const server = await serve(PORT);

  const appData = mkdtempSync(join(tmpdir(), 'ff-adopt-'));
  const legacy = join(appData, 'omnibox');
  const next = join(appData, 'forgeflight');
  mkdirSync(legacy, { recursive: true });

  // ------------------------------------------------ 1. build a real session
  console.log('signing in, in a real browser, under the OLD product name');
  {
    const ctx = await launch(legacy);
    const page = await ctx.newPage();
    await page.goto(ORIGIN);
    await page.evaluate(() => localStorage.setItem('ff_profile_marker', 'the-user-was-here'));
    const cookies = await ctx.cookies(ORIGIN);
    check(
      'the old profile really holds a session cookie',
      cookies.some((c) => c.name === 'ff_session' && c.value === 'abc123-session-token'),
      JSON.stringify(cookies.map((c) => c.name))
    );
    await ctx.close(); // clean shutdown: jar flushed, lock released
  }

  check('the old profile has a cookie jar on disk', jarSomewhere(legacy), readdirSync(legacy).join(','));
  check(
    'and Chromium wrote it under Default/, the layout a real profile has',
    existsSync(join(legacy, 'Default')),
    readdirSync(legacy).join(',')
  );

  // -------------------------------------------------------- 2. adopt it
  console.log('\nrenaming: adopting that profile into the Forge Flight directory');
  const r = adoptLegacyProfile(next);
  check('adoption ran and reported a move', r.action === 'moved', `${r.action}: ${r.detail}`);
  check('the new profile now has the cookie jar', jarSomewhere(next), existsSync(next) ? readdirSync(next).join(',') : '(absent)');
  check(
    'the Default/ subdirectory arrived intact, not flattened',
    existsSync(join(next, 'Default')) && jarSomewhere(next),
    existsSync(next) ? readdirSync(next).join(',') : '(absent)'
  );
  check('a note was left where the old profile used to be', existsSync(join(legacy, NOTE)));
  check(
    'and the note names Forge Flight, so the empty folder explains itself',
    existsSync(join(legacy, NOTE)) && /Forge Flight/.test(readFileSync(join(legacy, NOTE), 'utf8'))
  );
  check(
    'a move leaves nothing behind but the note — no second copy of the cookie jar',
    readdirSync(legacy).length === 1 && !jarSomewhere(legacy),
    readdirSync(legacy).join(',')
  );

  // ------------------------------------- 3. the actual question: still signed in?
  console.log('\nlaunching Forge Flight against the adopted profile');
  {
    const ctx = await launch(next);
    const cookies = await ctx.cookies(ORIGIN);
    const session = cookies.find((c) => c.name === 'ff_session');
    check(
      'THE LOGIN SURVIVED THE RENAME — the session cookie is in the new profile',
      !!session && session.value === 'abc123-session-token',
      JSON.stringify(cookies.map((c) => `${c.name}=${c.value}`))
    );

    const page = await ctx.newPage();
    await page.goto(ORIGIN);
    const marker = await page.evaluate(() => localStorage.getItem('ff_profile_marker'));
    check('localStorage came across too — a session is more than a cookie', marker === 'the-user-was-here', String(marker));

    // What a provider sees: the cookie is presented on the next request.
    const sent = await page.evaluate(() => document.cookie);
    check('the adopted cookie is actually presented to the site', /ff_session=abc123-session-token/.test(sent), sent);
    await ctx.close();
  }

  // ------------------------------------------------ 4. it never runs twice
  console.log('\na second launch must not adopt again');
  {
    const again = adoptLegacyProfile(next);
    check('the second run is a no-op', again.action === 'kept', `${again.action}: ${again.detail}`);

    const ctx = await launch(next);
    const cookies = await ctx.cookies(ORIGIN);
    check(
      'the session is still intact after that refusal',
      cookies.some((c) => c.name === 'ff_session'),
      JSON.stringify(cookies.map((c) => c.name))
    );
    await ctx.close();
  }

  // --------------------------------- 5. a populated profile is never clobbered
  console.log('\na Forge Flight profile that has already been used is never written over');
  {
    const appData2 = mkdtempSync(join(tmpdir(), 'ff-adopt2-'));
    const oldDir = join(appData2, 'omnibox');
    const newDir = join(appData2, 'forgeflight');

    for (const [dir, token] of [[oldDir, 'OLD-TOKEN'], [newDir, 'NEW-TOKEN']]) {
      mkdirSync(dir, { recursive: true });
      const ctx = await launch(dir);
      const page = await ctx.newPage();
      await page.goto(ORIGIN);
      await page.evaluate((t) => localStorage.setItem('which', t), token);
      await ctx.close();
    }

    const res = adoptLegacyProfile(newDir);
    check('adoption keeps the profile that is already in use', res.action === 'kept', `${res.action}: ${res.detail}`);
    check('and the old profile is left exactly where it was', jarSomewhere(oldDir));
    check('no note claims a move that did not happen', !existsSync(join(oldDir, NOTE)));

    const ctx = await launch(newDir);
    const page = await ctx.newPage();
    await page.goto(ORIGIN);
    const which = await page.evaluate(() => localStorage.getItem('which'));
    check('the newer session is intact — nothing was clobbered', which === 'NEW-TOKEN', String(which));
    await ctx.close();
  }

  // ------------------------------------------- 6. a failed adoption is survivable
  //
  // D26 promises adoption never throws: a failure starts a fresh profile,
  // leaves the old one untouched, and tries again next launch. A read-only
  // parent is the cheapest way to actually provoke that rather than assume it.
  console.log('\na migration that cannot complete leaves the old profile alone');
  {
    const appData3 = mkdtempSync(join(tmpdir(), 'ff-adopt3-'));
    const oldDir = join(appData3, 'omnibox');
    mkdirSync(oldDir, { recursive: true });
    const ctx = await launch(oldDir);
    const page = await ctx.newPage();
    await page.goto(ORIGIN);
    await ctx.close();

    let threw = false;
    let res;
    try {
      // A destination path that cannot be created: a file sits where the
      // directory must go.
      const blocked = join(appData3, 'forgeflight');
      writeFileSync(blocked, 'not a directory');
      res = adoptLegacyProfile(blocked);
    } catch {
      threw = true;
    }
    check('adoption did not throw', !threw);
    check('it reported a result rather than crashing', !!res && typeof res.action === 'string', JSON.stringify(res));
    check('the old profile still has its jar, so the next launch can retry', jarSomewhere(oldDir));
  }

  server.close();
  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nfailures:');
    for (const f of failures) console.log(`  · ${f}`);
  }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
