/**
 * tie-boundary.mjs — real-Chromium verification of the ambiguous boundary.
 *
 * The detector's refusal is a product feature, and the case it exists for is
 * a TIE: two candidates the page gives no honest way to choose between. No
 * fixture in the suite manufactured one. `ambiguous-two-composers.html` is a
 * split view whose two boxes happen to land close together; the margin it
 * produces is a property of the layout, so a weight change could widen it
 * and quietly turn a refusal into a seat with every test still green.
 *
 * `true-tie-composers.html` is built to remove that accident: the two
 * candidates are identical on all ten structural signals by construction and
 * differ on exactly one, named by `?vary=`. That makes the margin a function
 * of a single weight, which is what lets these checks sit ON the MIN_MARGIN
 * boundary and know why they are there.
 *
 * Real layout, real getComputedStyle, real getBoundingClientRect — every
 * signal the detector reads is a layout fact, so a DOM shim here would be a
 * test of the shim.
 *
 *   node test/ui/tie-boundary.mjs
 *   OMNIBOX_CHROMIUM=/path/to/chrome node test/ui/tie-boundary.mjs
 */

import { chromium } from 'playwright-core';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const fixtures = resolve(root, 'test/fixtures');

function chromiumPath() {
  if (process.env.FORGEFLIGHT_CHROMIUM) return process.env.FORGEFLIGHT_CHROMIUM;
  if (process.env.OMNIBOX_CHROMIUM) return process.env.OMNIBOX_CHROMIUM;
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers';
  if (!existsSync(base)) return undefined;
  const dir = readdirSync(base).find((d) => /^chromium-\d+$/.test(d));
  if (!dir) return undefined;
  for (const p of [join(base, dir, 'chrome-linux', 'chrome'), join(base, dir, 'chrome-linux', 'headless_shell')]) {
    if (existsSync(p)) return p;
  }
  return undefined;
}

const SIGNALS = readFileSync(resolve(root, 'src/detector/signals.js'), 'utf8');
const STAMP = readFileSync(resolve(root, 'src/detector/stamp.js'), 'utf8');
const DETECT = readFileSync(resolve(root, 'src/detector/detect.js'), 'utf8');

const cjsShim = (src, name) =>
  `(() => { const module = { exports: {} }; const exports = module.exports;
    const require = (id) => id.includes('signals') ? globalThis.__FORGEFLIGHT_SIGNALS__
      : id.includes('stamp') ? globalThis.__FORGEFLIGHT_STAMP__ : globalThis.__FORGEFLIGHT_DETECT__;
    ${src}
    globalThis[${JSON.stringify(name)}] = module.exports; })();`;

let passed = 0;
let failed = 0;
const failures = [];
const check = (name, cond, detail) => {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
};

async function verdictFor(browser, vary) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.addInitScript({ content: cjsShim(SIGNALS, '__FORGEFLIGHT_SIGNALS__') });
  await page.addInitScript({ content: cjsShim(STAMP, '__FORGEFLIGHT_STAMP__') });
  await page.addInitScript({ content: cjsShim(DETECT, '__FORGEFLIGHT_DETECT__') });
  const url = `${pathToFileURL(resolve(fixtures, 'true-tie-composers.html')).href}?vary=${vary}`;
  await page.goto(url);
  await page.waitForTimeout(120);
  const v = await page.evaluate(() => {
    const D = globalThis.__FORGEFLIGHT_DETECT__;
    const V = D.detectComposer(document);
    const id = (el) => (el ? el.id || el.tagName.toLowerCase() : null);
    // The scored candidate list, so a tie can be verified signal by signal
    // rather than inferred from the verdict.
    return {
      ok: V.ok,
      reason: V.reason || null,
      margin: V.margin ?? null,
      tiedOn: V.tiedOn || [],
      confidence: V.confidence ?? null,
      composer: id(V.composer),
      candidates: (V.candidates || []).map((c) => ({ id: c.id || '', score: c.score, signals: c.signals })),
      minMargin: D.CONFIG.MIN_MARGIN,
      minScore: D.CONFIG.MIN_SCORE,
    };
  });
  await page.close();
  return v;
}

const SIGNAL_NAMES = [
  'askIntent',
  'anchored',
  'viewportBottom',
  'area',
  'sendAffinity',
  'centrality',
  'multiline',
  'notChrome',
  'notSearch',
  'notDocument',
];

async function main() {
  const exe = chromiumPath();
  const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
  console.log(`\nForge Flight — ambiguous-boundary verification (chromium: ${exe || 'bundled'})\n`);

  // ------------------------------------------------------------- the pure tie
  console.log('a true tie: two candidates identical on all ten signals');
  {
    const v = await verdictFor(browser, 'none');

    check('the detector refuses rather than picking one', v.ok === false, JSON.stringify(v).slice(0, 200));
    check('and it refuses by the right name', v.reason === 'ambiguous', v.reason);
    check('two candidates were actually scored', v.candidates.length >= 2, String(v.candidates.length));

    const [a, b] = v.candidates;
    check(
      'both candidates cleared the score floor — this is a tie, not two rejects',
      a && b && a.score >= v.minScore && b.score >= v.minScore,
      `${a && a.score} / ${b && b.score} floor ${v.minScore}`
    );

    const differing = SIGNAL_NAMES.filter((k) => Math.abs((a.signals[k] ?? 0) - (b.signals[k] ?? 0)) >= 0.05);
    check(
      'the fixture really does tie on every one of the ten signals',
      differing.length === 0,
      `differ on: ${differing.map((k) => `${k} ${a.signals[k]}/${b.signals[k]}`).join(', ')}`
    );
    check('the margin is at or near zero', v.margin !== null && v.margin < 0.01, String(v.margin));
    check(
      'the refusal names all ten tied signals, so a person can see why',
      SIGNAL_NAMES.every((k) => v.tiedOn.includes(k)),
      `tiedOn: ${v.tiedOn.join(', ')}`
    );
  }

  // -------------------------------------------- one signal at a time, on the boundary
  //
  // Each of these differs from the pure tie by exactly one signal. Whether a
  // single signal is enough to break the tie is a *deliberate* property of
  // that signal's weight; the check is not "it must seat" or "it must
  // refuse", it is "the verdict is one of the two named outcomes and the
  // margin is consistent with it". A detector that silently started guessing
  // would fail this, and so would one whose margin stopped matching its own
  // verdict.
  console.log('\none signal apart: the boundary, signal by signal');
  for (const vary of ['askIntent', 'notDocument', 'notSearch', 'sendAffinity', 'multiline', 'notChrome', 'area']) {
    const v = await verdictFor(browser, vary);
    const seated = v.ok === true;
    const refused = v.ok === false && v.reason === 'ambiguous';
    const droppedOne = v.ok === true || (v.candidates && v.candidates.length >= 1);

    check(
      `vary=${vary}: the verdict is a seat or a named refusal, never a silent guess`,
      seated || refused || ['document-field', 'below-floor'].includes(v.reason),
      `${v.ok} ${v.reason} margin=${v.margin}`
    );
    check(
      `vary=${vary}: the margin agrees with the verdict`,
      seated ? v.margin >= v.minMargin : refused ? v.margin < v.minMargin : true,
      `margin ${v.margin} vs floor ${v.minMargin} (ok=${v.ok})`
    );
    if (seated) {
      check(
        `vary=${vary}: the surviving candidate is the untouched one`,
        v.composer === 'left',
        `seated #${v.composer}`
      );
    }
    check(`vary=${vary}: ${droppedOne ? 'candidates were reported' : 'no candidates'}`, droppedOne);
  }

  // -------------------------------------------------- refusal is not fragile
  console.log('\nrefusal holds under a viewport the page did not expect');
  {
    const page = await browser.newPage({ viewport: { width: 620, height: 900 } });
    await page.addInitScript({ content: cjsShim(SIGNALS, '__FORGEFLIGHT_SIGNALS__') });
    await page.addInitScript({ content: cjsShim(STAMP, '__FORGEFLIGHT_STAMP__') });
    await page.addInitScript({ content: cjsShim(DETECT, '__FORGEFLIGHT_DETECT__') });
    await page.goto(`${pathToFileURL(resolve(fixtures, 'true-tie-composers.html')).href}?vary=none`);
    await page.waitForTimeout(120);
    const v = await page.evaluate(() => {
      const V = globalThis.__FORGEFLIGHT_DETECT__.detectComposer(document);
      return { ok: V.ok, reason: V.reason || null };
    });
    check('a narrow window does not turn a tie into a seat', v.ok === false, `${v.ok} ${v.reason}`);
    await page.close();
  }

  await browser.close();

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nfailures:');
    for (const f of failures) console.log(`  · ${f}`);
  }
  process.exit(failed ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
