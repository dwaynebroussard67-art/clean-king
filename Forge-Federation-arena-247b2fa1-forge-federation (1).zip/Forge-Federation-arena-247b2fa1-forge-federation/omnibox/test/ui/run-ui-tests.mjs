/**
 * run-ui-tests.mjs — real-Chromium verification of the seat detector.
 *
 * These are not DOM-shim tests. Every fixture is loaded in a real browser
 * with real layout, real getComputedStyle, and real getBoundingClientRect,
 * because every signal the detector uses is a layout fact. A jsdom pass here
 * would be a test of jsdom.
 */

import { chromium } from 'playwright-core';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const fixtures = resolve(root, 'test/fixtures');

function chromiumPath() {
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers';
  if (!existsSync(base)) return undefined;
  const dir = readdirSync(base).find((d) => /^chromium-\d+$/.test(d));
  if (!dir) return undefined;
  for (const p of [join(base, dir, 'chrome-linux', 'chrome'), join(base, dir, 'chrome-linux', 'headless_shell')]) {
    if (existsSync(p)) return p;
  }
  return undefined;
}

const SIGNALS_SRC = readFileSync(resolve(root, 'src/detector/signals.js'), 'utf8');
const STAMP_SRC = readFileSync(resolve(root, 'src/detector/stamp.js'), 'utf8');
const DETECT_SRC = readFileSync(resolve(root, 'src/detector/detect.js'), 'utf8');
const INJECT_SRC = readFileSync(resolve(root, 'src/preload/inject.js'), 'utf8');
const WATCH_SRC = readFileSync(resolve(root, 'src/preload/watch.js'), 'utf8');

/** Evaluate a CommonJS-shaped source file inside the page and hang its
 *  exports off globalThis, mimicking how the preload requires it. */
function cjsShim(src, globalName) {
  return `(() => { const module = { exports: {} }; const exports = module.exports;
    const require = (id) => {
      if (id.includes('signals')) return globalThis.__FORGEFLIGHT_SIGNALS__;
      if (id.includes('stamp')) return globalThis.__FORGEFLIGHT_STAMP__;
      if (id.includes('detect'))  return globalThis.__FORGEFLIGHT_DETECT__;
      throw new Error('unexpected require: ' + id);
    };
    ${src}
    globalThis[${JSON.stringify(globalName)}] = module.exports;
  })();`;
}

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail) {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

async function newPage(browser, fixture) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  await page.addInitScript({ content: cjsShim(SIGNALS_SRC, '__FORGEFLIGHT_SIGNALS__') });
  await page.addInitScript({ content: cjsShim(STAMP_SRC, '__FORGEFLIGHT_STAMP__') });
  await page.addInitScript({ content: cjsShim(DETECT_SRC, '__FORGEFLIGHT_DETECT__') });
  await page.addInitScript({ content: cjsShim(INJECT_SRC, '__FORGEFLIGHT_INJECT__') });
  await page.addInitScript({ content: cjsShim(WATCH_SRC, '__FORGEFLIGHT_WATCH__') });
  await page.goto(pathToFileURL(resolve(fixtures, fixture)).href);
  return page;
}

const detect = (page) =>
  page.evaluate(() => {
    const v = globalThis.__FORGEFLIGHT_DETECT__.detectComposer(document);
    const describe = (el) =>
      el ? { tag: el.tagName.toLowerCase(), id: el.id, label: el.getAttribute('aria-label') || '' } : null;
    return { ...v, composer: describe(v.composer), send: describe(v.send) };
  });

async function main() {
  const exe = chromiumPath();
  const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox'] });
  console.log(`\nForge Flight UI verification (chromium: ${exe || 'bundled'})\n`);

  // ---------------------------------------------------------------- detector
  console.log('detector — seats a contenteditable chat');
  {
    const page = await newPage(browser, 'contenteditable-chat.html');
    const v = await detect(page);
    check('seats the page', v.ok === true, v.detail);
    check('picks the composer, not the nav link', v.composer?.id === 'cmp', JSON.stringify(v.composer));
    check('binds the send button', v.send?.id === 'send', JSON.stringify(v.send));
    check('records named signals', v.ok && Object.keys(v.signals).length === 10);
    check('confidence above the floor', v.ok && v.confidence >= 0.42, String(v.confidence));
    await page.close();
  }

  console.log('detector — seats a textarea chat inside a form');
  {
    const page = await newPage(browser, 'textarea-chat.html');
    const v = await detect(page);
    check('seats the page', v.ok === true, v.detail);
    check('picks the textarea', v.composer?.tag === 'textarea', JSON.stringify(v.composer));
    check('binds the submit button', v.send?.id === 'send', JSON.stringify(v.send));
    await page.close();
  }

  console.log('detector — refuses the search box, takes the composer');
  {
    const page = await newPage(browser, 'chat-with-search.html');
    const v = await detect(page);
    check('seats the page', v.ok === true, v.detail);
    check('composer wins over both search inputs', v.composer?.id === 'cmp', JSON.stringify(v.composer));
    await page.close();
  }

  console.log('detector — refuses a page with no chat surface');
  {
    const page = await newPage(browser, 'no-composer.html');
    const v = await detect(page);
    check('does not seat', v.ok === false, JSON.stringify(v));
    check('reason is a refusal, not a crash', ['no-candidates', 'below-floor'].includes(v.reason), v.reason);
    check('refusal carries a human detail', typeof v.detail === 'string' && v.detail.length > 20);
    await page.close();
  }

  console.log('detector — refuses two identical composers rather than guessing');
  {
    const page = await newPage(browser, 'ambiguous-two-composers.html');
    const v = await detect(page);
    check('does not seat', v.ok === false, JSON.stringify(v).slice(0, 200));
    check('reason is ambiguous', v.reason === 'ambiguous', v.reason);
    check('names the tied signals', Array.isArray(v.tiedOn) && v.tiedOn.length > 0, JSON.stringify(v.tiedOn));
    check('lists the candidates for manual pick', Array.isArray(v.candidates) && v.candidates.length >= 2);
    await page.close();
  }

  console.log('detector — a comment box on an article is not a chat surface');
  {
    const page = await newPage(browser, 'comment-box-decoy.html');
    const v = await detect(page);
    check('refuses outright', v.ok === false, JSON.stringify({ ok: v.ok, c: v.confidence }));
    check('names it a document field, not a low score', v.reason === 'document-field', v.reason);
    check('says so in words a person can act on', /scroll away with the document/.test(v.detail || ''), v.detail);
    await page.close();
  }

  console.log('detector — pierces an open shadow root');
  {
    const page = await newPage(browser, 'shadow-dom-chat.html');
    const v = await detect(page);
    check('seats a composer inside a web component', v.ok === true, v.detail);
    check('picks the shadow composer', v.composer?.id === 'cmp', JSON.stringify(v.composer));
    check('binds the shadow send button', v.send?.id === 'send', JSON.stringify(v.send));
    check('anchoring still resolves across the shadow boundary', v.ok && v.signals.anchored === 1, JSON.stringify(v.signals));
    await page.close();
  }

  console.log('detector — a command palette does not steal the seat');
  {
    const page = await newPage(browser, 'command-palette-chat.html');
    const v = await detect(page);
    check('seats the page', v.ok === true, v.detail);
    check('picks the composer, not the focused palette input', v.composer?.id === 'cmp', JSON.stringify(v.composer));
    await page.close();
  }

  console.log('detector — finds a composer that only appears after hydration');
  {
    const page = await newPage(browser, 'late-hydration-chat.html');
    const early = await detect(page);
    check('honestly reports nothing at first paint', early.ok === false, JSON.stringify(early.reason));
    await page.waitForTimeout(4200);
    const late = await detect(page);
    check('seats once the app hydrates', late.ok === true, late.detail);
    check('picks the hydrated composer', late.composer?.id === 'cmp', JSON.stringify(late.composer));
    await page.close();
  }

  console.log('detector — a frame it may not read is named, not called "not a chat"');
  {
    // Loaded over file://, where Chromium gives every frame an opaque origin —
    // so this is a genuine cross-origin frame, not a mocked one.
    const page = await newPage(browser, 'iframe-host.html');
    await page.waitForTimeout(900);
    const v = await detect(page);
    check('does not seat', v.ok === false, JSON.stringify(v).slice(0, 140));
    check('names the frame as the reason', v.reason === 'cross-origin-frame', v.reason);
    check('and tells you what to do about it', /own tab/.test(v.detail || ''), v.detail);
    await page.close();
  }

  // ------------------------------------------------------------------ inject
  console.log('inject — types into a contenteditable and verifies read-back');
  {
    const page = await newPage(browser, 'contenteditable-chat.html');
    const r = await page.evaluate(async () => {
      const v = globalThis.__FORGEFLIGHT_DETECT__.detectComposer(document);
      return globalThis.__FORGEFLIGHT_INJECT__.setComposerText(v.composer, 'hello from forgeflight');
    });
    check('reports success', r.ok === true, JSON.stringify(r));
    check('read-back matches exactly', r.readBack === 'hello from forgeflight', r.readBack);
    check('names the strategy that worked', typeof r.strategy === 'string' && r.strategy.length > 0, r.strategy);
    const enabled = await page.evaluate(() => !document.getElementById('send').disabled);
    check('page reacted (send button enabled)', enabled === true);
    await page.close();
  }

  console.log('inject — types into a React-style textarea');
  {
    const page = await newPage(browser, 'textarea-chat.html');
    const r = await page.evaluate(async () => {
      const v = globalThis.__FORGEFLIGHT_DETECT__.detectComposer(document);
      return globalThis.__FORGEFLIGHT_INJECT__.setComposerText(v.composer, 'line one\nline two');
    });
    check('reports success', r.ok === true, JSON.stringify(r));
    check('preserves newlines', r.readBack === 'line one\nline two', JSON.stringify(r.readBack));
    await page.close();
  }

  console.log('inject — refuses to send when read-back does not match');
  {
    const page = await newPage(browser, 'contenteditable-chat.html');
    const r = await page.evaluate(async () => {
      // A composer that silently drops everything typed into it.
      const el = document.createElement('div');
      el.setAttribute('contenteditable', 'true');
      Object.defineProperty(el, 'textContent', { get: () => '', set: () => {}, configurable: true });
      Object.defineProperty(el, 'innerText', { get: () => '', set: () => {}, configurable: true });
      document.body.appendChild(el);
      return globalThis.__FORGEFLIGHT_INJECT__.setComposerText(el, 'this will never land');
    });
    check('refuses rather than sending blind', r.ok === false, JSON.stringify(r));
    check('reason is read-back mismatch', r.reason === 'readback-mismatch', r.reason);
    await page.close();
  }

  // ------------------------------------------------------------- end-to-end
  console.log('end-to-end — send a prompt and capture the streamed reply');
  for (const fixture of [
    'contenteditable-chat.html',
    'textarea-chat.html',
    'rerender-chat.html',
    'shadow-dom-chat.html',
    'virtualized-thread-chat.html',
  ]) {
    const page = await newPage(browser, fixture);
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      const chunks = [];
      const done = W.watchResponse(document, {
        onChunk: (t) => chunks.push(t),
        settleMs: 220,
        timeoutMs: 8000,
      });
      const typed = I.setComposerText(v.composer, 'ping');
      if (!typed.ok) return { error: typed };
      I.submit(v.composer, v.send);
      const final = await done;
      return { chunks: chunks.length, final: final.text, reason: final.reason };
    });
    check(`${fixture}: captured a reply`, !out.error && out.final && out.final.length > 10, JSON.stringify(out).slice(0, 220));
    check(`${fixture}: reply mentions the prompt`, !!out.final && /ping/.test(out.final), (out.final || '').slice(0, 80));
    check(`${fixture}: streamed in more than one chunk`, out.chunks > 1, String(out.chunks));
    check(`${fixture}: settled rather than timing out`, out.reason === 'settled', out.reason);
    check(
      `${fixture}: captured the reply, not an echo of the prompt`,
      !!out.final && !/^ping\b/.test(out.final.trim()),
      (out.final || '').slice(0, 60)
    );
    check(
      `${fixture}: captured the reply, not unrelated page churn`,
      !!out.final && !/history item/.test(out.final),
      (out.final || '').slice(0, 80)
    );
    await page.close();
  }

  // ------------------------------------------- real-provider failure modes
  // One fixture per capture failure in the passport export of 2026-08-27:
  // a sidebar title (claude.ai), an account menu (chatgpt.com), and a
  // mid-word slice of furniture text (gemini.google.com). None of these is
  // a reply; before the fix all three settled as "the answer".
  console.log('capture — the sidebar retitles the conversation, not the reply');
  {
    const page = await newPage(browser, 'sidebar-title-chat.html');
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      const done = W.watchResponse(document, { settleMs: 220, timeoutMs: 9000 });
      const typed = I.setComposerText(v.composer, 'do a deep dive on memory');
      if (!typed.ok) return { error: typed };
      I.submit(v.composer, v.send);
      const final = await done;
      return { final: final.text, reason: final.reason };
    });
    check('sidebar title: the reply was captured', !!out.final && /considered reply/.test(out.final), JSON.stringify(out).slice(0, 200));
    check('sidebar title: the title was not captured', !!out.final && !/improving memory/i.test(out.final), (out.final || '').slice(0, 80));
    check('sidebar title: settled, not timed out', out.reason === 'settled', out.reason);
    await page.close();
  }

  console.log('capture — an account menu opens over the chat, not the reply');
  {
    const page = await newPage(browser, 'account-menu-chat.html');
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      const done = W.watchResponse(document, { settleMs: 220, timeoutMs: 9000 });
      const typed = I.setComposerText(v.composer, 'do a deep dive on memory');
      if (!typed.ok) return { error: typed };
      I.submit(v.composer, v.send);
      const final = await done;
      return { final: final.text, reason: final.reason };
    });
    check('account menu: the reply was captured', !!out.final && /real answer/.test(out.final), JSON.stringify(out).slice(0, 200));
    check('account menu: the menu was not captured', !!out.final && !/manage api keys/i.test(out.final), (out.final || '').slice(0, 80));
    check('account menu: settled, not timed out', out.reason === 'settled', out.reason);
    await page.close();
  }

  console.log('capture — furniture that types itself mid-word is not the reply');
  {
    const page = await newPage(browser, 'ticker-fragment-chat.html');
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      const done = W.watchResponse(document, { settleMs: 220, timeoutMs: 9000 });
      const typed = I.setComposerText(v.composer, 'do a deep dive on memory');
      if (!typed.ok) return { error: typed };
      I.submit(v.composer, v.send);
      const final = await done;
      return { final: final.text, reason: final.reason };
    });
    check('mid-word ticker: the reply was captured', !!out.final && /genuine reply/.test(out.final), JSON.stringify(out).slice(0, 200));
    check('mid-word ticker: no mid-word slice was captured', !!out.final && !/ization/.test(out.final), (out.final || '').slice(0, 80));
    check('mid-word ticker: settled, not timed out', out.reason === 'settled', out.reason);
    await page.close();
  }

  console.log('capture — furniture-only growth refuses rather than poisons');
  {
    // Nothing on this page ever replies: the thread is torn out before the
    // fixture can stream into it, so the only growth is the account menu.
    // The honest outcome is empty + timeout (rendered by the seat as
    // empty-response), never the menu text.
    const page = await newPage(browser, 'account-menu-chat.html');
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      const done = W.watchResponse(document, { settleMs: 220, timeoutMs: 3200 });
      const typed = I.setComposerText(v.composer, 'hello');
      if (!typed.ok) return { error: typed };
      document.getElementById('thread').remove();
      I.submit(v.composer, v.send);
      const final = await done;
      return { final: final.text, reason: final.reason };
    });
    check('furniture-only: captured nothing', !out.final, JSON.stringify(out).slice(0, 200));
    await page.close();
  }

  // ------------------------------------------------ anchor stamps (the oracle)
  // Engine-training records are made of the winner, the losers, and the
  // structural stamp that joins Forge Flight's observations to the engine.
  console.log('stamps — every described candidate carries identity and a stability key');
  {
    const page = await newPage(browser, 'contenteditable-chat.html');
    const out = await page.evaluate(() => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const STAMP = globalThis.__FORGEFLIGHT_STAMP__;
      const v = D.detectComposer(document);
      const twice = STAMP.stampOf(v.composer);
      return {
        ok: v.ok,
        anchor: STAMP.stampOf(v.composer, { score: v.confidence }),
        sameKeyTwice: twice.stabilityKey === STAMP.stampOf(v.composer).stabilityKey,
        candidates: v.candidates,
        boxKeys: Object.keys(twice.box || {}),
      };
    });
    check('seats', out.ok === true);
    check('the anchor stamp carries identity fields', out.anchor.id === 'cmp' && out.anchor.editableKind === 'contenteditable' && !!out.anchor.path, JSON.stringify(out.anchor).slice(0, 140));
    check('the stamp carries a box but the stability key does not depend on it', out.boxKeys.includes('x') && out.boxKeys.includes('w'));
    check('stamping the same element twice is stable', out.sameKeyTwice === true);
    check('success verdicts now list every scored candidate, not only refusals', out.candidates.length >= 1 && !!out.candidates[0].stabilityKey && !!out.candidates[0].signals, JSON.stringify(out.candidates).slice(0, 140));
    await page.close();
  }

  console.log('stamps — a page where the runner-up is close enough to matter');
  {
    const page = await newPage(browser, 'close-runner-up.html');
    const out = await page.evaluate(() => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const v = D.detectComposer(document);
      return {
        ok: v.ok,
        margin: v.margin,
        winner: v.candidates[0],
        runner: v.candidates[1],
      };
    });
    check('the real composer wins', out.ok === true);
    check('by a real but narrow margin', out.margin >= 0.12 && out.margin < 0.35, String(out.margin));
    check('the runner-up is the draft panel, recorded with its own stamp', out.runner && out.runner.id === 'draft' && !!out.runner.stabilityKey, JSON.stringify(out.runner).slice(0, 140));
    check('winner and runner-up carry their signals for the record', out.winner.signals && out.runner.signals && 'anchored' in out.winner.signals && 'anchored' in out.runner.signals);
    await page.close();
  }

  console.log('stamps — a composer that moves between loads is a before/after pair');
  {
    const page = await newPage(browser, 'moving-composer.html');
    // Reset the visit counter, then reload so load 1 is deterministic.
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    const first = await page.evaluate(() => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const STAMP = globalThis.__FORGEFLIGHT_STAMP__;
      const v = D.detectComposer(document);
      return { ok: v.ok, key: STAMP.stampOf(v.composer).stabilityKey, path: STAMP.stampOf(v.composer).path };
    });
    await page.reload();
    const second = await page.evaluate(() => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const STAMP = globalThis.__FORGEFLIGHT_STAMP__;
      const v = D.detectComposer(document);
      return { ok: v.ok, key: STAMP.stampOf(v.composer).stabilityKey, path: STAMP.stampOf(v.composer).path };
    });
    check('the page seats on the first load', first.ok === true);
    check('and on the second load after the redesign', second.ok === true);
    check('the stability key changed — same URL, different anchor shape', first.key !== second.key, `${first.key} vs ${second.key}`);
    check('the structural path is what changed', first.path !== second.path, `${first.path} vs ${second.path}`);
    await page.evaluate(() => localStorage.clear());
    await page.close();
  }

  // ------------------------------------------------------- the local seat
  // forgeflight://local is a page like any other page: same detector, same
  // typing ladder, same watcher. Two things are pinned here — that a FAST
  // local model (first token well inside the 500ms reaction window, still
  // streaming past it) is captured rather than demoted as furniture, and
  // that with no local server the seat refuses honestly instead of
  // pretending.
  console.log('local seat — a fast local model is captured, not demoted');
  {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    await page.addInitScript({ content: cjsShim(SIGNALS_SRC, '__FORGEFLIGHT_SIGNALS__') });
    await page.addInitScript({ content: cjsShim(STAMP_SRC, '__FORGEFLIGHT_STAMP__') });
    await page.addInitScript({ content: cjsShim(DETECT_SRC, '__FORGEFLIGHT_DETECT__') });
    await page.addInitScript({ content: cjsShim(INJECT_SRC, '__FORGEFLIGHT_INJECT__') });
    await page.addInitScript({ content: cjsShim(WATCH_SRC, '__FORGEFLIGHT_WATCH__') });
    await page.addInitScript(() => {
      // A mock bridge that behaves like a local server: available, and
      // streaming its first token at ~150ms — faster than any remote
      // provider, well inside the watcher's reaction window.
      window.forgeflightLocal = {
        status: async () => ({ available: true, model: 'mock-local', endpoint: 'http://127.0.0.1:11434' }),
        generate: (prompt) =>
          new Promise((resolve) => {
            const words = 'The local seat answers quickly, beginning inside the reaction window and streaming on past it.'.split(' ');
            let i = 0;
            const iv = setInterval(() => {
              const tok = (i ? ' ' : '') + words[i];
              window.__localTok && window.__localTok(tok);
              if (++i >= words.length) {
                clearInterval(iv);
                resolve({ ok: true, text: words.join(' ') });
              }
            }, 45);
          }),
        onToken: (cb) => (window.__localTok = cb),
      };
    });
    await page.goto(pathToFileURL(resolve(root, 'src/renderer/local-seat.html')).href);
    await page.waitForTimeout(300); // let the page's status poll arm the send control
    const out = await page.evaluate(async () => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const W = globalThis.__FORGEFLIGHT_WATCH__;
      const v = D.detectComposer(document);
      if (!v.ok) return { seated: false };
      const done = W.watchResponse(document, { composer: v.composer, settleMs: 220, timeoutMs: 9000 });
      const typed = I.setComposerText(v.composer, 'hello local model');
      if (!typed.ok) return { seated: true, typed: false };
      I.submit(v.composer, v.send);
      const final = await done;
      return { seated: true, typed: true, text: final.text, reason: final.reason };
    });
    check('the local page seats structurally, like any other chat', out.seated === true);
    check('typing and read-back work on the local composer', out.typed === true, JSON.stringify(out).slice(0, 120));
    check('the fast local reply was captured', !!out.text && /local seat answers quickly/.test(out.text), JSON.stringify(out).slice(0, 160));
    check('it settled rather than timing out', out.reason === 'settled', out.reason);
    await page.close();
  }

  console.log('local seat — no local server is an honest refusal, never a faked answer');
  {
    const page = await newPage(browser, '../../src/renderer/local-seat.html');
    // (no forgeflightLocal mock: the page is outside Forge Flight, so there is no bridge)
    const out = await page.evaluate(() => {
      const D = globalThis.__FORGEFLIGHT_DETECT__;
      const I = globalThis.__FORGEFLIGHT_INJECT__;
      const v = D.detectComposer(document);
      if (!v.ok) return { seated: false };
      const typed = I.setComposerText(v.composer, 'anyone there?');
      const sent = typed.ok ? I.submit(v.composer, v.send) : null;
      return { seated: true, typed: typed.ok, sent };
    });
    check('the page still seats — the composer is real', out.seated === true);
    check('typing works', out.typed === true);
    check('send is refused by name while no server is available', out.sent && out.sent.ok === false && out.sent.reason === 'send-disabled', JSON.stringify(out.sent));
    await page.close();
  }

  await browser.close();

  console.log(`\n${passed} passed, ${failed} failed`);
  if (failed) {
    console.log('\nFailures:');
    for (const f of failures) console.log('  - ' + f);
    process.exit(1);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
