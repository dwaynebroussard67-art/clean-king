/**
 * tabs-mount.test.js — the real open() path, gated and released.
 *
 * test/gate.test.js pins the layout and refusal rules with stand-in tabs.
 * This file goes one level deeper and drives TabManager's ACTUAL open():
 * nothing is overridden. TabManager imports Electron lazily (only when a tab
 * is constructed), so a stub module is installed for `require('electron')`
 * before the first tab is opened — no Chromium, real code.
 *
 * What this proves is the mount rule at the one place it can be violated:
 * open() must refuse BEFORE constructing a WebContentsView (a constructed
 * view is added to the window and starts loading its URL — a 0x0 view still
 * touches the profile), and must construct exactly one view per opened tab
 * once the launch has signed in.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const Module = require('node:module');

// ------------------------------------------------------------------ stubs

const fakeWindow = () => {
  const stack = [];
  return {
    stack,
    contentView: {
      addChildView(v) {
        if (!stack.includes(v)) stack.push(v);
      },
      removeChildView(v) {
        const i = stack.indexOf(v);
        if (i !== -1) stack.splice(i, 1);
      },
    },
  };
};

class FakeWebContentsView {
  constructor() {
    this.bounds = null;
    this.visible = null;
    this.webContents = {
      id: 0,
      on() {},
      setWindowOpenHandler() {},
      loadURL() {
        return Promise.resolve();
      },
      close() {},
    };
  }
  setBackgroundColor() {}
  setBounds(b) {
    this.bounds = b;
  }
  setVisible(v) {
    this.visible = v;
  }
}

const fakeElectron = { WebContentsView: FakeWebContentsView };

const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return fakeElectron;
  return origLoad.apply(this, arguments);
};

// The hook is installed before the first open(); TabManager still loads
// Electron lazily, so requiring the module now is safe either way.
const { TabManager } = require('../src/main/tabs.js');

// ------------------------------------------------------------------ tests

test('the real open() constructs nothing while the launch is gated', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});

  assert.equal(mgr.open('https://a.example/'), null, 'open refuses');
  assert.equal(mgr.open('https://b.example/'), null, 'open refuses again');
  assert.equal(mgr.tabs.length, 0, 'no Tab objects exist');
  assert.equal(win.stack.length, 0, 'no WebContentsView was ever added to the window');
});

test('signing in arms the real open(): one view per tab, mounted and loadable', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  mgr.setSignedIn(true);

  const t = mgr.open('https://a.example/');
  assert.ok(t, 'open returns the tab once signed in');
  assert.equal(mgr.tabs.length, 1);
  assert.equal(win.stack.length, 1, 'exactly one view was added');
  assert.ok(win.stack[0] instanceof FakeWebContentsView);
  assert.equal(t.view, win.stack[0], 'the manager and the window agree on the view');
  assert.ok(t.view.bounds.width === 0, 'a new tab starts hidden until the chrome reports a hole');

  // The chrome reports the hole and the browse pane is showing: the active
  // tab gets exactly that box — never the 1200x600 default of the bug.
  const BOX = { x: 246, y: 96, width: 1000, height: 600 };
  mgr.setBounds(BOX);
  mgr.layout();
  assert.deepEqual(t.view.bounds, BOX, 'the view sits in the reported hole, nowhere else');
  assert.equal(t.view.visible, true);

  // A background tab joins; the next layout (a restore's activate, a resize,
  // anything) hands the unjudged newcomer the same hole to be measured in.
  const bg = mgr.open('https://b.example/', { background: true });
  assert.equal(mgr.tabs.length, 2);
  assert.equal(win.stack.length, 2);
  mgr.layout();
  assert.equal(bg.view.bounds.width, 1000, 'an unjudged background tab is measured under the active one');
  assert.ok(mgr.tabs.every((x) => x.view.bounds.width === BOX.width));
});

test('the real restore() opens nothing gated and everything signed in', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});

  const none = mgr.restore(['https://a.example/', 'https://b.example/'], { activeUrl: 'https://a.example/' });
  assert.deepEqual(none, [], 'restore before sign-in brings nothing back');
  assert.equal(win.stack.length, 0);

  mgr.setSignedIn(true);
  const opened = mgr.restore(['https://a.example/', 'https://b.example/'], { activeUrl: 'https://b.example/' });
  assert.equal(opened.length, 2);
  assert.equal(mgr.tabs.length, 2);
  assert.equal(win.stack.length, 2);
  assert.equal(mgr.active.url, 'https://b.example/', 'the saved active URL is the one in front');
});
