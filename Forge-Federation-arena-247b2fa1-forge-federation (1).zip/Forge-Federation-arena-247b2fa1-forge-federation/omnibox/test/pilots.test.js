/**
 * pilots.test.js — the four browser agents and the soundness gate around them.
 *
 * The point of these tests is the GATE, not the model: a pilot may only ever
 * perform actions from the closed set, the driver's answer must be strict
 * JSON, and a sentence that cannot be read is REFUSED by name rather than
 * executed as something else. That is what separates a browser agent from a
 * misclicking script.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { PilotManager, parseAction, performAction, MAX_ACTIVE, MAX_STEPS } = require('../src/main/pilots.js');

// --------------------------------------------------------------------------
// parseAction — the only interpretation of a model's answer
// --------------------------------------------------------------------------

test('a clean JSON action parses', () => {
  const a = parseAction('{"action":"navigate","to":"https://claude.ai"}');
  assert.equal(a.rejected, undefined);
  assert.deepEqual(a, { action: 'navigate', to: 'https://claude.ai' });
});

test('navigate is limited to https, loopback http, and forgeflight pages', () => {
  assert.equal(parseAction('{"action":"navigate","to":"javascript:alert(1)"}').rejected, true);
  assert.equal(parseAction('{"action":"navigate","to":"file:///etc/passwd"}').rejected, true);
  assert.equal(parseAction('{"action":"navigate","to":"data:text/html,hi"}').rejected, true);
  assert.equal(parseAction('{"action":"navigate","to":"http://example.com"}').reason, 'bad-url');
  assert.ok(!parseAction('{"action":"navigate","to":"https://example.com"}').rejected);
  assert.ok(!parseAction('{"action":"navigate","to":"http://localhost:4173"}').rejected);
  assert.ok(!parseAction('{"action":"navigate","to":"http://127.0.0.1:8080"}').rejected);
  assert.ok(!parseAction('{"action":"navigate","to":"forgeflight://local"}').rejected);
});

test('prose instead of JSON is refused, not guessed at', () => {
  const a = parseAction('I think you should click the login button');
  assert.equal(a.rejected, true);
  assert.equal(a.reason, 'bad-json');
});

test('an unknown action is refused by name', () => {
  const a = parseAction('{"action":"fetch","url":"https://example.com"}');
  assert.equal(a.rejected, true);
  assert.equal(a.reason, 'unknown-action');
});

test('an unknown field on a known action is refused', () => {
  const a = parseAction('{"action":"click","selector":"#x","password":"hunter2"}');
  assert.equal(a.rejected, true);
  assert.equal(a.reason, 'unknown-field');
  assert.match(a.detail, /does not take "password"/);
});

test('click needs a target; type needs both fields; press only takes enter/escape', () => {
  assert.equal(parseAction('{"action":"click"}').reason, 'no-target');
  assert.equal(parseAction('{"action":"type","selector":"#x"}').reason, 'need-both');
  assert.equal(parseAction('{"action":"press","key":"ctrl+alt+delete"}').reason, 'bad-key');
  assert.ok(!parseAction('{"action":"press","key":"enter"}').rejected);
  assert.ok(!parseAction('{"action":"wait","ms":99999999}').rejected); // capped
  assert.deepEqual(parseAction('{"action":"wait","ms":99999999}').ms, 10000);
});

// --------------------------------------------------------------------------
// performAction — a real driver over a stub page
// --------------------------------------------------------------------------

function stubPage() {
  const calls = [];
  const doc = { title: 'Stub', url: 'https://example.com', body: { innerText: 'hello world' } };
  const page = {
    navigate: async (id, to) => { calls.push(['navigate', id, to]); },
    evaluate: async (id, code) => {
      calls.push(['evaluate', id, code.slice(0, 40)]);
      if (code.includes('"#crowded"')) return 'ambiguous:3';
      if (code.includes('"#locked"')) return 'disabled:1';
      if (code.includes('document.querySelectorAll') && code.includes('"#go"')) return 'selector';
      if (code.includes('document.querySelectorAll') && code.includes('"Send"')) return 'text';
      if (code.includes('document.querySelectorAll') && code.includes('"#missing"')) return 'not-found';
      if (code.includes('document.querySelectorAll') && code.includes('"#field"')) return 'ok';
      if (code.includes('KeyboardEvent')) return 'BUTTON';
      if (code.includes('innerText')) return doc;
      return 'ok';
    },
    open: async (url) => 't-pilot',
  };
  return { page, calls };
}

test('performAction dispatches navigate/click/type/press and reports honestly', async () => {
  const { page, calls } = stubPage();
  const nav = await performAction(page, 't1', { action: 'navigate', to: 'https://arena.ai' });
  assert.ok(nav.ok);
  assert.deepEqual(calls[0], ['navigate', 't1', 'https://arena.ai']);

  const click = await performAction(page, 't1', { action: 'click', selector: '#go' });
  assert.ok(click.ok);

  const miss = await performAction(page, 't1', { action: 'click', selector: '#missing' });
  assert.equal(miss.ok, false);
  assert.equal(miss.reason, 'not-found');

  const press = await performAction(page, 't1', { action: 'press', key: 'enter' });
  assert.ok(press.ok);
});

test('a click or type matching several elements is refused, never first-match guessed', async () => {
  const { page } = stubPage();
  const click = await performAction(page, 't1', { action: 'click', selector: '#crowded' });
  assert.equal(click.ok, false);
  assert.equal(click.reason, 'ambiguous-click');
  assert.match(click.detail, /3 visible elements/);
  const type = await performAction(page, 't1', { action: 'type', selector: '#crowded', text: 'hi' });
  assert.equal(type.ok, false);
  assert.equal(type.reason, 'ambiguous-type');
  assert.match(type.detail, /refuses to guess/);
});

test('type looks at every match, not the first one — the no-guess rule is in the page script itself', async () => {
  let script = '';
  const page = {
    navigate: async () => {},
    evaluate: async (_id, code) => {
      script = code;
      return 'ok';
    },
  };
  await performAction(page, 't1', { action: 'type', selector: '#field', text: 'hi' });
  assert.match(script, /querySelectorAll/, 'type must collect every match, not querySelector the first');
  assert.match(script, /ambiguous:/, 'type must name the crowd rather than pick one');
  assert.match(script, /reanchor/, 'the SOUND engine re-finds a stamped control instead of guessing');
  assert.doesNotMatch(script, /\.suggest\(/, 'suggest is never auto-applied');
  assert.doesNotMatch(script, /document\.querySelector\(/, 'first-match querySelector is the silent-wrong-grab this product refuses');
});

test('a disabled control is refused by its own name, not mislabelled not-found', async () => {
  const { page } = stubPage();
  const dis = await performAction(page, 't1', { action: 'click', selector: '#locked' });
  assert.equal(dis.ok, false);
  assert.equal(dis.reason, 'disabled');
  assert.match(dis.detail, /did not force/);
});

// --------------------------------------------------------------------------
// PilotManager — four slots, a strict gate, honest refusals
// --------------------------------------------------------------------------

function harness({ driver, page } = {}) {
  const emit = [];
  const em = (kind, payload) => emit.push({ kind, payload });
  const manager = new PilotManager({
    ask: driver || (async () => ({ ok: true, text: '{"action":"done","summary":"found it"}' })),
    page: page || stubPage().page,
    emit: em,
    sleep: async () => {},
  });
  return { manager, emit };
}

test('only four pilots fly at once — the fifth is refused by name', () => {
  const { manager } = harness();
  const launches = [];
  for (let i = 0; i < MAX_ACTIVE; i++) {
    const r = manager.launch({ goal: `goal ${i}`, url: 'https://example.com' });
    assert.equal(r.ok, true);
    launches.push(r.pilot.id);
  }
  const fifth = manager.launch({ goal: 'goal 4', url: 'https://example.com' });
  assert.equal(fifth.ok, false);
  assert.equal(fifth.reason, 'limit');
  // slots are stable P1..P4
  const slots = manager.status().slots.map((s) => s.slot);
  assert.deepEqual(slots, [1, 2, 3, 4]);
  manager.stopAll();
});

test('a pilot that returns prose instead of JSON stops and names the refusal', async () => {
  const { manager } = harness({ driver: async () => ({ ok: true, text: 'click the button please' }) });
  const launch = manager.launch({ goal: 'do the thing', url: 'https://example.com' });
  assert.equal(launch.ok, true);
  // wait for the flight to settle
  await new Promise((r) => setTimeout(r, 50));
  const p = manager.get(launch.pilot.id);
  assert.equal(p.state, 'stopped');
  assert.equal(p.result.reason, 'bad-json');
  assert.match(p.result.detail, /JSON action/);
});

test('a pilot with no driver refuses to launch the flight', async () => {
  const { manager } = harness({ driver: async () => ({ ok: false, reason: 'no-driver', detail: 'No local model and no seat to think with.' }) });
  const r = manager.launch({ goal: 'go', url: 'https://example.com' });
  await new Promise((res) => setTimeout(res, 50));
  const p = manager.get(r.pilot.id);
  assert.equal(p.result.reason, 'no-driver');
});

test('a pilot can fly a full step until done', async () => {
  let step = 0;
  const driver = async ({ prompt }) => {
    step++;
    if (step === 1) return { ok: true, text: '{"action":"navigate","to":"https://arena.ai"}' };
    if (step === 2) return { ok: true, text: '{"action":"click","text":"Send"}' };
    return { ok: true, text: '{"action":"done","summary":"reached the goal"}' };
  };
  const { manager } = harness({ driver });
  const r = manager.launch({ goal: 'find it', url: 'https://example.com' });
  await new Promise((res) => setTimeout(res, 60));
  const p = manager.get(r.pilot.id);
  assert.equal(p.state, 'done');
  assert.ok(p.steps >= 3, `steps=${p.steps}`);
});

test('steps are capped and the cap is named', async () => {
  const driver = async () => ({ ok: true, text: '{"action":"wait","ms":1}' });
  const { manager } = harness({ driver });
  const r = manager.launch({ goal: 'loop', url: 'https://example.com' });
  await new Promise((res) => setTimeout(res, 300));
  const p = manager.get(r.pilot.id);
  assert.equal(p.result.reason, 'step-limit');
  assert.equal(p.steps, MAX_STEPS);
});

test('every step emits a flight bag; page words stay out of it', async () => {
  const { manager, emit } = harness({
    driver: async () => ({ ok: true, text: '{"action":"done","summary":"found the secret plan"}' }),
  });
  const r = manager.launch({ goal: 'find the secret plan', url: 'https://example.com' });
  await new Promise((res) => setTimeout(res, 50));
  const steps = emit.filter((e) => e.kind === 'pilot:step');
  assert.ok(steps.length >= 1);
  const bag = steps[0].payload.flight;
  assert.ok(bag);
  assert.equal(bag.verb, 'done');
  assert.equal(bag.ok, true);
  assert.equal(bag.before.url, 'https://example.com');
  assert.equal(typeof bag.before.n, 'number');
  assert.equal(bag.before.text, undefined);
  assert.equal(bag.text, undefined);
  assert.equal(bag.selector, undefined);
  assert.equal(bag.goal, undefined);
  const dumped = JSON.stringify(bag);
  assert.equal(dumped.includes('secret plan'), false);
  assert.equal(dumped.includes('hello world'), false);
});

test('a bad-json refusal emits none-refused before the flight stops', async () => {
  const { manager, emit } = harness({ driver: async () => ({ ok: true, text: 'click the button please' }) });
  manager.launch({ goal: 'do the thing', url: 'https://example.com' });
  await new Promise((r) => setTimeout(r, 50));
  const steps = emit.filter((e) => e.kind === 'pilot:step');
  assert.equal(steps.length, 1);
  assert.equal(steps[0].payload.flight.verb, 'none');
  assert.equal(steps[0].payload.flight.ok, false);
  assert.equal(steps[0].payload.flight.reason, 'bad-json');
  assert.ok(emit.some((e) => e.kind === 'pilot:finished'));
});

test('an ambiguous click emits click-refused, not a guessed landing', async () => {
  const { manager, emit } = harness({
    driver: async () => ({ ok: true, text: '{"action":"click","selector":"#crowded"}' }),
  });
  manager.launch({ goal: 'click it', url: 'https://example.com' });
  await new Promise((r) => setTimeout(r, 50));
  const steps = emit.filter((e) => e.kind === 'pilot:step');
  assert.equal(steps.length, 1);
  assert.equal(steps[0].payload.flight.verb, 'click');
  assert.equal(steps[0].payload.flight.ok, false);
  assert.equal(steps[0].payload.flight.reason, 'ambiguous-click');
  assert.equal(JSON.stringify(steps[0].payload.flight).includes('#crowded'), false);
});
