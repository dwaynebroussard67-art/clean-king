'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const main = readFileSync(path.join(root, 'src/main/main.js'), 'utf8');
const chrome = readFileSync(path.join(root, 'src/renderer/chrome.js'), 'utf8');
const html = readFileSync(path.join(root, 'src/renderer/index.html'), 'utf8');
const css = readFileSync(path.join(root, 'src/renderer/chrome.css'), 'utf8');
const preload = readFileSync(path.join(root, 'src/preload/chrome.js'), 'utf8');
const operatorSrc = readFileSync(path.join(root, 'src/main/operator.js'), 'utf8');
const captainSrc = readFileSync(path.join(root, 'src/main/captain.js'), 'utf8');
const localSeat = readFileSync(path.join(root, 'src/renderer/local-seat.html'), 'utf8');

test('the main process wires the radio into the table and the boot flow', () => {
  assert.match(main, /require\(['"]\.\.\/federation\/bridge\.js['"]\)/);
  assert.match(main, /proposeSupportedClaims/);
  assert.match(main, /bootPayload|bootFor/);
  assert.match(main, /federation:autoPropose/);
  assert.match(main, /renderSeatBriefing|copilotPrompt/);
  assert.match(main, /captainDecide/);
});

test('a release is signed by this launch\'s operator; the renderer actor is ignored', () => {
  assert.match(main, /authorizeActor\(operator/);
  assert.match(operatorSrc, /reason: 'not-signed-in'/);
  assert.match(operatorSrc, /void actor/);
  assert.match(operatorSrc, /signIn\(/);
  assert.doesNotMatch(operatorSrc, /reason: 'no-operator'/);
  // The payload's actor must not be what lands on the queue.
  assert.doesNotMatch(main, /queue\.release\(id,\s*\{\s*actor\s*\}/);
  assert.doesNotMatch(main, /queue\.refuse\(id,\s*\{\s*actor\s*\}/);
});

test('the carrier release flow never hardcodes a name', () => {
  assert.doesNotMatch(chrome, /federation\.release\(it\.id,\s*['"]D['"]/);
  assert.doesNotMatch(chrome, /federation\.refuse\(it\.id,\s*['"]D['"]/);
  assert.doesNotMatch(chrome, /window\.prompt\s*\(/);
  assert.match(chrome, /operator\.signIn/);
});

test('the chrome bridge exposes a narrow federation API and an operator the renderer cannot stamp', () => {
  assert.match(preload, /federation:\s*\{/);
  assert.match(preload, /stats: \(\) => ipcRenderer\.invoke\(['"]federation:stats['"]\)/);
  assert.match(preload, /release: \(id, note\)/);
  assert.match(preload, /operator:\s*\{/);
  assert.match(preload, /signIn: \(name\) => ipcRenderer\.invoke\(['"]operator:signin['"]/);
  assert.match(preload, /captain: \(spec\) => ipcRenderer\.invoke\(['"]table:captain['"]/);
  assert.doesNotMatch(preload, /invoke\(['"]federation:release['"],\s*\{\s*id,\s*actor/);
});

test('no local model puts the human in the captain chair, never a no-captain skip', () => {
  assert.match(captainSrc, /awaitingHuman/);
  assert.match(captainSrc, /reason: 'human-captain'/);
  assert.match(captainSrc, /applyHumanCaptain/);
  assert.doesNotMatch(captainSrc, /reason: 'no-captain'/);
  assert.match(main, /table:captain/);
  assert.match(main, /pendingCaptain/);
  assert.match(chrome, /awaitingHuman/);
  assert.match(chrome, /humanChair/);
  assert.doesNotMatch(chrome, /no-captain/);
});

test('every launch asks the human to sign in by name', () => {
  assert.match(html, /id="gate"/);
  assert.match(chrome, /function renderGate/);
  assert.match(chrome, /submitGate/);
  assert.match(main, /operator:signin/);
  assert.match(main, /operator\.status\(\)/);
});

test('talk-to-text sits on every input; listen sits on every output and never auto-plays', () => {
  assert.match(chrome, /function attachMic/);
  assert.match(chrome, /function attachSpeak/);
  assert.match(chrome, /speechSynthesis/);
  assert.doesNotMatch(chrome, /synth\.speak\(u\);\s*\n\s*synth\.speak/);
  assert.match(html, /id="gateMic"/);
  assert.match(html, /id="carOpMic"/);
  assert.match(html, /id="bootSpeak"/);
  assert.match(html, /id="carSpeak"/);
  assert.match(html, /id="pilotSpeak"/);
  assert.match(css, /\.speak\.speaking/);
  assert.match(localSeat, /id="cmpMic"/);
  assert.match(localSeat, /className = 'speak'/);
  assert.match(main, /LOCAL_SEAT_URL_RE\.test\(url\)/);
});
