const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { readFileSync } = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const agent = readFileSync(path.join(root, 'mobile/android/app/src/main/assets/seat-agent.js'), 'utf8');
const pocket = readFileSync(path.join(root, 'mobile/app.js'), 'utf8');

function get(port, pathname) {
  return new Promise((resolve, reject) => {
    const request = require('node:http').get({ hostname: '127.0.0.1', port, path: pathname }, (response) => {
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => resolve({ status: response.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    request.on('error', reject);
  });
}

test('mobile agent refuses a disabled send control instead of falling back to Enter', () => {
  assert.match(agent, /reason:\s*'send-disabled'/);
  assert.match(agent, /if \(controls\[0\]\.el\.disabled\) return \{ ok: false/);
  assert.doesNotMatch(agent, /if \(controls\[0\]\.el\.disabled\)[\s\S]{0,180}return 'enter'/);
});

test('mobile agent keeps the document-field discriminator and bridge hardening', () => {
  assert.match(agent, /!isAnchored && !messageHits/);
  assert.match(agent, /score < 6/);
  assert.match(agent, /Object\.defineProperty\(window, name/);
});

test('Pocket repairs hostile URL state and refuses executable schemes', () => {
  assert.match(pocket, /pendingPrompt: typeof parsed\.pendingPrompt/);
  assert.match(pocket, /safeIndex = history\.length/);
  assert.match(pocket, /javascript\|vbscript\|file\|data/);
  assert.ok(pocket.includes('(?:\\d{1,3}\\.)'));
});

test('mobile server serves only its shell and rejects traversal', async (t) => {
  const port = 43000 + Math.floor(Math.random() * 1000);
  const child = spawn(process.execPath, ['mobile/server.mjs'], {
    cwd: root,
    env: { ...process.env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  t.after(() => child.kill('SIGTERM'));
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('mobile server did not start')), 4000);
    child.stdout.once('data', () => { clearTimeout(timer); resolve(); });
    child.once('error', (error) => { clearTimeout(timer); reject(error); });
    child.once('exit', (code) => {
      if (code !== null) { clearTimeout(timer); reject(new Error(`mobile server exited with ${code}`)); }
    });
  });
  const index = await get(port, '/');
  assert.equal(index.status, 200);
  assert.match(index.body, /Forge Flight Pocket/);
  const manifest = await get(port, '/manifest.webmanifest');
  assert.equal(manifest.status, 200);
  assert.match(manifest.body, /"display": "standalone"/);
  const traversal = await get(port, '/%2e%2e/%2e%2e/etc/passwd');
  assert.equal(traversal.status, 404);
});
