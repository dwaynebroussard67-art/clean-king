/**
 * forge-bench.test.js — the hangar: the self-healing relay, pinned down.
 *
 * The idea under test: copilots fly on free/low tiers; when one runs dry the
 * forge ejects it (never bills it) and seats the next spare from the bench; if
 * the bench is empty the run PAUSES rather than dies, and resumes when
 * allowances reset or a seat is added. The bench is the user's own seats —
 * their other providers, their local models — never harvested strangers.
 *
 * The tree language is the same as forge.test.js: F(name) is a failing test,
 * -F(name) removes it. A smart seat removes the first failing test it sees, so
 * a relay of N smart seats removes N failures per round.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');

const { CodeForge, ForgeBench, ForgePausedError } = require('../src/forge/index.js');

// ── The failing-test tree language ────────────────────────────────────────

function failingOf(tree) {
  const out = [];
  const re = /F\(([^)]*)\)/g;
  let m;
  while ((m = re.exec(String(tree))) !== null) out.push(m[1]);
  return out.sort();
}

function treeOf(names) {
  return names.slice().sort().map((n) => `F(${n})`).join(' ');
}

function setsEqual(a, b) {
  return a.size === b.size && [...a].every((x) => b.has(x));
}

function referee() {
  return {
    async verdict(tree) {
      const failing = failingOf(tree);
      return failing.length === 0 ? { status: 'green' } : { status: 'red', failing };
    },
  };
}

function apply() {
  return (tree, patch) => {
    const cur = new Set(failingOf(tree));
    const next = new Set(cur);
    for (const t of String(patch).split(/\s+/).filter(Boolean)) {
      if (t.startsWith('-F(')) next.delete(t.slice(3, -1));
      else if (t.startsWith('+F(')) next.add(t.slice(3, -1));
      else return { ok: false, reason: `unparseable patch token: ${t}` };
    }
    if (setsEqual(cur, next)) return { ok: true, changed: false, tree };
    return { ok: true, changed: true, tree: treeOf([...next]) };
  };
}

function smartSeat(id) {
  return {
    id,
    label: id,
    propose: async (ctx) => {
      const failing = failingOf(ctx.tree);
      if (!failing.length) return { kind: 'pass', reason: 'nothing failing' };
      return { kind: 'proposal', patch: `-F(${failing[0]})`, summary: `fix ${failing[0]}`, toolSequence: ['forge.run_tests'] };
    },
  };
}

function baseSpec(over = {}) {
  return {
    goal: 'make the tests pass',
    trunk: treeOf(['t0', 't1', 't2']),
    seats: [],
    referee: referee(),
    apply: apply(),
    ...over,
  };
}

// ── The bench itself ──────────────────────────────────────────────────────

test('the bench is an ordered queue: seatNext removes, add appends, peek does not', () => {
  const b = new ForgeBench([{ id: 'a' }, { id: 'b' }]);
  assert.equal(b.remaining, 2);
  assert.equal(b.peek().id, 'a');
  assert.equal(b.remaining, 2); // peek does not remove
  assert.equal(b.seatNext().id, 'a');
  assert.equal(b.seatNext().id, 'b');
  assert.equal(b.seatNext(), null);
  assert.equal(b.isEmpty(), true);
  b.add({ id: 'c' });
  assert.equal(b.seatNext().id, 'c');
});

test('a bench refuses a non-array', () => {
  assert.throws(() => new ForgeBench('nope'), /must be an array/);
});

// ── Swap on ejection ──────────────────────────────────────────────────────

test('an ejected seat is swapped for the next bench member, which inherits full context', async () => {
  const seenCtx = [];
  const spec = baseSpec({
    trunk: treeOf(['auth', 'login']),
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    seats: [
      {
        id: 's1',
        label: 's1',
        propose: async (ctx) => {
          if (ctx.round === 1) return { kind: 'proposal', patch: '-F(auth)', summary: 'fix auth' };
          return { kind: 'pass', reason: 'spent' };
        },
      },
    ],
    bench: [
      {
        id: 'b1',
        label: 'b1',
        propose: async (ctx) => {
          seenCtx.push(ctx);
          return { kind: 'proposal', patch: '-F(login)', summary: 'fix login' };
        },
      },
    ],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();

  assert.equal(r.stopReason, 'goal_reached');
  assert.equal(r.proposal.seatId, 'b1'); // the replacement won
  assert.equal(forge.budget.ejected('s1'), true);

  // The newcomer inherited the run: it knows who it replaced, when it joined,
  // what the tree was, and what had failed before it arrived.
  assert.equal(seenCtx.length, 1);
  assert.equal(seenCtx[0].replacedSeat, 's1');
  assert.equal(seenCtx[0].joinedAt, 2);
  assert.equal(seenCtx[0].tree, 'F(login)');
  assert.ok(seenCtx[0].failures.some((f) => /tests still failing: login/.test(f.reason)));

  // The swap is a named record in the hash-chained memory.
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'event' && rec.data.type === 'seat_swapped' && rec.data.ejected === 's1' && rec.data.seated === 'b1'));
});

// ── Pause and resume ──────────────────────────────────────────────────────

test('an exhausted relay with an empty bench PAUSES, keeps its runId, and resumes to green', async () => {
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2']),
    budget: { s1: { maxCalls: 1, tier: 'free' }, s2: { maxCalls: 1, tier: 'free' } },
    seats: [smartSeat('s1'), smartSeat('s2')],
    bench: [], // configured, but empty: pause instead of terminal budget_exhausted
  });
  const forge = new CodeForge(spec);

  const r1 = await forge.run();
  assert.equal(r1.stopReason, 'paused');
  assert.equal(r1.resumable, true);
  assert.equal(forge.isPaused, true);
  assert.equal(r1.roundsRun, 1);
  assert.equal(r1.lastVerdict.failing.join(','), 't2'); // t0 and t1 fixed, t2 remains

  // A paused forge refuses to start a fresh run.
  await assert.rejects(() => forge.run(), ForgePausedError);

  // A new day: allowances reset, then resume — same run, same memory.
  forge.resetBudgets();
  const r2 = await forge.resume();

  assert.equal(r2.runId, r1.runId); // the same flight, continued
  assert.equal(r2.stopReason, 'goal_reached');
  assert.equal(r2.roundsRun, 2);
  assert.equal(r2.proposal.seatId, 's1');
  assert.equal(forge.isPaused, false);
});

test('resume with nothing suspended is a named refusal', async () => {
  const forge = new CodeForge(baseSpec({ seats: [smartSeat('s1')] }));
  await assert.rejects(() => forge.resume(), ForgePausedError);
});

test('adding a seat to an empty bench during a pause lets the run resume to green', async () => {
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2']),
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    seats: [smartSeat('s1')],
    bench: [],
  });
  const forge = new CodeForge(spec);

  const r1 = await forge.run();
  assert.equal(r1.stopReason, 'paused');
  assert.equal(r1.roundsRun, 1);
  assert.equal(forge.bench.remaining, 0);

  forge.addSeat(smartSeat('b1')); // "the user added a provider"
  assert.equal(forge.bench.remaining, 1);

  const r2 = await forge.resume();
  assert.equal(r2.runId, r1.runId);
  assert.equal(r2.stopReason, 'goal_reached');
  assert.equal(r2.proposal.seatId, 'b1');
});

test('an unmetered local bench member keeps the relay flying — no pause, no terminal stop', async () => {
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2', 't3']),
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    seats: [smartSeat('s1')],
    bench: [smartSeat('local')], // unmetered: no provision
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.equal(r.proposal.seatId, 'local');
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'event' && rec.data.type === 'seat_swapped'));
});

test('without a bench, exhaustion is terminal budget_exhausted — not a pause', async () => {
  const spec = baseSpec({
    trunk: treeOf(['t0', 't1', 't2']),
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    seats: [smartSeat('s1')],
    // no `bench` key at all
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'budget_exhausted');
  assert.equal(r.resumable, false);
  assert.equal(forge.isPaused, false);
});

test('the ejected seat is billed exactly once, and the swap is remembered for the audit', async () => {
  const spec = baseSpec({
    trunk: treeOf(['auth', 'login']),
    budget: { s1: { maxCalls: 1, tier: 'free' } },
    seats: [smartSeat('s1')],
    bench: [smartSeat('b1')],
  });
  const forge = new CodeForge(spec);
  const r = await forge.run();
  assert.equal(r.stopReason, 'goal_reached');
  assert.equal(r.budget.s1.calls, 1); // charged once, then ejected — never billed again
  assert.equal(forge.budget.ejected('s1'), true);
  assert.ok(forge.recorder.records.some((rec) => rec.op === 'refusal' && rec.data.seatId === 's1' && rec.data.reason === 'budget_exhausted'));
});
