'use strict';

/**
 * field-evidence.test.js — the gate's view of the scorer.
 *
 * The full suite (18 checks) lives next to the scorer at
 * src/field-evidence/scorer.test.mjs and runs in the unit stage alongside
 * this file. This bridge exists for one reason: `require()` of the ESM
 * scorer must keep working, because the day it stops, the gate silently
 * covers a module nothing loads. Three smoke checks, pinned here.
 */

const test = require('node:test');
const assert = require('node:assert/strict');

const { scoreFieldEvidence, scoreAnchorsText, confidentlyWrongRate } = require('../src/field-evidence/scorer.mjs');

const seated = (key = 'k1', over = {}) => ({
  type: 'verdict',
  url: 'https://chat.example/room',
  trigger: 'load',
  status: 'seated',
  manual: false,
  confidence: 0.9,
  margin: 0.2,
  winner: { stabilityKey: key },
  losers: [],
  ...over,
});

test('field evidence loads through require() and refuses a rate on no rulings', () => {
  const r = scoreFieldEvidence([seated()]);
  assert.equal(r.confident, 1);
  assert.equal(r.adjudicated, 0);
  assert.equal(r.confidentlyWrongRate, null);
  assert.equal(confidentlyWrongRate([seated()]), null);
});

test('field evidence joins a disagreeing pick to a confident seat (rate 1)', () => {
  const r = scoreFieldEvidence([
    seated('k1'),
    { type: 'pick', url: 'https://chat.example/room', ok: true, stamp: { stabilityKey: 'k9' } },
  ]);
  assert.equal(r.adjudicated, 1);
  assert.equal(r.disagreed, 1);
  assert.equal(r.confidentlyWrongRate, 1);
});

test('field evidence text form counts a torn final line', () => {
  const r = scoreAnchorsText(`${JSON.stringify(seated())}\n{"type":"verdict", "url":`);
  assert.equal(r.verdicts, 1);
  assert.equal(r.lines.torn, 1);
  assert.equal(r.lines.corrupt, 0);
});
