/**
 * profile-watch.test.js — the boot watch on an adopted OmniBox profile.
 *
 * Adoption moves a profile an OLDER Chromium wrote into the folder a NEWER
 * Chromium opens at launch. Usually Chromium migrates it forward; sometimes
 * it dies inside its own storage layer instead — silently, before or just
 * after the window shows, and then on EVERY launch of that folder. The watch
 * makes the death speak: an adopted profile's launches are marked, a launch
 * that ends well clears the mark, and two deaths in a row quarantine the
 * tree to `forgeflight.old` so the next launch starts fresh instead of
 * dying again.
 *
 * These tests pin the policy surface of profile.js:
 *
 *   - only a folder a legacy note NAMES as adopted is ever watched, and only
 *     it can be quarantined — a profile Forge Flight created itself is never
 *     armed;
 *   - one dead boot arms, it does not quarantine; two dead boots in a row do;
 *   - a cleared watch (graceful quit / settled boot) starts the count over;
 *   - quarantine MOVES the tree aside, untouched, and rewrites the legacy
 *     note so the fresh folder is never mistaken for the adopted one again;
 *   - nothing here ever throws.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const {
  adoptLegacyProfile,
  guardAdoptedProfile,
  clearBootWatch,
  adoptedFromLegacyNote,
  NOTE,
  BOOT_WATCH,
} = require('../src/main/profile.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-watch-'));
const write = (p, s) => {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s, 'utf8');
};

/** A parent folder with an adopted profile at forgeflight/ (note at omnibox/). */
function adoptedTree() {
  const parent = tmp();
  const next = path.join(parent, 'forgeflight');
  write(path.join(parent, 'omnibox', 'passport', 'x.jsonl'), '{}\n');
  write(path.join(parent, 'omnibox', 'Partitions', 'omnibox', 'Cookies'), 'jar');
  const r = adoptLegacyProfile(next);
  assert.equal(r.action, 'moved', r.detail);
  return { parent, next, legacy: path.join(parent, 'omnibox') };
}

test('only a folder a legacy note names as adopted is watched', () => {
  const parent = tmp();
  const native = path.join(parent, 'forgeflight');
  write(path.join(native, 'session.json'), '{"fresh":true}');
  const r = guardAdoptedProfile(native);
  assert.equal(r.action, 'none', 'a native profile is never armed');
  assert.ok(!fs.existsSync(path.join(native, BOOT_WATCH)), 'no mark was written');

  // Even a stray mark file cannot arm a native profile: the note is the only
  // evidence the watch accepts.
  write(path.join(native, BOOT_WATCH), '{"n":2}');
  assert.equal(guardAdoptedProfile(native).action, 'none');
});

test('the first launch of an adopted profile arms the watch; one dead boot arms, it does not quarantine', () => {
  const { parent, next } = adoptedTree();
  assert.ok(adoptedFromLegacyNote(next), 'the note names the adopted folder');

  const first = guardAdoptedProfile(next);
  assert.equal(first.action, 'watching', JSON.stringify(first));
  const mark = JSON.parse(fs.readFileSync(path.join(next, BOOT_WATCH), 'utf8'));
  assert.equal(mark.n, 1, 'first armed boot is count one');

  // Boot two starts with the previous boot's death still marked.
  const second = guardAdoptedProfile(next);
  assert.equal(second.action, 'watching-2', 'one death arms the second boot — it does not throw the profile away');
  assert.ok(fs.existsSync(next), 'the profile is still in place');
});

test('two dead boots in a row quarantine the adopted tree, untouched, and the fresh boot is unarmed', () => {
  const { parent, next, legacy } = adoptedTree();
  guardAdoptedProfile(next); // boot 1 arms (n=1) and dies
  guardAdoptedProfile(next); // boot 2 arms (n=2) and dies

  const third = guardAdoptedProfile(next); // boot 3: quarantine, then start fresh
  assert.equal(third.action, 'quarantined', JSON.stringify(third));
  assert.ok(!fs.existsSync(next), 'the poisoned folder is no longer what Electron will open');
  assert.equal(third.to, path.join(parent, 'forgeflight.old'), JSON.stringify(third));
  const dest = third.to;
  assert.ok(fs.existsSync(path.join(dest, 'Partitions', 'omnibox', 'Cookies')), 'the cookie jar came along untouched');
  assert.ok(fs.existsSync(path.join(dest, 'passport', 'x.jsonl')), 'the passport came along untouched');

  const note = fs.readFileSync(path.join(legacy, NOTE), 'utf8');
  assert.match(note, /could not open it/, 'the legacy note explains why');
  assert.ok(!adoptedFromLegacyNote(next), 'the note no longer names the fresh folder — it can never be quarantined again');

  // The fresh folder boots clean: nothing armed, nothing to quarantine.
  const fourth = guardAdoptedProfile(next);
  assert.equal(fourth.action, 'none', JSON.stringify(fourth));
});

test('a cleared watch (graceful quit or settled boot) starts the count over', () => {
  const { next } = adoptedTree();
  guardAdoptedProfile(next); // boot 1 arms and dies

  // Boot 2 clears the mark the way a graceful quit or a settled boot does.
  clearBootWatch(next);
  assert.ok(!fs.existsSync(path.join(next, BOOT_WATCH)), 'the mark is gone');

  // Boot 3 sees no death and arms at count one again — not a quarantine.
  const boot3 = guardAdoptedProfile(next);
  assert.equal(boot3.action, 'watching', JSON.stringify(boot3));
  assert.equal(JSON.parse(fs.readFileSync(path.join(next, BOOT_WATCH), 'utf8')).n, 1);
});

test('quarantine finds a free sibling name when forgeflight.old already exists', () => {
  const { parent, next } = adoptedTree();
  fs.mkdirSync(path.join(parent, 'forgeflight.old'), { recursive: true });
  guardAdoptedProfile(next);
  guardAdoptedProfile(next);
  const third = guardAdoptedProfile(next);
  assert.equal(third.action, 'quarantined');
  assert.notEqual(third.to, path.join(parent, 'forgeflight.old'), 'the taken name is not reused');
  assert.ok(fs.existsSync(path.join(third.to, 'Partitions', 'omnibox', 'Cookies')), 'the profile landed in the free name');
});

test('the watch never throws — corrupt marks and unwritable folders are handled', () => {
  const { next } = adoptedTree();
  write(path.join(next, BOOT_WATCH), 'not json at all');
  assert.doesNotThrow(() => guardAdoptedProfile(next), 'a corrupt mark reads as no mark');

  // A folder that cannot take the mark reports it instead of throwing — and
  // the boot proceeds unarmed rather than crashing over bookkeeping.
  const second = adoptedTree();
  fs.mkdirSync(path.join(second.next, BOOT_WATCH)); // a directory where the file belongs
  assert.doesNotThrow(() => guardAdoptedProfile(second.next));
  const r = guardAdoptedProfile(second.next);
  assert.ok(['watching', 'watching-2', 'unwritable'].includes(r.action), JSON.stringify(r));
});
