/**
 * rename.test.js — the OmniBox → Forge Flight rename does not lose anything.
 *
 * The product name changed. The person's logins, passport, session, picks,
 * anchors and federation did not, and every one of them is keyed by a name
 * somewhere on disk. These tests pin the compatibility surface that D26
 * promises: the profile is adopted once, old exports still import, old
 * session files still resume, old federation logs still load, and the one
 * identifier that MUST stay (the cookie partition) has stayed.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { adoptLegacyProfile, NOTE } = require('../src/main/profile.js');
const { Passport, EXPORT_SCHEMA, IMPORT_SCHEMAS } = require('../src/passport/index.js');
const { restorableURL } = require('../src/main/session.js');
const { Federation } = require('../src/federation/store.js');
const { ProposalQueue } = require('../src/federation/queue.js');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-rename-'));
const write = (p, s) => {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s, 'utf8');
};

// ------------------------------------------------------------------ profile

test('a first launch adopts the OmniBox profile — moved, not copied, with a note left behind', () => {
  const parent = tmp();
  const old = path.join(parent, 'omnibox');
  const next = path.join(parent, 'forgeflight');
  write(path.join(old, 'passport', 'passport.jsonl'), '{"op":"claim","data":{"id":"c1","signature":"s"}}\n');
  write(path.join(old, 'session.json'), '{"tabs":[]}');
  write(path.join(old, 'Partitions', 'omnibox', 'Cookies'), 'not-really-a-cookie-db');

  const r = adoptLegacyProfile(next);
  assert.equal(r.action, 'moved', r.detail);
  assert.ok(fs.existsSync(path.join(next, 'passport', 'passport.jsonl')), 'the passport came along');
  assert.ok(fs.existsSync(path.join(next, 'session.json')), 'the session came along');
  assert.ok(fs.existsSync(path.join(next, 'Partitions', 'omnibox', 'Cookies')), 'the cookie jar came along');
  assert.ok(fs.existsSync(path.join(old, NOTE)), 'the old folder explains where the profile went');
  assert.match(fs.readFileSync(path.join(old, NOTE), 'utf8'), /Forge Flight/);
  assert.equal(fs.readdirSync(old).length, 1, 'nothing else was left behind in the old folder');
});

test('adoption NEVER overwrites a Forge Flight profile that already has anything in it', () => {
  const parent = tmp();
  const old = path.join(parent, 'omnibox');
  const next = path.join(parent, 'forgeflight');
  write(path.join(old, 'session.json'), '{"from":"omnibox"}');
  write(path.join(next, 'session.json'), '{"from":"forgeflight"}');

  const r = adoptLegacyProfile(next);
  assert.equal(r.action, 'kept');
  assert.equal(JSON.parse(fs.readFileSync(path.join(next, 'session.json'), 'utf8')).from, 'forgeflight');
  assert.ok(fs.existsSync(path.join(old, 'session.json')), 'and the old profile was left exactly where it was');
  assert.ok(!fs.existsSync(path.join(old, NOTE)), 'no note claims a move that did not happen');
});

test('adoption is a no-op with nothing to adopt, and an already-adopted folder is not adopted twice', () => {
  const parent = tmp();
  const next = path.join(parent, 'forgeflight');
  assert.equal(adoptLegacyProfile(next).action, 'none');

  // A folder that holds only our note is the leftover of a previous move.
  const old = path.join(parent, 'omnibox');
  write(path.join(old, NOTE), 'moved');
  assert.equal(adoptLegacyProfile(next).action, 'none', 'the note marks it as already handled');
});

test('an empty pre-created Forge Flight folder does not block adoption', () => {
  const parent = tmp();
  const old = path.join(parent, 'omnibox');
  const next = path.join(parent, 'forgeflight');
  write(path.join(old, 'picks.json'), '{}');
  fs.mkdirSync(next, { recursive: true }); // Electron may touch it before ready
  const r = adoptLegacyProfile(next);
  assert.equal(r.action, 'moved', r.detail);
  assert.ok(fs.existsSync(path.join(next, 'picks.json')));
});

// --------------------------------------------------------------- partition

test('THE COOKIE PARTITION KEPT ITS NAME — renaming it would sign everyone out', () => {
  // Read the source rather than require it: tabs.js pulls in electron.
  const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'main', 'tabs.js'), 'utf8');
  assert.match(src, /const PARTITION = 'persist:omnibox';/);
});

// ------------------------------------------------------------------ exports

test('a passport exported by OmniBox still imports; a new export declares the Forge Flight schema', () => {
  const a = new Passport(tmp());
  a.propose({
    type: 'fact',
    title: 'capital',
    content: 'The capital of France is Paris.',
    confidence: 0.6,
    metadata: { witness_kind: 'outcome', reference: 'seat:x run:1' },
  });
  const bundle = a.export();
  assert.equal(bundle.schema, EXPORT_SCHEMA);
  assert.equal(EXPORT_SCHEMA, 'forgeflight.passport.v1');

  // The same file, as OmniBox would have written it.
  const legacy = { ...bundle, schema: 'omnibox.passport.v1' };
  const b = new Passport(tmp());
  const res = b.importBundle(legacy);
  assert.equal(res.ok, true, res.detail);
  assert.equal(res.imported, 1);
  assert.ok(IMPORT_SCHEMAS.includes('omnibox.passport.v1'));

  // And a file that is neither is still refused by name.
  assert.equal(b.importBundle({ schema: 'something.else' }).reason, 'not-a-passport');
});

// ------------------------------------------------------------------ session

test('a session saved by OmniBox resumes: its own pages translate to the new scheme, nothing else changes', () => {
  assert.equal(restorableURL('omnibox://start'), 'forgeflight://start');
  assert.equal(restorableURL('omnibox://local'), 'forgeflight://local');
  assert.equal(restorableURL('forgeflight://local'), 'forgeflight://local');
  assert.equal(restorableURL('https://claude.ai/new'), 'https://claude.ai/new');
  assert.equal(restorableURL('file:///etc/passwd'), null, 'the allowlist did not widen');
  assert.equal(restorableURL('javascript:alert(1)'), null);
});

// --------------------------------------------------------------- federation

test('a federation log written under the old folder and file name is adopted on load, chain intact', () => {
  const userData = tmp();
  // Write a real log under the OLD layout by using the store itself, then
  // move it to where OmniBox would have left it.
  const staging = new Federation(path.join(userData, 'staging')).load();
  staging.land({
    shelf: 'operational',
    equation: { subject: 'claude.ai', predicate: 'rate_limit', object: '0' },
    witness: 'outcome',
    nodeId: 'node-a',
    reference: 'run:1',
    target: 'claude.ai',
  });
  const oldDir = path.join(userData, 'collective');
  fs.mkdirSync(oldDir, { recursive: true });
  fs.renameSync(staging.logPath, path.join(oldDir, 'collective.jsonl'));
  fs.rmSync(path.join(userData, 'staging'), { recursive: true, force: true });

  const fed = new Federation(path.join(userData, 'federation')).load();
  assert.equal(fed.live().length, 1, 'the fact is there');
  assert.equal(fed.chain.breaks.length, 0, 'the chain is untouched — it was a rename, not a rewrite');
  assert.ok(fs.existsSync(fed.logPath));
  assert.ok(!fs.existsSync(path.join(oldDir, 'collective.jsonl')), 'moved, not copied');

  // A record stamped with the OmniBox-era schema id replays like any other.
  const raw = fs.readFileSync(fed.logPath, 'utf8');
  assert.match(raw, /forgeflight\.federation\.v1/);
  const relabelled = raw.replace(/forgeflight\.federation\.v1/g, 'omnibox.collective.v1');
  const dir2 = path.join(userData, 'federation2');
  write(path.join(dir2, 'federation.jsonl'), relabelled);
  const fed2 = new Federation(dir2).load();
  assert.equal(fed2.live().length, 1, 'an old-schema line still loads');
});

test('a proposal queue under the old folder is adopted on load', () => {
  const userData = tmp();
  const staging = new ProposalQueue(path.join(userData, 'staging')).load();
  staging.propose({ id: 'prop_1', ask: 'recheck' });
  fs.mkdirSync(path.join(userData, 'collective'), { recursive: true });
  fs.renameSync(staging.logPath, path.join(userData, 'collective', 'queue.jsonl'));

  const q = new ProposalQueue(path.join(userData, 'federation')).load();
  assert.equal(q.open().length, 1);
  assert.equal(q.get('prop_1').state, 'open');
});

test('an existing new-layout federation log is never clobbered by an old one', () => {
  const userData = tmp();
  const fed = new Federation(path.join(userData, 'federation')).load();
  fed.land({
    shelf: 'world',
    equation: { subject: 'france', predicate: 'capital', object: 'paris' },
    witness: 'structural',
    nodeId: 'n',
    reference: 'r',
  });
  write(path.join(userData, 'collective', 'collective.jsonl'), '{"op":"fact","data":{"signature":"zzz"},"prev":"0","hash":"0"}\n');
  const again = new Federation(path.join(userData, 'federation')).load();
  assert.equal(again.live().length, 1);
  assert.ok(fs.existsSync(path.join(userData, 'collective', 'collective.jsonl')), 'the old one was left where it was');
});

// ------------------------------------------------------------- local seat

test('the local-model URL override honours both the new and the OmniBox-era variable', () => {
  const { LocalLLM } = require('../src/main/localLLM.js');
  const saved = { a: process.env.FORGEFLIGHT_LOCAL_LLM_URL, b: process.env.OMNIBOX_LOCAL_LLM_URL };
  try {
    delete process.env.FORGEFLIGHT_LOCAL_LLM_URL;
    process.env.OMNIBOX_LOCAL_LLM_URL = 'http://127.0.0.1:9999';
    assert.deepEqual(new LocalLLM().endpoints, ['http://127.0.0.1:9999']);
    process.env.FORGEFLIGHT_LOCAL_LLM_URL = 'http://127.0.0.1:8888';
    assert.deepEqual(new LocalLLM().endpoints, ['http://127.0.0.1:8888'], 'the new name wins when both are set');
  } finally {
    if (saved.a === undefined) delete process.env.FORGEFLIGHT_LOCAL_LLM_URL;
    else process.env.FORGEFLIGHT_LOCAL_LLM_URL = saved.a;
    if (saved.b === undefined) delete process.env.OMNIBOX_LOCAL_LLM_URL;
    else process.env.OMNIBOX_LOCAL_LLM_URL = saved.b;
  }
});
