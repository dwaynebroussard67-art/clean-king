'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  supportedEquationClaims,
  alreadyProposed,
  proposeSupportedClaims,
  carrierAudit,
  rankCarrierFacts,
  renderCarrierSection,
  renderSeatBriefing,
  bootPayload,
  copilotPrompt,
} = require('../src/federation/bridge.js');

function row(overrides = {}) {
  return {
    memory: {
      id: 'm1',
      title: 'capital of France',
      content: 'The capital of France is Paris.',
      origin: 'local',
      metadata: {
        witness_kind: 'outcome',
        reference: 'seat:claude run:r1',
        host: 'claude.ai',
        seat: 'Claude',
      },
      ...(overrides.memory || {}),
    },
    claim: {
      id: 'c1',
      status: 'supported',
      confirmationCount: 5,
      form: 'equation',
      equation: { subject: 'france', predicate: 'capital', object: 'paris' },
      ...(overrides.claim || {}),
    },
  };
}

function fakeQueued(equation, shelf = 'world') {
  return { id: 'p1', ask: 'transfer', shelf, equation };
}

test('upward: the Passport walk selects only supported, equation-form claims', () => {
  const rows = [
    row(),
    row({ claim: { id: 'c2', status: 'provisional', form: 'equation', equation: row().claim.equation } }),
    row({ claim: { id: 'c3', status: 'supported', form: 'prose', equation: null } }),
    row({ claim: { id: 'c4', status: 'supported', form: 'equation', equation: null } }),
  ];
  const got = supportedEquationClaims(rows);
  assert.equal(got.length, 1);
  assert.equal(got[0].claimId, 'c1');
  assert.equal(got[0].shelf, 'world');
  assert.equal(got[0].witness, 'outcome');
  assert.equal(got[0].nodeId, 'local-cockpit');
  assert.equal(got[0].replication, 5);
  assert.match(got[0].reference, /claim:c1/);
  assert.ok(got[0].hosts.includes('claude.ai'));
  assert.match(got[0].rendered, /capital\(france\) = paris/);
});

test('upward: multiple Passport memories for one claim aggregate into one proposal', () => {
  const got = supportedEquationClaims([
    row({ memory: { id: 'm1', metadata: { witness_kind: 'outcome', reference: 'seat:claude run:r1', host: 'claude.ai' } } }),
    row({ memory: { id: 'm2', metadata: { witness_kind: 'outcome', reference: 'seat:chatgpt run:r1', host: 'chatgpt.com' } } }),
  ]);
  assert.equal(got.length, 1);
  assert.deepEqual(got[0].hosts.sort(), ['chatgpt.com', 'claude.ai']);
  assert.equal(got[0].replication, 5);
});

test('upward: an unknown Passport witness kind falls back to structural, never to agreement', () => {
  const got = supportedEquationClaims([
    row({ memory: { metadata: { witness_kind: 'agreement', reference: 'r', host: 'h' } } }),
  ]);
  assert.equal(got[0].witness, 'structural');
});

test('upward: alreadyProposed compares the equation identity on the same shelf', () => {
  const eq = { subject: 'france', predicate: 'capital', object: 'paris' };
  const c = supportedEquationClaims([row()])[0];
  assert.equal(alreadyProposed({ all: () => [fakeQueued(eq, 'world')] }, c), true);
  assert.equal(alreadyProposed({ all: () => [fakeQueued(eq, 'operational')] }, c), false);
  assert.equal(alreadyProposed({ all: () => [{ ask: 'capability', equation: eq }] }, c), false);
});

test('upward: proposeSupportedClaims proposes once and reports skipped dupes', () => {
  const c = row();
  const proposed = [];
  const fakeCurator = {
    reviewTransfer(spec) {
      const p = { id: 'p1', ask: 'transfer', decision: 'proposed', ...spec };
      proposed.push(p);
      return p;
    },
  };
  let queued = [];
  const fakeQueue = { all: () => queued };
  const r = proposeSupportedClaims({
    passport: { rows: () => [c, c] },
    curator: fakeCurator,
    queue: fakeQueue,
  });
  assert.equal(proposed.length, 1);
  assert.equal(r.proposed.length, 1);
  queued = [fakeQueued(c.claim.equation)];
  const r2 = proposeSupportedClaims({ passport: { rows: () => [c] }, curator: fakeCurator, queue: fakeQueue });
  assert.equal(r2.proposed.length, 0);
  assert.equal(r2.skipped[0].reason, 'already-proposed');
});

test('downward: carrier audit separates live, superseded and closed', () => {
  const live = { id: 'f1', rendered: 'capital(france) = paris', status: 'established', distinct: 5, shelf: 'world' };
  const sup = {
    id: 'f2',
    rendered: 'composer(claude.ai) = old',
    status: 'superseded',
    closedAt: 'x',
    distinct: 3,
    shelf: 'operational',
  };
  const closed = { id: 'f3', rendered: 'capital(france) = lyon', status: 'closed', closedAt: 'x', distinct: 2, shelf: 'world' };
  const audit = carrierAudit([live, sup, closed]);
  assert.deepEqual(
    audit.admitted.map((f) => f.id),
    ['f1']
  );
  assert.deepEqual(
    audit.superseded.map((f) => f.id),
    ['f2']
  );
  assert.deepEqual(
    audit.closed.map((f) => f.id),
    ['f3']
  );
});

test('downward: carrier section ranks established facts first and owns its audit', () => {
  const rank = rankCarrierFacts([
    { id: 'a', status: 'provisional', distinct: 6 },
    { id: 'b', status: 'established', distinct: 3 },
    { id: 'c', status: 'superseded' },
  ]);
  assert.deepEqual(
    rank.map((f) => f.id),
    ['b', 'a']
  );

  const out = renderCarrierSection('=== MEMORY PASSPORT ===', [
    { id: 'b', rendered: 'capital(france) = paris', shelf: 'world', status: 'established', distinct: 5 },
    { id: 'c', rendered: 'composer(claude.ai) = old', shelf: 'operational', status: 'superseded', distinct: 3 },
    { id: 'd', rendered: 'capital(france) = lyon', shelf: 'world', status: 'closed', closedAt: 'x', distinct: 2 },
  ]);
  assert.match(out.text, /=== FEDERATION CARRIER ===/);
  assert.match(out.text, /--- carrier not shown ---/);
  assert.match(out.text, /closed by another cockpit/);
  assert.match(out.text, /superseded \(the target moved\)/);
  assert.ok(out.text.startsWith('=== MEMORY PASSPORT ===\n'));
  const reasons = out.carrier.excluded.map((x) => x.reason);
  assert.ok(reasons.includes('federation-superseded'));
  assert.ok(reasons.includes('federation-closed'));
});

test('downward: an empty carrier stays visible, not silently absent', () => {
  const out = renderCarrierSection('=== MEMORY PASSPORT ===\n', []);
  assert.match(out.text, /=== FEDERATION CARRIER ===/);
  assert.match(out.text, /nothing was withheld from the carrier/);
});

test('briefing: copilots get established facts only, never the full boot, never provisionals', () => {
  const briefing = renderSeatBriefing([
    { status: 'established', rendered: 'capital(france) = paris', distinct: 5, shelf: 'world' },
    { status: 'provisional', rendered: 'secret(thing) = classified', distinct: 1, shelf: 'world' },
    { status: 'closed', closedAt: 'x', rendered: 'old(fact) = gone', distinct: 2, shelf: 'world' },
  ]);
  assert.match(briefing, /FORGE FLIGHT BRIEFING/);
  assert.match(briefing, /capital\(france\) = paris/);
  assert.doesNotMatch(briefing, /secret\(thing\)/);
  assert.doesNotMatch(briefing, /old\(fact\)/);
  assert.doesNotMatch(briefing, /MEMORY PASSPORT/);
  assert.ok(briefing.length <= 700);
});

test('briefing: nothing established means no briefing at all', () => {
  assert.equal(renderSeatBriefing([]), '');
  assert.equal(renderSeatBriefing([{ status: 'provisional', rendered: 'x', distinct: 1 }]), '');
});

test('briefing: copilotPrompt leaves the question alone when there is nothing to brief', () => {
  assert.equal(copilotPrompt('What is the capital of France?', ''), 'What is the capital of France?');
  assert.match(copilotPrompt('Q', 'BRIEF'), /BRIEF[\s\S]*Q/);
});

test('bootPayload appends the carrier section to the passport boot block', () => {
  const out = bootPayload(
    {
      bootBlock: () => ({
        text: '=== MEMORY PASSPORT ===\nhello\n',
        admitted: [],
        excluded: [],
        tokensUsed: 1,
        tokenBudget: 100,
      }),
    },
    { all: () => [{ id: 'f1', rendered: 'capital(france) = paris', shelf: 'world', status: 'established', distinct: 5 }] },
    'france'
  );
  assert.match(out.text, /MEMORY PASSPORT/);
  assert.match(out.text, /FEDERATION CARRIER/);
  assert.match(out.text, /capital\(france\) = paris/);
  assert.equal(out.carrier.admitted.length, 1);
});
