/**
 * gate.test.js — the sign-in gate is the hit-test boundary.
 *
 * The gate ("Who is flying?") is HTML, and a browser tab is a NATIVE
 * WebContentsView that Electron composites ABOVE the window's HTML. A page
 * view mounted while the gate is up covers the sign-in card in its bounds
 * and wins every click and keystroke there — the window looks alive and
 * nothing in it can be touched. That is the bug this file pins:
 *
 *   1. no page view is opened, restored, or revealed before this launch
 *      signs in (open() refuses, restore() restores nothing);
 *   2. even a view that already exists stays at 0x0, invisible, while the
 *      gate is up — layout must not hand an unjudged background tab a real
 *      box "for measuring" while the page is hidden, because a real box is
 *      exactly a native lid over the chrome;
 *   3. the reveal happens only once the launch signs in AND the browse pane
 *      is showing AND the chrome has reported a real hole.
 *
 * TabManager constructs no Chromium view until open() passes the gate, so
 * all of this is expressible without Electron — the one place that needs a
 * real browser (does the card actually take the click) lives in
 * test/e2e/run-e2e.mjs.
 */

'use strict';

const test = require('node:test');
const assert = require('node:assert');

const { TabManager } = require('../src/main/tabs.js');

/** A window that records the child-view stack the way Electron maintains it. */
function fakeWindow() {
  const stack = [];
  return {
    stack,
    contentView: {
      addChildView(v) {
        const i = stack.indexOf(v);
        if (i !== -1) stack.splice(i, 1);
        stack.push(v);
      },
      removeChildView(v) {
        const i = stack.indexOf(v);
        if (i !== -1) stack.splice(i, 1);
      },
    },
  };
}

function fakeView() {
  return {
    bounds: null,
    visible: null,
    setBounds(b) {
      this.bounds = b;
    },
    setVisible(v) {
      this.visible = v;
    },
  };
}

/** A tab already past the gate — the shape open() produces once signed in. */
function stubTab(mgr, win, url, n) {
  const view = fakeView();
  const tab = {
    id: `t${n}`,
    url,
    title: url,
    seat: { status: 'unknown' }, // unjudged: awaitingVerdict() is true
    view,
    destroy() {},
  };
  mgr.tabs.push(tab);
  win.contentView.addChildView(view);
  return tab;
}

const BOX = { x: 246, y: 96, width: 1000, height: 600 };
const isZero = (b) => b && b.width === 0 && b.height === 0;
const shown = (t) => !isZero(t.view.bounds) && t.view.visible === true;

test('no page view mounts before this launch signs in — open() refuses', () => {
  const mgr = new TabManager(fakeWindow(), () => {});
  assert.equal(mgr.signedIn, false, 'a fresh TabManager is gated');

  const t = mgr.open('https://a.example/');
  assert.equal(t, null, 'open() returns null instead of mounting a view');
  assert.equal(mgr.tabs.length, 0, 'nothing was added to the window');
  assert.equal(mgr.activeId, null, 'nothing was activated');
});

test('restore() before sign-in restores nothing', () => {
  const mgr = new TabManager(fakeWindow(), () => {});
  const opened = mgr.restore(['https://a.example/', 'https://b.example/'], { activeUrl: 'https://a.example/' });
  assert.deepEqual(opened, [], 'the caller is told nothing came back');
  assert.equal(mgr.tabs.length, 0, 'and the window really has no views in it');
});

test('signing in flips the mount gate, once — and re-arming is not a change', () => {
  const mgr = new TabManager(fakeWindow(), () => {});
  let changes = 0;
  mgr.onChange = () => changes++;
  assert.equal(mgr.signedIn, false, 'a fresh TabManager is gated');
  mgr.setSignedIn(true);
  assert.equal(mgr.signedIn, true);
  mgr.setSignedIn(true);
  assert.equal(changes, 1, 're-signing in is not a change to report');
  mgr.setSignedIn(false);
  mgr.setSignedIn(true);
  assert.equal(changes, 3, 'the gate coming back up is a real change (defensive; no sign-out flow today)');
});

test('layout parks every existing view at 0x0, invisible, while the gate is up', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  const a = stubTab(mgr, win, 'https://a.example/', 1);
  const b = stubTab(mgr, win, 'https://b.example/', 2); // unjudged → would be "measured"
  mgr.activeId = a.id;

  // The chrome reported a real hole and the browse pane is showing, but this
  // launch has not signed in: no view gets a real box, not even the unjudged
  // one. A real box would be a native lid over the sign-in card.
  mgr.setBounds(BOX);
  mgr.setPageVisible(true);
  mgr.layout();

  for (const t of [a, b]) {
    assert.ok(isZero(t.view.bounds), `${t.url} stayed at ${JSON.stringify(t.view.bounds)}`);
    assert.equal(t.view.visible, false, `${t.url} stayed invisible`);
  }
  assert.deepEqual(
    win.stack,
    [a.view, b.view],
    'no re-raising churn while the gate is up — nothing may be "above" anything'
  );

  // Signing in is what releases the page… but only when the chrome then says
  // the browse pane may show it. (In production the chrome sends
  // pageVisible(false) while gated and true again the moment the gate hides,
  // so the state below is the hostile order — and it still behaves: the gate
  // outranks the pane until the launch signs in, and the reveal is deferred.)
  mgr.setSignedIn(true);
  mgr.layout();
  assert.ok(shown(a), 'signed in + browse showing: the active tab gets the hole');
  assert.ok(!isZero(b.view.bounds) && b.view.visible === true, 'an unjudged tab is measured under it — the D25 contract still holds');
});

test('a hidden page is never handed to an unjudged tab for measuring', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  mgr.setSignedIn(true);
  const a = stubTab(mgr, win, 'https://a.example/', 1);
  const b = stubTab(mgr, win, 'https://b.example/', 2);
  mgr.activeId = a.id;
  mgr.setBounds(BOX);

  // The Table pane is showing: pageVisible(false). Before the fix, layout()
  // still gave the unjudged tab a real box AND setVisible(true) — a native
  // view floating over the HTML table pane. Nothing may show while hidden.
  mgr.setPageVisible(false);
  for (const t of [a, b]) {
    assert.ok(isZero(t.view.bounds) && t.view.visible === false, `${t.url} is not measurable into a hidden page`);
  }

  mgr.setPageVisible(true);
  assert.ok(shown(a), 'back on Browse, the active tab shows');
});

test('setPageVisible(true) cannot reveal the page while the gate is up', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  const a = stubTab(mgr, win, 'https://a.example/', 1);
  mgr.activeId = a.id;
  mgr.setBounds(BOX);
  mgr.setPageVisible(true);
  mgr.layout();
  assert.ok(isZero(a.view.bounds), 'the gate outranks the browse pane');

  mgr.setSignedIn(true);
  mgr.layout();
  assert.ok(shown(a), 'once signed in, the same state reveals the page');
});

test('a verdict keeps its meaning across the gate: judged tabs stay parked', () => {
  const win = fakeWindow();
  const mgr = new TabManager(win, () => {});
  mgr.setSignedIn(true);
  const a = stubTab(mgr, win, 'https://a.example/', 1);
  const b = stubTab(mgr, win, 'https://b.example/', 2);
  mgr.activeId = a.id;
  mgr.setBounds(BOX);
  mgr.setPageVisible(true);

  b.seat = { status: 'seated', confidence: 0.9 };
  mgr.layout();
  assert.ok(isZero(b.view.bounds), 'a background tab that has ruled is parked');
  assert.equal(b.view.visible, false);

  // Gate back up (defensive — there is no sign-out flow today), then down.
  mgr.setSignedIn(false);
  assert.ok(isZero(a.view.bounds) && a.view.visible === false, 'gate up: the active tab hides too');
  mgr.setSignedIn(true);
  assert.ok(shown(a), 'gate down again: the active tab is back');
  assert.ok(isZero(b.view.bounds), 'and the judged tab is still parked, not re-measured');
});
