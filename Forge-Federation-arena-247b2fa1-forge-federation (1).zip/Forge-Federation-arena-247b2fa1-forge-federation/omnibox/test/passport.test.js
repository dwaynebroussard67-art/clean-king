'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { PassportStore } = require('../src/passport/store.js');
const { WriteBoundary, WriteBoundaryError } = require('../src/passport/writeBoundary.js');
const { TrustGate, stableSoftmax } = require('../src/passport/trustGate.js');
const { Passport } = require('../src/passport/index.js');
const { sha256, claimSignature, witnessSignature } = require('../src/passport/core.js');

function tmpdir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'forgeflight-passport-'));
}

function newBoundary() {
  const dir = tmpdir();
  const store = new PassportStore(dir).load();
  return { dir, store, wb: new WriteBoundary(store) };
}

const good = (over = {}) => ({
  type: 'fact',
  title: 'API rate limit is 100 req/min per key',
  content: 'API rate limit is 100 req/min per key',
  confidence: 0.7,
  metadata: { witness_kind: 'contract', reference: 'docs §4.2' },
  ...over,
});

// ===========================================================================
test('write boundary — a valid proposal creates one claim and one memory', () => {
  const { wb, store } = newBoundary();
  const { memory, claim } = wb.propose(good());
  assert.equal(memory.claimId, claim.id);
  assert.equal(claim.status, 'provisional');
  assert.equal(claim.confirmationCount, 1);
  assert.equal(store.stats().claims, 1);
  assert.equal(memory.adjudicatedAt, null, 'a write can never arrive adjudicated');
});

test('write boundary — REJECTS a privileged field rather than stripping it (C4a)', () => {
  const { wb } = newBoundary();
  for (const field of ['status', 'adjudicatedAt', 'pinned', 'confirmationCount', 'id', 'claimId']) {
    assert.throws(
      () => wb.propose(good({ [field]: 'supported' })),
      (e) => e instanceof WriteBoundaryError && e.field === field,
      `expected ${field} to be refused by name`
    );
  }
});

test('write boundary — REJECTS a privileged field smuggled inside metadata', () => {
  const { wb } = newBoundary();
  assert.throws(
    () => wb.propose(good({ metadata: { witness_kind: 'human', reference: 'x', status: 'supported' } })),
    (e) => e instanceof WriteBoundaryError && e.field === 'metadata.status'
  );
});

test('write boundary — evidence pointer is mandatory', () => {
  const { wb } = newBoundary();
  assert.throws(
    () => wb.propose(good({ metadata: { witness_kind: 'human' } })),
    (e) => e.field === 'metadata.reference'
  );
});

test('write boundary — closed vocabularies are enforced', () => {
  const { wb } = newBoundary();
  assert.throws(() => wb.propose(good({ type: 'observation' })), (e) => e.field === 'type');
  assert.throws(
    () => wb.propose(good({ metadata: { witness_kind: 'vibes', reference: 'x' } })),
    (e) => e.field === 'metadata.witness_kind'
  );
  assert.throws(() => wb.propose(good({ confidence: 1.4 })), (e) => e.field === 'confidence');
});

// ===========================================================================
test('C2 — five DISTINCT witnesses promote; a repeated witness does not', () => {
  const { wb } = newBoundary();
  let claim;
  for (let i = 0; i < 4; i++) {
    ({ claim } = wb.propose(good({ metadata: { witness_kind: 'outcome', reference: `run-${i}` } })));
  }
  assert.equal(claim.confirmationCount, 4);
  assert.equal(claim.status, 'provisional', 'four witnesses is not five');

  // The same witness said again, ten times.
  for (let i = 0; i < 10; i++) {
    ({ claim } = wb.propose(good({ metadata: { witness_kind: 'outcome', reference: 'run-0' } })));
  }
  assert.equal(claim.confirmationCount, 4, 'repetition of one witness is still one witness');
  assert.equal(claim.status, 'provisional');

  ({ claim } = wb.propose(good({ metadata: { witness_kind: 'human', reference: 'operator' } })));
  assert.equal(claim.confirmationCount, 5);
  assert.equal(claim.status, 'supported');
  assert.ok(claim.promotedAt, 'promotion is stamped');
});

test('C2 — the status ceiling is `supported`; nothing ever reaches `settled`', () => {
  const { wb, store } = newBoundary();
  for (let i = 0; i < 12; i++) wb.propose(good({ metadata: { witness_kind: 'outcome', reference: `r${i}` } }));
  const claim = [...store.claims.values()][0];
  assert.equal(claim.status, 'supported');
  assert.equal(claim.confirmationCount, 12);
});

test('C2 — one contradiction CLOSES the claim, it does not decrement a tally', () => {
  const { wb } = newBoundary();
  for (let i = 0; i < 5; i++) wb.propose(good({ metadata: { witness_kind: 'outcome', reference: `r${i}` } }));
  const { claim } = wb.contradict(good({ metadata: { witness_kind: 'outcome', reference: 'the-incident' } }));
  assert.equal(claim.status, 'contested');
  assert.equal(claim.confirmationCount, 5, 'the confirmations are not erased, the claim is closed');
  assert.equal(claim.contradictionCount, 1);
  assert.ok(claim.invalidAt);
});

test('C2 — a confirmation does not reopen a closed claim', () => {
  const { wb } = newBoundary();
  wb.propose(good());
  wb.contradict(good({ metadata: { witness_kind: 'outcome', reference: 'incident' } }));
  const { claim } = wb.propose(good({ metadata: { witness_kind: 'human', reference: 'someone-insists' } }));
  assert.equal(claim.status, 'contested', 'reopening is a deliberate act, never a side effect');
  assert.equal(claim.confirmationCount, 1);
});

test('C1 — supersede is bi-temporal and nothing hard-deletes', () => {
  const { wb, store } = newBoundary();
  const a = wb.propose(good());
  const b = wb.propose(good({ content: 'API rate limit is 300 req/min per key', title: 'new limit' }));
  const closed = wb.supersede(a.claim.id, b.claim.id);
  assert.equal(closed.status, 'invalidated');
  assert.equal(closed.supersededBy, b.claim.id);
  assert.ok(store.getMemory(a.memory.id), 'the superseded memory is still there');

  const retired = wb.retire(a.memory.id);
  assert.ok(retired.retiredAt, 'retire is a soft stamp');
  assert.ok(store.getMemory(a.memory.id), 'still on disk after retirement');
});

test('C4 — an import contributes no witness and cannot arrive adjudicated', () => {
  const { wb } = newBoundary();
  const { claim, memory } = wb.import(good());
  assert.equal(claim.confirmationCount, 0);
  assert.equal(claim.witnessSignatures.length, 0);
  assert.equal(memory.adjudicatedAt, null);
  assert.equal(memory.origin, 'imported');
});

test('C4 — export/relabel/reimport cannot launder a status', () => {
  const { wb } = newBoundary();
  const exported = { ...good(), status: 'supported', adjudicatedAt: new Date().toISOString() };
  assert.throws(() => wb.import(exported), (e) => e instanceof WriteBoundaryError);
});

test('adjudication is a system path and is digest-bound', () => {
  const { wb, store } = newBoundary();
  const { memory } = wb.propose(good());
  const adj = wb.adjudicate(memory.id);
  assert.equal(adj.adjudicatedDigest, sha256(memory.content));
  const events = store.eventsFor({ memoryId: memory.id }).map((e) => e.kind);
  assert.ok(events.includes('adjudicated'));
});

// ===========================================================================
test('C3 — the worked example: 0.98 cosine loses 4:1 to 0.85 cosine on trust', () => {
  const gate = new TrustGate();
  // M1: adjudicated + digest match (1.0) × supported at 5 witnesses (1.0)
  //     × fresh (1.0) × confidence 0.95  =>  0.95
  // M2: unadjudicated (0.55) × provisional 1 witness (0.2+0.4×0.2=0.28)
  //     × fresh (1.0) × confidence 0.40  =>  0.0616
  const logits = gate.logits([0.85, 0.98], [0.95, 0.0616]);
  assert.ok(Math.abs(logits[0] - 8.4487) < 0.01, `logit_1 was ${logits[0]}`);
  assert.ok(Math.abs(logits[1] - 7.0129) < 0.01, `logit_2 was ${logits[1]}`);
  const w = stableSoftmax(logits);
  assert.ok(Math.abs(w[0] - 0.8078) < 0.001, `weight_1 was ${w[0]}`);
  assert.ok(Math.abs(w[1] - 0.1922) < 0.001, `weight_2 was ${w[1]}`);
  assert.ok(Math.abs(w[0] + w[1] - 1) < 1e-12);
});

test('C3 — τ is 0.10, not √d; the √d version would let trust dominate', () => {
  const gate = new TrustGate();
  assert.equal(gate.config.temperature, 0.1);
  // With √768 scaling the semantic term collapses to ±0.036 and the ranking
  // is decided entirely by trust — the failure this constant exists to avoid.
  const sqrtD = new TrustGate({ temperature: Math.sqrt(768) });
  const wrong = stableSoftmax(sqrtD.logits([0.85, 0.98], [0.95, 0.0616]));
  assert.ok(wrong[0] > 0.9, 'with √d scaling the low-trust memory is annihilated regardless of relevance');
  const right = stableSoftmax(gate.logits([0.85, 0.98], [0.95, 0.0616]));
  assert.ok(right[1] > 0.15, 'with τ=0.10 relevance still counts for something');
});

test('C3 — a digest mismatch is trusted LESS than never having been adjudicated', () => {
  const gate = new TrustGate();
  assert.ok(gate.config.tAdjMismatch < gate.config.tAdjUnadjudicated);
  const claim = { status: 'supported', confirmationCount: 5, nextRecheckAt: null };
  const base = { confidence: 0.8, pinned: false, origin: 'local', content: 'x' };
  const never = gate.evaluate({ ...base, adjudicatedAt: null, adjudicatedDigest: null }, claim);
  const tampered = gate.evaluate({ ...base, adjudicatedAt: '2020-01-01T00:00:00Z', adjudicatedDigest: 'stale' }, claim);
  assert.ok(
    tampered.trustGate < never.trustGate,
    'a claim verified once then silently changed is more suspicious than one never verified'
  );
});

test('C3 — a contested claim is hard-excluded and never enters the softmax', () => {
  const gate = new TrustGate();
  const ev = gate.evaluate(
    { confidence: 0.99, pinned: false, origin: 'local', content: 'x', adjudicatedAt: null },
    { status: 'contested', confirmationCount: 9, nextRecheckAt: null }
  );
  assert.equal(ev.trustGate, 0);
  assert.equal(ev.excludeReason, 'contested');
});

test('C3 — pinned survives the budget, but pinning cannot override contested', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  p.propose(good({ title: 'doctrine', content: 'The agent asks before it changes the world.', confidence: 0.99 }), {
    pin: true,
  });
  for (let i = 0; i < 12; i++) {
    p.propose(
      good({
        title: `filler ${i}`,
        content: `some unrelated fact number ${i} about rate limits and quotas`,
        metadata: { witness_kind: 'outcome', reference: `f${i}` },
      })
    );
  }
  const boot = p.bootBlock('may I drop the table?', { tokenBudget: 60 });
  assert.ok(
    boot.admitted.some((a) => a.pinned && a.memory.title === 'doctrine'),
    'the pinned doctrine survived a budget that admits almost nothing'
  );

  // Now contest it and confirm pinning does not rescue it.
  p.contradict(
    good({
      title: 'doctrine',
      content: 'The agent asks before it changes the world.',
      metadata: { witness_kind: 'outcome', reference: 'it-did-not-ask' },
    })
  );
  const after = p.bootBlock('may I drop the table?', { tokenBudget: 600 });
  assert.ok(!after.admitted.some((a) => a.memory.title === 'doctrine'), 'a contested pin is still refused');
  assert.ok(after.excluded.some((e) => e.reason === 'contested'));
});

test('the read shape always carries the exclusion audit', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  p.propose(good());
  p.propose(good({ title: 'low', content: 'a barely-believed thing', confidence: 0.05, metadata: { witness_kind: 'human', reference: 'hunch' } }));
  const boot = p.bootBlock('rate limit', { tokenBudget: 400 });
  assert.match(boot.text, /--- not shown ---/);
  assert.match(boot.text, /status ceiling is `supported`/);
  assert.ok(boot.excluded.length >= 1);
  assert.ok(boot.excluded.every((e) => typeof e.reason === 'string' && e.reason.length > 0), 'every exclusion carries a reason');
});

// ===========================================================================
test('store — survives a restart and drops a torn line without crashing', () => {
  const dir = tmpdir();
  const p1 = new Passport(dir);
  p1.propose(good());
  p1.propose(good({ content: 'a second distinct proposition entirely', title: 'second' }));
  const before = p1.stats();

  fs.appendFileSync(path.join(dir, 'passport.jsonl'), '{"op":"memory","data":{"id":"tor');

  const p2 = new Passport(dir);
  assert.equal(p2.stats().claims, before.claims);
  assert.equal(p2.stats().memories, before.memories);
  assert.equal(p2.stats().corruptLines, 1, 'the torn line is counted, not swallowed');
});

// ===========================================================================
test('intake — two seats answering one prompt are two distinct witnesses', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  const prompt = 'what is the capital of France';
  const a = p.ingestReply({ seatName: 'Alpha', host: 'alpha.example', prompt, text: 'Paris.', runId: 'r1' });
  const b = p.ingestReply({ seatName: 'Beta', host: 'beta.example', prompt, text: 'Paris.', runId: 'r1' });
  assert.ok(a && b);
  assert.equal(a.claim.id, b.claim.id, 'same proposition is one claim');
  assert.equal(b.claim.confirmationCount, 2, 'two different seats are two witnesses');

  // The same seat saying it again is not a third witness.
  const c = p.ingestReply({ seatName: 'Alpha', host: 'alpha.example', prompt, text: 'Paris.', runId: 'r1' });
  assert.equal(c.claim.confirmationCount, 2);
});

test('intake — a reply enters provisional, unpinned, unadjudicated, low confidence', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  const r = p.ingestReply({ seatName: 'Alpha', host: 'a.example', prompt: 'q', text: 'an answer', runId: 'r1' });
  assert.equal(r.claim.status, 'provisional');
  assert.equal(r.memory.pinned, false);
  assert.equal(r.memory.adjudicatedAt, null);
  assert.ok(r.memory.confidence <= 0.5, 'a model saying something is weak evidence');
});

test('intake — an unusable reply is refused and logged, never thrown', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  assert.equal(p.ingestReply({ seatName: 'A', prompt: 'q', text: '   ' }), null);
});

test('cross-provider agreement and disagreement are recorded as distinct events', () => {
  const dir = tmpdir();
  const p = new Passport(dir);
  const prompt = 'is the sky blue';
  const same = [
    { ok: true, memory: p.ingestReply({ seatName: 'A', host: 'a.x', prompt, text: 'Yes.', runId: 'r1' }) },
    { ok: true, memory: p.ingestReply({ seatName: 'B', host: 'b.x', prompt, text: 'Yes.', runId: 'r1' }) },
  ];
  const agree = p.recordDisagreement('r1', same);
  assert.equal(agree.kind, 'cross_agreement');
  assert.equal(agree.agreementCount, 2);

  const diff = [
    { ok: true, memory: p.ingestReply({ seatName: 'A', host: 'a.x', prompt, text: 'Yes it is.', runId: 'r2' }) },
    { ok: true, memory: p.ingestReply({ seatName: 'B', host: 'b.x', prompt, text: 'No it is not.', runId: 'r2' }) },
  ];
  const dis = p.recordDisagreement('r2', diff);
  assert.equal(dis.kind, 'cross_disagreement');
  assert.equal(dis.claims.length, 2);
});

test('signatures — title is presentation, proposition and scope are identity', () => {
  assert.equal(claimSignature('The Sky  Is Blue'), claimSignature('the sky is blue'));
  assert.notEqual(claimSignature('the sky is blue', 'global'), claimSignature('the sky is blue', 'mars'));
  assert.equal(witnessSignature('outcome', 'run-1'), witnessSignature('OUTCOME', ' run-1 '));
});

// ===========================================================================
test('export/import — a passport can be carried, but status cannot', () => {
  const a = new Passport(tmpdir());
  for (let i = 0; i < 5; i++) a.propose(good({ metadata: { witness_kind: 'outcome', reference: `r${i}` } }));
  const { memory } = a.propose(good({ title: 'pinned thing', content: 'a pinned and adjudicated proposition' }));
  a.boundary.pin(memory.id, true);
  a.boundary.adjudicate(memory.id);

  const bundle = a.export();
  assert.equal(bundle.schema, 'forgeflight.passport.v1');
  const supported = bundle.claims.find((c) => c.status === 'supported');
  assert.ok(supported, 'the export records that a claim was supported');

  const b = new Passport(tmpdir());
  const res = b.importBundle(bundle);
  assert.ok(res.ok);
  assert.equal(res.imported, bundle.memories.length);

  for (const { claim, memory: m } of b.rows()) {
    assert.equal(claim.status, 'provisional', 'nothing arrives supported, however the file was edited');
    assert.equal(claim.confirmationCount, 0, 'an import brings no witnesses with it');
    assert.equal(m.adjudicatedAt, null, 'and no adjudication stamp');
    assert.equal(m.pinned, false, 'and nothing arrives pinned');
    assert.equal(m.origin, 'imported');
  }
  assert.ok(res.dropped.includes('status'), 'and it reports what it left behind');
  assert.match(res.detail, /cannot cross a file boundary/);
});

test('export/import — a hand-edited export still cannot launder a status', () => {
  const a = new Passport(tmpdir());
  a.propose(good());
  const bundle = a.export();
  // The attack: open the file, promote everything, import it somewhere else.
  for (const c of bundle.claims) {
    c.status = 'supported';
    c.confirmationCount = 99;
  }
  for (const m of bundle.memories) {
    m.adjudicatedAt = new Date().toISOString();
    m.pinned = true;
  }
  const b = new Passport(tmpdir());
  b.importBundle(bundle);
  const rows = b.rows();
  assert.ok(rows.length > 0);
  assert.ok(rows.every((r) => r.claim.status === 'provisional' && r.claim.confirmationCount === 0));
  assert.ok(rows.every((r) => !r.memory.adjudicatedAt && !r.memory.pinned));
});

test('export/import — a file that is not a passport is refused by name', () => {
  const b = new Passport(tmpdir());
  const res = b.importBundle({ schema: 'something.else', memories: [] });
  assert.equal(res.ok, false);
  assert.equal(res.reason, 'not-a-passport');
});
