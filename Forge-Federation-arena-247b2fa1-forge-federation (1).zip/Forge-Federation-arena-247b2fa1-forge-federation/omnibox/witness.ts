/**
 * witness.ts — plumbing-generated witnesses for the collective.
 *
 * The pilot never touches a witness. The harness plumbing does.
 * This file is the ONLY place a Witness is minted in production.
 * A fact that arrives with a witness the plumbing did not create
 * is refused at the gate — the witness is the receipt, not the claim.
 *
 * Two invariants this file enforces:
 * 1. A Witness carries the harnessId of the plumbing that created it.
 *    A pilot that forges a harnessId still has to forge a reference that
 *    passes per-kind format validation, and the reference must be precise
 *    enough to re-check (not "" or "x").
 * 2. References are per-kind: outcome = request/tool id, structural =
 *    content hash, contract = URL, human = named person. A human witness
 *    that says "12345" is not a person and is refused.
 */

import type { Witness, WitnessKind } from './types.ts'

// ── Per-kind reference shapes ───────────────────────────────────────────
// These are the real rules — gate.ts's old `length >= 3` was the proxy.
// Keep them permissive enough for tests but strict enough to catch
// fabricated witnesses (empty, placeholder, role-not-person).

const OUTCOME_RE = /^[a-zA-Z0-9:_-]{3,}$/
const STRUCTURAL_RE = /^(sha256:[a-f0-9]{64}|hash_[a-zA-Z0-9_-]+|artifact:[^\s]+|[a-zA-Z0-9:_\/.-]{3,})$/
const CONTRACT_RE = /^https?:\/\/.+/ // must be a URL — empty / bare path is not a contract
const HUMAN_RE = /^[a-zA-Z][a-zA-Z0-9 .'\-]{2,}$/ // starts with letter, at least 3 chars, contains a letter

function referenceOk(kind: WitnessKind, ref: string): string | null {
  if (typeof ref !== 'string' || !ref.trim()) return 'reference missing'
  const v = ref.trim()
  if (v.length < 3) return 'reference too short to re-check'
  switch (kind) {
    case 'outcome': {
      if (!OUTCOME_RE.test(v)) return 'outcome reference must be a request/tool id (alphanumeric, _, :, -)'
      return null
    }
    case 'structural': {
      if (!STRUCTURAL_RE.test(v)) return 'structural reference must be a content hash or artifact id'
      return null
    }
    case 'contract': {
      if (!CONTRACT_RE.test(v)) return 'contract reference must be a URL (https://...)'
      return null
    }
    case 'human': {
      if (!HUMAN_RE.test(v)) return 'human witness must name a person (at least 3 chars, starts with letter)'
      if (!/[a-zA-Z]/.test(v)) return 'human witness must contain a letter'
      // Reject pure-numeric or role-like strings — "12345", "the team" without a name is not a witness
      if (/^\d+$/.test(v.replace(/\s/g, ''))) return 'human witness must name a person, not a number'
      return null
    }
    default:
      return `unknown witness kind: ${kind}`
  }
}

export function validateWitnessReference(kind: WitnessKind, reference: string): string | null {
  return referenceOk(kind, reference)
}

// ── Factory — the only mint ─────────────────────────────────────────────

/**
 * Mint a plumbing witness. The harnessId is the plumbing's identity, never
 * the pilot's. observedAt defaults to now if not supplied.
 *
 * This is intentionally NOT constructable by pilot code — the HarnessRuntime
 * holds the harnessId and the clock, the pilot never sees them.
 */
export function createPlumbingWitness(params: {
  kind: WitnessKind
  harnessId: string
  reference: string
  observedAt?: string
}): Witness {
  const { kind, harnessId, reference } = params
  if (!harnessId || !harnessId.trim()) throw new Error('WITNESS_HARNESS_MISSING: plumbing harnessId is required')
  const problem = referenceOk(kind, reference)
  if (problem) throw new Error(`WITNESS_REFERENCE_INVALID: ${problem} — got "${reference}"`)
  const observedAt = params.observedAt ?? new Date().toISOString()
  if (Number.isNaN(Date.parse(observedAt))) throw new Error('WITNESS_TIME_INVALID: observedAt must be ISO timestamp')
  return { kind, harnessId: harnessId.trim(), reference: reference.trim(), observedAt }
}

// ── Convenience creators for plumbing code ───────────────────────────────

/**
 * Outcome = an action was taken and the world responded.
 * Reference is the plumbing's own request/tool id — e.g. `${missionId}:${toolCallId}` or `req_...`
 * The pilot never supplies this.
 */
export function outcomeWitness(
  harnessId: string,
  toolCallId: string,
  missionId?: string,
  observedAt?: string,
): Witness {
  const ref = missionId ? `${missionId}:${toolCallId}` : toolCallId
  return createPlumbingWitness({ kind: 'outcome', harnessId, reference: ref, observedAt })
}

export function structuralWitness(
  harnessId: string,
  artifactRef: string,
  observedAt?: string,
): Witness {
  return createPlumbingWitness({ kind: 'structural', harnessId, reference: artifactRef, observedAt })
}

export function contractWitness(
  harnessId: string,
  docUrl: string,
  observedAt?: string,
): Witness {
  return createPlumbingWitness({ kind: 'contract', harnessId, reference: docUrl, observedAt })
}

export function humanWitness(
  harnessId: string,
  person: string,
  observedAt?: string,
): Witness {
  return createPlumbingWitness({ kind: 'human', harnessId, reference: person, observedAt })
}

// ── Hash helpers — content-addressed structural refs ────────────────────────
// These produce `sha256:<hex>` which matches STRUCTURAL_RE above, so the gate
// accepts them. They hash RAW BYTES, never JSON.stringify(output).

import { createHash as _createHash } from 'crypto'

function _sha256Hex(input: string | Uint8Array): string {
  const h = _createHash('sha256')
  if (typeof input === 'string') h.update(input, 'utf8')
  else h.update(input)
  return h.digest('hex')
}

/** Hash arbitrary bytes/string to a structural ref `sha256:<hex>` */
export function hashToStructuralRef(input: string | Uint8Array): string {
  return `sha256:${_sha256Hex(input)}`
}

/**
 * Hash fetch body bytes -> structural ref.
 * Takes Uint8Array, Buffer, or string. RAW BYTES only.
 */
export function hashFetchBodyToRef(body: Uint8Array | Buffer | string): string {
  return hashToStructuralRef(typeof body === 'string' ? body : (body as Uint8Array))
}

/**
 * Hash a DOM snapshot string -> structural ref, after canonicalizing
 * (CRLF->LF, trim trailing whitespace per line, overall trim).
 */
export function hashDomSnapshotToRef(snapshot: string): string {
  const canon = snapshot.replace(/\r\n/g, '\n').split('\n').map(l => l.trimEnd()).join('\n').trim()
  return hashToStructuralRef(canon)
}

// ── Guard — is this witness plumbing-generated? ──────────────────────────

/**
 * A pilot-submitted witness that happens to look valid is still distinguishable:
 * in production, the harness re-generates the witness from its own plumbing
 * and compares. This helper is for that comparison — the harness never trusts
 * the witness the pilot attached, it mints its own and the gate checks the
 * minted one.
 */
export function isPlumbingWitnessFormat(w: Witness): boolean {
  return referenceOk(w.kind, w.reference) === null
}
