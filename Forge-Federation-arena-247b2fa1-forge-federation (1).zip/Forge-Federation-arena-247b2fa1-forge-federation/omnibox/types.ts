/**
 * types.ts — the collective's vocabulary.
 *
 * The collective IS the oracle. It holds facts, not opinions.
 * A fact enters only if it is ESTABLISHED (a witness can point at what
 * made it true) and CONSISTENT (it contradicts nothing already held).
 *
 * Consistency alone is not enough — a well-formed lie contradicts nothing.
 * Establishment alone is not enough — a real outcome can still conflict
 * with a real prior fact, and that conflict must surface, not resolve.
 *
 * Both gates. Always. In that order.
 */

// ── Subject / Predicate / Object ──────────────────────────────────────────
// Facts arrive already structured. The collective never parses prose.

/** A thing a fact can be about. Namespaced to avoid collisions across
 *  contributors: "endpoint:api.stripe.com/v1/charges", "schema:orders.amount" */
export type Subject = string

/** What is being asserted about the subject. Closed vocabulary — a
 *  contributor cannot invent predicates, because an unknown predicate has
 *  no contradiction rule and would enter unchecked. */
export type Predicate =
  | 'accepts_field'        // endpoint accepts a named field
  | 'rejects_field'        // endpoint rejects a named field
  | 'requires_field'       // field must be present
  | 'field_type'           // field has this type
  | 'field_max_length'     // numeric bound
  | 'field_min_length'
  | 'allows_method'        // HTTP method permitted
  | 'denies_method'
  | 'rate_limit_per_min'   // numeric
  | 'returns_status'       // status code observed for a shape of request
  | 'element_has_id'       // DOM: element carries this stable id
  | 'element_absent'       // DOM: no element with this id
  | 'exists'               // the subject exists at all
  | 'not_exists'

/** The value side. Kept to primitives — no nested objects, because
 *  nesting hides structure the contradiction rules need to see. */
export type FactValue = string | number | boolean

// ── Witness ───────────────────────────────────────────────────────────────
// The answer to "how do you know?" A fact with no witness is an opinion
// wearing a fact's clothes.

export type WitnessKind =
  /** An action was taken and the world responded. Self-labelling: the
   *  outcome is the evidence. Strongest kind. */
  | 'outcome'
  /** Re-derivable from an artifact anyone can inspect. A schema, a DOM,
   *  a response body. Checkable on demand without asking anyone. */
  | 'structural'
  /** A published contract: docs, an OpenAPI spec, a rate limit header. */
  | 'contract'
  /** A named human ruled on it. Weakest, and the only kind that carries
   *  a person's name into the record. */
  | 'human'

export interface Witness {
  kind: WitnessKind
  /** Where this came from, precisely enough to re-check.
   *  outcome: the request id / mission id that produced it
   *  structural: the artifact hash or URL
   *  contract: the doc URL and section
   *  human: the person's identifier */
  reference: string
  /** Which harness submitted it. Never used to decide truth — only to
   *  count independence and to trace a bad contributor after the fact. */
  harnessId: string
  /** When the witnessing happened (not when it was submitted). */
  observedAt: string
}

// ── Fact record ───────────────────────────────────────────────────────────

export interface FactRecord {
  subject: Subject
  predicate: Predicate
  value: FactValue
  witness: Witness
  /** Contingent facts describe a mutable thing and can expire.
   *  Invariant facts follow from structure and cannot.
   *  Everything derived from a contingent fact inherits its contingency. */
  stability: 'invariant' | 'contingent'
}

/** A fact that has passed both gates and lives in the collective. */
export interface EstablishedFact extends FactRecord {
  /** Deterministic id: hash of subject+predicate+value. Same fact from two
   *  harnesses produces the same id — that is how independence is counted. */
  factId: string
  /** Every witness that has independently established this same fact.
   *  More witnesses does NOT make it more true. It makes a later
   *  contradiction easier to adjudicate and cheaper to trace. */
  witnesses: Witness[]
  admittedAt: string
}

// ── Verdicts ──────────────────────────────────────────────────────────────

export type AdmitVerdict =
  | { status: 'admitted'; fact: EstablishedFact }
  /** Same fact already held; witness appended, nothing else changed. */
  | { status: 'corroborated'; fact: EstablishedFact }
  /** Rejected. The collective does not repair, negotiate, or average. */
  | { status: 'refused'; reason: RefusalReason; detail: string }
  /** Directly contradicts a held fact. NEITHER is trusted from here on —
   *  both are quarantined until a human rules. This is the only outcome
   *  that can make the collective smaller. */
  | { status: 'conflict'; incumbent: EstablishedFact; challenger: FactRecord }

export type RefusalReason =
  /** No witness, or a witness with no usable reference. */
  | 'UNWITNESSED'
  /** Predicate not in the closed vocabulary. */
  | 'UNKNOWN_PREDICATE'
  /** Value type doesn't match what the predicate requires. */
  | 'TYPE_MISMATCH'
  /** Internally impossible before it ever meets the store —
   *  e.g. a negative rate limit, min_length above max_length. */
  | 'SELF_INCONSISTENT'
  /** The subject is currently quarantined by an unresolved conflict. */
  | 'SUBJECT_QUARANTINED'
  /** Malformed record. */
  | 'MALFORMED'

// ── Query ─────────────────────────────────────────────────────────────────

/** The collective answers exactly three things. Note there is no
 *  "is this true?" — only "do I hold it" and "is it ruled out." */
export type QueryResult =
  /** Held, with the receipts. */
  | { answer: 'established'; fact: EstablishedFact }
  /** Contradicts something held. This is the valuable answer —
   *  provably impossible given what is established. */
  | { answer: 'impossible'; because: EstablishedFact[] }
  /** Not held and not ruled out. The honest majority answer. */
  | { answer: 'unknown' }
  /** Held facts about this subject conflict; nothing can be said. */
  | { answer: 'quarantined'; conflicts: Conflict[] }

export interface Conflict {
  subject: Subject
  predicate: Predicate
  incumbent: EstablishedFact
  challenger: FactRecord
  detectedAt: string
  resolvedBy: string | null
}
