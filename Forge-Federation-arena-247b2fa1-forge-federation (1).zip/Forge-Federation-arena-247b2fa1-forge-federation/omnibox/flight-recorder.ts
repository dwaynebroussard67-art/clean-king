import type { MissionEvent } from './contracts.ts';
import type { Skill, SkillStep } from './packs.ts';

/**
 * THE FLIGHT RECORDER
 *
 * The plane is not the pilot. Pilots are interchangeable and they come and go.
 * What makes the plane worth more after each flight is that it kept the flight.
 *
 * Two things get recorded, and they answer two different questions:
 *
 *   GAPS  -- what did a pilot reach for that this plane does not carry?
 *            A pilot asking for a tool we do not have is not an error to be
 *            thrown away. It is the most direct signal we will ever get about
 *            what to build next, and it is free.
 *
 *   MOVES -- what sequence of capabilities did a pilot actually fly, and did it
 *            work? A sequence that keeps working is a skill the plane has been
 *            taught by watching, rather than one somebody sat down and authored.
 *
 * Promotion follows the rule the flight manual already settled in §5.2 rather
 * than inventing a second one: repetition promotes, a single contradiction
 * blocks, and silence is not a vote. A manoeuvre that succeeded five times and
 * failed once is not a skill -- it is a manoeuvre with a failure mode nobody has
 * characterised yet.
 *
 * What a learned skill is NOT: authority. It is a plan template like any other.
 * Every step in it still passes the gate individually, and a skill learned from
 * a pilot who had a capability granted does not carry that grant to a pilot who
 * does not. The plane learning to fly itself means it stops needing to be told
 * the sequence, not that it stops asking before it changes the world.
 */

export const PROMOTE_AFTER = 5;

export type CapabilityGap = {
  capabilityId: string;
  /** 'not_mounted' -- nobody provides it. 'not_granted' -- it exists, this mission may not reach it. */
  reason: 'not_mounted' | 'not_granted';
  /** Free text from the pilot about what it was trying to accomplish. */
  intent?: string;
  missionId: string;
  observedAt: string;
};

export type Manoeuvre = {
  /** The ordered capability ids the pilot flew. */
  sequence: string[];
  signature: string;
  successes: number;
  failures: number;
  missionIds: string[];
  firstSeen: string;
  lastSeen: string;
};

export type GapReport = {
  capabilityId: string;
  requests: number;
  missions: number;
  reason: 'not_mounted' | 'not_granted';
  intents: string[];
};

function signatureOf(sequence: string[]): string {
  return sequence.join(' -> ');
}

export class FlightRecorder {
  private readonly gaps: CapabilityGap[] = [];
  private readonly manoeuvres = new Map<string, Manoeuvre>();
  private readonly promoted = new Set<string>();

  recordGap(gap: CapabilityGap): void {
    this.gaps.push(gap);
  }

  /**
   * Record one completed manoeuvre: the sequence a pilot flew and whether it
   * worked. Sequences of one are ignored -- a single call is not a skill, it is
   * a tool, and the plane already has it.
   */
  recordManoeuvre(input: {
    missionId: string;
    sequence: string[];
    succeeded: boolean;
    at?: string;
  }): Manoeuvre | null {
    if (input.sequence.length < 2) return null;
    const signature = signatureOf(input.sequence);
    const at = input.at ?? new Date().toISOString();
    const existing = this.manoeuvres.get(signature);
    if (existing) {
      if (input.succeeded) existing.successes += 1;
      else existing.failures += 1;
      if (!existing.missionIds.includes(input.missionId)) existing.missionIds.push(input.missionId);
      existing.lastSeen = at;
      return existing;
    }
    const created: Manoeuvre = {
      sequence: [...input.sequence],
      signature,
      successes: input.succeeded ? 1 : 0,
      failures: input.succeeded ? 0 : 1,
      missionIds: [input.missionId],
      firstSeen: at,
      lastSeen: at,
    };
    this.manoeuvres.set(signature, created);
    return created;
  }

  /**
   * Rebuild the flight from a mission's own event spine. Preferred over live
   * recording because the spine is the durable record -- if it is not in the
   * events, it did not happen, and a recorder that knows more than the audit
   * trail is a recorder that can be wrong without anyone noticing.
   */
  ingestEvents(missionId: string, events: MissionEvent[]): Manoeuvre | null {
    const sequence: string[] = [];
    let anyFailed = false;
    for (const event of events) {
      const payload = event.payload as Record<string, unknown>;
      if (event.type === 'capability_gap') {
        this.recordGap({
          capabilityId: String(payload.capabilityId),
          reason: (payload.reason as CapabilityGap['reason']) ?? 'not_mounted',
          intent: payload.intent ? String(payload.intent) : undefined,
          missionId,
          observedAt: event.createdAt,
        });
      }
      if (event.type === 'tool_invoked') {
        sequence.push(String(payload.capabilityId));
        if (payload.status === 'failed') anyFailed = true;
      }
    }
    return this.recordManoeuvre({ missionId, sequence, succeeded: !anyFailed });
  }

  /**
   * What the pilots wanted and this plane could not give them, worst first.
   * This is the build queue, written by use rather than by opinion.
   */
  gapReport(): GapReport[] {
    const byCapability = new Map<string, GapReport>();
    for (const gap of this.gaps) {
      const existing = byCapability.get(gap.capabilityId);
      if (existing) {
        existing.requests += 1;
        if (!existing.intents.includes(gap.intent ?? '') && gap.intent) existing.intents.push(gap.intent);
        continue;
      }
      byCapability.set(gap.capabilityId, {
        capabilityId: gap.capabilityId,
        requests: 1,
        missions: 0,
        reason: gap.reason,
        intents: gap.intent ? [gap.intent] : [],
      });
    }
    for (const [capabilityId, report] of byCapability) {
      const forCapability = this.gaps.filter((gap) => gap.capabilityId === capabilityId);
      report.missions = new Set(forCapability.map((gap) => gap.missionId)).size;
      // Every distinct thing a pilot said it was trying to do. This is the part
      // that tells you WHAT to build, not just that something is missing.
      report.intents = [...new Set(
        forCapability.map((gap) => gap.intent).filter((intent): intent is string => Boolean(intent)),
      )];
    }
    return [...byCapability.values()].sort((a, b) => b.requests - a.requests || a.capabilityId.localeCompare(b.capabilityId));
  }

  manoeuvreReport(): Manoeuvre[] {
    return [...this.manoeuvres.values()].sort(
      (a, b) => b.successes - a.successes || a.signature.localeCompare(b.signature),
    );
  }

  /**
   * Manoeuvres that have earned promotion: flown enough times, never
   * contradicted by a failure, and seen on more than one mission.
   *
   * The multi-mission requirement is the one that is easy to leave out and
   * expensive to leave out. Five successes inside a single mission is one pilot
   * repeating itself in one context, which is exactly the amplified-error case
   * the manual warns about in C1. Five successes across five missions is
   * evidence.
   */
  promotable(): Manoeuvre[] {
    return this.manoeuvreReport().filter(
      (manoeuvre) => manoeuvre.successes >= PROMOTE_AFTER
        && manoeuvre.failures === 0
        && manoeuvre.missionIds.length > 1
        && !this.promoted.has(manoeuvre.signature),
    );
  }

  /**
   * Turn an earned manoeuvre into a skill the plane owns. Returns the skill and
   * the evidence behind it, because a learned skill with no receipt is exactly
   * the fabricated reasoning history the manual forbids.
   */
  promote(signature: string): { skill: Skill; evidence: string[] } {
    const manoeuvre = this.manoeuvres.get(signature);
    if (!manoeuvre) throw new Error(`no manoeuvre recorded for: ${signature}`);
    if (manoeuvre.failures > 0) {
      throw new Error(`manoeuvre has ${manoeuvre.failures} failure(s); a contradiction blocks promotion`);
    }
    if (manoeuvre.successes < PROMOTE_AFTER) {
      throw new Error(`manoeuvre has ${manoeuvre.successes} successes; ${PROMOTE_AFTER} are required`);
    }

    const steps: SkillStep[] = manoeuvre.sequence.map((capabilityId, index) => ({
      id: `step-${index + 1}`,
      description: `Observed step ${index + 1}: ${capabilityId}`,
      capabilityId,
    }));

    const id = `learned.${manoeuvre.sequence.map(slug).join('-')}`.slice(0, 120);
    this.promoted.add(signature);

    return {
      skill: {
        id,
        name: `Learned: ${manoeuvre.sequence.join(' then ')}`,
        description:
          `A sequence flown successfully ${manoeuvre.successes} times across ${manoeuvre.missionIds.length} missions, never failed. Learned by observation, not authored.`,
        requiredCapabilityIds: [...new Set(manoeuvre.sequence)],
        steps,
      },
      // Mission ids are the observable artifacts. A reader can replay each one.
      evidence: manoeuvre.missionIds.map((missionId) => `mission://${missionId}`),
    };
  }
}

function slug(capabilityId: string): string {
  return capabilityId.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '').toLowerCase();
}
