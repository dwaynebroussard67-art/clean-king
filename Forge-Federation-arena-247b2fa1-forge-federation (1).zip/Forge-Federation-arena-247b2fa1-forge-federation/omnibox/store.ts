/**
 * store.ts — what the collective holds, and how it answers.
 *
 * Two rules that make this different from a database:
 *
 * 1. A CONFLICT QUARANTINES THE SUBJECT. When two established facts
 *    contradict, the collective does not pick a winner, average them, or
 *    prefer the newer one. It stops answering about that subject entirely
 *    until a named human rules. Picking a winner is the moment an oracle
 *    starts having opinions.
 *
 * 2. THE COLLECTIVE NEVER SAYS "TRUE". It says "established" (I hold this,
 *    here are the receipts), "impossible" (this contradicts what I hold),
 *    "unknown" (I have nothing), or "quarantined" (what I hold is broken).
 *    "Unknown" is the honest majority answer and it is not a failure.
 */

import type {
  EstablishedFact,
  FactRecord,
  Conflict,
  QueryResult,
  Predicate,
  FactValue,
} from './types.ts'
import { PREDICATES, factId, type FactStore } from './gate.ts'

export class Collective implements FactStore {
  private facts = new Map<string, EstablishedFact>()
  private subjectIndex = new Map<string, Set<string>>()
  private conflicts: Conflict[] = []
  private quarantined = new Set<string>()

  // ── FactStore surface (used by the gate) ────────────────────────────────

  get(id: string): EstablishedFact | undefined {
    return this.facts.get(id)
  }

  bySubject(subject: string): EstablishedFact[] {
    const ids = this.subjectIndex.get(subject)
    if (!ids) return []
    const out: EstablishedFact[] = []
    for (const id of ids) {
      const f = this.facts.get(id)
      if (f) out.push(f)
    }
    return out
  }

  put(fact: EstablishedFact): void {
    this.facts.set(fact.factId, fact)
    let ids = this.subjectIndex.get(fact.subject)
    if (!ids) {
      ids = new Set()
      this.subjectIndex.set(fact.subject, ids)
    }
    ids.add(fact.factId)
  }

  isQuarantined(subject: string): boolean {
    return this.quarantined.has(subject)
  }

  // ── Conflict handling ───────────────────────────────────────────────────

  /**
   * Called when the gate returns a conflict. Records it and quarantines the
   * subject. The incumbent stays in the store but the subject stops
   * answering — we do not delete established facts on the word of a
   * challenger, and we do not trust them either.
   */
  recordConflict(incumbent: EstablishedFact, challenger: FactRecord): Conflict {
    const conflict: Conflict = {
      subject: challenger.subject,
      predicate: challenger.predicate,
      incumbent,
      challenger,
      detectedAt: new Date().toISOString(),
      resolvedBy: null,
    }
    this.conflicts.push(conflict)
    this.quarantined.add(challenger.subject)
    return conflict
  }

  /**
   * A named human rules. This is the ONLY way a subject leaves quarantine.
   * No timeout, no majority, no "newer wins" — those are all ways for the
   * oracle to start guessing.
   *
   * keep: 'incumbent' leaves the store as it was.
   * keep: 'challenger' retracts the incumbent and admits the challenger.
   * keep: 'neither' retracts both — the honest answer when a human looks and
   *       cannot tell either.
   */
  resolveConflict(
    subject: string,
    keep: 'incumbent' | 'challenger' | 'neither',
    ruledBy: string
  ): { resolved: number } {
    if (!ruledBy || !/[a-zA-Z]/.test(ruledBy))
      throw new Error('RESOLUTION_UNSIGNED: a conflict resolution must name a person')

    const open = this.conflicts.filter(c => c.subject === subject && !c.resolvedBy)
    if (open.length === 0) return { resolved: 0 }

    for (const c of open) {
      if (keep === 'challenger' || keep === 'neither') {
        this.retract(c.incumbent.factId)
      }
      if (keep === 'challenger') {
        const id = factId(c.challenger.subject, c.challenger.predicate, c.challenger.value)
        this.put({
          ...c.challenger,
          factId: id,
          witnesses: [c.challenger.witness],
          admittedAt: new Date().toISOString(),
        })
      }
      c.resolvedBy = ruledBy
    }

    this.quarantined.delete(subject)
    return { resolved: open.length }
  }

  private retract(id: string): void {
    const fact = this.facts.get(id)
    if (!fact) return
    this.facts.delete(id)
    this.subjectIndex.get(fact.subject)?.delete(id)
  }

  openConflicts(): Conflict[] {
    return this.conflicts.filter(c => !c.resolvedBy)
  }

  // ── Query ───────────────────────────────────────────────────────────────

  /**
   * The whole point. Ask whether a proposed fact is established, ruled out,
   * or simply unknown.
   *
   * "impossible" is the answer worth paying for: it means a plan can be
   * abandoned before it is attempted, and the reason can be shown.
   */
  ask(subject: string, predicate: Predicate, value: FactValue): QueryResult {
    if (this.quarantined.has(subject)) {
      return {
        answer: 'quarantined',
        conflicts: this.conflicts.filter(c => c.subject === subject && !c.resolvedBy),
      }
    }

    const id = factId(subject, predicate, value)
    const held = this.facts.get(id)
    if (held) return { answer: 'established', fact: held }

    const contract = PREDICATES[predicate]
    if (!contract) return { answer: 'unknown' }

    const because: EstablishedFact[] = []
    for (const other of this.bySubject(subject)) {
      // Excluded by a mutually exclusive predicate on the same value.
      if (contract.excludes.includes(other.predicate) && other.value === value) {
        because.push(other)
      }
      // Single-valued predicate already holds a different value.
      if (
        contract.singleValued &&
        other.predicate === predicate &&
        other.value !== value
      ) {
        because.push(other)
      }
    }

    if (because.length > 0) return { answer: 'impossible', because }
    return { answer: 'unknown' }
  }

  // ── Introspection ───────────────────────────────────────────────────────

  size(): number {
    return this.facts.size
  }

  subjects(): string[] {
    return [...this.subjectIndex.keys()]
  }

  /** Facts whose contingent premises may have gone stale. A contingent fact
   *  older than the window is not wrong — it is unverified, and the caller
   *  should know the difference. */
  staleContingent(olderThanMs: number): EstablishedFact[] {
    const cutoff = Date.now() - olderThanMs
    return [...this.facts.values()].filter(
      f => f.stability === 'contingent' && Date.parse(f.admittedAt) < cutoff
    )
  }

  /** Every held fact. A view, never a grant. */
  listFacts(): EstablishedFact[] {
    return [...this.facts.values()]
  }

  /**
   * Empty the in-memory store. Process memory only — there is no durable
   * collective yet, so this cannot destroy a receipt that lived on disk.
   * Named `reset` rather than `clear` so it cannot be mistaken for
   * conflict resolution.
   */
  reset(): void {
    this.facts.clear()
    this.subjectIndex.clear()
    this.conflicts = []
    this.quarantined.clear()
  }
}
