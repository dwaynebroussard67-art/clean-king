# Forge Flight

**A browser whose tabs are seats.** Open an AI in a tab and that tab *is* a
seat at the table. No boarding, no keys, no picker, no extension. Type once in
the box at the bottom and every seat hears it.

```
npm install
npm start
```

That is the whole setup. No API keys, no accounts, no config file. Forge Flight
stores no credentials — you log in to each site the ordinary way, inside
Forge Flight, and the browser holds the session the way a browser does.

**Your session resumes itself.** The logins live in the browser's own
persistent profile, so they were always waiting for you; what a restart used
to lose was the list of which AIs you had open. Now the tab list, which one
was in front, who was arguing which side, and any composer box you picked by
hand are all saved, and the table is back the moment you open Forge Flight. A
**Resume** button in the tab strip brings it back on purpose after a crash or
after you closed it by hand. Nothing in that file is a credential — it is a
list of places, and opening them is all a resume does.

---

## What actually happens

1. You open a tab and go to an AI chat. Anything with a chat box.
2. Forge Flight looks at the page and decides whether it is a chat surface. If it
   is, the tab joins the rail on the left as a seat, named after the site.
3. You type one prompt in the dock at the bottom and pick a shape.
4. Every seat gets typed into, sent, and watched. The replies stream back side
   by side.
5. Every reply lands in the Memory Passport as a *candidate* memory with the
   seat, the prompt, and the timestamp attached.

**If Forge Flight cannot tell which box on a page is the composer, it does not
guess.** The seat shows as `ambiguous`, names the elements it could not choose
between and which signals they tied on, and gives you a "Pick the box" button
that lets you point at the right one. That choice is remembered.

Every refusal has its own name and its own sentence:

| Verdict | What it means |
|---|---|
| `ambiguous` | Two editables scored too close together. Names the tied signals. |
| `document-field` | The editable scrolls away with the page and nothing calls it a message box. A comment form, not a conversation. |
| `below-floor` | Nothing on the page scores like a chat surface. |
| `cross-origin-frame` | The chat is in a frame from another site, which Forge Flight may not read. Open it in its own tab. |
| `no-candidates` | No visible editable at all — including a closed shadow root, which nobody can enter. |

That refusal is the product, not a rough edge. Every other multi-AI tool ships
a list of CSS selectors per provider and silently types into the wrong field —
or into nothing — the week a provider ships a redesign. Forge Flight contains no
provider names and no selector list anywhere in its source. It identifies the
composer structurally, and when the structure is ambiguous it says so.

---

## The rules, enforced in code

These are in the source, not in this file, because a rule that lives only in a
README is not a rule.

| Rule | Where |
|---|---|
| **User-triggered only.** No scheduler, no polling, no background querying. A run exists because you pressed send. Multi-round shapes declare their rounds up front, are capped at 4, and can be stopped. | `src/main/table.js` |
| **One seat per host.** Two tabs on the same site cannot both be seated. Forge Flight fans a prompt across *different* services, never across several accounts on one service. | `src/main/seats.js` |
| **A session is a list of places, not a bag of credentials.** Resuming reopens URLs through the allowlist (`https`, loopback, Forge Flight's own pages) in the profile that already holds the logins. No cookie, token, prompt or reply is ever written to it, and a resumed tab is compared by host — because one seat per host is the law. | `src/main/session.js` |
| **A remembered pick is a hint, never a verdict.** A composer you chose by hand is replayed only onto an element whose recomputed stamp matches exactly, on the host it was chosen on. No match: the ordinary verdict stands and the page asks again. | `src/main/picks.js` |
| **Human pacing.** Seats are staggered and each seat has a floor on how often it can be sent to. | `src/main/table.js` |
| **Read back before send.** The composer must read back exactly what was typed into it, or nothing is sent to that seat. | `src/preload/inject.js` |
| **Furniture is not a reply.** Growth that is a click reaction, lives in a nav/aside/menu region, or would capture mid-word can never become "the answer." If only furniture grew, the seat says `empty-response` instead of ingesting page chrome as a fact. | `src/preload/watch.js` |
| **Facts that reduce cleanly merge by equation, never by fuzzy match.** A fact may carry an equation — `capital(france) = paris` — and differently-worded statements of the same fact are one claim. A model nominates the equation; code decides (shape + grounding). If the reduction is not clean, the claim keeps its prose form and merges with nothing. Vectors stay ruled out. | `src/passport/equation.js` |
| **The history is tamper-evident.** Every line of the passport's log carries the hash of the line before it; editing the past is detectable by recomputation. A break is reported, never hidden — and never fatal. | `src/passport/store.js` |
| **The local seat is a tab, not an app feature.** A free local model (Ollama or LM Studio, no key, no account) joins the table through the same structural detection as any website — and it wears the passport's boot block for every answer. No local server running is an honest named refusal. | `src/main/localLLM.js` |
| **Engine-training records never touch the Memory Passport.** Anchor choices, losers, outcomes and human picks go to their own append-only log; prompts and replies are stripped by name before anything is written. | `src/main/anchors.js` |
| **A model cannot stamp its own adjudication.** Privileged fields on a write are refused by name. | `src/passport/writeBoundary.js` |
| **A seated anchor can be ruled on, and the ruling is the oracle.** "Box is right" / "wrong box" in the seat sheet writes a `confirm` record keyed by the anchor's stability key; the field-evidence scorer joins it to the claim by exact url. No rulings means no rate (null, never 0.0); outcomes never adjudicate. | `src/field-evidence/scorer.mjs` |
| **A pilot acts from a closed verb set, and refuses to guess.** Four slots, twelve steps, one strict-JSON verb per step. A click or type matching several elements stops the flight with the count named; prose instead of JSON is `bad-json`. Every step is recorded as verb + refusal only — never the target or the words. | `src/main/pilots.js` |
| **The address bar remembers places, nothing else.** The last 200 restorable URLs + titles live in their own file and power mid-URL suggestions. A corrupt file reads as an empty list, never a crash. | `src/main/history.js` |

---

## Shapes

| Shape | What it does |
|---|---|
| **Solo** | Just the tab you are looking at. An ordinary browser. |
| **Communal** | Everyone hears the same question at the same time. |
| **Sides** | Split the table: one side argues for, the other against. Each is asked to name its own weakest point. Assign For / Against / Sit out per seat in the rail. |
| **Adversarial** | One seat answers. The rest are shown that answer and asked to break it — or to say it is sound and name the strongest remaining objection. |
| **Relay** | The draft moves down the line. Each hand improves it and says in one line what it changed. |
| **Interview** | One seat is asked for the single question that would change the most. That question goes to the rest. |

---

## The Memory Passport

Every reply is a candidate memory, and nothing more than that. It enters
`provisional`, unpinned, unadjudicated, at low confidence, with an evidence
pointer naming the seat and the run.

- A claim needs **five distinct witnesses** to be promoted. Repetition is not
  evidence: the same seat saying the same thing ten times is one witness.
- **One contradiction closes a claim.** It does not decrement a tally.
- `supported` is the ceiling. Nothing is ever `settled`.
- A boot block always ends with the **exclusion audit** — what you were *not*
  given, and why. Visibly absent, never quietly missing.
- Nothing auto-deletes.

Because four seats asked one question at one moment are four distinct
witnesses arriving together, cross-provider agreement is a real confirmation
count, and cross-provider disagreement is a contradiction *happening now* as
distinct from drift over time. Both are recorded as events.

The store is an append-only JSONL log at
`<userData>/passport/passport.jsonl` — no native modules, no database to
install, greppable by hand, and a torn final line is dropped and counted
rather than crashing the app.

**Export and Import** in the Memory pane carry it between machines. Import is
a *translation*, not a restore: every record is reduced to the fields a writer
may set, and status, witness counts, pins and adjudication are left behind and
reported by name. Editing `"status": "supported"` into the file changes
nothing — everything still arrives provisional with zero witnesses.

---

## The Carrier

The passport is the helmet — clamped to whatever is flying, session-scoped.
The **Federation** is the carrier: where knowledge lands, not where it lives.

It stores **equations**, never prose. `capital(france) = paris` is one claim
however it was worded, which is what makes contradiction *computable* — same
left side, different right side, a machine check rather than a judgment call.

**Two shelves, two clocks.** World claims don't expire: five distinct
witnesses promote, one contradiction closes, permanently. Operational facts
are scoped to a target that mutates — when a site redesigns, the old fact
didn't become wrong, it *expired*, so it is superseded rather than closed.
Nothing is ever deleted on either shelf; the store has no delete method and
the tests assert its absence.

**Four ways in, and agreement is not one of them.** `outcome` (an action
succeeded), `structural` (re-derivable by anyone), `contract` (published),
`human` (a ruling, with the human named). A thousand nodes agreeing is exactly
what an unlistening oracle exists to be immune to.

### Mission control

The **curator** watches the carrier. It sees more than any pilot — that is the
job — and *more knowledge is not more authority*. It reads everything and
writes to exactly one place: an append-only proposal queue. It cannot send,
cannot fly, cannot mount a capability.

The triangle is three machines: a **reader** that proposes and cannot promote,
an **overseer** that decides and never reads the page, an **oracle** that does
not listen. **You are step four, outside it** — and that is what makes it
airtight rather than weaker. Because the overseer is blind and mechanical,
persuasion has already failed as a strategy before anything reaches you. You
are not the defence. You are the release.

And a denial is safe to trust because it *cannot be an opinion*:

```
Pilot 3 requested browser.fetch.
Its preconditions assumed rate_limit(claude.ai) = 100.
Federation holds rate_limit(claude.ai) = 0 — 3 witnesses, provisional,
since 2026-08-30. Constraint rate_limit(claude.ai) fails.
Denied pending your call.
```

Four seconds to check. A thing that must show its work cannot accumulate
authority.

**The queue size is an alarm, not a feeling.** The whole design rests on the
funnel narrowing — math eliminates, and what reaches you is the residue it
genuinely could not settle. If the queue grows past the alarm, the funnel
upstream has stopped working, and that is a defect with a name.

---

## Verifying it

```
npm run verify
```

Four stages, in order of cost. A stage whose tooling is missing reports
`SKIP`, never a silent pass.

| Stage | What it proves |
|---|---|
| `syntax` | Every source file parses. |
| `unit` | The passport's C1–C4 rules, the shapes, the seat rules, the address bar, the resume contract. |
| `ui` | The detector, the injector and the watcher in **real Chromium** against eleven fixture chat apps. |
| `e2e` | **The real app**, launched and driven end to end — including a quit-and-relaunch that requires the seats to come back. |

The unit stage is **102 checks**; `npm run verify` prints the running total
across all four. The `ui` and `e2e` stages need the Chromium and Electron
binaries that `npm install` fetches.

The fixtures are adversarial on purpose. Each one is a real failure mode:

| Fixture | What it is for |
|---|---|
| `ambiguous-two-composers` | Two identical composers side by side — must refuse, not coin-flip. |
| `comment-box-decoy` | An article with a comment box near a Post button — the classic false positive. |
| `rerender-chat` | Destroys and rebuilds its reply container on every token. **Found two real bugs.** |
| `virtualized-thread-chat` | Recycled rows churning forever underneath the reply. |
| `shadow-dom-chat` | Composer inside a web component's shadow root. **Found one real bug.** |
| `iframe-host` | The whole chat inside a frame. |
| `late-hydration-chat` | Nothing to seat for the first three and a half seconds. |
| `command-palette-chat` | A focused, centred palette input over a real chat. |

The e2e run serves three chat apps on three different loopback hosts, watches
them seat themselves, exercises the Sides assignment (including a seat sitting
out), sends through an embedded frame, and then exports the Passport, edits
every claim in the file to `supported` with 99 witnesses, imports it back, and
checks that everything still arrives provisional. It finishes by quitting the
app and relaunching it on the same profile: the seats must come back with
nothing opened by hand, on the sides they were assigned, and the Resume button
must bring them back again after the table is emptied by hand.

### Probing a real page

```
node tools/probe.mjs https://some-ai.example/chat
node tools/probe.mjs ~/Downloads/saved-chat.mhtml
```

Prints the verdict with every signal named and bar-charted. The `.mhtml` form
is the useful one: `Ctrl+S → Webpage, single file` on a logged-in chat, then
probe the saved copy. That is how you find out whether Forge Flight will seat a
site before you rely on it.

---

## Layout

```
src/
  detector/
    signals.js      named weighted signals + the lexicons (data, not code)
    detect.js       soundness-first composer detection; refusal is a verdict
  preload/
    seat.js         the tab-side agent — runs in every tab
    inject.js       the typing ladder + read-back verification
    watch.js        streamed-reply capture with no selectors
    chrome.js       the narrow bridge to the UI
  main/
    main.js         app, IPC, wiring
    tabs.js         real Chromium tabs in one persistent session
    seats.js        who is at the table; one seat per host
    table.js        fan-out and the conversation shapes
    session.js      the resume contract: a list of places, never a credential
    picks.js        composer boxes you chose by hand, remembered per host
    anchors.js      engine-training records — their own log, never the passport
    localLLM.js     the local-model seat's bridge (Ollama / LM Studio)
    profile.js      one-time adoption of an OmniBox profile (D26), plus the boot watch
                    that quarantines an adopted profile Chromium cannot open (D34)
  passport/         THE HELMET — session-scoped memory, C1–C4
    core.js         vocabularies, signatures, the placeholder encoder
    equation.js     D16 — claim identity for facts that reduce cleanly
    store.js        append-only, hash-chained JSONL persistence (D17)
    writeBoundary.js  C4 — the one way in
    trustGate.js    C3 — trust-weighted admission, τ = 0.10
    format.js       the read shape and the exclusion audit
    index.js        the facade: intake, boot block, export / import
  federation/       THE CARRIER — the Forge Federation, equations only
    store.js        two shelves, four witness kinds, hash-chained, no delete
    queue.js        the curator's ONLY write path: an append-only proposal queue
    curator.js      mission control: the overseer (blind, mechanical) + the curator
  renderer/         the chrome UI (local only; loads nothing remote)
mobile/             Forge Flight Pocket — the PWA and the Android WebView shell
tools/probe.mjs     "would Forge Flight seat this page, and why?"
docs/               decisions, patterns, handoff
FORGE-FLIGHT-MEMORY-SYSTEM.md   the memory system, exactly — every store, rule and constant
```

Everything a person accumulates lives under Electron's `userData` folder:

```
<userData>/
  Partitions/omnibox/      the cookie jar — your logins (name kept on purpose, D26)
  passport/passport.jsonl  the Memory Passport: claims, memories, events
  federation/federation.jsonl   the Forge Federation: landed facts + events
  federation/queue.jsonl        the curator's proposal queue
  anchors.jsonl            engine-training records (never conversation text)
  session.json             the tab list to resume (never a credential)
  picks.json               composer boxes you chose by hand, per host
  seats.json               renames and mutes, per host
```

## Using the clone on a phone

The desktop app is Electron, so it is not itself an Android or iOS binary.
This clone now includes a phone-first build instead of pretending Electron can
run on a phone:

- `npm run mobile` serves an installable **Forge Flight Pocket** PWA on port 4173.
  Open the computer's LAN address on a phone and choose **Add to Home Screen**.
  It provides the touch-first browser shell, tabs, recent pages, AI seat list,
  an always-available full-page fallback, and the same soundness-first copy.
- `mobile/android/` is a dependency-free Android Studio project for a real
  WebView browser. It loads pages directly in native tabs and injects the
  structural seat agent only into the current page. Build it from Android
  Studio to get an APK for a phone.

The PWA never proxies a website: pages that disallow iframe embedding get an
explicit **Open in browser** action. The Android wrapper is the path for full
in-app browsing. Nothing is merged upstream; these files are only on this
working clone/branch. Full setup and mobile limitations are in
[`mobile/README.md`](mobile/README.md).

The Electron chrome also has a `max-width: 720px` layout so the same UI remains
touchable when it is hosted by a mobile WebView.

## Building an installer

```
npm run dist        for the machine you are on
npm run dist:win    a Windows installer + a portable exe
```

electron-builder is fetched on demand rather than installed as a dependency,
so `npm install` keeps pulling electron and nothing else. Building for Windows
on Windows needs nothing extra; building for Windows from Linux or macOS needs
wine.

## Putting it on GitHub

```
npm run push new     a private repo of its own
npm run push sub     a subfolder of the repo you are standing in
```

It prints every command before running it, never force-pushes, and never
touches a branch you did not name.

## Known limits, named

- **Claim identity is normalized exact text.** Two seats that both answer
  "Paris" agree. "Paris" and "The capital of France is Paris" do not. Dense
  embeddings would produce confident wrong merges, which is the failure this
  whole system exists to avoid, so this is left visible rather than papered
  over. See `docs/DECISIONS.md` D7.
- **The encoder is a labelled placeholder** — deterministic feature hashing,
  swappable behind `(text) => Float64Array`. Retrieval numbers from it
  describe the mechanism, not semantic recall.
- **A cross-origin frame is refused, not reached into.** Widening Electron's
  subframe integration would hand a Node-capable world to every ad frame on
  every page. Named, with a sentence telling you to open the chat in its own
  tab. See D8.
- **A closed shadow root** cannot be entered by anyone, us included.
- **No passport restore.** Import is a translation by design (D13); restoring
  byte-for-byte is a different operation on a different trust footing.
- **A resume restores places, not logins.** The session file is a list of
  URLs; the credential was always the browser's, in its persistent profile. If
  a provider has since revoked it, the restored tab shows their login page and
  the seat is refused with a reason — Forge Flight has nothing to re-inject and does
  not pretend otherwise. See `docs/DECISIONS.md` D19.
- **A remembered pick does not survive a redesign.** The replay matches a
  stability key — identity fields plus structural path — so a provider that
  rebuilds its composer invalidates it. The replay then declines rather than
  guessing, the rail says the box you picked is gone, and the page asks again.
- **Nobody has run this against a real provider yet.** That needs your logins.
  `tools/probe.mjs` is how you find out before you rely on it.
