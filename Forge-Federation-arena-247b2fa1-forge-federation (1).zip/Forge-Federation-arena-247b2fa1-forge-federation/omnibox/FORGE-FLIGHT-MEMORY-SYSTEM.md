# Forge Flight — The Memory System, Exactly

**Status:** as of commit on branch `arena/01a06bdf-omnibox-browser`, 2026-09-04.
**Verified by:** 143/143 unit checks (`test/*.test.js`) plus a scripted
end-to-end smoke of the whole pipeline (three phrasings → one claim → five
witnesses → promotion → contradiction → closed → export → relabel attack →
import arrives provisional → hash chain catches a one-character edit →
federation denial names its variable → unsigned release refused).

This document is self-contained. Every constant, field name, file path, rule
and threshold below is lifted from the code, not paraphrased from a plan. Where
something is a placeholder, it says so. Where something is deliberately not
built, it says so. It is written to be re-uploaded on its own and used as the
ground truth for the next phase.

Names: the browser is **Forge Flight** (formerly OmniBox). The shared,
multi-node equation base is the **Forge Federation** (formerly "the
collective"). The passport is **the Memory Passport**, informally "the helmet".
The Federation is informally "the carrier"; each browser is a "cockpit".

---

## 0. The one-paragraph version

A Forge Flight run sends one prompt to several AI chats ("seats") in real tabs.
Every reply becomes a *candidate memory* — an observation, witnessed by the
seat that said it, at confidence 0.4, never a fact. Replies that reduce cleanly
to a `predicate(subject) = object` **equation** share one claim regardless of
wording; replies that don't keep their exact text as their identity and never
merge. A claim is promoted to `supported` only by **5 distinct witnesses**;
the same witness repeating counts once. **One contradiction closes** a claim
permanently. Nothing auto-deletes. Every write goes through **one boundary**
that **rejects by name** any attempt to pre-set status, counts or adjudication.
What a session actually receives is a **boot block**: a softmax over
trust-weighted similarity at **τ = 0.10**, under a token budget, followed by an
**exclusion audit** listing every memory that was withheld and why. Export is a
record, not an instruction — **import re-derives everything** (arrives
provisional, zero witnesses, no adjudication). Every log is **append-only JSONL
with a SHA-256 hash chain**. Above the passport sits the **Forge Federation**:
equations only, two shelves with two clocks, four witness kinds (agreement is
never one of them), a blind mechanical **overseer**, a **curator** that can
write to exactly one place (a proposal queue), and a **human** who is the only
party that can release — and must sign by name.

---

## 1. Where everything lives on disk

Electron `userData` (`~/.config/forgeflight` on Linux,
`~/Library/Application Support/forgeflight` on macOS,
`%APPDATA%\forgeflight` on Windows; overridable with `FORGEFLIGHT_USER_DATA`).

```
<userData>/
  Partitions/omnibox/           Chromium cookie jar = every login. Name KEPT on purpose (D26).
  passport/passport.jsonl       STORE 1  the Memory Passport (claims, memories, events)
  federation/federation.jsonl   STORE 2  the Forge Federation (facts, events)
  federation/queue.jsonl        STORE 3  the curator's proposal queue
  anchors.jsonl                 STORE 4  engine-training records (page anchors, outcomes, rulings)
  session.json                  STORE 5a the resume contract (a list of places, never a credential)
  picks.json                    STORE 5b composer boxes a person chose by hand, per host
  seats.json                    STORE 5c renames and mutes, per host
```

Persistence posture, shared by stores 1–4 (D10, D17):

- **Newline-delimited JSON, append-only.** A record is never rewritten in
  place; a change is a new line carrying the whole new record. State is
  rebuilt by replaying the file.
- **Hash-chained.** Each line is `{op, data, prev, hash}`.
  Passport: `hash = sha256(prev + "\u0000" + JSON.stringify({op, data}))`,
  genesis `prev = "0"×64`. Federation and queue: `sha256(prev + "|" + JSON.stringify(rec))`.
  `verify()` walks the file and reports `{line, kind}` breaks of kind
  `hash-mismatch`, `prev-mismatch`, or `unparseable`. Verified in the smoke:
  changing one word in line 1 → 1 break; deleting line 2 → `1:hash-mismatch,
  2:prev-mismatch`. Lines with neither `prev` nor `hash` are counted as
  `legacy` and accepted (pre-D17 files still load).
- **A torn final line is dropped on load and counted** (`corrupt`), never
  crashed on.
- **The `schema` field is a per-record label, never checked on read.** Old
  `omnibox.*`-stamped lines replay identically (tested).
- Human-readable, greppable, recoverable with `cat`.

The phone build (`mobile/`, Forge Flight Pocket) has **no memory system**. It
is a tab surface with its own `localStorage` state (`forgeflight-pocket-v1`,
adopting `omnibox-pocket-v1` once). It does not touch the passport or the
Federation. It is in the repo and it builds: PWA (`mobile/index.html`,
`app.js`, `sw.js`, `manifest.webmanifest`, `server.mjs`) and Android WebView
shell (`mobile/android/`, package `com.misfit.forgeflight.mobile`).

---

## 2. STORE 1 — The Memory Passport (`src/passport/`)

### 2.1 The four rules it is built on (C1–C4)

| Rule | Meaning | Where it is enforced |
|---|---|---|
| **C1** | Nothing auto-deletes and nothing hard-deletes. `retire()` is a soft mark. | `writeBoundary.js` |
| **C2** | The counting unit is the *distinct witness*. Five repetitions of one witness are one witness. Claim identity excludes the title (presentation). | `core.js` `witnessSignature`, `claimSignature` |
| **C3** | Admission to a context is trust-weighted, τ = 0.10, under a budget, with an exclusion audit. | `trustGate.js`, `format.js` |
| **C4** | One write path. A privileged field in a proposal is **rejected**, not stripped (C4a, D6). Import can never arrive pre-adjudicated. | `writeBoundary.js` |

### 2.2 Vocabularies (`core.js`)

```
CLAIM_STATUSES     = ['provisional', 'supported', 'contested', 'invalidated']
MEMORY_TYPES       = ['fact', 'preference', 'decision', 'rule']
WITNESS_KINDS      = ['outcome', 'structural', 'contract', 'human']
MEMORY_ORIGINS     = ['local', 'imported']
EXCLUSION_REASONS  = ['low-confidence', 'budget', 'contested', 'invalidated', 'stale', 'imported_unadjudicated']
PROMOTION_THRESHOLD = 5
DEFAULT_RECHECK_DAYS = 30
```

**The status ceiling is `supported`.** There is no `true`. The boot block says
so in its last line, every time.

### 2.3 The three record kinds

**Claim** — the thing that is counted. One per distinct proposition.

```
id                  'claim_<12 hex>'
signature           sha256(scope|normalized proposition)      (prose form)
                    or sha256('eq'|scope|subject|predicate|object|units|time)  (equation form)
questionText        the title of the first memory (presentation only; NOT in the signature)
proposition         the content of the first memory
scope               default 'global'
form                'prose' | 'equation'
equation            {subject, predicate, object, units, time} | null
status              'provisional' → 'supported' | 'contested' | 'invalidated'
confirmationCount   = witnessSignatures.length     (0 for a claim born by import)
contradictionCount  a count of record, not a tally that decrements anything
witnessSignatures   [sha256(witness_kind|reference), …]  — distinct by construction
validAt / invalidAt ISO timestamps; invalidAt is set by a contradiction
supersededBy        claim id | null
derivedFrom         [memory ids]
promotedAt          ISO | null
lastConfirmedAt     ISO | null
nextRecheckAt       lastConfirmedAt + 30 days — the drift clock
createdAt
```

**Memory** — one observation attached to a claim.

```
id                  'mem_<12 hex>'
claimId
type                one of MEMORY_TYPES
title, content, confidence (0..1), tags []
metadata            { witness_kind, reference, derived_from[], …anything else the writer sent }
pinned              boolean — set only by pin(), never by a proposal
origin              'local' | 'imported'
adjudicatedAt       ISO | null   — set only by adjudicate()
adjudicatedDigest   sha256(content) at adjudication time — a later edit is detectable
createdAt, updatedAt, retiredAt
```

**Event** — the trail. Kinds written today: `created`, `imported`,
`confirmed` (a new distinct witness), `contradicted`, `promoted`,
`adjudicated`, `adjudication_revoked`, `pinned` / `unpinned`, `deleted` (the
soft retire — the memory keeps its line, `retiredAt` is set), `superseded`,
`rechecked`, `intake_refused` (a reply the boundary would not take, logged
instead of thrown), `cross_agreement` / `cross_disagreement`. Every event
carries `actor` and `createdAt`; most carry `claimId`/`memoryId`, `evidence`
(the witness reference) and a `note`.

### 2.4 The write boundary (`writeBoundary.js`) — the only way in

Public operations and who calls them:

| Op | Actor default | Effect |
|---|---|---|
| `propose(raw, {actor, pin, at})` | `'model'` | validate → ingest as `origin:'local'`, one witness |
| `contradict(raw, {actor, at})` | `'model'` | validate → ingest with `isContradiction:true` |
| `import(raw, {actor, at})` | `'import'` | validate → ingest as `origin:'imported'`, **zero witnesses** |
| `adjudicate(memoryId)` | `'human'` | stamps `adjudicatedAt` + `adjudicatedDigest` |
| `revokeAdjudication(memoryId)` | `'human'` | clears both |
| `pin(memoryId, bool)` | `'human'` | pinned memories survive budget (not contested/invalidated) |
| `retire(memoryId)` | `'human'` | soft: `retiredAt` set; `liveMemories()` excludes it |
| `supersede(oldClaimId, newClaimId)` | `'human'` | the only way forward from a closed claim |
| `recheck(claimId)` | `'system'` | refreshes `nextRecheckAt` |

**Validation (`validate(raw)`), in order — each failure throws
`WriteBoundaryError(message, field)`:**

1. Must be a JSON object.
2. **C4a — privileged fields are rejected by name**, at the top level and inside
   `metadata`: `adjudicatedAt, adjudicated_at, adjudicatedDigest,
   adjudicated_digest, status, claimId, claim_id, pinned, confirmationCount,
   confirmation_count, promotedAt, promoted_at, id`. Message:
   `"status" is set by the passport, never by a writer. Remove it and propose again.`
3. `type` ∈ MEMORY_TYPES. `title` and `content` required (trimmed).
4. `confidence` a number in [0, 1].
5. `metadata` object required; `metadata.witness_kind` ∈ WITNESS_KINDS;
   `metadata.reference` required (a witness with no evidence pointer has no
   value); `metadata.derived_from` a list of ids if present; `tags` a list of
   strings if present.
6. If `metadata.equation` is present it is a **nomination**, run through
   `acceptEquation(nomination, content)` (§2.6). Rejected → the claim keeps
   prose form; accepted → `clean.equation` is canonical.

**Ingest (`ingest(clean, {origin, isContradiction, actor, pin, at})`):**

```
sig  = clean.equation ? equationSignature(eq, scope) : claimSignature(content, scope)
wsig = witnessSignature(metadata.witness_kind, metadata.reference)
claim = store.getClaimBySignature(sig)

if no claim:           create it, status 'provisional',
                       confirmationCount = imported ? 0 : 1, witnesses = imported ? [] : [wsig]
else if contradiction: contradictionCount+1, status 'contested', invalidAt = now
                       event 'contradicted' ("a single contradiction closed the claim")
else if claim closed:  attach the memory, change NOTHING on the claim
                       (a confirmation never reopens; the caller must supersede)
else if not imported and wsig not already present:
                       add witness; confirmationCount = witnesses.length; refresh clocks
                       if count >= 5 and status 'provisional': status 'supported', promotedAt, event 'promoted'
(imported: memory attaches, claim untouched — import contributes no witness)

then: write the memory, write event 'created' | 'imported'
```

Verified in the smoke: claude repeating itself → witness count unchanged; five
distinct hosts → `supported`, `promotedAt` set; a contradiction on a supported
claim → `contested`, and five more witnesses afterwards leave it `contested`.

### 2.5 The witness signature — why five is five

```
witnessSignature = sha256(lower(witness_kind) + '|' + trim(reference))
```

Intake builds the reference as `seat:<host> run:<runId>[ round:<n>]`. So:

- two seats answering the same prompt in one run → two witnesses;
- one seat answering twice in one run → one witness;
- the same seat in a *different run* → a new witness (a fresh observation).

This is the entire defence against "a model promotes a claim by saying it
five times", and it falls out of C2 with no extra code.

### 2.6 The equation form (`equation.js`, D16) — claim identity that survives wording

An equation is `{subject, predicate, object, units?, time?}`; rendered as
`predicate(subject) = object[ units][ @ time]`. Canonicalisation: lowercase,
collapse whitespace, strip trailing stops; each of subject/predicate/object
non-empty and ≤ 120 chars (longer "is not a reduction, it is a sentence").

**Identity is conjunctive:** two nominations are one claim only when subject
AND predicate AND object AND units AND time all match. Missing units/time are
`''` and match only `''`.

**Acceptance is soundness-first:** `acceptEquation(nomination, prose)` returns
a canonical equation or `{rejected, reason}` — never throws.

- `shape` — not a clean triple.
- `ungrounded` — the subject or the object does not actually occur in the
  prose it claims to reduce. This is what stops a nominator (model or pattern)
  inventing a fact and pinning it to someone's reply. Verified in the smoke: a
  reply saying "Lyon" that nominates `capital(france)=paris` is refused and
  the Paris claim is untouched.

**The nominator is a labelled placeholder** (`nominateEquation`): four
deterministic sentence shapes, ≤ 300 chars, nothing else —

```
"the capital of france is paris"     → capital(france) = paris
"paris is the capital of france"     → capital(france) = paris
"france has paris as its capital"    → capital(france) = paris
"france's capital is paris"          → capital(france) = paris
```

Design note (`NOMINATOR_NOTE`): *"A model nominating through
`acceptEquation()` replaces it with no downstream changes."* The pattern is
**model nominates, code decides** — the same posture as `HashEncoder`.

Prose that does not reduce keeps the exact-text signature it always had
(D7) and **never merges with anything**. That asymmetry is deliberate: a false
merge is worse than a missed one.

### 2.7 The trust gate (`trustGate.js`, C3) — what a session is actually given

```
logit_i  = (q · k_i) / τ  +  log(TrustGate_i + ε)        τ = 0.10, ε = 1e-6
weight_i = softmax(logit_i)  over the eligible shortlist (top 50 by similarity)
```

τ is **0.10, not √d** — the file header says this correction is the reason the
file exists. The gate touches a context window; it cannot touch any model's
weights.

`TrustGate_i = tStatus × tAdj × tSupp × tDrift × tConf`, each in [0, 1]:

| Term | Value |
|---|---|
| `tStatus` | 1 — but `contested` / `invalidated` are **zeroed out before scoring** (hard gate, reason = the status) |
| `tAdj` | adjudicated & digest matches → **1.0**; adjudicated & digest **mismatch → 0.50**; never adjudicated → **0.55**. The ordering is deliberate: a memory that was verified and then silently changed under its stamp is *more* suspicious than one never verified. |
| `tSupp` | `supported` → min(count/5, 1); `provisional` → 0.2 + 0.4 × min(count/5, 0.8); else 0 |
| `tDrift` | 1 until `nextRecheckAt`; after that `exp(−λ·days)` with half-life **14 days**; below **0.25** → zeroed as `stale` (unless pinned) |
| `tConf` | max(0.05, confidence); below **0.20** → zeroed as `low-confidence` (unless pinned) |

Optional `adjudicatedOnly` mode zeroes imported, never-adjudicated memories as
`imported_unadjudicated` — an opt-in, because an unadjudicated import is a
weighting question, not a boundary one.

Budget: tokens ≈ max(10, 0.25 × chars). **Pinned memories are admitted first
and survive the budget** (unless contested/invalidated); the rest are admitted
in weight order until the budget is full; everything after is excluded as
`budget` with the remaining-token count in the detail.

Returns `{admitted[], excluded[], tokensUsed, tokenBudget, weights{}}` where
every excluded entry carries `reason` and `detail`.

### 2.8 The boot block (`format.js`) — the read shape

`passport.bootBlock(query, {tokenBudget = 1200, adjudicatedOnly})` renders:

```
=== MEMORY PASSPORT ===
query: <query>
admitted N of M · T/B tokens

- [type] <title>
  <content>
  (<status mark> · N witnesses · w=0.412 | pinned · adjudicated?) evidence: <witness reference>
…
--- not shown ---
nothing was withheld.            ← or:  "k × <reason label>:" followed by the titles
status ceiling is `supported`. nothing here is asserted as simply true.
```

**The exclusion audit is not diagnostics — it is half the product.** A context
window that quietly dropped something is the failure the store exists to
prevent.

Two consumers today:

1. `passport:boot` IPC → the Memory pane in the chrome.
2. **The local seat wears it as its system prompt** (`main.js` local bridge):
   `system = passport.bootBlock(prompt, {tokenBudget: 1200}).text`. This is the
   only seat whose context Forge Flight owns, so it is the one place the
   helmet is actually put on a model's head. A boot-block failure is caught
   and yields an empty system prompt — it must never stop the answer.

### 2.9 Intake from the table (`index.js`, D11) — a reply is a candidate, never a fact

`table:send` runs the prompt across the chosen seats, then for every
successful reply:

```
equation = nominateEquation(reply.text) || undefined      (failure → undefined, memory still lands)
passport.ingestReply({ seatName, host, prompt, text, runId, round, role, equation })
```

`ingestReply` builds exactly this proposal:

```
type        'fact'
title       prompt clipped to 120 chars
content     reply clipped to 2000 chars
confidence  0.4
tags        ['forgeflight', 'reply', role || 'answer']
metadata    { witness_kind: 'outcome',
              reference: 'seat:<host> run:<runId>[ round:<n>]',
              seat, host, runId, round, prompt (≤1000 chars),
              equation?  (the nomination — data, not truth) }
actor       'seat:<seatName>'
```

Never pinned, never adjudicated, never above 0.4. It has to earn everything
else. A refused intake is logged and never thrown at the UI.

Then `recordDisagreement(runId, results)` groups the run's memories by claim
and writes one event: `cross_agreement` if every seat landed on **one** claim,
otherwise `cross_disagreement` with `distinct claims across N seats`, plus
`agreementCount` (the largest cluster). With the equation form, "The capital of
France is Paris" / "Paris is the capital of France" / "France has Paris as its
capital" is **one claim with three witnesses** and a `cross_agreement` — verified.

### 2.10 Export and import (`index.js`, D13) — a translation, not a restore

`export()` →

```
{ schema: 'forgeflight.passport.v1', exportedAt,
  note: 'Status and adjudication in this file are a RECORD, not an instruction…',
  chain: { head, chained, legacy },      ← provenance, not authority; nothing on import trusts it
  claims: [...], memories: [...], events: [...] }
```

`importBundle(bundle)`:

- refuses anything whose `schema` is not in
  `['forgeflight.passport.v1', 'omnibox.passport.v1']` → `not-a-passport`;
- every memory is re-proposed through `boundary.import()` → arrives
  `origin:'imported'`, `provisional`, **0 witnesses**, no adjudication, not pinned;
- returns `{ok, imported, dropped: [...]}` where `dropped` **names every
  privileged field it refused to honour**. Verified: a bundle relabelled to
  `status:'supported', confirmationCount:99` imports with
  `dropped: status, confirmationCount, promotedAt, id, claimId, origin` and
  every claim `provisional`.

This is the whole export-relabel-reimport defence, and it is why import
contributes no confirmation and no witness.

### 2.11 The IPC surface (renderer ↔ main)

`passport:boot {query, tokenBudget}` · `passport:list` · `passport:pin {id,
pinned}` · `passport:adjudicate {id}` · `passport:retire {id}` ·
`passport:export` · `passport:import`. Exposed to the chrome as
`window.forgeflight.passport.*` through `src/preload/chrome.js`; the chrome
loads nothing remote (D12).

---

## 3. STORE 4 — Anchors (`src/main/anchors.js`, D15) — the other log, on purpose

This is **not** the passport and must never become it. The passport holds
claims about the world; `anchors.jsonl` holds observations about *pages*:
which composer anchor Forge Flight acted on, what else it could have chosen,
whether the world responded, and when a person overruled it. "A page
observation is not knowledge, and knowledge does not need a bounding box."

Three record kinds: `verdict` (the detector's choice + its losers),
`outcome` (did the send produce a reply — keyed by anchor, never the text),
`pick` (a human chose a box by hand).

**The pipe rule, enforced:** `sanitize()` strips any field whose *key* matches

```
/^(prompt|prompts|reply|replies|text|texts|content|body|message|sent|chunks?|answer|answers|draft)$/i
```

at any depth, before anything is written; allowed strings are capped at 160
chars (page furniture, bounded so a hostile page cannot use them as a
channel). A record that arrives carrying a prompt loses the prompt, keeps the
rest, and the log records that it did so. Same JSONL/torn-line posture as the
passport. **Not hash-chained today** (the passport, federation and queue are).

---

## 4. STORE 5 — The small stores

- **`session.json`** (`session.js`, D19) — `{version: 1, savedAt, tabs[],
  activeUrl, assign (host → role), order (hosts), subjectHost, …}`. A session
  is *a list of places, never a credential*.
  Restore passes every URL through `restorableURL()`: `https:` and `http:`
  ordinary; `forgeflight://start` and `forgeflight://local` are the two
  internal rooms; `omnibox://…` is translated to `forgeflight://…`; `file:`,
  `javascript:`, `data:` and everything else → `null` (dropped). The
  allowlist did not widen in the rename (tested).
- **`picks.json`** (`picks.js`) — per host, a composer box a person chose by
  hand, keyed by a **stability key** (hash of identity fields + structural
  path), validated by regex on load; a pick is honoured only if an element on
  the page actually matches the key. Never a selector string from the page.
- **`seats.json`** (`seats.js`) — `{names: {host: name}, muted: {host: true}}`.

Logins are not a store Forge Flight writes; they are Chromium's cookie jar in
partition **`persist:omnibox`** — kept verbatim through the rename because a
partition name is never shown to anyone and changing it signs everyone out
(pinned by `test/rename.test.js`).

---

## 5. STORES 2 & 3 — The Forge Federation (`src/federation/`)

### 5.1 What it is

The carrier. Many cockpits land facts on it; a pilot's request is checked
against it before a capability is granted. It stores **equations only** —
prose does not cross the radio; it stays in the cockpit.

### 5.2 Two shelves, two clocks (D23)

| Shelf | What it holds | On contradiction | Promotion |
|---|---|---|---|
| **`world`** | facts about the world that do not move (`capital(france) = paris`) | **closes** the old fact permanently (`status:'closed'`, `closedAt`, `closedBy`); it does not reopen on a repeat | `established` at **5 distinct witnesses** (event `established`) |
| **`operational`** | facts about a *target that mutates* (`rate_limit(claude.ai) = 0`); `target` is **required** | **supersedes**: old fact stays, `status:'superseded'`, `supersededBy` → new id — "the target moved" | none; stays `provisional` and is subject to the staleness clock |

Nothing is ever deleted on either shelf. `live()` = facts with no `closedAt`.
`stale({days=30})` = live operational facts not re-observed in `days`.

A **contradiction is computable**: same subject + predicate on the same shelf,
different object (`findByPredicate`). That is why the store insists on
equations.

### 5.3 Witness kinds — and the one that is not (D24)

```
WITNESS_KINDS   = ['outcome', 'structural', 'contract', 'human']
SELF_VERIFYING  = {'structural', 'contract'}
OUTCOME_REPLICATION = 3    ← reported to the human on a transfer; NOT enforced by code today
PROMOTION_THRESHOLD = 5
```

- `outcome` — a node observed a result. The one kind nobody else can
  re-derive, so a single node's outcome stays local until independently
  replicated or paired with something structural.
- `structural` — derivable from the artefact itself.
- `contract` — declared by the provider.
- `human` — a person ruled; **requires a named `actor`**.

**"Agreement between nodes is not a witness kind and never will be."**
`land({witness:'agreement'})` → `{rejected, reason:'witness'}` (verified).
Replication is not agreement: five nodes measuring is not five parties voting.

### 5.4 Fact record

```
id            'f_<12 hex>'
schema        'forgeflight.federation.v1'
signature     equationSignature(equation, shelf)      ← shelf is the scope
shelf         'world' | 'operational'
equation      {subject, predicate, object, units, time}
rendered      'predicate(subject) = object'
target        string | null  (required on operational)
status        'provisional' | 'established' | 'closed' | 'superseded'
witnesses     [{ sig: sha256(kind|nodeId|reference), kind, nodeId, reference, at }]
distinct      = witnesses.length
landedAt, lastSeenAt, supersededBy, closedAt, closedBy
```

`land(spec)` validation, in order: object shape → `shelf` → `witness` kind →
`equation` canonical → `nodeId` non-empty ("every witness names the node that
observed it") → `reference` non-empty ("a witness with no evidence pointer has
no value") → `human` needs `actor` → `operational` needs `target`. Results:
`landed` | `witnessed` | `already-witnessed` (same node+kind+reference bumps
`lastSeenAt` only) | `{rejected, reason:'closed'}`.

### 5.5 The triangle (D20–D22) — three machines, the human is step four

```
   PILOT ──request──▶ CURATOR ──proposal──▶ QUEUE ◀──release/refuse── HUMAN (named)
                          │                                  │
                          ▼ (blind)                          ▼
                       OVERSEER  ◀── reads ── FEDERATION ◀── land() by the APP on a signed ticket
```

**The overseer** (`checkPrecondition`, `overseer`) is the entire mechanical
core and is deliberately tiny. It is handed equations and returns a verdict.
It never sees prose. Per precondition:

| Verdict | Meaning |
|---|---|
| `satisfied` | the Federation holds the same equation |
| `unsatisfied` | the Federation holds a **different object** for the same subject+predicate — a **named broken constraint** with `variable: 'predicate(subject)'`, `expected`, `actual`, `witnesses`, `status`, `since` |
| `unknown` | the Federation holds nothing on this subject+predicate |
| `malformed` | not an equation; cannot be checked |

Ruling for a request: any `malformed` → `malformed`; else any `unsatisfied` →
`blocked`; else any `unknown` → `unproven`; else `clear`.

**The curator** (`Curator(federation, queue)`) is a reader on the outbound
side. It **cannot write to the Federation** — its only write path is
`queue.propose()` (D21). Three asks:

- `reviewCapability({pilot, capability, shelf, preconditions[]})` →
  `clear` → `no-objection` (nothing queued);
  `malformed` → `refused` ("nothing was denied on judgment"; nothing queued);
  `unproven` → `no-objection` **with a notice** — absence of evidence is not
  evidence, the pilot proceeds;
  `blocked` → **`denied-pending-human`**, queued, with a signable
  `denialNotice` that names the variable, what was assumed, what the
  Federation holds, on how many witnesses, since when (D22: *a denial must
  name a broken constraint, or it is an opinion*). Verified output:

  ```
  Pilot 3 requested browser.fetch.
  Its preconditions assumed rate_limit(claude.ai) = 100. Federation holds
  rate_limit(claude.ai) = 0 — 3 witnesses, provisional, since 2026-09-04.
  Constraint rate_limit(claude.ai) fails.
  Denied pending your call.
  ```

- `reviewTransfer({equation, shelf, witness, nodeId, reference, target,
  replication})` — a fact wants to leave a cockpit and land on the carrier.
  Not an equation → `refused` ("prose does not cross the radio"). Otherwise
  queued as `proposed` with a `transferNotice` that states the witness, the
  replication count, the evidence, and any **CONFLICT** on the named variable
  and what landing would do to it (close vs supersede). What the human signs
  is a **delta of equations, never a story**.

- `proposeRechecks({days=30, limit=10})` — staleness. The curator never
  deletes or expires; it asks. Each stale operational fact becomes a `recheck`
  proposal: "Nothing is deleted — re-establish it, or let a contradiction
  supersede it."

**`health()`** — `QUEUE_ALARM = 12`. More than 12 open proposals is *a defect
with a name*: the equations have stopped discriminating, the entry rule admits
too much, or the curator is forwarding instead of deciding.

### 5.6 STORE 3 — The proposal queue (`queue.js`)

```
schema   'forgeflight.queue.v1'
STATES   ['open', 'released', 'refused', 'withdrawn']
ops      propose(item) · release(id,{actor,note}) · refuse(id,{actor,note}) · withdraw(id,{reason})
```

`decide()` refuses: unknown id → `unknown-proposal`; not open →
`already-decided`; **no `actor` → `unsigned`**. There is no default actor
anywhere in the chain — an anonymous approval is the machine approving itself.
Verified: `release(id, {actor: ''})` → `unsigned`; `{actor: 'D'}` → ok.

**A release authorises; it does not land.** `federation:release` in `main.js`
checks the signature, and only then — for a `transfer` — calls
`federation.land()` itself, with the human's `actor` attached. The curator
never lands anything. For a `capability`, release returns "Authorised. The
action is performed by the harness, not by this screen."

### 5.7 The IPC surface

`federation:stats` → `{federation: stats, queue: stats, health}` ·
`federation:facts {shelf}` · `federation:queue` · `federation:release {id,
actor, note}` · `federation:refuse` · `federation:rechecks {days}` ·
`federation:review request` · `federation:propose spec`. Chrome:
`window.forgeflight.federation.*`, the **Carrier** pane
(`viewCarrier`/`paneCarrier`, `carStats`, `carHealth`, `carDetail`).

---

## 6. How the two stores relate (and the seam that is still open)

```
 seats ──replies──▶ PASSPORT (cockpit, session-scale, prose + equations, 5 witnesses, τ-gate)
                        │
                        │  a fact that reduced to an equation and earned witnesses
                        ▼
                 curator.reviewTransfer ──▶ QUEUE ──human signs──▶ federation.land()
                                                                          │
              local seat's system prompt ◀── passport.bootBlock ◀── ???  ◀┘
```

- **Upward (cockpit → carrier)** exists end to end but is **manually
  triggered**: `federation:propose` is an IPC the chrome can call with an
  equation; nothing yet walks the passport for `supported` equation claims
  and proposes them automatically. That automation is the next obvious step
  and everything it needs (claim `form`, `equation`, `confirmationCount`,
  witness list with hosts) is already on the claim record.
- **Downward (carrier → cockpit)** does **not** exist yet. The boot block is
  built from the passport only. The header comment in the local bridge says
  the local model "wears the Federation's knowledge" — today that is true only
  in the sense that the passport is the local copy. Landing Federation facts
  into a session's boot block (as `structural`/`contract` witnesses, or as a
  separate "carrier" section under the same exclusion audit) is not built.
- The two stores **share `equation.js`** (same canonicalisation, same
  signature function), so an equation that is one claim in the passport is
  the same fact on the carrier. The shelf is the scope on the carrier; the
  passport's scope defaults to `global`.
- Passport witness signature = `sha256(kind|reference)`; Federation witness
  signature = `sha256(kind|nodeId|reference)`. The Federation adds the node
  because many cockpits land on it; the passport is one cockpit.

---

## 7. Placeholders, labelled

| Placeholder | Where | What replaces it | Downstream change needed |
|---|---|---|---|
| `HashEncoder` — hashed-token vectors standing in for a real embedding | `passport/core.js` | any `(text) => Float64Array` | none; `Passport` takes an encoder |
| Deterministic 4-shape nominator | `passport/equation.js` `nominateEquation` | a model that nominates through `acceptEquation()` | none |
| `OUTCOME_REPLICATION = 3` reported, not enforced | `federation/store.js` | a rule in `reviewTransfer` or `land` | small |
| Carrier pane signs releases as the literal actor `'D'` | `renderer/chrome.js` | an identity | UI only |
| `driftHalfLifeDays: 14` "a starting constant, not a settled one" | `trustGate.js` | measurement | none |

## 8. Deliberately not built (from `docs/DECISIONS.md` "Open")

A real encoder; reaching into cross-origin frames or closed shadow roots
(named and refused instead); byte-for-byte passport restore (D13 — a
different operation on a different trust footing); rejecting one of several
pending approvals; the label-to-lesson bridge (Forge Flight captures and
labels; the engine's own extractor and promotion gate decide — D15).

---

## 9. The rename, as it touches memory (D26)

Everything a person accumulated survives the OmniBox → Forge Flight rename:

| Kept / bridged | Mechanism |
|---|---|
| logins | `persist:omnibox` partition name kept verbatim |
| the whole profile folder | `src/main/profile.js` moves a sibling `omnibox` userData folder into place **once**, only if the new one is empty; never overwrites; never throws; leaves `MOVED-TO-FORGE-FLIGHT.txt` behind; falls back to copy across volumes |
| old passport exports | `IMPORT_SCHEMAS` includes `omnibox.passport.v1` |
| old federation + queue logs | `collective/collective.jsonl` and `collective/queue.jsonl` adopted by move on first load; old schema-stamped lines replay as-is; chain untouched |
| old saved sessions | `omnibox://…` → `forgeflight://…` |
| `OMNIBOX_LOCAL_LLM_URL` | still honoured when `FORGEFLIGHT_LOCAL_LLM_URL` is unset |
| Pocket's saved tabs | `omnibox-pocket-v1` → `forgeflight-pocket-v1` localStorage adoption |

Not bridgeable and named as such: installer/app ids (`com.misfit.forgeflight`,
`com.misfit.forgeflight.mobile`) — a Forge Flight install lands beside an
OmniBox one and adopts its profile on first launch.

All of this is pinned by `test/rename.test.js` (11 checks).

---

## 10. Test map

| Suite | Checks | Covers |
|---|---|---|
| `passport.test.js` | 28 | C1–C4, promotion at 5, one contradiction closes, ceiling, privileged-field rejection, export/import translation, boot block + audit |
| `equation.test.js` | 18 | canonical form, conjunctive identity, grounding, the four nominator shapes, prose never merges |
| `chain.test.js` | 8 | hash chain write/verify, edit/delete detection, legacy lines |
| `federation.test.js` | 26 | shelves, witness kinds, agreement refused, close vs supersede, overseer verdicts, curator asks, queue signing, alarm |
| `anchors.test.js` | 11 | the pipe rule, sanitize by key at depth, torn lines |
| `session.test.js` | 18 | resume contract, allowlist, scheme translation |
| `table.test.js` | 14 | fan-out shapes; witness references per seat/run/round |
| `local.test.js` | 5 | local seat bridge |
| `mobile.test.js` | 4 | Pocket shell |
| `rename.test.js` | 11 | everything in §9 |
| **total** | **143** | run: `node --test test/*.test.js` (with Electron stubbed if no binary) |

UI (`test/ui`) and e2e (`test/e2e`) suites need a real Electron/Chromium and
were not runnable in the sandbox used for this pass; they are unchanged
except for the rename.

---

## 11. Vocabulary, for the next phase

- **seat** — an AI chat tab that Forge Flight detected a composer in and can type into.
- **table / run** — one prompt fanned out to several seats; a `runId` per run, `round` within it.
- **witness** — a distinct `(kind, reference)`; five make `supported`.
- **claim** — the counted unit; `prose` or `equation` form.
- **memory** — one observation attached to a claim.
- **boot block / helmet** — the curated, audited context a session is given.
- **exclusion audit** — the list of what was withheld and why; half the product.
- **cockpit** — one Forge Flight; **carrier** — the Forge Federation.
- **shelf** — `world` (closes) or `operational` (supersedes; has a target and a clock).
- **overseer** — blind mechanical precondition checker; **curator** — proposes, never lands.
- **proposal / queue / release** — the only human step, and it must be signed.
- **funnel** — decisions reaching a human should be the residue the math could not settle; the alarm is 12.
