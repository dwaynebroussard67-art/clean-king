import type {
  ContextFrameStore,
  MissionEvent,
  MissionRecord,
  MissionStore,
  RunRecord,
  RunStore,
} from './contracts.ts';

export type Queryable = {
  query<T = Record<string, unknown>>(sql: string, params?: unknown[]): Promise<{ rows: T[] }>;
};

/**
 * PostgreSQL/PGlite mission store. The runtime only depends on Queryable, so
 * the same store can be exercised against node-postgres or PGlite without
 * giving the model, Passport adapter, or tool layer a database handle.
 */
export class PostgresMissionStore implements MissionStore, RunStore, ContextFrameStore {
  private readonly client: Queryable;

  constructor(client: Queryable) {
    this.client = client;
  }

  async create(mission: MissionRecord): Promise<void> {
    await this.client.query(
      `INSERT INTO missions
        (id, passport_id, kind, goal, constraints, budget, authority,
         success_criteria, harness_status, harness_revision, context_digest, checkpoint, metadata)
       VALUES ($1, $2, 'harness', $3, $4::jsonb, $5::jsonb, $6::jsonb,
               $7::jsonb, $8, $9, $10, $11::jsonb, $12::jsonb)`,
      [
        mission.id,
        mission.passportId,
        mission.goal,
        JSON.stringify(mission.constraints ?? []),
        JSON.stringify(mission.budget ?? {}),
        JSON.stringify(mission.authority ?? {}),
        JSON.stringify(mission.successCriteria ?? []),
        mission.status,
        mission.revision,
        mission.contextDigest ?? null,
        JSON.stringify(mission.checkpoint ?? {}),
        JSON.stringify(mission.metadata ?? {}),
      ],
    );
  }

  async get(id: string): Promise<MissionRecord | null> {
    const { rows } = await this.client.query<Record<string, unknown>>(
      `SELECT id, passport_id, goal, constraints, budget, authority,
              success_criteria, harness_status, harness_revision, context_digest,
              checkpoint, metadata, created_at, updated_at
         FROM missions WHERE id = $1`,
      [id],
    );
    const row = rows[0];
    if (!row) return null;
    return fromRow(row);
  }

  async save(mission: MissionRecord, expectedRevision?: number): Promise<void> {
    const result = await this.client.query(
      `UPDATE missions
          SET harness_status = $1,
              harness_revision = $2,
              context_digest = $3,
              checkpoint = $4::jsonb,
              metadata = $5::jsonb,
              updated_at = $6
        WHERE id = $7
          AND ($8::integer IS NULL OR harness_revision = $8)
        RETURNING id`,
      [
        mission.status,
        mission.revision,
        mission.contextDigest ?? null,
        JSON.stringify(mission.checkpoint ?? {}),
        JSON.stringify(mission.metadata ?? {}),
        mission.updatedAt,
        mission.id,
        expectedRevision ?? null,
      ],
    );
    if (result.rows.length === 0) {
      throw new Error(expectedRevision === undefined
        ? `mission not found: ${mission.id}`
        : `mission revision conflict: ${mission.id}`);
    }
  }

  async createRun(run: RunRecord): Promise<void> {
    await this.client.query(
      `INSERT INTO harness_runs
        (id, mission_id, attempt, status, state, checkpoint, idempotency_key, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5::jsonb, $6::jsonb, $7, $8, $9)`,
      [
        run.id,
        run.missionId,
        run.attempt,
        run.status,
        JSON.stringify(run.state),
        JSON.stringify(run.checkpoint),
        run.idempotencyKey,
        run.createdAt,
        run.updatedAt,
      ],
    );
  }

  async getRun(id: string): Promise<RunRecord | null> {
    const { rows } = await this.client.query<Record<string, unknown>>(
      `SELECT id, mission_id, attempt, status, state, checkpoint,
              idempotency_key, created_at, updated_at
         FROM harness_runs WHERE id = $1`,
      [id],
    );
    const row = rows[0];
    if (!row) return null;
    return fromRunRow(row);
  }

  async getLatestRun(missionId: string): Promise<RunRecord | null> {
    const { rows } = await this.client.query<Record<string, unknown>>(
      `SELECT id, mission_id, attempt, status, state, checkpoint,
              idempotency_key, created_at, updated_at
         FROM harness_runs
        WHERE mission_id = $1
        ORDER BY attempt DESC, created_at DESC
        LIMIT 1`,
      [missionId],
    );
    return rows[0] ? fromRunRow(rows[0]) : null;
  }

  async saveRun(run: RunRecord): Promise<void> {
    const result = await this.client.query(
      `UPDATE harness_runs
          SET status = $1,
              state = $2::jsonb,
              checkpoint = $3::jsonb,
              updated_at = $4
        WHERE id = $5
        RETURNING id`,
      [run.status, JSON.stringify(run.state), JSON.stringify(run.checkpoint), run.updatedAt, run.id],
    );
    if (result.rows.length === 0) throw new Error(`run not found: ${run.id}`);
  }

  async saveContextFrame(input: { runId: string; missionId: string; passportId: string; frame: import('./contracts.ts').ContextFrame }): Promise<void> {
    await this.client.query(
      `INSERT INTO harness_context_frames
        (run_id, mission_id, passport_id, digest, frame)
       VALUES ($1, $2, $3, $4, $5::jsonb)
       ON CONFLICT (run_id, digest) DO NOTHING`,
      [input.runId, input.missionId, input.passportId, input.frame.digest, JSON.stringify(input.frame)],
    );
  }

  async loadLatestContextFrame(runId: string): Promise<import('./contracts.ts').ContextFrame | null> {
    const { rows } = await this.client.query<{ frame: import('./contracts.ts').ContextFrame }>(
      `SELECT frame FROM harness_context_frames
        WHERE run_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [runId],
    );
    const frame = rows[0]?.frame;
    return frame ?? null;
  }

  async appendEvent(event: MissionEvent): Promise<MissionEvent> {
    const existing = await this.client.query<Record<string, unknown>>(
      `SELECT id, mission_id, run_id, sequence, type, actor, payload, created_at
         FROM harness_events WHERE id = $1`,
      [event.id],
    );
    if (existing.rows[0]) return eventFromRow(existing.rows[0]);

    let sequence = event.sequence;
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const inserted = await this.client.query<Record<string, unknown>>(
        `INSERT INTO harness_events
          (id, mission_id, run_id, sequence, type, actor, payload, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8)
         ON CONFLICT (mission_id, sequence) DO NOTHING
         RETURNING id, mission_id, run_id, sequence, type, actor, payload, created_at`,
        [
          event.id,
          event.missionId,
          event.runId ?? null,
          sequence,
          event.type,
          event.actor,
          JSON.stringify(event.payload),
          event.createdAt,
        ],
      );
      if (inserted.rows[0]) return eventFromRow(inserted.rows[0]);

      const sameId = await this.client.query<Record<string, unknown>>(
        `SELECT id, mission_id, run_id, sequence, type, actor, payload, created_at
           FROM harness_events WHERE id = $1`,
        [event.id],
      );
      if (sameId.rows[0]) return eventFromRow(sameId.rows[0]);
      const next = await this.client.query<{ next_sequence: number }>(
        `SELECT COALESCE(MAX(sequence), -1) + 1 AS next_sequence
           FROM harness_events WHERE mission_id = $1`,
        [event.missionId],
      );
      sequence = Number(next.rows[0]?.next_sequence ?? sequence + 1);
    }
    throw new Error(`could not allocate harness event sequence for mission: ${event.missionId}`);
  }

  async listEvents(missionId: string): Promise<MissionEvent[]> {
    const { rows } = await this.client.query<Record<string, unknown>>(
      `SELECT id, mission_id, run_id, sequence, type, actor, payload, created_at
         FROM harness_events WHERE mission_id = $1 ORDER BY sequence`,
      [missionId],
    );
    return rows.map(eventFromRow);
  }
}

function eventFromRow(row: Record<string, unknown>): MissionEvent {
  return {
    id: String(row.id),
    missionId: String(row.mission_id),
    runId: row.run_id ? String(row.run_id) : undefined,
    sequence: Number(row.sequence),
    type: row.type as MissionEvent['type'],
    actor: String(row.actor),
    payload: (row.payload ?? {}) as Record<string, unknown>,
    createdAt: new Date(String(row.created_at)).toISOString(),
  };
}

function fromRow(row: Record<string, unknown>): MissionRecord {
  return {
    id: String(row.id),
    passportId: String(row.passport_id),
    goal: String(row.goal ?? ''),
    constraints: (row.constraints ?? []) as MissionRecord['constraints'],
    budget: (row.budget ?? {}) as MissionRecord['budget'],
    authority: (row.authority ?? {}) as MissionRecord['authority'],
    successCriteria: (row.success_criteria ?? []) as MissionRecord['successCriteria'],
    status: String(row.harness_status) as MissionRecord['status'],
    revision: Number(row.harness_revision ?? 0),
    contextDigest: row.context_digest ? String(row.context_digest) : undefined,
    checkpoint: (row.checkpoint ?? undefined) as MissionRecord['checkpoint'],
    metadata: (row.metadata ?? {}) as Record<string, unknown>,
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
  };
}

function fromRunRow(row: Record<string, unknown>): RunRecord {
  return {
    id: String(row.id),
    missionId: String(row.mission_id),
    attempt: Number(row.attempt),
    status: String(row.status) as RunRecord['status'],
    state: (row.state ?? {}) as Record<string, unknown>,
    checkpoint: (row.checkpoint ?? {}) as Record<string, unknown>,
    idempotencyKey: String(row.idempotency_key),
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
  };
}
