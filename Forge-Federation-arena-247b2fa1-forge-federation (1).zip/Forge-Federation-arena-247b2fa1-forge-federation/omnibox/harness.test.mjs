// Run with: node --experimental-strip-types src/harness/harness.test.mjs
//
// The first flight-computer gate. These tests deliberately use an in-memory
// mission store and a fake Passport adapter: the state machine and Neuralink
// contract must be correct before PostgreSQL, MCP, or a provider can hide a
// defect.

import { randomUUID } from 'node:crypto';
import { PGlite } from '@electric-sql/pglite';
import { applyMigrations } from '../../scripts/lib/migrations.mjs';
import { HarnessRuntime, InMemoryMissionStore } from './runtime.ts';
import { PostgresMissionStore } from './postgres-store.ts';
import { PostgresPassportAdapter } from './passport-adapter.ts';
import { CapabilityRegistry, createToolCall } from './capabilities.ts';
import { BudgetExceededError, BudgetLedger, MissionComputer } from './mission-computer.ts';
import { NeuralinkSession, compileContext } from './neuralink.ts';
import { corePack } from './packs/core-pack.ts';
import { createMissionRecord, transitionMission, MissionStateError } from './state-machine.ts';

let passed = 0;
let failed = 0;
function check(name, condition, detail = '') {
  if (condition) { console.log(`  ✓ ${name}`); passed++; }
  else { console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`); failed++; }
}

const clock = (() => {
  let tick = 0;
  return () => new Date(Date.UTC(2026, 7, 16, 12, 0, tick++));
})();

const passportContext = {
  passportId: 'passport-1',
  identity: { name: 'Dwayne', preferredName: 'D', timezone: 'America/Chicago', language: 'English' },
  memories: [
    {
      id: 'm-asserted', title: 'Unverified', content: 'Do not include by default.', status: 'asserted',
      evidence: [], updatedAt: '2026-08-16T10:00:00.000Z',
    },
    {
      id: 'm-evidenced', title: 'Evidence', content: 'Evidence-backed context.', status: 'evidenced',
      evidence: ['docs/evidence.md'], updatedAt: '2026-08-16T09:00:00.000Z',
    },
    {
      id: 'm-adjudicated', title: 'Settled', content: 'Adjudicated context.', status: 'adjudicated',
      pinned: true, evidence: ['run-42'], updatedAt: '2026-08-16T08:00:00.000Z',
    },
  ],
};

const persisted = [];
const passport = {
  async loadContext({ passportId }) {
    if (passportId !== passportContext.passportId) throw new Error('unknown Passport');
    return structuredClone(passportContext);
  },
  async persistMemoryCandidate(candidate) {
    persisted.push(candidate);
    return { memoryId: `memory-${persisted.length}` };
  },
};

const spec = {
  passportId: 'passport-1',
  goal: 'Resolve the mission without losing provenance.',
  constraints: [{ id: 'c1', text: 'Do not fabricate evidence', kind: 'must_not' }],
  budget: { maxUsd: 1, maxToolCalls: 3, maxModelTurns: 1 },
  authority: { actorId: 'user-1', allowedCapabilityIds: ['read.example', 'write.example'], autoApproveRiskAtMost: 'read' },
  successCriteria: [{ id: 'evidence', description: 'Answer is recorded with evidence.', type: 'evidence_present' }],
};

console.log('\n1. State machine\n');
const base = createMissionRecord({ id: 'mission-1', ...spec }, clock);
const prepared = transitionMission(base, 'NEURALINK_BOUND', 'harness', {}, clock).mission;
const ready = transitionMission(prepared, 'CONTEXT_READY', 'neuralink', {}, clock).mission;
check('mission starts in CREATED', base.status === 'CREATED');
check('valid transitions advance', ready.status === 'CONTEXT_READY' && ready.revision === 2);
try {
  transitionMission(base, 'RUNNING', 'pilot', {}, clock);
  check('invalid transitions are rejected', false);
} catch (error) {
  check('invalid transitions are rejected', error instanceof MissionStateError);
}

console.log('\n2. Mission Computer\n');
const missionComputer = new MissionComputer();
const plan = missionComputer.plan({
  ...base,
  successCriteria: [
    { id: 'answer', description: 'Answer includes ready.', type: 'output_contains', value: 'ready' },
    { id: 'evidence', description: 'Evidence is present.', type: 'evidence_present' },
  ],
}, clock);
check('Mission Computer creates a deterministic plan', plan.schema === 'omnibox.mission-plan.v1' && plan.steps.at(-1)?.kind === 'evaluation');
check('plan exposes approval before execution', plan.steps.some((step) => step.kind === 'approval'));
check('plan has a deterministic digest', /^[a-f0-9]{64}$/.test(plan.digest));
const ledger = new BudgetLedger({ maxUsd: 1, maxToolCalls: 2, maxModelTurns: 1 });
ledger.consume({ usd: 0.25, toolCalls: 1, modelTurns: 1 });
check('budget ledger accounts for usage', ledger.usage.usd === 0.25 && ledger.usage.toolCalls === 1);
try {
  ledger.consume({ toolCalls: 2 });
  check('budget overrun is rejected', false);
} catch (error) {
  check('budget overrun is rejected', error instanceof BudgetExceededError);
}
const evaluation = missionComputer.evaluate([
  { id: 'answer', description: 'Answer includes ready.', type: 'output_contains', value: 'ready' },
  { id: 'evidence', description: 'Evidence is present.', type: 'evidence_present' },
], { answer: 'The system is ready.', evidence: ['run-1'] });
check('Mission Computer evaluates declarative success criteria', evaluation.status === 'succeeded');

console.log('\n3. Neuralink\n');
const frame = compileContext(base, passportContext, { maxMemories: 2, maxCharacters: 2_000 }, clock);
check('context is bound to the mission Passport', frame.passportId === base.passportId);
check('identity is included in the frame', frame.identity.preferredName === 'D');
check('unverified memory is excluded by default', !frame.memories.some((memory) => memory.id === 'm-asserted'));
check('adjudicated and evidenced memory can be loaded', frame.memories.length === 2);
check('context receives a deterministic digest', /^[a-f0-9]{64}$/.test(frame.digest));

const session = new NeuralinkSession(passport, {}, clock);
await session.bind(base);
check('low-importance observations are excluded', session.observe({
  type: 'pilot_response', source: 'pilot-a', content: 'noise', importance: 'low',
}).action === 'exclude');
const beforeObservationDigest = session.frame.digest;
check('important observations are retained', session.observe({
  type: 'tool_result', source: 'tool-a', content: 'The requested record was found.',
  importance: 'high', evidence: ['api://record/1'],
}).action === 'include');
check('Neuralink updates the active frame after observation',
  session.frame.observations?.length === 1 && session.frame.digest !== beforeObservationDigest);
const candidate = session.proposeCandidate({
  content: 'The requested record was found.',
  sourceEventIds: ['event-tool-1'],
  evidence: ['api://record/1'],
  scope: 'Only this mission and this record type.',
  outcomeStatus: 'confirmed',
});
check('candidate carries source events and scope', candidate.sourceEventIds.length === 1 && candidate.scope.length > 0);
const held = await session.reviewCandidate(candidate);
check('Passport promotion is not automatic', held.action === 'persist_candidate' && persisted.length === 0);
const promoted = await session.reviewCandidate(candidate, { explicitApproval: true });
check('explicit approval can promote a confirmed candidate', promoted.action === 'promote' && persisted.length === 1);

console.log('\n4. Harness runtime\n');
const store = new InMemoryMissionStore();
const runtimeCapabilities = new CapabilityRegistry();
runtimeCapabilities.register({
  id: 'read.example', name: 'Read example', description: 'Read a record.', risk: 'read',
  inputSchema: { type: 'object' }, requiresApproval: false,
});
runtimeCapabilities.register({
  id: 'write.example', name: 'Write example', description: 'Write a record.', risk: 'update',
  inputSchema: { type: 'object' }, requiresApproval: true,
});
const runtime = new HarnessRuntime({
  store,
  passport,
  capabilities: runtimeCapabilities,
  clock,
  idFactory: () => 'mission-runtime',
});
const created = await runtime.createMission(spec);
const bound = await runtime.bindNeuralink(created.id);
check('runtime creates and binds a mission', bound.mission.status === 'CONTEXT_READY');
check('runtime returns a Neuralink context frame', bound.context.missionId === created.id);
check('runtime persists the Mission Computer plan', (await runtime.getPlan(created.id)).digest === bound.mission.metadata?.missionPlan?.digest);
await runtime.beginPlanning(created.id);
const requestedTool = await runtime.requestTool({
  missionId: created.id,
  id: 'tool-call-1',
  capabilityId: 'write.example',
  arguments: { value: 'approved later' },
  estimatedCostUsd: 0.1,
});
check('tool request enters the approval path', requestedTool.authorization.decision === 'require_approval');
const running = await runtime.decideApproval(created.id, {
  approvalId: 'approval-1', toolCallId: 'tool-call-1', decision: 'approve', actorId: 'user-1', decidedAt: clock().toISOString(),
});
check('approval resumes the run', running.status === 'RUNNING');
const firstTurnUsage = await runtime.recordModelTurn(created.id, 0.01);
const budgetAfterApproval = await runtime.getRun(created.id);
check('runtime consumes model-turn budget', firstTurnUsage.modelTurns === 1);
check('approval commits its pending budget', budgetAfterApproval.state.budgetUsage?.toolCalls === 1);
try {
  await runtime.recordModelTurn(created.id, 0.01);
  check('runtime rejects model-turn budget overrun', false);
} catch (error) {
  check('runtime rejects model-turn budget overrun', error instanceof BudgetExceededError, `actual: ${error.name}: ${error.message}`);
}
const secondTool = await runtime.requestTool({
  missionId: created.id, id: 'tool-call-2', capabilityId: 'read.example', arguments: { id: 2 }, estimatedCostUsd: 0.01,
});
const thirdTool = await runtime.requestTool({
  missionId: created.id, id: 'tool-call-3', capabilityId: 'read.example', arguments: { id: 3 }, estimatedCostUsd: 0.01,
});
check('multiple tool requests at one revision receive distinct events',
  secondTool.authorization.decision === 'allow' && thirdTool.authorization.decision === 'allow');
try {
  await runtime.requestTool({
    missionId: created.id, id: 'tool-call-4', capabilityId: 'read.example', arguments: { id: 4 },
  });
  check('runtime enforces the mission tool budget', false);
} catch (error) {
  check('runtime enforces the mission tool budget', error instanceof BudgetExceededError, `actual: ${error.name}: ${error.message}`);
}
const budgetEvents = await store.listEvents(created.id);
check('budget rejection is auditable', budgetEvents.at(-1)?.payload?.budgetRejected === true);
// Dry run is no longer something a caller can ask for. It used to be a flag on
// requestTool() that returned before the risk ceiling was consulted, so a
// caller could declare a dry run, receive a non-approval decision, and then
// perform the real side effect. It is now a harness-wide execution mode that
// changes what the EXECUTOR does and never changes what a capability requires.
const dryHarness = new HarnessRuntime({
  store: new InMemoryMissionStore(), passport, capabilities: new CapabilityRegistry(),
  mode: 'dry_run',
});
dryHarness.mount(corePack());
const dryMission = await dryHarness.createMission({
  ...spec,
  authority: { actorId: 'user-1', allowedCapabilityIds: ['core.note'], autoApproveRiskAtMost: 'transform' },
});
await dryHarness.bindNeuralink(dryMission.id);
await dryHarness.beginPlanning(dryMission.id);
const dryResult = await dryHarness.runTool({
  missionId: dryMission.id, capabilityId: 'core.note', arguments: { key: 'k', value: 1 },
});
check('a harness in dry-run mode simulates instead of acting',
  dryResult.mode === 'dry_run' && dryResult.output?.simulated === true);
check('the caller cannot request a dry run for itself',
  !('dryRun' in (runtime.requestTool.length ? {} : {})) && dryResult.status === 'succeeded');
check('runtime records retained observations', (await runtime.observe(created.id, {
  type: 'tool_result', source: 'read.example', content: 'result', importance: 'high',
})).action === 'include');
for (let i = 0; i < 30; i += 1) {
  await runtime.observe(created.id, {
    type: 'tool_result', source: 'read.example', content: `result-${i}`, importance: 'high',
  });
}
const restartedMidRun = new HarnessRuntime({ store, passport, capabilities: runtimeCapabilities, clock, idFactory: () => 'unused' });
check('Neuralink session restores from the persisted frame',
  (await restartedMidRun.observe(created.id, {
    type: 'tool_result', source: 'read.example', content: 'after-restart', importance: 'high',
  })).action === 'include');
await runtime.markContextUpdated(created.id);
await runtime.resumeRunning(created.id);
await runtime.beginEvaluation(created.id);
const completion = await runtime.complete(created.id, { evidence: ['run://mission-runtime'] });
const completed = completion.mission;
const events = await store.listEvents(created.id);
const eventSequences = new Set(events.map((event) => event.sequence));
check('Mission Computer derives mission success', completion.evaluation.status === 'succeeded');
check('runtime completes a mission', completed.status === 'SUCCEEDED');
check('runtime persists a separate Run record', (await runtime.getRun(created.id)).status === 'SUCCEEDED');
check('runtime persists checkpoints', completed.checkpoint?.revision === completed.revision);
check('runtime keeps an event trail', events.length >= 8);
check('event sequence allocator survives repeated observations', eventSequences.size === events.length);
const restartedRuntime = new HarnessRuntime({ store, passport, capabilities: runtimeCapabilities, clock, idFactory: () => 'unused' });
check('runtime recovers the latest Run after restart', (await restartedRuntime.getRun(created.id)).status === 'SUCCEEDED');
check('runtime recovers the Mission Computer plan after restart', (await restartedRuntime.getPlan(created.id)).digest === completed.metadata?.missionPlan?.digest);
try {
  await runtime.startRunning(created.id);
  check('terminal missions cannot resume', false);
} catch {
  check('terminal missions cannot resume', true);
}

console.log('\n5. Capability policy\n');
const capabilities = new CapabilityRegistry();
capabilities.register({
  id: 'read.example', name: 'Read example', description: 'Read a record.', risk: 'read',
  inputSchema: { type: 'object' }, requiresApproval: false,
});
capabilities.register({
  id: 'write.example', name: 'Write example', description: 'Write a record.', risk: 'update',
  inputSchema: { type: 'object' }, requiresApproval: true,
});
const authority = { actorId: 'user-1', allowedCapabilityIds: ['read.example', 'write.example'], autoApproveRiskAtMost: 'read' };
check('capability registry discovers tools deterministically', capabilities.list().map((item) => item.id).join(',') === 'read.example,write.example');
check('read capability is allowed within the authority ceiling', capabilities.authorize('read.example', authority).decision === 'allow');
check('write capability requires approval', capabilities.authorize('write.example', authority).decision === 'require_approval');
check('ungranted capability is denied', capabilities.authorize('read.example', { ...authority, allowedCapabilityIds: [] }).decision === 'deny');
// Previously: authorize(..., { dryRun: true }) returned 'dry_run' for a write,
// short-circuiting the approval gate. A requester-supplied flag can no longer
// change an authorization decision at all -- extra arguments are ignored and
// the write still requires a human.
check('a requester-supplied dry-run flag cannot change an authorization',
  capabilities.authorize('write.example', authority, { dryRun: true }).decision === 'require_approval');
const toolCall = createToolCall({ id: 'tool-1', missionId: 'mission-1', capabilityId: 'read.example', arguments: { id: 1 }, requestedAt: clock().toISOString() });
check('tool calls carry a stable arguments digest', /^[a-f0-9]{64}$/.test(toolCall.argumentsDigest));

console.log('\n6. PostgreSQL persistence\n');
const durableDb = new PGlite();
await applyMigrations(durableDb);
const durablePassportId = randomUUID();
await durableDb.query(`INSERT INTO passports (id, name) VALUES ($1, 'Durable Test Passport')`, [durablePassportId]);
await durableDb.query(
  `INSERT INTO memories (passport_id, type, title, content, metadata, origin, updated_at)
   VALUES ($1, 'note', 'new asserted', 'not trusted', '{}'::jsonb, 'local', '2026-08-16T11:00:00Z'),
          ($1, 'note', 'older evidenced', 'trusted context', '{"evidence":["docs/old.md"]}'::jsonb, 'local', '2026-08-15T11:00:00Z')`,
  [durablePassportId],
);
const durableStore = new PostgresMissionStore(durableDb);
const durablePassport = new PostgresPassportAdapter(durableDb);
const filteredContext = await durablePassport.loadContext({ passportId: durablePassportId, missionId: 'durable-mission', maxMemories: 1 });
check('Passport adapter does not let raw SQL LIMIT starve eligible context', filteredContext.memories.some((memory) => memory.status === 'evidenced'));
const durableRuntime = new HarnessRuntime({
  store: durableStore,
  passport: durablePassport,
  clock,
  idFactory: randomUUID,
});
const durableMission = await durableRuntime.createMission({ ...spec, passportId: durablePassportId });
const durableBound = await durableRuntime.bindNeuralink(durableMission.id);
const durableSession = durableRuntime.getNeuralink(durableMission.id);
const durableCandidate = durableSession.proposeCandidate({
  content: 'A confirmed harness fact.',
  sourceEventIds: ['durable-event-1'],
  evidence: ['postgres://evidence/1'],
  scope: 'This durable test mission.',
  outcomeStatus: 'confirmed',
});
const durableDecision = await durableSession.reviewCandidate(durableCandidate, { explicitApproval: true });
await durableRuntime.beginPlanning(durableMission.id);
const durableSaved = await durableStore.get(durableMission.id);
const durableRun = await durableRuntime.getRun(durableMission.id);
const durableEvents = await durableStore.listEvents(durableMission.id);
const collisionEvent = {
  id: 'collision-a', missionId: durableMission.id, runId: durableRun.id, sequence: 5000,
  type: 'tool_completed', actor: 'test', payload: {}, createdAt: clock().toISOString(),
};
await durableStore.appendEvent(collisionEvent);
const reassignedCollision = await durableStore.appendEvent({ ...collisionEvent, id: 'collision-b' });
const { rows: [durableMemory] } = await durableDb.query(
  `SELECT content, metadata FROM memories WHERE passport_id = $1 AND type = 'omnibox'`,
  [durablePassportId],
);
check('PostgreSQL store persists the mission', durableSaved?.status === 'PLANNING');
check('Neuralink publishes only an approved candidate', durableDecision.action === 'promote' && durableMemory?.content === 'A confirmed harness fact.');
check('PostgreSQL store persists the separate Run', durableRun.status === 'CREATED' && durableRun.missionId === durableMission.id);
check('PostgreSQL store persists the context digest', durableSaved?.contextDigest === durableBound.context.digest);
check('PostgreSQL store persists mission metadata', durableSaved?.metadata?.missionPlan?.digest === durableBound.mission.metadata?.missionPlan?.digest);
check('PostgreSQL store persists the harness event spine', durableEvents.length >= 4);
check('PostgreSQL event append retries a cross-runtime sequence collision', reassignedCollision.sequence > collisionEvent.sequence);
if (!durableSaved) throw new Error('durable mission missing for conflict test');
const staleMission = durableSaved;
await durableStore.save({ ...staleMission, revision: staleMission.revision + 1 }, staleMission.revision);
try {
  await durableStore.save({ ...staleMission, revision: staleMission.revision + 1 }, staleMission.revision);
  check('PostgreSQL store rejects stale mission writes', false);
} catch (error) {
  check('PostgreSQL store rejects stale mission writes', /revision conflict/.test(String(error)));
}
await durableDb.close();

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
