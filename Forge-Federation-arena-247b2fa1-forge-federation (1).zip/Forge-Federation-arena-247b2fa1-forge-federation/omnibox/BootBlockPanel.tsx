"use client";

import { useCallback, useEffect, useState } from "react";
import { Sparkles, Copy, Check, X, RefreshCw, AlertTriangle } from "lucide-react";

interface Props {
  passportId: string;
  onClose: () => void;
}

interface BootBlock {
  text: string;
  includedCount: number;
  omittedCount: number;
  omitted: Array<{ id: string; title: string; reason: "low-confidence" | "budget" }>;
  estimatedTokens: number;
  truncated: boolean;
}

const BUDGETS = [1000, 2000, 4000];

/**
 * The boot block, shown before it is copied.
 *
 * Showing it matters: this is the text that will speak for you in somebody
 * else's session, and what was *left out* is as important as what went in —
 * so the omissions are listed with their reason rather than hidden behind a
 * count.
 */
export function BootBlockPanel({ passportId, onClose }: Props) {
  const [block, setBlock] = useState<BootBlock | null>(null);
  const [budget, setBudget] = useState(2000);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/passports/${passportId}/context?format=json&budget=${budget}`
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setBlock(await res.json());
      setError(null);
    } catch {
      setError("Could not compile the boot block.");
    } finally {
      setLoading(false);
    }
  }, [passportId, budget]);

  useEffect(() => {
    // State lands in a promise continuation after the request, not
    // synchronously in the effect body.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void load();
  }, [load]);

  const handleCopy = async () => {
    if (!block) return;
    try {
      await navigator.clipboard.writeText(block.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError("Clipboard blocked by the browser — select the text and copy manually.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl rounded-2xl bg-[#1a1f3a] border border-white/10 shadow-2xl overflow-hidden animate-fade-in">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-passport-400" />
            <h2 className="text-lg font-bold text-white">Boot block</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="px-6 py-4 space-y-4">
          <p className="text-sm text-slate-400">
            Settled claims plus their evidence, compiled small enough to paste at the
            top of a fresh session. Pinned memories always make it in; unpinned ones
            need confidence of 0.7 or better.
          </p>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Budget</span>
            {BUDGETS.map((option) => (
              <button
                key={option}
                onClick={() => setBudget(option)}
                className={`px-2.5 py-1 rounded-lg text-xs border transition ${
                  budget === option
                    ? "bg-passport-500/20 border-passport-500/40 text-passport-200"
                    : "bg-transparent border-white/[0.06] text-slate-400 hover:text-white"
                }`}
              >
                {option} tokens
              </button>
            ))}
            <button
              onClick={() => void load()}
              className="ml-auto p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
              title="Recompile"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>

          {error && (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">
              {error}
            </div>
          )}

          <pre className="max-h-72 overflow-auto rounded-xl bg-black/40 border border-white/[0.06] p-4 text-xs text-slate-200 whitespace-pre-wrap font-mono">
            {loading ? "Compiling…" : block?.text}
          </pre>

          {block && (
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
              <span>{block.includedCount} claims in</span>
              <span>~{block.estimatedTokens} tokens</span>
              {block.omittedCount > 0 && (
                <span className="flex items-center gap-1 text-amber-400">
                  <AlertTriangle className="h-3 w-3" />
                  {block.omittedCount} left out
                </span>
              )}
            </div>
          )}

          {block && block.omitted.length > 0 && (
            <details className="rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
              <summary className="text-xs text-slate-400 cursor-pointer">
                What was left out, and why
              </summary>
              <ul className="mt-2 space-y-1">
                {block.omitted.slice(0, 25).map((item) => (
                  <li key={item.id} className="text-xs text-slate-400 flex gap-2">
                    <span className="text-slate-600 shrink-0">
                      {item.reason === "budget" ? "budget" : "confidence"}
                    </span>
                    <span className="truncate">{item.title}</span>
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-white/[0.06]">
          <a
            href={`/api/passports/${passportId}/context?budget=${budget}`}
            target="_blank"
            rel="noreferrer"
            className="px-4 py-2 text-sm text-slate-300 hover:text-white rounded-lg hover:bg-white/5 transition"
          >
            Open as markdown
          </a>
          <button
            onClick={handleCopy}
            disabled={!block}
            className="flex items-center gap-2 px-4 py-2 bg-passport-600 hover:bg-passport-500 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition"
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied" : "Copy boot block"}
          </button>
        </div>
      </div>
    </div>
  );
}
