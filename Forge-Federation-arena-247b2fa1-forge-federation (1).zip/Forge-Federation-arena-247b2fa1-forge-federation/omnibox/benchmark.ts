import type { MissionEvaluation } from './mission-computer.ts';

export type PilotRun = {
  pilotId: string;
  model: string;
  planDigest: string;
  contextDigest: string;
  evaluation: MissionEvaluation;
  recovered: boolean;
  toolCalls: number;
  approvalsRequested: number;
  approvalsCorrect: number;
  memoryItemsUsed: number;
  costUsd: number;
  durationMs: number;
};

export type PilotScore = {
  pilotId: string;
  model: string;
  missionSuccess: number;
  recoveryRate: number;
  toolEfficiency: number;
  approvalAccuracy: number;
  memoryUsage: number;
  costUsd: number;
  durationMs: number;
  planDigest: string;
  contextDigest: string;
};

export type PilotBenchmark = {
  missionId: string;
  pilots: PilotScore[];
  invariant: {
    samePlan: boolean;
    sameContext: boolean;
  };
};

/**
 * Compare pilots while holding the aircraft constant. The benchmark measures
 * the pilot's contribution; the plan, Passport frame, policy and capability
 * surface must be identical for every run.
 */
export function benchmarkPilots(
  missionId: string,
  runs: PilotRun[],
  expectedToolCalls = 1,
): PilotBenchmark {
  if (runs.length === 0) throw new Error('pilot benchmark requires at least one run');
  const first = runs[0];
  const pilots = runs.map((run) => ({
    pilotId: run.pilotId,
    model: run.model,
    missionSuccess: run.evaluation.status === 'succeeded' ? 1 : 0,
    recoveryRate: run.recovered ? 1 : 0,
    toolEfficiency: Math.min(1, expectedToolCalls / Math.max(1, run.toolCalls)),
    approvalAccuracy: run.approvalsRequested === 0
      ? 1
      : run.approvalsCorrect / run.approvalsRequested,
    memoryUsage: run.memoryItemsUsed,
    costUsd: run.costUsd,
    durationMs: run.durationMs,
    planDigest: run.planDigest,
    contextDigest: run.contextDigest,
  }));
  return {
    missionId,
    pilots,
    invariant: {
      samePlan: runs.every((run) => run.planDigest === first.planDigest),
      sameContext: runs.every((run) => run.contextDigest === first.contextDigest),
    },
  };
}
