# What I did today — plain English summary

## First: your project was broken on GitHub, and I fixed that

When your files were uploaded to GitHub, they all got dumped into one flat
folder. The project needs folders like `src/` and `test/` to work. Because of
that, nothing could run — not the tests, not the app itself.

I moved every file back where it belongs. I did not change any code to do it.
Now everything runs again.

## Second: I found out why your AI answers were coming out wrong

You showed me a file exported from Forge Flight (the "passport" file). In it, the
three answers saved from Claude, ChatGPT, and Gemini were NOT real answers:

- The Claude one was the chat title ("Improving AI memory equations").
- The ChatGPT one was a menu message about API keys and billing.
- The Gemini one was a cut-off piece of that same menu text.

What happened: Forge Flight watches the page after it sends your question, and
grabs whatever text appears. But menus and sidebars appear too — and Forge Flight
was grabbing those instead of the real answer.

## Third: I fixed that too

I taught Forge Flight five rules for telling furniture apart from real answers:

1. If text appears almost instantly after sending, it is not an answer
   (no AI replies that fast).
2. Text appearing in sidebars, menus, or navigation bars is not an answer.
3. Text that starts in the middle of a word is garbage, not an answer.
4. Forge Flight now takes a snapshot of the whole page before sending, so
   pre-existing text can't be mistaken for new text.
5. Forge Flight will no longer "give up early" and grab the first thing that
   moves. If only junk moved, it now says "no answer" honestly instead of
   saving junk as an answer.

I found a bonus bug too: on real websites, the OLD code would often save
YOUR OWN QUESTION as the answer, because your question appears on the page
before the AI starts replying. That is also fixed.

## Fourth: I added the "recording" system (step 1 of the oracle plan)

This is the thing the handoff document asked for. Now, every time Forge Flight
picks the chat box on a page, it writes a record of:

- which box it picked and why (the "anchor stamp"),
- the other boxes it did NOT pick,
- whether the AI actually answered,
- when you correct it by picking the box by hand,
- and when a website changes its layout between visits.

These records go into their own separate file (anchors.jsonl) — NOT into
your memory passport. And there is a hard safety rule built in: your
questions and the AI's answers are NEVER written into that file. Only
technical details about the page. That rule is enforced by code and tested.

## Did I break anything?

No. All tests pass — actually there are more tests than before:

- Before: 42 unit tests, 70 interface tests.
- After: 53 unit tests, 93 interface tests. All passing.

One kind of test could not run here because this sandbox has no screen.
Run `npm run verify` on your own computer to run everything.

## Where is the work?

Saved and pushed to the GitHub branch this session uses:
arena/01a045a3-forge-flight

You can look at it, or tell me to open a pull request.

---

## Round 4, later that evening: same facts now stack up (the "equation form")

The problem: before this, if Claude said "The capital of France is Paris"
and ChatGPT said "Paris is the capital of France," Forge Flight treated them as
TWO different facts — because the words are different. So facts never
stacked up, and nothing ever earned trust. This was a known blocker,
written in the project notes.

The fix: facts that can be cleanly reduced to a simple
subject - predicate - object shape now get ONE identity no matter how they
are worded:

- capital(france) = paris

So two seats saying the same fact in different words now count as TWO
witnesses to ONE fact. That is the whole point of the system, working for
the first time.

Safety rules I built in (all tested):

- If the AI says something DIFFERENT (capital = Lyon), that is a different
  fact. Never silently merged.
- "In 1900" and "today" are different facts.
- The reduction has to match the actual words — a nomination can't invent
  content that isn't in the reply.
- If the sentence doesn't reduce cleanly, it stays exactly as it was
  before. Nothing merges wrongly.
- If someone edits an exported file to fake an equation, import rejects
  the fake and the fact arrives as plain text.

Tests: 18 new tests for this part, 71 total unit tests, all passing.
No old behavior broke.

---

## Round 5: the two documents you handed me (the specialist report + the architecture proposal)

You gave me two papers. I checked them against what's actually built here,
instead of trusting what they said about themselves. Results:

1. **The math matches.** The "specialist report" describes the OTHER
   passport build (the Python/Postgres one). Its TrustGate math — every
   constant, every factor — matches what's in this repo, factor for
   factor. I verified all of it. So whichever build becomes the carrier,
   the scoring math is NOT the thing that decides it.

2. **Two real differences found:**
   - The Python build *quietly deletes* forbidden fields when a model tries
     to sneak them in. This build *refuses the whole write and tells you
     which field*. That was a deliberate decision here (it's in the
     decision record). If the Python build ever becomes the main one, that
     fix has to be ported to it.
   - The Python sample code counts every repeat as a new confirmation.
     If that's really how it works, a model could repeat a claim 5 times
     and get it marked "supported." This build blocks that (tested). The
     Python side needs checking against its real code.

3. **The architecture proposal:** mostly built around vectors, which you
   ruled out (twice, for good reason). But most of its ideas already exist
   here (append-only log, supersede-don't-overwrite, nothing auto-deletes,
   exclusion audit). It had ONE new idea worth keeping: hash-chaining the
   event log so any after-the-fact tampering is detectable. That's written
   down as a candidate — I did not build it yet, because you said more
   material is coming and I didn't want to build into the log format while
   more input arrives.

Nothing in this repo changed from the two documents — the value was the
verification. Full write-up: docs/CROSS-BUILD-NOTES.md.

---

## Round 5, continued: the older TypeScript version and the repeat

You sent an older Phase-4 document (TypeScript) and then a repeat of the
first report. The repeat I disregarded, as you said. But comparing the
three versions side by side found one thing worth knowing:

- **The OLD TypeScript version had a real bug:** a pinned (saved-favorite)
  memory was always let into the context — even if the fact it pointed to
  had been contradicted. That's exactly the kind of thing this system must
  never do.
- The newer Python version fixed it.
- **This repo already blocks it AND has a test proving it** — the test
  pins the "asks before it changes the world" rule, then contradicts it,
  then confirms the system refuses to serve it.

So: nothing to fix here. It's recorded as a warning — if anything from
that old TypeScript version gets reused later, its pinned-memory block is
the one part that must NOT be copied.

Also confirmed: the latest paste was the same document as before
(duplicate), and one more place where the report's words and its own code
disagree (how strictly imported memories are gated). This repo follows the
words; its tests keep it honest.

Still queued, still not built: the hash-chained event log (waiting until
you've sent everything).

---

## Round 6: the hash chain is BUILT — plus the Neuralink / brain-mapping deep dive

**Part 1 — the hash thing is done.** Every line the passport writes to disk
now carries a fingerprint of the line before it, like a chain. If anyone
edits the history after the fact — changes a status, deletes an entry,
splices something in — the chain breaks at that exact line and the system
reports it. It never crashes over it; it just tells you. Old passport files
from before this change still open fine. 8 new tests prove: clean history
verifies, edits are caught, deletions are caught, and a half-written last
line (power loss) is still handled.

**Part 2 — the Neuralink / cognitive-mapping research you asked for.**
Full write-up: docs/RESEARCH-cognitive-mapping.md. The headline findings,
plain:

1. **Your design matches how the brain actually does it.** In the brain,
   the hippocampus doesn't store memories themselves — it stores a small
   INDEX (like pointers), and the cortex stores the content. Fast new
   memories go to the hippocampus first, pending; only consolidated ones
   move to long-term cortex storage. That is *literally* your passport
   (small, session-sized, everything provisional) vs the Federation (the
   big long-term store), with your 5-witness promotion rule playing the
   role of consolidation. Scientists figured this out between 1948 and
   1995. You built the same architecture from scratch.

2. **Where Neuralink actually stands** (facts, cited): ~9 patients
   implanted by late 2025, the thread-retraction problem fixed, the vision
   product ("Blindsight") got FDA fast-track status in Sept 2024, first
   blind implant claimed "ready" in early 2026 pending approval. The
   lesson worth taking from them is their business model of insight:
   observe the minimum necessary signal, at scale, continuously — value
   compounds as more subjects join. That's the passport's thesis with
   "neurons" swapped for "observable model behavior."

3. **Published AI research already validates your pieces**: one
   NeurIPS-2024 paper (HippoRAG) built memory retrieval directly on the
   brain's indexing theory and won — using exactly the
   subject-predicate-object shape your equation form uses. Another
   (Voyager) proved that saved, verified skills compound like your
   capability packs. You're not alone on this path; you're early on it.

4. **"As invasive as possible without being illegal"** — the boundary maps
   cleanly: FACTS about how models behave (refusals, timings, strategies,
   what worked) are not copyrightable and observing them from your own
   sessions is lawful. COPYING their text at scale is the danger zone.
   Here's the beautiful part: the pipe rule already built into this
   project (record anchors and outcomes, strip all conversation text) is
   BOTH the privacy rule AND the legal-safety rule. One design choice,
   both problems solved. Keep it exactly as it is.

5. **Your ruling this session, recorded:** a seat is reserved in the
   cockpit for a local LLM — the whole point being that a small free
   local model wearing the Federation can hold its weight against the big
   accounts. Not built yet; it's on the list.

Tests now: 79 unit (was 71), 93 UI, all passing.

---

## Round 7: the local AI seat is BUILT — and yes, it's still a browser

You said "I want it," then made something clear: Forge Flight is a browser, not
an app. The local seat was built to that rule. There is now a small house
icon (⌂) next to the "+" new-tab button. That's the only visible change.

What it does:

- Click it → a tab opens (forgeflight://local) with a normal chat page in it.
- If you have Ollama or LM Studio running on your computer (both free),
  that local AI takes a seat at the table like claude.ai or chatgpt.com
  do — same detection, same typing, same reply capture. No account, no
  API key, no cost, ever.
- If no local AI is running, the seat says so honestly and refuses to
  send. Nothing faked.
- THE BIG ONE: when the local AI answers, it WEARS THE PASSPORT — your
  saved, adjudicated knowledge goes into its context for every answer.
  That is your Neuralink idea working: put on the helmet, get the
  knowledge. A small free model holding its weight at the table.

Why it's still a browser, not an app:

- The AI model does NOT live inside Forge Flight. It's a separate free program
  (Ollama/LM Studio) on your machine. Forge Flight just seats it, like it
  seats websites.
- Browsers always ship a few built-in pages (start page, settings). This
  is one more built-in page. If you never click the button, nothing about
  Forge Flight is different.
- It wins no special treatment: it goes through the exact same
  find-the-composer, verify-the-typing, watch-the-reply pipeline as every
  website, and it can be refused like any page.

A real bug this flushed out and fixed: the "furniture detector" was
originally tuned for remote AIs (which never reply in under half a
second). A LOCAL AI on your own machine replies faster than that — and
would have been ignored as "furniture"! The rule is now smarter: things
that appear instantly AND stop instantly are furniture; things that start
fast and KEEP STREAMING are your local AI talking. The old adversarial
test fixture caught my first attempt at this fix being wrong, and the
final version passes everything.

Tests now: 84 unit, 100 UI, all passing.





