'use client'

/**
 * THE FLIGHT DECK.
 *
 * Design direction: a benchtop laboratory instrument, not a spaceship.
 * Every competing AI browser is dark-mode sci-fi; this is paper-white,
 * monospace throughout, hairline-ruled. The product is a measuring device
 * — it counts, it attributes, and it refuses — so it should read like one.
 *
 * The signature element is the seat strip: five channels across the top,
 * each showing who is seated and how much allowance is left. It is always
 * visible because it is the only thing here nobody else ships.
 *
 * React correctness notes, since the previous version failed on all three:
 *   - No ref is assigned during render.
 *   - No setState runs synchronously inside an effect; every state write
 *     lands in a promise continuation after a fetch.
 *   - No Math.random() in the component body; ids come from a module-scope
 *     counter, which is also collision-free within a millisecond.
 */

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import { inShell, navigate, readPage, onTab, toUrl, hostOf, type TabState, type ShellWitness } from '@/lib/shell'
import { BELTS, type BeltId } from '@/lib/belts.ts'

type ProposedAction = {
  capabilityId: string
  arguments: Record<string, unknown>
  intent?: string
  seatIndex?: number
  label?: string
}

// ── tokens ───────────────────────────────────────────────────────────────
// paper  #FBFAF7   warm ground        ink    #14140F   near-black
// rule   #D8D5CC   hairline           signal #1B3FCB   active / answered
// held   #B0812A   waiting / unknown  refuse #A8281E   refused / exhausted

const MONO = "ui-monospace, 'SF Mono', 'Cascadia Mono', 'Roboto Mono', Menlo, monospace"

type SeatStatus = 'empty' | 'boarding' | 'seated' | 'flying' | 'ejected'
type PilotType =
  | 'local' | 'claude' | 'gemini' | 'gpt' | 'grok'
  | 'mistral' | 'deepseek' | 'perplexity' | 'custom'

type Seat = {
  index: number
  typelock: PilotType | null
  status: SeatStatus
  pilot: { pilotId: string; type: PilotType; label: string } | null
  lastChanged: string
  missionCount: number
}

type CockpitState = {
  seats: Record<string, Seat>
  shape: Shape
  activeMissionId: string | null
}

type Shape = 'communal' | 'adversarial' | 'relay' | 'interview' | 'sidebar' | 'free'

type BudgetRow = {
  seatIndex: number
  tier: string
  status: 'ok' | 'exhausted' | 'unmetered'
  usage: { calls: number; usd: number; spentOnFailure: number }
  remainingCalls: number | null
}

type Answer = {
  seatIndex: number
  label: string
  type: PilotType
  roleContext: string
  text: string
  tookMs: number
  provider: string
  error?: string
}

const SHAPES: Array<{ id: Shape; name: string; blurb: string }> = [
  { id: 'communal', name: 'All at once', blurb: 'Everyone answers the same prompt independently' },
  { id: 'adversarial', name: 'Argue it', blurb: 'Seats split into two sides and take each other on' },
  { id: 'relay', name: 'Relay', blurb: 'Each seat answers in turn, seeing what came before' },
  { id: 'interview', name: 'Interview', blurb: 'One seat asks, the rest answer' },
  { id: 'sidebar', name: 'Sidebar', blurb: 'Two seats talk, the others watch' },
  { id: 'free', name: 'Open', blurb: 'No enforced structure' },
]

const TYPES: PilotType[] = [
  'local', 'claude', 'gemini', 'gpt', 'grok', 'mistral', 'deepseek', 'perplexity', 'custom',
]

// Module scope on purpose: react-hooks/purity flags Math.random anywhere in a
// component body, and a counter cannot collide inside one millisecond anyway.
let pilotSeq = 0
function newPilotId(type: string): string {
  pilotSeq += 1
  return `${type}-${Date.now().toString(36)}-${pilotSeq}`
}

async function call(url: string, body?: unknown): Promise<Record<string, unknown>> {
  const res = await fetch(url, body === undefined ? { cache: 'no-store' } : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  let data: Record<string, unknown> = {}
  try { data = await res.json() as Record<string, unknown> } catch { /* empty body */ }
  if (!res.ok || typeof data.error === 'string') {
    throw new Error(typeof data.error === 'string' ? data.error : `${res.status} ${res.statusText}`)
  }
  return data
}

export default function CockpitPage() {
  const [state, setState] = useState<CockpitState | null>(null)
  const [budget, setBudget] = useState<BudgetRow[]>([])
  const [shape, setShape] = useState<Shape>('communal')
  const [prompt, setPrompt] = useState('')
  const [answers, setAnswers] = useState<Answer[]>([])
  const [missionId, setMissionId] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [picker, setPicker] = useState<number | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [shell, setShell] = useState(false)
  const [tab, setTab] = useState<TabState | null>(null)
  const [address, setAddress] = useState('')
  const [witness, setWitness] = useState<ShellWitness | null>(null)
  const [navNote, setNavNote] = useState<{ kind: 'refused' | 'error'; text: string } | null>(null)
  const [sharedHash, setSharedHash] = useState<string | null>(null)
  const [attachPage, setAttachPage] = useState(true)
  const [keysHint, setKeysHint] = useState<string | null>(null)
  const [beltId, setBeltId] = useState<BeltId>('talk')
  const [holster, setHolster] = useState<{ a: BeltId; b: BeltId }>({ a: 'browse', b: 'remember' })
  const [proposed, setProposed] = useState<ProposedAction[]>([])
  const [proposalNote, setProposalNote] = useState<string | null>(null)

  const refresh = useCallback(async () => {
    try {
      const seats = await call('/api/harness/cockpit/seats')
      const cockpit = seats.state as CockpitState
      setState(cockpit)
      if (cockpit?.shape) setShape(cockpit.shape)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setLoaded(true)
    }
    try {
      const b = await call('/api/harness/cockpit/budget')
      setBudget((b.seats as BudgetRow[]) ?? [])
    } catch {
      setBudget([])
    }
  }, [])

  useEffect(() => {
    // Fetch on mount. Every setState inside refresh lands after an await, so
    // there is no synchronous cascade — and a load that must happen once per
    // mount has no non-effect home.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void refresh()
    void fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data?.anyModel) {
          setKeysHint(null)
          return
        }
        setKeysHint(
          'No model key is configured yet. Seat 0 talks to Ollama on this machine. The other seats need HF_TOKEN, or a provider key, or they will come back with a plain error instead of an answer.',
        )
      })
      .catch(() => undefined)
  }, [refresh])

  useEffect(() => {
    // `window.omnibox` only exists inside the desktop shell, so this cannot be
    // read during render — the server render has no window at all.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setShell(inShell())
    return onTab(setTab)
  }, [])

  useEffect(() => {
    try {
      const raw = localStorage.getItem('omnibox.holster')
      if (!raw) return
      const parsed = JSON.parse(raw) as { a?: BeltId; b?: BeltId }
      const ids = new Set(BELTS.map((belt) => belt.id))
      if (parsed.a && ids.has(parsed.a) && parsed.b && ids.has(parsed.b)) {
        // localStorage is not available during SSR, so the holster has to
        // land after mount. Same pattern as `setShell(inShell())` above.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setHolster({ a: parsed.a, b: parsed.b })
      }
    } catch {
      /* holster is a convenience, not a contract */
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem('omnibox.holster', JSON.stringify(holster))
    } catch {
      /* ignore quota / private mode */
    }
  }, [holster])

  const go = async (raw: string) => {
    const url = toUrl(raw)
    if (!url) {
      setNavNote({ kind: 'error', text: 'That is not a web address. Type a host like example.com.' })
      return
    }
    setBusy('Opening')
    setNavNote(null)
    const outcome = await navigate(url)
    setBusy(null)
    if (outcome.status === 'done') {
      setWitness(outcome.witness)
      setAddress(outcome.result.url)
    } else if (outcome.status === 'refused') {
      // A refusal is the gate working. It is shown as an outcome, not as a
      // failure, because presenting it as breakage invites a retry loop.
      setWitness(null)
      setNavNote({ kind: 'refused', text: outcome.reason })
    } else if (outcome.status === 'error') {
      setWitness(null)
      setNavNote({ kind: 'error', text: outcome.message })
    }
  }

  const board = async (seatIndex: number, type: PilotType) => {
    setPicker(null)
    setBusy(`Seating ${type} in ${seatIndex}`)
    setError(null)
    try {
      await call('/api/harness/cockpit/seats', {
        action: 'board', seatIndex, type, label: type, pilotId: newPilotId(type),
      })
      await refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const eject = async (seatIndex: number) => {
    setBusy(`Clearing seat ${seatIndex}`)
    setError(null)
    try {
      await call('/api/harness/cockpit/seats', { action: 'eject', seatIndex })
      await call('/api/harness/cockpit/seats', { action: 'clear', seatIndex })
      await refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const chooseShape = async (next: Shape) => {
    setBusy('Changing structure')
    setError(null)
    try {
      await call('/api/harness/cockpit/shape', { shape: next })
      setShape(next)
      await refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const fireProposed = async (item: ProposedAction, index: number) => {
    setBusy(`Firing ${item.capabilityId}`)
    setError(null)
    setProposalNote(null)
    try {
      const res = await fetch('/api/harness/functions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          capabilityId: item.capabilityId,
          args: item.arguments,
          intent: item.intent,
          beltId,
          missionId: missionId ?? undefined,
        }),
      })
      const data = await res.json() as {
        error?: string
        awaitingApproval?: boolean
        result?: { status?: string; output?: unknown }
        missionId?: string
      }
      if (data.missionId) setMissionId(data.missionId)
      if (res.status === 202 || data.awaitingApproval) {
        setProposalNote(`${item.capabilityId} is waiting for you at the gun base.`)
        return
      }
      if (!res.ok) throw new Error(data.error || res.statusText)
      setProposed((prev) => prev.filter((_, i) => i !== index))
      setProposalNote(
        data.result?.status === 'succeeded'
          ? `${item.capabilityId} ran.`
          : `${item.capabilityId} returned ${data.result?.status ?? 'done'}.`,
      )
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const send = async () => {
    const text = prompt.trim()
    if (!text) return
    setBusy('Waiting on the seats')
    setError(null)
    setAnswers([])
    setSharedHash(null)
    try {
      // Read the page ONCE and hand the same bytes to every seat.
      //
      // Letting each seat fetch its own copy would be the obvious shortcut and
      // it would destroy the only thing that makes these answers comparable:
      // if two seats disagree, you could never rule out that they were shown
      // different pages. One read, one hash, five readers — that is what makes
      // a divergence a measurement instead of an anecdote.
      let page: Record<string, unknown> | undefined
      if (shell && attachPage && tab?.url && tab.url !== 'about:blank') {
        const read = await readPage()
        if (read.status === 'done') {
          page = {
            url: read.result.url,
            title: read.result.title,
            text: read.result.text,
            contentHash: read.result.contentHash,
          }
          setSharedHash(read.result.contentHash)
        } else if (read.status === 'refused') {
          // Proceed without the page rather than silently handing the seats an
          // empty one. A seat told nothing is honest; a seat told "the page was
          // blank" is being lied to.
          setNavNote({ kind: 'refused', text: `Page not read: ${read.reason}. The seats are answering without it.` })
        }
      }

      const body: Record<string, unknown> = { prompt: text, beltId }
      if (page) body.page = page

      const data = await call('/api/harness/cockpit/prompt', body)
      setAnswers((data.responses as Answer[]) ?? [])
      setProposed(Array.isArray(data.proposed) ? data.proposed as ProposedAction[] : [])
      const mission = data.mission as { id?: string } | undefined
      if (mission?.id) setMissionId(mission.id)
      await refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err))
    } finally {
      setBusy(null)
    }
  }

  const seats: Seat[] = [0, 1, 2, 3, 4].map((i) => state?.seats?.[String(i)] ?? {
    index: i, typelock: i === 0 ? 'local' : null, status: 'empty',
    pilot: null, lastChanged: '', missionCount: 0,
  })
  const seatedCount = seats.filter((s) => s.pilot).length
  const budgetFor = (i: number) => budget.find((b) => b.seatIndex === i)

  return (
    <div style={{ fontFamily: MONO }} className="min-h-screen bg-[#FBFAF7] text-[#14140F]">

      {/* ── instrument header ─────────────────────────────────────────── */}
      <header className="border-b border-[#D8D5CC] px-4 sm:px-6 py-3 flex items-baseline gap-4 flex-wrap">
        <h1 className="text-sm font-bold tracking-[0.22em] uppercase">OmniBox</h1>
        <span className="text-[10px] tracking-[0.18em] uppercase text-[#14140F]/45">Flight deck</span>
        <div className="ml-auto flex items-center gap-4 text-[10px] tracking-[0.14em] uppercase text-[#14140F]/45">
          <span>{seatedCount} of 5 seated</span>
          <span className={shell ? 'text-[#1B3FCB]' : ''}>{shell ? 'Governed engine' : 'Browser tab'}</span>
          <Link href="/passport" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">
            Passport
          </Link>
          <Link href="/functions" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">
            Gun base
          </Link>
          <Link href="/browser" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">
            Browser
          </Link>
          <Link href="/lab" className="hover:text-[#1B3FCB] underline underline-offset-4 decoration-[#D8D5CC]">
            Lab
          </Link>
        </div>
      </header>

      {/* ── the seat strip: the signature ─────────────────────────────── */}
      <section className="border-b border-[#D8D5CC]">
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5">
          {seats.map((seat) => {
            const b = budgetFor(seat.index)
            const exhausted = b?.status === 'exhausted'
            const pct = b && b.remainingCalls !== null && b.usage.calls + b.remainingCalls > 0
              ? (b.remainingCalls / (b.usage.calls + b.remainingCalls)) * 100
              : 100
            const accent = exhausted ? '#A8281E' : seat.pilot ? '#1B3FCB' : '#D8D5CC'

            return (
              <div
                key={seat.index}
                className="border-r border-b border-[#D8D5CC] last:border-r-0 p-3 min-h-[132px] flex flex-col"
              >
                <div className="flex items-baseline justify-between">
                  <span className="text-[10px] tracking-[0.2em] text-[#14140F]/40">
                    SEAT {seat.index}{seat.typelock ? ' · LOCAL ONLY' : ''}
                  </span>
                  <span aria-hidden className="h-2 w-2 rounded-full" style={{ background: accent }} />
                </div>

                {seat.pilot ? (
                  <>
                    <div className="mt-2 text-[15px] font-bold leading-tight break-words">
                      {seat.pilot.label}
                    </div>
                    <div className="text-[10px] tracking-[0.14em] uppercase text-[#14140F]/45 mt-0.5">
                      {seat.pilot.type}
                    </div>

                    <div className="mt-auto pt-3">
                      {b && b.remainingCalls !== null ? (
                        <>
                          <div className="h-[3px] w-full bg-[#EFEDE6]">
                            <div className="h-full transition-[width] duration-500"
                              style={{ width: `${pct}%`, background: accent }} />
                          </div>
                          <div className="mt-1 text-[10px] text-[#14140F]/50">
                            {exhausted
                              ? 'Out of allowance'
                              : `${b.remainingCalls} calls left · ${b.usage.calls} used`}
                          </div>
                        </>
                      ) : (
                        <div className="text-[10px] text-[#14140F]/40">
                          {b ? `Unmetered · ${b.usage.calls} used` : 'Not yet flown'}
                        </div>
                      )}
                      <button
                        onClick={() => void eject(seat.index)}
                        className="mt-2 text-[10px] tracking-[0.14em] uppercase text-[#14140F]/40 hover:text-[#A8281E]"
                      >
                        Clear seat
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="mt-auto">
                    {picker === seat.index ? (
                      <div className="flex flex-wrap gap-1">
                        {(seat.typelock ? [seat.typelock] : TYPES).map((t) => (
                          <button
                            key={t}
                            onClick={() => void board(seat.index, t)}
                            className="px-1.5 py-0.5 text-[10px] border border-[#D8D5CC] hover:border-[#1B3FCB] hover:text-[#1B3FCB]"
                          >
                            {t}
                          </button>
                        ))}
                        <button
                          onClick={() => setPicker(null)}
                          className="px-1.5 py-0.5 text-[10px] text-[#14140F]/40 hover:text-[#14140F]"
                        >
                          cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setPicker(seat.index)}
                        className="w-full border border-dashed border-[#D8D5CC] py-2.5 text-[11px] tracking-[0.14em] uppercase text-[#14140F]/45 hover:border-[#1B3FCB] hover:text-[#1B3FCB]"
                      >
                        Seat a model
                      </button>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </section>

      {/* ── the governed address bar ──────────────────────────────────── */}
      <section className="px-4 sm:px-6 py-4 border-b border-[#D8D5CC]">
        <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">
          The page everyone is looking at
        </div>

        {shell ? (
          <>
            <div className="flex gap-1.5">
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') void go(address) }}
                spellCheck={false}
                style={{ fontFamily: MONO }}
                placeholder="example.com"
                className="flex-1 min-w-0 bg-white border border-[#D8D5CC] px-2.5 py-1.5 text-[12px] outline-none focus:border-[#1B3FCB] placeholder:text-[#14140F]/25"
              />
              <button
                onClick={() => void go(address)}
                disabled={!!busy}
                className="px-3 py-1.5 text-[10px] tracking-[0.16em] uppercase border border-[#14140F] hover:bg-[#14140F] hover:text-[#FBFAF7] disabled:opacity-25"
              >
                Open
              </button>
            </div>

            {tab?.url && tab.url !== 'about:blank' && (
              <div className="mt-2 flex items-baseline gap-2 text-[11px]">
                <span className="text-[#14140F]/40">{tab.loading ? 'loading' : 'on'}</span>
                <span className="font-bold truncate">{hostOf(tab.url)}</span>
                <span className="text-[#14140F]/45 truncate">{tab.title}</span>
              </div>
            )}

            {witness && (
              <div className="mt-2 border-l-2 border-[#1B3FCB] pl-2.5 py-1">
                <div className="text-[10px] tracking-[0.16em] uppercase text-[#1B3FCB]">Receipt</div>
                <div className="text-[10px] text-[#14140F]/55 break-all leading-relaxed">{witness.ref}</div>
                <div className="mt-0.5 text-[10px] text-[#14140F]/35">
                  Minted by the engine over the bytes that arrived. No model can produce this.
                </div>
              </div>
            )}

            {navNote && (
              <div
                className="mt-2 border-l-2 pl-2.5 py-1"
                style={{ borderColor: navNote.kind === 'refused' ? '#B0812A' : '#A8281E' }}
              >
                <div
                  className="text-[10px] tracking-[0.16em] uppercase"
                  style={{ color: navNote.kind === 'refused' ? '#B0812A' : '#A8281E' }}
                >
                  {navNote.kind === 'refused' ? 'Refused by the gate' : 'Did not open'}
                </div>
                <div className="text-[11px] text-[#14140F]/70 break-words">{navNote.text}</div>
              </div>
            )}
          </>
        ) : (
          <p className="text-[12px] text-[#14140F]/50 leading-relaxed max-w-lg">
            Browsing is governed by the desktop shell, so it is off here. In a browser tab
            this page can seat models and ask them things, but no seat can open, click, or
            read a page — there is no engine on this side to govern.{' '}
            <span className="text-[#14140F]/70">Run <code>npm run shell</code> to fly it.</span>
          </p>
        )}
      </section>

      {/* ── structure ─────────────────────────────────────────────────── */}
      <section className="px-4 sm:px-6 py-4 border-b border-[#D8D5CC]">
        <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">
          How they talk
        </div>
        <div className="flex flex-wrap gap-1.5">
          {SHAPES.map((s) => (
            <button
              key={s.id}
              onClick={() => void chooseShape(s.id)}
              title={s.blurb}
              className={`px-2.5 py-1 text-[11px] border transition-colors ${
                shape === s.id
                  ? 'border-[#1B3FCB] text-[#1B3FCB] bg-[#1B3FCB]/[0.05]'
                  : 'border-[#D8D5CC] text-[#14140F]/60 hover:border-[#14140F]/40 hover:text-[#14140F]'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-[#14140F]/45">
          {SHAPES.find((s) => s.id === shape)?.blurb}
        </p>
      </section>

      {/* ── gun belt ──────────────────────────────────────────────────── */}
      <section className="px-4 sm:px-6 py-4 border-b border-[#D8D5CC]">
        <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">
          What the captain is carrying
        </div>
        <div className="flex flex-wrap gap-1.5">
          {BELTS.map((belt) => (
            <button
              key={belt.id}
              onClick={() => setBeltId(belt.id)}
              title={belt.when}
              className={`px-2.5 py-1 text-[11px] border transition-colors ${
                beltId === belt.id
                  ? 'border-[#1B3FCB] text-[#1B3FCB] bg-[#1B3FCB]/[0.05]'
                  : 'border-[#D8D5CC] text-[#14140F]/60 hover:border-[#14140F]/40 hover:text-[#14140F]'
              }`}
            >
              {belt.name}
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px]">
          <span className="text-[10px] tracking-[0.16em] uppercase text-[#14140F]/40">Two-belt farm</span>
          {(['a', 'b'] as const).map((slot) => (
            <button
              key={slot}
              onClick={() => setBeltId(holster[slot])}
              onContextMenu={(e) => {
                e.preventDefault()
                setHolster((prev) => {
                  const next = { ...prev, [slot]: beltId }
                  try { localStorage.setItem('omnibox.holster', JSON.stringify(next)) } catch { /* ignore */ }
                  return next
                })
              }}
              className={`px-2 py-1 border ${
                beltId === holster[slot]
                  ? 'border-[#1B3FCB] text-[#1B3FCB]'
                  : 'border-[#D8D5CC] text-[#14140F]/60'
              }`}
              title="Click to load. Right-click to store the current belt here."
            >
              {slot.toUpperCase()} · {BELTS.find((b) => b.id === holster[slot])?.name ?? holster[slot]}
            </button>
          ))}
          <Link href="/functions" className="ml-auto text-[10px] tracking-[0.14em] uppercase text-[#14140F]/45 hover:text-[#1B3FCB]">
            Open the gun base
          </Link>
        </div>
        <p className="mt-2 text-[11px] text-[#14140F]/45 max-w-2xl">
          {BELTS.find((b) => b.id === beltId)?.blurb} Seat 0 — the local captain — is the only
          model that sees these guns. The other seats do not need to know.
        </p>
      </section>

      {/* ── prompt ────────────────────────────────────────────────────── */}
      <section className="px-4 sm:px-6 py-5">
        <label htmlFor="prompt" className="block text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40 mb-2">
          Ask every seated model
        </label>
        <textarea
          id="prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') void send()
          }}
          rows={3}
          style={{ fontFamily: MONO }}
          placeholder="What do you want them to work on?"
          className="w-full bg-white border border-[#D8D5CC] p-3 text-[14px] leading-relaxed resize-y outline-none focus:border-[#1B3FCB] placeholder:text-[#14140F]/25"
        />
        <div className="mt-2 flex items-center gap-3 flex-wrap">
          <button
            onClick={() => void send()}
            disabled={!!busy || seatedCount === 0 || !prompt.trim()}
            className="px-4 py-2 text-[11px] tracking-[0.16em] uppercase bg-[#14140F] text-[#FBFAF7] hover:bg-[#1B3FCB] disabled:opacity-25 disabled:hover:bg-[#14140F]"
          >
            {busy ? 'Working' : 'Send to all seats'}
          </button>
          <span className="text-[10px] text-[#14140F]/35">⌘↵</span>
          {shell && tab?.url && tab.url !== 'about:blank' && (
            <label className="flex items-center gap-1.5 text-[10px] tracking-[0.12em] uppercase text-[#14140F]/45 cursor-pointer">
              <input
                type="checkbox"
                checked={attachPage}
                onChange={(e) => setAttachPage(e.target.checked)}
                className="accent-[#1B3FCB]"
              />
              Show them the page
            </label>
          )}
          {busy && <span className="text-[11px] text-[#B0812A]">{busy}…</span>}
          {missionId && (
            <span className="ml-auto text-[10px] text-[#14140F]/35">
              mission {missionId.slice(0, 8)}
            </span>
          )}
        </div>

        {error && (
          <div className="mt-3 border-l-2 border-[#A8281E] bg-[#A8281E]/[0.04] px-3 py-2">
            <div className="text-[10px] tracking-[0.16em] uppercase text-[#A8281E]">Did not go through</div>
            <div className="mt-1 text-[12px] text-[#14140F]/75 break-words">{error}</div>
          </div>
        )}

        {proposed.length > 0 && (
          <div className="mt-4 border border-[#D8D5CC] bg-white">
            <div className="px-3 py-2 border-b border-[#D8D5CC] text-[10px] tracking-[0.16em] uppercase text-[#14140F]/45">
              The captain asked for a gun — nothing has fired
            </div>
            <ul className="divide-y divide-[#EFEDE6]">
              {proposed.map((item, index) => (
                <li key={`${item.capabilityId}-${index}`} className="px-3 py-2 flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-[12px] font-bold">{item.capabilityId}</div>
                    <div className="text-[11px] text-[#14140F]/55">
                      {item.label ? `Seat ${item.seatIndex} · ${item.label}` : 'Captain'}
                      {item.intent ? ` — ${item.intent}` : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      onClick={() => void fireProposed(item, index)}
                      disabled={!!busy}
                      className="text-[10px] tracking-[0.14em] uppercase text-[#14140F] border border-[#14140F] px-2 py-1 hover:bg-[#14140F] hover:text-[#FBFAF7] disabled:opacity-25"
                    >
                      Run it
                    </button>
                    <Link href="/functions" className="text-[10px] tracking-[0.14em] uppercase text-[#1B3FCB]">
                      Gun base
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {proposalNote && (
          <div className="mt-3 border-l-2 border-[#1B3FCB] pl-2.5 py-1 text-[11px] text-[#14140F]/70">
            {proposalNote}
          </div>
        )}
      </section>

      {/* ── answers ───────────────────────────────────────────────────── */}
      <section className="px-4 sm:px-6 pb-16">
        {answers.length > 0 ? (
          <>
            <div className="pt-1 border-t border-[#D8D5CC] mb-3">
              <div className="text-[10px] tracking-[0.2em] uppercase text-[#14140F]/40">
                {answers.length} {answers.length === 1 ? 'answer' : 'answers'}
              </div>
              {sharedHash && (
                <div className="mt-1.5 border-l-2 border-[#1B3FCB] pl-2.5 py-1">
                  <div className="text-[10px] tracking-[0.16em] uppercase text-[#1B3FCB]">
                    All seats read the same bytes
                  </div>
                  <div className="text-[10px] text-[#14140F]/55 break-all leading-relaxed">{sharedHash}</div>
                  <div className="mt-0.5 text-[10px] text-[#14140F]/35">
                    Where these answers differ, they differ on identical input. That is a
                    measurement, not a coincidence.
                  </div>
                </div>
              )}
            </div>
            <div className="grid gap-4 lg:grid-cols-2">
              {[...answers].sort((a, b) => a.seatIndex - b.seatIndex).map((a) => (
                <article
                  key={`${a.seatIndex}-${a.provider}-${a.tookMs}`}
                  className="border border-[#D8D5CC] bg-white"
                >
                  <div className="flex items-baseline gap-2 px-3 py-2 border-b border-[#D8D5CC] flex-wrap">
                    <span className="text-[10px] tracking-[0.2em] text-[#14140F]/40">
                      SEAT {a.seatIndex}
                    </span>
                    <span className="text-[13px] font-bold">{a.label}</span>
                    <span className="ml-auto text-[10px] text-[#14140F]/35">
                      {a.provider} · {(a.tookMs / 1000).toFixed(1)}s
                    </span>
                  </div>
                  {a.roleContext && (
                    <div className="px-3 pt-2 text-[10px] tracking-[0.1em] uppercase text-[#14140F]/35">
                      {a.roleContext}
                    </div>
                  )}
                  <div className="px-3 py-3 text-[13px] leading-relaxed whitespace-pre-wrap break-words">
                    {a.error
                      ? <span className="text-[#A8281E]">{a.error}</span>
                      : a.text || <span className="text-[#14140F]/35">Came back empty.</span>}
                  </div>
                </article>
              ))}
            </div>
          </>
        ) : loaded && (
          <div className="border-t border-[#D8D5CC] pt-8 max-w-xl">
            <p className="text-[15px] leading-relaxed">
              {seatedCount === 0
                ? 'Nobody is seated yet. Pick a model for a seat above, then ask a question — every seat answers it.'
                : 'Ready. Type something above and all seated models will answer at once.'}
            </p>
            {seatedCount === 0 && (
              <p className="mt-3 text-[12px] text-[#14140F]/50 leading-relaxed">
                Seat 0 takes a local model only. The rest take any provider. You need a key
                for that provider, or an HF_TOKEN, or the seat comes back with an error
                instead of an answer.
              </p>
            )}
            {keysHint && (
              <p className="mt-3 text-[12px] text-[#B0812A] leading-relaxed">{keysHint}</p>
            )}
          </div>
        )}
      </section>
    </div>
  )
}
