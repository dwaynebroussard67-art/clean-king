/**
 * neuralink.ts
 * The cockpit. Five seats: seat 0 is locked to local LLM, seats 1-4 are
 * interchangeable. OmniBox locks on when a pilot connects and hands them
 * their capability handles. The flight recorder watches from that point.
 *
 * Seat layout:
 *   0 — LOCAL (Ollama or any local inference endpoint). Type-locked.
 *   1 — interchangeable
 *   2 — interchangeable
 *   3 — interchangeable
 *   4 — interchangeable
 */

import { EventEmitter } from 'events'

// ── Types ──────────────────────────────────────────────────────────────────

export type PilotType = 'local' | 'claude' | 'gemini' | 'gpt' | 'grok' |
  'mistral' | 'deepseek' | 'perplexity' | 'custom'

export type SeatIndex = 0 | 1 | 2 | 3 | 4

export type SeatStatus = 'empty' | 'boarding' | 'seated' | 'flying' | 'ejected'

export interface PilotDescriptor {
  /** Unique ID for this pilot instance (per-connection, not per-type) */
  pilotId: string
  type: PilotType
  /** Human label — "Qwen 2.5 local", "Claude Sonnet 4.6", etc */
  label: string
  /** For local: base URL of the inference server. For hosted: API key handle (not the key itself) */
  endpoint?: string
  /** Which conversation roles this pilot can play */
  capabilities?: string[]
}

export interface Seat {
  index: SeatIndex
  /** Seat 0 only accepts local pilots */
  typelock: PilotType | null
  status: SeatStatus
  pilot: PilotDescriptor | null
  /** ISO timestamp of last state change */
  lastChanged: string
  /** Running count of missions this seat has flown */
  missionCount: number
}

export interface CockpitState {
  seats: Record<SeatIndex, Seat>
  /** Active conversation shape */
  shape: ConversationShape
  /** Mission currently loaded, null if idle */
  activeMissionId: string | null
}

export type ConversationShape =
  | 'communal'      // all seated pilots on the same prompt
  | 'adversarial'   // seats split into two sides, argue
  | 'relay'         // pilots answer in sequence, each sees prior
  | 'interview'     // one pilot asks, the rest answer
  | 'sidebar'       // two pilots talk, rest observe
  | 'free'          // no enforced shape, caller decides routing

export interface ShapeConfig {
  shape: ConversationShape
  /** For adversarial: which seat indices are on which side */
  sides?: { a: SeatIndex[]; b: SeatIndex[] }
  /** For interview: which seat is the interviewer */
  interviewer?: SeatIndex
  /** For relay: order of seats */
  relayOrder?: SeatIndex[]
  /** For sidebar: which two seats */
  sidebarPair?: [SeatIndex, SeatIndex]
}

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Deep copy a seat including its pilot descriptor. Callers get a snapshot,
 * not a live handle into cockpit state.
 */
function cloneSeat(seat: Seat): Seat {
  return {
    ...seat,
    pilot: seat.pilot
      ? {
          ...seat.pilot,
          ...(seat.pilot.capabilities
            ? { capabilities: [...seat.pilot.capabilities] }
            : {}),
        }
      : null,
  }
}

// ── Neuralink ──────────────────────────────────────────────────────────────

export class Neuralink extends EventEmitter {
  private seats: Map<SeatIndex, Seat>
  private shapeConfig: ShapeConfig
  private activeMissionId: string | null = null

  constructor() {
    super()
    this.seats = new Map()
    this.shapeConfig = { shape: 'communal' }

    // Initialise all five seats
    const ALL_SEATS: SeatIndex[] = [0, 1, 2, 3, 4]
    for (const index of ALL_SEATS) {
      this.seats.set(index, {
        index,
        typelock: index === 0 ? 'local' : null,
        status: 'empty',
        pilot: null,
        lastChanged: new Date().toISOString(),
        missionCount: 0,
      })
    }
  }

  // ── Boarding ─────────────────────────────────────────────────────────────

  /**
   * Board a pilot into a specific seat.
   * Seat 0 rejects non-local pilots.
   * A seat already occupied must be ejected before re-boarding.
   */
  board(seatIndex: SeatIndex, pilot: PilotDescriptor): Seat {
    const seat = this._seat(seatIndex)

    if (seat.status === 'seated' || seat.status === 'flying') {
      throw new Error(
        `SEAT_OCCUPIED: seat ${seatIndex} already has ${seat.pilot?.label}. Eject first.`
      )
    }

    if (seat.typelock && pilot.type !== seat.typelock) {
      throw new Error(
        `SEAT_TYPELOCK: seat ${seatIndex} is locked to "${seat.typelock}" pilots only. ` +
        `Got "${pilot.type}".`
      )
    }

    // P8: if a mission is already in the air, a boarding pilot joins it
    // flying — not seated. Otherwise missionEnded() never transitions it
    // and its missionCount is never incremented.
    const midMission = this.activeMissionId !== null

    const updated: Seat = {
      ...seat,
      status: midMission ? 'flying' : 'seated',
      pilot,
      lastChanged: new Date().toISOString(),
    }
    this.seats.set(seatIndex, updated)
    this.emit('pilot:boarded', { seatIndex, pilot, midMission })
    if (midMission) {
      // The flight recorder needs to know this pilot missed the start.
      this.emit('pilot:late-boarded', {
        seatIndex,
        pilot,
        missionId: this.activeMissionId,
      })
    }
    return updated
  }

  /**
   * Find the first available interchangeable seat (1-4) and board the pilot there.
   * Returns the seat index assigned.
   */
  boardAny(pilot: PilotDescriptor): { seatIndex: SeatIndex; seat: Seat } {
    if (pilot.type === 'local') {
      // Local pilots go to seat 0 — and seat 0 is the ONLY seat they can
      // take. P10: report that plainly instead of the generic occupancy error.
      const seat0 = this._seat(0)
      if (seat0.status === 'seated' || seat0.status === 'flying') {
        throw new Error(
          `LOCAL_SEAT_TAKEN: seat 0 is the only seat for local pilots and ` +
          `${seat0.pilot?.label} is in it. Eject seat 0 first.`
        )
      }
      return { seatIndex: 0, seat: this.board(0, pilot) }
    }

    const interchangeable: SeatIndex[] = [1, 2, 3, 4]
    for (const idx of interchangeable) {
      const seat = this._seat(idx)
      if (seat.status === 'empty' || seat.status === 'ejected') {
        return { seatIndex: idx, seat: this.board(idx, pilot) }
      }
    }
    throw new Error('COCKPIT_FULL: all interchangeable seats (1-4) are occupied.')
  }

  /**
   * Eject a pilot from a seat. Sets status to ejected (not empty) so the
   * flight recorder knows this seat was used this session.
   */
  eject(seatIndex: SeatIndex): Seat {
    const seat = this._seat(seatIndex)
    if (seat.status === 'empty') {
      throw new Error(`SEAT_EMPTY: seat ${seatIndex} has no pilot to eject.`)
    }
    const ejected: Seat = {
      ...seat,
      status: 'ejected',
      lastChanged: new Date().toISOString(),
    }
    this.seats.set(seatIndex, ejected)
    this.emit('pilot:ejected', { seatIndex, pilot: seat.pilot })
    return ejected
  }

  /** Reset a seat to empty (after eject, between sessions). */
  clear(seatIndex: SeatIndex): void {
    const seat = this._seat(seatIndex)
    this.seats.set(seatIndex, {
      ...seat,
      status: 'empty',
      pilot: null,
      lastChanged: new Date().toISOString(),
    })
  }

  // ── Mission wiring ────────────────────────────────────────────────────────

  /** Called by the harness runtime when a mission starts flying. */
  missionStarted(missionId: string): void {
    this.activeMissionId = missionId
    for (const [idx, seat] of this.seats) {
      if (seat.status === 'seated') {
        this.seats.set(idx, {
          ...seat,
          status: 'flying',
          lastChanged: new Date().toISOString(),
        })
      }
    }
    this.emit('mission:started', { missionId, seatedPilots: this.seatedPilots() })
  }

  /** Called when a mission ends (complete, failed, or cancelled). */
  missionEnded(missionId: string): void {
    this.activeMissionId = null
    for (const [idx, seat] of this.seats) {
      if (seat.status === 'flying') {
        this.seats.set(idx, {
          ...seat,
          status: 'seated',
          missionCount: seat.missionCount + 1,
          lastChanged: new Date().toISOString(),
        })
      }
    }
    this.emit('mission:ended', { missionId })
  }

  // ── Shape config ──────────────────────────────────────────────────────────

  setShape(config: ShapeConfig): void {
    this._validateShape(config)
    this.shapeConfig = config
    this.emit('shape:changed', config)
  }

  /** P7: deep copy — callers must not be able to mutate cockpit state. */
  getShape(): ShapeConfig {
    const c = this.shapeConfig
    return {
      shape: c.shape,
      ...(c.sides ? { sides: { a: [...c.sides.a], b: [...c.sides.b] } } : {}),
      ...(c.interviewer !== undefined ? { interviewer: c.interviewer } : {}),
      ...(c.relayOrder ? { relayOrder: [...c.relayOrder] } : {}),
      ...(c.sidebarPair ? { sidebarPair: [...c.sidebarPair] as [SeatIndex, SeatIndex] } : {}),
    }
  }

  /**
   * Given a prompt, return the routing plan: which seats get the prompt,
   * in what order, and what role context each seat gets.
   *
   * P9: the shape is re-validated here, not just at setShape() time. A pilot
   * ejected after the shape was set can leave a side empty or a relay broken,
   * and that must fail loudly rather than quietly routing a debate with one side.
   */
  routingPlan(prompt: string): RoutingPlan {
    const active = this.seatedPilots()
    if (active.length === 0) throw new Error('NO_PILOTS: no pilots are seated.')

    try {
      this._validateShape(this.shapeConfig)
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err)
      throw new Error(
        `SHAPE_STALE: the cockpit changed since this shape was set. ${detail}`
      )
    }

    return buildRoutingPlan(prompt, active, this.shapeConfig)
  }

  // ── Queries ───────────────────────────────────────────────────────────────

  state(): CockpitState {
    const seats = {} as Record<SeatIndex, Seat>
    for (const [idx, seat] of this.seats) seats[idx] = cloneSeat(seat)
    return {
      seats,
      shape: this.shapeConfig.shape,
      activeMissionId: this.activeMissionId,
    }
  }

  seatedPilots(): Array<{ seatIndex: SeatIndex; seat: Seat }> {
    const result: Array<{ seatIndex: SeatIndex; seat: Seat }> = []
    for (const [idx, seat] of this.seats) {
      if (seat.status === 'seated' || seat.status === 'flying') {
        result.push({ seatIndex: idx, seat: cloneSeat(seat) })
      }
    }
    return result
  }

  isEmpty(): boolean {
    return this.seatedPilots().length === 0
  }

  isFull(): boolean {
    // Full = all 5 seats occupied
    return this.seatedPilots().length === 5
  }

  getSeat(index: SeatIndex): Seat {
    return cloneSeat(this._seat(index))
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  private _seat(index: SeatIndex): Seat {
    const seat = this.seats.get(index)
    if (!seat) throw new Error(`INVALID_SEAT: ${index} is not a valid seat index (0-4).`)
    return seat
  }

  private _validateShape(config: ShapeConfig): void {
    const active = this.seatedPilots().map(s => s.seatIndex)

    if (config.shape === 'adversarial') {
      if (!config.sides) throw new Error('SHAPE_CONFIG: adversarial requires sides: {a, b}')
      const all = [...config.sides.a, ...config.sides.b]
      const invalid = all.filter(s => !active.includes(s))
      if (invalid.length) throw new Error(`SHAPE_CONFIG: seats ${invalid} are not seated.`)

      // P2: a seat on both sides would silently be assigned to side A and
      // argue against itself.
      const overlap = config.sides.a.filter(s => config.sides!.b.includes(s))
      if (overlap.length)
        throw new Error(
          `SHAPE_CONFIG: seats ${overlap} appear on both sides. A pilot cannot argue against itself.`
        )

      // A debate needs two sides with someone on each.
      if (config.sides.a.length === 0 || config.sides.b.length === 0)
        throw new Error(
          `SHAPE_CONFIG: adversarial needs a pilot on each side ` +
          `(a=${config.sides.a.length}, b=${config.sides.b.length}).`
        )
    }

    if (config.shape === 'interview') {
      if (config.interviewer === undefined)
        throw new Error('SHAPE_CONFIG: interview requires interviewer seat index')
      if (!active.includes(config.interviewer))
        throw new Error(`SHAPE_CONFIG: interviewer seat ${config.interviewer} is not seated.`)

      // P4: an interviewer with nobody to interview is not an interview.
      if (active.length < 2)
        throw new Error(
          `SHAPE_CONFIG: interview needs at least 2 seated pilots, found ${active.length}.`
        )
    }

    if (config.shape === 'relay' && config.relayOrder) {
      const invalid = config.relayOrder.filter(s => !active.includes(s))
      if (invalid.length) throw new Error(`SHAPE_CONFIG: relay seats ${invalid} are not seated.`)

      // P5: a seated pilot missing from the relay order would never receive
      // the prompt, with no signal that it was skipped.
      const omitted = active.filter(s => !config.relayOrder!.includes(s))
      if (omitted.length)
        throw new Error(
          `SHAPE_CONFIG: seated pilots at seats ${omitted} are omitted from the relay order ` +
          `and would never receive the prompt. Include them or eject them.`
        )

      const dupes = config.relayOrder.filter((s, i) => config.relayOrder!.indexOf(s) !== i)
      if (dupes.length)
        throw new Error(`SHAPE_CONFIG: seats ${dupes} appear more than once in the relay order.`)
    }

    if (config.shape === 'sidebar') {
      if (!config.sidebarPair) throw new Error('SHAPE_CONFIG: sidebar requires sidebarPair')
      const invalid = config.sidebarPair.filter(s => !active.includes(s))
      if (invalid.length) throw new Error(`SHAPE_CONFIG: sidebar seats ${invalid} are not seated.`)

      // P3: a "pair" of one seat is not a sidebar.
      if (config.sidebarPair[0] === config.sidebarPair[1])
        throw new Error(
          `SHAPE_CONFIG: sidebar pair must be two distinct seats, got [${config.sidebarPair}].`
        )
    }
  }
}

// ── Routing plan ──────────────────────────────────────────────────────────

export interface PilotRoute {
  seatIndex: SeatIndex
  pilot: PilotDescriptor
  /** What role context this pilot gets alongside the prompt */
  roleContext: string
  /** For relay/sequential shapes: wait for these seats to respond first */
  waitFor: SeatIndex[]
}

export interface RoutingPlan {
  shape: ConversationShape
  prompt: string
  routes: PilotRoute[]
}

function buildRoutingPlan(
  prompt: string,
  active: Array<{ seatIndex: SeatIndex; seat: Seat }>,
  config: ShapeConfig
): RoutingPlan {
  const routes: PilotRoute[] = []

  switch (config.shape) {
    case 'communal': {
      for (const { seatIndex, seat } of active) {
        routes.push({
          seatIndex,
          pilot: seat.pilot!,
          roleContext: 'You are one of several pilots responding to the same prompt. Respond independently.',
          waitFor: [],
        })
      }
      break
    }

    case 'adversarial': {
      const sides = config.sides!
      const debaters = [...sides.a, ...sides.b]
      for (const { seatIndex, seat } of active) {
        const onA = sides.a.includes(seatIndex)
        const onB = sides.b.includes(seatIndex)

        // P1: a seated pilot on neither side used to be dropped from the plan
        // entirely — in the cockpit, given no prompt, with nothing in the
        // flight recorder to say it was skipped. It observes and judges instead.
        if (!onA && !onB) {
          routes.push({
            seatIndex,
            pilot: seat.pilot!,
            roleContext:
              'You are not on either side. Observe the debate, then judge it: ' +
              'say which side argued better and where each one was weak.',
            waitFor: debaters,
          })
          continue
        }

        routes.push({
          seatIndex,
          pilot: seat.pilot!,
          roleContext: onA
            ? 'You are on Side A. Argue your position clearly and directly against Side B.'
            : 'You are on Side B. Argue your position clearly and directly against Side A.',
          waitFor: [],
        })
      }
      break
    }

    case 'relay': {
      const order = config.relayOrder ?? active.map(a => a.seatIndex)
      for (let i = 0; i < order.length; i++) {
        const seatIndex = order[i]
        const entry = active.find(a => a.seatIndex === seatIndex)
        if (!entry) continue
        routes.push({
          seatIndex,
          pilot: entry.seat.pilot!,
          roleContext: i === 0
            ? 'You are first in the relay. Respond to the prompt. The next pilot will build on your answer.'
            : `You are pilot ${i + 1} in the relay. Read the prior response and extend or refine it.`,
          waitFor: order.slice(0, i) as SeatIndex[],
        })
      }
      break
    }

    case 'interview': {
      const interviewer = config.interviewer!
      for (const { seatIndex, seat } of active) {
        routes.push({
          seatIndex,
          pilot: seat.pilot!,
          roleContext: seatIndex === interviewer
            ? 'You are the interviewer. Ask the other pilots a focused question based on the prompt.'
            : 'You are being interviewed. Answer the interviewer\'s question directly and honestly.',
          waitFor: seatIndex !== interviewer ? [interviewer] : [],
        })
      }
      break
    }

    case 'sidebar': {
      const pair = config.sidebarPair!
      for (const { seatIndex, seat } of active) {
        const inPair = pair.includes(seatIndex)
        routes.push({
          seatIndex,
          pilot: seat.pilot!,
          roleContext: inPair
            ? 'You are in a sidebar conversation with one other pilot. The rest are observing.'
            : 'You are observing a sidebar conversation. Do not respond unless asked.',
          waitFor: [],
        })
      }
      break
    }

    case 'free':
    default: {
      for (const { seatIndex, seat } of active) {
        routes.push({
          seatIndex,
          pilot: seat.pilot!,
          roleContext: 'Respond as instructed.',
          waitFor: [],
        })
      }
      break
    }
  }

  return { shape: config.shape, prompt, routes }
}

// ── Singleton export ──────────────────────────────────────────────────────
// Survive Next.js HMR so boarding a pilot is not wiped by a route recompile.

const globalForCockpit = globalThis as typeof globalThis & { __omniboxCockpit?: Neuralink }
export const neuralink = globalForCockpit.__omniboxCockpit ?? new Neuralink()
if (!globalForCockpit.__omniboxCockpit) globalForCockpit.__omniboxCockpit = neuralink
