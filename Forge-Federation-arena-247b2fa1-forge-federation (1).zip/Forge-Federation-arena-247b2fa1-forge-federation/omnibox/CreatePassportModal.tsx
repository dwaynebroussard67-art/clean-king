"use client";

import { useState } from "react";
import type { Passport } from "@/lib/types";
import { X, Shield } from "lucide-react";

interface Props {
  onClose: () => void;
  onCreated: (p: Passport) => void;
}

const TIMEZONES = [
  "UTC",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Tokyo",
  "Asia/Shanghai",
  "Australia/Sydney",
];

const STYLES = ["balanced", "technical", "conversational", "concise", "detailed"];
const VERBOSITY = ["low", "medium", "high"];

export function CreatePassportModal({ onClose, onCreated }: Props) {
  const [name, setName] = useState("");
  const [preferredName, setPreferredName] = useState("");
  const [timezone, setTimezone] = useState("UTC");
  const [language, setLanguage] = useState("English");
  const [responseStyle, setResponseStyle] = useState("balanced");
  const [verbosity, setVerbosity] = useState("medium");
  const [codingLangs, setCodingLangs] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);

    const res = await fetch("/api/passports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: name.trim(),
        preferredName: preferredName.trim() || null,
        timezone,
        language: language.trim() || "English",
        responseStyle,
        verbosity,
        codingLanguages: codingLangs
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
      }),
    });
    const data = await res.json();
    onCreated(data);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="relative w-full max-w-lg rounded-2xl bg-[#1a1f3a] border border-white/10 shadow-2xl animate-fade-in overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-passport-500 to-passport-700 flex items-center justify-center">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <h2 className="text-lg font-bold text-white">
              Create Memory Passport
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* Identity */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase tracking-wider text-passport-400 font-semibold flex items-center gap-2">
              👤 Identity Layer
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 sm:col-span-1">
                <label className="block text-xs text-slate-400 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Dwayne"
                  required
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <label className="block text-xs text-slate-400 mb-1">
                  Preferred Name
                </label>
                <input
                  type="text"
                  value={preferredName}
                  onChange={(e) => setPreferredName(e.target.value)}
                  placeholder="Big Daddy"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Timezone
                </label>
                <select
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                >
                  {TIMEZONES.map((tz) => (
                    <option key={tz} value={tz} className="bg-[#1a1f3a]">
                      {tz}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Language
                </label>
                <input
                  type="text"
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  placeholder="English"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                />
              </div>
            </div>
          </div>

          {/* Preferences */}
          <div className="space-y-3">
            <h3 className="text-xs uppercase tracking-wider text-purple-400 font-semibold flex items-center gap-2">
              ⚙️ Preference Layer
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Response Style
                </label>
                <select
                  value={responseStyle}
                  onChange={(e) => setResponseStyle(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                >
                  {STYLES.map((s) => (
                    <option key={s} value={s} className="bg-[#1a1f3a]">
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Verbosity
                </label>
                <select
                  value={verbosity}
                  onChange={(e) => setVerbosity(e.target.value)}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                >
                  {VERBOSITY.map((v) => (
                    <option key={v} value={v} className="bg-[#1a1f3a]">
                      {v}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs text-slate-400 mb-1">
                  Coding Languages (comma-separated)
                </label>
                <input
                  type="text"
                  value={codingLangs}
                  onChange={(e) => setCodingLangs(e.target.value)}
                  placeholder="typescript, python, rust"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm placeholder:text-slate-500 focus:border-passport-500 focus:outline-none focus:ring-1 focus:ring-passport-500/50 transition"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving || !name.trim()}
            className="w-full py-3 bg-gradient-to-r from-passport-600 to-passport-500 hover:from-passport-500 hover:to-passport-400 text-white font-semibold rounded-xl transition-all shadow-lg shadow-passport-600/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? "Creating…" : "Create Passport"}
          </button>
        </form>
      </div>
    </div>
  );
}
