/**
 * collective-admission.ts — derive witnessed facts from tool outputs that carry content hashes.
 *
 * This is the bridge that makes "the collective is the oracle" true:
 * a harness that fetches a URL or snapshots a DOM produces a structural witness
 * (sha256 of raw bytes). That witness can be used to admit a fact into the
 * collective that is re-derivable by anyone holding the same bytes.
 *
 * Pilot never calls this. Harness plumbing does, after executeAuthorized mints
 * the structural witness from bodyHash / snapshotHash / contentHash / pngHash.
 *
 * Mapping is intentionally conservative:
 *  - http.fetch -> endpoint:<origin><pathname> returns_status <status> with structural witness
 *  - browser.read_page / snapshot / screenshot / navigate -> page:<url> exists true
 *  - browser.snapshot additionally attempts to extract stable ids (data-testid / id)
 *    from its snapshot text? For now, not — because snapshot text format is
 *    "[ref] role name" without stable id in text. Future work: extract from
 *    anchor-bridge resolved snapshots which DO have snapshot.testId.
 *
 * Facts are contingent (mutable) — the web changes.
 */

import type { FactRecord, Witness, Predicate, FactValue } from './types.ts'

function safeOrigin(urlStr: string): string {
  try {
    const u = new URL(urlStr)
    return `${u.origin}${u.pathname}`.slice(0, 300)
  } catch {
    return urlStr.slice(0, 300)
  }
}

function subjectForEndpoint(url?: string): string {
  if (!url) return 'endpoint:unknown'
  return `endpoint:${safeOrigin(url)}`
}

function subjectForPage(url?: string): string {
  if (!url) return 'page:unknown'
  try {
    const u = new URL(url)
    // Page subject is origin + pathname, query stripped because query is not identity
    return `page:${u.origin}${u.pathname}`.slice(0, 300)
  } catch {
    return `page:${url.slice(0, 250)}`
  }
}

export type DerivedFact = FactRecord

/**
 * Derive facts from a tool's output that already has a structural witness.
 * Returns [] if nothing derivable — not an error, just unknown.
 */
export function deriveFacts(input: {
  capabilityId: string
  output: any
  witness: Witness // structural witness preferred, fallback to outcome
}): DerivedFact[] {
  const { capabilityId, output, witness } = input
  if (!output || typeof output !== 'object') return []
  if (!witness) return []

  const url: string | undefined = typeof output.url === 'string' ? output.url : undefined

  switch (capabilityId) {
    case 'http.fetch': {
      const status = typeof output.status === 'number' ? output.status : undefined
      if (status === undefined || status < 100 || status > 599) return []
      // One fact: this endpoint returns this status (contingent)
      return [
        {
          subject: subjectForEndpoint(url),
          predicate: 'returns_status' as Predicate,
          value: status as FactValue,
          witness,
          stability: 'contingent',
        },
      ]
    }

    case 'browser.navigate': {
      if (!url) return []
      return [
        {
          subject: subjectForPage(url),
          predicate: 'exists' as Predicate,
          value: true as FactValue,
          witness,
          stability: 'contingent',
        },
      ]
    }

    case 'browser.read_page':
    case 'browser.snapshot':
    case 'browser.screenshot':
    case 'browser.back': {
      // Generic existence — we saw the page, it exists, with this snapshot hash as receipt
      const pageUrl = url ?? (typeof output.snapshot === 'string' ? undefined : undefined)
      // For snapshot, url is inside snapshot header "URL: ..." — try parse
      let extractedUrl: string | undefined = url
      if (!extractedUrl && typeof output.snapshot === 'string') {
        const m = output.snapshot.match(/^URL:\s*(\S+)/m)
        if (m) extractedUrl = m[1]
      }
      return [
        {
          subject: subjectForPage(extractedUrl ?? pageUrl),
          predicate: 'exists' as Predicate,
          value: true as FactValue,
          witness,
          stability: 'contingent',
        },
      ]
    }

    default:
      return []
  }
}
