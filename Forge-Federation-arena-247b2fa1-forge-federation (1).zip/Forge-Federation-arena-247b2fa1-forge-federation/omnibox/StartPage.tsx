"use client";

import { useRef } from "react";
import {
  ArrowRight,
  Shield,
  FlaskConical,
  Plane,
  Search,
  FileText,
  Layers,
} from "lucide-react";

type Props = {
  onSearch: (query: string) => void;
  onOpen: (url: string) => void;
};

const QUICK_LINKS = [
  { label: "Passport", href: "/passport", icon: Shield, tint: "text-indigo-300" },
  { label: "Cockpit", href: "/cockpit", icon: Plane, tint: "text-amber-300" },
  { label: "Lab", href: "/lab", icon: FlaskConical, tint: "text-emerald-300" },
  { label: "Docs", href: "/docs", icon: FileText, tint: "text-sky-300" },
];

const DEMO_SITES = [
  { label: "Demo page", url: "omnibox://demo", desc: "Lives inside the plane" },
  { label: "New tab", url: "omnibox://newtab", desc: "Start again" },
];

export function StartPage({ onSearch, onOpen }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="h-full w-full overflow-y-auto bg-gradient-to-br from-[#0d1326] via-[#141b36] to-[#0b1020] text-slate-100">
      <div className="min-h-full flex flex-col items-center px-6 pt-[12vh] pb-16">
        <div className="flex items-center gap-3 mb-2">
          <span className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-400 via-violet-500 to-fuchsia-600 grid place-items-center shadow-2xl shadow-violet-600/30">
            <Layers className="h-6 w-6 text-white" />
          </span>
          <div>
            <div className="text-3xl font-bold tracking-tight">Vector</div>
            <div className="text-[11px] uppercase tracking-[0.28em] text-slate-400">
              the browser for your models
            </div>
          </div>
        </div>

        {/* Search field */}
        <form
          className="mt-10 w-full max-w-2xl"
          onSubmit={(e) => {
            e.preventDefault();
            const v = inputRef.current?.value.trim();
            if (v) onSearch(v);
          }}
        >
          <div className="flex items-center gap-3 h-14 px-5 rounded-full bg-[#0a1124]/80 border border-white/10 focus-within:border-indigo-400/60 focus-within:ring-4 focus-within:ring-indigo-500/10 transition shadow-xl">
            <Search className="h-5 w-5 text-slate-400" />
            <input
              ref={inputRef}
              name="q"
              autoFocus
              placeholder="Search the web, or type an address"
              className="flex-1 bg-transparent text-base text-white placeholder:text-slate-500 outline-none"
            />
            <button
              type="submit"
              aria-label="Search"
              className="h-9 px-4 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 text-white text-sm font-medium hover:from-indigo-400 hover:to-violet-400 transition flex items-center gap-1.5"
            >
              Go <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </form>

        {/* Quick links */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-2xl">
          {QUICK_LINKS.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                onOpen(link.href);
              }}
              className="group flex flex-col items-center gap-2 rounded-2xl bg-white/[0.03] border border-white/[0.06] px-4 py-5 hover:bg-white/[0.07] hover:border-white/10 transition"
            >
              <link.icon className={`h-6 w-6 ${link.tint}`} />
              <span className="text-sm font-medium text-slate-200">{link.label}</span>
            </a>
          ))}
        </div>

        {/* In-plane demo */}
        <div className="mt-10 w-full max-w-2xl">
          <div className="text-[11px] uppercase tracking-widest text-slate-500 mb-3">In-plane</div>
          <div className="grid sm:grid-cols-2 gap-3">
            {DEMO_SITES.map((site) => (
              <button
                key={site.url}
                onClick={() => onOpen(site.url)}
                className="text-left rounded-2xl bg-white/[0.03] border border-white/[0.06] px-4 py-4 hover:bg-white/[0.07] hover:border-white/10 transition"
              >
                <div className="text-sm font-medium text-slate-100">{site.label}</div>
                <div className="text-xs text-slate-500 mt-0.5">{site.desc}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
