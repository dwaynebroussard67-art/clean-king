/**
 * probe.mjs — "would Forge Flight seat this page, and why?"
 *
 * Point it at any page and it runs the real seat detector against real layout
 * and prints the verdict with every signal named. Works on a live URL, a
 * saved .html, or a saved .mhtml (Ctrl+S "Webpage, single file" from Chrome —
 * which is the useful one, because it captures a logged-in chat as it
 * actually renders).
 *
 *   node tools/probe.mjs https://example.com/chat
 *   node tools/probe.mjs ~/Downloads/some-ai-chat.mhtml
 *
 * BATCH MODE — a directory instead of a file:
 *
 *   node tools/probe.mjs ~/captures/                 # every capture, one table
 *   node tools/probe.mjs ~/captures/ --json=out.json # machine-readable
 *   node tools/probe.mjs ~/captures/ --baseline=b.json --fail-on-regression
 *
 * That last form is the point of this change. A one-off diagnostic tells you
 * about one page on one day. What actually breaks a seat is a provider
 * redesign, and the question you need answered then is not "does this page
 * seat" but "which of the twenty chats I have captured stopped seating, and
 * which signal moved". So a run over a directory records a verdict per file,
 * a baseline can be written from a known-good run, and a later run diffs
 * against it and exits non-zero when a page that used to seat no longer does
 * — a regression sentinel you can put in front of trusting a seat again.
 *
 * A refusal is NOT a regression. Ambiguous, below-floor and cross-origin-frame
 * are the product working; the sentinel only complains when a verdict
 * CHANGES, and it says which signals moved and by how much. It will not push
 * anyone toward making the detector guess.
 *
 * Needs playwright-core and a Chromium. It is a diagnostic tool, not part of
 * the app — the browser itself has no dependency on it.
 */

import { readFileSync, writeFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve, join, isAbsolute, basename, extname } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');

let chromium;
try {
  ({ chromium } = await import('playwright-core'));
} catch {
  console.error('probe needs playwright-core:  npm i -D playwright-core');
  process.exit(2);
}

function findChromium() {
  // D26: the new name wins, the OmniBox-era one is still honoured so an
  // existing shell profile keeps working.
  if (process.env.FORGEFLIGHT_CHROMIUM) return process.env.FORGEFLIGHT_CHROMIUM;
  if (process.env.OMNIBOX_CHROMIUM) return process.env.OMNIBOX_CHROMIUM;
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH || '/opt/pw-browsers';
  if (!existsSync(base)) return undefined;
  const dir = readdirSync(base).find((d) => /^chromium-\d+$/.test(d));
  if (!dir) return undefined;
  for (const p of [join(base, dir, 'chrome-linux', 'chrome'), join(base, dir, 'chrome-linux', 'headless_shell')]) {
    if (existsSync(p)) return p;
  }
  return undefined;
}

const SIGNALS = readFileSync(resolve(root, 'src/detector/signals.js'), 'utf8');
const STAMP = readFileSync(resolve(root, 'src/detector/stamp.js'), 'utf8');
const DETECT = readFileSync(resolve(root, 'src/detector/detect.js'), 'utf8');
const shim = (src, name) =>
  `(()=>{const module={exports:{}};const exports=module.exports;` +
  `const require=(id)=>id.includes('signals')?globalThis.__FORGEFLIGHT_SIGNALS__:id.includes('stamp')?globalThis.__FORGEFLIGHT_STAMP__:globalThis.__FORGEFLIGHT_DETECT__;` +
  `${src};globalThis[${JSON.stringify(name)}]=module.exports;})();`;

// --------------------------------------------------------------------------
// Arguments
// --------------------------------------------------------------------------

const argv = process.argv.slice(2);
const flags = {};
const targets = [];
for (const a of argv) {
  const m = /^--([\w-]+)(?:=(.*))?$/.exec(a);
  if (m) flags[m[1]] = m[2] === undefined ? true : m[2];
  else targets.push(a);
}

if (targets.length === 0 || flags.help) {
  console.error(`usage: node tools/probe.mjs <url | file | directory> [more…] [flags]

  --json=<path>            write the full result set as JSON
  --baseline=<path>        compare this run against a previous --json
  --write-baseline=<path>  record this run as the known-good baseline
  --fail-on-regression     exit 1 if any page's verdict got worse
  --wait=<ms>              hydration wait per page (default 2500)
  --quiet                  summary table only, no per-signal detail`);
  process.exit(2);
}

const WAIT = Number(flags.wait ?? 2500);
const CAPTURE_EXT = new Set(['.mhtml', '.mht', '.html', '.htm']);

/** A directory target expands to every capture inside it, sorted, so two
 *  runs over the same directory are comparable line for line. */
function expand(t) {
  if (/^https?:\/\//i.test(t)) return [t];
  const p = isAbsolute(t) ? t : resolve(process.cwd(), t);
  let st;
  try {
    st = statSync(p);
  } catch {
    return [t]; // let the load step report it, with its own message
  }
  if (!st.isDirectory()) return [p];
  return readdirSync(p)
    .filter((n) => CAPTURE_EXT.has(extname(n).toLowerCase()))
    .sort()
    .map((n) => join(p, n));
}

const files = targets.flatMap(expand);
if (files.length === 0) {
  console.error('nothing to probe: the directory holds no .mhtml, .mht, .html or .htm captures');
  process.exit(2);
}

const batch = files.length > 1;
const bar = (v) => '█'.repeat(Math.round(v * 12)).padEnd(12, '·');
const label = (t) => (/^https?:\/\//i.test(t) ? t : basename(t));

// --------------------------------------------------------------------------
// The run
// --------------------------------------------------------------------------

const browser = await chromium.launch({ executablePath: findChromium(), args: ['--no-sandbox'] });
const results = [];

for (const t of files) {
  const url = /^https?:\/\//i.test(t) ? t : pathToFileURL(isAbsolute(t) ? t : resolve(process.cwd(), t)).href;
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  await page.addInitScript({ content: shim(SIGNALS, '__FORGEFLIGHT_SIGNALS__') });
  await page.addInitScript({ content: shim(STAMP, '__FORGEFLIGHT_STAMP__') });
  await page.addInitScript({ content: shim(DETECT, '__FORGEFLIGHT_DETECT__') });

  if (!batch) console.log(`\n\x1b[1m${t}\x1b[0m`);

  const started = Date.now();
  try {
    await page.goto(url, { waitUntil: 'load', timeout: 45000 });
  } catch (e) {
    const detail = e.message.split('\n')[0];
    if (!batch) console.log(`  could not load: ${detail}`);
    results.push({ target: label(t), path: t, ok: false, reason: 'load-failed', detail, signals: null });
    await page.close();
    continue;
  }
  await page.waitForTimeout(WAIT); // let a chat app hydrate

  const v = await page.evaluate(() => {
    const V = globalThis.__FORGEFLIGHT_DETECT__.detectComposer(document);
    const d = (el) =>
      el
        ? {
            tag: el.tagName.toLowerCase(),
            label: el.getAttribute('aria-label') || el.getAttribute('placeholder') || '',
            cls: String(el.className || '').slice(0, 70),
          }
        : null;
    return { ...V, composer: d(V.composer), send: d(V.send) };
  });

  results.push({
    target: label(t),
    path: t,
    ok: !!v.ok,
    reason: v.ok ? 'seated' : v.reason,
    detail: v.detail || '',
    confidence: v.confidence ?? null,
    margin: v.margin ?? null,
    tiedOn: v.tiedOn || [],
    composer: v.composer || null,
    send: v.send || null,
    candidates: (v.candidates || []).slice(0, 4).map((c) => ({ tag: c.tag, label: c.label, score: c.score })),
    signals: v.signals || null,
    elapsedMs: Date.now() - started,
  });

  if (!batch) {
    if (v.ok) {
      console.log(`  \x1b[38;5;208mSEATED\x1b[0m  confidence ${v.confidence}  margin ${v.margin}`);
      console.log(`  composer  <${v.composer.tag}> ${v.composer.label || `class="${v.composer.cls}"`}`);
      console.log(`  send      ${v.send ? `<${v.send.tag}> ${v.send.label || v.send.cls}` : '(none — will submit with Enter)'}`);
    } else {
      console.log(`  \x1b[33mNOT SEATED\x1b[0m  (${v.reason})`);
      console.log(`  ${v.detail}`);
      if (v.tiedOn && v.tiedOn.length) console.log(`  tied on: ${v.tiedOn.join(', ')}`);
      for (const c of (v.candidates || []).slice(0, 4)) {
        console.log(`    · <${c.tag}> ${c.label || '(no label)'}  score ${c.score}`);
      }
    }
    if (v.signals) {
      console.log('  signals');
      for (const [k, s] of Object.entries(v.signals)) {
        console.log(`    ${k.padEnd(15)} ${bar(s)} ${Number(s).toFixed(2)}`);
      }
    }
  } else {
    const mark = v.ok ? '\x1b[38;5;208mSEATED    \x1b[0m' : `\x1b[33m${String(v.reason).padEnd(10)}\x1b[0m`;
    const num = v.ok ? `conf ${Number(v.confidence).toFixed(3)}  margin ${Number(v.margin).toFixed(3)}` : '';
    console.log(`  ${mark} ${label(t).padEnd(38).slice(0, 38)} ${num}`);
    if (!flags.quiet && !v.ok && v.tiedOn && v.tiedOn.length) {
      console.log(`             ${' '.repeat(38)} tied on ${v.tiedOn.join(', ')}`);
    }
  }

  await page.close();
}

await browser.close();

// --------------------------------------------------------------------------
// The sentinel
// --------------------------------------------------------------------------

const seated = results.filter((r) => r.ok).length;
if (batch) {
  console.log(`\n  ${seated}/${results.length} seated, ${results.length - seated} refused`);
  const byReason = {};
  for (const r of results) if (!r.ok) byReason[r.reason] = (byReason[r.reason] || 0) + 1;
  for (const [k, n] of Object.entries(byReason)) console.log(`    ${String(n).padStart(3)}  ${k}`);
}

const payload = { at: new Date().toISOString(), count: results.length, seated, results };

if (flags.json) {
  writeFileSync(String(flags.json), JSON.stringify(payload, null, 2), 'utf8');
  console.log(`\n  wrote ${flags.json}`);
}
if (flags['write-baseline']) {
  writeFileSync(String(flags['write-baseline']), JSON.stringify(payload, null, 2), 'utf8');
  console.log(`  baseline recorded at ${flags['write-baseline']} — ${seated}/${results.length} seated`);
}

let regressions = 0;
if (flags.baseline) {
  let base;
  try {
    base = JSON.parse(readFileSync(String(flags.baseline), 'utf8'));
  } catch (e) {
    console.error(`  could not read baseline: ${e.message}`);
    process.exit(2);
  }
  const prev = new Map((base.results || []).map((r) => [r.target, r]));
  const changes = [];
  const gone = [];

  for (const r of results) {
    const b = prev.get(r.target);
    if (!b) {
      changes.push({ kind: 'new', r });
      continue;
    }
    if (b.reason === r.reason) continue;
    // A page that used to seat and no longer does is the thing worth
    // failing a build over. Every other change is reported, not enforced —
    // a page that started seating, or moved from one honest refusal to
    // another, is information, not an alarm.
    const worse = b.ok && !r.ok;
    if (worse) regressions++;
    changes.push({ kind: worse ? 'regression' : 'change', r, from: b.reason, to: r.reason, before: b });
  }
  for (const [target, b] of prev) if (!results.some((r) => r.target === target)) gone.push({ target, b });

  console.log(`\n  against baseline ${flags.baseline} (${base.at || 'unknown date'})`);
  if (changes.length === 0 && gone.length === 0) {
    console.log('    no change — every capture reached the same verdict as the baseline');
  }
  for (const c of changes) {
    if (c.kind === 'new') {
      console.log(`    \x1b[36mNEW\x1b[0m         ${c.r.target}  ${c.r.reason}`);
      continue;
    }
    const tag = c.kind === 'regression' ? '\x1b[31mREGRESSION\x1b[0m' : '\x1b[36mchanged\x1b[0m   ';
    console.log(`    ${tag}  ${c.r.target}  ${c.from} → ${c.to}`);
    // Which signal moved: the actionable half. A redesign that moved the
    // composer out of the anchored region says `anchored 1.00 → 0.00`, and
    // that is a fact about the page, not an invitation to lower the floor.
    if (c.before.signals && c.r.signals) {
      const moved = Object.keys(c.r.signals)
        .filter((k) => Math.abs((c.r.signals[k] ?? 0) - (c.before.signals[k] ?? 0)) >= 0.05)
        .map((k) => `${k} ${Number(c.before.signals[k] ?? 0).toFixed(2)}→${Number(c.r.signals[k] ?? 0).toFixed(2)}`);
      if (moved.length) console.log(`                 signals: ${moved.join(', ')}`);
    }
    if (c.r.tiedOn && c.r.tiedOn.length) console.log(`                 tied on: ${c.r.tiedOn.join(', ')}`);
  }
  for (const g of gone) console.log(`    \x1b[90mmissing\x1b[0m     ${g.target} (was ${g.b.reason})`);

  console.log(`\n  ${regressions} regression${regressions === 1 ? '' : 's'}`);
}

if (flags['fail-on-regression'] && regressions > 0) process.exit(1);
if (results.every((r) => r.reason === 'load-failed')) process.exit(2);
process.exit(0);
