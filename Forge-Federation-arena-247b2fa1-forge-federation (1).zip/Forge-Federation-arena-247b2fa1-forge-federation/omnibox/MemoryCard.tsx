"use client";

import type { Memory } from "@/lib/types";
import { MEMORY_TYPES } from "@/lib/types";
import { Pin, Trash2, Edit3, Clock } from "lucide-react";
import { EpistemicBadge } from "@/components/EpistemicBadge";

interface Props {
  memory: Memory;
  onEdit: (m: Memory) => void;
  onDelete: (id: string) => void;
  onTogglePin: (m: Memory) => void;
}

export function MemoryCard({ memory, onEdit, onDelete, onTogglePin }: Props) {
  const typeInfo = MEMORY_TYPES.find((t) => t.value === memory.type) ||
    MEMORY_TYPES[1];

  return (
    <div className="group rounded-xl bg-white/[0.03] border border-white/[0.06] hover:border-white/[0.12] transition animate-fade-in overflow-hidden">
      <div className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-2">
            <span
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium"
              style={{
                backgroundColor: `${typeInfo.color}15`,
                color: typeInfo.color,
              }}
            >
              <span>{typeInfo.icon}</span>
              {typeInfo.label}
            </span>
            {memory.pinned && (
              <Pin className="h-3 w-3 text-yellow-400 fill-yellow-400" />
            )}
            <EpistemicBadge memory={memory} />
          </div>
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
            <button
              onClick={() => onTogglePin(memory)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-yellow-400 transition"
              title={memory.pinned ? "Unpin" : "Pin"}
            >
              <Pin className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => onEdit(memory)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-passport-400 transition"
              title="Edit"
            >
              <Edit3 className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => onDelete(memory.id)}
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-400 hover:text-red-400 transition"
              title="Delete"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Title */}
        <h4 className="font-semibold text-white text-sm mb-1.5">
          {memory.title}
        </h4>

        {/* Content preview */}
        <p className="text-sm text-slate-400 leading-relaxed line-clamp-3">
          {memory.content}
        </p>

        {/* Tags */}
        {memory.tags && memory.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {memory.tags.map((tag) => (
              <span
                key={tag}
                className="px-2 py-0.5 rounded-md bg-white/5 text-xs text-slate-400 border border-white/5"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/[0.04]">
          <div className="flex items-center gap-1 text-xs text-slate-500">
            <Clock className="h-3 w-3" />
            {new Date(memory.updatedAt).toLocaleDateString()}
          </div>
          {memory.confidence !== null && (
            <div className="flex items-center gap-1.5">
              <div className="h-1 w-12 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full rounded-full bg-passport-500"
                  style={{ width: `${(memory.confidence ?? 1) * 100}%` }}
                />
              </div>
              <span className="text-xs text-slate-500">
                {Math.round((memory.confidence ?? 1) * 100)}%
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
