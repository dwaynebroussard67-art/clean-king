/**
 * hashing.test.mjs — fetch body bytes and DOM snapshot hashes, not JSON.stringify(output)
 *
 * The defect this guards: wiring that does `JSON.stringify(output)` to get a hash
 *  - is unstable (key order, undefined, base64)
 *  - hashes the envelope, not the content
 *  - makes two identical bodies produce different hashes if wrapper differs
 *
 * Correct wiring:
 *  - fetch: sha256(raw body bytes)
 *  - DOM snapshot: sha256(canonical snapshot text)
 *  - page text: sha256(normalized text)
 *  - screenshot: sha256(raw PNG bytes from base64)
 */

import assert from 'node:assert/strict'
import {
  sha256Hex,
  sha256Ref,
  hashFetchBody,
  hashDomSnapshot,
  hashPageText,
  hashPngBase64,
  canonicalizeSnapshot,
} from './hashing.ts'

let passed = 0, failed = 0
const failures = []
function test(name, fn) {
  try { fn(); passed++ } catch (e) { failed++; failures.push({ name, message: e.stack ?? String(e) }) }
}

// ── Baseline: sha256 is deterministic ──
test('sha256Ref is deterministic for same bytes', () => {
  const a = sha256Ref('hello world')
  const b = sha256Ref('hello world')
  assert.equal(a, b)
  assert.match(a, /^sha256:[a-f0-9]{64}$/)
})

test('different bytes produce different hash', () => {
  const a = sha256Ref('hello world')
  const b = sha256Ref('hello world!')
  assert.notEqual(a, b)
})

test('fetch body bytes hash over raw bytes, not JSON wrapper', () => {
  const body = new TextEncoder().encode('{"key":"value"}')
  const rawHash = hashFetchBody(body)
  const wrapperJson = JSON.stringify({ body: '{"key":"value"}', status: 200, headers: {} })
  const wrapperHash = sha256Ref(wrapperJson)
  // must differ because wrapper includes status/headers envelope
  assert.notEqual(rawHash, wrapperHash)
  // same body bytes different wrapper still same hash
  const wrapper2 = JSON.stringify({ body: '{"key":"value"}', status: 404, headers: { 'content-type': 'text/plain' } })
  const wrapper2Hash = sha256Ref(wrapper2)
  assert.notEqual(wrapperHash, wrapper2Hash) // wrapper hashes differ by status
  // raw stays same
  assert.equal(rawHash, hashFetchBody(body))
})

test('canonicalizeSnapshot normalizes CRLF and trims trailing whitespace', () => {
  const a = 'URL: https://example.com\nTITLE: Test\n\n## heading\n[1] button "Submit"  \n'
  const b = 'URL: https://example.com\r\nTITLE: Test\r\n\r\n## heading\r\n[1] button "Submit"\r\n'
  assert.equal(canonicalizeSnapshot(a), canonicalizeSnapshot(b))
  assert.equal(hashDomSnapshot(a), hashDomSnapshot(b))
})

test('DOM snapshot hash changes when content changes, not when scroll number same content', () => {
  const snap1 = 'URL: https://example.com\nTITLE: A\nSCROLL: 0px\nELEMENTS: 1\n[1] button "Go"'
  const snap2 = 'URL: https://example.com\nTITLE: A\nSCROLL: 0px\nELEMENTS: 1\n[1] button "Go differently"'
  assert.notEqual(hashDomSnapshot(snap1), hashDomSnapshot(snap2))
})

test('page text hash is normalized — CRLF/LF same hash', () => {
  assert.equal(hashPageText('hello\r\nworld'), hashPageText('hello\nworld'))
})

test('screenshot hash is over raw PNG bytes, not JSON.stringify({png})', () => {
  // 1x1 transparent PNG base64 (minimal)
  const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII='
  const rawHash = hashPngBase64(pngBase64)
  const wrapper = JSON.stringify({ png: pngBase64, width: 1, height: 1 })
  const wrapperHash = sha256Ref(wrapper)
  assert.notEqual(rawHash, wrapperHash, 'screenshot hash must be over raw PNG bytes, not wrapper JSON')
})

test('hash is stable even when output shape reordered', () => {
  const body = new TextEncoder().encode('identical body')
  const out1 = { url: 'https://example.com', status: 200, bodyHash: hashFetchBody(body), bodyText: 'identical body' }
  const out2 = { bodyText: 'identical body', bodyHash: hashFetchBody(body), status: 200, url: 'https://example.com' }
  // JSON.stringify would differ because key order differs — hashes of wrapper would differ
  // but bodyHash field must be identical because it is hash of body bytes only
  assert.equal(out1.bodyHash, out2.bodyHash)
  assert.equal(JSON.stringify(out1) !== JSON.stringify(out2), true, 'JSON.stringify wrapper differs by key order — proves why we must not hash wrapper')
})

console.log(`\nhashing: ${passed} passed, ${failed} failed\n`)
if (failures.length) {
  for (const f of failures) console.log(`  FAIL  ${f.name}\n        ${f.message}\n`)
  process.exit(1)
}
