# core/plugin_loader.py — Plugin discovery, loading, and lifecycle
#
# Scans plugins/ and user/plugins/ for plugin.json manifests.
# Registers hooks, voice commands, and (later) tools/web/schedule.

import json
import inspect
import logging
import os
import re
import shutil
import sqlite3
import stat
import threading
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Tuple

from core.hooks import hook_runner
from core.plugin_verify import verify_plugin
from core.fs_utils import replace_with_retry, ro_uri

logger = logging.getLogger(__name__)


# Canonical copy moved to fs_utils so pre-boot code (restore.py) can use it
# without importing the plugin loader; alias keeps every call site working.
from core.fs_utils import rmtree_robust as _rmtree_robust

# Plugin search paths (relative to project root)
from core.paths import PROJECT_ROOT, SYSTEM_PLUGINS_DIR, USER_PLUGINS_DIR, PLUGIN_STATE_DIR
# Previous versions retained by plugin updates (one generation, = Revert).
# MUST live outside user/plugins — the scanner registers any subdir with a
# plugin.json under its manifest name, so a retained copy inside the scan
# path would shadow-fight the live one. Same filesystem keeps swaps rename-fast.
PLUGIN_PREV_DIR = PROJECT_ROOT / "user" / "plugin_prev"

# Where enabled/disabled state is stored
USER_PLUGINS_JSON = PROJECT_ROOT / "user" / "webui" / "plugins.json"
# Every read-modify-write of plugins.json holds this: the loader's own writers,
# the toggle route, and the install doors. Two writers on different plugins
# otherwise both read one snapshot and the second silently drops the first.
PLUGINS_JSON_LOCK = threading.RLock()
# Core-ui plugin names from before the class retired (2026-10-25): an old
# install's plugins.json may still enable them, so no user plugin may take one.
RETIRED_PLUGIN_NAMES = frozenset({"setup-wizard"})


def _time_to_cron(value, fallback: str) -> str:
    """'HH:MM' or a bare hour (9, 9.0, '9') → daily cron 'M H * * *'. Anything
    unparsable keeps the manifest cron, so a mistyped settings value degrades
    to the declared default. The bare-hour form lets a plugin bind a schedule
    to an existing numeric hour setting (Discord greeting/sleep hours) instead
    of polling every 15 min and guarding the hour inside the handler."""
    try:
        text = str(value).strip()
        if ':' in text:
            hh, mm = text.split(':')
            hh, mm = int(hh), int(mm)
        else:
            hh, mm = int(float(text)), 0
        if 0 <= hh <= 23 and 0 <= mm <= 59:
            return f"{mm} {hh} * * *"
    except (ValueError, AttributeError, TypeError, OverflowError):
        pass
    return fallback


def _version_tuple(text) -> Optional[tuple]:
    """'2.10.1' → (2, 10, 1). Trailing non-numeric parts drop; None if nothing parses."""
    parts = []
    for piece in str(text).strip().split('.'):
        digits = re.match(r'\d+', piece)
        if not digits:
            break
        parts.append(int(digits.group()))
    return tuple(parts) if parts else None


# The classic memory engine's own rows. Per-chat RAG documents (knowledge tabs in
# `__rag__:<chat>` scopes) are not counted: core keeps those under either engine.
CLASSIC_MEMORY_COUNTS = (
    ("memory.db", "SELECT COUNT(*) FROM memories"),
    ("knowledge.db", "SELECT COUNT(*) FROM knowledge_entries e JOIN knowledge_tabs t ON t.id = e.tab_id "
                     "WHERE substr(t.scope, 1, 8) != '__rag__:'"),
    ("knowledge.db", "SELECT COUNT(*) FROM people"),
    ("goals.db", "SELECT COUNT(*) FROM goals"),
)


def _count_rows(path: Path, sql: str):
    """One read-only count. A table the schema never had counts 0; a store
    that will not open (locked, malformed, a share sqlite cannot address)
    is None: not empty, and nobody may decide anything on it."""
    try:
        conn = sqlite3.connect(ro_uri(path), uri=True)
        try:
            return conn.execute(sql).fetchone()[0]
        finally:
            conn.close()
    except sqlite3.Error as e:
        if "no such table" in str(e):
            return 0
        logger.warning(f"[PLUGINS] {path.name} could not be read for the memory engine count: {e}")
        return None


def classic_memory_rows(user_dir: Path):
    """How many rows the classic memory engine holds for this install
    (read-only). None: a store exists but could not be read."""
    n = 0
    for db, sql in CLASSIC_MEMORY_COUNTS:
        path = user_dir / db
        if not path.exists():
            continue
        c = _count_rows(path, sql)
        if c is None:
            return None
        n += c
    return n


def palace_memory_rows(user_dir: Path):
    """How many rows Mind Palace holds (memories and entities), the same way.
    Two counts: one statement over both tables read a palace without an
    entities table as empty (hunt of the hunt H13)."""
    path = user_dir / "memory" / "mind.db"
    if not path.exists():
        return 0
    n = 0
    for sql in ("SELECT COUNT(*) FROM chunks", "SELECT COUNT(*) FROM entities"):
        c = _count_rows(path, sql)
        if c is None:
            return None
        n += c
    return n


def core_name_collision(name: str):
    """Why `name` may not be installed into the user band, or None. ONE rule for
    every install door — the REST installer, the store tool, Toolmaker. A user
    plugin that takes a shipped plugin's name shadows it at the next boot: the
    third-party code runs under the shipped name, scopes and tool names, or,
    blocked as unsigned, the shipped plugin is simply gone from the registry
    (for memory, that is the degraded-mode banner)."""
    if (SYSTEM_PLUGINS_DIR / name).is_dir():
        return f"'{name}' conflicts with the shipped system plugin at core/plugins/{name} — a user plugin may not take its name"
    if (PROJECT_ROOT / "functions" / f"{name}.py").exists():
        return f"'{name}' conflicts with a core function"
    if name in RETIRED_PLUGIN_NAMES:
        return f"'{name}' is a retired core name — an old install's plugin list may still enable it"
    return None


class PluginState:
    """Simple JSON key-value store for plugin data.

    Each plugin gets its own file at user/plugin_state/{name}.json.
    Authors who need more can bring their own SQLite.
    """

    def __init__(self, plugin_name: str):
        self._name = plugin_name
        self._path = PLUGIN_STATE_DIR / f"{plugin_name}.json"
        self._lock = threading.Lock()
        self._data = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8-sig"))
            except Exception as e:
                # Quarantine the corrupted file before returning empty dict —
                # otherwise the next save() silently overwrites whatever was
                # salvageable (often the only copy of plugin auth/state).
                from datetime import datetime
                quarantine = self._path.with_suffix(
                    f'.json.bad-{datetime.utcnow().strftime("%Y%m%dT%H%M%S")}'
                )
                try:
                    self._path.rename(quarantine)
                    logger.error(
                        f"[PLUGIN-STATE] Corrupted state file for '{self._name}': {e}. "
                        f"Quarantined to {quarantine.name}; starting with empty state."
                    )
                except Exception as rename_err:
                    logger.error(
                        f"[PLUGIN-STATE] Corrupted {self._path}: {e}. "
                        f"Could not quarantine ({rename_err}); next save will overwrite."
                    )
        return {}

    def _save(self):
        PLUGIN_STATE_DIR.mkdir(parents=True, exist_ok=True)
        # Unique tmp suffix per-process so concurrent writers can't truncate
        # each other's tmp file before rename. Lock ordering still matters
        # for content correctness (use update_with_lock for RMW), but this
        # ensures the on-disk tmp never collides.
        import os as _os
        tmp = self._path.with_suffix(f'.json.tmp.{_os.getpid()}.{id(self):x}')
        try:
            tmp.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
            replace_with_retry(tmp, self._path)
        finally:
            if tmp.exists():
                try: tmp.unlink()
                except Exception: pass

    def get(self, key: str, default=None):
        with self._lock:
            return self._data.get(key, default)

    def save(self, key: str, value):
        with self._lock:
            self._data[key] = value
            self._save()

    def delete(self, key: str):
        with self._lock:
            self._data.pop(key, None)
            self._save()

    def all(self) -> dict:
        with self._lock:
            return dict(self._data)

    def clear(self):
        with self._lock:
            self._data = {}
            self._save()

    def update_with_lock(self, key: str, mutator, default=None):
        """Atomic read-modify-write for a single key.

        mutator(current_value) -> new_value, called under self._lock so two
        concurrent updates can't clobber each other (the bug family that hit
        MCP, discord, telegram — read the dict, mutate, save, second writer
        loses the first writer's change).

        Returns the new value.
        """
        with self._lock:
            current = self._data.get(key, default)
            new_value = mutator(current)
            self._data[key] = new_value
            self._save()
            return new_value


class PluginChatState:
    """Chat-scoped plugin data (vault v1.3). Rows live in the history DB
    and follow the chat: sealed with vault_chat, renamed with it, deleted
    with it. Values are JSON-serializable objects. Reads on a hidden chat
    (private + vault sealed) come back empty; writes RAISE there — never a
    silent drop. Resolves the chat store lazily per call so this can be
    handed out at plugin-load time, before the chat system is up."""

    def __init__(self, plugin_name: str):
        self._name = plugin_name

    @staticmethod
    def _sm():
        from core.api_fastapi import get_system
        return get_system().llm_chat.session_manager

    def get(self, chat_name: str, key: str, default=None):
        return self._sm().plugin_data_get(self._name, chat_name, key, default)

    def put(self, chat_name: str, key: str, value):
        self._sm().plugin_data_put(self._name, chat_name, key, value)

    def append(self, chat_name: str, key: str, value) -> int:
        return self._sm().plugin_data_append(self._name, chat_name, key, value)

    def append_many(self, chat_name: str, key: str, values: list) -> list:
        """Append several rows in ONE transaction — all land or none."""
        return self._sm().plugin_data_append_many(self._name, chat_name, key, values)

    def read_all(self, chat_name: str, key: str) -> list:
        return self._sm().plugin_data_read_all(self._name, chat_name, key)

    def replace(self, chat_name: str, key: str, values: list):
        self._sm().plugin_data_replace(self._name, chat_name, key, values)

    def delete(self, chat_name: str, key: str = None):
        self._sm().plugin_data_delete(self._name, chat_name, key)

    def keys(self, chat_name: str) -> list:
        return self._sm().plugin_data_keys(self._name, chat_name)

    def get_all_chats(self, key: str) -> dict:
        """{chat: value} across every VISIBLE chat holding `key` — hidden
        chats structurally absent (core filters, not the plugin)."""
        return self._sm().plugin_data_get_all_chats(self._name, key)

    def meta(self, chat_name: str, key: str):
        """{'rows': n, 'updated_at': max-ISO} or None when absent/hidden."""
        return self._sm().plugin_data_meta(self._name, chat_name, key)


class PluginLoader:
    """Discovers, validates, and loads plugins from plugins/ and user/plugins/."""

    def __init__(self):
        # {plugin_name: {manifest, path, enabled, band, state}}
        self._plugins: Dict[str, dict] = {}
        self._lock = threading.Lock()
        self._load_errors: list = []  # Accumulates startup errors for frontend display
        self._function_manager = None  # Set via scan() for plugin tool loading
        self._scheduler = None  # Set via set_scheduler() for plugin schedule tasks
        self._watcher_running = False
        self._watcher_thread = None
        # Route registry: {plugin_name: [(method, compiled_regex, param_names, handler_func), ...]}
        self._routes: Dict[str, list] = {}
        # Socket registry: {plugin_name: {path: async handler}}, and the live
        # handler tasks per plugin as {task: loop} so unload can end them
        self._sockets: Dict[str, dict] = {}
        self._live_sockets: Dict[str, dict] = {}
        # Daemon event source registry: {plugin_name: [source_defs]}
        self._event_sources: Dict[str, list] = {}
        # Daemon reply handlers: {plugin_name: callable(task, event_data_dict, response_text)}
        self._reply_handlers: Dict[str, Callable] = {}
        # Per-plugin reload locks — serializes reload against concurrent toggle/watcher
        self._reload_locks: Dict[str, threading.Lock] = {}
        self._reload_locks_lock = threading.Lock()

    def _is_managed(self):
        """Check if running in managed/Docker mode (single source of truth)."""
        from core.settings_manager import settings
        return settings.is_managed()

    def _band_move_tripwires(self):
        """Loud where the band move (plugins/ -> core/plugins/, 2026-10-17) would
        otherwise fail silently. Every branch only logs (plus one toast entry)."""
        import sys
        from core.paths import PROJECT_ROOT as _REAL_ROOT   # the real root, not the patchable module global
        # 1. Code that counted .parent one level short lands on a REAL folder —
        #    core/ for a shipped plugin, user/ for a user-band one — and quietly
        #    builds core/user/... or user/user/...
        for stray_user in (PROJECT_ROOT / "core" / "user", PROJECT_ROOT / "user" / "user"):
            if stray_user.exists():
                logger.error(f"[PLUGINS] {stray_user} exists — something computed the project root "
                             "one level short. Move its contents into user/ and replace the counted "
                             ".parent chain with core.paths.PROJECT_ROOT.")
        # 2. The old root plugins/ is no longer scanned. Old copies of SHIPPED
        #    plugins (a zip extracted over the old tree) are deleted by name,
        #    never moved; a hand-dropped plugin belongs in user/plugins/. Named
        #    apart on purpose: "delete the folder" beside "found yours" would
        #    cost that user their plugin. Theirs also rides the boot-toast lane
        #    (_load_errors), because a log line is exactly what they never read.
        old_root = PROJECT_ROOT / "plugins"
        if old_root.is_dir():
            stray = sorted(p.name for p in old_root.iterdir()
                           if p.is_dir() and (p / "plugin.json").exists())
            shipped = [n for n in stray if (SYSTEM_PLUGINS_DIR / n).is_dir()]
            yours = [n for n in stray if n not in shipped]
            if shipped:
                logger.warning(f"[PLUGINS] plugins/ at the repo root is no longer scanned (the shipped band "
                               f"lives in core/plugins/). It holds old copies of {len(shipped)} shipped "
                               f"plugin(s) {shipped[:8]} — delete those folders; do NOT move them to user/plugins/.")
            if yours:
                logger.warning(f"[PLUGINS] plugins/ at the repo root is no longer scanned (the shipped band "
                               f"lives in core/plugins/). Found {yours} there — your own plugins go in user/plugins/.")
                for name in yours:
                    err = {"plugin": name,
                           "error": f"plugins/{name} sits in the old root plugins/ folder, which is no longer scanned",
                           "hint": f"move it to user/plugins/{name} and reload"}
                    self._load_errors.append(err)
                    try:
                        from core.event_bus import publish, Events
                        publish(Events.PLUGIN_LOAD_ERROR, err)
                    except Exception:
                        pass
            # A package at the old root would BEAT the plugins.py shim (a folder
            # with an __init__ wins over a module file) and hijack every
            # plugins.* import into the old tree. Checked on disk, because at
            # scan time nothing has usually imported `plugins` yet.
            if (old_root / "__init__.py").exists():
                logger.error(f"[PLUGINS] {old_root / '__init__.py'} exists — it shadows the plugins.py shim "
                             "and sends every plugins.<name> import into the dead old tree; delete it (and "
                             "the root plugins/ folder if nothing of yours is in it).")
        # 3. Imported by disk path? core.plugins.<x> is a SECOND module object
        #    with its own locks and state; the import name is plugins.<x>.
        by_disk_path = sorted(k for k in sys.modules
                              if k == "core.plugins" or k.startswith("core.plugins."))
        if by_disk_path:
            logger.error(f"[PLUGINS] imported by disk path (a second module copy): {by_disk_path[:5]} — "
                         "import shipped plugins as plugins.<name>, never core.plugins.<name>.")
        # 4. If something did import `plugins` already, it must be the shim.
        shim = sys.modules.get("plugins")
        if shim is not None:
            shim_file = getattr(shim, "__file__", None)
            expected = _REAL_ROOT / "plugins.py"
            if not shim_file or Path(shim_file).absolute() != expected:
                logger.error(f"[PLUGINS] the plugins namespace is {shim_file or 'a bare namespace package'}, "
                             f"not the shim {expected} — a stray plugins/__init__.py or plugins/ package at "
                             "the repo root is shadowing it; remove it.")

    def scan(self, function_manager=None):
        """Discover all plugins and load enabled ones.

        Args:
            function_manager: Optional FunctionManager for plugin tool registration.
        """
        self._function_manager = function_manager

        # Tripwires for the band move (plugins/ -> core/plugins/, 2026-10-17).
        # Advisory only, and wrapped: an unreadable stray folder must never
        # take the whole scan (and every plugin) down with it.
        try:
            self._band_move_tripwires()
        except Exception as e:
            logger.debug(f"[PLUGINS] band-move tripwires skipped: {e}")
        self._plugins.clear()
        add, drop = {}, {}
        try:
            add, drop = self._pin_memory_engine_once()
        except Exception as e:
            logger.warning(f"[PLUGINS] memory engine pin skipped: {e}")
        try:
            self._pin_featured_once()
        except Exception as e:
            logger.warning(f"[PLUGINS] featured plugin pin skipped: {e}")
        enabled_list = self._get_enabled_list()
        disabled_list = self._get_disabled_list()
        # The engine verdict holds for this boot even when plugins.json could
        # not take it (a no-op when it could): a boot on the wrong engine
        # strands whatever it saves.
        for key, names in (("enabled", enabled_list), ("disabled", disabled_list)):
            names[:] = [n for n in names if n not in drop.get(key, ())] + [n for n in add.get(key, ()) if n not in names]

        # System plugins (priority band 0-99)
        self._scan_dir(SYSTEM_PLUGINS_DIR, band="system", enabled_list=enabled_list, disabled_list=disabled_list)

        # User plugins (priority band 100-199)
        self._scan_dir(USER_PLUGINS_DIR, band="user", enabled_list=enabled_list, disabled_list=disabled_list)

        # Load enabled plugins
        loaded = 0
        blocked = []
        # Add-ons (`requires_plugins`) load after every host, so a dependent
        # that sorts before its host by name still finds it loaded (S0 doors).
        ordered = sorted(self._plugins.items(),
                         key=lambda kv: bool((kv[1].get("manifest") or {}).get("requires_plugins")))
        for name, info in ordered:
            if info["enabled"]:
                try:
                    ok = self._load_plugin(name)
                except Exception as e:
                    # one plugin's bad manifest must not stop every plugin after
                    # it (and plugins_ready) - integrity scout 2026-10-27
                    logger.error(f"[PLUGINS] {name} failed to load: {e!r}", exc_info=True)
                    try:
                        self.unload_plugin(name)           # whatever it registered before the raise
                    except Exception as ue:
                        logger.warning(f"[PLUGINS] {name}: cleanup after the failed load: {ue!r}")
                    self._load_errors.append({"plugin": name, "error": f"Failed to load: {e}",
                                              "hint": "Check the plugin's plugin.json"})
                    ok = False
                if ok:
                    loaded += 1
                else:
                    # Plugin failed verification/load. Mark in-memory enabled=False
                    # so UI and toolset registration reflect reality. DO NOT remove
                    # from user's enabled list on disk — user intent survives
                    # temporary failures (e.g. signing regressions, missing deps).
                    # Next restart with the underlying issue fixed = loads clean,
                    # no UI click needed.
                    info["enabled"] = False
                    blocked.append(name)
                    # Surface it: the reload path publishes on a block, the boot path
                    # only logged — the user saw a toggle that was simply off
                    # (Discord hunt 2.13.0, row 84). When _load_plugin already said
                    # why (a tool-name refusal, a failed load), that row stands: the
                    # generic one read "Blocked at boot: verified" beside it.
                    if not any(e.get("plugin") == name for e in self._load_errors):
                        err_data = {"plugin": name,
                                    "error": f"Blocked at boot: {info.get('verify_msg') or 'load failure'}"}
                        self._load_errors.append(err_data)
                        try:
                            from core.event_bus import publish, Events
                            publish(Events.PLUGIN_LOAD_ERROR, err_data)
                        except Exception:
                            pass

        if blocked:
            logger.warning(f"[PLUGINS] Enabled but blocked (intent preserved, retry next restart): {blocked}")

        logger.info(f"[PLUGINS] Scan complete: {len(self._plugins)} found, {loaded} loaded")

        # plugins_ready: fires once per scan, after every enabled plugin has
        # registered (tools, hooks, prompt packs, games). The "after my own
        # pack registered" moment plugins had no way to reach — e.g. game-room
        # re-merging its runtime-rendered story prompts so names like 'rose'
        # resolve before sapphire.py's post-scan re-prime reads them.
        # (Sapph-not-Rose reboot bug, 2026-08-05.)
        self._fire_plugins_ready("scan", loaded)

    def _fire_plugins_ready(self, reason: str, loaded: int = 1, plugin: str = None):
        """The "registration finished, re-assert anything runtime-owned" moment.
        Fires after the boot scan AND after every out-of-scan (re)load — reload,
        enable-toggle, dep-install, dev-watcher, rescan. Manifest-only
        re-registration wipes runtime-rendered entries (a story costume the
        pack files don't contain), and core's missing-prompt fallback then
        permanently rewrites the chat's prompt to 'default' — so this must
        fire on EVERY path, not just boot (Sapph-not-Rose reload leg, 2026-08-05)."""
        try:
            if hook_runner.has_handlers("plugins_ready"):
                from core.hooks import HookEvent
                hook_runner.fire("plugins_ready",
                                 HookEvent(metadata={"loaded": loaded, "reason": reason, "plugin": plugin}))
        except Exception as e:
            logger.warning(f"[PLUGINS] plugins_ready ({reason}) dispatch failed: {e}")
        # Toolsets that still name the other memory engine's tools: a row with
        # a Repair button (core/toolsets/engine_drift.py). Boot here; the engine
        # switch checks after it records the new engine (routes/plugins.py).
        if reason == "scan":
            try:
                from core.toolsets import engine_drift
                engine_drift.register()
                engine_drift.check()
            except Exception as e:
                logger.warning(f"[PLUGINS] toolset engine check failed: {e}")
        # Re-derive the NO_PROXY belt now that this (re)load wave changed the
        # set of registered direct hosts: unmigrated raw-requests plugins and
        # daemon subprocesses (which inherit env at spawn) need late-added LAN
        # gear in NO_PROXY. Migrated callers read direct_hosts() live and don't
        # care. Boot's post-scan re-derive is now the scan-leg special case of
        # this general rule (net-facade wave 2).
        try:
            from core.socks_proxy import apply_proxy_env
            apply_proxy_env()
        except Exception as e:
            logger.debug(f"[PLUGINS] belt re-derive after plugins_ready failed: {e}")

    def _scan_dir(self, directory: Path, band: str, enabled_list: list, disabled_list: list = None):
        """Scan a directory for plugin.json manifests."""
        if not directory.exists():
            return
        if disabled_list is None:
            disabled_list = []

        for child in sorted(directory.iterdir()):
            if not child.is_dir():
                continue
            manifest_path = child / "plugin.json"
            if not manifest_path.exists():
                continue

            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
            except Exception as e:
                logger.warning(f"[PLUGINS] Bad manifest in {child.name}: {e}")
                continue

            name = manifest.get("name", child.name)
            if not self._validate_manifest(name, manifest):
                continue

            # Skip plugins hidden in managed mode
            if manifest.get("managed_hide") and self._is_managed():
                logger.debug(f"[PLUGINS] Skipping {name} (managed_hide)")
                continue

            # Enabled if user enabled it, OR manifest default_enabled AND user didn't explicitly disable it
            is_enabled = (name in enabled_list) or (
                manifest.get("default_enabled", False) and name not in disabled_list
            )

            # Verify signature on discovery (before any code loads)
            verified, verify_msg, verify_meta = verify_plugin(child)

            try:
                manifest_mtime = manifest_path.stat().st_mtime
            except Exception:
                manifest_mtime = 0

            prev = self._plugins.get(name)
            if prev is not None and prev.get("band") != band:
                logger.warning(
                    f"[PLUGINS] '{name}' ({band} band) shadows the {prev.get('band')} copy "
                    f"at {prev.get('path')} — only the {band} copy will load"
                )
            self._plugins[name] = {
                "manifest": manifest,
                "path": child,
                "enabled": is_enabled,
                "band": band,
                "loaded": False,
                "verified": verified,
                "verify_msg": verify_msg,
                "verify_tier": verify_meta.get("tier", "unsigned"),
                "verified_author": verify_meta.get("author"),
                "_manifest_mtime": manifest_mtime,
            }
            logger.debug(f"[PLUGINS] Found: {name} ({band}, enabled={is_enabled}, {verify_msg})")

    def _validate_manifest(self, name: str, manifest: dict) -> bool:
        """Basic manifest validation."""
        if "name" not in manifest:
            logger.warning(f"[PLUGINS] {name}: manifest missing 'name' field")
            return False
        return True

    @staticmethod
    def _check_dependencies(manifest: dict) -> list:
        """Check if pip_dependencies from manifest are installed.

        Returns list of missing package specifiers (empty = all good).
        """
        deps = manifest.get("pip_dependencies", [])
        if not deps:
            return []

        import importlib.metadata
        import re

        missing = []
        for spec in deps:
            # Extract package name from specifier like "telethon>=1.34"
            pkg_name = re.split(r'[><=!~\[]', spec)[0].strip()
            if not pkg_name:
                continue
            try:
                importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                missing.append(spec)
        return missing

    @staticmethod
    def pip_hint(missing: list) -> str:
        """The copy-paste line for missing pip_dependencies. Specs carrying
        operators / extras / direct references are double-quoted — the one
        quote cmd, PowerShell and bash all accept. Unquoted, `davey>=0.1.4`
        is a shell redirect and `py-cord[voice] @ git+…` splits at the `@`
        (Windows scout 2026-09-20). Every hint site calls this."""
        def q(s):
            return f'"{s}"' if re.search(r'[<>=!~\[\]@ ;]', s) else s
        return "pip install " + " ".join(q(s) for s in missing)

    @staticmethod
    def _warn_min_core_version(name: str, manifest: dict):
        """Shout when a plugin declares min_core_version newer than this core.

        A newer plugin on an older core fails at runtime with zero explanation
        (missing renderer features, absent routes). This turns that mystery
        into one loud log line. Never blocks the load."""
        want_raw = str(manifest.get("min_core_version") or "").strip()
        if not want_raw:
            return
        try:
            have_raw = (PROJECT_ROOT / "VERSION").read_text(encoding="utf-8").strip()
        except Exception:
            return
        want, have = _version_tuple(want_raw), _version_tuple(have_raw)
        if want is None or have is None:
            return
        if have < want:
            logger.warning(
                f"[PLUGINS] VERSION MISMATCH: '{name}' wants Sapphire core >= {want_raw} "
                f"but this install is {have_raw}. Loading anyway — expect broken settings "
                f"pages or missing features until the core is updated (git pull)."
            )

    def switched_on(self, name: str) -> bool:
        """Is `name`'s switch on, as far as this loader knows? True when it
        knows nothing (tests, scripts). A plugin module imported while its
        switch is off must do nothing at import: the palace registered its
        contacts provider and audit sink that way, from a doc:N picture or
        a layer plugin's mirror, with no unload to follow (migration hunt
        2026-11-01, D1). ONE door for every such check."""
        info = self.get_plugin_info(name)
        return info is None or bool(info.get("enabled"))

    def _read_plugins_json(self, key: str) -> list:
        """Read a list from user/webui/plugins.json; no file = the defaults. A
        corrupt file is quarantined at ERROR — silently reverting to defaults
        would turn every explicitly-enabled plugin dark on next boot with two
        WARNING lines as the only trace."""
        path = USER_PLUGINS_JSON
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            value = data.get(key, [])
            if not isinstance(value, list):
                logger.warning(f"[PLUGINS] {path.name}: '{key}' is not a list, ignored")
                return []
            return [n for n in value if isinstance(n, str)]
        except Exception as e:
            from datetime import datetime
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            quarantine = path.with_name(path.name + f".bad-{stamp}")
            try:
                path.rename(quarantine)
                logger.error(f"[PLUGINS] CORRUPT {path.name} quarantined to "
                             f"{quarantine.name} — plugin enable state LOST, "
                             f"reverting to defaults: {e}")
            except OSError:
                logger.error(f"[PLUGINS] CORRUPT {path.name} (quarantine "
                             f"failed) — plugin enable state ignored: {e}")
            try:
                from core.event_bus import publish, Events
                publish(Events.PLUGIN_LOAD_ERROR, {
                    "plugin": "plugins.json",
                    "error": "Corrupt plugin enable-state file — reverted to defaults",
                })
            except Exception:
                pass
        return []

    def _get_enabled_list(self) -> list:
        """Read enabled plugins from user/webui/plugins.json."""
        return self._read_plugins_json("enabled")

    def _get_disabled_list(self) -> list:
        """Read explicitly-disabled plugins (overrides default_enabled)."""
        return self._read_plugins_json("disabled")

    def _append_plugins_json(self, pins: dict, drop: dict = None):
        """Add names to the lists of user/webui/plugins.json (created if
        absent); `drop` takes names out of lists first (an engine moved
        from one list to the other)."""
        with PLUGINS_JSON_LOCK:
            data = {}
            if USER_PLUGINS_JSON.exists():
                data = json.loads(USER_PLUGINS_JSON.read_text(encoding="utf-8-sig"))
            lst = lambda key: [n for n in data[key] if isinstance(n, str)] if isinstance(data.get(key), list) else []
            for key in ("enabled", "disabled", "pinned"):
                data[key] = lst(key)                 # a hand-edited null or string heals on the next write
            for key, names in (drop or {}).items():
                data[key] = [n for n in lst(key) if n not in names]
            for key, names in pins.items():
                cur = lst(key)
                data[key] = cur + [n for n in names if n not in cur]
            USER_PLUGINS_JSON.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = USER_PLUGINS_JSON.with_suffix('.tmp')
            # fsync like the toggle route (2026-05-07): a power cut between
            # rename and flush zeroed the file, and the engine pin rode in it.
            from core.settings_manager import _fsync_file, _fsync_dir
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
                _fsync_file(f)
            replace_with_retry(tmp_path, USER_PLUGINS_JSON)
            _fsync_dir(USER_PLUGINS_JSON.parent)

    # Flipped to default_enabled for the new setup wizard (2026-10-24), which
    # shows them ticked so a new user chooses. An install that never saw that
    # step must not wake up with a shell, a camera and a screen grabber on.
    FEATURED_2026_10 = ("discord", "telegram", "email", "homeassistant",
                        "coding-harness", "webcam", "screenshot")

    def _pin_featured_once(self):
        """Once per install: an install that finished setup before the new
        wizard (complete, but no SETUP_CONSENT - only the new wizard stamps
        it) gets the featured plugins it never chose pinned OFF. Names already
        in a list were chosen either way and stay. A fresh install, or one that
        walked the new wizard, keeps the defaults (hunt 20)."""
        data = json.loads(USER_PLUGINS_JSON.read_text(encoding="utf-8-sig")) if USER_PLUGINS_JSON.exists() else {}
        if "featured-2026-10" in (data.get("pinned") or []):
            return
        from core.settings_manager import settings
        pins = {"pinned": ["featured-2026-10"]}
        off = []
        if settings.get("SETUP_COMPLETE", False) and not settings.get("SETUP_CONSENT", None):
            enabled, disabled = self._get_enabled_list(), self._get_disabled_list()
            off = [n for n in self.FEATURED_2026_10 if n not in enabled and n not in disabled]
            if off:
                pins["disabled"] = off
        self._append_plugins_json(pins)
        if not off:
            return
        logger.info(f"[PLUGINS] featured plugins kept off for an existing install: {', '.join(off)}")
        try:
            from core import notify
            notify.notify("Some plugins stay off until you turn them on", level="warning", source="plugins",
                          key="featured-pin", once=True,
                          body=f"An update marked these as featured: {', '.join(off)}. This install never "
                               f"chose them, so they stay off. Settings \u203a Plugins turns any of them on.",
                          go={'view': 'settings', 'tab': 'plugins'})
        except Exception as e:
            logger.debug(f"[PLUGINS] featured pin notice skipped: {e}")

    ENGINES = ("memory", "mindpalace")

    def _place_engine(self, engine, enabled, disabled):
        """The list edits that make `engine` ('memory' | 'mindpalace' | 'none')
        the one that runs: the chosen one on, the other off. Returns (add, drop)."""
        add, drop = {}, {}
        for name in self.ENGINES:
            if name == engine:
                if name == "memory" and name not in enabled:    # classic defaults off now
                    add.setdefault("enabled", []).append(name)
                if name in disabled:
                    drop.setdefault("disabled", []).append(name)
            else:
                if name in enabled:
                    drop.setdefault("enabled", []).append(name)
                if name not in disabled:
                    add.setdefault("disabled", []).append(name)
        return add, drop

    def _engine_file(self):
        """The engine verdict's durable home: a one-key file beside
        plugins.json. plugins.json is quarantined on sight and rewritten by
        other hands; this file is written only here and by the toggle route,
        with fsync (hunt of the hunt 2026-11-01, H8)."""
        return USER_PLUGINS_JSON.with_name("memory-engine.json")

    def read_engine(self):
        """'memory' | 'mindpalace' | 'none', or None when no verdict is recorded."""
        try:
            data = json.loads(self._engine_file().read_text(encoding="utf-8-sig"))
            engine = data.get("engine") if isinstance(data, dict) else None
            return engine if engine in ("memory", "mindpalace", "none") else None
        except FileNotFoundError:
            return None
        except Exception as e:
            logger.warning(f"[PLUGINS] memory-engine.json unreadable, ignored: {e}")
            return None

    def write_engine(self, engine: str, by: str):
        from datetime import datetime, timezone
        from core.settings_manager import _fsync_file, _fsync_dir
        path = self._engine_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"engine": engine, "by": by,
                       "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}, f, indent=2)
            _fsync_file(f)
        replace_with_retry(tmp, path)
        _fsync_dir(path.parent)

    def _pin_memory_engine_once(self):
        """2026-10: Mind Palace became the shipped default memory engine and
        classic memory went legacy (both manifests' default_enabled flipped).
        The engine this install runs lives in user/webui/memory-engine.json,
        written here the first time and by the toggle route after:
        plugins.json is quarantined on sight, and a verdict that lived only
        there re-ran the data vote and could flip a user off the engine they
        chose (hunt of the hunt 2026-11-01, H8). Every boot the lists are
        made to agree with it. With no verdict yet, once per install
        ("memory-engine" in pinned) the loader settles it:
          - an engine already placed in a list (an earlier pin, Settings)
            stays as placed; classic off before the palace existed = no
            engine, as before; the palace off with classic unplaced = classic
            ran by the old default, so classic (H7);
          - both on, the palace on with classic unplaced (the 2026-10 toggle
            bug's leftover), or nothing placed: the engine that holds the
            data runs. A tie goes to classic (the palace imports classic,
            not the reverse); an empty install takes the new default.
        A store that exists but cannot be read is not empty: nothing is
        recorded and this boot runs classic unless the palace is known to
        hold more, so the next boot decides for real.
        Returns (add, drop) for the lists. scan() applies them to this boot
        even when plugins.json could not take them: a boot on the wrong
        engine strands whatever it saves."""
        enabled, disabled = self._get_enabled_list(), self._get_disabled_list()
        marked = "memory-engine" in self._read_plugins_json("pinned")
        chosen = self.read_engine()
        if chosen:
            add, drop = self._place_engine(chosen, enabled, disabled)
            if not marked:
                add["pinned"] = ["memory-engine"]
            if add or drop:
                logger.info(f"[PLUGINS] memory engine '{chosen}' restored to the lists: +{add} -{drop}")
                try:
                    self._append_plugins_json(add, drop)
                except Exception as e:
                    logger.warning(f"[PLUGINS] memory engine lists not saved ({e}); applied for this boot only")
            return add, drop
        if marked:
            # Pinned before the verdict file existed: derive it from the lists
            # once, so the durable home is there before any plugins.json loss.
            derived = ("memory" if "memory" in enabled
                       else "mindpalace" if "mindpalace" not in disabled else "none")
            try:
                self.write_engine(derived, "pin")
            except Exception as e:
                logger.warning(f"[PLUGINS] memory engine verdict not saved: {e}")
            return {}, {}
        mem_on, mem_off = "memory" in enabled, "memory" in disabled
        mp_on, mp_off = "mindpalace" in enabled, "mindpalace" in disabled
        notice, record = None, True
        if mem_off:
            engine = "mindpalace" if mp_on else "none"         # classic turned off on purpose
        elif mp_off:
            engine = "memory"                                   # placed, or the old default ran classic (H7)
            if not mem_on:
                notice = "This install stays on Memory (legacy), the engine it was running."
        elif mem_on and not mp_on:
            engine = "memory"
            notice = "This install stays on Memory (legacy), the engine it was running."
        else:
            user_dir = USER_PLUGINS_JSON.parent.parent
            classic, palace = classic_memory_rows(user_dir), palace_memory_rows(user_dir)
            record = classic is not None and palace is not None
            c, p = (1 if classic is None else classic), (1 if palace is None else palace)
            if p > c or c == 0:
                engine = "mindpalace"
                if mem_on:
                    notice = ("Both engines were switched on; only one runs at a time. Mind Palace "
                              "holds your data, so it runs and Memory (legacy) is off.")
            else:
                engine = "memory"
                notice = "This install stays on Memory (legacy) because it holds your data."
        add, drop = self._place_engine(engine, enabled, disabled)
        if record:
            add["pinned"] = ["memory-engine"]
            try:
                self.write_engine(engine, "pin")
            except Exception as e:
                logger.warning(f"[PLUGINS] memory engine verdict not saved: {e}")
            try:
                self._append_plugins_json(add, drop)
            except Exception as e:
                logger.warning(f"[PLUGINS] memory engine pin not saved ({e}); applied for this boot only")
        else:
            notice = None
            logger.warning("[PLUGINS] a memory store could not be read; the engine is chosen for this boot only")
        if add.get("enabled") or add.get("disabled") or drop:
            logger.info(f"[PLUGINS] memory engine '{engine}' pinned for an existing install: +{add} -{drop}")
        if notice:
            try:
                from core import notify
                notify.notify("Mind Palace is the new default memory", level="warning", source="plugins",
                              key="memory-engine-pin", once=True,
                              body=notice + " Settings \u203a Plugins switches engines; Mind Palace imports the old data.",
                              go={'view': 'settings', 'tab': 'plugins'})
            except Exception as e:
                logger.debug(f"[PLUGINS] engine pin notice skipped: {e}")
        return add, drop

    def _install_pkg_alias(self, name: str, plugin_dir: Path, info: dict):
        """Make a user-band plugin importable as `plugins.<name>`.

        Installs a package module in sys.modules with submodule_search_locations
        pointing at the plugin dir, so submodule imports resolve through the
        standard machinery. No-op if a real plugins/<name> exists on disk
        (the genuine namespace package wins) or the alias is already present.
        Removed in unload_plugin via info["_pkg_alias"].
        """
        import sys
        import importlib
        import importlib.util
        from importlib.machinery import ModuleSpec

        alias = f"plugins.{name}"
        if alias in sys.modules:
            return
        # A system plugins/<name>/ on disk normally wins (genuine namespace
        # package) — unless the registry winner is this user-band plugin
        # (user shadows system by name). Then imports must follow the registry,
        # or the shadowed system copy's code would execute instead.
        reg = self._plugins.get(name)
        if (SYSTEM_PLUGINS_DIR / name).is_dir() and not (reg and reg.get("band") == "user"):
            return
        try:
            pkg = importlib.import_module("plugins")
            spec = ModuleSpec(alias, None, is_package=True)
            spec.submodule_search_locations = [str(plugin_dir)]
            mod = importlib.util.module_from_spec(spec)
            sys.modules[alias] = mod
            setattr(pkg, name, mod)
            info["_pkg_alias"] = alias
        except Exception as e:
            logger.warning(f"[PLUGINS] {name}: package alias install failed: {e}")

    def _remove_pkg_alias(self, name: str, info: dict):
        """Drop the plugins.<name> alias and everything imported under it."""
        import sys
        alias = info.pop("_pkg_alias", None)
        if not alias:
            return
        for key in [k for k in list(sys.modules) if k == alias or k.startswith(alias + ".")]:
            sys.modules.pop(key, None)
        try:
            import plugins as pkg
            if getattr(pkg, name, None) is not None:
                delattr(pkg, name)
        except Exception:
            pass

    def _load_plugin(self, name: str) -> bool:
        """Load an enabled plugin, or leave NOTHING of it behind. True if loaded.

        A load that raised half-way (a bad manifest field, a route that isn't a
        regex, a plugin calling sys.exit at import) used to leave its hooks,
        tools, routes, schedules and daemon live on every path but boot's:
        rescan, reload, toggle. Uninstall then skipped the unload ("not
        loaded") and a reinstall registered on top - hooks fired twice (hunt
        21, reproduced). Every path now gets the unwind boot had."""
        try:
            return self._load_plugin_inner(name)
        except (Exception, SystemExit) as e:          # SystemExit: one plugin never ends her
            logger.error(f"[PLUGINS] {name} failed to load: {e!r}", exc_info=True)
            try:
                self.unload_plugin(name)
            except Exception as ue:
                logger.warning(f"[PLUGINS] {name}: cleanup after the failed load: {ue!r}")
            with self._lock:
                if name in self._plugins:
                    self._plugins[name]["loaded"] = False
            self._load_errors.append({"plugin": name, "error": f"Failed to load: {e}",
                                      "hint": "Check the plugin's plugin.json and its code"})
            return False

    def _load_plugin_inner(self, name: str) -> bool:
        """_load_plugin's body: check cached verification, register hooks, voice commands.
        Returns True if loaded, False if blocked."""
        info = self._plugins.get(name)
        if not info:
            return False

        # A fresh load ATTEMPT supersedes this plugin's stale errors — since
        # get_load_errors went non-destructive (N7), a fixed-then-reloaded
        # plugin's old failure would otherwise toast in every new browser
        # session forever. Fail again and this same call re-appends the
        # current truth. (wave-3 A1, 2026-08-31)
        self._load_errors[:] = [e for e in self._load_errors
                                if e.get("plugin") != name]

        # Use verification result from scan
        verified = info.get("verified", False)
        verify_msg = info.get("verify_msg", "unknown")

        if not verified:
            if verify_msg != "unsigned":
                # Tampered signature — always block
                logger.error(f"[PLUGINS] BLOCKED {name}: {verify_msg}")
                return False

            try:
                import config
                allow_unsigned = config.ALLOW_UNSIGNED_PLUGINS
            except Exception as e:
                logger.warning(f"[PLUGINS] Could not read ALLOW_UNSIGNED_PLUGINS: {e}")
                allow_unsigned = False

            if allow_unsigned:
                logger.warning(f"[PLUGINS] {name}: unsigned plugin (sideloading enabled)")
            elif self._is_managed():
                # Managed mode: validate code instead of requiring signature
                from core.code_validator import validate_plugin_files
                ok, err = validate_plugin_files(info["path"], strictness='strict')
                if ok:
                    logger.info(f"[PLUGINS] {name}: unsigned but passed strict validation")
                    info["verify_tier"] = "validated"
                else:
                    logger.warning(f"[PLUGINS] BLOCKED {name}: failed code validation — {err}")
                    return False
            else:
                logger.warning(f"[PLUGINS] BLOCKED {name}: unsigned plugin (sideloading disabled)")
                return False
        else:
            logger.info(f"[PLUGINS] {name}: signature verified")

        manifest = info["manifest"]
        plugin_dir = info["path"]
        band = info["band"]
        try:
            base_priority = int(manifest.get("priority", 50))
        except (TypeError, ValueError):
            # A non-int priority ("50", null) used to ride into the hook
            # registry and blow up fire()'s sort INSIDE the lock, on every
            # turn, forever (hunt 2026-09-04 S2-01). Coerce or default.
            logger.warning(f"[PLUGINS] {name}: manifest priority "
                           f"{manifest.get('priority')!r} is not an int — using 50")
            base_priority = 50

        # Version-skew shout — warns loudly, never blocks
        self._warn_min_core_version(name, manifest)

        # Pre-flight dependency check — before any code loads
        missing = self._check_dependencies(manifest)
        info.pop("missing_deps", None)  # Clear stale dep state on reload
        if missing:
            info["missing_deps"] = missing
            pip_cmd = self.pip_hint(missing)
            logger.warning(f"[PLUGINS] {name}: missing dependencies: {missing} — {pip_cmd}")
            err_data = {
                "plugin": name,
                "error": f"Missing dependencies: {', '.join(missing)}",
                "hint": pip_cmd,
                "missing_deps": missing,
            }
            self._load_errors.append(err_data)
            from core.event_bus import publish, Events
            publish(Events.PLUGIN_LOAD_ERROR, err_data)
            # Stay enabled but not loaded — user can install deps and reload
            return True  # Don't block/disable, just skip loading code

        # requires_plugins (S0 doors, 2026-09-21): an add-on that rides another
        # plugin's hooks + api facade (discord-personality -> discord) does not
        # load while its host is missing or disabled. Same shape as missing
        # deps: stays enabled, reports once, retried when the host loads
        # (_load_dependents) or at the next boot.
        required = [str(r) for r in (manifest.get("requires_plugins") or [])]
        info.pop("missing_plugins", None)
        missing_hosts = [r for r in required
                         if not (self._plugins.get(r) or {}).get("loaded")]
        if missing_hosts:
            info["missing_plugins"] = missing_hosts
            hosts = ", ".join(missing_hosts)
            logger.warning(f"[PLUGINS] {name}: requires {hosts} — not loaded")
            err_data = {"plugin": name,
                        "error": f"Requires plugin(s) not loaded: {hosts}",
                        "hint": f"Enable {hosts} first, then reload {name}",
                        "missing_plugins": missing_hosts}
            self._load_errors.append(err_data)
            from core.event_bus import publish, Events
            publish(Events.PLUGIN_LOAD_ERROR, err_data)
            return True

        # Offset user plugins into 100-199 band
        if band == "user":
            base_priority = min(base_priority + 100, 199)
            # User-band plugins live outside the real plugins/ namespace
            # package, so their own absolute imports ("from plugins.<name>.
            # tools import x") can't resolve from disk. Install a package
            # alias whose search path points at the plugin dir — the normal
            # import machinery handles everything below it.
            self._install_pkg_alias(name, plugin_dir, info)

        capabilities = manifest.get("capabilities", {})

        # Register scope ContextVars BEFORE daemons and tools (Phase 3).
        # Plugin tool and daemon modules may do `from core.chat.function_manager
        # import scope_email` (etc.) at call time; those imports resolve via
        # function_manager.__getattr__ which looks up SCOPE_REGISTRY. If the
        # scope hasn't been registered yet, the import raises AttributeError.
        # Order MUST be: scope register → daemons → tools → hooks → routes.
        scope_defs = capabilities.get("scopes", [])
        if scope_defs:
            try:
                from core.chat.function_manager import register_plugin_scope
                for scope_def in scope_defs:
                    key = scope_def.get("key")
                    if not key:
                        continue
                    # Manifest can override the default value (e.g. None for disabled-by-default)
                    default = scope_def.get("default", "default")
                    register_plugin_scope(key, plugin_name=name, default=default)
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: failed to register scopes: {e}", exc_info=True)

        # Register hooks. privacy_aware (manifest top-level, vaulted chats
        # ruling F2): only plugins declaring it receive hooks for private-chat
        # turns — undeclared plugins are withheld, fail-closed.
        hook_runner.mark_privacy_aware(name, bool(manifest.get("privacy_aware")))
        # Plugin surfaces (2026-08-23): manifest `surfaces` = where this
        # plugin's presence injections belong; the user's override (plugin
        # state `surfaces`, Plugins page) wins. Absent = everywhere.
        hook_runner.set_surfaces(name, self.effective_surfaces(name, manifest))
        hooks = capabilities.get("hooks", {})
        hook_ns = {}            # one module per file: tts_stream_start's state is tts_chunk_audio's (2026-10-19)
        for hook_name, handler_path in hooks.items():
            handler_func = self._load_handler(plugin_dir, handler_path, hook_name, ns_cache=hook_ns)
            if handler_func:
                hook_runner.register(
                    hook_name, handler_func,
                    priority=base_priority,
                    plugin_name=name
                )

        # Register voice commands as auto-wired pre_chat hooks
        voice_commands = capabilities.get("voice_commands", [])
        for vc in voice_commands:
            handler_path = vc.get("handler")
            handler_func = self._load_handler(plugin_dir, handler_path, "pre_chat", ns_cache=hook_ns)
            if handler_func:
                voice_match = {
                    "triggers": vc.get("triggers", []),
                    "match": vc.get("match", "exact"),
                }
                # Voice commands that bypass LLM get highest priority in their band
                vc_priority = base_priority if not vc.get("bypass_llm") else min(base_priority, 19)
                if band == "user" and vc.get("bypass_llm"):
                    vc_priority = min(base_priority, 119)

                hook_runner.register(
                    "pre_chat", handler_func,
                    priority=vc_priority,
                    plugin_name=name,
                    voice_match=voice_match
                )

        # Slash commands (core/commands.py): `command` or `handle` in the handler file
        for cd in capabilities.get("commands", []):
            handler_func = self._load_handler(plugin_dir, cd.get("handler"), "command", ns_cache=hook_ns)
            if handler_func:
                from core import commands
                commands.register(cd.get("name"), handler_func, args=cd.get("args", ""),
                                  description=cd.get("description", ""), plugin=name)

        # Register tools with FunctionManager. A refusal dict means a tool-name
        # collision with an already-loaded plugin — mutual exclusivity by design
        # (e.g. memory vs mindpalace share tool names on purpose). Unwind this
        # plugin's partial registrations and report not-loaded; the boot loop
        # preserves user intent (retry next restart). Scopes stay — the scope
        # registry is idempotent and the owning plugin's entry was never
        # displaced.
        tool_paths = capabilities.get("tools", [])
        if tool_paths and self._function_manager:
            refusal = self._function_manager.register_plugin_tools(name, plugin_dir, tool_paths,
                                                                   expires=manifest.get("tool_expires"))
            if refusal:
                self._function_manager.unregister_plugin_tools(name)
                hook_runner.unregister_plugin(name)
                from core import commands
                commands.unregister_plugin(name)
                # A refused plugin's tool files already EXEC'd — any
                # module-level side effects (contacts providers, etc.) must
                # unwind too, or a "not loaded" plugin keeps serving
                # whitelist decisions from the wrong store (scout find,
                # 2026-07-19: mindpalace's provider survived the memory-
                # collision refusal).
                try:
                    from core.contacts import unregister_provider as _unreg_contacts
                    _unreg_contacts(name)
                except Exception:
                    pass
                try:
                    from core.audit import unregister_sink as _unreg_audit
                    _unreg_audit(name)
                except Exception:
                    pass
                try:
                    from core.socks_proxy import unregister_direct_hosts as _unreg_dh
                    _unreg_dh(name)
                except Exception:
                    pass
                self._load_errors.append(refusal)
                from core.event_bus import publish, Events
                publish(Events.PLUGIN_LOAD_ERROR, refusal)
                logger.warning(f"[PLUGINS] {name}: not loaded — {refusal['error']}")
                return False

        # Register dashboard widgets — same shape as other capabilities.
        # Widget render modules are served at /plugin-web/{name}/{render_path}.
        widgets = capabilities.get("widgets", [])
        if widgets:
            # Reserve plugin name 'core' for built-in widget registration.
            # Registering a plugin under 'core' would merge its widgets with
            # built-ins in the registry; unloading would wipe ALL built-ins.
            # 2026-05-07 chaos-scout finding.
            if name == "core":
                logger.warning(
                    f"[PLUGINS] plugin name 'core' is reserved for built-in widgets; "
                    f"refusing to register widgets from plugin '{name}'"
                )
                widgets = []
        if widgets:
            try:
                from core.dashboard_widgets import register_widget, WidgetSpec
                for w in widgets:
                    if not isinstance(w, dict):
                        continue
                    widget_id = w.get("id")
                    if not widget_id:
                        logger.warning(f"[PLUGINS] {name} widget missing 'id'; skipping")
                        continue
                    render_path = w.get("render", f"widgets/{widget_id}.js")
                    register_widget(WidgetSpec(
                        plugin=name,
                        widget_id=widget_id,
                        name=w.get("name", widget_id),
                        render_url=f"/plugin-web/{name}/{render_path}",
                        description=w.get("description", ""),
                        icon=w.get("icon", ""),
                        sizes=w.get("sizes", ["1x1"]),
                        default_size=w.get("default_size", "1x1"),
                        multi_instance=w.get("multi_instance", False),
                        settings_schema=w.get("settings_schema", []) or [],
                        api_version=w.get("api_version", 1),
                    ))
                logger.debug(f"[PLUGINS] Registered {len(widgets)} widget(s) for {name}")
            except Exception as e:
                logger.warning(f"[PLUGINS] Widget registration failed for {name}: {e}")

        # Register HTTP routes
        routes = capabilities.get("routes", [])
        if routes:
            self._register_routes(name, plugin_dir, routes)

        # Register WebSockets (/ws/plugin/<name>/<path>)
        sockets = capabilities.get("sockets", [])
        if sockets:
            self._register_sockets(name, plugin_dir, sockets)

        # Register providers (TTS, STT, Embedding, LLM)
        providers_decl = capabilities.get("providers", {})
        if providers_decl:
            registered = []
            for system_name, prov_config in providers_decl.items():
                registry = self._get_provider_registry(system_name)
                if not registry:
                    logger.warning(f"[PLUGINS] Unknown provider system '{system_name}' in {name}")
                    continue
                entry_file = prov_config.get("entry", "provider.py")
                class_name = prov_config.get("class_name")
                prov_key = prov_config.get("key", name)
                display_name = prov_config.get("display_name", name)
                if not class_name:
                    logger.warning(f"[PLUGINS] Provider in {name} missing class_name for {system_name}")
                    continue
                provider_path = plugin_dir / entry_file
                if not provider_path.exists():
                    logger.warning(f"[PLUGINS] Provider file not found: {provider_path}")
                    continue
                try:
                    ns = {"__file__": str(provider_path), "__name__": f"plugin_provider_{name}_{system_name}"}
                    exec(compile(provider_path.read_text(encoding='utf-8-sig'), str(provider_path), 'exec'), ns)
                    provider_class = ns.get(class_name)
                    if not provider_class:
                        logger.error(f"[PLUGINS] Class '{class_name}' not found in {provider_path}")
                        continue
                    # Pass through extra metadata
                    extra = {k: v for k, v in prov_config.items()
                             if k not in ('entry', 'class_name', 'key', 'display_name')}
                    registry.register_plugin(prov_key, provider_class, display_name, name, **extra)
                    registered.append((system_name, prov_key))
                except Exception as e:
                    logger.error(f"[PLUGINS] Failed to load provider {class_name} for {name}: {e}", exc_info=True)
            if registered:
                info["registered_providers"] = registered
                logger.debug(f"[PLUGINS] {name}: registered {len(registered)} provider(s)")

        # Register memory layers (mirror-mode declarations consumed by the
        # active memory plugin; harmless when no memory plugin is loaded)
        layer_defs = capabilities.get("memory_layers", [])
        if layer_defs:
            try:
                from core.memory_layers import register_layer
                accepted = [ld.get("key") for ld in layer_defs
                            if isinstance(ld, dict) and register_layer(ld.get("key"), ld, name)]
                if accepted:
                    info["registered_memory_layers"] = accepted
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: memory layer registration failed: {e}")

        # Register games (declarations consumed by a game HOST plugin, e.g.
        # game-room; harmless when no host is loaded — the registry just holds)
        game_defs = capabilities.get("games", [])
        if game_defs:
            try:
                from core.games_registry import register_game
                accepted = [gd.get("id") for gd in game_defs
                            if isinstance(gd, dict) and register_game(gd.get("id"), gd, name)]
                if accepted:
                    info["registered_games"] = accepted
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: game registration failed: {e}")

        # Register device drivers (declarations consumed by the device
        # engine, core/devices/engine.py)
        device_defs = capabilities.get("devices", [])
        if device_defs:
            try:
                from core.devices.registry import register_driver
                accepted = [dd.get("driver") for dd in device_defs
                            if isinstance(dd, dict) and register_driver(dd.get("driver"), dd, name)]
                if accepted:
                    info["registered_device_drivers"] = accepted
                    from core.devices import presence as _presence, engine as _dev_engine
                    _presence.poke()           # its devices may have things waiting
                    _dev_engine.retell()       # the device tools' descriptions name what its devices can do
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: device driver registration failed: {e}")

        # Register agent kinds (declarations consumed by the agent engine,
        # core/agents/engine.py; the kind's code stays in the plugin)
        agent_defs = capabilities.get("agents", [])
        if agent_defs:
            try:
                from core.agents.registry import register_kind
                accepted = [kd.get("kind") for kd in agent_defs
                            if isinstance(kd, dict) and register_kind(kd.get("kind"), kd, name)]
                if accepted:
                    info["registered_agent_kinds"] = accepted
                    from core.agents import engine as _agent_engine
                    _agent_engine.retell()     # the agent tools' descriptions name the kinds
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: agent kind registration failed: {e}")

        # Register prompt pack (mirror-only — merged into the prompt system
        # at read time, never written to user/prompts; user wins collisions)
        prompts_decl = capabilities.get("prompts", {})
        if prompts_decl and isinstance(prompts_decl, dict):
            try:
                from core import prompt_packs
                monoliths, pieces = None, None
                mono_rel = prompts_decl.get("monoliths")
                if mono_rel:
                    monoliths = json.loads((plugin_dir / mono_rel).read_text(encoding="utf-8-sig"))
                pieces_rel = prompts_decl.get("pieces")
                if pieces_rel:
                    pieces = json.loads((plugin_dir / pieces_rel).read_text(encoding="utf-8-sig"))
                counts = prompt_packs.register_pack(name, monoliths=monoliths, pieces=pieces,
                                                    kind=prompts_decl.get("kind"))
                info["registered_prompt_pack"] = True
                logger.info(f"[PLUGINS] {name}: prompt pack registered {counts}")
            except Exception as e:
                logger.error(f"[PLUGINS] {name}: prompt pack registration failed: {e}")

        # Register scheduled tasks with continuity scheduler
        schedules = capabilities.get("schedule", [])
        if schedules and self._scheduler:
            task_ids = []
            for sched in schedules:
                try:
                    task = self._scheduler.create_task(
                        self._sched_task_def(name, sched, plugin_dir), trusted=True)
                    task_ids.append(task["id"])
                    logger.debug(f"[PLUGINS] Registered schedule task '{sched.get('name')}' for {name}")
                except Exception as e:
                    # None placeholder keeps task_ids aligned with the manifest
                    # order — resync_plugin_schedules zips them positionally.
                    task_ids.append(None)
                    logger.error(f"[PLUGINS] Failed to register schedule for {name}: {e}")
            info["schedule_task_ids"] = task_ids

        # Register daemon event sources
        daemon_config = capabilities.get("daemon", {})
        if daemon_config:
            event_sources = daemon_config.get("event_sources", [])
            if event_sources:
                with self._lock:
                    self._event_sources[name] = [{
                        "name": src.get("name", f"{name}_event"),
                        "label": src.get("label", src.get("name", name)),
                        "plugin": name,
                        "filter_fields": src.get("filter_fields", []),
                        "task_fields": src.get("task_fields", []),
                        "description": src.get("description", ""),
                        "realtime": bool(src.get("realtime", False)),
                    } for src in event_sources]
                logger.debug(f"[PLUGINS] Registered {len(event_sources)} event source(s) for {name}")

            # Load daemon module (start is deferred until scheduler is ready)
            daemon_entry = daemon_config.get("entry")
            if daemon_entry:
                try:
                    # Both bands register as plugins.<name>.<entry>: the import
                    # name is band-neutral, and a cwd-derived name (what the
                    # system band used to get) would be a second module copy.
                    pkg_base = f"plugins.{name}"
                    daemon_mod = self._load_daemon_module(plugin_dir, daemon_entry, pkg_base)
                    if daemon_mod and hasattr(daemon_mod, "start"):
                        info["daemon_module"] = daemon_mod
                        if self._scheduler:
                            # Scheduler already set — start immediately
                            settings = self.get_plugin_settings(name)
                            daemon_mod.start(self, settings)
                            info["daemon_started"] = True
                            logger.info(f"[PLUGINS] Started daemon thread for {name}")
                        else:
                            logger.info(f"[PLUGINS] Daemon for {name} deferred until scheduler ready")
                except ModuleNotFoundError as e:
                    logger.error(f"[PLUGINS] Missing dependency for daemon '{name}': {e}")
                    err_data = {
                        "plugin": name, "error": f"Missing pip package: {e.name or e}",
                        "hint": f"pip install {e.name}" if e.name else str(e)
                    }
                    self._load_errors.append(err_data)
                    from core.event_bus import publish, Events
                    publish(Events.PLUGIN_LOAD_ERROR, err_data)
                except Exception as e:
                    logger.error(f"[PLUGINS] Failed to load daemon for {name}: {e}", exc_info=True)
                    err_data = {"plugin": name, "error": f"Daemon failed to load: {e}"}
                    self._load_errors.append(err_data)
                    try:
                        from core.event_bus import publish, Events
                        publish(Events.PLUGIN_LOAD_ERROR, err_data)
                    except Exception:
                        pass

        # Subprocess services (capabilities.services) — spawned via
        # ProcessManager with the plugin's own conda env python when the
        # manifest declares an environment (core/plugin_envs.py). Deferred
        # until boot completes, same as daemons.
        if capabilities.get("services"):
            if self._scheduler:
                self._start_services(name)
            else:
                logger.info(f"[PLUGINS] Services for {name} deferred until boot completes")

        info["loaded"] = True
        self._load_dependents(name)

        # Seed default settings if manifest declares schema and no settings file exists
        settings_schema = capabilities.get("settings", [])
        if settings_schema:
            settings_file = PROJECT_ROOT / "user" / "webui" / "plugins" / f"{name}.json"
            if not settings_file.exists():
                defaults = {f["key"]: f["default"] for f in settings_schema if "key" in f and "default" in f}
                if defaults:
                    settings_file.parent.mkdir(parents=True, exist_ok=True)
                    tmp = settings_file.with_suffix('.json.tmp')
                    tmp.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
                    replace_with_retry(tmp, settings_file)
                    logger.debug(f"[PLUGINS] Seeded default settings for {name}")

        logger.info(f"[PLUGINS] Loaded: {name} (priority {base_priority}, {band})")
        return True

    def _load_daemon_module(self, plugin_dir: Path, entry_path: str, pkg_base: str):
        """Load a daemon module from a plugin. Returns the module namespace."""
        full_path = plugin_dir / entry_path
        try:
            full_path.resolve().relative_to(plugin_dir.resolve())
        except ValueError:
            logger.error(f"[PLUGINS] Path traversal blocked in daemon entry: {entry_path}")
            return None
        if not full_path.exists():
            logger.warning(f"[PLUGINS] Daemon entry not found: {full_path}")
            return None

        try:
            import importlib.util
            import sys

            # Register under the plugin's import name (plugins.<name>.<entry>) so
            # "from plugins.telegram.daemon import X" finds this same module
            # instead of executing a second copy with separate state.
            entry_dotted = str(Path(entry_path).with_suffix("")).replace("/", ".").replace("\\", ".")
            pkg_name = f"{pkg_base}.{entry_dotted}"

            spec = importlib.util.spec_from_file_location(pkg_name, str(full_path))
            mod = importlib.util.module_from_spec(spec)
            sys.modules[pkg_name] = mod
            try:
                spec.loader.exec_module(mod)
            except BaseException:
                # A half-run module must not stay importable (a later import
                # would hide the real cause), and the raise goes to the
                # caller, whose branches tell the person - swallowed here, the
                # plugin showed "on" with no bot and no toast (hunt 21).
                sys.modules.pop(pkg_name, None)
                raise
            mod._pkg_name = pkg_name  # For sys.modules cleanup on unload
            return mod
        except Exception as e:
            logger.error(f"[PLUGINS] Failed to load daemon module {full_path}: {e}", exc_info=True)
            raise

    def _load_dependents(self, host: str):
        """Retry add-ons that failed earlier for want of `host` (toggle-on lane).
        Boot never sets missing_plugins before an attempt, so this is a no-op
        during scan() — no double registration."""
        for dep, dinfo in list(self._plugins.items()):
            if (dinfo.get("enabled") and not dinfo.get("loaded")
                    and host in (dinfo.get("missing_plugins") or [])):
                logger.info(f"[PLUGINS] {host} loaded — retrying {dep}")
                try:
                    self._load_plugin(dep)
                except Exception as e:
                    logger.error(f"[PLUGINS] {dep}: retry after {host} loaded failed: {e}")

    def _load_handler(self, plugin_dir: Path, handler_path: str, hook_name: str, ns_cache: dict = None):
        """Import a Python handler from a plugin directory.

        Args:
            plugin_dir: Plugin root (e.g., plugins/stop/)
            handler_path: Relative path (e.g., "hooks/stop.py")
            hook_name: The hook this handler is for (used as function name to look up)
            ns_cache: Optional dict to cache namespaces per file path (for shared state)

        Returns:
            Callable or None
        """
        if not handler_path:
            return None

        full_path = plugin_dir / handler_path
        try:
            full_path.resolve().relative_to(plugin_dir.resolve())
        except ValueError:
            logger.error(f"[PLUGINS] Path traversal blocked in handler: {handler_path}")
            return None
        if not full_path.exists():
            logger.warning(f"[PLUGINS] Handler not found: {full_path}")
            return None

        try:
            # One namespace per file: handlers from the same file share module-level state
            namespace = ns_cache.get(handler_path) if ns_cache is not None else None
            if namespace is None:
                source = full_path.read_text(encoding="utf-8-sig")
                namespace = {"__file__": str(full_path), "__name__": f"plugin_{plugin_dir.name}_{full_path.stem}"}
                exec(compile(source, str(full_path), "exec"), namespace)
                if ns_cache is not None:
                    ns_cache[handler_path] = namespace

            # Look for a function matching the hook name (e.g., pre_chat, prompt_inject)
            handler = namespace.get(hook_name)
            if handler and callable(handler):
                return handler

            # Fallback: look for a generic 'handle' function
            handler = namespace.get("handle")
            if handler and callable(handler):
                return handler

            logger.warning(f"[PLUGINS] No '{hook_name}' or 'handle' function in {full_path}")
            return None

        except Exception as e:
            logger.error(f"[PLUGINS] Failed to load handler {full_path}: {e}", exc_info=True)
            return None

    def _get_provider_registry(self, system_name: str):
        """Get the provider registry for a system (tts, stt, embedding, llm)."""
        try:
            if system_name == 'tts':
                from core.tts.providers import tts_registry
                return tts_registry
            elif system_name == 'stt':
                from core.stt.providers import stt_registry
                return stt_registry
            elif system_name == 'embedding':
                from core.embeddings import embedding_registry
                return embedding_registry
            elif system_name == 'llm':
                from core.chat.llm_providers import provider_registry
                return provider_registry
        except ImportError as e:
            logger.error(f"[PLUGINS] Failed to import {system_name} provider registry: {e}")
        return None

    def unload_plugin(self, name: str):
        """Unload a plugin — deregister all hooks, tools, routes, providers, schedule tasks, event sources, scopes, and dashboard widgets."""
        # User turned it off / it's going away — its load errors are moot
        # (and would otherwise toast forever now that the list is
        # non-destructive). (wave-3 A1)
        self._load_errors[:] = [e for e in self._load_errors
                                if e.get("plugin") != name]
        # Device drivers let go FIRST, while the plugin is still whole: a
        # driver that started something (a synth) ends it here.
        if self._plugins.get(name, {}).get("registered_device_drivers"):
            try:
                from core.devices import presence as _presence
                _presence.release(name)
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: device presence release failed: {e}")
        quiet = [n for n, i in self._plugins.items() if i.get("loaded")
                 and name in ((i.get("manifest") or {}).get("requires_plugins") or [])]
        if quiet:
            logger.info(f"[PLUGINS] {name} unloading — {quiet} stay loaded; "
                        f"their {name} hooks go quiet until it is back")
        hook_runner.unregister_plugin(name)
        from core import commands
        commands.unregister_plugin(name)
        if self._function_manager:
            self._function_manager.unregister_plugin_tools(name)
        self._unregister_routes(name)
        self._unregister_sockets(name)
        self._remove_pkg_alias(name, self._plugins.get(name, {}))

        # Unregister dashboard widgets contributed by this plugin.
        # Refuse to touch the 'core' namespace — that's where built-ins live;
        # blasting it would wipe System/Updates/Backups/Maintenance/Spotlight.
        try:
            from core.dashboard_widgets import unregister_plugin_widgets
            if name != "core":
                unregister_plugin_widgets(name)
        except Exception as e:
            logger.warning(f"[PLUGINS] {name}: failed to unregister widgets: {e}")

        # Direct-host providers (net facade): a not-loaded plugin must not
        # keep steering global proxy policy from a dead closure — same
        # rationale as the contacts/audit legs above. 2026-09-01.
        try:
            from core.socks_proxy import unregister_direct_hosts as _unreg_dh
            _unreg_dh(name)
        except Exception:
            pass

        # Unregister scopes this plugin contributed so a later manifest edit
        # with a different default takes effect on re-register instead of
        # hitting register_plugin_scope's idempotent early-return.
        try:
            info_for_scopes = self._plugins.get(name, {})
            scope_defs = info_for_scopes.get("manifest", {}).get("capabilities", {}).get("scopes", [])
            if scope_defs:
                from core.chat.function_manager import unregister_plugin_scope
                for sd in scope_defs:
                    key = sd.get("key")
                    if key:
                        unregister_plugin_scope(key, plugin_name=name)
        except Exception as e:
            logger.warning(f"[PLUGINS] {name}: failed to unregister scopes: {e}")

        # Unregister any contacts provider this plugin installed
        try:
            from core.contacts import unregister_provider as _unreg_contacts
            _unreg_contacts(name)
        except Exception:
            pass

        # Unregister any change-audit sink this plugin installed (same
        # unwind rationale as contacts: tool files EXEC'd at load, their
        # module-level registrations must not outlive the plugin)
        try:
            from core.audit import unregister_sink as _unreg_audit
            _unreg_audit(name)
        except Exception:
            pass

        # Unregister providers — reset active setting if it pointed to this plugin
        info = self._plugins.get(name, {})
        for system_name, prov_key in info.get("registered_providers", []):
            registry = self._get_provider_registry(system_name)
            if registry:
                if registry.get_active_key() == prov_key:
                    # Wrapped like every sibling leg: this used to import a
                    # name that doesn't exist (`settings_manager`) and blow
                    # the whole unload half-way whenever the disabled plugin
                    # provided the ACTIVE provider (broadsword hunt H10).
                    try:
                        from core.settings_manager import settings
                        settings.set(registry.setting_key, 'none', persist=True)
                        logger.info(f"[PLUGINS] Reset {registry.setting_key} to 'none' (was '{prov_key}' from disabled plugin)")
                    except Exception as e:
                        logger.warning(f"[PLUGINS] {name}: failed to reset {registry.setting_key}: {e}")
                registry.unregister_plugin(name)

        # Unregister memory layers (registered layers go dark in the memory
        # plugin — data survives, reads exclude it until re-enable)
        if info.get("registered_memory_layers"):
            try:
                from core.memory_layers import unregister_plugin as _unreg_layers
                _unreg_layers(name)
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: failed to unregister memory layers: {e}")

        # Unregister games (they go dark in the host; plugin-owned state and
        # saves survive until re-enable)
        if info.get("registered_games"):
            try:
                from core.games_registry import unregister_plugin as _unreg_games
                _unreg_games(name)
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: failed to unregister games: {e}")

        # Unregister device drivers (their devices go dark in the engine; the
        # device rows and secrets survive until re-enable)
        if info.get("registered_device_drivers"):
            try:
                from core.devices.registry import unregister_plugin as _unreg_drivers
                _unreg_drivers(name)
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: failed to unregister device drivers: {e}")

        # Unregister agent kinds (their agents' rows survive; a running agent
        # keeps its already-imported class and finishes on its own - Krem's
        # 2026-10-06 call: coding sessions are not killed by a plugin reload)
        if info.get("registered_agent_kinds"):
            try:
                from core.agents.registry import unregister_plugin as _unreg_kinds
                _unreg_kinds(name)
                from core.agents import engine as _agent_engine
                _agent_engine.retell()
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: failed to unregister agent kinds: {e}")

        # Unregister prompt pack (pack prompts go dark; if one was the active
        # prompt and no user entry shadows it, the registry hands off to
        # default loudly)
        if info.get("registered_prompt_pack"):
            try:
                from core import prompt_packs
                prompt_packs.unregister_plugin(name)
            except Exception as e:
                logger.warning(f"[PLUGINS] {name}: failed to unregister prompt pack: {e}")

        # Remove plugin schedule tasks and event sources
        # Snapshot daemon_mod under lock, then stop OUTSIDE lock to avoid
        # ABBA deadlock: _lock → _lifecycle_lock vs _lifecycle_lock → _lock
        daemon_mod = None
        with self._lock:
            if self._scheduler and name in self._plugins:
                for tid in self._plugins[name].get("schedule_task_ids", []):
                    if not tid:
                        continue  # None placeholder from a failed registration
                    try:
                        self._scheduler.delete_task(tid)
                    except Exception as e:
                        logger.warning(f"[PLUGINS] Failed to delete schedule task {tid}: {e}")
                self._plugins[name].pop("schedule_task_ids", None)
            self._event_sources.pop(name, None)
            if name in self._plugins:
                daemon_mod = self._plugins[name].get("daemon_module")
            if not (daemon_mod and hasattr(daemon_mod, "stop")):
                self._reply_handlers.pop(name, None)

        # Stop daemon outside _lock (daemon.stop() acquires _lifecycle_lock)
        if daemon_mod and hasattr(daemon_mod, "stop"):
            try:
                daemon_mod.stop()
                logger.info(f"[PLUGINS] Stopped daemon for {name}")
            except Exception as e:
                logger.warning(f"[PLUGINS] Failed to stop daemon for {name}: {e}")
            # Reply handler goes AFTER the daemon is down (row 85): popping it
            # first left a window where an inbound event ran the LLM and the
            # scheduler dropped the answer (reply_callback=None, no log).
            with self._lock:
                self._reply_handlers.pop(name, None)
            # Clean sys.modules so file handles are released (needed for Windows rmtree)
            pkg = getattr(daemon_mod, "_pkg_name", None)
            if pkg:
                import sys
                sys.modules.pop(pkg, None)

        # Stop subprocess services (no core locks held by these)
        self._stop_services(name)

        # Evict plugin's lib/ modules from sys.modules so the next load picks
        # up edited code instead of stale cache. Without this, hook files
        # that do `from lib import X` get the old X even after re-exec
        # because Python caches imports globally. 2026-05-13.
        import sys as _sys
        plugin_path = self._plugins.get(name, {}).get("path")
        if plugin_path:
            # With the separator: user/plugins/foo must not evict foo-bar's modules (hunt 21)
            plugin_path_str = str(plugin_path).rstrip("/\\") + os.sep
            evict = [
                mod_name for mod_name, mod in list(_sys.modules.items())
                if getattr(mod, "__file__", None)
                and str(mod.__file__).startswith(plugin_path_str)
            ]
            for mod_name in evict:
                _sys.modules.pop(mod_name, None)
            if evict:
                logger.info(f"[PLUGINS] Evicted {len(evict)} cached module(s) for {name}: {evict}")

        # Finalize state under lock
        with self._lock:
            if name in self._plugins:
                self._plugins[name].pop("daemon_module", None)
                self._plugins[name]["loaded"] = False
        logger.info(f"[PLUGINS] Unloaded: {name}")

    def enforce_unsigned_policy(self) -> list:
        """Unload and disable any enabled unsigned plugins. Returns list of names affected."""
        affected = []
        with self._lock:
            candidates = [
                (name, info) for name, info in self._plugins.items()
                if info.get("enabled") and not info.get("verified")
                and info.get("verify_msg") == "unsigned"
            ]
        for name, info in candidates:
            if info.get("loaded"):
                self.unload_plugin(name)
            with self._lock:
                info["enabled"] = False
            affected.append(name)
            logger.info(f"[PLUGINS] Unsigned policy: disabled '{name}'")

        # Remove from enabled list on disk
        if affected:
            self._remove_from_enabled_list(affected)

        return affected

    def _remove_from_enabled_list(self, names: list):
        """Remove plugin names from the persisted enabled list."""
        if not USER_PLUGINS_JSON.exists():
            return
        try:
            with PLUGINS_JSON_LOCK:
                data = json.loads(USER_PLUGINS_JSON.read_text(encoding="utf-8-sig"))
                enabled = data.get("enabled", [])
                data["enabled"] = [n for n in enabled if n not in names]
                tmp_path = USER_PLUGINS_JSON.with_suffix('.tmp')
                tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
                replace_with_retry(tmp_path, USER_PLUGINS_JSON)
        except Exception as e:
            logger.warning(f"[PLUGINS] Failed to update enabled list: {e}")

    def _get_reload_lock(self, name: str) -> threading.Lock:
        with self._reload_locks_lock:
            if name not in self._reload_locks:
                self._reload_locks[name] = threading.Lock()
            return self._reload_locks[name]

    def refresh_from_disk(self, name: str):
        """The plugin's record brought up to date with its folder before any load
        that isn't boot's (a reload, a toggle on): the manifest re-read, so a route,
        setting or hook added while it was disabled comes up (the toggle loaded the
        boot-time copy and a new route answered 404, 2026-11-04); its mtime restamped,
        or rescan() re-queues a reload forever after any manifest edit (negspace N14,
        2026-08-31); and the signature checked again (files may have changed since
        the scan). Reading and hashing happen off self._lock: get_route_handler waits
        on it, and a verify hashes every file of the plugin."""
        with self._lock:
            info = self._plugins.get(name)
            plugin_path = Path(info["path"]) if info else None
        if plugin_path is None:
            return
        manifest = mtime = None
        manifest_path = plugin_path / "plugin.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
                mtime = manifest_path.stat().st_mtime
            except Exception as e:
                logger.warning(f"[PLUGINS] Failed to re-read manifest for {name}: {e}")
        verified, verify_msg, verify_meta = verify_plugin(plugin_path)
        with self._lock:
            info = self._plugins.get(name)
            if not info:
                return
            if manifest is not None:
                info["manifest"], info["_manifest_mtime"] = manifest, mtime
            info.update(verified=verified, verify_msg=verify_msg,
                        verify_tier=verify_meta.get("tier", "unsigned"), verified_author=verify_meta.get("author"))

    def reload_plugin(self, name: str):
        """Unload and reload a plugin. Safe — if reload fails, plugin stays unloaded.

        Re-reads manifest from disk so code/settings changes take effect.
        Re-verifies signature to catch tampering since initial scan.
        Also re-enables plugin tools in the active toolset.
        Per-plugin lock prevents concurrent reload/toggle races.
        """
        with self._get_reload_lock(name):
            self.unload_plugin(name)
            with self._lock:
                should_load = name in self._plugins and self._plugins[name]["enabled"]
            self.refresh_from_disk(name)
            if should_load:
                try:
                    if not self._load_plugin(name):
                        # Signature block / load refusal: the old flow still
                        # logged "Reloaded" and left the UI toggle ON while
                        # every tool, hook and route was gone — the exact
                        # edit-without-resign dev-watcher trap.
                        logger.error(f"[PLUGINS] Reload BLOCKED for {name} — "
                                     f"plugin did not load (unsigned/tampered or "
                                     f"load failure); its tools, hooks and routes "
                                     f"are now OFFLINE until a successful reload")
                        from core.event_bus import publish, Events
                        publish(Events.PLUGIN_LOAD_ERROR, {
                            "plugin": name,
                            "error": "Reload blocked — signature or load failure",
                        })
                        return
                    # Re-enable tools in active toolset. Capture the toolset
                    # name UNDER the function_manager's tools lock so a
                    # concurrent toolset save (dev-watcher fires while user
                    # is mid-save) can't slip a stale name past us and
                    # silently clobber their save. 2026-05-16.
                    if self._function_manager:
                        fm = self._function_manager
                        with fm._tools_lock:
                            current = fm.current_toolset_name
                        if current:
                            # Carry the active chat's extra_toolsets through the
                            # resync — a by-name-only re-apply silently strips
                            # them from the enabled set (story-tools decay bug,
                            # 2026-08-03). Settings survive; runtime must too.
                            extras = None
                            try:
                                from core.api_fastapi import get_system
                                _sys = get_system()
                                if _sys is not None:
                                    extras = (_sys.llm_chat.session_manager.get_chat_settings()
                                              or {}).get('extra_toolsets') or None
                            except Exception:
                                pass
                            fm.update_enabled_functions([current], extra_toolsets=extras)
                    logger.info(f"[PLUGINS] Reloaded: {name}")
                    self._fire_plugins_ready("reload")
                    from core.event_bus import publish, Events
                    publish(Events.PLUGIN_RELOADED, {"plugin": name})
                except Exception as e:
                    logger.error(f"[PLUGINS] Reload failed for {name}: {e}", exc_info=True)
                    with self._lock:
                        if name in self._plugins:
                            self._plugins[name]["loaded"] = False

    def _owned_by_other(self, name: str, fname: str) -> bool:
        """Whether `fname` (in plugin_state) belongs to a LONGER plugin name that
        starts with `name`: purging `claude` swept `claude-code.json`, `google`
        took google-calendar's tokens, `mcp` the MCP client keys (hunt 21)."""
        others = set(self._plugins)
        for d in (SYSTEM_PLUGINS_DIR, USER_PLUGINS_DIR):
            try:
                others.update(p.name for p in d.iterdir() if p.is_dir())
            except OSError:
                pass
        stem = fname.split('.', 1)[0]
        for other in others:
            if other != name and len(other) > len(name) and other.startswith(name):
                if stem == other or stem.startswith(other + '-') or stem.startswith(other + '_'):
                    return True
        return False

    def purge_plugin_data(self, name: str) -> dict:
        """Delete everything a plugin stores ABOUT THE USER, leaving the
        plugin itself installed and configured: user/plugin_state/<name>.json,
        its `{name}-*` / `{name}_*` siblings, and every plugin_chat_data row
        it holds (sealed chats skipped, counted). The lever behind the card's
        "Purge data" and the uninstall path (2026-10-02: deleting the state
        file by hand never reached the chat rows). Returns counts."""
        out = {"rows": 0, "skipped_sealed": 0, "files": 0}
        try:
            from core.api_fastapi import get_system
            sm = get_system().llm_chat.session_manager
            r = sm.plugin_data_purge(name)
            out["rows"], out["skipped_sealed"] = r["deleted"], r["skipped_sealed"]
        except Exception as e:
            logger.warning(f"[PLUGINS] purge {name}: chat rows not reached: {e}")
        # A LIVE plugin holds the loader's PluginState singleton with the
        # whole file in memory — unlinking the file alone would let its next
        # save() rewrite everything back (the hand-delete trap). Empty the
        # instance first; it stays the shared singleton, now blank.
        with self._plugin_state_cache_lock:
            inst = self._plugin_state_cache.get(name)
        if inst is not None:
            try:
                inst.clear()
            except Exception as e:
                logger.warning(f"[PLUGINS] purge {name}: live state not cleared: {e}")
        state_file = PLUGIN_STATE_DIR / f"{name}.json"
        if state_file.exists():
            state_file.unlink(missing_ok=True)
            out["files"] += 1
        # Sweep sibling files/dirs in plugin_state whose name starts with
        # the plugin name (+ '-' or '_' separator). Catches conventions
        # like `{name}-logs/`, `{name}_sessions/`, `{name}-sessions.json`.
        # Without this, e.g. uninstalling telegram leaves
        # `telegram_sessions/` with live credentials on disk (H5).
        try:
            for prefix in (f"{name}-", f"{name}_"):
                for extra in PLUGIN_STATE_DIR.glob(f"{prefix}*"):
                    if self._owned_by_other(name, extra.name):
                        continue
                    try:
                        if extra.is_dir():
                            _rmtree_robust(extra)
                        else:
                            extra.unlink()
                        out["files"] += 1
                        logger.info(f"[PLUGINS] purge: removed sibling {extra.name}")
                    except Exception as e:
                        logger.warning(f"[PLUGINS] Could not remove {extra}: {e}")
        except Exception as e:
            logger.warning(f"[PLUGINS] purge sibling sweep failed: {e}")
        logger.info(f"[PLUGINS] purged data for {name}: {out}")
        return out

    def uninstall_plugin(self, name: str):
        """Fully remove a user plugin — unload, delete files, settings, and state."""
        info = self._plugins.get(name)
        if not info:
            raise ValueError(f"Unknown plugin: {name}")
        if info["band"] != "user":
            raise ValueError(f"Cannot uninstall system plugin: {name}")

        # Unload whatever it registered, "loaded" or not: a half-failed load
        # left live registrations on a plugin marked unloaded (hunt 21).
        self.unload_plugin(name)

        # Best-effort conda env cleanup in the background — multi-GB envs take
        # tens of seconds to remove and nothing else will ever reclaim them
        # once the plugin is gone (the UI's env strip goes with it).
        if info.get("manifest", {}).get("environment"):
            try:
                from core import plugin_envs
                threading.Thread(target=plugin_envs.remove_env, args=(name,),
                                 daemon=True, name=f"env-rm-{name}").start()
            except Exception:
                pass

        # Remove from internal dict
        with self._lock:
            self._plugins.pop(name, None)

        # A user copy SHADOWING a shipped plugin of the same name (a local
        # fork): its settings, state and chat rows are the shipped plugin's
        # too, so uninstall removes the copy and keeps all of them; the
        # shipped one takes its place (hunt 21: it wiped the shipped data).
        shadowed = (SYSTEM_PLUGINS_DIR / name).is_dir()

        # Remove from enabled list on disk
        if not shadowed:
            self._remove_from_enabled_list([name])

        # Delete plugin directory (use actual path, not name — they may differ)
        plugin_dir = info["path"] if info else USER_PLUGINS_DIR / name
        if plugin_dir.exists():
            _rmtree_robust(plugin_dir)

        # Retained previous version (update-revert copy) goes too — a later
        # revert must never resurrect an uninstalled plugin.
        prev_dir = PLUGIN_PREV_DIR / name
        if prev_dir.exists():
            _rmtree_robust(prev_dir)

        if shadowed:
            with self._plugin_state_cache_lock:
                self._plugin_state_cache.pop(name, None)
            logger.info(f"[PLUGINS] Uninstalled the user copy of {name}; the shipped {name} is back, its data kept")
            try:
                self.rescan()
            except Exception as e:
                logger.warning(f"[PLUGINS] rescan after removing {name}'s user copy: {e}")
            return

        # Delete settings
        settings_file = PROJECT_ROOT / "user" / "webui" / "plugins" / f"{name}.json"
        settings_file.unlink(missing_ok=True)

        # Delete state — the file, its siblings, AND the plugin's chat rows
        # (the purge lever; uninstall is its first caller).
        self.purge_plugin_data(name)

        # Manifest-declared extra cleanup paths — for plugins whose state
        # files/dirs DON'T follow the `{name}-*` convention (e.g. Google
        # Calendar's `gcal-csrf.json`). Paths are relative to the user/
        # sandbox and must ALSO be in a plugin-owned subtree — otherwise
        # a malicious or buggy manifest could declare
        # `cleanup_paths: ["chats", "memory.db", "credentials.json"]` and
        # have Sapphire delete all user data at uninstall. 2026-04-22
        # day-ruiner finding — pre-fix the guard only blocked `..` escape
        # out of user/, which left every file under user/ fair game.
        #
        # Allowed parents (plugin-namespaced only):
        #   user/plugin_state/                     (any file/dir prefixed with plugin name)
        #   user/webui/plugins/                    (settings files, already handled above anyway)
        #   user/plugins/<name>/                   (for user-plugins-dir files)
        #
        # Anything else (chats, memory.db, knowledge.db, credentials.json,
        # settings.json, logs, etc.) is refused with a loud WARN.
        try:
            manifest = info.get("manifest", {}) if info else {}
            extra_paths = manifest.get("capabilities", {}).get("cleanup_paths", [])
            user_root = (PROJECT_ROOT / "user").resolve()
            allowed_parents = [
                (user_root / "plugin_state").resolve(),
                (user_root / "webui" / "plugins").resolve(),
                (user_root / "plugins" / name).resolve(),
            ]
            for rel in extra_paths:
                if not isinstance(rel, str):
                    continue
                candidate = (user_root / rel).resolve()
                # 1. Must stay within user/ (existing guard, kept)
                try:
                    candidate.relative_to(user_root)
                except ValueError:
                    logger.warning(f"[PLUGINS] Uninstall cleanup refused — outside user/: {rel}")
                    continue
                # 2. Must be under a plugin-namespaced parent. Top-level
                # files/dirs in user/ (chats, credentials.json, etc) are
                # never OK from a plugin manifest.
                in_allowed_parent = False
                for parent in allowed_parents:
                    try:
                        candidate.relative_to(parent)
                        in_allowed_parent = True
                        break
                    except ValueError:
                        continue
                if not in_allowed_parent:
                    logger.warning(
                        f"[PLUGINS] Uninstall cleanup REFUSED — path not in a "
                        f"plugin-namespaced parent (user/plugin_state/, "
                        f"user/webui/plugins/, or user/plugins/{name}/): {rel}"
                    )
                    continue
                # 3. For plugin_state targets specifically, the filename
                # must start with the plugin name (or exactly match it) —
                # prevents 'foo' plugin from declaring cleanup of 'bar's
                # state. This covers the common case where the file is
                # directly under plugin_state/.
                plugin_state_root = allowed_parents[0]
                try:
                    rel_in_state = candidate.relative_to(plugin_state_root)
                    first_seg = rel_in_state.parts[0] if rel_in_state.parts else ""
                    if not (first_seg == name or first_seg.startswith(f"{name}-")
                            or first_seg.startswith(f"{name}_")) or self._owned_by_other(name, first_seg):
                        logger.warning(
                            f"[PLUGINS] Uninstall cleanup REFUSED — state path "
                            f"must start with plugin name '{name}': {rel}"
                        )
                        continue
                except ValueError:
                    pass  # Not under plugin_state — other allowed_parent matched
                if candidate.exists():
                    try:
                        if candidate.is_dir():
                            _rmtree_robust(candidate)
                        else:
                            candidate.unlink()
                        logger.info(f"[PLUGINS] Uninstall: removed declared {rel}")
                    except Exception as e:
                        logger.warning(f"[PLUGINS] Could not remove {candidate}: {e}")
        except Exception as e:
            logger.warning(f"[PLUGINS] Uninstall manifest-cleanup failed: {e}")

        # Evict cached PluginState so reinstall gets fresh instance
        with self._plugin_state_cache_lock:
            self._plugin_state_cache.pop(name, None)

        logger.info(f"[PLUGINS] Uninstalled: {name}")

    def _sched_task_def(self, name: str, sched: dict, plugin_dir) -> dict:
        """Build the scheduler task dict for one manifest schedule entry.

        Settings-linked fields: `time_setting` names a plugin-settings key
        holding "HH:MM" (built into a daily cron, user-local like all crons);
        `enabled_setting` names a boolean key. Both fall back to the static
        manifest values, so a bad setting never kills the task.
        """
        cron = sched.get("cron", "0 9 * * *")
        enabled = sched.get("enabled", True)
        if sched.get("time_setting") or sched.get("enabled_setting"):
            s = self.get_plugin_settings(name)
            if sched.get("time_setting"):
                raw = s.get(sched["time_setting"])
                parsed = _time_to_cron(raw, None)
                if parsed is None and raw not in (None, ""):
                    # The fallback is deliberate (a bad value never kills the task)
                    # but it used to be silent: the resync log printed the manifest
                    # cron as if the user had chosen it (row 81).
                    logger.warning(f"[PLUGINS] {name}: {sched['time_setting']}={raw!r} is not a valid "
                                   f"hour or HH:MM — schedule '{sched.get('name')}' keeps '{cron}'")
                cron = parsed or cron
            if sched.get("enabled_setting") and sched["enabled_setting"] in s:
                enabled = bool(s[sched["enabled_setting"]])
        return {
            "name": sched.get("name", f"{name} task"),
            "schedule": cron,
            "enabled": enabled,
            "chance": sched.get("chance", 100),
            "initial_message": sched.get("description", "Plugin scheduled task"),
            "source": f"plugin:{name}",
            "handler": sched.get("handler", ""),
            "plugin_dir": str(plugin_dir),
        }

    def resync_plugin_schedules(self, name: str):
        """Re-resolve settings-linked schedule fields after a plugin-settings
        save, updating the live scheduler tasks in place. Static entries (no
        time_setting/enabled_setting) are left alone. Called from the plugin
        settings PUT route; a restart reaches the same state via re-registration."""
        info = self._plugins.get(name)
        if not info or not self._scheduler or not info.get("loaded"):
            return
        schedules = info["manifest"].get("capabilities", {}).get("schedule", [])
        task_ids = info.get("schedule_task_ids") or []
        for sched, tid in zip(schedules, task_ids):
            if not tid or not (sched.get("time_setting") or sched.get("enabled_setting")):
                continue
            try:
                d = self._sched_task_def(name, sched, info["path"])
                self._scheduler.update_task(
                    tid, {"schedule": d["schedule"], "enabled": d["enabled"]})
                logger.info(f"[PLUGINS] Schedule '{d['name']}' resynced for {name}: "
                            f"'{d['schedule']}' enabled={d['enabled']}")
            except Exception as e:
                logger.warning(f"[PLUGINS] Schedule resync failed for {name}: {e}")

    def set_scheduler(self, scheduler):
        """Set the continuity scheduler for plugin schedule tasks.

        Also registers schedule tasks for plugins that were already loaded
        during scan() (before the scheduler existed).
        """
        self._scheduler = scheduler
        self._register_pending_schedules()
        self._start_pending_daemons()
        self._start_pending_services()
        self._reactivate_plugin_providers()

    def _register_pending_schedules(self):
        """Register schedule tasks for loaded plugins that missed registration during scan()."""
        if not self._scheduler:
            return
        with self._lock:
            snapshot = list(self._plugins.items())
        for name, info in snapshot:
            if not info.get("loaded"):
                continue
            if info.get("schedule_task_ids"):
                continue  # Already registered
            schedules = info["manifest"].get("capabilities", {}).get("schedule", [])
            if not schedules:
                continue
            plugin_dir = info["path"]
            task_ids = []
            for sched in schedules:
                try:
                    task = self._scheduler.create_task(
                        self._sched_task_def(name, sched, plugin_dir), trusted=True)
                    task_ids.append(task["id"])
                    logger.info(f"[PLUGINS] Deferred schedule registration: '{sched.get('name')}' for {name}")
                except Exception as e:
                    task_ids.append(None)
                    logger.error(f"[PLUGINS] Failed deferred schedule for {name}: {e}")
            info["schedule_task_ids"] = task_ids

    def _reactivate_plugin_providers(self):
        """Re-trigger provider switches for TTS/STT if they point to a now-available plugin provider.

        At boot, system init runs before plugins load. If TTS_PROVIDER=elevenlabs
        but the plugin hasn't registered yet, TTS falls back to null. After plugins
        load and set_scheduler is called (from start_server), we re-check and switch
        if the provider is now available.
        """
        try:
            import config as cfg
            from core.api_fastapi import get_system
            try:
                system = get_system()
            except Exception:
                logger.debug("[PLUGINS] Provider reactivation skipped: system not available yet")
                return

            # TTS
            tts_key = getattr(cfg, 'TTS_PROVIDER', 'none')
            if tts_key and tts_key != 'none':
                from core.tts.providers import tts_registry
                if tts_registry.has_key(tts_key):
                    current = getattr(system.tts, 'provider', None)
                    from core.tts.providers.null import NullTTSProvider
                    if isinstance(current, NullTTSProvider) or current is None:
                        logger.info(f"[PLUGINS] Re-activating TTS provider '{tts_key}' (was null at boot)")
                        system.switch_tts_provider(tts_key)
                        # switch_tts_provider now re-applies chat settings
                        # internally (Wolf-Claude finding 2026-04-21), so the
                        # persona voice survives plugin-driven late activation
                        # without a second call here.
                        # Notify frontend so voice dropdown and speed range refresh
                        try:
                            from core.event_bus import publish, Events
                            publish(Events.SETTINGS_CHANGED, {"key": "TTS_PROVIDER", "value": tts_key})
                        except Exception:
                            pass

            # STT
            stt_key = getattr(cfg, 'STT_PROVIDER', 'none')
            if stt_key and stt_key != 'none':
                from core.stt.providers import stt_registry
                if stt_registry.has_key(stt_key):
                    from core.stt.stt_null import NullWhisperClient
                    current = getattr(system, 'whisper_client', None)
                    if isinstance(current, NullWhisperClient) or current is None:
                        logger.info(f"[PLUGINS] Re-activating STT provider '{stt_key}' (was null at boot)")
                        system.switch_stt_provider(stt_key)

        except Exception as e:
            logger.debug(f"[PLUGINS] Provider reactivation skipped: {e}")

    def _start_pending_daemons(self):
        """Start daemon threads for plugins that were loaded before scheduler was ready."""
        with self._lock:
            snapshot = list(self._plugins.items())
        for name, info in snapshot:
            if not info.get("loaded") or not info.get("daemon_module"):
                continue
            if info.get("daemon_started"):
                continue
            daemon_mod = info["daemon_module"]
            try:
                settings = self.get_plugin_settings(name)
                daemon_mod.start(self, settings)
                info["daemon_started"] = True
                logger.info(f"[PLUGINS] Started deferred daemon for {name}")
            except Exception as e:
                logger.error(f"[PLUGINS] Failed to start deferred daemon for {name}: {e}", exc_info=True)
                # A daemon that failed to start used to leave the plugin "loaded
                # and on" with no bot behind it — error log only (row 75).
                err_data = {"plugin": name, "error": f"Daemon failed to start: {e}"}
                self._load_errors.append(err_data)
                try:
                    from core.event_bus import publish, Events
                    publish(Events.PLUGIN_LOAD_ERROR, err_data)
                except Exception:
                    pass

    # ── Plugin services (subprocess servers, optional per-plugin conda env) ──

    def _start_services(self, name: str):
        """Start declared subprocess services for a loaded plugin.

        If the manifest declares an environment, services only start when
        that env is built and matches the spec — otherwise they stay dormant
        and the UI offers a Build button (info['services_blocked'] carries why).
        """
        import sys
        info = self._plugins.get(name)
        if not info or info.get("service_managers"):
            return
        manifest = info["manifest"]
        services = manifest.get("capabilities", {}).get("services", [])
        if not services:
            return
        plugin_dir = info["path"]
        env_spec = manifest.get("environment")

        from core.process_manager import ProcessManager, kill_process_on_port
        python = sys.executable
        from core import plugin_envs
        if plugin_envs.platform_refusal(manifest):
            info["services_blocked"] = "unsupported"
            logger.info(f"[PLUGINS] {name}: services not started — {plugin_envs.platform_refusal(manifest)}")
            return
        if plugin_envs.client_mode(manifest, self.get_plugin_settings(name)):
            info["services_blocked"] = "client"
            logger.info(f"[PLUGINS] {name}: client only — its services run on another computer")
            return
        if env_spec:
            status = plugin_envs.env_status(name, env_spec)
            if status != "ready":
                info["services_blocked"] = status
                logger.warning(f"[PLUGINS] {name}: services not started — env {status}")
                return
            python = str(plugin_envs.env_python(name))

        managers = {}
        settings = self.get_plugin_settings(name)
        for svc in services:
            svc_name = svc.get("name", "service")
            if not svc.get("autostart", True):
                continue
            entry = svc.get("entry")
            if not entry:
                logger.warning(f"[PLUGINS] Service '{svc_name}' for {name} has no entry")
                continue
            full_path = plugin_dir / entry
            try:
                full_path.resolve().relative_to(plugin_dir.resolve())
            except ValueError:
                logger.error(f"[PLUGINS] Path traversal blocked in service entry: {entry}")
                continue
            if not full_path.exists():
                logger.warning(f"[PLUGINS] Service entry not found: {full_path}")
                continue

            port = None
            port_setting = svc.get("port_setting")
            if port_setting:
                port = settings.get(port_setting)
            port = port or svc.get("port")
            if port:
                try:
                    port = int(port)
                except (TypeError, ValueError):
                    logger.warning(f"[PLUGINS] Invalid service port {port!r} for '{name}' — service not started")
                    continue
                # Never kill/claim Sapphire's own ports — a typo'd plugin port
                # setting must not SIGTERM the web UI, TTS server, or proxy.
                import config
                core_ports = set()
                for k in ("WEB_UI_PORT", "TTS_SERVER_PORT", "SOCKS_PORT"):
                    try:
                        core_ports.add(int(getattr(config, k, 0) or 0))
                    except (TypeError, ValueError):
                        pass                       # a junk value (SOCKS fails closed on it) guards no port
                core_ports -= {0}
                if port in core_ports:
                    logger.error(f"[PLUGINS] Service port {port} for '{name}' is a Sapphire core port — service NOT started (fix the plugin's port setting)")
                    continue
                try:
                    kill_process_on_port(port, owner=str(PROJECT_ROOT))
                except Exception:
                    pass

            def _make_env(plugin=name, service_port=port):
                env = dict(os.environ)
                env["SAPPHIRE_PLUGIN"] = plugin
                env["SAPPHIRE_ROOT"] = str(PROJECT_ROOT)
                env.setdefault("PYTHONUTF8", "1")   # Windows: open() and the log file in UTF-8, not cp1252
                if service_port:
                    env["SAPPHIRE_SERVICE_PORT"] = str(service_port)
                try:
                    env["SAPPHIRE_PLUGIN_SETTINGS"] = json.dumps(self.get_plugin_settings(plugin))
                except Exception:
                    pass
                return env

            pm = ProcessManager(
                script_path=full_path,
                log_name=f"{name}-{svc_name}",
                base_dir=PROJECT_ROOT,
                env_callback=_make_env,
                python_exe=python,
            )
            if pm.start():
                if svc.get("restart", True):
                    pm.monitor_and_restart(check_interval=10)
                managers[svc_name] = pm
                port_note = f" (port {port})" if port else ""
                logger.info(f"[PLUGINS] Started service '{svc_name}' for {name}{port_note}")

        if managers:
            info["service_managers"] = managers
            info.pop("services_blocked", None)

    def _stop_services(self, name: str):
        """Stop all subprocess services for a plugin."""
        info = self._plugins.get(name)
        if not info:
            return
        managers = info.pop("service_managers", None) or {}
        for svc_name, pm in managers.items():
            try:
                pm.stop()
                logger.info(f"[PLUGINS] Stopped service '{svc_name}' for {name}")
            except Exception as e:
                logger.warning(f"[PLUGINS] Failed to stop service '{svc_name}' for {name}: {e}")

    def restart_services(self, name: str):
        """Stop then start a plugin's subprocess services: the door a plugin
        uses for its own (a fetch retried, a model changed). Blocks while they
        stop, so call it off the event loop."""
        self._stop_services(name)
        self._start_services(name)

    def sync_client_mode(self, name: str):
        """A settings save may have flipped client mode: stop the services it
        turned off, start the ones it turned back on. Blocks while they stop."""
        info = self._plugins.get(name)
        if not info or not info.get("loaded") or not self._scheduler:
            return
        from core import plugin_envs
        client = plugin_envs.client_mode(info["manifest"], self.get_plugin_settings(name))
        if client and info.get("service_managers"):
            self._stop_services(name)
            info["services_blocked"] = "client"
            logger.info(f"[PLUGINS] {name}: client only — services stopped")
        elif not client and info.get("services_blocked") == "client":
            info.pop("services_blocked", None)
            self._start_services(name)

    def _start_pending_services(self):
        """Start services for plugins loaded before boot completed (mirrors daemons)."""
        with self._lock:
            snapshot = list(self._plugins.keys())
        for name in snapshot:
            info = self._plugins.get(name)
            if not info or not info.get("loaded") or info.get("service_managers"):
                continue
            if not info["manifest"].get("capabilities", {}).get("services"):
                continue
            try:
                self._start_services(name)
            except Exception as e:
                logger.error(f"[PLUGINS] Failed to start deferred services for {name}: {e}", exc_info=True)

    def stop_all_services(self):
        """Stop all plugin service subprocesses. Called at shutdown alongside daemons."""
        with self._lock:
            names = [n for n, info in self._plugins.items() if info.get("service_managers")]
        for n in names:
            self._stop_services(n)

    def get_env_status(self, name: str) -> dict:
        """Env + services summary for the UI. required=False when the manifest
        declares no environment section."""
        info = self._plugins.get(name)
        if not info:
            return {"required": False}
        manifest = info.get("manifest", {})
        env_spec = manifest.get("environment")
        services = manifest.get("capabilities", {}).get("services", [])
        result = {"required": bool(env_spec), "has_services": bool(services)}
        if env_spec:
            from core import plugin_envs
            why = plugin_envs.platform_refusal(manifest)
            if why:
                result["state"] = "unsupported"
                result["why"] = why
            elif plugin_envs.client_mode(manifest, self.get_plugin_settings(name)):
                result["state"] = "client"
            else:
                result["state"] = plugin_envs.env_status(name, env_spec)
            client = env_spec.get("client")
            if isinstance(client, dict) and client.get("setting"):
                result["client"] = {k: str(client.get(k) or "") for k in ("setting", "label", "help")}
            result["env_name"] = plugin_envs.env_name(name)
            b = plugin_envs.build_state(name)
            if b:
                result["build"] = {"state": b.get("state"), "step": b.get("step"),
                                   "error": b.get("error")}
        if services:
            managers = info.get("service_managers") or {}
            result["services"] = [{
                "name": s.get("name", "service"),
                "running": bool(managers.get(s.get("name", "service"))
                                and managers[s.get("name", "service")].is_running()),
            } for s in services]
            if info.get("services_blocked"):
                result["services_blocked"] = info["services_blocked"]
        return result

    def get_env_python(self, name: str) -> str:
        """Interpreter for a plugin: its own env python if declared and built,
        else Sapphire's. Convenience for plugins running one-shot scripts."""
        import sys
        info = self._plugins.get(name)
        if info and info.get("manifest", {}).get("environment"):
            from core import plugin_envs
            p = plugin_envs.env_python(name)
            if p:
                return str(p)
        return sys.executable

    def rescan(self):
        """Scan for new plugins and clean up removed ones.

        Returns dict with 'added' and 'removed' plugin name lists.
        """
        enabled_list = self._get_enabled_list()
        disabled_list = self._get_disabled_list()
        new_found = []
        removed = []
        needs_reload = []

        # Collect all plugin names currently on disk
        on_disk = set()
        for directory, band in [(SYSTEM_PLUGINS_DIR, "system"), (USER_PLUGINS_DIR, "user")]:
            if not directory.exists():
                continue
            for child in sorted(directory.iterdir()):
                if not child.is_dir():
                    continue
                manifest_path = child / "plugin.json"
                if not manifest_path.exists():
                    continue
                try:
                    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
                except Exception as e:
                    # "Can't parse" is not "gone": the removal sweep below
                    # would otherwise classify it as removed-from-disk and
                    # unload a plugin whose manifest is mid-save/corrupt.
                    logger.warning(f"[PLUGINS] Rescan: unreadable plugin.json in "
                                   f"{child.name} — keeping current state: {e}")
                    with self._lock:
                        for known, info in self._plugins.items():
                            if info.get("path") == child:
                                on_disk.add(known)
                                break
                        else:
                            on_disk.add(child.name)
                    continue
                name = manifest.get("name", child.name)
                on_disk.add(name)

                with self._lock:
                    if name in self._plugins:
                        # Check if manifest changed on disk (mtime)
                        existing = self._plugins[name]
                        try:
                            disk_mtime = manifest_path.stat().st_mtime
                            cached_mtime = existing.get("_manifest_mtime", 0)
                            if disk_mtime > cached_mtime and existing.get("loaded"):
                                needs_reload.append(name)
                        except Exception:
                            pass
                        continue

                    if not self._validate_manifest(name, manifest):
                        continue

                    # Skip plugins hidden in managed mode
                    if manifest.get("managed_hide") and self._is_managed():
                        logger.debug(f"[PLUGINS] Rescan: skipping {name} (managed_hide)")
                        continue

                    verified, verify_msg, verify_meta = verify_plugin(child)
                    is_enabled = (name in enabled_list) or (
                        manifest.get("default_enabled", False) and name not in disabled_list
                    )

                    try:
                        mtime = manifest_path.stat().st_mtime
                    except Exception:
                        mtime = 0

                    self._plugins[name] = {
                        "manifest": manifest,
                        "path": child,
                        "enabled": is_enabled,
                        "band": band,
                        "loaded": False,
                        "verified": verified,
                        "verify_msg": verify_msg,
                        "verify_tier": verify_meta.get("tier", "unsigned"),
                        "verified_author": verify_meta.get("author"),
                        "_manifest_mtime": mtime,
                    }
                new_found.append(name)

                if is_enabled:
                    if self._load_plugin(name):
                        self._fire_plugins_ready("rescan")
                        logger.info(f"[PLUGINS] Rescan: loaded new plugin '{name}'")
                    else:
                        # Failed verification — mark in-memory False but preserve
                        # enabled list on disk so user intent survives.
                        self._plugins[name]["enabled"] = False
                        logger.warning(f"[PLUGINS] Rescan: plugin '{name}' enabled but blocked (retry next restart)")

        # Reload plugins whose manifests changed on disk (outside lock to avoid deadlock)
        for rname in needs_reload:
            logger.info(f"[PLUGINS] Rescan: '{rname}' changed on disk, reloading")
            self.reload_plugin(rname)
            new_found.append(f"{rname} (reloaded)")

        # Detect removed plugins (folder deleted while running)
        with self._lock:
            for name in list(self._plugins.keys()):
                if name not in on_disk:
                    removed.append(name)

        for name in removed:
            logger.info(f"[PLUGINS] Rescan: plugin '{name}' removed from disk, unloading")
            self.unload_plugin(name)
            with self._lock:
                self._plugins.pop(name, None)

        if new_found or removed:
            logger.info(f"[PLUGINS] Rescan: {len(new_found)} added, {len(removed)} removed")
        return {"added": new_found, "removed": removed}

    # ── Route helpers ──

    def _register_routes(self, name: str, plugin_dir: Path, routes: list):
        """Register HTTP route handlers declared in plugin manifest."""
        registered = []
        # Cache namespaces per file so multiple handlers from the same file share state
        ns_cache = {}
        if not isinstance(routes, list):
            logger.warning(f"[PLUGINS] {name}: capabilities.routes must be a list")
            return
        for route_def in routes:
            if not isinstance(route_def, dict) or not all(isinstance(route_def.get(k, ""), str)
                                                          for k in ("method", "path", "handler")):
                logger.warning(f"[PLUGINS] {name}: a route entry must be {{\"method\", \"path\", \"handler\"}} strings")
                continue
            method = route_def.get("method", "GET").upper()
            path = route_def.get("path", "")
            handler_ref = route_def.get("handler", "")

            if not path or not handler_ref:
                logger.warning(f"[PLUGINS] {name}: route missing path or handler")
                continue

            if method not in ("GET", "POST", "PUT", "DELETE"):
                logger.warning(f"[PLUGINS] {name}: unsupported route method '{method}'")
                continue

            # Parse handler reference: "routes/file.py:func_name"
            if ":" in handler_ref:
                file_path, func_name = handler_ref.rsplit(":", 1)
            else:
                file_path = handler_ref
                func_name = "handle"

            # Load from cached namespace if same file, otherwise exec fresh
            if file_path in ns_cache:
                ns = ns_cache[file_path]
                handler_func = ns.get(func_name)
                if not handler_func or not callable(handler_func):
                    logger.warning(f"[PLUGINS] {name}: no '{func_name}' in cached {file_path}")
                    continue
            else:
                handler_func = self._load_handler(plugin_dir, file_path, func_name, ns_cache=ns_cache)
                if not handler_func:
                    logger.warning(f"[PLUGINS] {name}: failed to load route handler '{handler_ref}'")
                    continue

            # Convert path pattern like "capture/{request_id}" to regex
            param_names = re.findall(r'\{(\w+)\}', path)
            regex_pattern = re.sub(r'\{(\w+)\}', r'(?P<\1>[^/]+)', path)
            compiled = re.compile(f'^{regex_pattern}$')

            # Route options the dispatcher reads (2026-10-10). `media`: a door
            # that hands file bytes to a <video>, <audio> or <img> — a seeking
            # player fires Range requests in bursts and a thumbnail grid is one
            # GET per tile, so a media GET is not metered like an API call.
            opts = {'media': bool(route_def.get('media'))}
            registered.append((method, compiled, param_names, handler_func, opts))
            logger.debug(f"[PLUGINS] Registered route: {method} /api/plugin/{name}/{path}"
                         f"{' (media)' if opts['media'] else ''}")

        if registered:
            with self._lock:
                self._routes[name] = registered

    def _unregister_routes(self, name: str):
        """Remove all route handlers for a plugin."""
        with self._lock:
            if name in self._routes:
                del self._routes[name]
                logger.debug(f"[PLUGINS] Unregistered routes for: {name}")

    def _register_sockets(self, name: str, plugin_dir: Path, sockets: list):
        """Register WebSocket handlers declared in the manifest:
        [{"path": "view", "handler": "routes/view.py:view"}] -> /ws/plugin/<name>/view.
        A handler is `async def view(websocket, settings)`; core has already
        checked the login and the Origin and accepted the socket."""
        found = {}
        ns_cache = {}
        if not isinstance(sockets, list):
            logger.warning(f"[PLUGINS] {name}: capabilities.sockets must be a list")
            return
        for sock in sockets:
            if not isinstance(sock, dict) or not isinstance(sock.get("handler", ""), str):
                logger.warning(f"[PLUGINS] {name}: a socket entry must be {{\"path\": ..., \"handler\": \"file.py:fn\"}}")
                continue
            path = str(sock.get("path", "")).strip("/")
            ref = sock.get("handler", "")
            if not path or not ref:
                logger.warning(f"[PLUGINS] {name}: socket missing path or handler")
                continue
            file_path, _, func_name = ref.rpartition(":") if ":" in ref else (ref, "", "handle")
            handler = self._load_handler(plugin_dir, file_path, func_name, ns_cache=ns_cache)
            if not handler:
                logger.warning(f"[PLUGINS] {name}: failed to load socket handler '{ref}'")
                continue
            if not inspect.iscoroutinefunction(handler):
                logger.warning(f"[PLUGINS] {name}: socket handler '{ref}' must be async def")
                continue
            found[path] = handler
            logger.debug(f"[PLUGINS] Registered socket: /ws/plugin/{name}/{path}")
        if found:
            with self._lock:
                self._sockets[name] = found

    def _unregister_sockets(self, name: str):
        """Drop a plugin's socket handlers and end its live sockets: a
        disabled or reloading plugin never keeps old code on an open socket."""
        with self._lock:
            self._sockets.pop(name, None)
            live = self._live_sockets.pop(name, {})
        for task, loop in live.items():
            try:
                loop.call_soon_threadsafe(task.cancel)
            except RuntimeError:
                pass                                   # that loop is already gone
        if live:
            logger.info(f"[PLUGINS] {name}: closed {len(live)} open socket(s)")

    def get_socket_handler(self, plugin_name: str, path: str) -> Optional[Callable]:
        with self._lock:
            return (self._sockets.get(plugin_name) or {}).get(path.strip("/"))

    def socket_opened(self, plugin_name: str, task, loop, cap: int) -> bool:
        """Count a live socket's handler task in; False when the plugin is at its cap."""
        with self._lock:
            if plugin_name not in self._sockets:
                return False
            live = self._live_sockets.setdefault(plugin_name, {})
            if len(live) >= cap:
                return False
            live[task] = loop
            return True

    def socket_closed(self, plugin_name: str, task):
        with self._lock:
            (self._live_sockets.get(plugin_name) or {}).pop(task, None)

    def get_route_handler(self, plugin_name: str, method: str, path: str) -> Optional[Tuple[Callable, dict, dict]]:
        """Find a matching route handler. Returns (handler_func, path_params,
        opts) or None; opts = the manifest's route options ({'media': bool})."""
        with self._lock:
            routes = self._routes.get(plugin_name)
        if not routes:
            return None

        method = method.upper()
        for route_method, pattern, param_names, handler, opts in routes:
            if route_method != method:
                continue
            match = pattern.match(path)
            if match:
                return handler, match.groupdict(), opts
        return None

    # ── Event source helpers ──

    def get_event_sources(self) -> List[dict]:
        """Get all registered daemon event sources across loaded plugins."""
        sources = []
        with self._lock:
            for plugin_sources in self._event_sources.values():
                sources.extend(plugin_sources)
        return sources

    def get_enabled_daemon_task(self, source_name: str, account: str = None,
                                payload: dict = None) -> Optional[dict]:
        """Return the enabled daemon task for a source (optionally matching an
        account), or None. Lets a realtime daemon read its gate task's AI config
        (chat_target, persona, toolset) to configure a live session.

        With `payload` (e.g. {"caller": "+1555..."}), rules are selected
        most-specific-wins: a rule whose filter MATCHES the payload beats a rule
        with no filter (the catch-all); a rule whose filter FAILS is excluded
        entirely. Two rules on one number = "just me" + "everyone else". No
        match at all -> None (the daemon should decline the session)."""
        if not self._scheduler:
            return None
        from core.continuity.scheduler import live_filter, task_in_active_hours
        catch_all = None
        for task in self._scheduler.find_tasks_by_event(source_name):
            tc = task.get("trigger_config", {})
            if account is not None and str(tc.get("account") or "") != str(account):
                continue
            if not task_in_active_hours(task):
                continue                                     # outside its hours it doesn't answer (as every event gate)
            if payload is None:
                return task                                  # legacy: first match
            task_filter = live_filter(task)
            if not task_filter:
                catch_all = catch_all or task
            elif self._scheduler.filter_matches(task_filter, payload,
                                                task.get("name", "")):
                return task                                  # specific match wins
        return catch_all

    def _is_realtime_source(self, source_name: str) -> bool:
        """True if the named event source declared `realtime: true` (a live-handled
        gate — its tasks must never be fired as one-shot event tasks)."""
        with self._lock:
            for plugin_sources in self._event_sources.values():
                for src in plugin_sources:
                    if src.get("name") == source_name:
                        return bool(src.get("realtime"))
        return False

    def register_reply_handler(self, plugin_name: str, handler: Callable):
        """Register a reply handler for a daemon plugin.

        The handler is called when an event-triggered task completes:
            handler(task: dict, event_data: dict, response_text: str)
        """
        with self._lock:
            self._reply_handlers[plugin_name] = handler
        logger.debug(f"[PLUGINS] Registered reply handler for {plugin_name}")

    def unregister_reply_handler(self, plugin_name: str):
        """Drop a daemon's reply handler (its stop() calls this — a handler bound
        to a dead runtime consumed events into 'runtime unavailable', row 85)."""
        with self._lock:
            self._reply_handlers.pop(plugin_name, None)

    def _source_plugin(self, source_name: str) -> Optional[str]:
        """Which plugin declared this event source (None = nobody)."""
        with self._lock:
            for plugin_name, sources in self._event_sources.items():
                if any(src["name"] == source_name for src in sources):
                    return plugin_name
        return None

    def _get_reply_handler(self, source_name: str) -> Optional[Callable]:
        """Find the reply handler for an event source by looking up its plugin."""
        owner = self._source_plugin(source_name)
        with self._lock:
            return self._reply_handlers.get(owner) if owner else None

    def tasks_for_source(self, source_name: str) -> List[dict]:
        """Enabled daemon tasks listening on `source_name`, trigger_config
        included — a daemon's own clock reads its task_fields (greeting_time,
        goodnight_time…) from these. Empty before the scheduler exists."""
        if not self._scheduler:
            return []
        return self._scheduler.find_tasks_by_event(source_name)

    def tasks_matching(self, source_name: str, event_obj: dict) -> List[dict]:
        """The enabled tasks on `source_name` that would answer `event_obj`
        (account, active hours, filter) — what emit_daemon_event is about to
        fire, as a read-only question. Empty before the scheduler exists."""
        if not self._scheduler:
            return []
        from core.continuity.scheduler import tasks_matching
        return tasks_matching(self._scheduler.find_tasks_by_event(source_name), event_obj)

    def fire_task(self, task_id: str, payload, *, plugin: str = None) -> dict:
        """A daemon fires ONE named task it owns (S0 doors, 2026-09-21).

        emit_daemon_event fans a payload out to every listener of a source;
        this targets a task — the Discord daemon's clock fires the greetings
        task whose own greeting_time just passed, and nobody else's. The
        task's source must be one this plugin declared (when `plugin` is
        given); the answer routes to that plugin's reply handler. Scheduler
        rules still apply: enabled, account match. The task's MESSAGE filter
        does not — the clock fires a task, not a message. Realtime gates
        refuse (they are switches, not tasks)."""
        if not self._scheduler:
            return {"success": False, "error": "no scheduler"}
        task = self._scheduler.get_task(task_id)
        if not task:
            return {"success": False, "error": "Task not found"}
        source = str((task.get("trigger_config") or {}).get("source") or "")
        owner = self._source_plugin(source)
        if owner is None or (plugin and owner != plugin):
            return {"success": False,
                    "error": f"source '{source}' is not owned by {plugin or 'any plugin'}"}
        if self._is_realtime_source(source):
            return {"success": False, "error": f"'{source}' is a realtime gate, not a fireable task"}
        data = payload if isinstance(payload, str) else json.dumps(payload)
        with self._lock:
            handler = self._reply_handlers.get(owner)
        return self._scheduler.fire_event_task(task_id, data, reply_callback=handler, skip_filter=True)

    def emit_daemon_event(self, source_name: str, event_data: str):
        """Emit an event from a daemon plugin, triggering matching tasks.

        Args:
            source_name: The event source name (matches trigger_config.source)
            event_data: String payload to pass to the task
        """
        if not self._scheduler:
            logger.warning(f"[PLUGINS] Cannot emit event '{source_name}': no scheduler")
            return

        # Realtime sources (e.g. live voice) are GATES, not fire-a-task events —
        # their tasks are read via active_daemon_accounts to gate a live handler.
        # Never run a one-shot task for them (would double-handle atop the live session).
        if self._is_realtime_source(source_name):
            logger.debug(f"[PLUGINS] '{source_name}' is realtime — gate only, not firing tasks")
            return

        tasks = self._scheduler.find_tasks_by_event(source_name)
        if not tasks:
            logger.debug(f"[PLUGINS] No tasks listening for event source '{source_name}'")
            return

        reply_handler = self._get_reply_handler(source_name)
        any_accepted = False
        for task in tasks:
            result = self._scheduler.fire_event_task(task["id"], event_data, reply_callback=reply_handler)
            # Accepted = the task took it (ran or queued). Before 2026-09-17 this was a
            # negative allowlist — task-disabled / not-found / wrong-type / unparseable /
            # queue-full all reported "accepted", so a plugin recorded its cooldown and
            # posted nothing (Discord hunt 2.13.0, rows 3 + 52).
            if result.get("success", False):
                any_accepted = True
        # The log row in the notification center (core/notify.py): the source
        # and the count, never the payload (a daemon's payload is a message).
        try:
            from core.notify import notify as _notify
            _notify(f"Daemon event: {source_name}", 'info',
                    f"{len(tasks)} task(s) listening, {'accepted' if any_accepted else 'not accepted'}",
                    source=source_name)
        except Exception:
            pass
        return any_accepted

    def active_daemon_accounts(self, source_name: str) -> set:
        """Return set of account names with enabled daemon tasks for a given event source."""
        if not self._scheduler:
            return set()
        return self._scheduler.active_daemon_accounts(source_name)

    # ── Settings helpers ──

    def get_plugin_settings(self, name: str) -> dict:
        """Read plugin settings, merged with manifest defaults."""
        defaults = {}
        info = self._plugins.get(name)
        if info:
            schema = info["manifest"].get("capabilities", {}).get("settings", [])
            defaults = {f["key"]: f["default"] for f in schema if "key" in f and "default" in f}
        path = PROJECT_ROOT / "user" / "webui" / "plugins" / f"{name}.json"
        stored = {}
        if path.exists():
            try:
                stored = json.loads(path.read_text(encoding="utf-8"))
            except Exception as e:
                # Shout — a corrupt settings file silently reverting EVERY
                # setting of this plugin to manifest defaults is invisible
                # otherwise (daemon quietly switches models, gates flip, etc.)
                # Once per file: this is a hot path (re-read per resolve).
                warned = getattr(self, "_warned_corrupt_settings", None)
                if warned is None:
                    warned = self._warned_corrupt_settings = set()
                if name not in warned:
                    warned.add(name)
                    logger.error(f"[PLUGINS] Corrupt settings file {path} — "
                                 f"'{name}' is running on manifest DEFAULTS: {e}")
        return {**defaults, **stored}

    # ── Query methods ──

    def get_plugin_names(self) -> List[str]:
        """All discovered plugin names."""
        return list(self._plugins.keys())

    def get_enabled_plugins(self) -> List[str]:
        """Names of enabled plugins."""
        return [n for n, info in self._plugins.items() if info["enabled"]]

    def get_load_errors(self) -> list:
        """Get accumulated plugin load errors (for startup toast display).

        NON-destructive (negspace N7/P1#12, 2026-08-31): any /api/init — a
        background tab, an SSE-reconnect refresh — used to DRAIN the list, so
        the only report of a failed plugin could be swallowed by a tab nobody
        was looking at. The frontend dedupes its toasts per browser session;
        the list is bounded here instead of cleared."""
        if len(self._load_errors) > 100:
            del self._load_errors[:-50]
        return list(self._load_errors)

    def get_loaded_plugins(self) -> List[str]:
        """Names of currently loaded plugins."""
        return [n for n, info in self._plugins.items() if info.get("loaded")]

    def get_plugin_info(self, name: str) -> Optional[dict]:
        """Get plugin info dict (manifest, path, enabled, band)."""
        info = self._plugins.get(name)
        if not info:
            return None
        return {
            "name": name,
            "manifest": info["manifest"],
            "path": str(info["path"]),
            "enabled": info["enabled"],
            "band": info["band"],
            "loaded": info.get("loaded", False),
            "verified": info.get("verified"),
            "verify_msg": info.get("verify_msg"),
            "verify_tier": info.get("verify_tier", "unsigned"),
            "verified_author": info.get("verified_author"),
            "missing_deps": info.get("missing_deps", []),
            "missing_plugins": info.get("missing_plugins", []),
            "env": self.get_env_status(name),
        }

    def get_all_plugin_info(self) -> List[dict]:
        """Get info for all discovered plugins."""
        # list() snapshot: a concurrent rescan() pops from _plugins and an
        # unsnapshotted iteration raises RuntimeError mid-listing.
        return [self.get_plugin_info(n) for n in list(self._plugins)]

    _plugin_state_cache: dict = {}
    _plugin_state_cache_lock = threading.Lock()

    def get_plugin_state(self, name: str) -> PluginState:
        """Get the PluginState helper for a plugin (cached singleton per name)."""
        with self._plugin_state_cache_lock:
            if name not in self._plugin_state_cache:
                self._plugin_state_cache[name] = PluginState(name)
            return self._plugin_state_cache[name]

    def effective_surfaces(self, name: str, manifest: dict = None):
        """Where a plugin's presence hooks fire: the user's override (plugin
        state `surfaces`) if it is a list, else the manifest's `surfaces`,
        else None (= everywhere). Unknown surface ids are dropped."""
        from core.hooks import SURFACES
        known = {s for s, _ in SURFACES}
        if manifest is None:
            manifest = (self._plugins.get(name) or {}).get("manifest") or {}
        declared = manifest.get("surfaces")
        if not isinstance(declared, list):
            return None
        override = self.get_plugin_state(name).get("surfaces")
        chosen = override if isinstance(override, list) else declared
        return [s for s in chosen if s in known]

    def set_surfaces_override(self, name: str, surfaces):
        """Persist the user's per-plugin surfaces choice (None = back to the
        manifest default) and apply it to the live runner."""
        state = self.get_plugin_state(name)
        if surfaces is None:
            state.delete("surfaces")
        else:
            state.save("surfaces", list(surfaces))
        eff = self.effective_surfaces(name)
        hook_runner.set_surfaces(name, eff)
        return eff

    _chat_state_cache: dict = {}

    def get_chat_state(self, name: str) -> PluginChatState:
        """Chat-scoped plugin data helper (cached per name). Sibling of
        get_plugin_state; rows ride the chat's vault/rename/delete."""
        with self._plugin_state_cache_lock:
            if name not in self._chat_state_cache:
                self._chat_state_cache[name] = PluginChatState(name)
            return self._chat_state_cache[name]

    def get_credentials(self):
        """Get the credentials manager singleton. Convenience for plugins."""
        from core.credentials_manager import credentials
        return credentials

    # ── File watcher (dev mode) ──

    def start_watcher(self):
        """Start mtime-based file watcher for loaded plugins. Dev mode only."""
        if self._watcher_running:
            return
        self._watcher_running = True
        self._watcher_thread = threading.Thread(
            target=self._watcher_loop, daemon=True, name="PluginFileWatcher"
        )
        self._watcher_thread.start()
        logger.info("[PLUGINS] File watcher started (dev mode)")

    def stop_all_tools(self):
        """Every plugin tool module with a shutdown() lets go of what it holds
        (an open port, a thread). Called at shutdown alongside the daemons; a
        single plugin's runs in unregister_plugin_tools when it is disabled
        or reloaded."""
        if self._function_manager:
            self._function_manager.shutdown_all_plugin_tools()

    def stop_all_daemons(self):
        """Stop all loaded plugin daemons. Must be called before audio/system teardown."""
        with self._lock:
            daemon_items = [
                (name, info.get("daemon_module"))
                for name, info in self._plugins.items()
                if info.get("loaded") and info.get("daemon_module")
            ]

        for name, daemon_mod in daemon_items:
            if daemon_mod and hasattr(daemon_mod, "stop"):
                try:
                    daemon_mod.stop()
                    logger.info(f"[PLUGINS] Stopped daemon for {name}")
                except Exception as e:
                    logger.warning(f"[PLUGINS] Failed to stop daemon for {name}: {e}")

    def stop_watcher(self):
        """Stop the file watcher."""
        self._watcher_running = False
        if self._watcher_thread:
            self._watcher_thread.join(timeout=5)
            self._watcher_thread = None

    def _watcher_loop(self):
        """Poll loaded plugin dirs for file changes, reload on change."""
        import time as _time

        # Snapshot initial mtimes
        mtimes: Dict[str, float] = {}
        with self._lock:
            snapshot = list(self._plugins.items())
        for name, info in snapshot:
            if info.get("loaded"):
                mtimes[name] = self._dir_mtime(info["path"])

        while self._watcher_running:
            _time.sleep(2)
            with self._lock:
                snapshot = list(self._plugins.items())
            for name, info in snapshot:
                if not info.get("loaded"):
                    # Track newly loaded plugins so first poll doesn't spuriously reload
                    if name not in mtimes and info["path"].exists():
                        mtimes[name] = self._dir_mtime(info["path"])
                    continue
                current = self._dir_mtime(info["path"])
                prev = mtimes.get(name, 0)
                if prev == 0:
                    # First time seeing this plugin loaded — snapshot, don't reload
                    mtimes[name] = current
                    continue
                if current > prev:
                    logger.info(f"[PLUGINS] File change detected in '{name}', reloading...")
                    self.reload_plugin(name)
                    mtimes[name] = self._dir_mtime(info["path"])

    @staticmethod
    def _dir_mtime(path: Path) -> float:
        """Get max mtime of all .py and .json files in a directory tree."""
        max_mtime = 0.0
        try:
            for f in path.rglob("*"):
                if f.suffix in (".py", ".json") and f.is_file():
                    mt = f.stat().st_mtime
                    if mt > max_mtime:
                        max_mtime = mt
        except Exception:
            pass
        return max_mtime


# Singleton
plugin_loader = PluginLoader()
