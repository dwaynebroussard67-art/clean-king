# core/audio/errors.py - Audio error classification and handling
"""
Unified audio error handling for Sapphire.
Provides actionable error messages for common audio issues.
"""

import logging

logger = logging.getLogger(__name__)


class AudioError(Exception):
    """Base exception for audio subsystem errors."""
    pass


class DeviceNotFoundError(AudioError):
    """No suitable audio device could be found."""
    pass


class DeviceConfigError(AudioError):
    """Device found but configuration failed."""
    pass


class StreamError(AudioError):
    """Error during audio streaming."""
    pass


def classify_audio_error(e: Exception) -> str:
    """
    Classify audio exception and return actionable user message.
    
    Analyzes exception type and message to provide helpful guidance
    for resolving common audio issues across platforms.
    
    Args:
        e: The exception to classify
        
    Returns:
        Human-readable error message with resolution steps
    """
    err_str = str(e).lower()
    
    # Windows blocks the mic for desktop apps: WASAPI says E_ACCESSDENIED
    # (-2147024891 = 0x80070005), not "permission denied".
    if any(x in err_str for x in ['-2147024891', '0x80070005']):
        return (
            "Windows is blocking the microphone. Open Windows Settings › Privacy & security › "
            "Microphone and turn on \"Let desktop apps access your microphone\", then try again."
        )

    # Permission denied
    if any(x in err_str for x in ['permission denied', 'eperm', 'eacces', 'access denied']):
        return (
            "Microphone access denied. "
            "Linux: run 'sudo usermod -aG audio $USER' then logout/login. "
            "Windows: Settings › Privacy & security › Microphone, turn on \"Let desktop apps access your microphone\"."
        )

    # Device busy (WASAPI: AUDCLNT_E_DEVICE_IN_USE -2004287478 = 0x8889000A;
    # PortAudio: Device unavailable -9985)
    if any(x in err_str for x in ['device or resource busy', 'ebusy', 'already in use', 'exclusive',
                                  '-2004287478', '0x8889000a', 'device unavailable', '-9985']):
        return (
            "Microphone in use by another application. "
            "Close Discord, Zoom, Teams, or other audio apps and retry."
        )
    
    # Invalid sample rate (PortAudio error -9997)
    if any(x in err_str for x in ['invalid sample rate', '-9997', 'sample rate', 'samplerate']):
        return (
            "Device rejected all sample rates. "
            "Add your device's own rate to Audio Sample Rates in Settings › Audio (Advanced)."
        )
    
    # Invalid channel count
    if any(x in err_str for x in ['invalid number of channels', 'channel', '-9998']):
        return (
            "Device rejected channel configuration. "
            "This is unusual - check if device supports audio input."
        )
    
    # No sound server (PulseAudio/PipeWire): headless boxes, VMs, or the
    # socket not up yet at boot. PortAudio >= 19.7 (Ubuntu 26.04) aborts
    # Pa_Initialize entirely in this case (upstream #900). 2026-09-06.
    if "can't connect to server" in err_str or 'pulseaudio_initialize' in err_str:
        return (
            "No audio server reachable (PulseAudio/PipeWire). Headless box or VM: "
            "'systemctl --user start pipewire-pulse.socket' (apt install pipewire-pulse "
            "if missing), then re-open Settings > Audio to re-detect. Ignore if this "
            "machine has no speaker/mic -- browser voice is unaffected."
        )

    # PortAudio not initialized / not found
    if any(x in err_str for x in ['portaudio', 'not initialized', 'pa_', 'libportaudio']):
        return (
            "Audio system not ready. "
            "Linux: run 'sudo apt install libportaudio2 portaudio19-dev'. "
            "Windows: reinstall Python audio packages."
        )
    
    # Device not found
    if any(x in err_str for x in ['no such device', 'device not found', 'invalid device']):
        return (
            "Audio device not found. "
            "Check its USB cable, or pick a different device in Settings › Audio."
        )
    
    # Timeout / underrun
    if any(x in err_str for x in ['timeout', 'underrun', 'overrun', 'xrun']):
        return (
            "Audio buffer underrun. "
            "Close other audio apps, or add a bigger value to Audio Blocksize Fallbacks in Settings › Audio (Advanced)."
        )
    
    # Generic with original error
    return f"The audio device failed ({e}). Pick another device in Settings › Audio, or try again." if str(e) \
        else "The audio device failed. Pick another device in Settings › Audio, or try again."