# core/credentials_manager.py
r"""
Credentials Manager - Secure storage for API keys and secrets

Stores credentials in platform-appropriate config directory:
- Linux: ~/.config/sapphire/credentials.json
- macOS: ~/Library/Application Support/Sapphire/credentials.json
- Windows: %APPDATA%\Sapphire\credentials.json

This keeps credentials OUT of the project directory and backups.
"""

import json
import os
import sys
import hashlib
import base64
import getpass
import logging
import re
import socket
import threading
from pathlib import Path
from typing import Optional
from core.setup import CONFIG_DIR, SOCKS_CONFIG_FILE, CLAUDE_API_KEY_FILE
from core.settings_manager import _fsync_file, _fsync_dir
from core.fs_utils import replace_with_retry

try:
    from cryptography.fernet import Fernet, InvalidToken
except ImportError:
    Fernet = None
    InvalidToken = Exception


class DecryptionError(Exception):
    """Raised by `_unscramble_strict` when an encrypted credential field
    can't be decrypted. Signals 'this value exists on disk and is encrypted
    but we can't read it right now' — distinct from 'this value is empty
    or absent'. Routes that read-existing-then-save MUST distinguish these
    because saving an empty value back through the encrypt path commits
    real data loss (`refresh_token` / `app_password` permanently gone after
    a routine field edit). Day-ruiner scout 2026-05-07 #C.
    """
    pass

logger = logging.getLogger(__name__)

CREDENTIALS_FILE = CONFIG_DIR / 'credentials.json'
SCRAMBLE_SALT_FILE = CONFIG_DIR / '.scramble_salt'

# Schema for credentials.json
DEFAULT_CREDENTIALS = {
    "llm": {
        "claude": {"api_key": ""},
        "fireworks": {"api_key": ""},
        "openai": {"api_key": ""},
        "other": {"api_key": ""},
        "grok": {"api_key": ""},
        "featherless": {"api_key": ""},
        "gemini": {"api_key": ""}
    },
    "socks": {
        "username": "",
        "password": ""
    },
    "homeassistant": {
        "token": ""
    },
    "email_accounts": {},
    "bitcoin_wallets": {},
    "gcal_accounts": {},
    "github_accounts": {},
    "twilio_accounts": {},
    "discord_accounts": {},
    "plugin_accounts": {},
    "ssh": {
        "servers": []
    },
    "services": {
        "stt_fireworks": {"api_key": ""},
        "tts_elevenlabs": {"api_key": ""},
        "embedding": {"api_key": ""}
    }
}

# Core provider env vars (static fallback — custom providers use api_key_env from config)
PROVIDER_ENV_VARS = {
    'claude': 'ANTHROPIC_API_KEY',
    'openai': 'OPENAI_API_KEY',
    'gemini': 'GOOGLE_API_KEY',
}


def _get_env_var_for_provider(provider: str) -> str:
    """Get env var name for a provider — checks static map, then provider config."""
    if provider in PROVIDER_ENV_VARS:
        return PROVIDER_ENV_VARS[provider]
    # Check custom provider config for api_key_env
    try:
        from core.settings_manager import settings
        custom = settings.get('LLM_CUSTOM_PROVIDERS', {})
        config = custom.get(provider, {})
        return config.get('api_key_env', '')
    except ImportError:
        return ''


class CredentialsManager:
    """Manages credentials stored outside project directory."""

    def __init__(self):
        self._credentials = None
        self._scramble_key = None
        self._lock = threading.RLock()
        self._load()
    
    def _load(self):
        """Load credentials from file, migrating legacy files if needed."""
        logger.info(f"Loading credentials, checking {CREDENTIALS_FILE}")
        
        if CREDENTIALS_FILE.exists():
            try:
                with open(CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
                    self._credentials = json.load(f)
                # Ensure all expected keys exist
                self._ensure_schema()
                logger.info(f"Loaded credentials from {CREDENTIALS_FILE}")
            except Exception as e:
                logger.critical(f"Credentials file corrupted: {e}")
                # Back up corrupt file before resetting (timestamped to preserve history)
                try:
                    from datetime import datetime
                    import shutil
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    backup = CREDENTIALS_FILE.with_suffix(f'.json.corrupt.{timestamp}')
                    shutil.copy2(CREDENTIALS_FILE, backup)
                    logger.critical(f"Corrupt credentials backed up to {backup}")
                except Exception as backup_err:
                    logger.error(f"Could not back up corrupt credentials: {backup_err}")
                self._credentials = self._deep_copy(DEFAULT_CREDENTIALS)
                self._save()
        else:
            logger.info(f"Credentials file does not exist, creating with defaults")
            self._credentials = self._deep_copy(DEFAULT_CREDENTIALS)
            self._migrate_legacy()
            if not self._save():
                logger.warning("Could not save initial credentials file - will operate in memory only")
    
    def _deep_copy(self, d: dict) -> dict:
        """Deep copy a nested dict."""
        return json.loads(json.dumps(d))
    
    def _ensure_schema(self):
        """Ensure all expected keys exist in loaded credentials."""
        changed = False
        for section, defaults in DEFAULT_CREDENTIALS.items():
            if section not in self._credentials:
                self._credentials[section] = self._deep_copy(defaults)
                changed = True
            elif isinstance(defaults, dict):
                for key, val in defaults.items():
                    if key not in self._credentials[section]:
                        self._credentials[section][key] = self._deep_copy(val) if isinstance(val, dict) else val
                        changed = True
        # Migrate old single "email" key -> "email_accounts"
        if "email" in self._credentials and "email_accounts" not in self._credentials:
            old = self._credentials.pop("email")
            self._credentials["email_accounts"] = {}
            if old.get("address"):
                self._credentials["email_accounts"]["default"] = old
                logger.info("Migrated single email credentials to email_accounts['default']")
            changed = True
        elif "email" in self._credentials:
            old = self._credentials.pop("email")
            if old.get("address") and "default" not in self._credentials["email_accounts"]:
                self._credentials["email_accounts"]["default"] = old
                logger.info("Migrated single email credentials to email_accounts['default']")
            changed = True
        if changed:
            if not self._save():
                logger.warning("Schema update could not be saved to disk")
        # Always sweep stale api_keys from settings.json into credentials
        self._migrate_settings_api_keys()
        self._migrate_service_api_keys()

    def _migrate_legacy(self):
        """Migrate from legacy credential files."""
        migrated = False
        
        # Migrate SOCKS credentials from socks_config file
        if SOCKS_CONFIG_FILE.exists():
            try:
                lines = SOCKS_CONFIG_FILE.read_text(encoding='utf-8-sig').splitlines()
                if len(lines) >= 2:
                    username = self._parse_legacy_line(lines[0])
                    password = self._parse_legacy_line(lines[1])
                    if username and password:
                        self._credentials['socks']['username'] = username
                        self._credentials['socks']['password'] = password
                        logger.info(f"Migrated SOCKS credentials from {SOCKS_CONFIG_FILE}")
                        migrated = True
            except Exception as e:
                logger.warning(f"Failed to migrate socks_config: {e}")
        
        # Migrate Claude API key from dedicated file
        if CLAUDE_API_KEY_FILE.exists():
            try:
                # utf-8-sig: a PowerShell-written key file carries a BOM, and
                # .strip() does NOT remove U+FEFF — the key 401s pointing nowhere.
                api_key = CLAUDE_API_KEY_FILE.read_text(encoding='utf-8-sig').strip()
                if api_key:
                    self._credentials['llm']['claude']['api_key'] = api_key
                    logger.info(f"Migrated Claude API key from {CLAUDE_API_KEY_FILE}")
                    migrated = True
            except Exception as e:
                logger.warning(f"Failed to migrate claude_api_key: {e}")
        
        # Migrate API keys from user/settings.json LLM_PROVIDERS
        self._migrate_settings_api_keys()
        self._migrate_service_api_keys()

        if migrated:
            logger.info("Legacy credential migration complete")
    
    def _migrate_settings_api_keys(self):
        """Migrate api_key fields from user/settings.json to credentials."""
        settings_file = Path(__file__).parent.parent / 'user' / 'settings.json'
        if not settings_file.exists():
            return
        
        try:
            with open(settings_file, 'r', encoding='utf-8') as f:
                user_settings = json.load(f)
            
            # Settings file can be nested (llm.LLM_PROVIDERS) or flat (LLM_PROVIDERS)
            providers = user_settings.get('LLM_PROVIDERS', {})
            if not providers:
                providers = user_settings.get('llm', {}).get('LLM_PROVIDERS', {})
            # Also check LLM_CUSTOM_PROVIDERS
            custom_providers = user_settings.get('LLM_CUSTOM_PROVIDERS', {})
            if not custom_providers:
                custom_providers = user_settings.get('llm', {}).get('LLM_CUSTOM_PROVIDERS', {})
            # Merge both for migration scan
            all_providers = {**providers, **custom_providers}
            migrated_any = False

            for provider_key, prov_config in all_providers.items():
                api_key = prov_config.get('api_key', '').strip()
                if api_key:
                    # Only migrate if we don't already have a key for this provider
                    if not self._credentials.get('llm', {}).get(provider_key, {}).get('api_key'):
                        if 'llm' not in self._credentials:
                            self._credentials['llm'] = {}
                        if provider_key not in self._credentials['llm']:
                            self._credentials['llm'][provider_key] = {}
                        self._credentials['llm'][provider_key]['api_key'] = api_key
                        logger.info(f"Migrated {provider_key} API key from settings.json")
                        migrated_any = True

            # Persist credentials BEFORE blanking settings.json (crash safety)
            if migrated_any:
                if not self._save():
                    logger.error("Failed to save migrated credentials — aborting settings.json cleanup")
                    return

            # Always clear api_key fields from settings.json (even if already in credentials)
            modified = False
            for prov_config in list(providers.values()) + list(custom_providers.values()):
                if prov_config.get('api_key'):
                    prov_config['api_key'] = ''
                    modified = True

            if modified:
                tmp = settings_file.with_suffix('.json.tmp')
                with open(tmp, 'w', encoding='utf-8') as f:
                    json.dump(user_settings, f, indent=2)
                    _fsync_file(f)
                replace_with_retry(tmp, settings_file)
                _fsync_dir(settings_file.parent)
                logger.info("Cleared stale API keys from settings.json")

                # Also strip from settings_manager's in-memory config so they
                # don't get written back on the next settings.set(..., persist=True)
                try:
                    from core.settings_manager import settings as sm
                    for dict_key in ('LLM_PROVIDERS', 'LLM_CUSTOM_PROVIDERS'):
                        mem_providers = sm._config.get(dict_key, {})
                        for prov in mem_providers.values():
                            if isinstance(prov, dict):
                                prov.pop('api_key', None)
                except Exception:
                    pass  # settings_manager may not be loaded yet — save() defense handles it

        except Exception as e:
            logger.warning(f"Failed to migrate settings.json API keys: {e}")
    
    # Settings keys that should live in credentials, mapped to services section
    _SERVICE_KEY_MAP = {
        'STT_FIREWORKS_API_KEY': 'stt_fireworks',
        'TTS_ELEVENLABS_API_KEY': 'tts_elevenlabs',
        'EMBEDDING_API_KEY': 'embedding',
    }

    def _migrate_service_api_keys(self):
        """Migrate standalone API key settings (STT/TTS/Embedding) to credentials."""
        settings_file = Path(__file__).parent.parent / 'user' / 'settings.json'
        if not settings_file.exists():
            return

        try:
            with open(settings_file, 'r', encoding='utf-8') as f:
                user_settings = json.load(f)

            migrated_any = False
            services = self._credentials.setdefault('services', {})

            # Search all nested sections for service API keys
            for settings_key, service_name in self._SERVICE_KEY_MAP.items():
                value = self._find_setting_value(user_settings, settings_key)
                if not value:
                    continue
                svc = services.setdefault(service_name, {})
                if not svc.get('api_key'):
                    svc['api_key'] = value
                    logger.info(f"Migrated {settings_key} to credentials")
                    migrated_any = True

            if migrated_any:
                if not self._save():
                    logger.error("Failed to save migrated service credentials — aborting cleanup")
                    return

            # Clear from settings.json
            modified = False
            for settings_key in self._SERVICE_KEY_MAP:
                if self._clear_setting_value(user_settings, settings_key):
                    modified = True

            if modified:
                tmp = settings_file.with_suffix('.json.tmp')
                with open(tmp, 'w', encoding='utf-8') as f:
                    json.dump(user_settings, f, indent=2)
                    _fsync_file(f)
                replace_with_retry(tmp, settings_file)
                _fsync_dir(settings_file.parent)
                logger.info("Cleared service API keys from settings.json")

                # Also strip from in-memory config
                try:
                    from core.settings_manager import settings as sm
                    for settings_key in self._SERVICE_KEY_MAP:
                        if settings_key in sm._config:
                            sm._config[settings_key] = ''
                except Exception:
                    pass

        except Exception as e:
            logger.warning(f"Failed to migrate service API keys: {e}")

    @staticmethod
    def _find_setting_value(user_settings: dict, key: str) -> str:
        """Find a setting value in nested or flat settings dict."""
        # Flat
        val = user_settings.get(key, '')
        if val:
            return val.strip() if isinstance(val, str) else ''
        # Nested — search all sections
        for section in user_settings.values():
            if isinstance(section, dict) and key in section:
                val = section[key]
                if val:
                    return val.strip() if isinstance(val, str) else ''
        return ''

    @staticmethod
    def _clear_setting_value(user_settings: dict, key: str) -> bool:
        """Clear a setting value from nested or flat settings dict. Returns True if modified."""
        modified = False
        if user_settings.get(key):
            user_settings[key] = ''
            modified = True
        for section in user_settings.values():
            if isinstance(section, dict) and section.get(key):
                section[key] = ''
                modified = True
        return modified

    def get_service_api_key(self, service: str) -> str:
        """Get API key for a service (stt_fireworks, tts_elevenlabs, embedding)."""
        services = self._credentials.get('services', {})
        return services.get(service, {}).get('api_key', '').strip()

    def set_service_api_key(self, service: str, api_key: str) -> bool:
        """Set API key for a service."""
        with self._lock:
            try:
                services = self._credentials.setdefault('services', {})
                services.setdefault(service, {})['api_key'] = api_key
                if not self._save():
                    logger.error(f"Failed to persist API key for service '{service}'")
                    return False
                logger.info(f"Set API key for service '{service}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set API key for service '{service}': {e}")
                return False

    def _parse_legacy_line(self, line: str) -> str:
        """Parse legacy config line, stripping key= prefix if present."""
        line = line.strip()
        if '=' in line:
            return line.split('=', 1)[1].strip()
        return line
    
    def _save(self) -> bool:
        """Save credentials to file with restrictive permissions. Returns True on success.
        Uses atomic write (temp + rename) to prevent corruption on crash.
        Thread-safe: acquires _lock to serialize all mutation+save cycles."""
        with self._lock:
            try:
                CONFIG_DIR.mkdir(parents=True, exist_ok=True)

                tmp_path = CREDENTIALS_FILE.with_suffix('.tmp')
                with open(tmp_path, 'w', encoding='utf-8') as f:
                    json.dump(self._credentials, f, indent=2)
                    _fsync_file(f)

                # Set restrictive permissions on Unix (before rename so file is protected)
                if sys.platform != 'win32':
                    os.chmod(tmp_path, 0o600)

                replace_with_retry(tmp_path, CREDENTIALS_FILE)
                _fsync_dir(CREDENTIALS_FILE.parent)

                logger.info(f"Saved credentials to {CREDENTIALS_FILE}")
                return True
            except Exception as e:
                logger.error(f"Failed to save credentials to {CREDENTIALS_FILE}: {e}")
                return False

    # =========================================================================
    # Backup encryption password — scrambled at rest in credentials.json
    # (~/.config/sapphire), never inside the user/ backup archive.
    # =========================================================================

    def set_backup_password(self, password: str) -> bool:
        """Store (or clear with '') the backup-encryption password."""
        with self._lock:
            try:
                self._credentials['backup_password'] = self._scramble(password) if password else ''
                if not self._save():
                    return False
                logger.info("Backup encryption password " + ("set" if password else "cleared"))
                return True
            except Exception as e:
                logger.error(f"Failed to set backup password: {e}")
                return False

    def get_backup_password(self) -> str:
        """Plaintext backup password (machine-bound unscramble), or '' if unset."""
        raw = (self._credentials or {}).get('backup_password', '')
        return self._unscramble(raw) if raw else ''

    def has_backup_password(self) -> bool:
        return bool((self._credentials or {}).get('backup_password'))

    def backup_password_status(self) -> str:
        """'missing' (none stored), 'unreadable' (stored but won't decrypt — salt
        lost / machine moved), or 'ok'. Lets the UI shout when encryption is on but
        the saved password can no longer be read (silent-plaintext guard)."""
        raw = (self._credentials or {}).get('backup_password', '')
        if not raw:
            return 'missing'
        try:
            self._unscramble_strict(raw)
            return 'ok'
        except Exception:
            return 'unreadable'

    # =========================================================================
    # Remembrance offsite-backup vault — connection lives here (api_key scrambled),
    # never inside user/ backups. Single vault (v1).
    # =========================================================================

    def get_offsite_account(self) -> dict:
        """Vault connection with api_key unscrambled. Empty strings if unset."""
        acct = (self._credentials or {}).get('offsite_account', {})
        return {
            'server_url': acct.get('server_url', ''),
            'tenant_id': acct.get('tenant_id', ''),
            'api_key': self._unscramble(acct.get('api_key', '')),
        }

    def set_offsite_account(self, server_url: str, tenant_id: str, api_key: str = '') -> bool:
        """Store the vault connection; api_key scrambled. An empty api_key keeps the
        existing one (so URL/tenant can be edited without re-entering the secret)."""
        with self._lock:
            try:
                existing = self._credentials.get('offsite_account', {})
                stored_key = existing.get('api_key', '') if not api_key else self._scramble(api_key)
                self._credentials['offsite_account'] = {
                    'server_url': (server_url or '').strip().rstrip('/'),
                    'tenant_id': (tenant_id or '').strip(),
                    'api_key': stored_key,
                }
                if not self._save():
                    return False
                logger.info("Set Remembrance offsite account")
                return True
            except Exception as e:
                logger.error(f"Failed to set offsite account: {e}")
                return False

    def has_offsite_account(self) -> bool:
        acct = (self._credentials or {}).get('offsite_account', {})
        return bool(acct.get('server_url') and acct.get('tenant_id') and acct.get('api_key'))

    # =========================================================================
    # Scramble (reversible encryption for sensitive fields)
    # =========================================================================

    def _get_scramble_key(self) -> bytes:
        """Derive Fernet key from salt + machine identity. Cached after first call."""
        if self._scramble_key:
            return self._scramble_key

        if Fernet is None:
            raise RuntimeError("cryptography package not installed — cannot scramble")

        # Create salt file on first use
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if SCRAMBLE_SALT_FILE.exists():
            salt = SCRAMBLE_SALT_FILE.read_bytes()
        else:
            salt = os.urandom(32)
            SCRAMBLE_SALT_FILE.write_bytes(salt)
            if sys.platform != 'win32':
                os.chmod(SCRAMBLE_SALT_FILE, 0o600)
            logger.info("Created scramble salt file")

        # Machine identity: hostname + OS username
        identity = f"{socket.gethostname()}:{getpass.getuser()}".encode()
        derived = hashlib.pbkdf2_hmac('sha256', identity, salt, 100_000)
        self._scramble_key = base64.urlsafe_b64encode(derived)
        return self._scramble_key

    def _scramble(self, value: str) -> str:
        """Encrypt a value. Returns 'enc:...' string."""
        if not value:
            return value
        key = self._get_scramble_key()
        f = Fernet(key)
        encrypted = f.encrypt(value.encode()).decode()
        return f"enc:{encrypted}"

    def _unscramble(self, value: str) -> str:
        """Decrypt an 'enc:...' value. Plaintext passes through unchanged.

        Returns '' on decrypt failure for read paths that just want a
        best-effort display value. CALLERS THAT WRITE BACK should use
        `_unscramble_strict` (raises) — silently rewriting a successfully-
        encrypted credential as `''` is a routine-edit data-loss class.
        Day-ruiner scout 2026-05-07 #C.
        """
        if not value or not value.startswith('enc:'):
            return value
        try:
            key = self._get_scramble_key()
            f = Fernet(key)
            return f.decrypt(value[4:].encode()).decode()
        except (InvalidToken, Exception) as e:
            logger.critical(f"Failed to decrypt credential — encryption key may have changed or salt file lost: {e}")
            return ''

    def _unscramble_strict(self, value: str) -> str:
        """Like `_unscramble` but raises `DecryptionError` on failure
        instead of returning ''. Use this from any code that will WRITE
        BACK the result — the route handler "preserve untouched fields"
        flow is the canonical example. Pre-fix, those routes pulled
        encrypted fields, got '' on decrypt failure (e.g. salt file lost
        after backup restore), and silently committed empty back through
        the encrypt path → data loss on a routine save. With strict, the
        route catches DecryptionError and refuses to save."""
        if not value or not value.startswith('enc:'):
            return value
        try:
            key = self._get_scramble_key()
            f = Fernet(key)
            return f.decrypt(value[4:].encode()).decode()
        except (InvalidToken, Exception) as e:
            logger.critical(
                f"Strict decrypt failed — encryption key may have changed "
                f"or salt file lost: {e}"
            )
            raise DecryptionError(
                "Credential is encrypted but cannot be decrypted "
                "(salt file may be missing or rotated)"
            ) from e

    def scramble(self, value: str) -> str:
        """Public door to the machine-bound scramble (core/devices/secret_store)."""
        return self._scramble(value)

    def unscramble_strict(self, value: str) -> str:
        """Public door to the strict decrypt - raises DecryptionError."""
        return self._unscramble_strict(value)

    # =========================================================================
    # LLM API Keys
    # =========================================================================
    
    def get_llm_api_key(self, provider: str) -> str:
        """
        Get API key for an LLM provider.
        
        Priority (DRY - all credential logic centralized here):
        1. Stored credential in credentials.json (user set in Sapphire UI)
        2. Environment variable fallback
        
        Returns empty string if neither is set.
        """
        # Check stored credential first (takes priority - user explicitly set it)
        stored_key = self._get_stored_api_key(provider)
        if stored_key:
            return stored_key
        
        # Fall back to environment variable (static + dynamic lookup)
        env_var = _get_env_var_for_provider(provider)
        if env_var:
            env_value = os.environ.get(env_var, '')
            if env_value and env_value.strip():
                logger.debug(f"Using API key from env var {env_var} for {provider}")
                return env_value

        return ''
    
    def _get_stored_api_key(self, provider: str) -> str:
        """Get API key stored in credentials.json only (not env)."""
        llm = self._credentials.get('llm', {})
        provider_creds = llm.get(provider, {})
        return provider_creds.get('api_key', '').strip()
    
    def has_stored_api_key(self, provider: str) -> bool:
        """Check if provider has a key stored in credentials.json."""
        return bool(self._get_stored_api_key(provider))
    
    def has_env_api_key(self, provider: str) -> bool:
        """Check if provider has a key from environment variable."""
        env_var = _get_env_var_for_provider(provider)
        if env_var:
            return bool(os.environ.get(env_var, '').strip())
        return False
    
    def get_api_key_source(self, provider: str) -> str:
        """
        Get the source of the API key for UI display.
        
        Returns: 'stored', 'env', or 'none'
        """
        if self.has_stored_api_key(provider):
            return 'stored'
        if self.has_env_api_key(provider):
            return 'env'
        return 'none'
    
    def get_env_var_name(self, provider: str) -> str:
        """Get the environment variable name for a provider."""
        return _get_env_var_for_provider(provider)
    
    def set_llm_api_key(self, provider: str, api_key: str) -> bool:
        """Set API key for an LLM provider."""
        with self._lock:
            try:
                if 'llm' not in self._credentials:
                    self._credentials['llm'] = {}
                if provider not in self._credentials['llm']:
                    self._credentials['llm'][provider] = {}

                self._credentials['llm'][provider]['api_key'] = api_key

                if not self._save():
                    logger.error(f"Failed to persist API key for '{provider}' to disk")
                    return False

                logger.info(f"Set API key for provider '{provider}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set API key for '{provider}': {e}")
                return False
    
    def clear_llm_api_key(self, provider: str) -> bool:
        """Remove the stored credential entry for an LLM provider (not just blank it),
        so a deleted provider leaves no dangling entry behind."""
        with self._lock:
            try:
                llm = self._credentials.get('llm', {})
                if provider not in llm:
                    return True  # nothing stored — already clear
                del llm[provider]
                if not self._save():
                    logger.error(f"Failed to persist credential removal for '{provider}'")
                    return False
                logger.info(f"Removed stored credential for provider '{provider}'")
                return True
            except Exception as e:
                logger.error(f"Failed to clear API key for '{provider}': {e}")
                return False
    
    def has_llm_api_key(self, provider: str) -> bool:
        """Check if provider has an API key (from either stored or env)."""
        return bool(self.get_llm_api_key(provider))
    
    # =========================================================================
    # SOCKS Credentials
    # =========================================================================
    
    def get_socks_credentials(self) -> tuple[str, str]:
        """
        Get SOCKS credentials.
        
        Returns (username, password) tuple. Empty strings if not set.
        Caller should check env vars as fallback.
        """
        socks = self._credentials.get('socks', {})
        return socks.get('username', ''), socks.get('password', '')
    
    def set_socks_credentials(self, username: str, password: str) -> bool:
        """Set SOCKS credentials."""
        with self._lock:
            try:
                if 'socks' not in self._credentials:
                    self._credentials['socks'] = {}

                self._credentials['socks']['username'] = username
                self._credentials['socks']['password'] = password

                if not self._save():
                    logger.error("Failed to persist SOCKS credentials to disk")
                    return False

                logger.info("Set SOCKS credentials")
                return True
            except Exception as e:
                logger.error(f"Failed to set SOCKS credentials: {e}")
            return False
    
    def clear_socks_credentials(self) -> bool:
        """Clear SOCKS credentials."""
        return self.set_socks_credentials('', '')
    
    def has_socks_credentials(self) -> bool:
        """Check if SOCKS credentials are stored."""
        username, password = self.get_socks_credentials()
        return bool(username and password)
    
    # =========================================================================
    # Home Assistant
    # =========================================================================
    
    def get_ha_token(self) -> str:
        """
        Get Home Assistant long-lived access token.
        
        Priority:
        1. Stored credential in credentials.json
        2. HA_TOKEN environment variable
        """
        # Check stored credential first
        ha = self._credentials.get('homeassistant', {})
        stored_token = ha.get('token', '').strip()
        if stored_token:
            return stored_token
        
        # Fall back to environment variable
        env_token = os.environ.get('HA_TOKEN', '').strip()
        if env_token:
            logger.debug("Using HA token from HA_TOKEN env var")
            return env_token
        
        return ''
    
    def set_ha_token(self, token: str) -> bool:
        """Set Home Assistant token."""
        with self._lock:
            try:
                if 'homeassistant' not in self._credentials:
                    self._credentials['homeassistant'] = {}

                self._credentials['homeassistant']['token'] = token

                if not self._save():
                    logger.error("Failed to persist HA token to disk")
                    return False

                logger.info("Set Home Assistant token")
                return True
            except Exception as e:
                logger.error(f"Failed to set HA token: {e}")
                return False
    
    def clear_ha_token(self) -> bool:
        """Clear Home Assistant token."""
        return self.set_ha_token('')
    
    def has_ha_token(self) -> bool:
        """Check if Home Assistant token is available."""
        return bool(self.get_ha_token())
    
    # =========================================================================
    # Email Accounts (multi-account, keyed by scope)
    # =========================================================================

    def get_email_account(self, scope: str = 'default') -> dict:
        """Get email account for a scope. Secrets are unscrambled on read."""
        accounts = self._credentials.get('email_accounts', {})
        acct = accounts.get(scope, {})
        result = {
            'address': acct.get('address', ''),
            'app_password': self._unscramble(acct.get('app_password', '')),
            'auth_type': acct.get('auth_type', 'password'),
            'imap_server': acct.get('imap_server', ''),
            'smtp_server': acct.get('smtp_server', ''),
            'imap_port': acct.get('imap_port', 993),
            'smtp_port': acct.get('smtp_port', 465),
        }
        # Include OAuth fields if present
        if result['auth_type'] == 'oauth2':
            result.update({
                'oauth_client_id': acct.get('oauth_client_id', ''),
                'oauth_client_secret': self._unscramble(acct.get('oauth_client_secret', '')),
                'oauth_tenant_id': acct.get('oauth_tenant_id', 'common'),
                'oauth_refresh_token': self._unscramble(acct.get('oauth_refresh_token', '')),
                'oauth_access_token': acct.get('oauth_access_token', ''),
                'oauth_expires_at': acct.get('oauth_expires_at', 0),
            })
        return result

    def set_email_account(self, scope: str, address: str, app_password: str,
                          imap_server: str = 'imap.gmail.com',
                          smtp_server: str = 'smtp.gmail.com',
                          imap_port: int = 993,
                          smtp_port: int = 465) -> bool:
        """Set email account for a scope. App password is scrambled before save."""
        with self._lock:
            try:
                if 'email_accounts' not in self._credentials:
                    self._credentials['email_accounts'] = {}

                self._credentials['email_accounts'][scope] = {
                    'address': address,
                    'app_password': self._scramble(app_password) if app_password else '',
                    'imap_server': imap_server,
                    'smtp_server': smtp_server,
                    'imap_port': imap_port,
                    'smtp_port': smtp_port,
                }

                if not self._save():
                    logger.error(f"Failed to persist email account '{scope}' to disk")
                    return False

                logger.info(f"Set email account for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set email account '{scope}': {e}")
                return False

    def delete_email_account(self, scope: str) -> bool:
        """Remove an email account by scope."""
        with self._lock:
            accounts = self._credentials.get('email_accounts', {})
            if scope not in accounts:
                return False
            del accounts[scope]
            if not self._save():
                logger.error(f"Failed to persist deletion of email account '{scope}'")
                return False
            logger.info(f"Deleted email account '{scope}'")
            return True

    def list_email_accounts(self) -> list:
        """List all email accounts (no passwords/tokens)."""
        accounts = self._credentials.get('email_accounts', {})
        result = []
        for scope, acct in accounts.items():
            addr = acct.get('address', '')
            result.append({
                'scope': scope,
                'name': scope,
                'value': scope,
                'label': addr or scope,
                'address': addr,
                'auth_type': acct.get('auth_type', 'password'),
                'imap_server': acct.get('imap_server', ''),
                'smtp_server': acct.get('smtp_server', ''),
                'imap_port': acct.get('imap_port', 993),
                'smtp_port': acct.get('smtp_port', 465),
            })
        return result

    # ── Twilio voice accounts (multi-number SIP) ──────────────────────────────
    def get_twilio_account(self, scope: str = 'default') -> dict:
        """Get a Twilio SIP account by scope. Secrets are unscrambled on read."""
        acct = self._credentials.get('twilio_accounts', {}).get(scope, {})
        return {
            'sip_domain': acct.get('sip_domain', ''),
            'sip_user': acct.get('sip_user', ''),
            'sip_pass': self._unscramble(acct.get('sip_pass', '')),
            'number': acct.get('number', ''),
            'chat': acct.get('chat', 'default'),
            'greeting': acct.get('greeting', ''),
            'account_sid': acct.get('account_sid', ''),
            'auth_token': self._unscramble(acct.get('auth_token', '')),
            'transport': acct.get('transport', 'tls'),
            'call_provider': acct.get('call_provider', ''),
            'call_model': acct.get('call_model', ''),
            'elevate_key': self._unscramble(acct.get('elevate_key', '')),
            'elevate_toolset': acct.get('elevate_toolset', ''),
        }

    def set_twilio_account(self, scope: str, sip_domain: str, sip_user: str,
                           sip_pass: str, number: str = '', chat: str = 'default',
                           greeting: str = '', account_sid: str = '',
                           auth_token: str = '', transport: str = 'tls',
                           call_provider: str = '', call_model: str = '',
                           elevate_key: str = '', elevate_toolset: str = '') -> bool:
        """Create/update a Twilio account. sip_pass and auth_token (the REST
        API secret for outbound calls) are scrambled before save."""
        with self._lock:
            try:
                if 'twilio_accounts' not in self._credentials:
                    self._credentials['twilio_accounts'] = {}
                self._credentials['twilio_accounts'][scope] = {
                    'sip_domain': sip_domain,
                    'sip_user': sip_user,
                    'sip_pass': self._scramble(sip_pass) if sip_pass else '',
                    'number': number,
                    'chat': chat,
                    'greeting': greeting,
                    'account_sid': account_sid,
                    'auth_token': self._scramble(auth_token) if auth_token else '',
                    'transport': transport if transport in ('tls', 'udp') else 'tls',
                    'call_provider': call_provider,
                    'call_model': call_model,
                    'elevate_key': self._scramble(elevate_key) if elevate_key else '',
                    'elevate_toolset': elevate_toolset,
                }
                if not self._save():
                    logger.error(f"Failed to persist twilio account '{scope}'")
                    return False
                logger.info(f"Set twilio account for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set twilio account '{scope}': {e}")
                return False

    def delete_twilio_account(self, scope: str) -> bool:
        """Remove a Twilio account by scope."""
        with self._lock:
            accounts = self._credentials.get('twilio_accounts', {})
            if scope not in accounts:
                return False
            del accounts[scope]
            if not self._save():
                logger.error(f"Failed to persist deletion of twilio account '{scope}'")
                return False
            logger.info(f"Deleted twilio account '{scope}'")
            return True

    # ── Discord bot accounts (plugins/discord, 2026-09-22): label → bot token ──

    def get_discord_account(self, name: str) -> dict:
        """One Discord bot account by its label; the token is unscrambled on read.
        Empty dict when unknown."""
        acct = self._credentials.get('discord_accounts', {}).get(name)
        if not acct:
            return {}
        return {
            'name': name,
            'token': self._unscramble(acct.get('token', '')),
            'bot_name': acct.get('bot_name', ''),
            'bot_id': acct.get('bot_id', ''),
            'created_at': acct.get('created_at', 0.0),
        }

    def set_discord_account(self, name: str, *, token: str = None, bot_name: str = None,
                            bot_id: str = None, created_at: float = None) -> bool:
        """Create or update a Discord bot account. Fields left None keep their
        stored value; the token is scrambled before save; created_at is set once."""
        import time as _time
        with self._lock:
            try:
                accounts = self._credentials.setdefault('discord_accounts', {})
                acct = dict(accounts.get(name) or {})
                if token is not None:
                    acct['token'] = self._scramble(token) if token else ''
                if bot_name is not None:
                    acct['bot_name'] = str(bot_name)
                if bot_id is not None:
                    acct['bot_id'] = str(bot_id)
                if not acct.get('created_at'):
                    acct['created_at'] = float(created_at) if created_at else _time.time()
                accounts[name] = acct
                if not self._save():
                    logger.error(f"Failed to persist discord account '{name}'")
                    return False
                logger.info(f"Set discord account '{name}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set discord account '{name}': {e}")
                return False

    def delete_discord_account(self, name: str) -> bool:
        with self._lock:
            accounts = self._credentials.get('discord_accounts', {})
            if name not in accounts:
                return False
            del accounts[name]
            if not self._save():
                logger.error(f"Failed to persist deletion of discord account '{name}'")
                return False
            logger.info(f"Deleted discord account '{name}'")
            return True

    def list_discord_accounts(self) -> list:
        """Discord bot accounts (no tokens) — for the accounts page and the scope dropdown."""
        accounts = self._credentials.get('discord_accounts', {})
        return [{'name': name, 'bot_name': acct.get('bot_name', ''), 'bot_id': acct.get('bot_id', ''),
                 'created_at': acct.get('created_at', 0.0)} for name, acct in sorted(accounts.items())]

    # ── Plugin accounts (2026-11-02): ONE encrypted account store for every plugin ──
    # plugin_accounts[plugin][name] = {'fields': {plain}, 'secrets': {k: 'enc:..'}, 'created_at': t}
    # A new plugin with accounts uses this instead of a hand-written section above
    # (social is the first). Plugin state (user/plugin_state) is plaintext and inside
    # backups; this file is neither. Names may hold '/' so "profile/connection" works.

    _PLUGIN_ACCT_RE = re.compile(r'[a-z0-9][a-z0-9_./-]{0,80}$')

    def _plugin_acct_ok(self, plugin: str, name: str = None) -> bool:
        if not self._PLUGIN_ACCT_RE.fullmatch(str(plugin or '')):
            logger.warning(f"plugin account: bad plugin name {plugin!r}")
            return False
        if name is not None and not self._PLUGIN_ACCT_RE.fullmatch(str(name or '')):
            logger.warning(f"plugin account: bad account name {name!r}")
            return False
        return True

    def get_plugin_account(self, plugin: str, name: str) -> dict:
        """One account with its secrets in the clear: {'name', 'fields', 'secrets',
        'created_at'}; {} when unknown. A secret this machine cannot unscramble
        comes back as '' (the warning names it) - the caller sees 'not set'."""
        if not self._plugin_acct_ok(plugin, name):
            return {}
        acct = self._credentials.get('plugin_accounts', {}).get(plugin, {}).get(name)
        if not acct:
            return {}
        secrets = {}
        for k, v in (acct.get('secrets') or {}).items():
            try:
                secrets[k] = self._unscramble_strict(v) if v else ''
            except DecryptionError:
                logger.warning(f"plugin account {plugin}/{name}: secret '{k}' cannot be read on this machine")
                secrets[k] = ''
        return {'name': name, 'fields': dict(acct.get('fields') or {}),
                'secrets': secrets, 'created_at': acct.get('created_at', 0.0)}

    def set_plugin_account(self, plugin: str, name: str, fields: dict = None,
                           secrets: dict = None) -> bool:
        """Create or update one account. `fields` (plain) merge over the stored
        ones; `secrets` merge too: a str replaces, '' clears, None keeps.
        Secrets are scrambled before save; created_at is set once."""
        import time as _time
        if not self._plugin_acct_ok(plugin, name):
            return False
        if fields is not None and not isinstance(fields, dict):
            return False
        if secrets is not None and not isinstance(secrets, dict):
            return False
        with self._lock:
            try:
                table = self._credentials.setdefault('plugin_accounts', {}).setdefault(plugin, {})
                acct = dict(table.get(name) or {})
                acct['fields'] = dict(acct.get('fields') or {})
                acct['secrets'] = dict(acct.get('secrets') or {})
                for k, v in (fields or {}).items():
                    if v is None:
                        acct['fields'].pop(k, None)
                    else:
                        acct['fields'][str(k)] = v
                for k, v in (secrets or {}).items():
                    if v is None:
                        continue
                    if v == '':
                        acct['secrets'].pop(k, None)
                    else:
                        acct['secrets'][str(k)] = self._scramble(str(v))
                json.dumps(acct['fields'])              # JSON-safe or refused
                if not acct.get('created_at'):
                    acct['created_at'] = _time.time()
                table[name] = acct
                if not self._save():
                    logger.error(f"Failed to persist plugin account {plugin}/{name}")
                    return False
                logger.info(f"Set plugin account {plugin}/{name}")
                return True
            except Exception as e:
                logger.error(f"Failed to set plugin account {plugin}/{name}: {e}")
                return False

    def delete_plugin_account(self, plugin: str, name: str) -> bool:
        if not self._plugin_acct_ok(plugin, name):
            return False
        with self._lock:
            table = self._credentials.get('plugin_accounts', {}).get(plugin, {})
            if name not in table:
                return False
            del table[name]
            if not self._save():
                logger.error(f"Failed to persist deletion of plugin account {plugin}/{name}")
                return False
            logger.info(f"Deleted plugin account {plugin}/{name}")
            return True

    def rename_plugin_account(self, plugin: str, old: str, new: str) -> bool:
        """Move an account to a new name. Never overwrites."""
        if not self._plugin_acct_ok(plugin, old) or not self._plugin_acct_ok(plugin, new):
            return False
        with self._lock:
            table = self._credentials.get('plugin_accounts', {}).get(plugin, {})
            if old == new or old not in table:
                return old == new and old in table
            if new in table:
                return False
            table[new] = table.pop(old)
            if self._save():
                return True
            table[old] = table.pop(new)
            return False

    def list_plugin_accounts(self, plugin: str) -> list:
        """Every account of a plugin, no secret values: [{'name', 'fields',
        'secrets': [names set], 'created_at'}], sorted by name."""
        if not self._plugin_acct_ok(plugin):
            return []
        table = self._credentials.get('plugin_accounts', {}).get(plugin, {})
        return [{'name': n, 'fields': dict(a.get('fields') or {}),
                 'secrets': sorted((a.get('secrets') or {}).keys()),
                 'created_at': a.get('created_at', 0.0)} for n, a in sorted(table.items())]

    def has_plugin_account(self, plugin: str, name: str) -> bool:
        if not self._plugin_acct_ok(plugin, name):
            return False
        return name in self._credentials.get('plugin_accounts', {}).get(plugin, {})

    def list_twilio_accounts(self) -> list:
        """List Twilio accounts (no secrets) — for the account dropdown + UI."""
        accounts = self._credentials.get('twilio_accounts', {})
        result = []
        for scope, acct in accounts.items():
            result.append({
                'scope': scope,
                'name': scope,
                'value': scope,
                'label': acct.get('number') or acct.get('sip_user') or scope,
                'number': acct.get('number', ''),
                'sip_domain': acct.get('sip_domain', ''),
                'sip_user': acct.get('sip_user', ''),
                'chat': acct.get('chat', 'default'),
                'greeting': acct.get('greeting', ''),
                'configured': bool(acct.get('sip_domain') and acct.get('sip_user') and acct.get('sip_pass')),
                'account_sid': acct.get('account_sid', ''),
                'rest_configured': bool(acct.get('account_sid') and acct.get('auth_token')),
                'transport': acct.get('transport', 'tls'),
                'call_provider': acct.get('call_provider', ''),
                'call_model': acct.get('call_model', ''),
                'elevate_configured': bool(acct.get('elevate_key')),
                'elevate_toolset': acct.get('elevate_toolset', ''),
            })
        return result

    def set_email_oauth_account(self, scope: str, address: str,
                                imap_server: str, smtp_server: str,
                                imap_port: int, smtp_port: int,
                                oauth_client_id: str, oauth_client_secret: str,
                                oauth_tenant_id: str, oauth_refresh_token: str,
                                oauth_access_token: str = '', oauth_expires_at: float = 0) -> bool:
        """Set an OAuth2-authenticated email account for a scope."""
        with self._lock:
            try:
                if 'email_accounts' not in self._credentials:
                    self._credentials['email_accounts'] = {}

                self._credentials['email_accounts'][scope] = {
                    'address': address,
                    'auth_type': 'oauth2',
                    'imap_server': imap_server,
                    'smtp_server': smtp_server,
                    'imap_port': imap_port,
                    'smtp_port': smtp_port,
                    'oauth_client_id': oauth_client_id,
                    'oauth_client_secret': self._scramble(oauth_client_secret) if oauth_client_secret else '',
                    'oauth_tenant_id': oauth_tenant_id,
                    'oauth_refresh_token': self._scramble(oauth_refresh_token) if oauth_refresh_token else '',
                    'oauth_access_token': oauth_access_token,
                    'oauth_expires_at': oauth_expires_at,
                }

                if not self._save():
                    logger.error(f"Failed to persist OAuth email account '{scope}' to disk")
                    return False

                logger.info(f"Set OAuth email account for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set OAuth email account '{scope}': {e}")
                return False

    def update_email_oauth_tokens(self, scope: str, access_token: str, expires_at: float,
                                   refresh_token: str = '') -> bool:
        """Update OAuth tokens for an existing email account (called after token refresh)."""
        with self._lock:
            accounts = self._credentials.get('email_accounts', {})
            if scope not in accounts:
                return False
            acct = accounts[scope]
            acct['oauth_access_token'] = access_token
            acct['oauth_expires_at'] = expires_at
            if refresh_token:
                acct['oauth_refresh_token'] = self._scramble(refresh_token)
            return self._save()

    def has_email_account(self, scope: str = 'default') -> bool:
        """Check if email account exists and has credentials."""
        acct = self.get_email_account(scope)
        if acct.get('auth_type') == 'oauth2':
            return bool(acct['address'] and acct.get('oauth_refresh_token'))
        return bool(acct['address'] and acct['app_password'])

    # Backwards-compat wrappers (existing code uses these)
    def get_email_credentials(self) -> dict:
        return self.get_email_account('default')

    def set_email_credentials(self, address: str, app_password: str,
                              imap_server: str = 'imap.gmail.com',
                              smtp_server: str = 'smtp.gmail.com',
                              imap_port: int = 993,
                              smtp_port: int = 465) -> bool:
        return self.set_email_account('default', address, app_password, imap_server, smtp_server, imap_port, smtp_port)

    def clear_email_credentials(self) -> bool:
        return self.delete_email_account('default')

    def has_email_credentials(self) -> bool:
        return self.has_email_account('default')

    # =========================================================================
    # Bitcoin Wallets (multi-wallet, keyed by scope)
    # =========================================================================

    def get_bitcoin_wallet(self, scope: str = 'default') -> dict:
        """Get bitcoin wallet for a scope. WIF is unscrambled on read."""
        wallets = self._credentials.get('bitcoin_wallets', {})
        w = wallets.get(scope, {})
        return {
            'label': w.get('label', scope),
            'wif': self._unscramble(w.get('wif', '')),
        }

    def set_bitcoin_wallet(self, scope: str, wif: str, label: str = '') -> bool:
        """Set bitcoin wallet for a scope. WIF is scrambled before save."""
        with self._lock:
            try:
                if 'bitcoin_wallets' not in self._credentials:
                    self._credentials['bitcoin_wallets'] = {}

                self._credentials['bitcoin_wallets'][scope] = {
                    'label': label or scope,
                    'wif': self._scramble(wif) if wif else '',
                }

                if not self._save():
                    logger.error(f"Failed to persist bitcoin wallet '{scope}' to disk")
                    return False

                logger.info(f"Set bitcoin wallet for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set bitcoin wallet '{scope}': {e}")
                return False

    def delete_bitcoin_wallet(self, scope: str) -> bool:
        """Remove a bitcoin wallet by scope."""
        with self._lock:
            wallets = self._credentials.get('bitcoin_wallets', {})
            if scope not in wallets:
                return False
            del wallets[scope]
            if not self._save():
                logger.error(f"Failed to persist deletion of bitcoin wallet '{scope}'")
                return False
            logger.info(f"Deleted bitcoin wallet '{scope}'")
            return True

    def list_bitcoin_wallets(self) -> list:
        """List all bitcoin wallets (no WIFs). Derives address from stored key."""
        wallets = self._credentials.get('bitcoin_wallets', {})
        result = []
        for scope, w in wallets.items():
            # Derive address from WIF for display
            address = ''
            wif = self._unscramble(w.get('wif', ''))
            if wif:
                try:
                    from bit import Key
                    address = Key(wif).address
                except Exception:
                    address = '(invalid key)'
            result.append({
                'scope': scope,
                'label': w.get('label', scope),
                'address': address,
            })
        return result

    def has_bitcoin_wallet(self, scope: str = 'default') -> bool:
        """Check if bitcoin wallet exists for scope."""
        w = self.get_bitcoin_wallet(scope)
        return bool(w['wif'])

    # =========================================================================
    # Google Calendar
    # =========================================================================

    def get_gcal_account(self, scope: str = 'default') -> dict:
        """Get Google Calendar account for a scope. Tokens are unscrambled on read."""
        accounts = self._credentials.get('gcal_accounts', {})
        acct = accounts.get(scope, {})
        return {
            'client_id': acct.get('client_id', ''),
            'client_secret': self._unscramble(acct.get('client_secret', '')),
            'refresh_token': self._unscramble(acct.get('refresh_token', '')),
            'calendar_id': acct.get('calendar_id', 'primary'),
            'label': acct.get('label', scope),
            'auth_mode': acct.get('auth_mode', 'byo'),
            'relay_url': acct.get('relay_url', ''),
        }

    def set_gcal_account(self, scope: str, client_id: str, client_secret: str,
                         calendar_id: str = 'primary', refresh_token: str = '',
                         label: str = '', auth_mode: str = 'byo',
                         relay_url: str = '') -> bool:
        """Set Google Calendar account for a scope. Secrets are scrambled before save.

        auth_mode 'byo' = user's own Google client (client_id/secret stored
        here); 'relay' = easy connect — no local client creds, token exchange
        and refresh go through relay_url (frozen at connect time, same as
        client creds are for byo)."""
        with self._lock:
            try:
                if 'gcal_accounts' not in self._credentials:
                    self._credentials['gcal_accounts'] = {}

                self._credentials['gcal_accounts'][scope] = {
                    'client_id': client_id,
                    'client_secret': self._scramble(client_secret) if client_secret else '',
                    'refresh_token': self._scramble(refresh_token) if refresh_token else '',
                    'calendar_id': calendar_id or 'primary',
                    'label': label or scope,
                    'auth_mode': auth_mode or 'byo',
                    'relay_url': relay_url,
                }

                if not self._save():
                    logger.error(f"Failed to persist gcal account '{scope}' to disk")
                    return False

                logger.info(f"Set gcal account for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set gcal account '{scope}': {e}")
                return False

    def update_gcal_tokens(self, scope: str, refresh_token: str, access_token: str = '', expires_at: float = 0) -> bool:
        """Update OAuth tokens for an existing gcal account (called after OAuth callback).

        Truthy-guard on refresh_token: if caller passes empty string, the
        existing refresh_token is PRESERVED — this is deliberate for the
        routine refresh path (new access_token, same refresh_token). To
        actually clear (disconnect), use `clear_gcal_tokens(scope)` instead
        — passing empty strings here does NOT clear. Scout finding (GCal #3
        follow-up) — the disconnect path was accidentally preserving the
        refresh_token because of this exact guard.
        """
        with self._lock:
            accounts = self._credentials.get('gcal_accounts', {})
            if scope not in accounts:
                return False
            accounts[scope]['refresh_token'] = self._scramble(refresh_token) if refresh_token else accounts[scope].get('refresh_token', '')
            accounts[scope]['access_token'] = access_token  # Short-lived, no need to encrypt
            accounts[scope]['expires_at'] = expires_at
            return self._save()

    def clear_gcal_tokens(self, scope: str) -> bool:
        """Unconditionally clear all OAuth tokens for a scope — disconnect path.
        Keeps the account config (client_id, client_secret, calendar_id) so the
        user can re-authorize without re-entering credentials, but the refresh
        token is really gone. See update_gcal_tokens docstring for why this
        dedicated method exists."""
        with self._lock:
            accounts = self._credentials.get('gcal_accounts', {})
            if scope not in accounts:
                return False
            accounts[scope]['refresh_token'] = ''
            accounts[scope]['access_token'] = ''
            accounts[scope]['expires_at'] = 0
            return self._save()

    def get_gcal_tokens_snapshot(self, scope: str) -> dict:
        """Return access_token + expires_at for a gcal scope under the
        credentials lock. Used by the token-refresh path so read/write on
        the short-lived cache don't race with concurrent updates.
        Refresh_token is returned separately via get_gcal_account()."""
        with self._lock:
            accounts = self._credentials.get('gcal_accounts', {})
            acct = accounts.get(scope, {})
            return {
                'access_token': acct.get('access_token', ''),
                'expires_at': acct.get('expires_at', 0),
            }

    def delete_gcal_account(self, scope: str) -> bool:
        """Remove a Google Calendar account by scope."""
        with self._lock:
            accounts = self._credentials.get('gcal_accounts', {})
            if scope not in accounts:
                return False
            del accounts[scope]
            if not self._save():
                return False
            logger.info(f"Deleted gcal account '{scope}'")
            return True

    def list_gcal_accounts(self) -> list:
        """List all gcal accounts (no secrets)."""
        accounts = self._credentials.get('gcal_accounts', {})
        result = []
        for scope, acct in accounts.items():
            result.append({
                'scope': scope,
                'label': acct.get('label', scope),
                'client_id': acct.get('client_id', ''),  # Not secret — shown in OAuth URLs
                'calendar_id': acct.get('calendar_id', 'primary'),
                'has_token': bool(acct.get('refresh_token', '')),
            })
        return result

    def has_gcal_account(self, scope: str = 'default') -> bool:
        """Check if gcal account exists and has a refresh token.
        Relay (easy-connect) accounts have no local client_id by design."""
        acct = self.get_gcal_account(scope)
        if not acct['refresh_token']:
            return False
        return bool(acct['client_id']) or acct['auth_mode'] == 'relay'

    # =========================================================================
    # GitHub
    # =========================================================================

    def get_github_account(self, scope: str = 'default') -> dict:
        """Get GitHub account for a scope. PAT is unscrambled on read."""
        accounts = self._credentials.get('github_accounts', {})
        acct = accounts.get(scope, {})
        return {
            'username': acct.get('username', ''),
            'pat': self._unscramble(acct.get('pat', '')),
            'label': acct.get('label', scope),
        }

    def set_github_account(self, scope: str, username: str, pat: str, label: str = '') -> bool:
        """Set GitHub account for a scope. PAT is scrambled before save.
        If pat is empty string, the existing stored PAT is preserved."""
        with self._lock:
            try:
                if 'github_accounts' not in self._credentials:
                    self._credentials['github_accounts'] = {}

                existing = self._credentials['github_accounts'].get(scope, {})
                stored_pat = existing.get('pat', '') if not pat else self._scramble(pat)

                self._credentials['github_accounts'][scope] = {
                    'username': username,
                    'pat': stored_pat,
                    'label': label or scope,
                }

                if not self._save():
                    logger.error(f"Failed to persist github account '{scope}' to disk")
                    return False

                logger.info(f"Set github account for scope '{scope}'")
                return True
            except Exception as e:
                logger.error(f"Failed to set github account '{scope}': {e}")
                return False

    def delete_github_account(self, scope: str) -> bool:
        """Remove a GitHub account by scope."""
        with self._lock:
            accounts = self._credentials.get('github_accounts', {})
            if scope not in accounts:
                return False
            del accounts[scope]
            if not self._save():
                return False
            logger.info(f"Deleted github account '{scope}'")
            return True

    def list_github_accounts(self) -> list:
        """List all github accounts (no PATs)."""
        accounts = self._credentials.get('github_accounts', {})
        result = []
        for scope, acct in accounts.items():
            result.append({
                'scope': scope,
                'label': acct.get('label', scope),
                'username': acct.get('username', ''),
                'has_token': bool(acct.get('pat', '')),
            })
        return result

    def has_github_account(self, scope: str = 'default') -> bool:
        """Check if github account exists and has a PAT."""
        acct = self.get_github_account(scope)
        return bool(acct['pat'])

    # =========================================================================
    # SSH
    # =========================================================================

    def get_ssh_servers(self) -> list:
        """Get list of configured SSH servers."""
        ssh = self._credentials.get('ssh', {})
        return ssh.get('servers', [])

    def get_ssh_server(self, name: str) -> dict | None:
        """Get a single SSH server by friendly name (case-insensitive)."""
        for s in self.get_ssh_servers():
            if s.get('name', '').lower() == name.lower():
                return s
        return None

    def set_ssh_servers(self, servers: list) -> bool:
        """Replace the full SSH servers list."""
        with self._lock:
            try:
                if 'ssh' not in self._credentials:
                    self._credentials['ssh'] = {}
                self._credentials['ssh']['servers'] = servers
                if not self._save():
                    logger.error("Failed to persist SSH servers to disk")
                    return False
                logger.info(f"Saved {len(servers)} SSH servers")
                return True
            except Exception as e:
                logger.error(f"Failed to set SSH servers: {e}")
                return False

    # =========================================================================
    # Utility
    # =========================================================================
    
    def get_masked_summary(self) -> dict:
        """
        Get credentials summary with masked values for UI display.
        
        Shows which credentials are set without exposing actual values.
        """
        summary = {
            "llm": {},
            "socks": {
                "has_credentials": self.has_socks_credentials()
            },
            "homeassistant": {
                "has_token": self.has_ha_token()
            },
            "email": {
                "has_credentials": self.has_email_account('default'),
                "accounts": len(self._credentials.get('email_accounts', {}))
            },
            "plugins": {p: len(t) for p, t in self._credentials.get('plugin_accounts', {}).items()}
        }
        
        for provider in self._credentials.get('llm', {}):
            summary['llm'][provider] = {
                "has_key": self.has_llm_api_key(provider)
            }
        
        return summary
    
    def reload(self):
        """Reload credentials from disk."""
        self._load()


# Singleton instance
credentials = CredentialsManager()