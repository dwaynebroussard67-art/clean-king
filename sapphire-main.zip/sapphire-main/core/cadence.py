"""core/cadence.py — the cadence organ (Game Room F3, 2026-09-09).

Her UNPROMPTED turns: on a random clock between a min and max gap (watching
you play Doom, a movie), or on game events (a wave cleared), each one a real
turn on the chat it's armed for — the same door the wake word and the phone
use (begin_stream by name + chat_stream, VOICE_TURN events so an open room
streams it live, Stop works, other tabs mirror). Turn-based games never arm.

One organ, one ticker thread, per-chat records. Rules:
  - a record is ARMED by a room (or a plugin) with a TTL and kept alive by
    its keepalive; the tab dying = the record expiring = silence
  - never two turns on one chat: her own live stream on that chat = skip,
    and the gap STRETCHES toward max after repeated skips
  - frames come from the perception inbox at fire time (latest wins) and
    reach the model for that turn only (`images_ephemeral`)
  - `speak`: 'browser' rides the VOICE_TURN_END payload (the room's tab
    plays it), 'device:<id>' speaks it on that device (a satellite),
    'speakers' speaks the blob on the server after the turn

This is also the seat for heartbeats / Discord proactive / her pinging Krem
later — nothing in here knows what a game is.
"""
import logging
import random
import re
import threading
import time
import uuid

from core.event_bus import publish, Events
from core import perception

logger = logging.getLogger(__name__)

TICK_S = 1.0
DEFAULT_TTL = 90.0
MODES = ('off', 'turn', 'event', 'timer')
EVENT_FLOOR_S = 3.0      # event mode's only clock: a breath between her turns, not a knob
# A thinking model that never leaves its <think> block: past this many chars
# of unfinished thinking the turn is cancelled and the pair dropped — an
# unattended turn has no one to wait for it (Krem's 8K-token think loop
# that then read the inside of the tag aloud, 2026-09-09).
THINK_BUDGET_CHARS = 32000
# (6000 until 2026-10-12: Qwen spends 3K in think tags on an ordinary turn; a room guest was
# cut off three turns running. 32000 is about 8K tokens: a brake for a true runaway, no more.)

_lock = threading.RLock()
_records = {}                   # chat -> dict
_system = None


class Unreadable(RuntimeError):
    """The chat exists but its row cannot be read at this moment (a locked
    database, a WAL hiccup): the caller holds the turn and tries again."""


class Unreachable(RuntimeError):
    """run_turn's chat is missing, sealed or unreadable. A TYPE, so the inbox
    drops the item on exactly this and treats every other failure (a provider's
    "model not found") as a failed turn - matching the message text turned real
    errors into silent drops (chaos + day-ruiner scouts, 2026-10-07)."""
_thread = None
_listening = False              # the AI_TYPING_END hook is registered once per process
_stop = threading.Event()


def _now():
    return time.time()


def _gap(rec, stretch=False):
    lo, hi = float(rec['min_s']), float(rec['max_s'])
    if hi < lo:
        hi = lo
    g = random.uniform(lo, hi)
    if stretch and rec['skips']:
        g = min(hi, g * (1 + 0.5 * rec['skips']))
    return g


def visible_text(text):
    """What she actually said: think blocks gone (closed, unclosed, or an
    orphaned close from a stream that opened before we looked)."""
    from core import think
    return think.strip(text)


def _unfinished_thinking(buf):
    """Chars of thinking still open at the end of `buf` (0 = none open)."""
    from core import think
    return think.unfinished(buf)


def silence(text, errored, cancelled, overthought, finish, tools):
    """Why a turn has no words, in words ('' when it has words, or failed):
    the one thing a door's asker, a room's log and the END event can say
    about a silent turn. Three silent guest turns in a row once looked like
    lost lines, and nothing on either box said why (field report 2026-10-12).
    The budget cut is this lane's own; a length finish is the model's ceiling
    (a reasoning model thinking to max_tokens); tools with no words is a move."""
    from core.chat.llm_providers.base import LENGTH_FINISH
    if text or errored:
        return ''
    if overthought:
        return f'thinking never finished (past {THINK_BUDGET_CHARS} chars with no words, cut off here)'
    if cancelled:
        return 'stopped'
    if finish in LENGTH_FINISH:
        return f'the model hit its reply token limit (finish={finish}) before any words'
    if tools:
        return f"ran {', '.join(tools)} and ended without words"
    return 'empty answer'


def _live_row_count(sm, chat):
    """Rows on the live chat's list, or None when `chat` isn't the live one
    (by-name row surgery is later — those rows stay and get logged)."""
    try:
        if sm.get_active_chat_name() == chat:
            return len(sm.current_chat.messages)
    except Exception:
        pass
    return None


def _drop_last_turn(chat, reason, count):
    """A no-answer turn leaves no trace: every row THIS turn added goes (the
    cue row + her think-only row — or more: a turn that ran a tool is four
    rows, and dropping a fixed two left an assistant tool_call without its
    tool row = provider 400 next turn; scout 3, 2026-09-10). `count` is the
    live list's growth measured around the turn; 0/None = nothing known to
    drop, so nothing is touched — a wrong count could eat the user's rows."""
    try:
        if not count or count <= 0:
            logger.info(f"[CADENCE] '{chat}': {reason} — rows left in place (chat not live)")
            return False
        sm = _system.llm_chat.session_manager
        ok = sm.remove_last_messages(count)
        logger.info(f"[CADENCE] '{chat}': {reason} — {count} row(s) dropped ({'ok' if ok else 'nothing to drop'})")
        return bool(ok)
    except Exception as e:
        logger.warning(f"[CADENCE] '{chat}': drop after {reason} failed: {e}")
    return False


def default_prompt(percept):
    """The cue when the arming party gave none."""
    lines = []
    if percept and percept.get('text'):
        lines.append(percept['text'])
    lines.append("(Your turn — nobody spoke. You're watching. Say what you'd say out loud right now, briefly; a word or two is fine.)")
    return '\n'.join(lines)


def arm(chat, *, mode='timer', min_s=60, max_s=180, paused=False, send_frames=False,
        frames_per_tick=6, every=1, ttl=DEFAULT_TTL, owner=None, prompt=None, speak=None, title=None):
    """(Re)arm her unprompted turns on `chat`. Idempotent: an armed record
    keeps its clock (and its poke count) unless the range changed; the TTL
    always extends. Modes 'off' and 'turn' disarm (turn = she answers moves
    through the seat instead). `every` = event mode fires on every Nth poke
    (a wave game at every 3rd wave); event mode ignores min/max — its floor
    is EVENT_FLOOR_S, the organ's own (one lever per nature, Krem
    2026-09-10: every-N is the frequency, a random clock is the timer's).
    Returns status()."""
    if not chat:
        return None
    mode = mode if mode in MODES else 'timer'
    if mode in ('off', 'turn'):
        disarm(chat)
        return status(chat)
    if mode == 'event':
        min_s = max_s = EVENT_FLOOR_S
    with _lock:
        rec = _records.get(chat)
        fresh = rec is None
        if fresh:
            rec = _records[chat] = {
                'chat': chat, 'last_at': None, 'skips': 0, 'pending': None,
                'running': False, 'next_at': None, 'fired': 0, 'pokes': 0,
            }
        range_changed = (not fresh) and (rec.get('min_s') != min_s or rec.get('max_s') != max_s or rec.get('mode') != mode)
        rec.update({
            'mode': mode, 'min_s': max(1.0, float(min_s)), 'max_s': max(1.0, float(max_s)),
            'paused': bool(paused), 'send_frames': bool(send_frames),
            'frames_per_tick': int(frames_per_tick or 1), 'every': max(1, int(every or 1)),
            'ttl_until': _now() + float(ttl),
            'owner': owner, 'prompt': prompt, 'speak': speak, 'title': title,
        })
        if mode == 'timer' and (fresh or range_changed or rec['next_at'] is None):
            rec['next_at'] = _now() + _gap(rec)
        if mode == 'event':
            rec['next_at'] = None
    logger.info(f"[CADENCE] armed '{chat}': {mode} {min_s}-{max_s}s"
                f"{' paused' if paused else ''}{' frames' if send_frames else ''} ({owner})")
    return status(chat)


def disarm(chat, owner=None):
    with _lock:
        rec = _records.get(chat)
        if not rec:
            return False
        if owner and rec.get('owner') and rec['owner'] != owner:
            return False
        del _records[chat]
    perception.clear(chat)
    logger.info(f"[CADENCE] disarmed '{chat}'")
    return True


def pause(chat, paused=True):
    with _lock:
        rec = _records.get(chat)
        if not rec:
            return None
        rec['paused'] = bool(paused)
        if not paused and rec['mode'] == 'timer' and rec['next_at'] is not None and rec['next_at'] < _now():
            rec['next_at'] = _now() + _gap(rec)     # resume = a fresh gap, not an instant turn
    return status(chat)


def poke(chat, note=None, force=False):
    """An event: 'a moment happened'. Event mode fires once the min gap has
    passed since her last turn — on every Nth poke when armed with `every`
    (the count runs from the last poke that became her turn); `force` marks
    a terminal moment (the castle fell) that always comes through. Timer
    mode pulls the next turn forward to that same floor."""
    with _lock:
        rec = _records.get(chat)
        if not rec:
            return None
        if rec['mode'] == 'event' and not force and (rec['pokes'] + 1) % rec['every']:
            rec['pokes'] += 1                 # counted, not yet her turn
            return _status_locked(rec)
        rec['pokes'] = 0
        rec['pending'] = str(note or '')[:400] or True
        if rec['mode'] == 'timer':
            floor = (rec['last_at'] or 0) + rec['min_s']
            rec['next_at'] = min(rec['next_at'] or floor, max(floor, _now()))
    return status(chat)


def touch(chat):
    """Someone spoke on the chat and she answered (a typed line at the
    table, a talk button): her next unprompted turn waits a fresh gap from
    now, and a pending moment waits the min gap too. Her own cadence turn
    is not a touch (`running`) — _fire sets its own clock. Returns status().
    Wired to AI_TYPING_END in start() (Krem 2026-10-10: talking to her
    resets her countdown)."""
    with _lock:
        rec = _records.get(chat)
        if not rec or rec['running']:
            return None
        rec['last_at'] = _now()
        rec['skips'] = 0
        if rec['mode'] == 'timer':
            rec['next_at'] = _now() + _gap(rec)
    return status(chat)


def status(chat):
    with _lock:
        rec = _records.get(chat)
        if not rec:
            return {'armed': False, 'chat': chat}
        return _status_locked(rec)


def _status_locked(rec):
    chat, nxt = rec['chat'], rec['next_at']
    return {
            'armed': True, 'chat': chat, 'mode': rec['mode'], 'paused': rec['paused'],
            'min_s': rec['min_s'], 'max_s': rec['max_s'], 'send_frames': rec['send_frames'],
            'frames_per_tick': rec['frames_per_tick'], 'every': rec['every'], 'pokes': rec['pokes'],
            'next_in': (max(0.0, nxt - _now()) if (nxt and not rec['paused']) else None),
            'last_at': rec['last_at'], 'skips': rec['skips'], 'running': rec['running'],
            'pending': bool(rec['pending']), 'fired': rec['fired'],
            'ttl_in': max(0.0, rec['ttl_until'] - _now()),
        }


def armed():
    with _lock:
        return sorted(_records)


# ── the turn ────────────────────────────────────────────────────────────────

def run_turn(chat, text, images=None, speak=None, source='cadence', on_event=None,
             stream_speech=False, keep_prompt=False, brain=None, on_stream=None, quiet=False,
             keep_images=False):
    """One unprompted turn on `chat` through THE engine, live to the wire.
    Raises ChatBusy when the chat has a turn in flight. Returns her text.
    on_event(event) sees every event of THIS turn as it happens (the bus
    cannot say whose turn a tool belongs to). Its faults are swallowed.
    keep_prompt=True: the prompt row IS the record (an agent's report, an MCP
    message, a call transcript, a MIDI take) - it stays in history even when
    her answer comes back empty or is stopped. Default False keeps cadence's
    own rule for its worthless prompts: no answer, no trace (2026-10-07).
    stream_speech=True (a device lane): her voice is made sentence by
    sentence while she writes, as `tts_chunk` events on_event takes to the
    device; the lane below speaks the whole reply only when no sentence was
    made (no voice engine, a refused chat, every sentence dropped).
    brain: a caller-built stream brain the engine takes over the chat's
    stored settings (core/rooms.py: a seat's fenced prompt, tools and
    settings on her own chat's session). on_stream(stream): the stream the
    moment it exists, for a caller that must be able to cut it (Stop, a seat
    clock). quiet=True: no VOICE_TURN events from here - the caller paints
    the turn itself from on_event (a room, under the seat's name).
    keep_images=True: the images are a pasted picture, not a glance - they go
    into the chat's image store and stay in history (a photo shared from a
    phone, 2026-10-12). Default False keeps them model-only for this turn."""
    system = _system
    if system is None:
        raise RuntimeError('cadence organ not started')
    _pub = (lambda *a, **k: None) if quiet else publish
    llm = system.llm_chat
    sm = llm.session_manager
    # Reachable first, before anything is published: a missing, sealed or
    # unreadable chat used to get its text sent over SSE as VOICE_TURN_START
    # and only THEN refused inside chat_stream (scout C, 2026-10-06). Gone or
    # sealed is Unreachable (the item is dropped); a database that cannot be
    # read RIGHT NOW is Unreadable (the item is held and tried again) - the
    # inbox's put-time hold was undone here by the same None for both (second
    # scout wave, 2026-10-08).
    exists_fn = getattr(sm, 'chat_exists', None)
    try:
        exists = exists_fn(chat) if exists_fn is not None else True
    except Exception as e:
        raise Unreadable(f"chat '{chat}' can't be read right now ({type(e).__name__})")
    settings = sm.get_settings_for(chat) if exists else None
    if settings is None:
        raise Unreachable(f"chat '{chat}' isn't reachable (missing or sealed)")
    if settings.get('mode') == 'room':
        # a room's seats speak through core/rooms.py; her unprompted turn has
        # no brain there (which seat would it be?). A failed turn, not a drop.
        raise RuntimeError(f"'{chat}' is a chat room; nothing runs an unprompted turn on it")
    stream, sid, chat_name = llm.begin_stream(chat, exclusive=True)
    stream.turn_source = source          # whose turn: only a person lane stamps the person (core/idle.py)
    if brain is not None:
        stream.brain = brain
    if on_stream is not None:
        try:
            on_stream(stream)
        except Exception as e:
            logger.debug(f"[CADENCE] on_stream hook failed: {e}")
    sentences = 0                         # tts_chunk events this turn made
    parts, cancelled, errored, overthought = [], False, None, False
    blocks = []                    # the prose of each round that ended in a tool call: her message is all of them
    thinking_chars = 0             # provider-side thinking events (Claude-style)
    tools_ran = False              # a tool-only turn (a move, no words) is an answer
    tools, finish = [], None       # the tools that ran, in order; how the last LLM call ended
    final, dropped, rows_before = '', False, None
    mid = uuid.uuid4().hex
    foreign = False
    # Everything from here to the end of the history work runs inside ONE try
    # whose finally releases the registration: a raise in the setup below used
    # to leak the stream (the gate refused the chat forever, only Stop cured
    # it), and the drop-last-turn surgery used to run AFTER end_stream, where
    # the next turn's fresh user row could be the one deleted (scout A).
    try:
        if stream_speech and isinstance(speak, str) and speak.startswith('device:'):
            # the pump runs for THIS chat whatever the browser's streaming
            # setting says, split at sentences (first sound at the first
            # sentence, as on a phone call), gated by this chat's own settings
            stream.suppress_tts = False
            stream.tts_split_override = 'sentence'
            stream.tts_force = True
            stream.tts_plays_here = False     # the satellite is elsewhere: Play speech here does not govern it
            stream.tts_device = speak[len('device:'):]   # whose voice it is: a face stream carries it to that board alone
            stream.tts_chat_settings = sm.get_settings_for(chat) or {'private_chat': True}
        else:
            stream.suppress_tts = True        # the pump stays inert; the lane below speaks
        stream.images_ephemeral = not keep_images   # frames reach the model this turn only; a shared photo stays
        try:
            active = sm.get_active_chat_name()
        except Exception:
            active = None
        foreign = bool(chat and chat != active)
        _pub(Events.VOICE_TURN_START, {"message_id": mid, "user_text": text,
                                          "chat": chat, "foreign": foreign, "source": source})
        rows_before = _live_row_count(sm, chat)
        for ev in stream.chat_stream(text, images=images or None):
            if not isinstance(ev, dict):
                continue
            if on_event is not None:
                try:
                    on_event(ev)
                except Exception as e:
                    logger.debug(f"[CADENCE] on_event hook failed: {e}")
            et = ev.get('type')
            if et == 'content':
                parts.append(ev.get('text') or '')
                _pub(Events.VOICE_TURN_CHUNK, {"message_id": mid, "text": ev.get('text', ''),
                                                  "chat": chat, "foreign": foreign})
            elif et == 'thinking':
                thinking_chars += len(ev.get('text') or '')
            elif et == 'tool_start':
                # the words before a tool are a round of their own; the engine
                # starts the next round's prose from nothing, and its `final`
                # carries only the last round (Blue saw half of Purple, 2026-10-03)
                if visible_text(''.join(parts)):
                    blocks.append(''.join(parts))
                parts = []
                # the tab paints the accordion as it happens - before this the
                # tools of an agent-report turn appeared only after a refresh
                # (Krem, 2026-10-08). Same exposure class as the chunks above.
                _pub(Events.VOICE_TURN_TOOL, {"message_id": mid, "chat": chat, "foreign": foreign, "phase": "start",
                                                 "id": ev.get('id'), "name": ev.get('name'), "args": ev.get('args')})
            elif et == 'tool_end':
                tools_ran = True
                tools.append(str(ev.get('name') or '?'))
                _pub(Events.VOICE_TURN_TOOL, {"message_id": mid, "chat": chat, "foreign": foreign, "phase": "end",
                                                 "id": ev.get('id'), "name": ev.get('name'),
                                                 "result": ev.get('result'), "error": bool(ev.get('error'))})
            elif et == 'tts_chunk':
                sentences += 1
            elif et == 'final':
                cancelled = bool(ev.get('cancelled'))
                finish = ev.get('finish')
                if ev.get('error'):
                    # a refused turn (🔒 chat unreachable): the engine yields
                    # its notice as content — that is NOT her answer; it used
                    # to be captioned and spoken aloud (scout 3, 2026-09-10)
                    errored = ev.get('text') or 'turn refused'
                    parts, blocks = [], []
                elif ev.get('text'):
                    parts = [ev['text']]          # the last round as the engine kept it (prefill, post_llm)
            elif et == 'error':
                errored = ev.get('text') or 'stream error'
            # the thinking budget: in-content <think> that never closes, or
            # provider thinking with no content yet, past the budget = cancel
            if not overthought and not cancelled:
                buf = ''.join(parts)
                if _unfinished_thinking(buf) > THINK_BUDGET_CHARS or \
                        (thinking_chars > THINK_BUDGET_CHARS and not visible_text(buf)):
                    overthought = True
                    stream.cancel_flag = True
                    logger.warning(f"[CADENCE] '{chat}': thinking past {THINK_BUDGET_CHARS} chars with no answer — cancelled")
    except Exception as e:
        # chat_stream RE-RAISES provider/connection errors (chat_streaming
        # :1472/:1498). Without this, VOICE_TURN_END below never fired, and
        # the browser — which only clears its voice-turn latch on END — sat
        # wedged in Stop with every refresh suppressed (broadsword H8). The
        # error still surfaces: END carries it, then the raise below fires.
        from core.chat.chat import friendly_llm_error
        # in words where the error has a known shape (the app's one voice for
        # these, core/chat/chat.py): a room's notice and a door's asker read the
        # cause, not a provider's dump (a seat with no model loaded, 2026-10-13)
        errored = errored or friendly_llm_error(e) or f"{type(e).__name__}: {e}"
    finally:
        # The history work happens HERE, while this turn still holds the chat:
        # _drop_last_turn removes the last N live rows whoever wrote them, and
        # after end_stream the next turn (the inbox drains the instant the chat
        # frees up) may already have written its user row (scout A, 2026-10-06).
        try:
            rounds = [visible_text(b) for b in blocks + [''.join(parts)]]
            final = '\n\n'.join(r for r in rounds if r) if not cancelled or overthought else ''
            if overthought or (not final and not errored and not tools_ran):
                # no answer (a think loop, an empty reply): nothing to show or speak
                final = ''
                if not keep_prompt:
                    # ...or keep: cadence's own prompt rows go. A door's content
                    # row (keep_prompt) stays - Stop on an agent's report used to
                    # erase the report itself (day-ruiner scout, 2026-10-07).
                    rows_after = _live_row_count(sm, chat)
                    added = (rows_after - rows_before) if (rows_before is not None and rows_after is not None) else None
                    dropped = _drop_last_turn(chat, 'thinking never finished' if overthought else 'empty answer', added)
        except Exception as e:
            logger.warning(f"[CADENCE] '{chat}': end-of-turn history work failed: {e}")
        llm.end_stream(sid, chat_name)
    why = silence(final, errored, cancelled, overthought, finish, tools)
    if why and not overthought:                         # the budget cut warned above as it happened
        (logger.warning if 'token limit' in why else logger.info)(f"[CADENCE] '{chat}': no answer - {why}")
    if on_event is not None:
        # the turn's report, after the engine's own events: what she said, why she
        # said nothing, the tools that ran - for the asker at a door (an MCP ask)
        try:
            on_event({'type': 'turn_report', 'text': final, 'why': why, 'tools': list(tools), 'finish': finish})
        except Exception as e:
            logger.debug(f"[CADENCE] on_event hook failed: {e}")
    _pub(Events.VOICE_TURN_END, {"message_id": mid, "chat": chat, "foreign": foreign,
                                    "text": final,
                                    "speak": (speak if (final and not errored) else None),
                                    "source": source, "dropped": dropped, "why": why, "tools": list(tools)})
    if errored:
        raise RuntimeError(errored)
    if speak == 'speakers' and final:
        try:
            # The gate must judge THIS session's chat: the stream's brain
            # override is already reset, so a bare speak() would read the
            # operator's active chat (broadsword H3 ×2). A sealed/unreadable
            # chat fails closed.
            gate_settings = sm.get_settings_for(chat) or {'private_chat': True}
            system.tts.speak(final, chat_settings=gate_settings)
        except Exception as e:
            logger.warning(f"[CADENCE] speakers lane failed: {e}")
    elif isinstance(speak, str) and speak.startswith('device:') and final and not sentences:
        # the device lane: the reply is spoken on the satellite that heard
        # the question, whole, when none of it was spoken as it was made.
        # Same gate rule as above - THIS chat's settings.
        try:
            from core.devices import voice
            gate_settings = sm.get_settings_for(chat) or {'private_chat': True}
            said, ok = voice.say(speak[len('device:'):], final, chat_settings=gate_settings)
            if not ok:
                logger.warning(f"[CADENCE] device lane: {said}")
        except Exception as e:
            logger.warning(f"[CADENCE] device lane failed: {e}")
    return final


def fire_once(chat, text, images=None, speak=None, source='cadence'):
    """A single unprompted turn now. Raises ChatBusy if the chat is mid-turn.
    A caller that would rather wait its turn than fail uses the inbox
    (core/chat/inbox.py tell/ask) - every machine door moved there 2026-10-06;
    this stays for a caller that wants the refusal."""
    return run_turn(chat, text, images=images, speak=speak, source=source)


def _fire(rec):
    chat = rec['chat']
    from core.chat.chat import ChatBusy
    try:
        sm = _system.llm_chat.session_manager
        if sm.is_streaming(chat):
            raise ChatBusy(chat)
        percept = perception.take(chat)
        prompt = rec.get('prompt')
        if callable(prompt):
            text = prompt(percept, rec)
        else:
            text = default_prompt(percept)
        images = (percept or {}).get('frames') if rec['send_frames'] else None
        if images:
            images = images[-max(1, rec['frames_per_tick']):]
        run_turn(chat, text, images=images, speak=rec.get('speak'))
        with _lock:
            if _records.get(chat) is rec:
                rec['last_at'] = _now()
                rec['skips'] = 0
                rec['pending'] = None
                rec['fired'] += 1
                rec['next_at'] = (_now() + _gap(rec)) if rec['mode'] == 'timer' else None
    except ChatBusy:
        with _lock:
            if _records.get(chat) is rec:
                rec['skips'] += 1
                rec['next_at'] = _now() + _gap(rec, stretch=True)
        logger.info(f"[CADENCE] '{chat}' busy — skipped ({rec['skips']}), gap stretched")
    except Exception as e:
        logger.warning(f"[CADENCE] turn on '{chat}' failed: {e}")
        with _lock:
            if _records.get(chat) is rec:
                rec['next_at'] = _now() + _gap(rec)
                rec['pending'] = None
    finally:
        with _lock:
            rec['running'] = False


def _due(rec, now):
    if rec['paused'] or rec['running']:
        return False
    since = now - (rec['last_at'] or 0)
    if rec['pending'] and since >= rec['min_s']:
        return True
    return rec['mode'] == 'timer' and rec['next_at'] is not None and now >= rec['next_at']


def _tick():
    now = _now()
    fire = []
    with _lock:
        for chat, rec in list(_records.items()):
            if now > rec['ttl_until']:
                del _records[chat]
                logger.info(f"[CADENCE] '{chat}' expired (no keepalive) — disarmed")
                continue
            if _due(rec, now):
                rec['running'] = True
                fire.append(rec)
    for rec in fire:
        threading.Thread(target=_fire, args=(rec,), daemon=True,
                         name=f"cadence-{rec['chat'][:24]}").start()


def _loop():
    while not _stop.wait(TICK_S):
        try:
            _tick()
        except Exception as e:
            logger.warning(f"[CADENCE] tick failed: {e}")


def _on_turn_end(event):
    """Bus listener (publisher's thread, returns at once): a turn ended on
    some chat — if that chat is armed, her clock restarts."""
    chat = ((event or {}).get('data') or {}).get('chat')
    if chat and chat in _records:
        touch(chat)


def start(system):
    global _system, _thread, _listening
    _system = system
    _stop.clear()
    if not _listening:
        from core.event_bus import get_event_bus
        get_event_bus().on([Events.AI_TYPING_END], _on_turn_end)
        _listening = True
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_loop, daemon=True, name='cadence-organ')
    _thread.start()
    logger.info("[CADENCE] organ started")


def stop():
    _stop.set()
    with _lock:
        _records.clear()
