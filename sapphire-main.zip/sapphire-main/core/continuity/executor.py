# core/continuity/executor.py
"""
Continuity Executor - Runs scheduled tasks with proper context isolation.
Switches chat context, applies settings, runs LLM, restores original state.
"""

import copy
import json
import logging
import threading
from contextvars import ContextVar
from datetime import datetime
from typing import Dict, Any
from core.event_bus import publish, Events

logger = logging.getLogger(__name__)


# Module-level ContextVar holding the parsed event_data dict that triggered
# the currently-running daemon/webhook task. Plugins (especially their
# tools) can read this to route results back to the originating request
# without the LLM having to carry routing IDs as tool arguments.
#
# Set INSIDE the task's thread (via _run_foreground/_run_background) so
# ContextVars resolve correctly — ContextVars don't propagate across the
# fresh threading.Thread the scheduler spawns per task.
#
# Empty dict default keeps `.get("anything")` safe in non-event contexts.
current_event_data: ContextVar[dict] = ContextVar("current_event_data", default={})


# Contract for plugin-supplied images on an event payload:
#   payload["images"] = [{"data": "<base64>", "media_type": "image/png"}, ...]
# Plugin authors populate this; core validates strictly and routes through the
# existing tool-image pipeline (DB blob + <<IMG::...>> marker + vision gate).
# Malformed entries are dropped with a log — never stringified into the prompt.
_MAX_EVENT_IMAGES = 8
_MAX_EVENT_IMAGE_BYTES = 10 * 1024 * 1024  # 10MB decoded, per image
_VALID_IMAGE_MEDIA = {"image/png", "image/jpeg", "image/jpg", "image/gif", "image/webp"}


def _extract_event_images(obj, notes: list = None) -> list:
    """Pull validated images from an event payload dict.

    Returns a list of {"data": <base64 str>, "media_type": <str>} that passed
    validation, or [] if none/invalid. This is the trust boundary for
    plugin-supplied binary data: a signed plugin can still be buggy, so we
    decode-test every entry and cap count + size before anything reaches the
    LLM context or the chat DB. 2026-06-13.

    Every survivor is normalized through core.images.for_chat (≤1536px long
    edge, RGB JPEG — the one resize). What a vision model bills is pixels,
    ~w*h/750, so this bounds an event image at ~3k tokens and roughly a fifth
    of the bytes on the wire and in the DB. A plugin hands us whatever the
    user posted (Discord: up to 10MB raw); before 2026-10-02 it went through
    untouched. Anything that can't be decoded is dropped — the API would have
    400'd the whole turn on it — and `notes`, when given, collects one human
    line per removed image so the model is told instead of left guessing.
    """
    import base64
    if not isinstance(obj, dict):
        return []
    raw = obj.get("images")
    if not isinstance(raw, list) or not raw:
        return []

    def _drop(reason):
        logger.warning(f"[EVENT-IMG] Dropped image — {reason}")
        if notes is not None:
            notes.append(reason)

    out = []
    for entry in raw[:_MAX_EVENT_IMAGES]:
        if not isinstance(entry, dict):
            _drop("entry is not an image record")
            continue
        data = entry.get("data")
        media_type = (entry.get("media_type") or "image/jpeg").lower()
        if not isinstance(data, str) or not data:
            _drop("no image data")
            continue
        if media_type not in _VALID_IMAGE_MEDIA:
            _drop(f"unsupported type {media_type}")
            continue
        try:
            decoded = base64.b64decode(data, validate=True)
        except Exception:
            _drop("image data is not valid base64")
            continue
        if len(decoded) > _MAX_EVENT_IMAGE_BYTES:
            _drop(f"{len(decoded) // (1024 * 1024)}MB is over the {_MAX_EVENT_IMAGE_BYTES // (1024 * 1024)}MB cap")
            continue
        try:
            from core import images as _ci
            fitted = _ci.for_chat(decoded)
        except Exception as e:
            _drop(f"could not be processed ({e})")
            continue
        out.append({"data": base64.b64encode(fitted).decode("ascii"), "media_type": "image/jpeg"})
    if len(raw) > _MAX_EVENT_IMAGES:
        logger.warning(f"[EVENT-IMG] Payload had {len(raw)} images; capped to {_MAX_EVENT_IMAGES}")
        if notes is not None:
            notes.append(f"{len(raw) - _MAX_EVENT_IMAGES} more image(s) over the {_MAX_EVENT_IMAGES}-per-message cap")
    return out


class ContinuityExecutor:
    """Executes continuity tasks with context isolation."""

    def __init__(self, system):
        """
        Args:
            system: VoiceChatSystem instance with llm_chat, tts, etc.
        """
        self.system = system
        # RLock (reentrant) — guards TTS voice snapshot/apply/restore. Non-reentrant
        # Lock caused a self-deadlock this morning when the finally block re-entered
        # via `with self._voice_lock:`. RLock also defends against any future tool
        # that calls back into the executor while a task is running (spawn_agent,
        # nested continuity triggers, future cross-task coordination) — that path
        # would deadlock on re-acquire with a plain Lock. Scout chaos #17/#18.
        self._voice_lock = threading.RLock()

    @staticmethod
    def _format_event_data(event_data: str) -> str:
        """Format raw event JSON into clean text for the AI.

        If the data is JSON with a 'text' field (e.g. messaging daemons),
        present it as a clean message. Otherwise pass through raw.
        """
        try:
            obj = json.loads(event_data) if isinstance(event_data, str) else event_data
        except (json.JSONDecodeError, TypeError):
            return event_data

        if not isinstance(obj, dict):
            return event_data

        # Email format — structured with subject, sender, body
        if obj.get("subject") is not None and obj.get("snippet") is not None:
            from_name = obj.get("from_name", "")
            from_addr = obj.get("from_address", "")
            sender = f"{from_name} <{from_addr}>" if from_name else from_addr
            parts = []
            if sender:
                parts.append(f"From: {sender}")
            parts.append(f"Subject: {obj['subject']}")
            if obj.get("uid"):
                parts.append(f"UID: {obj['uid']}")
            parts.append("")
            parts.append(obj["snippet"])
            return "\n".join(parts)

        text = obj.get("text") or obj.get("content") or None
        if not text:
            # Messaging-shaped payloads (daemon events with routing fields) must
            # never fall through to raw JSON: the payload carries routing
            # metadata — llm_primary/llm_model, attachment URLs, author ids —
            # that would enter the prompt AND persist into chat history as the
            # user turn, where the AI later quotes it as fact ("I'm on <old
            # model>"). Format normally with a placeholder trigger instead.
            if any(obj.get(k) for k in ("channel_id", "chat_id", "account")):
                text = "(message has no text — likely an attachment, sticker, or embed)"
            else:
                # Generic non-message events keep raw-JSON visibility, minus
                # the LLM routing keys, which are never content.
                redacted = {k: v for k, v in obj.items()
                            if k not in ("llm_primary", "llm_model")}
                try:
                    return json.dumps(redacted, ensure_ascii=False, default=str)
                except Exception:
                    return event_data

        # Build clean message from common fields
        sender = obj.get("display_name") or obj.get("first_name") or obj.get("username") or obj.get("sender") or ""
        channel = obj.get("channel_name", "")
        guild = obj.get("guild_name", "")

        parts = []
        # Label channel to match tool param name exactly — AI can copy-paste
        if channel and guild:
            parts.append(f"channel: {channel}")
            parts.append(f"server: {guild}")
        elif channel:
            parts.append(f"channel: {channel}")

        # Include recent chat history if available
        history = obj.get("recent_history", [])
        if history:
            parts.append("Recent chat:")
            for line in history:
                parts.append(f"  {line}")
            parts.append("")  # blank line before the trigger message

        # Current date/time for context
        from datetime import datetime as _dt
        try:
            import config as _cfg
            tz_name = getattr(_cfg, 'USER_TIMEZONE', '')
            if tz_name:
                from zoneinfo import ZoneInfo
                now = _dt.now(ZoneInfo(tz_name))
            else:
                now = _dt.now().astimezone()
        except Exception:
            now = _dt.now()
        parts.append(f"Current time: {now.strftime('%Y-%m-%d %H:%M %Z').strip()}")

        # Include chat_id/account for messaging tools (Telegram, Discord)
        chat_id = obj.get("chat_id")
        channel_id = obj.get("channel_id")
        account = obj.get("account")
        if chat_id:
            parts.append(f"chat_id: {chat_id}")
        if channel_id:
            parts.append(f"channel_id: {channel_id}")
        if account:
            parts.append(f"account: {account}")

        # Discord mention hint — works for sender and anyone in recent history
        author_id = obj.get("author_id")
        if author_id and channel_id:
            parts.append(f"To @mention a Discord user, use <@userid> (e.g. <@{author_id}> for the sender). User IDs appear in [id:...] brackets in the chat history.")

        if chat_id or channel_id or account:
            parts.append("")

        # The trigger message itself — emphasized
        if sender:
            parts.append(f">>> {sender}: {text}")
        else:
            parts.append(f">>> {text}")
        return "\n".join(parts)

    def run(self, task: Dict[str, Any], event_data: str = None,
            progress_callback=None, response_callback=None,
            cancel_event=None) -> Dict[str, Any]:
        """
        Execute a continuity task.

        cancel_event: optional threading.Event — set by the scheduler when the
        user stops the run (⏹ / toggle off / delete). Honored between LLM
        rounds by ExecutionContext; a cancelled run persists an empty reply,
        sends nothing to its source, speaks nothing. Plugin-handler tasks
        (source 'plugin:*') run their own code and can't be interrupted.

        Args:
            task: Task definition dict
            event_data: Optional event payload (for daemon/webhook triggered tasks).
                        When present, initial_message is prepended as instructions.
            progress_callback: Optional callable(iteration, total) for progress updates
            response_callback: Optional callable(response_text) called before TTS

        Returns:
            Result dict with success, responses, errors
        """
        # Plugin-sourced tasks run their handler directly
        source = task.get("source", "")
        if source.startswith("plugin:"):
            return self._run_plugin_task(task, progress_callback, response_callback)
        # A Device task runs one device action, no LLM (2026-10-06)
        if task.get("device_action"):
            return self._run_device_task(task, progress_callback, response_callback)

        # Deepcopy to protect against update_task mutating the dict while we
        # read it. Scheduler passes live refs from self._tasks.values(), so
        # a concurrent UI edit of this task would otherwise produce incoherent
        # merged settings (new persona name + old toolset, etc.)
        task = copy.deepcopy(task)

        # For event-triggered tasks, build message from instructions + event data
        _ev_token = None
        if event_data is not None:
            event_display = self._format_event_data(event_data)
            instructions = task.get("initial_message", "").strip()
            if instructions:
                task["initial_message"] = f"{instructions}\n\n{event_display}"
            else:
                task["initial_message"] = event_display

            # Plugin-supplied images (payload["images"]). Validated here at the
            # trust boundary; saved to the chat DB + sent to vision models at the
            # run site. Absent/invalid → [] → behavior identical to text-only. 2026-06-13.
            try:
                _img_obj = json.loads(event_data) if isinstance(event_data, str) else event_data
                _img_notes = []
                event_images = _extract_event_images(_img_obj, _img_notes)
                if event_images:
                    task["_event_images"] = event_images
                    logger.info(f"[EVENT-IMG] {len(event_images)} image(s) attached from event payload")
                if _img_notes:
                    # The model is told what it didn't get, in the user turn, so
                    # "what's in the picture?" gets an honest answer. 2026-10-02.
                    task["initial_message"] += "".join(
                        f"\n(An attached image was removed before it reached you: {n})" for n in _img_notes)
            except (json.JSONDecodeError, TypeError):
                pass

            # Auto-set plugin scopes from event data (e.g. discord account)
            # Event source → scope key mapping for auto-fill.
            # Extracted to a list so adding a new event-emitting plugin only touches this table,
            # not the surrounding logic. (Future: move this into the scope manifest capability
            # so plugins can self-declare `"event_source_keyword": "discord"`.)
            _EVENT_SOURCE_SCOPE_MAP = [
                ("discord",  "discord_scope"),
                ("telegram", "telegram_scope"),
                ("email",    "email_scope"),
            ]
            try:
                obj = json.loads(event_data) if isinstance(event_data, str) else event_data
                if isinstance(obj, dict) and obj.get("account"):
                    trigger = task.get("trigger_config", {})
                    source = trigger.get("source", "") or trigger.get("event_source", "")
                    for keyword, scope_key in _EVENT_SOURCE_SCOPE_MAP:
                        if keyword in source and not task.get(scope_key):
                            task[scope_key] = obj["account"]
                            # Discord needs channel_id for auto-reply targeting
                            if keyword == "discord" and obj.get("channel_id"):
                                task["_discord_reply_channel_id"] = obj["channel_id"]
                            break
            except (json.JSONDecodeError, TypeError):
                pass

            # Generic plugin context propagation. Set the current event_data
            # in a ContextVar that plugin tools can read without the LLM
            # carrying routing IDs as arguments. Works in this thread + any
            # downstream call frame in the same task; ContextVars don't
            # propagate across new threads, but the task runs in this thread
            # so anything ExecutionContext.run does (LLM, tool calls) sees
            # the set value.
            try:
                event_obj = json.loads(event_data) if isinstance(event_data, str) else (event_data or {})
                if isinstance(event_obj, dict):
                    _ev_token = current_event_data.set(event_obj)
            except (json.JSONDecodeError, TypeError):
                pass

        # Resolve persona defaults into task (task-level fields override persona).
        # `_resolve_persona` raises on malformed-persona / lookup failure (today's
        # change). Build the result dict FIRST so we can return a shaped error
        # if persona resolution explodes — without this, the raise propagates
        # before the result dict exists and the scheduler's outer except has
        # to fabricate state. Witch-hunt 2026-04-21 finding H12.
        result = {
            "success": False,
            "task_id": task.get("id"),
            "task_name": task.get("name"),
            "started_at": datetime.now().isoformat(),
            "responses": [],
            "errors": []
        }
        try:
            try:
                task = self._resolve_persona(task)
            except Exception as e:
                err = f"Persona resolution failed: {e}"
                logger.error(f"[Continuity] {err}", exc_info=True)
                result["errors"].append(err)
                result["completed_at"] = datetime.now().isoformat()
                return result

            chat_target = task.get("chat_target", "").strip()

            # Blank chat_target = ephemeral: isolated, no chat creation, no UI impact
            if not chat_target:
                return self._run_background(task, result, progress_callback, response_callback,
                                            cancel_event=cancel_event)

            # Named chat_target = foreground: runs in that chat, waiting its turn
            # in the chat's inbox (core/chat/inbox.py, wave I-3 2026-10-06). An
            # event from a person on another surface (Discord, Telegram, email)
            # stands with people; cron and webhooks stand with machines.
            return self._run_foreground_queued(task, result, progress_callback, response_callback,
                                               cancel_event=cancel_event,
                                               lane='now' if event_data else 'later')
        finally:
            # Reset the event ContextVar. Harmless on today's fresh-thread-per-task
            # scheduler; load-bearing the day any pooled thread calls run() —
            # without it the next run on that thread inherits a stale event's
            # llm_primary and routing ids.
            if _ev_token is not None:
                current_event_data.reset(_ev_token)
    
    @staticmethod
    def _extract_task_settings(task: Dict[str, Any]) -> Dict[str, Any]:
        """Extract execution settings from a task dict for ExecutionContext.
        Scope keys are pulled dynamically from SCOPE_REGISTRY so new plugin scopes
        propagate to scheduled tasks without code changes.

        Missing scope keys fall back to 'default' for backward compat with
        tasks created before the scope-registry rollout. But: we warn when
        that happens so the silent-default class of bugs is visible in logs.
        A task that SHOULD have been scoped to e.g. 'lookout' but is missing
        the key will still run, but the warning flags the write as going to
        shared memory unintentionally. Scout finding 2026-04-19."""
        from core.chat.function_manager import scope_setting_keys
        settings = {
            "prompt": task.get("prompt", "default"),
            "privacy_required": task.get("privacy_required", False),
            "toolset": task.get("toolset", "none"),
            "provider": task.get("provider", "auto"),
            "model": task.get("model", ""),
            # Per-chat read deadline (phone chats stamp 20s): reaches the
            # resolver on chat_from_payload tasks (2026-09-21).
            "llm_request_timeout": task.get("llm_request_timeout"),
            "inject_datetime": task.get("inject_datetime", False),
            "max_tool_rounds": task.get("max_tool_rounds"),
            "max_parallel_tools": task.get("max_parallel_tools"),
            "context_limit": task.get("context_limit"),
            "system_append": task.get("system_append"),
        }
        missing_scopes = []
        for setting_key in scope_setting_keys():
            if setting_key in task:
                settings[setting_key] = task[setting_key]
            else:
                # Pre-2026-05-07 we wrote 'default' here. That defeated the
                # force-None protection in ExecutionContext._build_scopes:
                # by the time it ran, every scope key was already in
                # task_settings, so the `if setting_key not in task_settings`
                # branch was dead code. The "silent-default closed" comment
                # was a lie — only the warning fired, the real protection
                # was bypassed. Now we leave the key UNSET so _build_scopes
                # can force-None it, disabling the scope for this task as
                # designed. Wildcard scout 2026-05-07 finding (verified).
                missing_scopes.append(setting_key)
        if missing_scopes:
            logger.warning(
                f"[Continuity] Task '{task.get('name', '?')}' missing scope keys "
                f"{missing_scopes} — those scopes will be DISABLED for this run "
                f"(force-None at task entry). Edit the task to set explicit scopes "
                f"if writes from this task should land somewhere."
            )
        return settings

    # ── one tail for both lanes (DRY scout, 2026-10-27: the background copy had
    # drifted - a text-only browser TTS payload in the wrong voice, a doubled
    # TTS gate that silenced public tasks, Discord errors swallowed) ──

    def _reply_channel(self, task):
        """Point Discord's auto-reply at the channel an event came from."""
        reply_ch = task.get("_discord_reply_channel_id")
        if not reply_ch:
            return
        try:
            from plugins.discord.tools.discord_tools import _reply_channel_id
            _reply_channel_id.set(reply_ch)
        except ImportError:
            pass                    # Discord plugin not loaded at all — expected path, quiet
        except Exception as e:
            # Loaded but broken: an auto-reply would land nowhere visible. Chaos scout #19.
            logger.warning(f"[Continuity] Discord reply channel set failed (plugin loaded but broken): {e}")

    def _deliver(self, task, response, private, response_cb, tts_enabled, browser_tts):
        """A task's answer out: the reply callback (Discord/Telegram/email:
        egress, never for a private chat or a privacy-required task), then
        her voice - in the browser, or here."""
        if not response:
            return
        if response_cb:
            if private:
                logger.info("[Continuity] reply callback suppressed — private chat or privacy-required task")
            else:
                try:
                    response_cb(response)
                except Exception as e:
                    logger.error(f"[Continuity] Response callback failed: {e}")
        if browser_tts:
            if private:
                logger.info("[Continuity] browser TTS skipped — private chat or privacy-required task")
                return
            # Carry the TASK's voice/pitch/speed in the payload: they're applied
            # globally only for this run, and restored before the browser's
            # /api/tts request can arrive - a text-only payload spoke the wrong voice.
            tts = getattr(self.system, 'tts', None)
            tv = self._task_voice(task)
            publish(Events.TTS_SPEAK, {
                "text": response, "task": task.get("name", ""),
                "voice": tv["voice"] or getattr(tts, "voice_name", None),
                "pitch": tv["pitch"] if tv["pitch"] is not None else getattr(tts, "pitch_shift", None),
                "speed": tv["speed"] if tv["speed"] is not None else getattr(tts, "speed", None),
            })
        elif tts_enabled and getattr(self.system, 'tts', None):
            # The privacy gate rides INSIDE speak_sync (one rule for every lane,
            # broadsword H3): a pre-gate here doubled it against the operator's
            # active chat and silenced public tasks.
            try:
                self.system.tts.speak_sync(response, chat_settings={"private_chat": bool(private)},
                                           voice=self._task_voice(task))
            except Exception as e:
                logger.warning(f"[Continuity] TTS failed: {e}")

    @staticmethod
    def _message(task):
        """The task's message, with {quiet} filled: how long the person has
        been quiet, app-wide (core/idle.py) - "1 h 5 min", or "a while" when
        it isn't known."""
        msg = task.get("initial_message", "Hello.")
        if isinstance(msg, str) and "{quiet}" in msg:
            from core import idle
            mins = idle.minutes(None, person=True)
            msg = msg.replace("{quiet}", idle.words(mins) if mins is not None else "a while")
        return msg

    def _fail(self, result, task, prefix, e):
        """One failure's words: logged, on the result, and to the UI."""
        from core.chat.chat import friendly_llm_error
        friendly = friendly_llm_error(e)
        error_msg = f"{prefix}: {friendly or e}"
        logger.error(f"[Continuity] {error_msg}", exc_info=True)
        result["errors"].append(error_msg)
        publish(Events.CONTINUITY_TASK_ERROR, {"task": task.get("name", "Unknown"), "error": friendly or str(e)})

    def _run_background(self, task: Dict[str, Any], result: Dict[str, Any],
                        progress_cb=None, response_cb=None, cancel_event=None) -> Dict[str, Any]:
        """Run task in background mode — fully isolated via ExecutionContext."""
        from core.continuity.execution_context import ExecutionContext

        task_name = task.get("name", "Unknown")
        logger.info(f"[Continuity] Running '{task_name}' in BACKGROUND mode (ExecutionContext)")

        with self._voice_lock:
            original_voice = self._snapshot_voice()
            try:
                self._apply_voice(task)
            except Exception:
                self._restore_voice(original_voice)
                raise

            try:
                task_settings = self._extract_task_settings(task)
                ctx = ExecutionContext(
                    self.system.llm_chat.function_manager,
                    self.system.llm_chat.tool_engine,
                    task_settings,
                    session_manager=self.system.llm_chat.session_manager,
                    cancel_check=(cancel_event.is_set if cancel_event is not None else None),
                )

                self._reply_channel(task)

                tts_enabled = task.get("tts_enabled", True)
                browser_tts = task.get("browser_tts", False)
                msg = self._message(task)
                # Ephemeral path doesn't persist — images are turn-only, shown to
                # the LLM (vision-gated in ctx), no DB save / marker needed.
                _ev_images = task.get("_event_images")

                try:
                    # Ephemeral carrier (2026-09-03): this lane has NO target
                    # chat, and without an override every "this chat" seam a
                    # tool touches (reset_chat, prompt_switch, switch_toolset,
                    # switch_model, hook privacy resolvers, token metrics)
                    # fell through to the OPERATOR'S live chat. The carrier
                    # makes chatlessness first-class: writers refuse loudly,
                    # readers see the task's declared settings. Same span
                    # discipline as the foreground lane — ctx.run only.
                    from core.chat import stream_brain
                    _brain_token = stream_brain.set_override(
                        self.system.llm_chat.session_manager
                            .make_ephemeral_override(task_settings))
                    try:
                        response = ctx.run(msg, images=_ev_images)
                    finally:
                        stream_brain.reset_override(_brain_token)

                    if getattr(ctx, "cancelled", False):
                        result["cancelled"] = True   # response is "" — nothing below fires

                    # P3-T5 (background/ephemeral path — no target chat):
                    # privacy_required is the carrier.
                    self._deliver(task, response, bool(task_settings.get("privacy_required")),
                                  response_cb, tts_enabled, browser_tts)

                    result["responses"].append({
                        "iteration": 1,
                        "input": msg,
                        "output": response or None
                    })
                except Exception as e:
                    self._fail(result, task, "Task failed", e)

                if progress_cb:
                    progress_cb(1, 1)

                result["success"] = len(result["errors"]) == 0

            except Exception as e:
                self._fail(result, task, "Background task failed", e)

            finally:
                self._restore_voice(original_voice)

        result["completed_at"] = datetime.now().isoformat()
        return result

    @staticmethod
    def _save_event_images(images, target_chat, session_manager) -> str:
        """Save plugin event images to the chat DB keyed to target_chat and
        return a marker suffix to append to the user message text.

        Markers (`<<IMG::tool:id>>`) match the UI strip pattern, so they're
        stripped before the LLM and rehydrated from the DB by the frontend —
        the same lifecycle as tool images. Bytes live in the DB; history holds
        only the marker. 2026-06-13.
        """
        import base64
        import uuid
        if not images or not hasattr(session_manager, "save_tool_image"):
            return ""
        markers = []
        for img in images:
            try:
                media_type = img.get("media_type", "image/jpeg")
                ext = "png" if "png" in media_type else ("gif" if "gif" in media_type
                      else ("webp" if "webp" in media_type else "jpg"))
                img_id = f"{uuid.uuid4().hex[:12]}.{ext}"
                img_bytes = base64.b64decode(img["data"])
                # Use the SAME `tool:` marker namespace as tool images — the
                # frontend (strips `tool:`), serve route, and orphan-pruner all
                # only recognize `tool:`. A separate `event:` prefix rendered as
                # a broken image AND got pruned as a false orphan. These ARE
                # tool_images-table entries, just sourced from an event. 2026-06-13.
                if session_manager.save_tool_image(img_id, img_bytes, media_type,
                                                   chat_name=target_chat):
                    # Marker = the UI's; the receipt line is the model's handle
                    # (core.images contract) so a plugin-delivered image can be
                    # filed with memory_save_image(source='img:...'). 2026-09-13.
                    img["id"] = img_id      # the describer keys the caption to this row
                    markers.append(f"<<IMG::tool:{img_id}>>\n(image img:{img_id})")
                else:
                    # DB write failed — don't append a marker pointing at a blob
                    # that isn't there (would 404 on render). LLM still saw the
                    # image this turn via the images= param; only history skips it.
                    logger.warning(f"[EVENT-IMG] save_tool_image returned False for {img_id} — marker skipped")
            except Exception as e:
                logger.warning(f"[EVENT-IMG] Failed to persist event image: {e}")
        return ("\n" + "\n".join(markers)) if markers else ""

    def _resolve_target_chat(self, task: Dict[str, Any]) -> str:
        """The chat a foreground task runs in, as kept - found by its normalized
        name or created. Raises ValueError when the name cannot be a chat or
        the chat cannot be made (a name sealed in the locked vault: fail LOUDLY,
        never a plaintext twin)."""
        session_manager = self.system.llm_chat.session_manager
        target_chat = task.get("chat_target", "").strip()
        # Normalize the same way create_chat sanitizes: keep alnum/space/dash/underscore
        normalized = "".join(c for c in target_chat if c.isalnum() or c in (' ', '-', '_')).strip()
        normalized = normalized.replace(' ', '_').lower()
        # Guard: all-non-alnum chat_target (e.g. "!!!") normalizes to empty.
        # Proceeding would create/write to a blank-named chat file — bad
        # on-disk state and session_manager behavior for "" is undefined.
        # Fail the task loudly instead. Chaos scout #15 — 2026-04-20.
        if not normalized:
            raise ValueError(
                f"chat_target {target_chat!r} normalizes to empty — "
                "refusing to create/write blank-named chat."
            )
        existing_chats = {c["name"]: c["name"] for c in session_manager.list_chat_files()}
        match = existing_chats.get(normalized)
        if match:
            return match
        logger.info(f"[Continuity] Creating new chat: {target_chat}")
        # create_chat now publishes CHAT_CREATED itself (the creation
        # chokepoint), so no explicit publish here.
        if not session_manager.create_chat(target_chat):
            # Vaulted chats Phase 1 (Krem's ruling: fail LOUDLY): the
            # name may belong to a chat sealed in a locked vault — the
            # list above can't see it, but the row exists. Falling
            # through would create a plaintext twin and write into it
            # in the clear, the one unforgivable outcome. Any create
            # failure kills the task.
            raise ValueError(
                f"chat_target '{target_chat}' could not be created "
                f"(name already taken — possibly by a chat sealed in "
                f"the locked vault) — task refused.")
        return normalized

    def _run_foreground_queued(self, task, result, progress_cb=None, response_cb=None,
                               cancel_event=None, lane='later') -> Dict[str, Any]:
        """A foreground task waits its turn in its chat's inbox and HOLDS the
        chat while it runs (an exclusive stream registration, so a typed turn
        cannot start on top of it). Before this (scout B, 2026-10-06) the task
        ran beside a live turn and its transcript append waited 60 s, then
        dropped - the tool effects already done, the chat missing the exchange."""
        from core.chat import inbox
        try:
            target_chat = self._resolve_target_chat(task)
        except Exception as e:
            error_msg = f"Persistent chat task failed: {e}"
            logger.error(f"[Continuity] {error_msg}", exc_info=True)
            result["errors"].append(error_msg)
            publish(Events.CONTINUITY_TASK_ERROR, {"task": task.get("name", "Unknown"), "error": str(e)})
            result["completed_at"] = datetime.now().isoformat()
            return result

        def _body():
            return self._run_foreground(task, result, progress_cb, response_cb,
                                        cancel_event=cancel_event, target_chat=target_chat, hold=True)
        try:
            return inbox.turn(target_chat, _body, source=f"continuity:{task.get('name', '?')}", lane=lane)
        except inbox.InboxRefused as e:
            error_msg = f"Persistent chat task refused: {e}"
            logger.warning(f"[Continuity] {error_msg}")
            result["errors"].append(error_msg)
            result["completed_at"] = datetime.now().isoformat()
            return result

    def _run_foreground(self, task: Dict[str, Any], result: Dict[str, Any],
                        progress_cb=None, response_cb=None, cancel_event=None,
                        target_chat=None, hold=False) -> Dict[str, Any]:
        """Run task with persistent chat history — no UI switching.

        target_chat: the resolved chat name (see _resolve_target_chat); None
        resolves it here. hold=True registers an exclusive stream on the chat
        for the run's duration - ChatBusy propagates to the inbox, which tries
        again when the chat frees up (never caught below).

        Voice-lock discipline: the lock is held for the ENTIRE duration of
        the task (snapshot → apply → LLM → TTS → restore). Before 2026-04-19
        the lock was released between apply and restore, which let a second
        concurrent task's `_apply_voice` run over the first's — task A would
        then speak with B's voice during overlap, and if B finished first
        and restored "original" (really A's voice), the user could hear
        half-swapped voices for the rest of A's run. Holding the lock across
        serializes concurrent foreground tasks but keeps TTS correctness.
        """
        from core.continuity.execution_context import ExecutionContext

        session_manager = self.system.llm_chat.session_manager
        hold_sid = hold_name = None
        if hold and target_chat:
            # The chat is ours for the run. ChatBusy is NOT caught here: the
            # inbox's drainer requeues this task at the head and tries again.
            # Anything else (a test double without a stream registry) runs unheld.
            from core.chat.chat import ChatBusy
            try:
                _held = self.system.llm_chat.begin_stream(chat_name=target_chat, exclusive=True)
                if isinstance(_held, tuple) and len(_held) == 3:
                    hold_sid, hold_name = _held[1], _held[2]
            except ChatBusy:
                raise
            except Exception as e:
                logger.debug(f"[Continuity] chat hold not taken for '{target_chat}': {e}")
        try:
            return self._run_foreground_held(task, result, progress_cb, response_cb, cancel_event,
                                             target_chat, session_manager, ExecutionContext)
        finally:
            if hold_sid is not None:
                if result.get("cancelled"):
                    _held[0].cancel_flag = True    # a stopped run drops what it asked for
                try:
                    self.system.llm_chat.end_stream(hold_sid, hold_name)
                except Exception as e:
                    logger.debug(f"[Continuity] chat hold release failed: {e}")
            # What her slash_command deferred in this run lands now its rows are
            # written: a task turn never passes chat_streaming's finish_turn.
            try:
                from core import commands
                commands.finish_turn(session_manager, target_chat)
            except Exception as e:
                logger.error(f"[Continuity] Waiting commands failed: {e!r}")

    def _run_foreground_held(self, task, result, progress_cb, response_cb, cancel_event,
                             target_chat, session_manager, ExecutionContext) -> Dict[str, Any]:
        original_voice: Dict[str, Any] = {}
        self._voice_lock.acquire()
        try:
            original_voice = self._snapshot_voice()
            self._apply_voice(task)
        except Exception:
            # Apply failed — restore whatever we captured and release BEFORE re-raising.
            try: self._restore_voice(original_voice)
            except Exception: pass
            self._voice_lock.release()
            raise

        try:
            if not target_chat:
                target_chat = self._resolve_target_chat(task)
            logger.info(f"[Continuity] Running '{task.get('name')}' with chat persistence, chat='{target_chat}'")

            # Build ExecutionContext — isolated, no singleton mutation.
            # "Webhook specifies chat name" (trigger_config.chat_from_payload): the
            # named chat answers with ITS OWN settings, not the task's — so the reply
            # runs as if typed in that chat (persona/toolset/scopes come from the chat).
            # Settings are read unconditionally: the privacy stamp below needs them.
            # A read failure propagates — a task that can't see its target chat's
            # settings must not run as if it could (fail-closed, like the gate).
            chat_settings = session_manager.read_chat_settings(target_chat) or {}
            if task.get("trigger_config", {}).get("chat_from_payload"):
                from core.chat.function_manager import scope_setting_keys
                cc = chat_settings
                merged = {**task,
                          "prompt": cc.get("persona") or cc.get("prompt") or "default",
                          "toolset": cc.get("toolset") or cc.get("ability") or "none",
                          "provider": cc.get("llm_primary") or "auto",
                          "model": cc.get("llm_model") or "",
                          "llm_request_timeout": cc.get("llm_request_timeout"),
                          **{k: cc[k] for k in scope_setting_keys() if k in cc}}
                task_settings = self._extract_task_settings(merged)
            else:
                task_settings = self._extract_task_settings(task)
            # The chat this run speaks in, by its RESOLVED name. ExecutionContext
            # reads it for the budgeter's watermark and meter key (one per
            # conversation), for tool provenance (set_tool_context) and for
            # {session} affinity. The extractor never carried it, so every
            # persistence run fit with no key: a from-scratch cut every round
            # (the prefix moved between rounds), and no meter (2026-11-01).
            task_settings["chat_target"] = target_chat
            # Privacy rides the CHAT here, not just the prompt (vaulted-chats
            # Phase 0, 2026-08-13). This lane is about to read the target
            # chat's whole transcript into the LLM request — before this, only
            # a privacy_required PROMPT forced local-only, so a cron/agent/
            # daemon task with chat_target=<private chat> + a cloud provider
            # shipped that chat's history out. OR the chat's flag into the
            # same carrier the prompt gate uses; ExecutionContext then gates
            # provider selection AND network tools off it.
            if chat_settings.get("private_chat"):
                task_settings["privacy_required"] = True
            ctx = ExecutionContext(
                self.system.llm_chat.function_manager,
                self.system.llm_chat.tool_engine,
                task_settings,
                session_manager=self.system.llm_chat.session_manager,
                cancel_check=(cancel_event.is_set if cancel_event is not None else None),
            )

            # Set Discord reply channel for auto-reply targeting
            self._reply_channel(task)

            tts_enabled = task.get("tts_enabled", True)
            browser_tts = task.get("browser_tts", False)
            msg = self._message(task)

            # Plugin event images: save bytes to the chat DB (keyed to target_chat)
            # and append <<IMG::tool:id>> markers to the persisted text. The base64
            # is handed to ctx separately for the LLM turn (vision-gated); history
            # keeps only the marker. 2026-06-13.
            _ev_images = task.get("_event_images")
            if _ev_images:
                msg = msg + self._save_event_images(_ev_images, target_chat, session_manager)

            # Read history from target chat WITHOUT switching active chat.
            # The task's context_limit (when set) governs the history trim
            # too — before this, the global CONTEXT_LIMIT silently capped
            # long-session tasks (the librarian's 128K nights) - at send time now:
            # the whole chat is read here (0 = no trim in the reader) and ExecCtx
            # fits it per call against the real window (core/chat/budget.py).
            # Trimmed here too, the cut point drifted and her note undercounted.
            history_messages = session_manager.read_chat_messages(
                target_chat, provider=task_settings.get("provider"),
                context_limit=0
            )

            try:
                # Per-stream brain override: for the duration of the run, any
                # tool that reads/writes "this chat's" state via session_manager
                # (get_self_info, switch_model, reset_chat, set_voice, …)
                # resolves the task's own chat_target — NOT the operator's
                # active web chat. Same primitive the phone-call stream uses
                # (chat_streaming.py:175). Span is ctx.run only; the
                # persistence + TTS below never consult it. 2026-08-06 —
                # closes the daemon↔web state-leak family (a Discord reply
                # reported the web chat's model as its own).
                from core.chat import stream_brain
                from core.chat.history import ConversationHistory
                _cc = session_manager.read_chat_settings(target_chat)
                # 'history' is REQUIRED, not decorative: _effective_chat()
                # diverts on it, and every override consumer (settings
                # writes, _save_current_chat, _in_tool_cycle) keys off that
                # divert. Shipping this override without it made a tool's
                # settings write persist the operator's ACTIVE chat's
                # settings+messages under target_chat (trinity clobbered
                # with default, 2026-08-17). Seeded from the messages we
                # already read — same shape make_stream_session builds.
                _hist = ConversationHistory(max_history=session_manager.max_history)
                _hist.messages = list(history_messages or [])
                _brain_token = stream_brain.set_override({
                    "chat": target_chat,
                    "settings": _cc if isinstance(_cc, dict) else {},
                    "system_prompt": ctx.system_prompt,
                    "tools": None,
                    "history": _hist,
                })
                try:
                    # Run through isolated ExecutionContext — no singleton contact
                    response = ctx.run(msg, history_messages=history_messages, images=_ev_images)
                finally:
                    stream_brain.reset_override(_brain_token)

                # If the run ended degraded (context overflow, tool exhaustion,
                # empty LLM, hallucinated tools), the empty assistant message
                # in ctx.new_messages is intentionally blank — Apr-24 fix kept
                # error text out of TTS / Discord / Telegram. But the chat UI
                # then renders a totally empty bubble with no signal to the
                # user. Attach degraded_reason as metadata on the empty asst
                # message so the frontend can render it as an italic system
                # note. Frontend MUST keep this out of any speak/relay paths.
                degraded = getattr(ctx, 'degraded_reason', None)
                cancelled = getattr(ctx, 'cancelled', False)
                if degraded and ctx.new_messages:
                    for _m in ctx.new_messages:
                        if _m.get("role") == "assistant" and not _m.get("content"):
                            _meta = dict(_m.get("metadata") or {})
                            _meta["degraded_reason"] = degraded
                            _m["metadata"] = _meta
                            break

                # Persist the FULL conversation (including tool calls + results)
                # to the target chat. ctx.new_messages has everything generated
                # during this run: user msg, assistant+tool_calls, tool results,
                # and the final assistant response — not just the bookends.
                # Convert wire-format tool results to canonical persistence
                # shape first — Claude / Anthropic-compat providers emit tool
                # results as `role=user` with list-content `tool_result` blocks
                # which the frontend renderer can't display. Without this
                # conversion every Claude-backed scheduled task corrupts its
                # named chat with empty user bubbles. 2026-05-11.
                if hasattr(ctx, 'new_messages') and ctx.new_messages:
                    from core.chat.chat_tool_calling import wire_to_canonical
                    canonical_messages = wire_to_canonical(ctx.new_messages)
                    # The task's prompt is a user row the person never wrote: it
                    # carries its origin, so the idle clock's restart seed never
                    # takes a heartbeat for the person (core/idle.py).
                    canonical_messages = [dict(m, origin=f"task:{task.get('name') or task.get('id')}")
                                          if m.get("role") == "user" and not m.get("origin") else m
                                          for m in canonical_messages]
                    appended = session_manager.append_messages_to_chat(
                        target_chat, canonical_messages)
                    if appended is False:
                        # Deleted chat or active-stream-wait timeout — the
                        # tool effects already happened; the transcript is
                        # now missing this exchange. Surface it (scout,
                        # 2026-07-20) instead of discarding the bool.
                        logger.warning(
                            f"[Continuity] Transcript append to "
                            f"'{target_chat}' FAILED — the chat is missing "
                            f"this exchange (deleted mid-run or stream-busy).")
                else:
                    # Fallback to simple pair if new_messages not available
                    session_manager.append_to_chat(target_chat, msg, response or "")

                if degraded:
                    # Surface degradation in the RESULT too — callers that
                    # gate work on the run (the librarian's drain stamps)
                    # must be able to tell "model failed" from "model
                    # declined"; success stays True for backward compat.
                    result["degraded"] = degraded
                    if cancelled:
                        # The user's stop, not a model failure — no error event.
                        result["cancelled"] = True
                    else:
                        publish(Events.CONTINUITY_TASK_ERROR, {
                            "task": task.get("name", "Unknown"),
                            "error": degraded,
                        })

                # P3-T5: privacy is the TASK's chat's, never the operator's.
                self._deliver(task, response,
                              bool(chat_settings.get("private_chat")) or bool(task_settings.get("privacy_required")),
                              response_cb, tts_enabled, browser_tts)

                result["responses"].append({
                    "iteration": 1,
                    "input": msg,
                    "output": response or None
                })
            except Exception as e:
                self._fail(result, task, "Task failed", e)

            if progress_cb:
                progress_cb(1, 1)

            result["success"] = len(result["errors"]) == 0

        except Exception as e:
            self._fail(result, task, "Persistent chat task failed", e)

        finally:
            # Voice lock is already held by this thread from the acquire above —
            # re-acquiring via `with self._voice_lock:` would deadlock against
            # ourselves (threading.Lock is NON-reentrant). Just restore + release.
            try:
                self._restore_voice(original_voice)
            except Exception as _e:
                logger.warning(f"[Continuity] _restore_voice in finally failed: {_e}")
            self._voice_lock.release()

        result["completed_at"] = datetime.now().isoformat()
        return result

    def _run_plugin_task(self, task: Dict[str, Any], progress_cb=None, response_cb=None) -> Dict[str, Any]:
        """Execute a plugin-sourced scheduled task by calling its handler."""
        from pathlib import Path
        import config

        result = {
            "success": False,
            "task_id": task.get("id"),
            "task_name": task.get("name"),
            "started_at": datetime.now().isoformat(),
            "responses": [],
            "errors": []
        }

        plugin_name = task.get("source", "").replace("plugin:", "")
        handler_path = task.get("handler", "")
        plugin_dir = task.get("plugin_dir", "")

        if not handler_path or not plugin_dir:
            result["errors"].append(f"Plugin task missing handler or plugin_dir")
            return result

        # Only a handler inside the directory of the plugin the task names, as
        # the loader knows it: a task's fields are data, never a path to run.
        try:
            from core.plugin_loader import plugin_loader as _pl
            known = (_pl._plugins.get(plugin_name) or {}).get("path")
            root = Path(known).absolute() if known else None
            full_path = (Path(plugin_dir) / handler_path).absolute()
            inside = (root is not None and Path(plugin_dir).resolve() == root.resolve()
                      and full_path.resolve().is_relative_to(root.resolve()))
        except Exception:
            inside = False
        if not inside:
            logger.warning(f"[Continuity] Plugin task '{task.get('name')}' refused: its handler is not "
                           f"inside the '{plugin_name}' plugin's own folder")
            result["errors"].append("Plugin task refused: its handler is not inside its plugin's folder")
            return result
        try:
            _on = bool((_pl._plugins.get(plugin_name) or {}).get("loaded"))
        except Exception:
            _on = True
        if not _on:
            # A runtime task (a clock alarm) outlives its plugin being switched
            # off; it waits until the plugin is back instead of running a
            # disabled plugin's code (hunt 21).
            logger.info(f"[Continuity] Plugin task '{task.get('name')}' skipped: '{plugin_name}' is off")
            result["errors"].append(f"Skipped: the {plugin_name} plugin is off")
            return result
        if not full_path.exists():
            result["errors"].append(f"Handler not found: {full_path}")
            return result

        try:
            source = full_path.read_text(encoding="utf-8")
            namespace = {"__file__": str(full_path), "__name__": f"plugin_schedule_{plugin_name}"}
            exec(compile(source, str(full_path), "exec"), namespace)

            run_func = namespace.get("run")
            if not run_func or not callable(run_func):
                result["errors"].append(f"No 'run' function in {full_path}")
                return result

            # Build event dict for the handler
            from core.plugin_loader import plugin_loader
            plugin_state = plugin_loader.get_plugin_state(plugin_name)

            event = {
                "system": self.system,
                "config": config,
                "task": task,
                "plugin_state": plugin_state,
            }

            output = run_func(event)
            if output:                      # none: a tick, not an event (the notification center logs no row)
                result["responses"].append({"output": str(output)})
            result["success"] = True
            # The handler's one-line receipt used to live only in activity.json
            # (a count) and tasks.json (purged per boot) — three days of dev
            # journal showed MATCHED/Triggering and never a result (row 77).
            logger.info(f"[Continuity] Plugin task '{task.get('name')}' -> {str(output)[:200] if output else '(no output)'}")

            if response_cb and output:
                try: response_cb(str(output))
                except Exception as _e: logger.error(f"[Continuity] Response callback failed: {_e}")

        except Exception as e:
            logger.error(f"[Continuity] Plugin task '{task.get('name')}' failed: {e}", exc_info=True)
            result["errors"].append(str(e))
            publish(Events.CONTINUITY_TASK_ERROR, {
                "task": task.get("name", "Unknown"),
                "error": str(e),
            })

        if progress_cb:
            progress_cb(1, 1)

        result["completed_at"] = datetime.now().isoformat()
        return result

    def _run_device_task(self, task: Dict[str, Any], progress_cb=None, response_cb=None) -> Dict[str, Any]:
        """Run the task's one device action through the device engine as the
        owner (core itself): a locked capability still runs, a `danger`
        action never got past the scheduler's check. The device's answer is
        the receipt; ok=False is a task error (toast + activity)."""
        from core.devices import engine
        da = task.get("device_action") or {}
        result = {
            "success": False,
            "task_id": task.get("id"),
            "task_name": task.get("name"),
            "started_at": datetime.now().isoformat(),
            "responses": [],
            "errors": []
        }
        where = f"{da.get('device')} / {da.get('capability')} / {da.get('action')}"
        try:
            told, ok = engine.run(da.get("device"), da.get("capability"), da.get("action"),
                                  da.get("value") or "", owner=True)
            text = engine.text_of(told)
        except Exception as e:
            logger.error(f"[Continuity] Device task '{task.get('name')}' crashed: {e}", exc_info=True)
            text, ok = f"{where} failed: {type(e).__name__}", False
        if text:                            # responses are what was said; an empty answer is not one
            result["responses"].append({"output": text})
        result["success"] = bool(ok)
        logger.info(f"[Continuity] Device task '{task.get('name')}' {where} -> "
                    f"{'ok' if ok else 'FAILED'}: {text[:200] if text else '(no answer)'}")
        if response_cb and text:
            try: response_cb(text)
            except Exception as _e: logger.error(f"[Continuity] Response callback failed: {_e}")
        if not ok:
            result["errors"].append(text or where)
            publish(Events.CONTINUITY_TASK_ERROR, {"task": task.get("name", "Unknown"),
                                                   "error": text or f"{where} failed"})
        if progress_cb:
            progress_cb(1, 1)
        result["completed_at"] = datetime.now().isoformat()
        return result

    def _resolve_persona(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """If task has a persona, merge persona settings as defaults under task-level overrides."""
        persona_name = task.get("persona", "")
        if not persona_name:
            return task

        try:
            from core.personas import persona_manager
            persona = persona_manager.get(persona_name)
            if not persona:
                logger.warning(f"[Continuity] Persona '{persona_name}' not found, skipping")
                return task

            ps = persona.get("settings", {})
            resolved = dict(task)

            # Persona provides defaults — task-level fields override.
            # Non-scope fields are static; scope fields are pulled dynamically from
            # SCOPE_REGISTRY so new plugin scopes flow through persona inheritance.
            from core.chat.function_manager import scope_setting_keys
            field_map = {
                "prompt": "prompt",
                "toolset": "toolset",
                "voice": "voice",
                "pitch": "pitch",
                "speed": "speed",
                "inject_datetime": "inject_datetime",
            }
            # (llm_primary/llm_model are NOT in the map — the brain merges as
            # a PAIR below, never field by field.)
            # Scope keys: persona key == task key (e.g. memory_scope → memory_scope)
            scope_keys = set(scope_setting_keys())
            for setting_key in scope_keys:
                field_map[setting_key] = setting_key
            # Sentinel values that mean "no preference, fall through to persona default".
            # For scope keys, 'none' is EXPLICIT opt-out ("disable this scope") and must
            # NOT fall through. 'default' is ALSO removed from the scope-key sentinel
            # list (2026-04-21) — 'default' is a real scope name where user memories
            # live, so treating it as a "please override me" sentinel meant an explicit
            # task_val='default' got silently replaced by the persona's scope. Scout
            # day-ruiner #4. Explicit 'default' now means exactly that: use the
            # default scope. Non-scope fields keep the legacy sentinel list.
            _empty_sentinels = ("", "auto", "none", "default", None)
            _empty_sentinels_scope = ("", "auto", None)  # 'none' AND 'default' excluded
            for persona_key, task_key in field_map.items():
                persona_val = ps.get(persona_key)
                task_val = resolved.get(task_key)
                if not persona_val:
                    continue
                if not task_val:
                    resolved[task_key] = persona_val
                    continue
                sentinels = _empty_sentinels_scope if task_key in scope_keys else _empty_sentinels
                if task_val in sentinels:
                    resolved[task_key] = persona_val

            # The brain is a PAIR (2026-10-07): provider and model merge
            # together — a persona's model belongs to the persona's provider
            # and must never ride onto the task's. The task defers (auto /
            # none / blank) → the persona's whole pair; the task pins a
            # provider → its own model stands, inheriting the persona's only
            # when both name the same provider. A model beside auto drops.
            from core.chat.llm_providers.resolve import normalize_pair
            pp, pm = normalize_pair(ps.get("llm_primary"), ps.get("llm_model"))
            tp, tm = normalize_pair(resolved.get("provider"), resolved.get("model"))
            if tp in ("auto", "none"):
                if pp != "auto":
                    tp, tm = pp, pm
            elif not tm and tp == pp:
                tm = pm
            resolved["provider"], resolved["model"] = tp, tm

            logger.info(f"[Continuity] Resolved persona '{persona_name}' into task settings")
            return resolved
        except Exception as e:
            # Previously this bare except returned the raw task, which meant
            # scope keys silently fell to registry defaults ('default', a real
            # scope) downstream. That's the silent-default class. Raise loudly
            # so the caller's try/except surfaces the failure to the user
            # instead of routing writes into the wrong scope. Scout chaos #4/#9.
            logger.error(f"[Continuity] Persona resolution failed for '{persona_name}': {e}", exc_info=True)
            raise

    def _snapshot_voice(self) -> Dict[str, Any]:
        """Snapshot current TTS voice/pitch/speed for later restore."""
        tts = getattr(self.system, 'tts', None)
        if not tts:
            return {}
        try:
            return {
                "voice": getattr(tts, 'voice_name', None),
                "pitch": getattr(tts, 'pitch_shift', None),
                "speed": getattr(tts, 'speed', None),
            }
        except Exception:
            return {}

    def _validate_voice(self, voice: str) -> str:
        """Validate voice matches current TTS provider, substitute default if mismatched."""
        from core.tts.utils import validate_voice
        return validate_voice(voice)

    def _restore_voice(self, snapshot: Dict[str, Any]) -> None:
        """Nothing to restore: a task no longer retunes the shared TTS client
        (hunt 21). It used to set the task's voice globally for the whole run
        and put back a snapshot at the end - a chat switch meanwhile was
        undone, and any reply born during the run spoke in the task's voice.
        The task's voice now rides its own speech (_task_voice)."""
        return None

    def _apply_voice(self, task: Dict[str, Any]) -> None:
        """Validate the task's voice up front (a bad one fails the task early,
        as before); nothing global is set. See _restore_voice."""
        self._task_voice(task)

    def _task_voice(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """{voice, speed, pitch} the task speaks with; a field it doesn't set is
        None (the client's own, the operator's chat's)."""
        voice = task.get("voice") or None
        return {"voice": self._validate_voice(voice) if voice else None,
                "speed": task.get("speed"), "pitch": task.get("pitch")}

    # _apply_task_settings removed — ExecutionContext handles all isolation now