# core/continuity/scheduler.py
"""
Continuity Scheduler - Background thread that checks cron schedules and fires tasks.
"""

import os
import re
import json
import uuid
import random
import logging
import threading
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Dict, List, Any, Optional
from core.fs_utils import replace_with_retry

logger = logging.getLogger(__name__)


# Lazy import croniter to avoid startup crash if not installed
croniter = None

def _get_croniter():
    global croniter
    if croniter is None:
        try:
            from croniter import croniter as _croniter
            croniter = _croniter
        except ImportError:
            logger.error("croniter not installed. Run: pip install croniter")
            raise ImportError("croniter required for Continuity. Install with: pip install croniter")
    return croniter


def task_in_active_hours(task, hour=None) -> bool:
    """Is `hour` (default: now, user timezone) inside the task's active hours?
    No window = always. End is exclusive; start > end wraps overnight (20→04).
    Module-level so a daemon plugin can read its own task's window (the Discord
    bot shows "away" while its Chat task is outside it)."""
    start = task.get("active_hours_start")
    end = task.get("active_hours_end")
    if start is None or end is None:
        return True
    hour = hour if hour is not None else _user_now().hour
    if start <= end:
        return start <= hour < end
    return hour >= start or hour < end


def _user_now():
    """Get current time in user's configured timezone."""
    try:
        import config
        tz_name = getattr(config, 'USER_TIMEZONE', 'UTC') or 'UTC'
        return datetime.now(ZoneInfo(tz_name))
    except Exception:
        return datetime.now(ZoneInfo('UTC'))


def _phone_key(s):
    """Digit-tail (last 10 digits) for phone-shaped strings, else None.
    Only engages when the value looks like a phone number, so non-phone filter
    fields fall through to plain equality untouched."""
    s = str(s).strip()
    if not s or not re.fullmatch(r"[+\d\s().\-]+", s):
        return None
    digits = re.sub(r"\D", "", s)
    return digits[-10:] if len(digits) >= 7 else None


def _value_matches(ev_val, filter_val):
    """Filter equality with two tolerances the caller allowlist needs:
    a comma-separated filter value is an allowlist (match ANY of the entries),
    and phone numbers compare on their digit tail so +1-555-010-1234,
    (555) 010-1234 and 5550101234 all match the same incoming E.164 caller."""
    ev = str(ev_val)
    ev_lower = ev.lower()
    ev_phone = _phone_key(ev)
    for cand in str(filter_val).split(","):
        cand = cand.strip()
        if not cand:
            continue
        if ev_lower == cand.lower():
            return True
        cand_phone = _phone_key(cand)
        if ev_phone and cand_phone and ev_phone == cand_phone:
            return True
    return False


EVENT_TYPES = ("daemon", "webhook")      # fired by events, never by the cron loop


def task_type(task) -> str:
    """A task's type: its `type`, else the legacy `heartbeat` bool's. The ONE
    reading (DRY scout, 2026-10-27: two defaults disagreed - 'task' vs the
    bool - so an API heartbeat with no bool landed in Scheduled)."""
    t = task.get("type") if isinstance(task, dict) else None
    return t or ("heartbeat" if isinstance(task, dict) and task.get("heartbeat") else "task")


class ContinuityScheduler:
    """
    Background scheduler for continuity tasks.
    Checks every 30 seconds, matches cron expressions, respects cooldowns.
    """
    
    CHECK_INTERVAL = 30  # seconds between schedule checks
    
    def __init__(self, system, executor):
        """
        Args:
            system: VoiceChatSystem instance
            executor: ContinuityExecutor instance
        """
        self.system = system
        self.executor = executor
        
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        
        # Paths
        self._base_dir = Path(__file__).parent.parent.parent / "user" / "continuity"
        self._tasks_path = self._base_dir / "tasks.json"
        self._activity_path = self._base_dir / "activity.json"
        
        # In-memory caches
        self._tasks: Dict[str, Dict] = {}
        self._activity: List[Dict] = []

        # Per-task run state: tracks busy flag, queued fires, and last matched minute
        self._task_running: Dict[str, bool] = {}
        self._task_pending: Dict[str, list] = {}  # task_id -> [(event_data, reply_cb), ...]
        self._task_last_matched: Dict[str, str] = {}  # task_id -> "YYYY-MM-DD HH:MM"
        self._task_progress: Dict[str, Dict] = {}  # task_id -> {iteration, total}
        # task_id -> threading.Event for the run in flight. Armed fresh per
        # run; set by cancel_task / toggle-off / delete. Read by the executor
        # between LLM rounds. 2026-09-08.
        self._task_cancel: Dict[str, threading.Event] = {}
        self._event_threads: list = []  # track spawned event worker threads
        self._concurrency_sem = threading.Semaphore(3)  # max 3 concurrent task threads
        
        self._ensure_dirs()
        self._load_tasks()
        self._load_activity()
    
    def _ensure_dirs(self):
        """Create user/continuity directory if missing."""
        self._base_dir.mkdir(parents=True, exist_ok=True)
    
    # =========================================================================
    # TASK PERSISTENCE
    # =========================================================================
    
    def _load_tasks(self):
        """Load tasks from JSON file. Purges plugin-sourced tasks (they re-register on load).
        Migrates legacy heartbeat bool to type field."""
        if not self._tasks_path.exists():
            self._tasks = {}
            return

        try:
            with open(self._tasks_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            # Per-entry tolerance (scout, 2026-07-20): one malformed entry
            # (missing "id") used to KeyError the whole comprehension →
            # _tasks = {} → and the same boot's plugin registration then
            # PERSISTED the wipe. Skip bad entries loudly instead.
            all_tasks = {}
            for t in data.get("tasks", []):
                if isinstance(t, dict) and t.get("id"):
                    all_tasks[t["id"]] = t
                else:
                    logger.error(f"[Continuity] Skipping malformed task entry "
                                 f"(no id): {str(t)[:120]}")

            # Purge plugin-sourced tasks — plugins re-register theirs via set_scheduler()
            plugin_count = 0
            migrated = 0
            for tid in list(all_tasks):
                # Manifest schedules are re-registered from the manifest each
                # boot; a plugin's runtime tasks (alarms) are the person's own
                # and stay (the clock promised "Survives reboot" - 2026-10-27).
                if str(all_tasks[tid].get("source") or "").startswith("plugin:") and not all_tasks[tid].get("runtime"):
                    del all_tasks[tid]
                    plugin_count += 1
                    continue
                # Migrate: heartbeat bool → type field
                if "type" not in all_tasks[tid]:
                    all_tasks[tid]["type"] = "heartbeat" if all_tasks[tid].get("heartbeat") else "task"
                    migrated += 1
                # Ensure trigger_config exists
                if "trigger_config" not in all_tasks[tid]:
                    all_tasks[tid]["trigger_config"] = {}

            self._tasks = all_tasks
            if plugin_count or migrated:
                self._save_tasks()
                if plugin_count:
                    logger.info(f"[Continuity] Purged {plugin_count} plugin task(s) from previous session")
                if migrated:
                    logger.info(f"[Continuity] Migrated {migrated} task(s) to type field")
            logger.info(f"[Continuity] Loaded {len(self._tasks)} tasks")
        except Exception as e:
            logger.error(f"[Continuity] Failed to load tasks: {e}")
            # Preserve the unreadable file before anything can persist over
            # it — a later _save_tasks (plugin registration runs the same
            # boot) would otherwise make the wipe permanent with no backup
            # (scout, 2026-07-20).
            try:
                import shutil
                from datetime import datetime as _dt
                bad = self._tasks_path.with_name(
                    self._tasks_path.name +
                    f".bad-{_dt.now().strftime('%Y%m%d-%H%M%S')}")
                shutil.copy2(self._tasks_path, bad)
                logger.error(f"[Continuity] Unreadable tasks file preserved "
                             f"at {bad.name} — restore by hand after fixing.")
            except Exception:
                pass
            self._tasks = {}

    def _save_tasks(self):
        """Save tasks to JSON file (atomic write via temp + rename)."""
        try:
            import tempfile
            data = {"tasks": list(self._tasks.values())}
            fd, tmp = tempfile.mkstemp(dir=self._tasks_path.parent, suffix='.tmp')
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                replace_with_retry(Path(tmp), self._tasks_path)
            except Exception:
                Path(tmp).unlink(missing_ok=True)
                raise
        except Exception as e:
            logger.error(f"[Continuity] Failed to save tasks: {e}")
    
    def _load_activity(self):
        """Load activity log from JSON file."""
        if not self._activity_path.exists():
            self._activity = []
            return
        
        try:
            with open(self._activity_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
            self._activity = data.get("activity", [])[-50:]  # Keep last 50
        except Exception as e:
            logger.error(f"[Continuity] Failed to load activity: {e}")
            self._activity = []
    
    def _save_activity(self):
        """Save activity log to JSON file (atomic write)."""
        try:
            import tempfile
            data = {"activity": self._activity[-50:]}  # Keep last 50
            fd, tmp = tempfile.mkstemp(dir=self._activity_path.parent, suffix='.tmp')
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2)
                replace_with_retry(Path(tmp), self._activity_path)
            except Exception:
                Path(tmp).unlink(missing_ok=True)
                raise
        except Exception as e:
            logger.error(f"[Continuity] Failed to save activity: {e}")
    
    def _log_activity(self, task_id: str, task_name: str, status: str, details: Optional[Dict] = None):
        """Add entry to activity log."""
        entry = {
            "timestamp": _user_now().isoformat(),
            "task_id": task_id,
            "task_name": task_name,
            "status": status,
            "details": details or {}
        }
        self._activity.append(entry)
        self._activity = self._activity[-50:]  # Trim
        self._save_activity()
        
        # Publish event. `cancel_requested` publishes nothing: the run is
        # still live, and the old fall-through to COMPLETE flipped the body
        # LED idle / cleared the avatar rail at the ⏹ click (E2#5).
        if status == "cancel_requested":
            return
        from core.event_bus import publish, Events
        event_map = {
            "started": Events.CONTINUITY_TASK_STARTING,
            "complete": Events.CONTINUITY_TASK_COMPLETE,
            "cancelled": Events.CONTINUITY_TASK_COMPLETE,
            "skipped": Events.CONTINUITY_TASK_SKIPPED,
            "error": Events.CONTINUITY_TASK_ERROR,
        }
        event_type = event_map.get(status, Events.CONTINUITY_TASK_COMPLETE)
        publish(event_type, {"task_id": task_id, "task_name": task_name, **entry})
    
    # =========================================================================
    # TASK CRUD
    def _log_result(self, task_id, task_name, result, **extra):
        """One activity row for a finished run - the same fields from the cron,
        manual and event paths (the event path had dropped `errors`)."""
        status = "cancelled" if result.get("cancelled") else ("complete" if result.get("success") else "error")
        self._log_activity(task_id, task_name, status, {
            **extra,
            "responses": len(result.get("responses", [])),
            "errors": result.get("errors", []),
        })

    def _record_run(self, task_id: str, clear_progress: bool = True):
        """A run finished: stamp last_run, count it (auto-disable or delete at
        its limit), save. The one copy for the cron, manual and event paths
        (DRY scout, 2026-10-27). A delete's vault reference is released after
        the lock (its scan re-enters it)."""
        gone = None
        with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id]["last_run"] = _user_now().isoformat()
                gone = self._increment_run_count(task_id)
                self._save_tasks()
            if clear_progress:
                self._task_progress.pop(task_id, None)
        if gone:
            self._vault_ref_sync(None, gone)

    def _forget_task(self, task_id: str, stop: bool = True):
        """Drop a task and every piece of its runtime state. Call under
        self._lock. stop=True also stops a live run. Returns the prompt name
        it referred to (release it with _vault_ref_sync after the lock)."""
        old_prompt = self._tasks.pop(task_id, {}).get("prompt")
        self._task_pending.pop(task_id, None)
        self._task_running.pop(task_id, None)
        self._task_last_matched.pop(task_id, None)
        self._task_progress.pop(task_id, None)
        _ev = self._cancel_events().pop(task_id, None)
        if _ev is not None and stop:
            _ev.set()   # a deleted task's live run stops too
        return old_prompt

    def _increment_run_count(self, task_id: str):
        """Increment run counter, auto-disable/delete if limits reached. Call
        under self._lock. Returns the deleted task's prompt name, or None."""
        task = self._tasks.get(task_id)
        if not task:
            return
        task_name = task.get("name", "Unknown")
        max_runs = task.get("max_runs", 0)

        # Increment counter (always, even for delete_after_run — for logging accuracy)
        if max_runs > 0:
            task["run_count"] = task.get("run_count", 0) + 1

        # Check delete_after_run — fires after max_runs is reached (or immediately if max_runs=0)
        if task.get("delete_after_run"):
            if max_runs <= 0 or task.get("run_count", 1) >= max_runs:
                queued = len(self._task_pending.get(task_id, []))
                if queued:
                    logger.warning(f"[Continuity] '{task_name}' — delete_after_run dropping {queued} queued events")
                logger.info(f"[Continuity] '{task_name}' — delete_after_run, removing task")
                return self._forget_task(task_id, stop=False)

        # Auto-disable at max runs
        if max_runs > 0 and task.get("run_count", 0) >= max_runs:
            task["enabled"] = False
            logger.info(f"[Continuity] '{task_name}' completed {task['run_count']}/{max_runs} runs — auto-disabled")

    # =========================================================================

    def list_tasks(self) -> List[Dict]:
        """Get all tasks, with live progress info merged in."""
        with self._lock:
            tasks = []
            for t in self._tasks.values():
                task = dict(t)  # shallow copy so we don't persist transient fields
                task["running"] = self._task_running.get(t["id"], False)
                _ev = self._cancel_events().get(t["id"])
                task["cancelling"] = bool(task["running"] and _ev is not None and _ev.is_set())
                progress = self._task_progress.get(t["id"])
                if progress:
                    task["progress"] = progress
                    # Use live timestamp from progress (known to reach UI)
                    if progress.get("timestamp"):
                        task["last_run"] = progress["timestamp"]
                tasks.append(task)
        # The Idle Heartbeat card's line, outside the lock (the idle clock's
        # first ask after a boot reads the chat database): how long the person
        # has been quiet, how many beats this quiet has had, when the next is due.
        for task in tasks:
            if is_idle(task):
                due, stretch, fires, quiet = idle_state(task)
                mins = int(task.get("idle_minutes") or 0)
                task["quiet_min"] = None if quiet is None else round(quiet, 1)
                task["idle_fires_now"] = fires
                done = task.get("idle_backoff", True) and fires >= self.IDLE_MAX_FIRES
                task["idle_next_min"] = None if done else mins * (2 ** fires if task.get("idle_backoff", True) else 1)
                look = idle_next_look(task, None if stretch is None else time.time() - quiet * 60, _user_now())
                task["idle_next_look"] = look.isoformat() if look else None
        return tasks
    
    def get_task(self, task_id: str) -> Optional[Dict]:
        """Get single task by ID."""
        with self._lock:
            return self._tasks.get(task_id)
    
    # Total and daemon caps are settings (Settings > System > Advanced, hot):
    # MAX_TOTAL_TASKS / MAX_DAEMON_TASKS. Realtime rules are daemon-type
    # tasks, so they share the daemon cap (2026-09-23). Heartbeat and
    # webhook caps stay fixed.
    MAX_HEARTBEATS = 4
    MAX_IDLE_HEARTBEATS = 4         # their own column, their own slots
    IDLE_MAX_FIRES = 3              # with backoff: at 1x, 2x, 4x the quiet, then it waits for the person
    MAX_WEBHOOKS = 10

    @staticmethod
    def _vault_ref_sync(new_name, old_name):
        """Tasks are the third referrer class of the vault references index.
        Called OUTSIDE self._lock (the release scan re-enters it)."""
        try:
            from core.prompt_crud import vault_ref_sync
            vault_ref_sync(new_name, old_name)
        except Exception:
            pass

    @staticmethod
    def _prompt_requires_privacy(name: str) -> bool:
        """Resolve a prompt name and report its privacy_required flag.
        Unresolvable (or any error) → False: the carrier this feeds is
        OR-ed with the LIVE derivation at run time, so a miss here can
        only under-stamp at edit time, never weaken an existing True."""
        try:
            from core import prompts
            p = prompts.get_prompt(name)
            return bool(isinstance(p, dict) and p.get('privacy_required'))
        except Exception:
            return False

    @staticmethod
    def _check_device_action(data: Dict) -> Dict:
        """A Device task (2026-10-06: the editor's "Chat / Device" radio) runs
        one device action with no LLM. The action is checked against what the
        device describes NOW, so a renamed device or a vanished action is a
        400 at save time, not a nightly error. A `danger` action (a card
        format) is never schedulable. Returns the clean dict ({} = Chat)."""
        da = data.get("device_action")
        if not da:
            return {}
        if not isinstance(da, dict):
            raise ValueError("device_action must be an object")
        clean = {k: str(da.get(k) or "").strip() for k in ("device", "capability", "action", "value")}
        if not (clean["device"] and clean["capability"] and clean["action"]):
            raise ValueError("A Device task needs a device, a capability and an action")
        from core.devices import engine
        try:
            row = engine.get(clean["device"])
        except engine.DeviceError as e:
            raise ValueError(str(e))
        if not row.get("enabled", True):
            raise ValueError(f"'{row['id']}' is turned off in Settings > Devices")
        caps = engine.describe(row)
        cap = next((c for c in caps if c["capability"] == clean["capability"]), None)
        if not cap:
            raise ValueError(f"'{clean['device']}' has no '{clean['capability']}'")
        if cap.get("error"):
            raise ValueError(f"{clean['device']} / {clean['capability']}: {cap['error']}")
        act = (cap.get("actions") or {}).get(clean["action"])
        if act is None:
            raise ValueError(f"'{clean['capability']}' on '{clean['device']}' has no action '{clean['action']}'")
        if act.get("danger"):
            raise ValueError(f"'{clean['action']}' asks for I UNDERSTAND every time; it cannot run on a schedule")
        return clean

    @staticmethod
    def _check_llm_provider(data: Dict) -> None:
        """A task's provider must exist (2026-09-21): the editor's list was
        the only check, so a deleted provider stayed pinned and the task
        failed every run. Raises ValueError (routes answer 400)."""
        if "provider" not in data:
            return
        p = str(data.get("provider") or "auto").strip() or "auto"
        if p in ("auto", "none"):
            return
        from core.chat.llm_providers.resolve import providers_config
        if p not in providers_config():
            raise ValueError(f"Unknown LLM provider '{p}' — pick one from Settings › LLM")

    # A task's internal fields: set by core and plugins in-process, never by a
    # request body or an imported file. `handler` + `plugin_dir` name a file
    # the executor runs - from a REST post or a task import that was a way to
    # run any file on disk (DRY scout, 2026-10-27).
    INTERNAL_FIELDS = ('id', 'handler', 'plugin_dir', 'run_count', 'last_run', 'last_response', 'created',
                       'runtime', 'idle_stretch', 'idle_fires')

    def create_task(self, data: Dict, trusted: bool = False) -> Dict:
        """Create new task, returns the created task. trusted=True: an
        in-process caller (the plugin loader, a plugin's own runtime task) may
        set the internal fields; anyone else's are dropped, and a `plugin:`
        source with them."""
        if not trusted:
            data = {k: v for k, v in data.items() if k not in self.INTERNAL_FIELDS}
            if str(data.get("source") or "").startswith("plugin:"):
                data.pop("source")
        # P3-T14: the sealed-vault display mask is never a real target.
        if data.get("chat_target") == "__locked__":
            data = {k: v for k, v in data.items() if k != "chat_target"}
        self._check_llm_provider(data)
        device_action = self._check_device_action(data)
        ttype = task_type(data)
        idle_minutes, idle_backoff = _idle_fields(data, ttype)
        import config
        max_daemons = int(config.MAX_DAEMON_TASKS)
        max_total = int(config.MAX_TOTAL_TASKS)

        with self._lock:
            total = len(self._tasks)
            type_counts = {}
            for t in self._tasks.values():
                tt = "idle heartbeat" if is_idle(t) else task_type(t)
                type_counts[tt] = type_counts.get(tt, 0) + 1

            limits = {"heartbeat": self.MAX_HEARTBEATS, "idle heartbeat": self.MAX_IDLE_HEARTBEATS,
                      "daemon": max_daemons, "webhook": self.MAX_WEBHOOKS}
            kind = "idle heartbeat" if idle_minutes else ttype
            if kind in limits and type_counts.get(kind, 0) >= limits[kind]:
                hint = " - raise Max Daemon Tasks in Settings > System > Advanced" if kind == "daemon" else ""
                raise ValueError(f"Maximum {kind} tasks reached ({limits[kind]}){hint}")
            if total >= max_total:
                raise ValueError(f"Maximum tasks reached ({max_total}) - raise Max Total Tasks in Settings > System > Advanced")

        # The pair rule (2026-10-07): a model beside an auto provider is dead
        # at resolve time — store the coherent pair, not what was posted.
        from core.chat.llm_providers.resolve import normalize_pair
        provider, model = normalize_pair(data.get("provider", "auto"), data.get("model", ""))
        task = {
            "id": str(uuid.uuid4()),
            "type": ttype,
            "name": data.get("name", "Unnamed Task"),
            "enabled": data.get("enabled", True),
            "schedule": data.get("schedule", "0 9 * * *"),
            "trigger_config": data.get("trigger_config", {}),
            "chance": data.get("chance", 100),
            "provider": provider,
            "model": model,
            "prompt": data.get("prompt", "default"),
            "toolset": data.get("toolset", "none"),
            "chat_target": data.get("chat_target", ""),
            "initial_message": data.get("initial_message", "" if device_action else "Hello."),
            "device_action": device_action,
            "tts_enabled": data.get("tts_enabled", True),
            "browser_tts": data.get("browser_tts", False),
            "inject_datetime": data.get("inject_datetime", False),
            "persona": data.get("persona", ""),
            "voice": data.get("voice", ""),
            "pitch": data.get("pitch", None),
            "speed": data.get("speed", None),
            "heartbeat": ttype == "heartbeat",      # derived from type, never its own truth
            # Idle Heartbeat: fires once the person has been quiet this many
            # minutes (0 = a plain heartbeat); backoff = 1x, 2x, 4x, then wait
            "idle_minutes": idle_minutes,
            "idle_backoff": idle_backoff,
            "emoji": data.get("emoji", ""),
            "context_limit": data.get("context_limit", 0),
            "max_parallel_tools": data.get("max_parallel_tools", 0),
            "max_tool_rounds": data.get("max_tool_rounds", 0),
            "active_hours_start": data.get("active_hours_start", None),
            "active_hours_end": data.get("active_hours_end", None),
            "source": data.get("source", ""),
            "handler": data.get("handler", ""),
            "plugin_dir": data.get("plugin_dir", ""),
            "max_runs": data.get("max_runs", 0),
            "run_count": data.get("run_count", 0),
            "delete_after_run": data.get("delete_after_run", False),
            # a plugin's own runtime task (a clock alarm), not a manifest
            # schedule: it survives a reboot (manifest ones are re-registered)
            "runtime": bool(data.get("runtime", False)),
            "last_run": None,
            "last_response": None,
            "created": _user_now().isoformat()
        }

        # Privacy carrier (2026-08-09, vault phase 0c): privacy is part of the
        # task's CONTRACT, not a lookup side-effect. Stamped here from the
        # resolved prompt, OR-ed with the live derivation at run time
        # (ExecutionContext._build_prompt) — the carrier is what survives the
        # pinned prompt becoming unresolvable (deleted, or asleep in a locked
        # vault), which used to silently drop the task onto cloud providers.
        task["privacy_required"] = (bool(data.get("privacy_required"))
                                    or self._prompt_requires_privacy(task["prompt"]))

        # Dynamically include all scope keys from SCOPE_REGISTRY so plugin scopes
        # propagate without code changes. Default 'none' for new tasks (disabled by default).
        from core.chat.function_manager import scope_setting_keys
        for setting_key in scope_setting_keys():
            task[setting_key] = data.get(setting_key, "none")

        # Auto-generate webhook secret if not provided
        if ttype == "webhook":
            tc = task.get("trigger_config", {})
            if not tc.get("secret"):
                import secrets as _secrets
                tc["secret"] = _secrets.token_urlsafe(32)
                task["trigger_config"] = tc

        # Validate cron
        try:
            _get_croniter()(task["schedule"], _user_now())
        except Exception as e:
            raise ValueError(f"Invalid cron schedule: {e}")
        
        with self._lock:
            self._tasks[task["id"]] = task
            self._save_tasks()

        logger.info(f"[Continuity] Created task: {task['name']} ({task['id']})")
        self._vault_ref_sync(task.get("prompt"), None)
        return task
    
    def update_task(self, task_id: str, data: Dict) -> Optional[Dict]:
        """Update existing task."""
        with self._lock:
            if task_id not in self._tasks:
                return None
            
            task = self._tasks[task_id]
            old_prompt = task.get("prompt") if "prompt" in data else None

            # P3-T14: '__locked__' is the route's sealed-vault display mask,
            # never a real target — a round-trip edit keeps the stored name.
            if data.get("chat_target") == "__locked__":
                data = {k: v for k, v in data.items() if k != "chat_target"}
            self._check_llm_provider(data)
            if "device_action" in data:
                data = {**data, "device_action": self._check_device_action(data)}
            # The pair rule for tasks (S6 2026-09-21; one rule 2026-10-07): a
            # provider change drops the old model unless the edit sets one,
            # and a model never lands beside an auto provider.
            from core.chat.llm_providers.resolve import normalize_pair_patch
            data = normalize_pair_patch(task, data, key="provider", model_key="model")

            # Validate cron if provided
            if "schedule" in data:
                try:
                    _get_croniter()(data["schedule"], _user_now())
                except Exception as e:
                    raise ValueError(f"Invalid cron schedule: {e}")
            
            # Update allowed fields. Scope keys are pulled dynamically from SCOPE_REGISTRY
            # so new plugin scopes can be updated on tasks without touching this set.
            from core.chat.function_manager import scope_setting_keys
            allowed = {
                "name", "type", "enabled", "schedule", "trigger_config", "chance",
                "provider", "model", "prompt", "toolset", "chat_target",
                "initial_message", "device_action", "tts_enabled", "browser_tts", "inject_datetime",
                "persona", "voice", "pitch", "speed",
                "heartbeat", "emoji",
                "context_limit", "max_parallel_tools", "max_tool_rounds",
                "active_hours_start", "active_hours_end",
                "max_runs", "delete_after_run", "privacy_required",
                "idle_minutes", "idle_backoff",
            }
            allowed.update(scope_setting_keys())
            for key in allowed:
                if key in data:
                    task[key] = data[key]
            if "idle_minutes" in data or "idle_backoff" in data or "type" in data:
                task["idle_minutes"], task["idle_backoff"] = _idle_fields(task, task_type(task))
            if "type" in data or "heartbeat" in data:
                if "type" not in data:
                    task["type"] = task_type({"heartbeat": data["heartbeat"]})
                task["heartbeat"] = task_type(task) == "heartbeat"     # one truth: the type

            # Re-stamp the privacy carrier whenever the prompt or the flag
            # changed: stored value OR derived-from-prompt. A user can't
            # un-flag a task whose pinned prompt demands privacy (same rule
            # as the chat-settings 409 guard: switch prompts first). Stale
            # directions are fail-CLOSED only — a True left behind by a
            # since-public prompt stays until explicitly cleared.
            if "prompt" in data or "privacy_required" in data:
                task["privacy_required"] = (
                    bool(task.get("privacy_required"))
                    or self._prompt_requires_privacy(task.get("prompt", "default")))
            
            # Reset run count when re-enabling a completed task
            if data.get("enabled") and task.get("max_runs", 0) > 0:
                if task.get("run_count", 0) >= task["max_runs"]:
                    task["run_count"] = 0
                    logger.info(f"[Continuity] Reset run count for re-enabled task '{task.get('name')}'")

            # Reset run state — clears pending queue and allows fresh cron match
            self._task_pending[task_id] = []
            self._task_last_matched.pop(task_id, None)

            # Toggling OFF a running task cancels its in-flight run. Before
            # this the drain loop only stopped BETWEEN runs — a daemon in a
            # long tool loop had no off switch (Krem, 2026-09-08).
            if data.get("enabled") is False and self._task_running.get(task_id):
                _ev = self._cancel_events().get(task_id)
                if _ev is not None:
                    _ev.set()
                    logger.info(f"[Continuity] '{task['name']}' disabled mid-run — cancelling")

            self._save_tasks()
            logger.info(f"[Continuity] Updated task: {task['name']} ({task_id})")
        if "prompt" in data:
            self._vault_ref_sync(data.get("prompt"), old_prompt)
        return task
    
    def delete_task(self, task_id: str) -> bool:
        """Delete task by ID."""
        with self._lock:
            if task_id not in self._tasks:
                return False
            
            name = self._tasks[task_id].get("name", task_id)
            old_prompt = self._forget_task(task_id)
            self._save_tasks()
            logger.info(f"[Continuity] Deleted task: {name} ({task_id})")
        self._vault_ref_sync(None, old_prompt)
        return True

    # ── Cancel (⏹ / toggle-off / delete) ──

    def _cancel_events(self) -> Dict[str, threading.Event]:
        # Test fixtures build the scheduler via __new__ and may skip __init__.
        d = getattr(self, "_task_cancel", None)
        if d is None:
            d = self._task_cancel = {}
        return d

    def _arm_cancel(self, task_id: str) -> threading.Event:
        """Fresh cancel Event for the run about to start. Armed in the SAME
        lock block that flips `_task_running` True (pre-push hunt
        2026-09-08, E2#1): arming later — after the concurrency semaphore
        wait — left a gap where ⏹ set the PREVIOUS run's Event and the new
        one was born unset (stop silently lost, UI said Stopping… then
        Running…). The run sites read the armed Event back (`_run_cancel`)
        instead of re-arming, so one Event spans a run's whole lifetime
        including drained queue iterations."""
        ev = threading.Event()
        self._cancel_events()[task_id] = ev
        return ev

    def _run_cancel(self, task_id: str) -> threading.Event:
        """The Event armed with `_task_running` — or a fresh one for a
        caller that set the flag without arming (test doubles)."""
        return self._cancel_events().get(task_id) or self._arm_cancel(task_id)

    def cancel_task(self, task_id: str) -> Dict[str, Any]:
        """Stop a task's in-flight run and drop anything queued behind it.
        The run ends at its next cancel point (between LLM rounds); the
        task stays enabled — a new event fires it again normally."""
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return {"success": False, "error": "Task not found"}
            running = self._task_running.get(task_id, False)
            self._task_pending[task_id] = []
            ev = self._cancel_events().get(task_id)
            # Only a RUNNING task's Event: setting a finished run's Event
            # made the next run paint "Stopping…" for its whole pre-arm
            # window. Second ⏹ on the same run = no second ledger row.
            already = ev is not None and ev.is_set()
            if ev is not None and running:
                ev.set()
            name = task.get("name", "Unnamed")
        if running and not already:
            logger.info(f"[Continuity] Cancel requested: {name}")
            self._log_activity(task_id, name, "cancel_requested")
        return {"success": True, "was_running": running}
    
    # =========================================================================
    # SCHEDULE CHECKING
    # =========================================================================
    
    def _cron_matches_now(self, cron_expr: str, last_check: datetime) -> bool:
        """
        Check if cron expression matches current minute.
        Uses croniter to get next scheduled time and compares.
        """
        try:
            cron = _get_croniter()(cron_expr, last_check - timedelta(minutes=1))
            next_time = cron.get_next(datetime)
            now = _user_now()
            
            matched = (next_time.year == now.year and
                       next_time.month == now.month and
                       next_time.day == now.day and
                       next_time.hour == now.hour and
                       next_time.minute == now.minute)
            
            if not matched:
                logger.debug(f"[Continuity] Cron '{cron_expr}': next={next_time.strftime('%H:%M')}, now={now.strftime('%H:%M')}")
            
            return matched
        except Exception as e:
            # "failed to find next date" is expected for daemon/webhook tasks that use
            # impossible schedules like "0 0 31 2 *" (Feb 31) to prevent cron firing.
            if 'next date' in str(e).lower() or 'next due' in str(e).lower():
                logger.debug(f"[Continuity] Cron '{cron_expr}' has no next date (expected for daemon/webhook tasks)")
            else:
                logger.error(f"[Continuity] Cron check failed for '{cron_expr}': {e}")
            return False
    
    def _make_progress_callback(self, task_id: str):
        """Create a progress callback for the executor."""
        def callback(iteration: int, total: int):
            now = _user_now().isoformat()
            with self._lock:
                self._task_progress[task_id] = {
                    "iteration": iteration,
                    "total": total,
                    "timestamp": now
                }
                if task_id in self._tasks:
                    self._tasks[task_id]["last_run"] = now
        return callback

    def _make_response_callback(self, task_id: str):
        """Create a response callback — stores last_response before TTS blocks."""
        def callback(response: str):
            from core import think
            clean = think.strip(response)
            with self._lock:
                if task_id in self._tasks:
                    self._tasks[task_id]["last_response"] = clean or None
                    self._save_tasks()
        return callback

    def _execute_task(self, task: Dict):
        """Execute a task and drain any pending queue. Runs on a worker thread."""
        self._concurrency_sem.acquire()
        try:
            self._execute_task_inner(task)
        finally:
            self._concurrency_sem.release()

    def _execute_task_inner(self, task: Dict):
        task_id = task["id"]
        task_name = task.get("name", "Unnamed")

        while True:
            # Re-check enabled state (task dict is shared, updated by update_task)
            with self._lock:
                live_task = self._tasks.get(task_id)
                if not live_task or not live_task.get("enabled", True):
                    logger.info(f"[Continuity] '{task_name}' disabled — stopping execution")
                    self._task_pending[task_id] = []
                    self._task_running[task_id] = False
                    self._task_progress.pop(task_id, None)
                    break

            self._log_activity(task_id, task_name, "started")
            ev = self._run_cancel(task_id)
            try:
                result = self.executor.run(
                    task,
                    progress_callback=self._make_progress_callback(task_id),
                    response_callback=self._make_response_callback(task_id),
                    cancel_event=ev,
                )

                self._record_run(task_id)

                # The executor's own verdict, not the Event: a ⏹ landing
                # after the run finished must not relabel real work.
                self._log_result(task_id, task_name, result)
            except Exception as e:
                logger.error(f"[Continuity] Task '{task_name}' execution failed: {e}", exc_info=True)
                self._log_activity(task_id, task_name, "error", {"exception": str(e)})
                with self._lock:
                    self._task_progress.pop(task_id, None)

            # Check for queued fires
            with self._lock:
                if ev.is_set():
                    # cancel = queued fires die too (Krem's ruling 2026-09-08:
                    # drop, but say so — a count only, never event content).
                    dropped = len(self._task_pending.get(task_id, []))
                    if dropped:
                        logger.warning(f"[Continuity] '{task_name}' stopped — dropping {dropped} queued fire(s)")
                    self._task_pending[task_id] = []
                queue = self._task_pending.get(task_id, [])
                if queue:
                    queue.pop(0)  # Cron queues don't carry data, just drain
                    logger.info(f"[Continuity] '{task_name}' draining queue ({len(queue)} remaining)")
                    continue  # Run again immediately
                else:
                    self._task_running[task_id] = False
                    break

    def _in_active_hours(self, task, check_hour=None):
        """Check if an hour is within the task's active hours window."""
        return task_in_active_hours(task, check_hour)

    def _check_and_run(self):
        """Single check cycle - evaluate all tasks, run eligible ones."""
        now = _user_now()

        with self._lock:
            tasks_snapshot = list(self._tasks.values())

        if not tasks_snapshot:
            return

        logger.debug(f"[Continuity] Checking {len(tasks_snapshot)} tasks at {now.strftime('%H:%M:%S')}")

        for task in tasks_snapshot:
            if not task.get("enabled", True):
                continue

            # Event-triggered tasks don't fire via cron
            if task_type(task) in EVENT_TYPES:
                continue

            task_id = task["id"]
            task_name = task.get("name", "Unnamed")
            schedule = task.get("schedule", "")

            # Check cron match
            cron_matched = self._cron_matches_now(schedule, now - timedelta(seconds=self.CHECK_INTERVAL))
            if not cron_matched:
                logger.debug(f"[Continuity] '{task_name}' schedule '{schedule}' - no match at {now.strftime('%H:%M')}")
                continue

            # Dedup: only fire once per matching minute (scheduler checks every 30s)
            current_minute = now.strftime('%Y-%m-%d %H:%M')
            if self._task_last_matched.get(task_id) == current_minute:
                continue
            self._task_last_matched[task_id] = current_minute

            # Check active hours window
            if not self._in_active_hours(task):
                start = task.get("active_hours_start")
                end = task.get("active_hours_end")
                logger.info(f"[Continuity] '{task_name}' outside active hours ({start}:00-{end}:00), skipping")
                continue

            # Idle Heartbeat: only once the person has been quiet long enough
            # (the cron above is how often it looks). Before the chance roll, so
            # a missed roll is simply a later look (Krem: random delay).
            idle_due = None
            if is_idle(task):
                due, stretch, fires, quiet = idle_state(task)
                if not due:
                    continue
                idle_due = (stretch, idle_fired(task, fires, quiet))

            # Chance roll — gates the entire firing
            chance = task.get("chance", 100)
            if chance < 100:
                roll = random.randint(1, 100)
                if roll > chance:
                    logger.info(f"[Continuity] '{task_name}' failed chance roll ({roll} > {chance}%), skipping")
                    continue

            logger.info(f"[Continuity] '{task_name}' schedule '{schedule}' - MATCHED at {now.strftime('%H:%M')}")

            # If task is already running, queue it instead of overlapping.
            # Cap at 3 (scout, 2026-07-20): the cron path was UNCAPPED — a
            # heartbeat wedged behind a hung provider accumulated one queued
            # fire per matched minute, then machine-gunned them all on
            # release. Missed fires beyond the cap coalesce into nothing.
            with self._lock:
                if self._task_running.get(task_id, False) and idle_due is not None:
                    continue                    # an idle beat never queues: its next look re-checks the quiet
                if self._task_running.get(task_id, False):
                    queue = self._task_pending.setdefault(task_id, [])
                    if len(queue) >= 3:
                        logger.warning(f"[Continuity] '{task_name}' pending "
                                       f"queue full — coalescing this fire")
                        continue
                    queue.append((None, None))  # Cron queues don't carry event data
                    logger.info(f"[Continuity] '{task_name}' busy — queued (pending: {len(queue)})")
                    self._log_activity(task_id, task_name, "queued", {"pending": len(queue)})
                    continue
                self._task_running[task_id] = True
                self._arm_cancel(task_id)
                if idle_due is not None and task_id in self._tasks:
                    # counted at dispatch: a run that fails still counts (no error loop)
                    self._tasks[task_id]["idle_stretch"], self._tasks[task_id]["idle_fires"] = idle_due
                    self._save_tasks()

            # Run on a separate thread so different tasks can run concurrently.
            # LOAD-BEARING: fresh threading.Thread per task is required for scope
            # isolation. ExecutionContext._build_scopes() mutates ContextVars on
            # this thread; a threadpool/reused-worker model would leak scope state
            # from the previous task's scope_memory/scope_rag/etc. If you refactor
            # this to a pool, you MUST wrap execution in copy_context().run() or
            # save/reset tokens per-task. See witch hunt 2026-04-17.
            logger.info(f"[Continuity] Triggering task: {task_name}")
            thread = threading.Thread(
                target=self._execute_task, args=(task,),
                daemon=True, name=f"Continuity-{task_name}"
            )
            thread.start()
    
    # =========================================================================
    # MANUAL RUN
    # =========================================================================
    
    def run_task_now(self, task_id: str) -> Dict[str, Any]:
        """Manually trigger a task immediately (for testing). Runs synchronously.

        Note on concurrent-scope safety: this runs the task on the caller's
        thread, potentially interleaving with the active chat. Scope bleed is
        prevented by `ExecutionContext.__enter__` (core/continuity/execution_context.py)
        which calls `reset_scopes()` at entry — the task always starts with a
        clean scope slate, never inheriting from whatever request triggered
        the manual run. Scout-4 "Race #5" (2026-04-19) is architecturally
        neutralized there; do not re-hunt without checking ExecutionContext.
        """
        with self._lock:
            task = self._tasks.get(task_id)

        if not task:
            return {"success": False, "error": "Task not found"}

        task_name = task.get("name", "Unnamed")

        # Check if already running
        with self._lock:
            if self._task_running.get(task_id, False):
                return {"success": False, "error": f"Task '{task_name}' is already running"}
            self._task_running[task_id] = True
            self._arm_cancel(task_id)

        logger.info(f"[Continuity] Manual run: {task_name}")
        self._log_activity(task_id, task_name, "started", {"manual": True})
        ev = self._run_cancel(task_id)

        try:
            result = self.executor.run(
                task,
                progress_callback=self._make_progress_callback(task_id),
                response_callback=self._make_response_callback(task_id),
                cancel_event=ev,
            )

            self._record_run(task_id, clear_progress=False)

            self._log_result(task_id, task_name, result, manual=True)

            return result

        except Exception as e:
            logger.error(f"[Continuity] Manual run failed: {e}", exc_info=True)
            self._log_activity(task_id, task_name, "error", {"manual": True, "exception": str(e)})
            return {"success": False, "error": str(e)}

        finally:
            with self._lock:
                self._task_running[task_id] = False
                self._task_progress.pop(task_id, None)
    
    # =========================================================================
    # EVENT-TRIGGERED EXECUTION
    # =========================================================================

    def fire_event_task(self, task_id: str, event_data: str, reply_callback=None,
                        skip_filter: bool = False) -> Dict[str, Any]:
        """Fire an event-triggered task (daemon or webhook) with event data.
        Runs on a worker thread, returns immediately.

        Args:
            reply_callback: Optional callable(task, event_data_dict, response_text)
                            called when the LLM responds, for routing back to source.
        """
        with self._lock:
            task = self._tasks.get(task_id)

        if not task:
            return {"success": False, "error": "Task not found"}

        if not task.get("enabled", True):
            return {"success": False, "error": "Task is disabled"}

        ttype = task_type(task)
        if ttype not in EVENT_TYPES:
            return {"success": False, "error": f"Task type '{ttype}' is not event-triggered"}

        task_name = task.get("name", "Unnamed")

        # The one gate (event_gate): account, active hours, message filter.
        # skip_filter: plugin_loader.fire_task - the owning daemon's own clock
        # firing its task (a greeting is not a message); the account still applies.
        why = event_gate(task, parse_event(event_data), skip_filter=skip_filter)
        if why:
            logger.debug(f"[Continuity] '{task_name}' event not answered: {why}")
            return {"success": False, "error": why}

        # If already running, queue with actual event data (not just a counter)
        with self._lock:
            if self._task_running.get(task_id, False):
                queue = self._task_pending.get(task_id, [])
                if len(queue) >= 50:
                    logger.warning(f"[Continuity] '{task_name}' queue full ({len(queue)} pending), dropping event")
                    return {"success": False, "error": "Event queue full"}
                queue.append((event_data, reply_callback))
                self._task_pending[task_id] = queue
                logger.info(f"[Continuity] '{task_name}' busy — queued event ({len(queue)} pending)")
                return {"success": True, "queued": True}
            self._task_running[task_id] = True
            self._arm_cancel(task_id)

        # Build response callback — saves last_response + routes reply to daemon source
        internal_cb = self._make_response_callback(task_id)
        def _make_reply_cb(cur_task, cur_event_data, cur_reply_callback):
            def _response_callback(response_text: str):
                internal_cb(response_text)
                if cur_reply_callback and response_text:
                    try:
                        event_dict = json.loads(cur_event_data) if isinstance(cur_event_data, str) else cur_event_data
                    except (json.JSONDecodeError, TypeError):
                        event_dict = {"raw": cur_event_data}
                    try:
                        cur_reply_callback(cur_task, event_dict, response_text)
                    except Exception as e:
                        logger.error(f"[Continuity] Reply callback failed for '{task_name}': {e}")
            return _response_callback

        # Run on worker thread — executes once then drains any queued events.
        # Acquire the concurrency semaphore (cap of 3) to honor the same cap
        # cron-fired tasks honor at _execute_task. Pre-fix, daemon/webhook
        # bursts (e.g. Discord 10 messages in 2s) spawned 10 ExecutionContexts
        # in parallel — each pokes credentials, sqlite, embedder. Voice mode
        # is going to drive more daemon traffic; the cap stops being a fiction
        # only if event tasks honor it too. Wildcard scout 2026-05-07 #2.
        cur_event_data = event_data
        cur_reply_callback = reply_callback
        def _run():
            nonlocal cur_event_data, cur_reply_callback
            # `_concurrency_sem` is initialized in __init__; test fixtures
            # that construct via `ContinuityScheduler.__new__()` may bypass
            # it, so degrade gracefully rather than AttributeError.
            sem = getattr(self, '_concurrency_sem', None)
            if sem is not None:
                sem.acquire()
            try:
                _drain_loop()
            finally:
                if sem is not None:
                    sem.release()

        def _drain_loop():
            nonlocal cur_event_data, cur_reply_callback
            while True:
                # Re-fetch live task per iteration. The outer `task` is a
                # snapshot from the moment this event fired; if the user
                # edits the task config, swaps prompt/toolset, or the plugin
                # reloads between queue-drain iterations, we'd keep running
                # the stale snapshot forever. Also used for the reply
                # callback so replies carry the task state as of THIS
                # iteration (not spawn-time).
                with self._lock:
                    live_task = self._tasks.get(task_id)
                    if not live_task or not live_task.get("enabled", True):
                        self._task_pending[task_id] = []
                        self._task_running[task_id] = False
                        self._task_progress.pop(task_id, None)
                        break
                    active_task = dict(live_task)

                # "Webhook specifies chat name" (trigger_config.chat_from_payload):
                # the secret-gated payload names the chat — route there (and that chat
                # answers with its own settings; see executor._run_foreground).
                # Override on the copy only (never the stored task).
                if active_task.get("trigger_config", {}).get("chat_from_payload"):
                    try:
                        _ev = json.loads(cur_event_data) if isinstance(cur_event_data, str) else cur_event_data
                        if isinstance(_ev, dict) and _ev.get("chat_target"):
                            active_task["chat_target"] = str(_ev["chat_target"])
                    except (json.JSONDecodeError, TypeError):
                        pass

                self._log_activity(task_id, task_name, "started", {"trigger": ttype})
                ev = self._run_cancel(task_id)
                try:
                    result = self.executor.run(
                        active_task,
                        event_data=cur_event_data,
                        progress_callback=self._make_progress_callback(task_id),
                        response_callback=_make_reply_cb(active_task, cur_event_data, cur_reply_callback),
                        cancel_event=ev,
                    )
                    self._record_run(task_id)

                    self._log_result(task_id, task_name, result, trigger=ttype)
                except Exception as e:
                    logger.error(f"[Continuity] Event task '{task_name}' failed: {e}", exc_info=True)
                    self._log_activity(task_id, task_name, "error", {"trigger": ttype, "exception": str(e)})
                    with self._lock:
                        self._task_progress.pop(task_id, None)

                # Drain queued events (with their actual data) or release
                with self._lock:
                    if ev.is_set():
                        # cancel = queued events die too — logged as a COUNT only
                        # (event payloads are user content; Krem's ruling 2026-09-08)
                        dropped = len(self._task_pending.get(task_id, []))
                        if dropped:
                            logger.warning(f"[Continuity] '{task_name}' stopped — dropping {dropped} queued event(s)")
                        self._task_pending[task_id] = []
                    queue = self._task_pending.get(task_id, [])
                    if queue:
                        cur_event_data, cur_reply_callback = queue.pop(0)
                        logger.info(f"[Continuity] '{task_name}' draining event queue ({len(queue)} remaining)")
                        continue
                    else:
                        self._task_running[task_id] = False
                        break

        thread = threading.Thread(target=_run, daemon=True, name=f"Event-{task_name}")
        thread.start()
        self._event_threads = [t for t in self._event_threads if t.is_alive()]  # prune dead
        self._event_threads.append(thread)

        logger.info(f"[Continuity] Event-triggered: {task_name} ({ttype})")
        return {"success": True, "queued": False}

    @staticmethod
    def filter_matches(task_filter: Dict, event_obj: Dict, task_name: str = "") -> bool:
        """Evaluate a task's trigger_config.filter against an event payload.
        Same semantics for fired events and realtime gate selection: exact
        case-insensitive match, `_not` negation, `_contains` substring."""
        for key, val in task_filter.items():
            if key.endswith("_not"):
                field = key[:-4]
                ev_val = str(event_obj.get(field, ""))
                if _value_matches(ev_val, val):
                    logger.debug(f"[Continuity] '{task_name}' filter excluded on '{field}' (not): {ev_val!r} == {val!r}")
                    return False
            elif key.endswith("_contains"):
                field = key[:-9]
                ev_val = str(event_obj.get(field, ""))
                if str(val).lower() not in ev_val.lower():
                    logger.debug(f"[Continuity] '{task_name}' filter mismatch on '{field}' (contains): {val!r} not in {ev_val!r}")
                    return False
            else:
                ev_val = event_obj.get(key)
                if not _value_matches(ev_val, val):
                    logger.debug(f"[Continuity] '{task_name}' filter mismatch on '{key}': {ev_val!r} != {val!r}")
                    return False
        return True

    def find_tasks_by_event(self, source: str) -> List[Dict]:
        """Find enabled daemon tasks that listen to a specific event source."""
        results = []
        with self._lock:
            for task in self._tasks.values():
                if task.get("type") != "daemon" or not task.get("enabled", True):
                    continue
                tc = task.get("trigger_config", {})
                if tc.get("source") == source:
                    results.append(dict(task))
        return results

    def active_daemon_accounts(self, source: str) -> set:
        """Return set of account names that have enabled daemon tasks for a given source.
        Reads 'account' from trigger_config or filter. Empty set = no active tasks."""
        accounts = set()
        with self._lock:
            for task in self._tasks.values():
                if task.get("type") != "daemon" or not task.get("enabled", True):
                    continue
                tc = task.get("trigger_config", {})
                if tc.get("source") != source:
                    continue
                acct = tc.get("account", "")
                if acct:
                    accounts.add(acct)
                # Also check filter for legacy tasks without task_field
                filt = tc.get("filter", {})
                if isinstance(filt, dict) and filt.get("account"):
                    accounts.add(filt["account"])
        return accounts

    def find_webhook_task(self, path: str, method: str = "POST") -> Optional[Dict]:
        """Find an enabled webhook task matching path and method."""
        with self._lock:
            for task in self._tasks.values():
                if task.get("type") != "webhook" or not task.get("enabled", True):
                    continue
                tc = task.get("trigger_config", {})
                if tc.get("path") == path and tc.get("method", "POST") == method:
                    return dict(task)
        return None

    # =========================================================================
    # THREAD CONTROL
    # =========================================================================
    
    def start(self):
        """Start the scheduler background thread."""
        if self._running:
            logger.warning("[Continuity] Scheduler already running")
            return
        
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, daemon=True, name="ContinuityScheduler")
        self._thread.start()
        logger.info("[Continuity] Scheduler started")
    
    def stop(self):
        """Stop the scheduler and wait for any in-flight event threads."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        # Wait for event-triggered worker threads to finish
        alive = [t for t in self._event_threads if t.is_alive()]
        if alive:
            logger.info(f"[Continuity] Waiting for {len(alive)} event thread(s) to finish...")
            for t in alive:
                t.join(timeout=10)
        self._event_threads.clear()
        logger.info("[Continuity] Scheduler stopped")
    
    def _run_loop(self):
        """Main scheduler loop."""
        import time
        
        logger.info("[Continuity] Scheduler loop running")
        check_count = 0
        
        while self._running:
            try:
                self._check_and_run()
                check_count += 1
                
                # Heartbeat every 120 checks (~1 hour)
                if check_count % 120 == 0:
                    with self._lock:
                        enabled = sum(1 for t in self._tasks.values() if t.get("enabled"))
                    logger.info(f"[Continuity] Heartbeat: {enabled} enabled tasks, {check_count} checks since start")
                    
            except Exception as e:
                logger.error(f"[Continuity] Scheduler loop error: {e}", exc_info=True)
            
            # Sleep in small increments for responsive shutdown
            for _ in range(self.CHECK_INTERVAL):
                if not self._running:
                    break
                time.sleep(1)
    
    def is_running(self) -> bool:
        """Check if scheduler is running."""
        return self._running
    
    # =========================================================================
    # STATUS / TIMELINE
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """Get scheduler status."""
        with self._lock:
            enabled_count = sum(1 for t in self._tasks.values() if t.get("enabled"))
            
        next_task = self._get_next_scheduled()
        
        return {
            "running": self._running,
            "total_tasks": len(self._tasks),
            "enabled_tasks": enabled_count,
            "next_task": next_task
        }
    
    def _get_next_scheduled(self) -> Optional[Dict]:
        """Get the next task that will run."""
        now = _user_now()
        next_task = None
        next_time = None
        
        with self._lock:
            for task in self._tasks.values():
                if not task.get("enabled"):
                    continue
                if task_type(task) in EVENT_TYPES or is_idle(task):
                    continue                    # an idle beat has no clock time: it waits for quiet

                try:
                    cron = _get_croniter()(task.get("schedule", ""), now)
                    task_next = cron.get_next(datetime)

                    if next_time is None or task_next < next_time:
                        next_time = task_next
                        next_task = {
                            "id": task["id"],
                            "name": task.get("name"),
                            "scheduled_for": task_next.isoformat()
                        }
                except Exception:
                    continue
        
        return next_task
    
    def get_activity(self, limit: int = 50) -> List[Dict]:
        """Get recent activity log."""
        return self._activity[-limit:]
    
    def get_timeline(self, hours: int = 24) -> List[Dict]:
        """Get timeline of scheduled tasks for next N hours."""
        now = _user_now()
        end = now + timedelta(hours=hours)
        timeline = []
        from core import idle as _idle
        since = _idle.since(None, person=True)          # read outside the lock (a boot's first ask reads the DB)

        with self._lock:
            for task in self._tasks.values():
                if not task.get("enabled"):
                    continue
                if task_type(task) in EVENT_TYPES:
                    continue
                if is_idle(task):
                    # one point, not every cron look: the look that will find it
                    # due if the person stays quiet (never, when backoff is spent)
                    when = idle_next_look(task, since, now)
                    if when is not None:
                        if when <= end and self._in_active_hours(task, when.hour):
                            timeline.append({
                                "task_id": task["id"], "task_name": task.get("name"),
                                "scheduled_for": when.isoformat(), "chance": task.get("chance", 100),
                                "heartbeat": True, "emoji": task.get("emoji", ""),
                                "task_type": task_type(task), "idle": True, "type": "upcoming"})
                    continue

                try:
                    cron = _get_croniter()(task.get("schedule", ""), now)

                    # Get next occurrences within window
                    for _ in range(10):  # Max 10 per task
                        next_time = cron.get_next(datetime)
                        if next_time > end:
                            break

                        if not self._in_active_hours(task, next_time.hour):
                            continue

                        timeline.append({
                            "task_id": task["id"],
                            "task_name": task.get("name"),
                            "scheduled_for": next_time.isoformat(),
                            "chance": task.get("chance", 100),
                            "heartbeat": task.get("heartbeat", False),
                            "emoji": task.get("emoji", ""),
                            "task_type": task_type(task),
                            "type": "upcoming"
                        })
                except Exception:
                    continue
        
        # Sort by time
        timeline.sort(key=lambda x: x["scheduled_for"])
        return timeline

    def get_merged_timeline(self, hours_back: int = 12, hours_ahead: int = 12) -> Dict[str, Any]:
        """Get merged timeline: past activity + future schedule with NOW marker."""
        now = _user_now()

        # Future: reuse existing timeline logic
        future = self.get_timeline(hours_ahead)

        # Past: pull from activity log, enrich with task info
        cutoff = now - timedelta(hours=hours_back)
        past = []
        with self._lock:
            task_map = {t["id"]: t for t in self._tasks.values()}
        for entry in self._activity:
            try:
                ts = datetime.fromisoformat(entry["timestamp"])
                if ts.tzinfo is None:
                    ts = ts.replace(tzinfo=ZoneInfo('UTC'))
                if ts < cutoff:
                    continue
            except (ValueError, KeyError):
                continue
            task = task_map.get(entry.get("task_id", ""), {})
            past.append({
                "task_id": entry.get("task_id"),
                "task_name": entry.get("task_name"),
                "timestamp": entry.get("timestamp"),
                "status": entry.get("status"),
                "heartbeat": task.get("heartbeat", False),
                "emoji": task.get("emoji", ""),
                "type": "past",
                "details": entry.get("details", {})
            })

        return {
            "now": now.isoformat(),
            "past": sorted(past, key=lambda x: x["timestamp"], reverse=True),
            "future": future
        }


def _idle_fields(data, ttype):
    """(idle_minutes, idle_backoff), checked: minutes 0 (a plain heartbeat) or
    5..10080 (a week); only a heartbeat can be idle."""
    try:
        mins = int(data.get("idle_minutes") or 0)
    except (TypeError, ValueError):
        raise ValueError("Time To Activate must be a number of minutes")
    if mins and ttype != "heartbeat":
        mins = 0
    if mins and not 5 <= mins <= 10080:
        raise ValueError("Time To Activate must be between 5 minutes and a week (10080)")
    return mins, bool(data.get("idle_backoff", True))


def is_idle(task) -> bool:
    """An Idle Heartbeat: a heartbeat that waits for the person's quiet."""
    try:
        return task_type(task) == "heartbeat" and int(task.get("idle_minutes") or 0) > 0
    except (TypeError, ValueError):
        return False


def idle_state(task, now=None):
    """For an Idle Heartbeat: (due, stretch, fires, quiet_minutes). The quiet
    is the person's, app-wide (core/idle.py: the last thing they said to her
    anywhere; her own replies and tasks never count). A new stretch (they
    spoke since) re-arms it. Backoff on: due at 1x, 2x, 4x the threshold,
    IDLE_MAX_FIRES times, then it waits for them. Off: due on every check
    while quiet. Unknown quiet (nothing said yet, sealed) is never due."""
    from core import idle
    since = idle.since(None, person=True)
    if since is None:
        return False, None, 0, None
    stretch, fires, since = _idle_stretch(task, since)
    now = now or time.time()
    at = _idle_next_at(task, since)
    return at is not None and now >= at, stretch, fires, max(0.0, (now - since) / 60.0)


def _idle_stretch(task, since):
    """(stretch, fires, since) for this quiet. The stored stretch holds, with
    its fires, unless the person spoke after it: a clock read a second off
    (a restart's seed) or older (a chat cleared, a sealed chat unread) is
    the same quiet, never a new one that re-arms the beats (hunt 19)."""
    try:
        stored = int(task.get("idle_stretch")) if task.get("idle_stretch") is not None else None
    except (TypeError, ValueError):
        stored = None
    if stored is not None and since <= stored + 2:
        return stored, int(task.get("idle_fires") or 0), max(since, stored)
    return int(since), 0, since


def idle_fired(task, fires, quiet):
    """The fires count after a beat now, `quiet` minutes in. With backoff it
    jumps to the rung the quiet has already reached: a beat that first looks
    10 h into a quiet (active hours opening, a wake, a boot) is the last of
    its ladder, not three beats on three looks (hunt 19)."""
    n = fires + 1
    if task.get("idle_backoff", True):
        mins = int(task.get("idle_minutes") or 0)
        while n < ContinuityScheduler.IDLE_MAX_FIRES and mins and quiet >= mins * 2 ** n:
            n += 1
    return n


def _idle_next_at(task, since):
    """Epoch when an Idle Heartbeat's next beat comes due if the quiet goes
    on, or None (quiet unknown, or the backoff is spent until they speak)."""
    if since is None:
        return None
    _, fires, since = _idle_stretch(task, since)
    mins = int(task.get("idle_minutes") or 0)
    if task.get("idle_backoff", True):
        if fires >= ContinuityScheduler.IDLE_MAX_FIRES:
            return None
        return since + mins * (2 ** fires) * 60
    return since + mins * 60


def idle_next_look(task, since, now):
    """When an Idle Heartbeat will actually look and find itself due: the
    first cron look at or after the moment the quiet reaches it (a look
    every 60 min = on the hour). None = not coming (quiet unknown, or the
    backoff is spent until the person speaks). `now`: a tz-aware datetime."""
    at = _idle_next_at(task, since)
    if at is None:
        return None
    start = max(datetime.fromtimestamp(at, tz=now.tzinfo), now) - timedelta(seconds=1)
    try:
        return _get_croniter()(task.get("schedule", ""), start).get_next(datetime)
    except Exception:
        return None


def live_filter(task) -> dict:
    """A task's message filter with its blank fields dropped: an empty field
    in the editor means "any", never "must be empty"."""
    tc = task.get("trigger_config") or {}
    raw = tc.get("filter") if isinstance(tc.get("filter"), dict) else {}
    return {k: v for k, v in raw.items() if str(v).strip()}


def event_gate(task, event_obj, skip_filter=False, hour=None):
    """Why an event task would NOT answer this event, or None: the one gate
    fire_event_task, tasks_matching and the plugin loader share (DRY scout,
    2026-10-27: three copies had drifted - account types, blank filters,
    active hours). event_obj: the parsed event (None = not JSON).
    skip_filter: the owner's own clock firing (a greeting) - no hours, no filter."""
    tc = task.get("trigger_config") or {}
    want = str(tc.get("account") or "")
    got = str(event_obj.get("account") or "") if isinstance(event_obj, dict) else ""
    if want and got and got != want:
        return "Account mismatch"
    if skip_filter:
        return None
    if not task_in_active_hours(task, hour):
        return "Outside active hours"
    flt = live_filter(task)
    if flt:
        if not isinstance(event_obj, dict):
            return "Event data not JSON-parseable, filter requires JSON"
        if not ContinuityScheduler.filter_matches(flt, event_obj, str(task.get("name") or "")):
            return "Event filtered out"
    return None


def parse_event(event_data):
    """The event payload as a dict, or None (parsed once, at the door)."""
    if isinstance(event_data, dict):
        return event_data
    try:
        obj = json.loads(event_data) if isinstance(event_data, str) else None
    except (json.JSONDecodeError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None


def tasks_matching(tasks, event_obj, hour=None) -> list:
    """The enabled event tasks that WOULD fire for `event_obj` — fire_event_task's
    gates (account match, active hours, message filter) as a read-only question.
    A host hands the answer to its add-ons before a message is emitted (Discord
    2.3.0: which task, hence which memory scope, is about to answer)."""
    if not isinstance(event_obj, dict):
        return []
    return [t for t in tasks or [] if t.get("enabled", True) and event_gate(t, event_obj, hour=hour) is None]
