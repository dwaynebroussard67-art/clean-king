# core/continuity/execution_context.py — Isolated execution environment
#
# Each task (heartbeat, daemon, foreground) gets its own ExecutionContext.
# Zero shared mutable state — no singleton mutations, no bleed between tasks.
#
# The FunctionManager is treated as a READ-ONLY registry.
# Prompt, tools, scopes, provider are all resolved at construction time.

import logging
import re
import string
import time
from contextvars import ContextVar
from typing import Dict, Any, Optional, Tuple, List

import config
from core.chat.llm_providers import get_generation_params

logger = logging.getLogger(__name__)

# Tracks the persona of the task currently running in this thread/async context.
# Set by ExecutionContext.run() and used by tools that need to know the
# *parent's* persona — notably spawn_agent(prompt='self'), which must inherit
# from the spawning agent, NOT from the user's foreground chat. Scout #7.
current_task_persona: ContextVar[Optional[str]] = ContextVar('current_task_persona', default=None)

# Warn once per process about a loop-guard version skew (see helper below).
_loop_guard_skew_warned = False


_FILLER = frozenset(string.punctuation + string.whitespace + '\u2026\u2014\u2013\u00b7\u2022')
from core.chat.llm_providers.base import LENGTH_FINISH as _LENGTH_FINISH   # openai-compat / anthropic / responses


def visible_answer(text: str) -> str:
    """What a person would see of a reply: think blocks gone (core.think, the
    one reader of those tags)."""
    from core import think
    return think.strip(text)


def degenerate_reason(text: str, finish=None) -> Optional[str]:
    """Why `text` is not an answer, or None. The shapes seen in the wild: a
    wall of '...' paragraphs (a Discord bot dripped 1500 of them, 2026-09-25),
    the same line on repeat, a two-token stub left after reasoning spent the
    budget. Emoji-only and short stylistic replies ('...', '?!') pass."""
    t = (text or '').strip()
    if not t:
        return 'empty'
    n = len(t)
    if n >= 12 and sum(c not in _FILLER for c in t) < n * 0.2:
        return 'punctuation wall'
    lines = [ln.strip() for ln in t.splitlines() if ln.strip()]
    if len(lines) >= 6 and max(lines.count(ln) for ln in set(lines)) >= len(lines) * 0.6:
        return 'repeated line'
    if finish in _LENGTH_FINISH and n < 8:
        return 'truncated fragment'
    return None


def _exec_with_loop_counts(fn, *args, loop_counts=None, **kwargs):
    """Call fn(*args, loop_counts=..., **kwargs), degrading gracefully if the tool
    engine predates the loop guard.

    The loop guard is a cosmetic warning feature. On a partial update where
    core/chat/chat_tool_calling.py is older than this file, fn won't accept the
    loop_counts kwarg and Python raises TypeError AT BIND TIME - before any tool
    runs - so it is safe to retry without it (no double execution). We drop the
    loop guard for this call and keep the trigger running. Warn once per process so
    the skew shows up in logs without spamming every trigger. A TypeError that is
    NOT about loop_counts is a real error, re-raised untouched."""
    global _loop_guard_skew_warned
    try:
        return fn(*args, loop_counts=loop_counts, **kwargs)
    except TypeError as e:
        if "loop_counts" not in str(e):
            raise
        if not _loop_guard_skew_warned:
            _loop_guard_skew_warned = True
            logger.warning(
                "[CONTINUITY] tool engine does not accept 'loop_counts' - core/chat/"
                "chat_tool_calling.py is older than execution_context.py (partial update). "
                "Loop guard disabled for triggers; continuing DEGRADED. Re-run the update so "
                "that file matches, then restart to re-enable."
            )
        return fn(*args, **kwargs)


def _scrub_inline_images(msg: Dict[str, Any]) -> Dict[str, Any]:
    """Strip inline base64 image blocks from a user message before persistence.

    Tool-returned images are injected mid-loop as a base64 user message (for the
    LLM to see THIS turn) by `_inject_tool_images`, and are separately saved to
    the chat DB with a `<<IMG::tool:id>>` marker in the tool-result message. So
    the base64 copy is turn-only — persisting it inline would replay the image
    every turn and bloat the chat (the same hazard the event-image dual-form swap
    guards). This drops only `type:image` blocks; `tool_result` and `text` blocks
    are preserved untouched (so wire_to_canonical's tool-result handling is safe).
    A text-only remainder collapses to a plain string — the safest persisted shape.
    Pure function; returns the message unchanged when there's nothing to scrub.
    2026-06-13.
    """
    if msg.get("role") != "user" or not isinstance(msg.get("content"), list):
        return msg
    kept = [b for b in msg["content"]
            if not (isinstance(b, dict) and b.get("type") == "image")]
    if len(kept) == len(msg["content"]):
        return msg  # no image blocks — untouched (e.g. tool_result messages)
    if not kept:
        # Content was image(s) only — never persist an empty-content user message
        # (invisible-bubble hazard). Unreachable from current producers (they all
        # prepend a text block) but guarded so a future one can't trip it.
        return {**msg, "content": "[image]"}
    if all(isinstance(b, dict) and b.get("type") == "text" for b in kept):
        # str()-coerce defensively — a malformed text block (text=None/int) must
        # collapse cleanly, never crash the persist with a join TypeError.
        return {**msg, "content": " ".join(str(b.get("text") or "") for b in kept).strip()}
    return {**msg, "content": kept}


def closed_scopes(task_settings):
    """The data scopes a task has shut: every registered scope it did not list,
    or listed as 'none' - exactly the set _build_scopes force-disables. Flags
    (private_chat, a bool) are not scopes. The resolver sheds the tools that
    need one of these (2026-10-08)."""
    from core.chat.function_manager import SCOPE_REGISTRY
    closed = set()
    for key, reg in list(SCOPE_REGISTRY.items()):
        setting = reg.get('setting')
        if not setting or isinstance(reg.get('default'), bool):
            continue
        if (task_settings or {}).get(setting) in (None, '', 'none'):
            closed.add(key)
    return closed


class ExecutionContext:
    """Self-contained execution environment for a single task run.

    Resolves prompt, tools, scopes, and provider at construction.
    Runs LLM + tool loop without touching any singleton state.
    """

    def __init__(self, function_manager, tool_engine, task_settings: Dict[str, Any],
                 session_manager=None, cancel_check=None, on_tool=None):
        self.fm = function_manager
        # on_tool(name) fires as each tool call is recorded, so a watcher (an
        # agent's transcript) sees progress while the run is still going -
        # tool_log alone is only readable after run() returns. 2026-10-06.
        self.on_tool = on_tool
        # Zero-arg callable polled by run(): True = stop. Checked at the top
        # of every tool round AND between the LLM's reply and its tool batch,
        # so a cancel never executes another tool. The LLM HTTP call itself
        # is blocking — a cancel lands when it returns (bounded by the LLM
        # timeout). Wired by the scheduler's per-run cancel Event. 2026-09-08.
        self.cancel_check = cancel_check
        self.cancelled = False
        self.tool_engine = tool_engine
        self.task_settings = task_settings
        # Image sink only — tool images from this lane went to a dead-end disk
        # fallback (user/tool_images, unserved, no GC) because execute_tool_calls
        # got history=None. With a sink + an active stream-brain override the
        # image lands in the chat DB keyed to the run's own chat. NEVER used
        # for transcript writes (see execute_tool_calls docstring). 2026-08-17.
        self.session_manager = session_manager

        # Resolve everything upfront — all read-only operations.
        # Provider BEFORE scopes: _build_scopes stamps tool provenance
        # (set_tool_context) with the RESOLVED provider/model — the old
        # order left provider always-None and model stale in every
        # continuity run's mindpalace metadata.
        self.system_prompt = self._build_prompt()
        self.tools = self._resolve_tools()
        self._allowed_tool_names = {t["function"]["name"] for t in self.tools if "function" in t} if self.tools else None
        self.provider_key, self.provider, self.model_override = self._resolve_provider()
        self.scopes = self._build_scopes()
        self.gen_params = self._build_gen_params()
        self.tool_log = []  # List of tool names called during run()
        # Populated by run() when the LLM loop didn't produce a real reply
        # (tool-round exhaustion, context overflow, empty LLM output). Lets
        # callers distinguish "clean done with response" from "done with a
        # placeholder" so agent UI / status reports don't render a green
        # success for a no-op run. Scout #15 — 2026-04-20. None = clean run.
        self.degraded_reason: Optional[str] = None

    def _tell_tool(self, names):
        if self.on_tool is None:
            return
        for n in names:
            try:
                self.on_tool(n)
            except Exception as e:
                logger.debug(f"[ExecCtx] on_tool failed: {e}")

    def _is_cancelled(self) -> bool:
        if self.cancelled:
            return True
        try:
            if self.cancel_check is not None and self.cancel_check():
                self.cancelled = True
        except Exception:
            pass
        return self.cancelled

    # ── Construction (read-only) ──

    def _build_prompt(self) -> str:
        """Build system prompt from task settings. No global mutation."""
        prompt_name = self.task_settings.get("prompt", "sapphire")
        from core import prompts

        prompt_data = prompts.get_prompt(prompt_name)
        # Stashed for _build_scopes/_resolve_provider: a privacy_required
        # prompt must not run on a non-local provider in this lane (there is
        # no private_chat toggle here — local-only IS the guarantee).
        # OR of the task's persisted carrier and the live prompt-derived flag
        # (vault phase 0c): the live half catches prompts that BECAME private
        # after the task was saved; the carrier half survives the prompt not
        # resolving at all (deleted, or asleep in a locked vault) — before
        # this, an unresolvable prompt silently dropped privacy and the task
        # ran on whatever provider it was pinned to, cloud included.
        self._prompt_privacy_required = (
            bool(self.task_settings.get("privacy_required"))
            or bool(isinstance(prompt_data, dict)
                    and prompt_data.get('privacy_required')))
        if prompt_data:
            system_prompt = prompt_data.get("content") if isinstance(prompt_data, dict) else str(prompt_data)
        else:
            logger.warning(
                f"[ExecCtx] Prompt '{prompt_name}' not found — running as "
                f"generic assistant"
                + (" (task carries privacy_required — local-only still enforced)"
                   if self._prompt_privacy_required else ""))
            system_prompt = "You are a helpful assistant."

        # Name substitutions
        username = getattr(config, 'DEFAULT_USERNAME', 'Human')
        ai_name = 'Sapphire'
        system_prompt = system_prompt.replace("{user_name}", username).replace("{ai_name}", ai_name)

        # No clock here. Per-turn context (the time when the task asks for it,
        # plugin ghost text, the idle line) rides the ghost row _run_inner adds
        # before the live user row (core/ghost_messages.py), as the chat lane
        # has since 2026-05-08. A minute stamp on this prompt re-read the whole
        # prompt at every minute boundary on any backend that caches a prefix
        # (an agent's tool loop runs for minutes); 'date' was the workaround
        # and now means the same as True.

        # Task-supplied append (e.g. the librarian's session-start self
        # snapshot) — ambient identity context, not a message. Rides every
        # round; stable within a session so the prompt cache holds.
        extra = self.task_settings.get("system_append")
        if extra:
            system_prompt = f"{system_prompt}\n\n{extra}"

        return system_prompt

    def _resolve_tools(self) -> Optional[List[Dict]]:
        """Resolve toolset to tool list. READ-ONLY — no mutation of FunctionManager.
        `extra_toolsets` in task settings unions module/toolset sets on top,
        same semantics as update_enabled_functions."""
        toolset_name = self.task_settings.get("toolset", "none")
        extra_toolsets = self.task_settings.get("extra_toolsets") or []
        # ONE rule, in the manager (broadsword H12) — same names the live
        # setter enables (hidden tools included in the rule), then the mode
        # filter + settings gate, no mutation. add_tools/drop_tools: single
        # names a task adds or withholds (a `self` agent's memory tools).
        # closed_scopes: _build_scopes force-disables every registered scope
        # this task did not list (or listed as 'none'); a tool that needs one
        # of those could only answer "scope disabled" - it is shed here, so
        # the lean agent stops carrying nine dead tools (2026-10-08).
        tools = self.fm.resolve_tools(toolset_name, extra_toolsets,
                                      add_tools=self.task_settings.get("add_tools"),
                                      drop_tools=self.task_settings.get("drop_tools"),
                                      closed_scopes=closed_scopes(self.task_settings))
        logger.info(f"[ExecCtx] Toolset '{toolset_name}': {len(tools or [])} tools")
        return tools

    def _build_scopes(self) -> Optional[Dict]:
        """Build scopes from task settings. Sets ContextVars for this thread only.
        Always resets scopes to prevent bleed between queued task iterations."""
        from core.chat.function_manager import (
            apply_scopes_from_settings, reset_scopes, snapshot_all_scopes, SCOPE_REGISTRY,
        )

        # Always reset first — prevents scope bleed when queue drains multiple
        # iterations on the same thread (previous task's scopes would linger)
        reset_scopes()

        # NOTE: we do NOT short-circuit on `not self.tools` before the force-None
        # closure below. An empty-toolset agent still needs its scopes closed —
        # hook_runner fires during agent runs, plugin handlers read ContextVars,
        # event publishes read scope from the current thread. If the closure
        # is skipped, the thread's scopes stay at registry defaults (including
        # 'default' — a real scope with user data). Silent-default leak for
        # toolset-less agents. H2 fix 2026-04-22.
        #
        # Apply task-specific scopes to this thread's ContextVars.
        apply_scopes_from_settings(self.fm, self.task_settings)
        # Force-None every SCOPE_REGISTRY key NOT explicitly present in the
        # task's settings. This is the silent-default class closure.
        #
        # Background: `'default'` is doing double duty in this system — it's
        # both the registry default assigned at ContextVar registration time
        # AND a real scope name where user data lives. After `reset_scopes()`
        # every ContextVar sits at `'default'`. `apply_scopes_from_settings`
        # sets the ones the task listed, leaving the rest at `'default'` — a
        # real scope containing the user's memories, knowledge, people,
        # goals. An agent (or any task) running through ExecutionContext
        # without listing every registered scope would silently write into
        # that personal bucket.
        #
        # The previous narrower fix gated this force-None only on
        # `prompt == 'agent'`, but tasks can resolve to sapphire/falcon/custom
        # personas (and spawn_agent(prompt='self') inherits non-agent
        # personas routinely). Three scouts converged on this exact gap.
        # Drop the gate — apply the stronger invariant universally. Any task
        # that doesn't EXPLICITLY list a scope key gets None (disabled) for
        # that scope, not the registry default. Silent-default closed.
        # Scout day-ruiner #1 / chaos #4 / #9 — 2026-04-21.
        for name, reg in list(SCOPE_REGISTRY.items()):
            setting_key = reg.get('setting')
            if setting_key and setting_key not in self.task_settings:
                # Bool-typed flags (e.g. scope_private) aren't scopes — their
                # registered default IS the disabled state (False). Force-None
                # on them sets a None value that breaks callers expecting bool.
                # Scopes are string-name ContextVars — those get None.
                default_val = reg.get('default')
                disabled_val = False if isinstance(default_val, bool) else None
                try:
                    reg['var'].set(disabled_val)
                except Exception as e:
                    logger.warning(f"[ExecCtx] Could not force-disable scope {name}: {e}")
        # Also clear rag since tasks don't use it. private_chat follows the
        # prompt: a privacy_required prompt keeps its network-tool gating even
        # in this lane (the old unconditional False actively STRIPPED privacy
        # from cron/heartbeat/agent runs).
        self.fm.set_rag_scope(None)
        self.fm.set_private_chat(getattr(self, '_prompt_privacy_required', False))

        # Provenance for tool executors (mindpalace metadata, get_self_info).
        # Set before the snapshot so it rides along. provider/model are the
        # RESOLVED values — the constructor already ran _resolve_provider,
        # including the event-payload override — so tools report what this
        # run actually executes on, not the task's pre-override fields.
        from core.chat.function_manager import set_tool_context
        set_tool_context(None, chat=self.task_settings.get('chat_target'),
                         persona=self.task_settings.get('prompt'),
                         model=(getattr(self, 'model_override', None)
                                or getattr(getattr(self, 'provider', None), 'model', '')
                                or self.task_settings.get('model')),
                         provider=getattr(self, 'provider_key', None),
                         toolset=self.task_settings.get('toolset'),
                         channel='continuity')

        return snapshot_all_scopes()

    def _resolve_provider(self) -> Tuple:
        """Select LLM provider from task settings. Returns (key, provider, model_override).

        Thin door onto core.chat.llm_providers.resolve — the ONE resolver
        (2026-09-21). Privacy is settled HERE (task carrier ∨ live prompt flag
        ∨ target chat's private_chat — see _build_prompt / executor) and handed
        in as `private`; there is no private_chat toggle in this lane, so
        local-only IS the guarantee. Before 2026-08-09 this lane had NO
        privacy check at all."""
        provider_key = self.task_settings.get("provider", "auto")
        model_override = self.task_settings.get("model", "")

        # The task's provider IS the brain. The event-payload override
        # (llm_primary/llm_model riding a daemon event — Discord's Reply LLM
        # silently beating the task's dropdown) retired 2026-09-21, S0 doors.

        from core.chat.llm_providers.resolve import resolve, PrivacyRefused
        requires_privacy = bool(getattr(self, '_prompt_privacy_required', False))
        try:
            sel = resolve(provider_key, model_override, private=requires_privacy,
                          timeout=self.task_settings.get("llm_request_timeout"),
                          # {session} affinity keys on the target chat; a task
                          # with no chat rides the per-install fallback id.
                          conversation=self.task_settings.get("chat_target") or None)
        except PrivacyRefused as e:
            raise PrivacyRefused(
                f"Task requires privacy (private target chat, or prompt "
                f"'{self.task_settings.get('prompt')}' is privacy_required); {e}") from e
        # Auto mode returns model='' — a pin for another provider never rides
        # to the one auto picked (scout V4, 2026-09-21).
        return sel.as_tuple()

    def _build_gen_params(self) -> Dict:
        """Build generation parameters for the resolved provider/model."""
        effective_model = self.model_override if self.model_override else self.provider.model
        params = get_generation_params(
            self.provider_key, effective_model,
            {**getattr(config, 'LLM_PROVIDERS', {}), **getattr(config, 'LLM_CUSTOM_PROVIDERS', {})}
        )
        if self.model_override:
            params['model'] = self.model_override
        return params

    # ── Execution ──

    def run(self, user_input: str, history_messages: List[Dict] = None,
            images: List[Dict] = None) -> str:
        """Run LLM + tool loop in complete isolation. Returns response text.

        After run() completes, self.new_messages contains all messages generated
        during this execution (user, assistant w/ tool_calls, tool results, final
        assistant). Callers can use this to persist the full conversation including
        tool calls — not just the final response.

        Args:
            user_input: The user/event message. When images are passed, this is
                        the PERSISTED form (text + <<IMG::...>> markers) — the
                        marker is what lands in chat history, never base64.
            history_messages: Optional prior messages for foreground chat continuity.
                              If None, runs ephemeral (system + user only).
            images: Optional plugin-supplied images [{"data": b64, "media_type": str}].
                    Shown to the LLM as base64 blocks THIS turn only, gated on
                    provider vision support; non-vision gets the image described in
                    words (core.image_describe: CLIP or a vision provider).
                    new_messages persists the marker form, plus that description
                    when a text-only model needed one.
        """
        # filter_to_thinking_only from its real home — chat.py stopped
        # re-exporting it when the blocking engine died (merge 2026-08-17).
        from core.chat.chat import _inject_tool_images
        from core.chat.chat_tool_calling import filter_to_thinking_only

        # Stamp this thread's ContextVar with the running task's persona so
        # tools invoked during the loop (spawn_agent, etc.) can inherit the
        # CORRECT parent. Reset on exit so nothing leaks back to the shared
        # main-chat path. Scout #7 — 2026-04-20.
        _persona_token = current_task_persona.set(self.task_settings.get("prompt"))
        try:
            return self._run_inner(user_input, history_messages,
                                   filter_to_thinking_only, _inject_tool_images,
                                   images)
        finally:
            current_task_persona.reset(_persona_token)

    def _build_user_message(self, user_input, images):
        """Build the user message content the LLM sees this turn.

        Returns (llm_content, persist_content). llm_content carries base64 image
        blocks for vision models (or the described text otherwise). persist_content
        never holds base64: the marker-string `user_input` for a vision model, and
        for a text-only model the same described text she read — the caption stays
        in history, so the next turn still knows what the image was (2026-09-26;
        the chat lane always did: its caption rides the tool result).
        """
        if not images:
            return user_input, user_input
        from core.chat.chat_tool_calling import strip_ui_markers
        clean_text = strip_ui_markers(user_input) if "<<" in user_input else user_input
        if getattr(self.provider, "supports_images", False):
            content = [{"type": "text", "text": clean_text}]
            for img in images:
                content.append({
                    "type": "image",
                    "data": img.get("data", ""),
                    "media_type": img.get("media_type", "image/jpeg"),
                })
            return content, user_input
        # No vision: describe the image(s) in words so the model gets them, not a
        # drop. Same privacy the task's own brain was resolved with (_resolve_provider).
        import base64
        vibe_parts = []
        private = bool(getattr(self, '_prompt_privacy_required', False))
        for img in images:
            try:
                from core import image_describe
                raw = base64.b64decode(img["data"])
                # A saved event image keeps its description on its own row.
                vibe_parts.append(image_describe.for_image(img["id"], raw, private=private) if img.get("id")
                                  else image_describe.describe(raw, private=private))
            except Exception as e:
                logger.warning(f"[EVENT-IMG] describe failed: {e}")
        augmented = user_input
        if vibe_parts:
            augmented = (user_input + "\n\n" + "\n\n".join(p for p in vibe_parts if p)).strip()
        # The description is persisted WITH the markers: a text-only model gets
        # no image on replay, so a caption that lived one turn left her with an
        # id and nothing else. Text only — never base64.
        return augmented, augmented

    def _row_meta(self, response_msg, content, t0, t1):
        """The metrics block the web lane stamps on every assistant row (the
        ui.js footer: provider, model, tokens, seconds, finish). The same
        builder, so a task's turn in a chat shows its numbers too; before
        2026-11-01 those rows were blank and a slow turn had nothing to say."""
        try:
            from core.chat.chat_streaming import usage_metadata, _stamp_finish
            model = self.model_override or getattr(self.provider, 'model', '')
            usage = getattr(response_msg, 'usage', None)
            if usage is not None and not isinstance(usage, dict):
                return None                                   # a stub response: nothing real to count
            meta = usage_metadata(self.provider_key, model, response_msg, content or '',
                                  getattr(response_msg, 'thinking', None), t0, t1)
            _stamp_finish(meta, getattr(response_msg, 'finish_reason', None), content or '', self.provider_key)
            return meta
        except Exception as e:
            logger.debug(f"[ExecCtx] row metadata skipped: {e}")
            return None

    def _ghost_row(self, user_input):
        """The per-turn ghost row the chat lane sends (core/ghost_messages.py):
        the time when the task asks for it (`inject_datetime`, True or 'date'),
        plugin `ghost_inject` text, the idle line for the chat. Labeled as the
        app's own context, never persisted (`_inject`), placed right before the
        live user row so the system prompt and the history stay a stable,
        cacheable prefix. Before 2026-11-01 this lane stamped the minute onto
        the system prompt instead. Spice stays off for a task: it has none of
        its own, and the chat's is the web lane's business."""
        try:
            from core.ghost_messages import build_ghost_message
            settings = {'inject_datetime': bool(self.task_settings.get('inject_datetime')),
                        'spice_enabled': False}
            text = build_ghost_message(None, settings, user_input or '',
                                       chat_name=self.task_settings.get('chat_target') or None)
        except Exception as e:
            logger.warning(f"[ExecCtx] ghost row skipped: {e}")
            return None
        return {"role": "user", "content": text, "_inject": True} if text else None

    def _with_meta(self, row, response_msg, content, t0, t1):
        """`row` with its metrics block when one could be built; a row without
        one stays exactly as it was (no `metadata: None` in history)."""
        meta = self._row_meta(response_msg, content, t0, t1)
        if meta:
            row["metadata"] = meta
        return row

    def _run_inner(self, user_input, history_messages, filter_to_thinking_only, _inject_tool_images,
                   images=None):
        # Build the user message. llm_content is what the model sees (may carry
        # base64 image blocks); persist_content is the marker form for history.
        llm_content, persist_content = self._build_user_message(user_input, images)
        # Build messages. Hold a reference to the user-message OBJECT so its index
        # can be re-derived by identity after the loop — the in-loop context trim
        # deletes front messages, which would make a frozen msg_start_idx stale and
        # silently drop the user turn from the persisted slice. 2026-06-13.
        user_msg = {"role": "user", "content": llm_content}
        ghost = self._ghost_row(user_input)           # per-turn context rides here, never the system prompt
        if history_messages is not None:
            # Foreground mode — use existing chat history
            messages = [{"role": "system", "content": self.system_prompt}] + history_messages
        else:
            # Ephemeral — no history
            messages = [{"role": "system", "content": self.system_prompt}]
        if ghost:
            messages.append(ghost)
        msg_start_idx = len(messages)  # the user row's initial position + fallback anchor
        messages.append(user_msg)

        # The scheduler stores 0 as the "unset / use default" sentinel for
        # max_tool_rounds and max_parallel_tools (scheduler.py:320-321,
        # frontend never exposes these by default). Treat 0 as "fall through
        # to config default" — `or` does this naturally for both None and 0.
        # Then max(1, ...) defends against negative or otherwise-falsy
        # surprises. Without this, a heartbeat task created without explicit
        # rounds was capped to 1 iteration: LLM uses it on a tool call, never
        # gets to respond, loop exhausts silently. 2026-05-10 bug.
        # Chaos scout #5/#10 (2026-04-20) protected against literal-0 cap-out
        # but mistook the scheduler's 0-default as a real value — preserved
        # the safety here by falling through to config defaults instead.
        # context_limit follows the same `or`: 0 / missing = the global
        # CONTEXT_LIMIT, which is what the task editor promises ("0 = app
        # default"). Unlimited is only reachable by setting THAT to 0.
        # Tool-image sink: only when the caller set a stream-brain override is
        # the effective chat genuinely this run's chat — without one, the sink
        # would key images to the OPERATOR'S open chat (P3-T4 mis-cascade), so
        # fall back to the old disk path instead.
        from core.chat import stream_brain
        _image_sink = self.session_manager if stream_brain.get_override() else None

        _rounds = self.task_settings.get("max_tool_rounds") or config.MAX_TOOL_ITERATIONS
        max_iterations = max(1, _rounds)
        _parallel = self.task_settings.get("max_parallel_tools") or config.MAX_PARALLEL_TOOLS
        max_parallel = max(1, _parallel)
        # Before 2026-09-26 a task's 0 meant NO limit, so every default-created
        # task shipped its whole chat: Discord Chat reached 271k tokens a turn
        # and Movie Night blew LM Studio's window with no trim log to say why.
        context_limit = self.task_settings.get("context_limit") or getattr(config, 'CONTEXT_LIMIT', 0)

        # Tool schemas are part of the actual API payload, so they MUST be
        # included in the budget. Without this, a task with 158 tools loaded
        # blows past the provider context cap even when message-content trim
        # claims things are fine. Reported in the wild 2026-05-05 — a heartbeat
        # with a heavy toolset hit this and produced an empty bubble. Trim of
        # message content can't free schema bytes; the user has to either
        # reduce the toolset or raise context_limit. Surfacing both numbers
        # in the error message tells them which lever to pull.
        from core.chat.history import count_tokens, count_message_tokens
        tool_schema_tokens = 0
        if self.tools:
            try:
                import json as _json
                tool_schema_tokens = sum(
                    count_tokens(_json.dumps(t, ensure_ascii=False))
                    for t in self.tools
                )
            except Exception:
                # Rough fallback if a tool schema isn't JSON-serializable
                tool_schema_tokens = len(self.tools) * 100

        logger.info(f"[ExecCtx] Running: provider='{self.provider_key}', "
                     f"tools={len(self.tools) if self.tools else 0} "
                     f"(~{tool_schema_tokens} schema tokens), "
                     f"history={len(history_messages) if history_messages else 0} msgs")
        from core.chat import budget
        _model = self.model_override or getattr(self.provider, 'model', '')
        _fm = getattr(self.tool_engine, 'function_manager', None)

        def _expiry(name):
            meta = _fm.tool_meta(name) if _fm is not None and hasattr(_fm, 'tool_meta') else None
            return meta.get('expires') if isinstance(meta, dict) else False   # False: not loaded, never expires
        # whose watermark and meter: the chat's own. ONE key per conversation,
        # whichever lane speaks: the web turn and this one share the cut point
        # and the context bar. A `task:` key of its own hid both (2026-11-01).
        _mark = (self.task_settings.get('chat_target')
                 if history_messages is not None and self.task_settings.get('chat_target') else None)
        final_content = None
        llm_retries = 0  # one rescue decode per run — shared by both garbage shapes below
        cut_streak = 0   # tool-call rounds cut at max_tokens, in a row

        overflow_reason = None
        loop_counts = {}  # per-turn per-tool call counts (loop guard); turn-local by design
        for i in range(max_iterations):
            if self._is_cancelled():
                logger.info(f"[ExecCtx] cancelled before round {i+1}")
                break
            # The one budgeter (core/chat/budget.py), as the chat lane uses it:
            # the real window (a local server's loaded context wins over a
            # bigger limit), room for the reply, expired tool results as one
            # line, the oldest turns out of view - on a copy; `messages` keeps
            # everything and this turn (user_msg on) is never cut. It replaces
            # this lane's own 90%/80% trim, which counted no reply room, no
            # tool_call arguments and every picture as 1500 tokens.
            try:
                fitted = budget.fit(messages, self.tools, self.provider, self.provider_key, _model,
                                    self.gen_params.get('max_tokens'), chat=_mark, live=user_msg,
                                    expiry=_expiry, limit=context_limit, label='a task')
            except budget.ContextFull as e:
                overflow_reason = f"(Context overflow - {e})"
                logger.error(f"[ExecCtx] {overflow_reason}")
                break
            gen_params = (self.gen_params if fitted.max_tokens == self.gen_params.get('max_tokens')
                          else {**self.gen_params, 'max_tokens': fitted.max_tokens})
            _t0 = time.time()
            response_msg = self.tool_engine.call_llm_with_metrics(
                self.provider, fitted.messages, gen_params, tools=self.tools
            )
            _t1 = time.time()
            budget.learn_usage(fitted, getattr(response_msg, 'usage', None))

            # A cancel that landed during the LLM call: nothing from this
            # reply is appended or executed — no tool side effects after the
            # user said stop, no half-turn in history.
            if self._is_cancelled():
                logger.info(f"[ExecCtx] cancelled after round {i+1}'s LLM reply — dropping it")
                break

            # What a person would see. Reasoning substituted for an empty
            # answer (openai_compat's fallback) and think-only text are NOT
            # answers on this lane: every outbound door (Discord, Telegram,
            # email, TTS) is downstream of here. The web chat renders those
            # itself and never comes through this loop.
            _reasoning_only = getattr(response_msg, 'content_is_reasoning', False) is True
            _visible = '' if _reasoning_only else visible_answer(response_msg.content or '')

            if response_msg.has_tool_calls:
                filtered = filter_to_thinking_only(response_msg.content or "")
                tool_calls = response_msg.get_tool_calls_as_dicts()[:max_parallel]
                # Carry `thinking` for DeepSeek-reasoner round-trip on next
                # iteration; harmless for other providers. 2026-05-14.
                _thinking = getattr(response_msg, "thinking", None)
                messages.append(self._with_meta({
                    "role": "assistant", "content": filtered,
                    "tool_calls": tool_calls,
                    "thinking": _thinking,
                }, response_msg, filtered, _t0, _t1))
                self.tool_log.extend(tc.get('function', {}).get('name', '?') for tc in tool_calls)
                self._tell_tool(tc.get('function', {}).get('name', '?') for tc in tool_calls)
                # Cap at source: a runaway agent can append thousands. The
                # poll-payload cap in BaseWorker.to_dict is a safety net; this
                # is the actual bound. Keep the last 500. Scout longevity #3.
                if len(self.tool_log) > 500:
                    del self.tool_log[:-500]
                tools_executed, tool_images = _exec_with_loop_counts(
                    self.tool_engine.execute_tool_calls,
                    tool_calls, messages, None, self.provider, scopes=self.scopes,
                    allowed_tools=self._allowed_tool_names, loop_counts=loop_counts,
                    image_sink=_image_sink, finish=getattr(response_msg, 'finish_reason', None)
                )
                if tool_images:
                    _inject_tool_images(messages, tool_images, self.provider)
                logger.info(f"[ExecCtx] Loop {i+1}: {tools_executed} tools executed")
                # If the LLM requested tool calls but NONE executed (hallucinated
                # tool names filtered out by allowed_tools, every call rejected),
                # continuing just invites the LLM to re-request the same ghosts
                # forever. Break with degraded_reason so the caller sees amber.
                # Scout chaos #6.
                if tools_executed == 0:
                    self.degraded_reason = (
                        f"LLM requested {len(tool_calls)} tool call(s) but none "
                        f"executed (likely hallucinated names not in toolset). "
                        f"Breaking loop to avoid infinite retry."
                    )
                    logger.warning(f"[ExecCtx] {self.degraded_reason}")
                    break
                # Two rounds in a row cut at max_tokens mid-call: each retry costs a
                # full max_tokens and lands the same way. Stop, and say why.
                cut_streak = cut_streak + 1 if response_msg.finish_reason in _LENGTH_FINISH else 0
                if cut_streak >= 2:
                    self.degraded_reason = (
                        "Two tool calls in a row were cut off at the reply length limit (max_tokens) "
                        "before their arguments finished. Stopped. Raise Max Tokens for this provider "
                        "in Settings › LLM, or ask for less per step.")
                    logger.warning(f"[ExecCtx] {self.degraded_reason}")
                    break
                continue

            elif response_msg.content and _visible:
                fn_data = self.tool_engine.extract_function_call_from_text(response_msg.content)
                if fn_data:
                    self.tool_log.append(fn_data.get('name', '?'))
                    self._tell_tool([fn_data.get('name', '?')])
                    if len(self.tool_log) > 500:
                        del self.tool_log[:-500]
                    filtered = filter_to_thinking_only(response_msg.content)
                    _, tool_images = _exec_with_loop_counts(
                        self.tool_engine.execute_text_based_tool_call,
                        fn_data, filtered, messages, None, self.provider, scopes=self.scopes,
                        allowed_tools=self._allowed_tool_names, loop_counts=loop_counts,
                        image_sink=_image_sink
                    )
                    if tool_images:
                        _inject_tool_images(messages, tool_images, self.provider)
                    continue

                # A tool task whose reply hit max_tokens WITHOUT a tool call is
                # a failed generation, not an answer (librarian b12 2026-07-19:
                # 35K chars of looping thinking, finish=length, the call never
                # came — one more sentence of budget and it would have landed).
                # Retry once with identical messages: nothing is appended, so
                # the garbage never poisons the fresh decode. A second length-
                # death keeps the text (the chat is the audit surface) but
                # flags degraded so workers don't count the message as ok.
                # Provider dialects for "hit the token ceiling": openai-compat
                # says 'length', Claude/anthropic-compat pass raw 'max_tokens',
                # openai_responses maps its max_output_tokens 'incomplete' to 'length' (fixer-scout, 2026-07-19 —
                # matching only 'length' left the b12 class live elsewhere).
                _finish = getattr(response_msg, 'finish_reason', None)
                # A wall of '...', a line on repeat, a two-token stub after
                # reasoning spent the budget: not an answer on ANY lane. Same
                # one rescue decode; a second failure DROPS it — an empty
                # bubble carrying the reason beats 1500 Discord messages of
                # dots (VIP report, 2026-09-25).
                _garbage = degenerate_reason(_visible, _finish)
                if _garbage or (_finish in _LENGTH_FINISH and self.tools):
                    if llm_retries < 1 and i + 1 < max_iterations:
                        # (last-iteration length-deaths skip the retry — the
                        # continue would exit the loop and DROP the text the
                        # audit contract promises to keep.)
                        llm_retries += 1
                        _what = (f"output looks degenerate ({_garbage})" if _garbage
                                 else f"finish={_finish} with no tool call")
                        logger.warning(
                            f"[ExecCtx] {_what} ({len(response_msg.content)} chars, "
                            f"finish={_finish}) — retrying turn once with a fresh decode.")
                        continue
                    if _garbage:
                        self.degraded_reason = (
                            f"LLM output looked degenerate ({_garbage}; "
                            f"{len(response_msg.content)} chars, finish={_finish}) "
                            f"— dropped, nothing sent.")
                        logger.warning(f"[ExecCtx] {self.degraded_reason}")
                        final_content = ""
                        messages.append(self._with_meta({"role": "assistant", "content": ""},
                                                        response_msg, "", _t0, _t1))
                        break
                    self.degraded_reason = (
                        "LLM hit max_tokens without completing a tool call "
                        "(truncated text kept for audit)."
                    )
                    logger.warning(f"[ExecCtx] {self.degraded_reason}")

                final_content = response_msg.content
                messages.append(self._with_meta({"role": "assistant", "content": final_content},
                                                response_msg, final_content, _t0, _t1))
                break
            else:
                # No answer and no tool_calls: empty content (a small /
                # quantized model, a provider that trimmed to its input cap),
                # reasoning substituted for content, or a think block with
                # nothing after it (the budget went to thinking). Same rescue
                # as the length-death above: spend the run's one retry, then
                # break degraded. Scout 2 #3.
                _why = ('reasoning only' if _reasoning_only
                        else 'thinking only' if response_msg.content else 'empty content')
                if llm_retries < 1 and i + 1 < max_iterations:
                    llm_retries += 1
                    logger.warning(
                        f"[ExecCtx] LLM returned {_why} with no tool calls — retrying turn once.")
                    continue
                self.degraded_reason = (
                    f"LLM returned {_why} with no tool calls "
                    "(provider may have hit its own input cap, spent the "
                    "budget thinking, or produced no output)."
                )
                logger.warning(f"[ExecCtx] {self.degraded_reason}")
                break

        # Before synthesizing a final placeholder, inject tool-result placeholders
        # for any dangling assistant(tool_calls) that never got their responses
        # (loop exhausted mid-round, worker cancelled, tools_executed==0 break).
        # Without this, the persisted sequence becomes asst(tc) → asst(text) with
        # no tool-role messages in between — OpenAI/Claude reject that structure
        # on the NEXT user turn and the chat is wedged. Placeholder content is
        # provider-agnostic (plain string, no special formatting). Scout chaos #12.
        def _patch_dangling_tool_calls():
            # Walk from end backward to find asst messages with tool_calls and
            # check whether their tool responses are present below them.
            for idx in range(len(messages) - 1, -1, -1):
                m = messages[idx]
                if m.get("role") != "assistant":
                    continue
                tcs = m.get("tool_calls") or []
                if not tcs:
                    break  # most-recent asst has no tool_calls — we're clean
                # Defensive: a misbehaving provider adapter or hand-edited
                # history could produce non-list tool_calls (dict, str). The
                # set-comprehension below would iterate a string as chars and
                # crash on `.get`, killing the whole task. Skip with a warning.
                # Witch-hunt 2026-04-21 finding H11.
                if not isinstance(tcs, list):
                    logger.warning(
                        f"[ExecCtx] _patch_dangling_tool_calls: msg[{idx}] tool_calls is "
                        f"{type(tcs).__name__}, not list — skipping patch"
                    )
                    break
                expected = {tc.get("id") for tc in tcs if isinstance(tc, dict) and tc.get("id")}
                got = set()
                insert_after = idx
                for j in range(idx + 1, len(messages)):
                    nxt = messages[j]
                    if nxt.get("role") == "tool" and nxt.get("tool_call_id") in expected:
                        got.add(nxt["tool_call_id"])
                        insert_after = j
                    elif nxt.get("role") == "assistant":
                        break  # new assistant turn — stop scanning
                missing = expected - got
                if missing:
                    # Insert placeholders right after the last real tool response
                    # (or right after the asst if there are none), preserving order.
                    pos = insert_after + 1
                    # Map tool_call_id -> function name from the asst(tc) so the
                    # placeholder carries `name`. history.get_messages_for_llm
                    # used to do msg["name"] (KeyError → swallowed → empty
                    # history return). Reader is fixed too, but writing the
                    # field is the right thing — keeps persisted history
                    # well-formed for any other consumer. 2026-05-10.
                    name_by_id = {}
                    for tc in tcs:
                        if isinstance(tc, dict):
                            tc_id = tc.get("id")
                            fn_name = (tc.get("function") or {}).get("name", "tool")
                            if tc_id:
                                name_by_id[tc_id] = fn_name
                    for tc_id in missing:
                        messages.insert(pos, {
                            "role": "tool",
                            "tool_call_id": tc_id,
                            "name": name_by_id.get(tc_id, "tool"),
                            "content": "(Tool did not execute — loop exhausted before resolution.)",
                        })
                        pos += 1
                break  # only patch the most recent asst(tc) — older ones already closed
        _patch_dangling_tool_calls()

        # If we exhausted iterations, try to extract last content
        if final_content is None and messages:
            last = messages[-1]
            if last.get("role") == "assistant" and last.get("content"):
                final_content = last["content"]
            else:
                # Diagnostic text MUST stay in degraded_reason for UI badges /
                # logs only — it must NEVER end up as final_content because
                # final_content becomes TTS speech, Discord channel posts,
                # Telegram replies, email bodies. Sapphire saying "(No response
                # — tool loop exhausted or LLM returned empty)" out loud was
                # the 2026-04-24 Evening-mode incident; the same string going
                # to Discord channels was the local-Sapph variant. Both close
                # by keeping final_content empty here so caller truthy-checks
                # (`if response:`) drop the output cleanly. Scout #15 / Krem
                # 2026-04-24.
                if self.cancelled:
                    self.degraded_reason = (
                        f"Cancelled by user. Tools called before the stop: "
                        f"{', '.join(self.tool_log) or '(none)'}."
                    )
                elif overflow_reason:
                    self.degraded_reason = overflow_reason
                elif not self.degraded_reason:
                    # (an in-loop reason — empty / reasoning-only / degenerate
                    # output — used to be overwritten here with "exhausted")
                    self.degraded_reason = (
                        f"Tool loop exhausted after {max_iterations} rounds without "
                        f"a final reply. Tools called: {', '.join(self.tool_log) or '(none)'}."
                    )
                final_content = ""
                # Empty assistant content keeps the chat-history pair intact
                # (closes the orphaned-user-turn hazard the original synth was
                # written to address) without putting engineering text in front
                # of users.
                messages.append({"role": "assistant", "content": ""})

        # ANCHOR BY IDENTITY: re-derive the user message's CURRENT index — the
        # in-loop context trim may have deleted messages before it, shifting it
        # down. A frozen index would point past the real turn and drop it from
        # the persisted slice. Derive ONCE here: the swap below replaces the
        # object (so it can't be re-found afterward), but the swap doesn't change
        # list length, so cur_idx stays valid for the slice. Multiple trims are
        # handled for free — this reflects the final position. 2026-06-13.
        cur_idx = next((i for i, m in enumerate(messages) if m is user_msg), msg_start_idx)

        # DUAL-FORM SWAP: the LLM saw the image as base64 across this turn's
        # rounds, but history must persist the MARKER form (text + <<IMG::...>>),
        # never inline base64 — otherwise every replay re-sends the image and
        # bloats the chat. Swap the anchored user message's content to the marker
        # form. No-op when no images were passed, and for a text-only model that
        # read a description (persist_content == llm_content both times).
        if images and len(messages) > cur_idx:
            _um = messages[cur_idx]
            if _um.get("role") == "user":
                messages[cur_idx] = {**_um, "content": persist_content}

        # Expose messages generated during this run. Scrub inline base64 image
        # blocks (appended mid-loop by _inject_tool_images for tool-returned
        # images) down to text — those images are referenced by their own
        # <<IMG::tool:id>> markers in the tool-result messages, so the base64 is
        # turn-only and must not persist (same replay-bloat hazard the swap
        # guards for event images). 2026-06-13. Only include if we got a response —
        # an orphaned user message with no assistant reply corrupts chat history.
        # The app's own rows (`_inject`: the tool-image note) stay turn-only, as
        # in the chat lane: stored, a note row reads as the person's turn later.
        new = [_scrub_inline_images(m) for m in messages[cur_idx:] if not m.get("_inject")]
        has_assistant = any(m.get("role") == "assistant" for m in new)
        self.new_messages = new if has_assistant else []

        return final_content or ""
