{
  "plugin": "email",
  "version": "1.2.0",
  "files": {
    "README.md": "sha256:b3724d27b960799ceca60d593c118eede4734704bb41e430d96d635988fc6b00",
    "daemon.py": "sha256:f1d3e12a60fb9700a1c39d6e9f840309e42fa08525b9c8178de9089a0b8e3026",
    "plugin.json": "sha256:90fd20a0db6d01e6d2eee0b00573e880b56480ab9c2400ffa42b023007c040ae",
    "tests/test_archive_partial_success.py": "sha256:04f3d1e9f3c68a5fbb56ced21656cfc7a55877e54190fe120594113327948470",
    "tests/test_delete_emails.py": "sha256:f3bf4af555fc00f68bc9020521f9cf92e0f017d0ca608de198da5e67310c32b3",
    "tests/test_forward_cc.py": "sha256:53cf70bc4f82e1dfd44eec1b43f7dac91e31e4387346235a1fb61cb63d8c1abc",
    "tests/test_oauth_refresh_error.py": "sha256:038dbc93d434de7185bfa5a53db785d5c587a20771016b7a1ad49e684e57d10e",
    "tests/test_search_emails.py": "sha256:f5cc9a4c9a354b03b564cc8fea8c25fecfdd0258ba523c4c14ff0e6155e606e4",
    "tests/test_send_email_mutex.py": "sha256:279220d7b548b86428b3e843027327ef490f89236ded03b7fbb510b58bcc6c1f",
    "tools/email_tool.py": "sha256:7d2b98e49bfb066d00091472568a489fc46e0ed23c4598692ac53cee707c5fd0",
    "web/index.js": "sha256:376002392e2790776e7f286b2129e3d30a812b6a91b2b5f72fa014b16a49448a"
  },
  "signature": "mMivL7SxICUt3yjQaquUwytD2nREp2BNE2AsfFoD5lyvdZ4XQWIOQ6Az9X9qxKSNJTcDXYAj0JsYbbYRiSSlBA=="
}