# Google Calendar tools
# Pure REST via requests — no Google client libraries needed.

import json
import logging
import re
import threading
import time
from datetime import datetime, timedelta

import requests
from core import net

logger = logging.getLogger(__name__)

# Per-scope locks serialize the token refresh dance (check expiry → POST to
# Google → save). Without this, two concurrent callers both see expired, both
# POST, both write — last-writer-wins on disk and the other thread's access
# token is the one Google rotated out of. Worse, if Google rotated the
# refresh_token, the losing write clobbers the new one with the old. Gone.
_refresh_locks_guard = threading.Lock()
_refresh_locks: dict = {}


def _lock_for(scope: str) -> threading.Lock:
    """Get or create the per-scope refresh lock. The guard lock around the
    dict itself is only held for the tiny get-or-create — the scope lock is
    what actually serializes refreshes."""
    with _refresh_locks_guard:
        lock = _refresh_locks.get(scope)
        if lock is None:
            lock = threading.Lock()
            _refresh_locks[scope] = lock
        return lock

ENABLED = True
EMOJI = '\U0001f4c5'
TOOL_CATEGORY = 'comms'

GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token'
CALENDAR_API = 'https://www.googleapis.com/calendar/v3'

AVAILABLE_FUNCTIONS = ['calendar_today', 'calendar_range', 'calendar_add', 'calendar_delete']

TOOLS = [
    {
        "type": "function",
        "is_local": False,
        "network": True,
        "function": {
            "name": "calendar_today",
            "description": "Today's events (numbered for calendar_delete) with times, guest RSVPs and free hours.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "is_local": False,
        "network": True,
        "function": {
            "name": "calendar_range",
            "description": "Events for a date range, numbered for calendar_delete.",
            "parameters": {
                "type": "object",
                "properties": {
                    "start_date": {
                        "type": "string",
                        "description": "YYYY-MM-DD (default today)"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "YYYY-MM-DD (default start + 7 days)"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "writes": True,
        "is_local": False,
        "network": True,
        "function": {
            "name": "calendar_add",
            "description": "Add a calendar event. Times are local - do NOT add 'Z' or offsets.",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string"
                    },
                    "start": {
                        "type": "string",
                        "description": "YYYY-MM-DDTHH:MM, or YYYY-MM-DD for all-day"
                    },
                    "end": {
                        "type": "string",
                        "description": "Default start + 1 hour"
                    },
                    "description": {
                        "type": "string",
                        "description": "Notes"
                    },
                    "attendees": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Contact names from People (or ids). Google emails each an invite. Only contacts with 'Allow AI to "
                                       "send email' resolve."
                    }
                },
                "required": ["title", "start"]
            }
        }
    },
    {
        "type": "function",
        "writes": True,
        "is_local": False,
        "network": True,
        "function": {
            "name": "calendar_delete",
            "description": "Delete a calendar event by its number from calendar_today / calendar_range.",
            "parameters": {
                "type": "object",
                "properties": {
                    "event_id": {
                        "type": "string",
                        "description": "e.g. '1' or '#1'"
                    }
                },
                "required": ["event_id"]
            }
        }
    }
]


# === Auth helpers ===

def _get_gcal_scope():
    """Get current gcal scope from ContextVar."""
    try:
        from core.chat.function_manager import scope_gcal
        return scope_gcal.get()
    except Exception as e:
        # Fail disabled, not defaulted. Same silent-default class we closed
        # in memory/knowledge/goals on 2026-04-20. If ContextVar resolution
        # fails, a task with gcal_scope='none' must not silently inherit
        # another scope's refresh token.
        logger.warning(f"Could not get gcal scope: {e}, returning None (disabled)")
        return None


def _get_gcal_creds():
    """Get credentials for current gcal scope."""
    from core.credentials_manager import credentials
    scope = _get_gcal_scope()
    if scope is None:
        return None, "Google Calendar is disabled for this chat."
    return credentials.get_gcal_account(scope), None


def _get_access_token(force_refresh: bool = False):
    """Get a valid access token for the current gcal scope.

    Returns (access_token, calendar_id, err). On error, token and
    calendar_id are None and err has a user-facing message.

    `force_refresh=True` bypasses the cache and hits Google unconditionally —
    used by the 401-retry path in _api_call.

    The refresh dance is serialized per-scope: a second concurrent caller
    waits on the scope lock, then re-reads the cache and returns the freshly-
    minted token instead of double-refreshing. This prevents the race where
    both threads POST and one loses a potential refresh_token rotation.
    """
    creds, err = _get_gcal_creds()
    if err:
        return None, None, err

    refresh_token = creds.get('refresh_token', '')
    if not refresh_token:
        return None, None, "Google Calendar not connected. Go to Settings > Google Calendar and click Connect."

    auth_mode = creds.get('auth_mode', 'byo')
    client_id = creds.get('client_id', '')
    client_secret = creds.get('client_secret', '')
    if auth_mode != 'relay' and (not client_id or not client_secret):
        return None, None, "Google Client ID/Secret not configured in Settings."

    calendar_id = creds.get('calendar_id', 'primary') or 'primary'

    from core.credentials_manager import credentials
    scope = _get_gcal_scope()

    with _lock_for(scope):
        # Re-check the cache AFTER taking the lock. If we were queued behind
        # another refresh, that refresh just completed — use its fresh token.
        snap = credentials.get_gcal_tokens_snapshot(scope)
        cached_token = snap.get('access_token', '')
        expires_at = snap.get('expires_at', 0)
        if not force_refresh and cached_token and expires_at > time.time() + 60:
            return cached_token, calendar_id, None

        # Actually refresh. Relay (easy-connect) accounts have no local
        # client creds — the relay adds the shared client's secret and
        # returns Google's response verbatim, so the handling below is
        # identical for both modes. Catch network errors separately from
        # HTTP errors so the user gets a useful message.
        try:
            if auth_mode == 'relay':
                relay = (creds.get('relay_url') or 'https://oauth.sapphireblue.dev').rstrip('/')
                resp = net.post(f"{relay}/refresh",
                                     json={'refresh_token': refresh_token}, timeout=15)
            else:
                resp = net.post(GOOGLE_TOKEN_URL, data={
                    'refresh_token': refresh_token,
                    'client_id': client_id,
                    'client_secret': client_secret,
                    'grant_type': 'refresh_token',
                }, timeout=15)
        except requests.RequestException as e:
            endpoint = "the Sapphire connect relay" if auth_mode == 'relay' else "Google's token endpoint"
            logger.warning(f"[GCAL] Network error during token refresh: {e}")
            return None, None, (f"Couldn't reach {endpoint} "
                                f"({type(e).__name__}). Try again in a moment.")

        if resp.status_code == 200:
            try:
                tokens = resp.json()
                access_token = tokens['access_token']
            except (ValueError, KeyError) as e:
                logger.error(f"[GCAL] Malformed token response: {e}; body: {resp.text[:200]}")
                return None, None, f"Malformed token response from Google: {e}"

            new_expires = time.time() + tokens.get('expires_in', 3600)
            # Rotation-aware save: Google MAY return a new refresh_token under
            # certain conditions (security rotation, scope change). If we
            # save the old one we'll fail with invalid_grant on next refresh.
            # Scout finding 2026-04-19.
            new_refresh = tokens.get('refresh_token', refresh_token)
            if new_refresh != refresh_token:
                logger.info(f"[GCAL] refresh_token rotated for scope '{scope}' — saving new one")
            credentials.update_gcal_tokens(scope, new_refresh, access_token, new_expires)
            return access_token, calendar_id, None

        # Non-200: discriminate the cause so the message matches reality.
        try:
            err_body = resp.json()
            err_code = err_body.get('error', '') or ''
        except ValueError:
            err_code = ''
        logger.error(f"[GCAL] Token refresh HTTP {resp.status_code} error={err_code!r}: {resp.text[:200]}")

        if err_code == 'invalid_grant':
            return None, None, (
                "Google rejected the refresh token (invalid_grant). "
                "Disconnect and reconnect in Settings > Google Calendar."
            )
        if resp.status_code >= 500:
            return None, None, (
                f"Google token endpoint temporarily unavailable (HTTP {resp.status_code}). "
                "Try again in a few minutes."
            )
        return None, None, (
            f"Token refresh failed (HTTP {resp.status_code}"
            + (f", error={err_code}" if err_code else "")
            + "). If this keeps happening, try reconnecting in Settings."
        )


def _api_call(method: str, endpoint_template: str, params=None, body=None):
    """Authenticated GCal API call with one automatic 401 retry.

    `endpoint_template` may contain `{calendar_id}` — substituted from the
    caller's scope credentials. Returns (data, err). For 204 / no-content
    responses, data is True on success.

    On 401, forces a fresh refresh and retries once. Without this, a tiny
    clock skew or cached Google 401 would surface to the user as "reconnect"
    when a retry would've worked.
    """
    last_err = None
    for attempt in range(2):
        force = (attempt == 1)
        token, calendar_id, err = _get_access_token(force_refresh=force)
        if err:
            return None, err
        try:
            url = f"{CALENDAR_API}{endpoint_template.format(calendar_id=calendar_id)}"
        except KeyError as e:
            return None, f"Endpoint template missing substitution: {e}"
        headers = {'Authorization': f'Bearer {token}'}
        if body is not None:
            headers['Content-Type'] = 'application/json'
        try:
            resp = net.request(method, url, headers=headers, params=params,
                                    json=body, timeout=15)
        except requests.RequestException as e:
            return None, f"Network error ({type(e).__name__}): {e}"
        if resp.status_code == 401 and attempt == 0:
            logger.info(f"[GCAL] 401 on {method} {endpoint_template} — forcing refresh and retrying")
            continue
        if resp.status_code == 401:
            return None, "Authentication expired after refresh. Reconnect in Settings > Google Calendar."
        if resp.status_code in (200, 201):
            try:
                return resp.json(), None
            except ValueError:
                return True, None
        if resp.status_code == 204:
            return True, None
        last_err = f"API error {resp.status_code}: {resp.text[:200]}"
        return None, last_err
    return None, last_err or "Unexpected auth failure."


def _api_get(endpoint_template, params=None):
    return _api_call('GET', endpoint_template, params=params)


def _api_post(endpoint_template, data, params=None):
    return _api_call('POST', endpoint_template, params=params, body=data)


def _api_delete(endpoint_template):
    return _api_call('DELETE', endpoint_template)


# === Formatting ===

def _format_time(dt_str):
    """Parse Google's datetime and return clean time string."""
    try:
        # Handle full datetime
        if 'T' in dt_str:
            dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
            return dt.strftime('%I:%M %p').lstrip('0')
        # Handle date-only (all-day events)
        return 'All day'
    except Exception:
        return dt_str


# Short ID map — maps #1, #2 etc to real Google event IDs, scoped per-request
# Display-number -> Google event ID, per scope. Module-global on purpose:
# a ContextVar dies with the tool call's execution context, so the map
# written by calendar_today was never visible to a later calendar_delete
# (found live 2026-07-30 — delete sent the raw "#3" to Google, 404).
# Restart wipes it; delete's error message says to re-list, which rebuilds.
_id_maps_guard = threading.Lock()
_id_maps: dict = {}  # scope -> {display_num_str: google_event_id}


def _resolve_event_id(raw: str):
    """Resolve a display number ('3' / '#3') to the real Google event ID via
    the current scope's last listing. Returns (event_id, err). Non-numeric
    input is assumed to already be a Google event ID and passes through."""
    raw = (raw or '').strip().lstrip('#')
    if not raw:
        return None, "Event ID is required. Use calendar_today or calendar_range to find event numbers."
    scope = _get_gcal_scope()
    with _id_maps_guard:
        mapped = _id_maps.get(scope, {}).get(raw)
    if mapped:
        return mapped, None
    if raw.isdigit():
        return None, (f"No current event listing to resolve #{raw} against. "
                      "Run calendar_today or calendar_range first, then delete using the fresh number.")
    return raw, None


# === Guests ===
# Invite resolution rides the People whitelist exactly like email/phone: the
# only path to an address is a contact with 'Allow AI to send email' checked
# in Mind -> People. No direct-address mode.

_RSVP = {'accepted': 'yes', 'declined': 'no', 'tentative': 'maybe', 'needsAction': 'pending'}
_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def _get_people_scope():
    """None when unset/disabled — refuse, never fall back to a real scope
    (silent-default class invariant, same as email/phone)."""
    try:
        from core.chat.function_manager import scope_people
        return scope_people.get()
    except Exception as e:
        logger.debug(f"gcal: people scope resolution failed: {e}")
        return None


def _split_guests(raw):
    """Normalize the attendees argument to a list of strings. Models sometimes
    hand over one string — 'Rob, Sam' / 'Rob and Sam' — instead of a list."""
    if raw is None:
        return []
    if isinstance(raw, (int, float)):
        return [str(int(raw))]
    if isinstance(raw, str):
        raw = raw.strip()
        if raw.startswith('['):
            # Some models JSON-encode the array as a string (GLM, live 2026-09-26).
            try:
                return _split_guests(json.loads(raw))
            except ValueError:
                pass
        return [s for s in re.split(r'\s*(?:,|;|&|\band\b)\s*', raw) if s.strip()]
    return [str(x) for x in raw if str(x).strip()]


def _match_person(key, people):
    """One name/id -> (person, None) or (None, err). Exact name (case-insensitive)
    first, then a unique substring match so 'Rob' finds 'Rob Smith'. Ambiguity
    is an error that names the candidates — never a silent guess."""
    key = key.strip().lstrip('#')
    if key.isdigit():
        pid = int(key)
        person = next((p for p in people if p.get('id') == pid), None)
        return (person, None) if person else (None, f"Contact id {pid} not found.")
    low = key.lower()
    names = lambda ps: ', '.join(f"{p['name']} [id:{p.get('id')}]" for p in ps)
    exact = [p for p in people if (p.get('name') or '').strip().lower() == low]
    if len(exact) == 1:
        return exact[0], None
    if exact:
        return None, f"'{key}' matches several contacts: {names(exact)}. Use the id."
    partial = [p for p in people if low in (p.get('name') or '').lower()]
    if len(partial) == 1:
        return partial[0], None
    if partial:
        return None, f"'{key}' matches several contacts: {names(partial)}. Use the full name or id."
    return None, f"No contact named '{key}'."


def _resolve_attendees(raw):
    """People names/ids -> Google attendee dicts. Returns (attendees, err);
    err is a full user-facing message and attendees is None on error."""
    wanted = _split_guests(raw)
    if not wanted:
        return [], None
    scope = _get_people_scope()
    if scope is None:
        return None, "People contacts are disabled for this chat, so guests can't be resolved."
    from core.contacts import get_people
    people = get_people(scope)
    invitable = [p for p in people if p.get('email_whitelisted') and p.get('email')]
    hint = ("\nInvitable contacts: " + ', '.join(p['name'] for p in invitable)) if invitable else (
        "\nNo contacts are allowed yet — tick 'Allow AI to send email' on them in Mind → People.")
    out, seen = [], set()
    for key in wanted:
        person, err = _match_person(key, people)
        if err:
            return None, err + hint
        name = person.get('name') or key
        if not person.get('email_whitelisted'):
            return None, f"{name} isn't allowed for invites — tick 'Allow AI to send email' on them in Mind → People."
        email = (person.get('email') or '').strip()
        if not email:
            return None, f"{name} has no email address in Mind → People."
        if not _EMAIL_RE.match(email):
            return None, f"{name}'s email '{email}' isn't a valid address — fix it in Mind → People."
        if email.lower() in seen:
            continue
        seen.add(email.lower())
        out.append({'email': email, 'displayName': name})
    return out, None


def _format_guests(event, limit=8):
    """'  [guests: Rob (yes), Sam (pending)]' or ''. Skips the calendar
    owner's own row and meeting-room resources."""
    guests = [a for a in event.get('attendees') or [] if not a.get('self') and not a.get('resource')]
    if not guests:
        return ''
    parts = [f"{a.get('displayName') or a.get('email') or '?'} ({_RSVP.get(a.get('responseStatus'), 'pending')})"
             for a in guests[:limit]]
    if len(guests) > limit:
        parts.append(f"+{len(guests) - limit} more")
    return f"  [guests: {', '.join(parts)}]"


def _format_events(events, title_line, now=None):
    """Format a list of events into AI-digestible text. Labels past/current if now is provided."""
    if not events:
        # Clear the stale number map too — otherwise "delete #1" after an
        # empty day would hit whatever #1 was in the previous listing.
        with _id_maps_guard:
            _id_maps[_get_gcal_scope()] = {}
        return f"{title_line}\nNo events scheduled."

    id_map = {}
    lines = [title_line]
    total_minutes = 0

    for i, event in enumerate(events, 1):
        summary = event.get('summary', '(No title)')
        real_id = event.get('id', '')
        id_map[str(i)] = real_id
        start = event.get('start', {})
        end = event.get('end', {})

        start_str = start.get('dateTime', start.get('date', ''))
        end_str = end.get('dateTime', end.get('date', ''))

        label = ''
        if start.get('dateTime') and end.get('dateTime'):
            start_time = _format_time(start_str)
            end_time = _format_time(end_str)
            time_str = f"{start_time}–{end_time}"
            try:
                s = datetime.fromisoformat(start_str.replace('Z', '+00:00'))
                e = datetime.fromisoformat(end_str.replace('Z', '+00:00'))
                total_minutes += (e - s).total_seconds() / 60
                if now:
                    if e <= now:
                        label = ' [past]'
                    elif s <= now < e:
                        label = ' [NOW]'
            except Exception:
                pass
        else:
            time_str = "All day"

        lines.append(f"  #{i}  {time_str}  {summary}{label}{_format_guests(event)}")

    # Summary line
    hours_busy = total_minutes / 60
    lines.append(f"\n{len(events)} event{'s' if len(events) != 1 else ''}, ~{hours_busy:.1f} hours scheduled")

    with _id_maps_guard:
        _id_maps[_get_gcal_scope()] = id_map
    return '\n'.join(lines)


# === Tool execution ===

def execute(function_name, arguments, config, plugin_settings=None):
    # Preflight: surfaces connection / credential errors before any
    # per-function work. Each _api_call re-acquires internally so rotation
    # + 401-retry land in the right place — the token from this preflight
    # is intentionally discarded.
    _, _, err = _get_access_token()
    if err:
        return err, False

    if function_name == 'calendar_today':
        tz = _get_local_tz()
        try:
            from zoneinfo import ZoneInfo
            user_tz = ZoneInfo(tz)
        except Exception:
            user_tz = None
        now = datetime.now(user_tz) if user_tz else datetime.now().astimezone()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        tomorrow = today + timedelta(days=1)

        data, err = _api_get('/calendars/{calendar_id}/events', {
            'timeMin': today.isoformat(),
            'timeMax': tomorrow.isoformat(),
            'timeZone': tz,
            'singleEvents': 'true',
            'orderBy': 'startTime',
            'maxResults': 50,
        })
        if err:
            return err, False

        events = data.get('items', [])
        day_name = today.strftime('%A %B %d')
        return _format_events(events, f"Today ({day_name}):", now=now), True

    elif function_name == 'calendar_range':
        start_str = arguments.get('start_date', '')
        end_str = arguments.get('end_date', '')
        tz = _get_local_tz()

        try:
            from zoneinfo import ZoneInfo
            user_tz = ZoneInfo(tz)
        except Exception:
            user_tz = None

        try:
            start = datetime.strptime(start_str, '%Y-%m-%d') if start_str else datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        except ValueError:
            return f"Invalid start_date format: '{start_str}'. Use YYYY-MM-DD.", False

        try:
            end = datetime.strptime(end_str, '%Y-%m-%d') if end_str else start + timedelta(days=7)
        except ValueError:
            return f"Invalid end_date format: '{end_str}'. Use YYYY-MM-DD.", False

        # Attach timezone so isoformat() includes the UTC offset
        if user_tz:
            start = start.replace(tzinfo=user_tz)
            end = end.replace(tzinfo=user_tz)
        else:
            start = start.astimezone()
            end = end.astimezone()

        # End should be end of day
        end = end.replace(hour=23, minute=59, second=59)

        data, err = _api_get('/calendars/{calendar_id}/events', {
            'timeMin': start.isoformat(),
            'timeMax': end.isoformat(),
            'timeZone': tz,
            'singleEvents': 'true',
            'orderBy': 'startTime',
            'maxResults': 100,
        })
        if err:
            return err, False

        events = data.get('items', [])

        # Group by day
        days = {}
        for event in events:
            e_start = event.get('start', {})
            date_str = e_start.get('dateTime', e_start.get('date', ''))[:10]
            days.setdefault(date_str, []).append(event)

        lines = [f"Schedule: {start.strftime('%b %d')} – {end.strftime('%b %d')}"]
        # Numbered #1.. across the whole range into the same map calendar_delete
        # reads. Before 2026-09-26 range printed raw Google ids and never wrote
        # the map, so "delete #3 from next week" 404'd (README promised numbers).
        id_map = {}

        # Walk each day in the range, show events or "free"
        current = start
        while current <= end:
            date_key = current.strftime('%Y-%m-%d')
            day_label = current.strftime('%A %b %d')
            if date_key in days:
                lines.append(f"\n{day_label}:")
                for event in days[date_key]:
                    n = len(id_map) + 1
                    id_map[str(n)] = event.get('id', '')
                    summary = event.get('summary', '(No title)')
                    e_start = event.get('start', {})
                    e_end = event.get('end', {})
                    if e_start.get('dateTime'):
                        time_str = f"{_format_time(e_start['dateTime'])}–{_format_time(e_end.get('dateTime', ''))}"
                    else:
                        time_str = "All day"
                    lines.append(f"  #{n}  {time_str}  {summary}{_format_guests(event)}")
            else:
                lines.append(f"\n{day_label}:\n  No events — free all day")
            current += timedelta(days=1)

        with _id_maps_guard:
            _id_maps[_get_gcal_scope()] = id_map
        total_events = len(id_map)
        lines.append(f"\n{total_events} event{'s' if total_events != 1 else ''} total")
        return '\n'.join(lines), True

    elif function_name == 'calendar_add':
        title = arguments.get('title', '').strip()
        start_str = arguments.get('start', '').strip()
        end_str = arguments.get('end', '').strip()
        description = arguments.get('description', '').strip()

        if not title:
            return "Event title is required.", False
        if not start_str:
            return "Start time is required.", False

        # Resolve guests BEFORE anything hits Google — a bad name must not
        # leave a guest-less event behind.
        attendees, err = _resolve_attendees(arguments.get('attendees'))
        if err:
            return err, False

        # Build event body
        event = {'summary': title}
        if description:
            event['description'] = description

        is_all_day = 'T' not in start_str

        if is_all_day:
            event['start'] = {'date': start_str}
            if end_str and 'T' not in end_str:
                # Google's all-day end date is exclusive, add 1 day
                try:
                    end_dt = datetime.strptime(end_str, '%Y-%m-%d') + timedelta(days=1)
                    event['end'] = {'date': end_dt.strftime('%Y-%m-%d')}
                except ValueError:
                    event['end'] = {'date': start_str}
            else:
                # Single all-day: end = start + 1 day
                try:
                    end_dt = datetime.strptime(start_str, '%Y-%m-%d') + timedelta(days=1)
                    event['end'] = {'date': end_dt.strftime('%Y-%m-%d')}
                except ValueError:
                    return f"Invalid date format: '{start_str}'. Use YYYY-MM-DD.", False
        else:
            tz = _get_local_tz()
            # Normalize to full ISO (YYYY-MM-DDTHH:MM:SS)
            try:
                start_dt = datetime.fromisoformat(start_str)
            except ValueError:
                return f"Invalid datetime format: '{start_str}'. Use YYYY-MM-DDTHH:MM.", False
            event['start'] = {'dateTime': start_dt.isoformat(), 'timeZone': tz}
            if end_str and 'T' in end_str:
                try:
                    end_dt = datetime.fromisoformat(end_str)
                except ValueError:
                    return f"Invalid datetime format: '{end_str}'. Use YYYY-MM-DDTHH:MM.", False
                event['end'] = {'dateTime': end_dt.isoformat(), 'timeZone': tz}
            else:
                # Default: 1 hour after start
                end_dt = start_dt + timedelta(hours=1)
                event['end'] = {'dateTime': end_dt.isoformat(), 'timeZone': tz}

        params = None
        if attendees:
            event['attendees'] = attendees
            # Google's default is OFF: without this the guests are listed on
            # the event but nobody gets an email (events.insert ref, 2026-09-26).
            params = {'sendUpdates': 'all'}

        data, err = _api_post('/calendars/{calendar_id}/events', event, params=params)
        if err:
            return err, False

        invited = ''
        if attendees:
            invited = "\nInvited (Google is emailing them): " + ', '.join(a['displayName'] for a in attendees)

        # Format confirmation
        e_start = data.get('start', {})
        if e_start.get('dateTime'):
            start_display = _format_time(e_start['dateTime'])
            e_end = data.get('end', {})
            end_display = _format_time(e_end.get('dateTime', ''))
            try:
                day = datetime.fromisoformat(e_start['dateTime'].replace('Z', '+00:00'))
                day_str = day.strftime('%A %b %d')
            except Exception:
                day_str = ''
            return f"Added: \"{title}\" — {day_str}, {start_display}–{end_display}\n(id: {data.get('id', '')}){invited}", True
        else:
            return f"Added: \"{title}\" — all day event\n(id: {data.get('id', '')}){invited}", True

    elif function_name == 'calendar_delete':
        event_id, err = _resolve_event_id(arguments.get('event_id', ''))
        if err:
            return err, False

        _, err = _api_delete('/calendars/{calendar_id}/events/' + event_id)
        if err:
            return err, False

        return f"Deleted event {event_id}.", True

    return f"Unknown function: {function_name}", False


def _get_local_tz():
    """Get local IANA timezone name (e.g. America/New_York)."""
    try:
        # Prefer Sapphire's configured timezone
        import config as cfg
        tz_name = getattr(cfg, 'USER_TIMEZONE', '') or ''
        if tz_name and tz_name != 'UTC':
            return tz_name
        # Python 3.9+: tzinfo.key gives IANA name
        tz = datetime.now().astimezone().tzinfo
        if hasattr(tz, 'key'):
            return tz.key
        # Fallback: read from system
        from pathlib import Path
        tz_link = Path('/etc/localtime')
        if tz_link.is_symlink():
            target = str(tz_link.resolve())
            if 'zoneinfo/' in target:
                return target.split('zoneinfo/')[-1]
    except Exception:
        pass
    return 'UTC'
