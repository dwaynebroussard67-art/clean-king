# Discord Plugin

Connect Sapphire to Discord. The host plugin is the bot itself: accounts, the reply pipeline
(mentions, name match, organic replies, batching, typing), images in and out, GIFs, silent
reactions, and voice channels running on Sapphire's own conversation engine. **What she does on
Discord is configured in Triggers**: chat and greetings are daemon tasks (**Triggers → Daemons**),
voice is a Realtime rule (**Triggers → Realtime**), and each task's persona, provider, model and toolset are the brain behind it. Personality
modules (people memory, birthdays, typos) live in the separate
`discord-personality` plugin.

When the plugin is enabled it starts its own background daemon. You never add a daemon entry for
the runtime itself — only Triggers tasks for what she should do.

Meticulously crafted by ddxfish and zeebie-the-zebra

## Requirements

The plugin needs a few Python packages, and they are **not** installed for you. When you enable it,
**Settings → Plugins → Discord** shows a **Missing: …** strip with an **Install** button (works in a
conda env or venv; on plain system Python it shows the pip command). Restart Sapphire after installing.

- **py-cord** (with voice support) — installs from a **pinned git commit**, so **Git must be on your PATH**.
- **davey** + **PyNaCl** — encrypted voice receive (DAVE).

> **If you ever installed `discord.py`, remove it first:** `pip uninstall discord.py`. It claims the
> same `discord` import name as py-cord and the two cannot live in one environment.

**ffmpeg is not required.** Her speech is decoded in-process. For voice channels you also need
**TTS streaming enabled** in Sapphire Settings.

## Upgrading

**From 1.x to 2.0:** on first boot your **bot accounts (tokens) are moved into Sapphire's credentials
manager**, where every other plugin keeps its secrets, and the old plugin database is renamed aside as
`discord.sqlite3.imported`. The plugin keeps no database of its own any more. Everything else the old
versions stored (profiles, memories, channel messages, traces, transcripts, per-server overlays)
belongs to features that left the host; delete the `.imported` file once your bots are online. Your
daemon and realtime tasks keep working. See [CHANGELOG.md](CHANGELOG.md).

**A hand-installed copy in `user/plugins/discord`** always wins over the shipped one (the log says
`[PLUGINS] 'discord' (user band) shadows the system copy`). Delete that folder and restart.

## Quick Start

### 1. Create a Discord bot

1. [Discord Developer Portal](https://discord.com/developers/applications) → **New Application**
2. **Bot** tab → **Add Bot**
3. Under **Privileged Gateway Intents** enable **Message Content Intent** (required) and
   **Server Members Intent** (recommended — it fills the bot allowlist picker)
4. Copy the bot token

### 2. Invite the bot to your server

**OAuth2 → URL Generator**: scope `bot`; permissions `View Channels`, `Read Message History`,
`Send Messages`, plus `Add Reactions` (silent reactions) and `Connect`, `Speak`,
`Use Voice Activity` (voice). Open the generated URL and add the bot.

### 3. Enable and add the account

1. **Settings → Plugins → Discord** → enable (install the missing packages if prompted)
2. The settings page shows **Daemon is running** when healthy
3. **Bot Accounts** → name + token → **Add Bot**

A saved bot stays offline until an enabled daemon or realtime task selects it — that is the
switch that decides which bots log in.

### 4. Give her a job in Triggers

**Triggers → Daemons → + Daemon** with source **Discord: Chat**, pick the bot, set
filters (start with `mentioned = true`), leave **Auto-reply** on, set the persona / provider /
toolset. She answers in that channel from the next message.

Optional: **Triggers → Realtime → + Realtime → Discord: Voice channel** for voice (see [Voice](#voice)).

## Trigger sources

| Source | Kind | What it does | Task fields |
|---|---|---|---|
| **Discord: Chat** | daemon | replies to messages that pass the filter | account, auto_reply |
| **Discord: Greetings** | daemon | posts a good-morning / goodnight at set times, no replies | account, channels, greeting_time, goodnight_time |
| **Discord: Voice channel** | realtime | turns voice ON for the channels its filter covers | account, auto_join, keep_chat_history |

Chat filters: `mentioned`, `guild_name`, `channel_name`, `username`, `content_contains` and the
`_not` twins, plus `guild_id` / `channel_id`. Voice filters: server / channel name, their `_not`
twins, and the ids. Filters match case-insensitively; a comma list is an allowlist. A task with no
filter hears everything the bot can see.

A bot that should reply and greet gets one task of each; either task keeps it online.

**Active hours** on a Chat task (Triggers → Daemons → the task → Active hours, overnight allowed) is her
Discord day: outside the window the task skips messages, the bot stays online, and with **Presence**
on she shows the away line. Greetings are not gated by it.

## Settings (Settings → Plugins → Discord)

| Tab | What it controls |
|---|---|
| **Conversation** | reply mode, human/bot organic chance, name match, batching window, **how many channel messages the AI sees** (fetched live when she replies), natural delay (read, type, pause like a person), ignored channels, **answer any bot** or the bot allowlist |
| **Reactions** | the `[react:]` tag and silent reactions (chance, cooldown, tone engine: word list or the RoBERTa sentiment model) |
| **Safety** | DMs (off by default) and the per-person daily DM budget, tools stay in server, reply cooldown |
| **Media** | images in (the task's model sees attachments), GIFs (provider, key, filter) |
| **Voice** | turn cues, silence, addressing mode + aliases, follow-up window, barge-in hold, the voice prompt |
| **Presence** | off by default; status lines rotated while awake, the away line outside the Chat task's Active hours |
| **Debug** | recent decisions — why she answered or stayed quiet, ids only |

## Tools

`discord_get_servers`, `discord_list_channels`, `discord_read_messages`, `discord_send_message`,
`discord_send_image`, `discord_send_gif`, `discord_add_reaction`, `discord_join_voice`,
`discord_leave_voice`, `discord_remind`. Add them to the task's toolset. Inside a server event her tools reach only
that server (Safety → tools stay in server).

`discord_remind` is the whole reminders feature — in the toolset means on, out means off, no
separate switch. "Remind me in 2h to…" becomes an @mention post in that channel when due; no LLM,
survives a restart. Caps: 20 pending per person, 30 days ahead, 300 characters.

Reply tags she may use in a normal reply: `[react:🔥]` and `[gif:search words]`.

## Voice

Voice is a **Realtime** rule: **Discord: Voice channel** names the bot; its filter says which voice
channels it covers (no filter = all of them); its persona, provider, model and toolset run the
voice chat. She joins on `/voice join` or her join tool, and leaves on `<<HANG UP>>` in her reply,
`/voice leave`, or when the channel empties.

**Auto-join** is opt-in per rule (off by default). On, she walks into a covered channel when a
human is there. A channel she left on purpose is not auto-rejoined until it has emptied once.

Slash commands (registered per bot): `/voice join` (defaults to the channel you are in) and
`/voice leave`.

Voice needs TTS streaming on in Sapphire and a working DAVE stack; the log line
`[DISCORD] Voice stack:` at boot and `GET /api/plugin/discord/voice/status` say what applied.

## Add-ons

Other plugins extend the host through nine hooks fired via core's hook runner —
`discord_message_observed`, `discord_reply_decided`, `discord_prompt_context`,
`discord_reply_planned`, `discord_reply_sent`, `discord_reaction_observed`,
`discord_voice_utterance`, `discord_presence_planned`, `discord_tick` — each carrying
`metadata['api']`, a small facade (send, edit, react, typing, image, presence, join / leave
voice, recent messages, text channels). An add-on may veto a reply or claim one she was
going to skip (never past safety, the ignore list or the bot gate), append to her prompt,
reshape the outgoing chunks, retint a presence line, and sees which daemon task (and
so which memory scope) is answering. `hooks_out.py` documents the payloads. The
`discord-personality` plugin is the reference add-on; its `DESIGN-PRINCIPLES.md` is the
bar for an add-on that ships with Sapphire.

## Operator & Diagnostics

Routes under `/api/plugin/discord/`:

| Endpoint | Purpose |
|---|---|
| `GET health` | daemon state + connected accounts |
| `GET/POST accounts`, `POST accounts/test`, `DELETE accounts/{name}`, `POST accounts/{name}/test` | bot accounts |
| `GET settings` | daemon state + the built-in voice prompt default |
| `GET channels/text`, `GET voice/targets`, `GET bots/allowlist` | what the connected bots can see (pickers) |
| `GET voice/status` | live sessions, connections, the auto-join view, the voice stack |
| `GET debug/decisions`, `POST debug/clear` | the last 20 decisions (ids, stage, reason, chunks) |

See [OPERATIONS.md](OPERATIONS.md) for the runtime, storage, runbooks and recovery.

## Troubleshooting

| Problem | Things to check |
|---|---|
| **"Missing: py-cord…"** | click **Install**, or run the command shown; Git on PATH; `discord.py` not installed |
| **Settings changes do nothing** | an older copy in `user/plugins/discord` shadows the shipped plugin |
| **Bot shows disconnected** | no enabled daemon or realtime task selects it; invalid token; missing portal intents (the account row shows `last_error`) |
| **She never replies** | task exists for that bot; filters match; Reply mode allows it; Debug → Recent decisions names the stage that refused it |
| **She ignores DMs** | Safety → Allow DMs is off by default |
| **Voice join fails / "no rule covers it"** | a **Discord: Voice channel** rule for that bot whose filter covers the channel; Connect/Speak permissions |
| **Voice transcribes but silent** | TTS streaming on; addressing mode may require saying her name |
| **Bot allowlist empty** | Server Members Intent; refresh with the daemon running |
| **Reactions not working** | Add Reactions permission; Reactions → silent reactions on |
| **GIFs fail** | Media → GIF enabled + API key |
