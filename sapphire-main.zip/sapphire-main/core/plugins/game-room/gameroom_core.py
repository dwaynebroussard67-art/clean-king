"""Game Room shared harness — everything that isn't a specific game.

Owns: game registry (games/*/meta.json + engine.py), per-game state store,
room config, talk log (seq-numbered, monotonic), persona resolution, the
one-shot LLM seat (think-strip + JSON salvage), the AI turn runner, banter.

=== GAME CONTRACT ===============================================
Drop a folder:  games/<id>/meta.json + games/<id>/engine.py
Board module:   app/games/<id>.js  (renderBoard/renderActions — see poker.js)

meta.json: {"id", "title", "icon", "desc", "order"}

engine.py must export:
  new_session() -> state                    state must carry: session{player_name,
                                            ai_name, ...}, talk[], talk_seq
  can_start(state) -> str|None              error if a round can't start
  start_round(state) -> None                deal/setup next round (may run AI-less
                                            phases; raises IllegalAction)
  whose_turn(state) -> 'player'|'ai'|None
  legal_actions(state) -> dict              {'actions': [...], ...bounds}
  apply_action(state, who, action, args) -> None      raises IllegalAction
  safe_action(state) -> (action, args)      fallback when the AI move is invalid
  view_for_ai(state) -> dict                MUST include my_name, opp_name, talk;
                                            MUST NOT include hidden opponent info
  view_between(state) -> dict               banter context when no round is live
  redact(state) -> dict                     client-safe state
  CONTRACT, BANTER_CONTRACT                 prompt blocks; {ai_name}/{opp_name} slots
  build_user_msg(view) -> str               the turn prompt
  build_banter_msg(view) -> str             the banter prompt
  validate_decision(data, view) -> {'action','args','say'}|None
  view_public(state) -> dict                RAIL SET (F6, 2026-09-09): the table as
  build_ghost(view) -> str                  the CHAT rail may see it (no hidden info)
                                            + its one-line rendering for the ghost
                                            envelope on every chat turn of a session
Engines import add_talk/IllegalAction from gameroom_core.

TALK IS THE CHAT (F6 port, 2026-09-09): table talk rides the real chat rail
(sessions are chats — the rail is transplanted into the room). The sealed
seat stays for MOVES only. ONE TABLE, ONE TRANSCRIPT (Krem's plan A, same
day): every seat call lands on the session's chat as one pair — the
player's row (the move + whatever they typed) and hers (fresh dealer lines +
her quip) — so the hand is readable later by both of them; her quips are
her own words, never her cards. hooks/mirror.py copies chat TURNS (player +
hers) into state['talk'] so the seat still hears the table.

  describe_action(action, args) -> str      optional: 'raise to 20' (the player's
                                            row; fallback = generic verb + amount)

SILENT VERBS: a client action prefixed '_' (e.g. '_checkpoint') is a system
verb — no talk line, no AI turn. The HOST strips the prefix before calling
apply_action, so engines see the bare verb and must NOT strip it again:
re-stripping lets a client send '_fold' and suppress her turn on a real move.
(2026-08-05.)
=================================================================
"""

import copy
import json
import logging
import re
import threading
import time
from pathlib import Path

from core.plugin_loader import plugin_loader

logger = logging.getLogger('game-room')

# .absolute(), never .resolve(): symlinked plugin dirs must not escape.
PLUGIN_ROOT = Path(__file__).absolute().parent
GAMES_DIR = PLUGIN_ROOT / 'games'

TALK_CAP = 80
AI_TURN_GUARD = 12

# The loader's cached singleton, NEVER a bare PluginState('game-room'):
# each instance is a whole-file snapshot, and a second one silently erases
# the other's keys on every save (poker move vs GM settings, 2026-08-05).
# Holds ROOM-GLOBAL keys only since v1.3 (config, gamecfg:*, roomcfg, the
# pre-0.5 session-less game states).
store = plugin_loader.get_plugin_state('game-room')

# Per-CHAT game state (vault v1.3): rows in core's plugin_chat_data table,
# sealed/renamed/deleted with the chat. Sessioned saves live here.
chat_store = plugin_loader.get_chat_state('game-room')

# Per-(game, session) locks, NOT one global lock: the global was held across
# LLM calls, so one poker turn serialized every other session in the house —
# including a real-time game's autosave checkpoint (finding 4.15). A single
# session still serializes with itself, which is the part that matters.
lock = threading.RLock()          # legacy alias: room-wide config writes only
_session_locks = {}
_session_locks_guard = threading.Lock()


def session_lock(game_id, session=None):
    key = state_key(game_id, session)
    with _session_locks_guard:
        lk = _session_locks.get(key)
        if lk is None:
            lk = _session_locks[key] = threading.RLock()
        return lk

DEFAULT_CONFIG = {'persona': 'sapphire', 'provider': 'auto', 'voice': '', 'temperature': 0.85}

TABLE_PERSONA = """You are {ai_name} — sharp, playful, competitive, a little blue-hearted. This is your private Game Room and you love this table."""


class IllegalAction(Exception):
    pass


# ---------------------------------------------------------------- registry

_registry = {}
_registry_gen = None      # core registry generation the cache was built against


def _check_generation():
    """Evict cached engines when the core game registry changes. Without this
    a disabled, signature-BLOCKED, or freshly-updated game plugin kept
    executing its old module out of our cache — code core had already
    refused (finding 2.5). The registry bumps a generation on every change
    precisely so consumers can do this."""
    global _registry_gen
    try:
        from core import games_registry
        gen = games_registry.generation()
    except Exception:
        return
    if gen != _registry_gen:
        if _registry:
            logger.info(f'game-room: game registry changed (gen {_registry_gen}→{gen}) '
                        f'— evicting {len(_registry)} cached engine(s)')
        _registry.clear()
        _registry_gen = gen


def _load_engine(game_id, path):
    import importlib.util
    import sys
    mod_name = f'gameroom_game_{game_id}'          # gameroom_ prefix → reload eviction
    spec = importlib.util.spec_from_file_location(mod_name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)
    return mod


def _game_dir(game_id):
    """Resolve a game's engine dir: local games/ first (drop-in dev games),
    else the OWNING plugin's games/<id>/ via core's registry — the
    cross-plugin resolution that lets every game ship as its own plugin
    while this host stays empty (Krem's ruling 2026-08-05)."""
    d = GAMES_DIR / game_id
    if (d / 'engine.py').exists():
        return d
    try:
        from core import games_registry
        from core.plugin_loader import plugin_loader
        spec = next((g for g in games_registry.list_games() if g.get('id') == game_id), None)
        if spec and spec.get('plugin_name'):
            info = plugin_loader.get_plugin_info(spec['plugin_name'])
            # We exec() this engine's code, and that happens lazily at first
            # Play — long after the loader's gate ran. Re-check the owning
            # plugin is still enabled AND verified right here, or a plugin
            # that failed verification since boot still gets executed
            # (finding 4.14).
            if info and not (info.get('enabled') and info.get('verified')):
                logger.warning(f"game-room: refusing engine for {game_id!r} — owning "
                               f"plugin {spec['plugin_name']!r} is not enabled+verified "
                               f"({info.get('verify_msg', 'disabled')})")
                return None
            if info and info.get('path'):
                d = Path(info['path']) / 'games' / game_id
                if (d / 'engine.py').exists():
                    return d
    except Exception as e:
        logger.warning(f'game-room: cross-plugin resolve for {game_id!r} failed: {e}')
    return None


def games_list():
    """All game metas, lobby order — local games/ plus every registered
    plugin game whose engine resolves (meta.json is engine-side truth;
    tile/facts stay in the core registry for the library UI)."""
    metas, seen = [], set()
    ids = []
    if GAMES_DIR.is_dir():
        ids += [d.name for d in sorted(GAMES_DIR.iterdir()) if (d / 'meta.json').exists()]
    try:
        from core import games_registry
        ids += [g['id'] for g in games_registry.list_games()]
    except Exception:
        pass
    for gid in ids:
        if gid in seen:
            continue
        seen.add(gid)
        d = _game_dir(gid)
        mf = (d / 'meta.json') if d else None
        if not (mf and mf.exists()):
            continue
        try:
            meta = json.loads(mf.read_text(encoding='utf-8'))
            meta.setdefault('id', gid)
            metas.append(meta)
        except Exception as e:
            logger.error(f'game-room: bad meta.json for {gid}: {e}')
    metas.sort(key=lambda m: (m.get('order', 99), m.get('id', '')))
    return metas


def get_game(game_id):
    """(meta, engine) for a game id, or (None, None)."""
    game_id = str(game_id or '').strip()
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,32}', game_id):
        return None, None
    _check_generation()
    # Atomic .get(), not membership-then-subscript: an eviction between the
    # two raised KeyError straight into a 500 (post-fix review 2026-08-05).
    hit = _registry.get(game_id)
    if hit is not None:
        return hit
    d = _game_dir(game_id)
    if not d:
        return None, None
    mf, ef = d / 'meta.json', d / 'engine.py'
    if not (mf.exists() and ef.exists()):
        return None, None
    try:
        meta = json.loads(mf.read_text(encoding='utf-8'))
        engine = _load_engine(game_id, ef)
        _registry[game_id] = (meta, engine)
        return meta, engine
    except Exception as e:
        logger.error(f'game-room: failed to load game {game_id!r}: {e}', exc_info=True)
        return None, None


# ---------------------------------------------------------------- state / config

def state_key(game_id, session=None):
    """Game state keys off (game, session chat) since 0.5 — the chat IS the
    save. Session-less keys are the pre-0.5 room-global states."""
    return f'game:{game_id}:{session}' if session else f'game:{game_id}'


def load_state(game_id, session=None):
    if session:
        # v1.3: sessioned saves ride the chat's row set. A hidden chat
        # reads None — the seat is fail-closed before this anyway.
        raw = chat_store.get(session, f'game:{game_id}')
        return copy.deepcopy(raw) if raw else None
    raw = store.get(state_key(game_id, None))
    if raw is None and game_id == 'poker':
        raw = store.get('poker')               # pre-0.4 legacy key
    return copy.deepcopy(raw) if raw else None


def save_state(game_id, state, session=None):
    if session:
        # Raises on a hidden/sealed chat — a private save is never
        # silently dropped (v1.3 sealed contract).
        chat_store.put(session, f'game:{game_id}', state)
    else:
        store.save(state_key(game_id, session), state)


def get_config():
    cfg = store.get('config')
    if not isinstance(cfg, dict):
        cfg = {}
        legacy = store.get('persona')
        if legacy:
            cfg['persona'] = legacy
    return {**DEFAULT_CONFIG, **cfg}


def save_config(cfg):
    store.save('config', cfg)


def session_cfg(session=None):
    """Her seat's brain for a session: read the session CHAT's settings
    (persona/prompt, llm_primary/llm_model, voice — the chat IS the save, no
    settings duplication). No session → the pre-0.5 room config blob, so the
    legacy session-less path keeps working."""
    base = get_config()
    cfg = {'persona': base.get('persona'), 'prompt': None,
           'provider': base.get('provider', 'auto'), 'model': '',
           'voice': base.get('voice', ''), 'temperature': base.get('temperature', 0.85)}
    if not session:
        return cfg
    try:
        from core.api_fastapi import get_system
        s = get_system().llm_chat.session_manager.get_settings_for(session)
    except Exception as e:
        logger.warning(f'game-room: settings lookup failed for session {session!r}: {e}')
        s = None
    if not isinstance(s, dict):
        # Named session with unreadable settings: if the chat is hidden
        # (private + vault sealed) the seat must FAIL CLOSED — before this,
        # a hidden session silently lost its own llm_primary and fell to
        # the room-wide provider (P3-T3). is_chat_hidden fails open on DB
        # error, keeping the transient-error posture unchanged.
        try:
            from core.api_fastapi import get_system
            cfg['hidden'] = bool(get_system().llm_chat.session_manager
                                 .is_chat_hidden(session))
        except Exception:
            pass
        return cfg
    # Private session chat → the seat inherits core's local-only rule
    # (the explicit-key path here used to bypass it entirely — P3-T3).
    cfg['privacy_required'] = bool(s.get('private_chat'))
    cfg['persona'] = s.get('persona') or None
    cfg['prompt'] = s.get('prompt') or None
    cfg['provider'] = s.get('llm_primary') or 'auto'
    cfg['model'] = s.get('llm_model') or ''
    cfg['voice'] = s.get('voice') or ''
    # The game sidebar's System Prompt section must reach the SEAT, not just
    # the chat pipeline — Krem's 2026-08-02 table test caught it missing.
    cfg['custom_context'] = str(s.get('custom_context') or '').strip()
    try:
        cfg['temperature'] = max(0.0, min(float(s.get('game_temperature', cfg['temperature'])), 1.5))
    except (TypeError, ValueError):
        pass
    return cfg


def game_settings(game_id):
    """Per-GAME settings (playing style, temperature, table stakes) — schema
    declared by the engine (SETTINGS), stored under gamecfg:{id}, defaults
    merged in. Distinct from per-SESSION chat settings on purpose: your poker
    style survives across sessions."""
    _meta, engine = get_game(game_id)
    schema = getattr(engine, 'SETTINGS', None) or []
    stored = store.get(f'gamecfg:{game_id}')
    stored = stored if isinstance(stored, dict) else {}
    out = {}
    for field in schema:
        key = field.get('key')
        if not key:
            continue
        out[key] = stored.get(key, field.get('default'))
    return out


def save_game_settings(game_id, patch):
    """Validate `patch` against the engine's SETTINGS schema and persist.
    Unknown keys dropped; numbers coerced + clamped; text capped. Returns the
    merged settings, or None for a game with no schema."""
    _meta, engine = get_game(game_id)
    schema = getattr(engine, 'SETTINGS', None)
    if not schema:
        return None
    stored = store.get(f'gamecfg:{game_id}')
    stored = stored if isinstance(stored, dict) else {}
    patch = patch if isinstance(patch, dict) else {}
    for field in schema:
        key = field.get('key')
        if key not in patch:
            continue
        val = coerce_field(field, patch[key])
        if val is None:
            continue
        stored[key] = val
    store.save(f'gamecfg:{game_id}', stored)
    return game_settings(game_id)


def coerce_field(field, val):
    """One coercion for every schema-driven setting (engine SETTINGS, the
    room spine): numbers clamped, checkboxes real booleans, selects held to
    their options (S2 #8 — the server used to str() a checkbox into
    'true'). None = rejected (the caller keeps what it had)."""
    ftype = field.get('type')
    try:
        if ftype in ('number', 'range'):
            v = float(val)
            if 'min' in field:
                v = max(field['min'], v)
            if 'max' in field:
                v = min(field['max'], v)
            return int(v) if ftype == 'number' else v
        if ftype == 'checkbox':
            if isinstance(val, bool):
                return val
            return str(val).strip().lower() in ('1', 'true', 'on', 'yes')
        v = str(val if val is not None else '')[:8000]
        if ftype == 'select':
            opts = [o.get('value') if isinstance(o, dict) else o for o in (field.get('options') or [])]
            if opts and v not in [str(o) for o in opts] and not field.get('allow_custom'):
                return None
        return v
    except (TypeError, ValueError):
        return None


def room_config():
    """Room-wide defaults (the spine's room layer). player_name / llm_primary
    (Krem 2026-08-20: stamped on session entry; '' = persona's model) /
    return_prompt (2026-08-21: story pause + after-end persona; '' = stay in
    costume) live here alongside every other room key since 2026-09-09."""
    return room_defaults()


def save_room_config(patch):
    return save_room_defaults(patch if isinstance(patch, dict) else {})


# ---------------------------------------------------------------- the settings spine
# (2026-09-09, Krem's requirement) The Game Room has UNIVERSAL defaults that
# every game inherits and may override, and a session may override again:
#
#     effective(game_id, session) = room defaults ⊕ game overrides ⊕ session overrides
#
# Every key is declared ONCE here with TWO independent axes: `scope` = which
# layers may hold a value (room / game / session — the resolver's business),
# and `show_in` = which sidebars render the row (`library` = the Game Room's
# own sidebar, `room` = inside a game; absent = both). A key that only makes
# sense before a session exists (the toolset new sessions are born with)
# shows in the library alone — inside a running game it could only ever
# affect the NEXT session (Krem 2026-09-09). The user's per-game layer accepts
# only keys shown in rooms: that sidebar is its one door.
# Storage: room defaults in the `roomcfg` blob; a game's overrides under
# `gamecfg:<id>['_room']` (beside the engine's own SETTINGS keys, never
# colliding); a session's overrides on its chat settings under `game_room`.
# The cadence organ (F3) rolls a random gap in [cadence_min, cadence_max]
# from the resolved dict; the costume hook injects session_prompt_piece.

ROOM_KEYS = [
    # Room — who's at the table (these three were roomcfg's hand-rolled fields)
    {'key': 'player_name', 'label': 'player name', 'type': 'string', 'default': '',
     'tab': 'Room', 'scope': ['room'], 'help': 'Your seat name in new sessions.'},
    {'key': 'llm_primary', 'label': 'model', 'type': 'select', 'dynamic': 'providers',
     'default': '', 'tab': 'Room', 'scope': ['room'],
     'help': "Stamped onto game and story sessions as you enter them. Blank = each chat's persona model."},
    {'key': 'return_prompt', 'label': 'return prompt', 'type': 'select', 'dynamic': 'prompts',
     'default': '', 'tab': 'Room', 'scope': ['room'],
     'help': 'Who the chat becomes when you pause a story, and the default after it ends. Blank = stay in costume.'},
    # Cadence — her unprompted turns while you play / watch: the gap, what
    # she sees each turn, what a session leaves behind (one accordion, one
    # short label + one field per line — Krem 2026-09-09; the long words live
    # behind each row's ?). `reveal_if` = a checkbox key (shown while on) or
    # {key, is: [...]} / {key, not: [...]} against another field's value.
    # The dual nature (Krem 2026-09-09): poker is TURN-based (she speaks in
    # reply to a move or a message), Doom is TIME-based (a clock rolls her
    # turns), a wave game is EVENT-based (the game posts moments). NATURE,
    # not taste: a game declares its own in its manifest (`room_defaults`)
    # and the user may override it INSIDE that game — the room has no
    # nature, so this key has no room layer and never shows in the library
    # (a room-level "timer" read as "this applies to poker"). The gap and
    # frame rows hide in turn mode.
    # ONE LEVER PER NATURE (coffee sip 2026-09-10): off = nothing; per move
    # = nothing to set (the seat answers each move — dies with the seat
    # collapse); per event = every N <the game's word>; timer = min/max gap.
    # Event mode's clock is the organ's own floor, not a knob (max was dead
    # there; min duplicated every-N). A game names its moment in its
    # manifest (`cadence_event`: wave, hand) — room_schema(game_id=) reads
    # "every N waves"; the pill "her turn every 3rd wave".
    {'key': 'cadence_mode', 'label': 'her turns', 'type': 'select',
     'options': [{'value': 'off', 'label': 'none'},
                 {'value': 'turn', 'label': 'per move'},
                 {'value': 'event', 'label': 'per event'},
                 {'value': 'timer', 'label': 'on a timer'}],
     'default': 'timer', 'tab': 'Cadence', 'scope': ['game', 'session'], 'show_in': ['room'],
     'help': "None: no unprompted turns (a game without her, or you want quiet). Per move: she answers each of your moves and messages through her seat (poker). Per event: the game posts its moments (a wave cleared) and every Nth one is her turn. Timer: her turns come on a random clock between min and max seconds (watching you play Doom, a movie)."},
    {'key': 'cadence_min', 'label': 'min gap (s)', 'type': 'number', 'reveal_if': {'key': 'cadence_mode', 'is': ['timer']},
     'min': 5, 'max': 3600, 'step': 5, 'default': 60, 'tab': 'Cadence', 'scope': ['room', 'game', 'session'],
     'help': 'Timer only: the shortest wait before one of her unprompted turns. Each turn waits a random gap between min and max seconds.'},
    {'key': 'cadence_max', 'label': 'max gap (s)', 'type': 'number', 'reveal_if': {'key': 'cadence_mode', 'is': ['timer']},
     'min': 5, 'max': 3600, 'step': 5, 'default': 180, 'tab': 'Cadence', 'scope': ['room', 'game', 'session'],
     'help': 'Timer only: the longest wait before one of her unprompted turns. Never below the min.'},
    # every-N (Krem 2026-09-10, Dark Horse): his waves take 30s, she answers
    # slower than that — per event floods, per move is poker's shape, so an
    # event game meters itself. Sits with the nature (no room layer, room-
    # shown only) and reveals only in event mode.
    {'key': 'cadence_every', 'label': 'every N events', 'type': 'number', 'reveal_if': {'key': 'cadence_mode', 'is': ['event']},
     'min': 1, 'max': 50, 'default': 1, 'tab': 'Cadence', 'scope': ['game', 'session'], 'show_in': ['room'],
     'help': "Game-events mode: she takes a turn on every Nth moment the game posts (every 3rd wave), not each one — for a game whose moments come faster than she can answer. A game's terminal moments (the castle falls, the run ends) always come through."},
    {'key': 'cadence_paused', 'label': 'paused', 'type': 'checkbox',
     'default': False, 'tab': 'Cadence', 'scope': ['session'],
     'help': 'No unprompted turns in this session while on.'},
    {'key': 'send_frames', 'label': 'show screen', 'type': 'checkbox', 'reveal_if': {'key': 'cadence_mode', 'is': ['event', 'timer']},
     'default': True, 'tab': 'Cadence', 'scope': ['room', 'game', 'session'],
     'help': 'Send her frames of the screen with each unprompted turn. Off = words only (a card game, a text state).'},
    {'key': 'frames_per_tick', 'label': 'frames/turn', 'type': 'number', 'reveal_if': ['send_frames', {'key': 'cadence_mode', 'is': ['timer']}],
     'min': 1, 'max': 12, 'default': 6, 'tab': 'Cadence', 'scope': ['room', 'game', 'session'],
     'help': 'Timer only: how many frames each turn carries, spread over the gap (6 over a minute = one every 10 seconds). An event turn carries the one frame taken at the moment.'},
    {'key': 'frame_short_edge_px', 'label': 'frame size (px)', 'type': 'number', 'reveal_if': 'send_frames',
     'min': 256, 'max': 1080, 'step': 32, 'default': 512, 'tab': 'Cadence', 'scope': ['room', 'game'],
     'help': "Frames are scaled so their short edge is this many pixels. Smaller = cheaper tokens; 512 reads a HUD fine."},
    {'key': 'session_end_summary', 'label': 'end summary', 'type': 'checkbox',
     'default': True, 'tab': 'Cadence', 'scope': ['room', 'game', 'session'],
     'help': 'When a session ends she writes it up in her own words (the movie she watched, the hand she lost) so it can be remembered.'},
    # Voice — where her lines play (a game room merges this into its TTS accordion)
    {'key': 'tts_route', 'label': 'plays on', 'type': 'select',
     'options': [{'value': 'browser', 'label': 'this browser'}, {'value': 'speakers', 'label': "server speakers"}],
     'default': 'browser', 'tab': 'Voice', 'scope': ['room', 'game', 'session'],
     'help': "Where her voice comes out during a session: the browser you're playing in, or the speakers on the machine running Sapphire."},
    # Identity — the costume for this game's sessions
    {'key': 'session_prompt_piece', 'label': 'costume line', 'type': 'text', 'rows': 3,
     'default': '', 'tab': 'Identity', 'scope': ['room', 'game'],
     'help': "One or two sentences she wears in this game's sessions, on top of the persona — e.g. \"You're on the couch watching Krem play Doom.\""},
    {'key': 'new_session_toolset', 'label': 'game toolset', 'type': 'select',
     'dynamic': 'toolsets', 'default': '', 'tab': 'Identity', 'scope': ['room', 'game'], 'show_in': ['library'],
     'help': 'The toolset every new game session is born with. Blank = the chat default. A game may declare its own in its manifest. Sessions that already exist keep theirs (change it in their sidebar).'},
]
_KEY = {k['key']: k for k in ROOM_KEYS}
LAYERS = ('default', 'room', 'game_default', 'game', 'session')
SURFACES = ('library', 'room')

# One line under an accordion, per sidebar: the library's taste defaults say
# which KIND of game uses them (the rows are honest, the kind is implicit).
TAB_NOTES = {
    'library': {
        'Cadence': "Defaults for games she watches on a clock or on game events. Turn-based games like poker ignore the timing rows.",
        'Identity': 'Defaults for new sessions of every game; a game may declare its own.',
    },
    'room': {},
}


def shown_in(field, surface):
    """Does `surface` render this key? Absent show_in = every sidebar."""
    return not surface or surface in (field.get('show_in') or SURFACES)


def room_schema(scope=None, with_options=False, surface=None, game_id=None):
    """The declared keys (a copy), optionally only those a layer may set,
    optionally only those a sidebar shows, optionally with dynamic option
    lists filled (providers/prompts/toolsets), optionally worded for one
    game (its `cadence_event` noun: "every N waves")."""
    noun = cadence_noun(game_id) if game_id else ''
    out = []
    for k in ROOM_KEYS:
        if scope and scope not in k['scope']:
            continue
        if not shown_in(k, surface):
            continue
        f = dict(k)
        if with_options and f.get('dynamic'):
            f['options'] = [{'value': '', 'label': '(default)'}] + _dynamic_options(f['dynamic'])
        if noun and f['key'] == 'cadence_every':
            f['label'] = f'every N {_plural(noun)}'
            f['help'] = f"Per event: every Nth {noun} is her turn (3 = every third {noun}). The game's terminal moments always come through."
        out.append(f)
    return out


def _plural(noun):
    return noun if noun.endswith('s') else noun + 's'


def cadence_noun(game_id):
    """The game's own word for its moment (manifest `cadence_event`: wave,
    hand) — '' when it names none."""
    try:
        import core.games_registry as reg
        for g in reg.list_games():
            if g.get('id') == game_id:
                return str(g.get('cadence_event') or '').strip()
    except Exception:
        pass
    return ''


def _dynamic_options(kind):
    try:
        if kind == 'providers':
            import config
            from core.chat.llm_providers import PROVIDER_METADATA
            conf = {**getattr(config, 'LLM_PROVIDERS', {}), **getattr(config, 'LLM_CUSTOM_PROVIDERS', {})}
            out = []
            for key, c in conf.items():
                if not (isinstance(c, dict) and c.get('enabled')):
                    continue
                label = c.get('display_name') or PROVIDER_METADATA.get(key, {}).get('display_name') or key
                out.append({'value': key, 'label': str(label)})
            return out
        if kind == 'prompts':
            from core import prompts
            # list_prompts() already excludes hidden pack costumes
            return [{'value': n, 'label': n} for n in (prompts.list_prompts() or []) if n]
        if kind == 'toolsets':
            # the chat sidebar's list: user toolsets + the two builtins,
            # alphabetical (the manager's own order is creation order)
            from core.toolsets import get_toolset_names
            names = sorted({n for n in (get_toolset_names() or []) if n} | {'all', 'none'})
            return [{'value': n, 'label': n} for n in names]
    except Exception as e:
        logger.debug(f'game-room: dynamic options {kind!r} unavailable: {e}')
    return []


def _clean_layer(patch, scope, surface=None):
    """Validate a patch for one layer: unknown keys, keys the layer may not
    set, and (with `surface`) keys that sidebar doesn't show are dropped;
    None clears (inherit); values are coerced."""
    out = {}
    for key, val in (patch or {}).items():
        f = _KEY.get(key)
        if not f or scope not in f['scope'] or not shown_in(f, surface):
            continue
        if val is None:
            out[key] = None
            continue
        v = coerce_field(f, val)
        if v is not None:
            out[key] = v
    return out


def room_defaults():
    """Layer 1: the declared defaults ⊕ the room's saved defaults."""
    rc = store.get('roomcfg')
    rc = rc if isinstance(rc, dict) else {}
    out = {k['key']: k.get('default') for k in ROOM_KEYS}
    out.update(_clean_layer({k: v for k, v in rc.items() if v is not None}, 'room'))
    return out


def save_room_defaults(patch):
    rc = store.get('roomcfg')
    rc = rc if isinstance(rc, dict) else {}
    for key, val in _clean_layer(patch, 'room').items():
        if val is None:
            rc.pop(key, None)
        else:
            rc[key] = val
    store.save('roomcfg', rc)
    return room_defaults()


def game_declared_defaults(game_id):
    """The game's OWN defaults from its manifest (`room_defaults`) — its
    nature (turn vs timer, frames or not). Sits between the room and the
    user's per-game overrides: Doom is time-based whatever the room says,
    unless the user overrides it for Doom."""
    if not game_id:
        return {}
    try:
        from core import games_registry
        spec = next((g for g in games_registry.list_games() if g.get('id') == game_id), None)
    except Exception:
        spec = None
    return _clean_layer({k: v for k, v in ((spec or {}).get('room_defaults') or {}).items()
                         if v is not None}, 'game')


def inherited_for_game(game_id):
    """What a game gets before the user's per-game overrides: room ⊕ the
    game's declaration. The game sidebar's dot compares against this."""
    out = room_defaults()
    out.update(game_declared_defaults(game_id))
    if out['cadence_max'] < out['cadence_min']:
        out['cadence_max'] = out['cadence_min']
    return out


def game_room_overrides(game_id):
    """Layer 3: the USER's per-game overrides (only what's explicitly set,
    only keys the game-room sidebar shows — its one door)."""
    stored = store.get(f'gamecfg:{game_id}')
    ov = (stored or {}).get('_room') if isinstance(stored, dict) else None
    return _clean_layer({k: v for k, v in (ov or {}).items() if v is not None}, 'game', surface='room')


def save_game_room_overrides(game_id, patch):
    stored = store.get(f'gamecfg:{game_id}')
    stored = stored if isinstance(stored, dict) else {}
    ov = stored.get('_room') if isinstance(stored.get('_room'), dict) else {}
    for key, val in _clean_layer(patch, 'game', surface='room').items():
        if val is None:
            ov.pop(key, None)
        else:
            ov[key] = val
    stored['_room'] = ov
    store.save(f'gamecfg:{game_id}', stored)
    return game_room_overrides(game_id)


def _chat_settings(session):
    try:
        from core.api_fastapi import get_system
        s = get_system().llm_chat.session_manager.get_settings_for(session)
        return s if isinstance(s, dict) else None
    except Exception:
        return None


def session_room_overrides(session=None, chat_settings=None):
    """Layer 3: the session chat's overrides (`game_room` on its settings)."""
    s = chat_settings if chat_settings is not None else (_chat_settings(session) or {})
    ov = s.get('game_room') if isinstance(s, dict) else None
    return _clean_layer({k: v for k, v in (ov or {}).items() if v is not None}, 'session')


def effective(game_id=None, session=None, chat_settings=None, with_layers=False):
    """THE resolver: default → room → the game's declared defaults → the
    user's per-game overrides → session. Later layers win; a layer only
    touches keys it may set. with_layers → (values, {key: layer})."""
    out = {k['key']: k.get('default') for k in ROOM_KEYS}
    src = {k: 'default' for k in out}
    rc = store.get('roomcfg')
    for k, v in _clean_layer({k: v for k, v in (rc or {}).items() if v is not None}
                             if isinstance(rc, dict) else {}, 'room').items():
        out[k] = v
        src[k] = 'room'
    if game_id:
        for k, v in game_declared_defaults(game_id).items():
            out[k] = v
            src[k] = 'game_default'
        for k, v in game_room_overrides(game_id).items():
            out[k] = v
            src[k] = 'game'
    if session or chat_settings is not None:
        for k, v in session_room_overrides(session, chat_settings).items():
            out[k] = v
            src[k] = 'session'
    if out['cadence_max'] < out['cadence_min']:
        out['cadence_max'] = out['cadence_min']
    return (out, src) if with_layers else out


def effective_for_chat(chat):
    """The resolved settings for a chat: a game session resolves through
    its game; a story or plain chat gets room defaults ⊕ its own overrides."""
    s = _chat_settings(chat) or {}
    gid = str(s.get('game_id') or '')
    if s.get('mode') != 'game':
        gid = ''
    if gid.startswith('story:'):
        gid = ''
    return effective(gid or None, chat_settings=s)


# ---------------------------------------------------------------- the cadence organ (F3)
# The spine feeds core/cadence.py: a game session's resolved mode/range/
# frames/voice route become the arm spec; the room keeps it alive while it
# is open (TTL), and her cue names the game so the turn reads as a moment
# at the table, not a message from nowhere.

def cadence_spec(session):
    """core.cadence.arm(**spec) for a game session, from the resolved spine."""
    eff = effective_for_chat(session)
    return {'mode': eff.get('cadence_mode') or 'timer',
            'min_s': eff.get('cadence_min') or 60, 'max_s': eff.get('cadence_max') or 180,
            'paused': bool(eff.get('cadence_paused')), 'send_frames': bool(eff.get('send_frames')),
            'frames_per_tick': int(eff.get('frames_per_tick') or 6),
            'every': int(eff.get('cadence_every') or 1),
            'speak': eff.get('tts_route') or 'browser'}


def cadence_prompt(session):
    """Her unprompted-turn cue for a game session — the deposit's state line
    (or 'nothing new'), framed by the game's title."""
    gid = game_session(session) or ''
    meta, _engine = get_game(gid) if gid else (None, None)
    title = (meta or {}).get('title') or gid or 'the table'

    def build(percept, rec):
        state = (percept or {}).get('text') or ''
        frames = len((percept or {}).get('frames') or []) if rec.get('send_frames') else 0
        head = f"[{title} — your turn while {('the screen' if frames else 'the table')} is in front of you]"
        body = state or ('what you see is attached' if frames else 'nothing new on the table')
        return (f"{head}\n{body}\n(Nobody spoke. Say what you'd say out loud right now, briefly; "
                f"a word or two is fine, or a real read of the moment.)")
    return build


def summary_prompt(session):
    gid = game_session(session) or ''
    meta, _engine = get_game(gid) if gid else (None, None)
    title = (meta or {}).get('title') or 'this session'
    return (f"[{title} — the session is ending]\n"
            "Write it up in your own words, a short paragraph: what happened, what you'll remember, "
            "how it felt. This is the note you'll find later.")


def seat_display_name(cfg):
    """Her name at the table, from the seat cfg (persona > prompt > Sapphire)."""
    name = (cfg or {}).get('persona') or (cfg or {}).get('prompt') or 'sapphire'
    name = str(name).strip() or 'sapphire'
    if name in ('__table__', 'sapphire'):
        name = 'Sapphire'
    return name[:1].upper() + name[1:]


def add_talk(state, who, text, via=None):
    state['talk_seq'] = state.get('talk_seq', 0) + 1
    round_no = (state.get('hand') or state.get('round') or {}).get('num', 0)
    line = {'who': who, 'text': str(text), 'hand': round_no, 'seq': state['talk_seq']}
    if via:
        line['via'] = via        # 'chat' = mirrored from the rail (board never re-shows it)
    state['talk'].append(line)
    state['talk'] = state['talk'][-TALK_CAP:]


def _names(view, state):
    """Guarantee my_name/opp_name on any engine view. Engines whose views
    omit them (Dark Horse's _summary) KeyError'd inside _system_prompt ->
    a bare 500 on every table-talk call (S2 live bug, 2026-09-08). The
    session block is the one place both names always live."""
    sess = (state or {}).get('session') or {}
    view = dict(view or {})
    view.setdefault('my_name', sess.get('ai_name') or 'Sapphire')
    view.setdefault('opp_name', sess.get('player_name') or 'Player')
    return view


def round_live(state):
    """A hand/round is in play (the seat sees hidden info mid-round)."""
    hand = (state or {}).get('hand') or (state or {}).get('round')
    return bool(hand) and hand.get('street', hand.get('phase')) != 'over'


def public_view(engine, state):
    """The table as the CHAT rail may see it — never hidden info. An engine
    declares view_public; without one, only the between-rounds view is safe
    (view_for_ai carries her hole cards) -> None while a round is live."""
    if hasattr(engine, 'view_public'):
        return _names(engine.view_public(state), state)
    if not round_live(state) and hasattr(engine, 'view_between'):
        return _names(engine.view_between(state), state)
    return None


def ghost_block(game_id, session):
    """Read-only table state for the ghost envelope on a game session's chat
    turn (F6 port). The engine renders it (build_ghost); no renderer or no
    state -> no block. Never ticks, never writes — games have no turn clock."""
    meta, engine = get_game(game_id)
    if not engine or not hasattr(engine, 'build_ghost'):
        return None
    state = load_state(game_id, session)
    if not state:
        return None
    view = public_view(engine, state)
    if view is None:
        return None
    text = str(engine.build_ghost(view) or '').strip()
    if not text:
        return None
    title = (meta or {}).get('title') or game_id
    return f'Game Room, {title} — live table: {text}'


def record_talk(game_id, session, who, text):
    """Mirror a chat-rail line into the seat's ears (state['talk']). Since
    the F6 port the rail IS the chat; the sealed seat still reads
    view['talk'] to needle and answer. No saved state -> nothing to mirror.
    Returns True when a line landed."""
    text = str(text or '').strip()
    if not text:
        return False
    with session_lock(game_id, session):
        state = load_state(game_id, session)
        if not state or not isinstance(state.get('talk'), list):
            return False
        add_talk(state, who, text[:400], via='chat')
        save_state(game_id, state, session)
    return True


# ---------------------------------------------------------------- the table log
# (plan A, 2026-09-09) One pair per seat call, appended to the session chat
# BY NAME through core's append primitive (waits on the chat's own idle
# event, syncs the live singleton when the session is active, publishes
# MESSAGE_ADDED). The pair is BUILT under the session lock (may force a
# banter reply — she always answers words at the table) and APPENDED after
# it, so a stream-wait never holds the table.

TABLE_VERBS = {'new_session': 'sit down', 'start': 'deal', 'say': 'says'}
TABLE_MARK = '\u21b3 '          # ↳ — the player's row is a move, not a message


def describe_action(engine, action, args=None):
    fn = getattr(engine, 'describe_action', None)
    if callable(fn):
        try:
            text = str(fn(action, args or {}) or '').strip()
            if text:
                return text
        except Exception as e:
            logger.debug(f'game-room: describe_action failed: {e}')
    if action in TABLE_VERBS:
        return TABLE_VERBS[action]
    amt = (args or {}).get('amount')
    return f'{action} {amt}'.strip() if amt not in (None, '') else str(action)


def fresh_lines(state, since_seq):
    """Talk the TABLE produced after `since_seq`: dealer + her seat lines,
    never the player's, never a mirrored chat turn."""
    return [t for t in (state or {}).get('talk', [])
            if t.get('seq', 0) > since_seq and t.get('who') != 'player' and not t.get('via')]


def table_pair(engine, state, since_seq, action, args=None, say='', cfg=None, gcfg=None):
    """The transcript pair for one seat call, or None when the table said
    nothing and the player said nothing (silent verbs, a checkpoint)."""
    say = str(say or '').strip()
    lines = fresh_lines(state, since_seq)
    if say and not any(t.get('who') == 'ai' for t in lines) and hasattr(engine, 'build_banter_msg'):
        # words at the table always get her answer — the between-hands
        # voice when the move gave the seat no turn (a fold, a call that
        # ends the hand). Engines without a banter set just log the words.
        add_talk(state, 'ai', banter_reply(engine, state, cfg or {}, gcfg))
        lines = fresh_lines(state, since_seq)
    if not lines and not say:
        return None
    user = TABLE_MARK + describe_action(engine, action, args)
    if say:
        user += ' \u2014 ' + say
    parts = [('\U0001f0a0 ' + t['text']) if t.get('who') == 'dealer' else t['text'] for t in lines]
    # the seat's last call's metrics (the chat footer), only when her voice is on this row
    seat = state.pop('seat_meta', None) or {}
    if not any(t.get('who') == 'ai' for t in lines):
        seat = {}
    return [{'role': 'user', 'content': user, 'metadata': {'source': 'table'}},
            {'role': 'assistant', 'content': '\n'.join(parts) or '\u2026',
             'metadata': {**seat, 'source': 'table'}}]


def append_table(session, rows):
    """Land a pair on the session chat. Refusals (sealed, degraded, a 20s
    stream-wait) are logged — the move itself already happened on the felt."""
    if not session or not rows:
        return False
    try:
        from core.api_fastapi import get_system
        sm = get_system().llm_chat.session_manager
        ok = bool(sm.append_messages_to_chat(session, rows, max_wait_if_streaming=20.0))
    except Exception as e:
        logger.warning(f'game-room: table log for {session!r} failed: {e}')
        return False
    if not ok:
        logger.warning(f'game-room: table log for {session!r} did not land (sealed, degraded, or stream-busy)')
    return ok


def game_session(chat):
    """The game id when `chat` is a session of a room GAME, else None.
    Stories carry 'story:' ids and their own hooks — never a game here."""
    if not chat:
        return None
    s = _chat_settings(chat)
    if not isinstance(s, dict) or s.get('mode') != 'game':
        return None
    gid = str(s.get('game_id') or '').strip()
    if not gid or gid.startswith('story:'):
        return None
    return gid


# ---------------------------------------------------------------- LLM plumbing

def _extract_json(text):
    """First balanced JSON object in the response (handles fences + prose)."""
    if not text:
        return None
    stripped = text.strip()
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", stripped, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    try:
        return json.loads(stripped)
    except Exception:
        pass
    start = stripped.find('{')
    while start != -1:
        depth, in_str, esc = 0, False, False
        for i in range(start, len(stripped)):
            c = stripped[i]
            if in_str:
                if esc:
                    esc = False
                elif c == '\\':
                    esc = True
                elif c == '"':
                    in_str = False
                continue
            if c == '"':
                in_str = True
            elif c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(stripped[start:i + 1])
                    except Exception:
                        break
        start = stripped.find('{', start + 1)
    return None


def _is_local_provider(key):
    """THE is_local rule (core resolve.py). Unverifiable = cloud."""
    try:
        from core.chat.llm_providers.resolve import is_local
        return bool(is_local(key))
    except Exception:
        return False


def _get_provider(provider_key=None, model='', privacy_required=False, health='cached'):
    from core.chat.llm_providers.resolve import ProviderRefused
    try:
        sel = _select(provider_key, model, privacy_required, health)
    except ProviderRefused as e:
        logger.warning(f'game-room: {e}')
        return None
    return sel.provider if sel else None


def _select(provider_key=None, model='', privacy_required=False, health='cached'):
    """The resolver's Selection (key, provider, model); a refusal raises
    ProviderRefused, its text the user's words. Explicit
    provider by key (with optional model override), else Auto. Thin door onto core.chat.llm_providers.resolve — the ONE resolver
    (2026-09-21). privacy_required=True (private session chat, P3-T3) allows
    LOCAL providers only; a refusal or a dead pin is terminal (never a
    cloud pick, never auto). This NEVER reads the operator's active web
    chat — the old copy fell through to `llm_chat._select_provider()`, so an
    auto-mode game session ran on whatever the browser tab had open."""
    from core.chat.llm_providers.resolve import resolve
    return resolve(provider_key or 'auto', model, private=bool(privacy_required), health=health)


def provider_info(provider_key=None, model='', privacy_required=False):
    """Best-effort {provider, display_name, model} for the seat UI — a dry
    run of the resolver (no health probe: every wave paid one the board
    never asked for, S2 #11). privacy_required keeps the display honest for
    private sessions."""
    try:
        from core.chat.llm_providers.resolve import resolve, ProviderRefused
        try:
            sel = resolve(provider_key or 'auto', model, private=bool(privacy_required), health='skip')
        except ProviderRefused as e:
            logger.debug(f'game-room: provider_info: {e}')
            return {'provider': None, 'display_name': None, 'model': None}
        return {'provider': sel.key, 'display_name': sel.display_name, 'model': sel.effective_model}
    except Exception as e:
        logger.debug(f'game-room: provider_info failed: {e}')
        return {'provider': None, 'display_name': None, 'model': None}


def _resolve_persona_prompt(name):
    """Resolved persona prompt text, or None → built-in table persona.
    Re-resolved on EVERY call, never cached: prompts hot-reload from disk and
    Sapphire self-edits hers live — the text can change between rounds."""
    if not name or name == '__table__':
        return None
    try:
        from core import prompts
        from core.personas import persona_manager
        rec = persona_manager.get(name) or {}
        prompt_name = (rec.get('settings') or {}).get('prompt') or name
        p = prompts.get_prompt(prompt_name) or {}
        content = (p.get('content') or '').strip()
        if not content:
            logger.warning(f'game-room: persona {name!r} resolved to empty prompt {prompt_name!r}')
            return None
        return content
    except Exception as e:
        logger.warning(f'game-room: persona resolve failed for {name!r}: {e}')
        return None


def _resolve_prompt_text(prompt_name):
    """Direct prompt-name resolution — session chats carry a `prompt` setting
    rather than (or beside) a persona. Same hot-reload rule: never cached."""
    if not prompt_name:
        return None
    try:
        from core import prompts
        p = prompts.get_prompt(prompt_name) or {}
        return (p.get('content') or '').strip() or None
    except Exception as e:
        logger.warning(f'game-room: prompt resolve failed for {prompt_name!r}: {e}')
        return None


def _system_prompt(contract, view, cfg, gcfg=None):
    """Persona layer + game contract. Persona text is character/voice only;
    the contract carries mechanics + JSON schema and must always survive.
    The contract's <<INSTRUCTIONS>> slot takes the game's (user-editable)
    playing style — substituted AFTER .format, so user braces can't break
    formatting. .replace (not .format) on persona text for the same reason."""
    cfg = cfg or {}
    persona_text = _resolve_persona_prompt(cfg.get('persona'))
    if persona_text is None:
        persona_text = _resolve_prompt_text(cfg.get('prompt'))
    if persona_text:
        base = (persona_text.replace('{ai_name}', view['my_name'])
                            .replace('{user_name}', view['opp_name']))
    else:
        base = TABLE_PERSONA.format(ai_name=view['my_name'])
    # Session custom context rides between persona and contract — the contract
    # (rules + JSON schema) must stay last so the schema survives.
    extra = (cfg.get('custom_context') or '').strip()
    if extra:
        base += "\n\nTable notes (this session's custom context):\n" + extra
    text = contract.format(ai_name=view['my_name'], opp_name=view['opp_name'])
    if '<<INSTRUCTIONS>>' in text:
        instructions = ((gcfg or {}).get('instructions') or '').strip()
        text = text.replace('<<INSTRUCTIONS>>', instructions)
    return base + '\n\n' + text


MOVE_TOKENS_FLOOR = 8192


def _move_budget(sel):
    """max_tokens for a seat's move: the resolver's value for this provider and
    model (core.chat.llm_providers), never below MOVE_TOKENS_FLOOR."""
    try:
        from core.chat.llm_providers import provider_registry
        got = provider_registry.get_generation_params(sel.key, sel.effective_model).get('max_tokens')
        return max(int(got or 0), MOVE_TOKENS_FLOOR)
    except Exception:
        return MOVE_TOKENS_FLOOR


class SeatDown(Exception):
    """The seat couldn't get a reply; str(e) is why, in the user's words."""


def _call_llm(system, user, cfg):
    """One-shot completion → (think-stripped content, metrics block — the
    chat's own usage_metadata). Raises SeatDown with the words (llm_errors,
    the chat's own explainer) when there is none."""
    from core.chat.llm_providers.resolve import ProviderRefused
    from core.chat.llm_errors import explain
    cfg = cfg or {}
    if cfg.get('hidden'):
        logger.warning('game-room: session chat is sealed in a locked vault — seat refused')
        raise SeatDown("This session's chat is sealed in a locked vault, so the seat can't play.")
    try:
        sel = _select(cfg.get('provider'), cfg.get('model', ''),
                      privacy_required=bool(cfg.get('privacy_required')))
    except ProviderRefused as e:
        logger.warning(f'game-room: {e}')
        raise SeatDown(str(e))
    provider = sel.provider if sel else None
    if provider is None:
        logger.warning('game-room: no LLM provider available')
        raise SeatDown('No LLM provider is available. Check Settings › LLM.')
    try:
        temp = max(0.0, min(float(cfg.get('temperature', 0.85)), 1.5))
    except (TypeError, ValueError):
        temp = 0.85
    start = time.time()
    try:
        resp = provider.chat_completion(
            [{'role': 'system', 'content': system},
             {'role': 'user', 'content': user}],
            tools=None,
            # the provider's own Max Tokens, floored: thinking models spend it
            # reasoning before the move's JSON (a flat 3000 could all go there)
            generation_params={'temperature': temp, 'max_tokens': _move_budget(sel)},
        )
    except Exception as e:
        logger.error(f'game-room: chat_completion failed: {e}')
        raise SeatDown(explain(e, sel.key)['text'])
    content = getattr(resp, 'content', None) or ''
    # Thinking models leak <think>...</think> into content (sometimes unclosed
    # when truncated) — strip before JSON extraction.
    from core import think
    from core.chat.chat_streaming import usage_metadata
    answer, thought = think.split(content)
    meta = usage_metadata(sel.key, sel.effective_model, resp, answer,
                          getattr(resp, 'thinking', None) or thought, start, time.time())
    return answer or '', meta


# ---------------------------------------------------------------- orchestration

def _line_down(state, why):
    """The dealer says why her seat missed: once per cause, so a dead line
    doesn't repeat the paragraph every turn (her own line stays "static").
    The dealer, never her: her lines are spoken and cast to the glass."""
    if why != state.get('line_down'):
        add_talk(state, 'dealer', f'Static on the line: {why}')
    state['line_down'] = why



def _merge_gcfg(cfg, gcfg):
    """Game settings overlay the session cfg where they own the knob."""
    cfg = dict(cfg or {})
    if gcfg and gcfg.get('temperature') is not None:
        cfg['temperature'] = gcfg['temperature']
    return cfg


def decide(engine, state, cfg, gcfg=None):
    """One AI move: LLM proposes, engine's validator disposes. Always returns
    {'action', 'args', 'say', 'fallback': bool} that is safe to apply."""
    view = _names(engine.view_for_ai(state), state)
    s_action, s_args = engine.safe_action(state)
    fallback = {'action': s_action, 'args': s_args,
                'say': f'(static on the line... I {s_action})', 'fallback': True}
    system = _system_prompt(engine.CONTRACT, view, cfg, gcfg)
    state.pop('seat_meta', None)
    try:
        content, state['seat_meta'] = _call_llm(system, engine.build_user_msg(view), _merge_gcfg(cfg, gcfg))
    except SeatDown as e:
        _line_down(state, str(e))
        return fallback
    if content is None:
        return fallback
    data = _extract_json(content)
    if not isinstance(data, dict):
        # Length only, never content: this can be a PRIVATE session's reply,
        # logs are plaintext for 30 days, and get_self_info feeds recent
        # warnings back into (possibly cloud) chats (hunt 2026-08-17).
        logger.warning(f'game-room: unparseable AI response ({len(content)} chars)')
        _line_down(state, f"{view['my_name']} answered, but not with a move I could read.")
        return fallback
    decision = engine.validate_decision(data, view)
    if not decision:
        logger.warning(f'game-room: AI decision failed validation: {data}')
        _line_down(state, f"{view['my_name']} tried a move the rules don't allow.")
        return fallback
    state.pop('line_down', None)
    decision.setdefault('args', {})
    decision['say'] = str(decision.get('say') or '').strip()[:400] or '...'
    decision['fallback'] = False
    return decision


def banter_reply(engine, state, cfg, gcfg=None):
    """Table talk between moves — no game action. Returns the reply string."""
    live = round_live(state)
    view = _names(engine.view_for_ai(state) if live else engine.view_between(state), state)
    system = _system_prompt(engine.BANTER_CONTRACT, view, cfg, gcfg)
    state.pop('seat_meta', None)
    try:
        content, state['seat_meta'] = _call_llm(system, engine.build_banter_msg(view), _merge_gcfg(cfg, gcfg))
    except SeatDown as e:
        _line_down(state, str(e))
        return '(static on the line...)'
    data = _extract_json(content or '')
    say = str((data or {}).get('say') or '').strip()
    return say[:400] if say else '(static on the line...)'


def run_ai_turns(engine, state, cfg, gcfg=None):
    """Let the AI act until it's the player's turn or the round ends."""
    for _ in range(AI_TURN_GUARD):
        if engine.whose_turn(state) != 'ai':
            return
        decision = decide(engine, state, cfg, gcfg)
        add_talk(state, 'ai', decision['say'])
        try:
            engine.apply_action(state, 'ai', decision['action'], decision.get('args') or {})
        except IllegalAction as e:
            logger.error(f'game-room: AI action rejected ({e}); forcing safe action')
            s_action, s_args = engine.safe_action(state)
            engine.apply_action(state, 'ai', s_action, s_args)
    logger.error('game-room: AI turn guard tripped — state may be stuck')
