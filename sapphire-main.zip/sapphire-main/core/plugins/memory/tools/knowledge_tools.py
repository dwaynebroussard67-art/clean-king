# core/plugins/memory/tools/knowledge_tools.py
"""
Knowledge base system for reference data: people contacts and knowledge tabs.
SQLite-backed with FTS5 search, semantic embeddings, and scope isolation.
People are scoped via people_scope. Knowledge tabs are scoped via knowledge_scope.
"""

import sqlite3
import logging
import re
import threading
import numpy as np
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager

logger = logging.getLogger(__name__)

ENABLED = True
EMOJI = '📖'
TOOL_CATEGORY = 'knowledge'

_db_path = None
_db_initialized = False
_db_lock = threading.Lock()

# Flips True only when backfill completed without transient failure. A failed
# attempt leaves it False so the next search retries. Reset on provider swap
# (see switch_embedding_provider in core.embeddings).
_backfill_done = False

AVAILABLE_FUNCTIONS = [
    'save_person',
    'save_knowledge',
    'search_knowledge',
    'delete_knowledge',
]

TOOLS = [
    {
        "type": "function",
        "writes": True,
        "category": "people",
        "is_local": True,
        "function": {
            "name": "save_person",
            "description": "Save or update a person. No id = upsert by name; with id = edit that row (and rename).",
            "parameters": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string"
                    },
                    "id": {
                        "type": "integer",
                        "description": "From search_knowledge"
                    },
                    "relationship": {
                        "type": "string",
                        "description": "e.g. father, friend, coworker"
                    },
                    "phone": {"type": "string"},
                    "email": {"type": "string"},
                    "address": {"type": "string"},
                    "notes": {
                        "type": "string",
                        "description": "Replaces existing notes"
                    },
                    "append_notes": {
                        "type": "string",
                        "description": "Adds to existing notes instead; not with notes"
                    }
                },
                "required": ["name"]
            }
        }
    },
    {
        "type": "function",
        "writes": True,
        "is_local": True,
        "function": {
            "name": "save_knowledge",
            "description": "Save content under a category; new categories are created, long content is chunked.",
            "parameters": {
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string"
                    },
                    "content": {
                        "type": "string"
                    },
                    "description": {
                        "type": "string",
                        "description": "Category description, used only when it is created"
                    }
                },
                "required": ["category", "content"]
            }
        }
    },
    {
        "type": "function",
        "is_local": True,
        "function": {
            "name": "search_knowledge",
            "description": "Search, browse or read your knowledge base (people, categories, notes). No arguments = overview.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Semantic search"
                    },
                    "category": {
                        "type": "string",
                        "description": "Browse one category"
                    },
                    "id": {
                        "type": "integer",
                        "description": "Read one entry in full"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Default 10"
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "writes": True,
        "is_local": True,
        "function": {
            "name": "delete_knowledge",
            "description": "Delete entries or categories you created; user-created content is protected.",
            "parameters": {
                "type": "object",
                "properties": {
                    "id": {
                        "type": "integer",
                        "description": "One entry"
                    },
                    "category": {
                        "type": "string",
                        "description": "The category and all its entries"
                    }
                },
                "required": []
            }
        }
    }
]


# ─── Database ─────────────────────────────────────────────────────────────────

def _get_db_path():
    global _db_path
    if _db_path is None:
        # Phase 4: depth-independent anchor via config.py (project root).
        import config
        _db_path = Path(config.__file__).parent / "user" / "knowledge.db"
    return _db_path


@contextmanager
def _get_connection():
    _ensure_db()
    conn = sqlite3.connect(str(_get_db_path()), timeout=10)
    try:
        # busy_timeout IS honored during active transactions; sqlite3.connect's
        # `timeout=` is ignored once BEGIN fires (CPython #124510). WAL is set
        # once in _ensure_db — db-header-persisted. foreign_keys IS per-conn
        # in SQLite, so it stays here.
        conn.execute("PRAGMA busy_timeout=10000")
        conn.execute("PRAGMA foreign_keys=ON")
        yield conn
    finally:
        conn.close()


def _scope_condition(scope, col='scope'):
    """Return (sql_fragment, params) that includes global overlay."""
    if scope == 'global':
        return f"{col} = ?", [scope]
    return f"{col} IN (?, 'global')", [scope]


def _ensure_db():
    global _db_initialized
    if _db_initialized:
        return
    with _db_lock:
        if _db_initialized:
            return

        db_path = _get_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(db_path, timeout=10)
        cursor = conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")

        # People (scoped via people_scope)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS people (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                relationship TEXT,
                phone TEXT,
                email TEXT,
                address TEXT,
                notes TEXT,
                scope TEXT NOT NULL DEFAULT 'default',
                embedding BLOB,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        # Migration: add scope column if missing (existing DBs)
        try:
            cursor.execute('SELECT scope FROM people LIMIT 1')
        except sqlite3.OperationalError:
            cursor.execute("ALTER TABLE people ADD COLUMN scope TEXT NOT NULL DEFAULT 'default'")
            logger.info("Migrated people table: added scope column")

        # Migration: add email_whitelisted column if missing
        try:
            cursor.execute('SELECT email_whitelisted FROM people LIMIT 1')
        except sqlite3.OperationalError:
            cursor.execute("ALTER TABLE people ADD COLUMN email_whitelisted INTEGER DEFAULT 0")
            logger.info("Migrated people table: added email_whitelisted column")

        # Migration: add call_whitelisted column if missing (phone_call tool gate)
        try:
            cursor.execute('SELECT call_whitelisted FROM people LIMIT 1')
        except sqlite3.OperationalError:
            cursor.execute("ALTER TABLE people ADD COLUMN call_whitelisted INTEGER DEFAULT 0")
            logger.info("Migrated people table: added call_whitelisted column")

        # Migration: add embedding provenance columns. Scout finding 2026-04-19
        # — without (provider, dim) stamped per row, a provider swap silently
        # invalidates all stored vectors. Read-path filters by these.
        try:
            cursor.execute('SELECT embedding_provider FROM people LIMIT 1')
        except sqlite3.OperationalError:
            cursor.execute("ALTER TABLE people ADD COLUMN embedding_provider TEXT")
            cursor.execute("ALTER TABLE people ADD COLUMN embedding_dim INTEGER")
            logger.info("Migrated people table: added embedding_provider, embedding_dim")

        # Unique per name+scope (drop old name-only index)
        cursor.execute('DROP INDEX IF EXISTS idx_people_name_lower')
        cursor.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_people_name_scope ON people(LOWER(name), scope)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_people_scope ON people(scope)')

        # Knowledge tabs (scoped)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_tabs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                type TEXT NOT NULL DEFAULT 'user',
                scope TEXT NOT NULL DEFAULT 'default',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(name, scope)
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_tabs_scope ON knowledge_tabs(scope)')

        # Knowledge entries (within tabs, chunked + embedded)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tab_id INTEGER NOT NULL REFERENCES knowledge_tabs(id) ON DELETE CASCADE,
                content TEXT NOT NULL,
                chunk_index INTEGER DEFAULT 0,
                source_filename TEXT,
                embedding BLOB,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_entries_tab ON knowledge_entries(tab_id)')

        # Provenance columns for knowledge entries — see note above for people.
        try:
            cursor.execute('SELECT embedding_provider FROM knowledge_entries LIMIT 1')
        except sqlite3.OperationalError:
            cursor.execute("ALTER TABLE knowledge_entries ADD COLUMN embedding_provider TEXT")
            cursor.execute("ALTER TABLE knowledge_entries ADD COLUMN embedding_dim INTEGER")
            logger.info("Migrated knowledge_entries: added embedding_provider, embedding_dim")

        # FTS5 on entries
        try:
            _setup_fts(cursor)
        except sqlite3.DatabaseError as e:
            logger.warning(f"Knowledge FTS5 corrupted, rebuilding: {e}")
            cursor.execute("DROP TABLE IF EXISTS knowledge_fts")
            cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_insert")
            cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_delete")
            cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_update")
            conn.commit()
            _setup_fts(cursor)

        # Scope registries
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_scopes (
                name TEXT PRIMARY KEY,
                created DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute("INSERT OR IGNORE INTO knowledge_scopes (name) VALUES ('default')")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS people_scopes (
                name TEXT PRIMARY KEY,
                created DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute("INSERT OR IGNORE INTO people_scopes (name) VALUES ('default')")

        conn.commit()
        conn.close()
        _db_initialized = True
        logger.info(f"Knowledge database ready at {db_path}")


def _setup_fts(cursor):
    cursor.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
            content,
            content=knowledge_entries, content_rowid=id
        )
    """)

    cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_insert")
    cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_delete")
    cursor.execute("DROP TRIGGER IF EXISTS knowledge_fts_update")

    cursor.execute("""
        CREATE TRIGGER knowledge_fts_insert
        AFTER INSERT ON knowledge_entries BEGIN
            INSERT INTO knowledge_fts(rowid, content) VALUES (new.id, new.content);
        END
    """)
    cursor.execute("""
        CREATE TRIGGER knowledge_fts_delete
        AFTER DELETE ON knowledge_entries BEGIN
            INSERT INTO knowledge_fts(knowledge_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
        END
    """)
    cursor.execute("""
        CREATE TRIGGER knowledge_fts_update
        AFTER UPDATE OF content ON knowledge_entries BEGIN
            INSERT INTO knowledge_fts(knowledge_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
            INSERT INTO knowledge_fts(rowid, content) VALUES (new.id, new.content);
        END
    """)

    # Populate if empty
    cursor.execute("SELECT COUNT(*) FROM knowledge_entries")
    entry_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM knowledge_fts")
    fts_count = cursor.fetchone()[0]
    if entry_count > 0 and fts_count == 0:
        logger.info(f"Populating knowledge FTS5 from {entry_count} entries...")
        cursor.execute("INSERT INTO knowledge_fts(rowid, content) SELECT id, content FROM knowledge_entries")


def _get_current_scope():
    try:
        from core.chat.function_manager import scope_knowledge
        return scope_knowledge.get()
    except Exception as e:
        # Fail disabled, not defaulted — see memory_tools._get_current_scope
        # comment. Silent-default was a real bug class.
        logger.warning(f"Could not get knowledge scope: {e}, returning None (disabled)")
        return None


def _get_current_rag_scope():
    try:
        from core.chat.function_manager import scope_rag
        return scope_rag.get()
    except Exception:
        return None


def _get_current_people_scope():
    try:
        from core.chat.function_manager import scope_people
        return scope_people.get()
    except Exception as e:
        # Fail disabled, not defaulted — silent-default class (2026-04-20).
        # Executor checks `if people_scope is None` and returns the disabled
        # message; falling back to 'default' would leak People-DB writes.
        logger.warning(f"Could not get people scope: {e}, returning None (disabled)")
        return None


def _get_embedder():
    """Get the singleton embedder directly from core.embeddings."""
    try:
        from core.embeddings import get_embedder
        return get_embedder()
    except Exception as e:
        logger.warning(f"Could not get embedder: {e}")
        return None


SIMILARITY_THRESHOLD = 0.40


# ─── Public API (used by api_fastapi.py) ──────────────────────────────────────

def get_scopes():
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT scope, COUNT(*) FROM knowledge_tabs GROUP BY scope')
            tab_counts = {row[0]: row[1] for row in cursor.fetchall()}
            cursor.execute('SELECT name FROM knowledge_scopes ORDER BY name')
            registered = [row[0] for row in cursor.fetchall()]
            all_scopes = set(registered) | set(tab_counts.keys()) | {'default'}
            # a chat's documents aren't a scope to pick: and the name is the chat's, private or not
            return [{"name": name, "count": tab_counts.get(name, 0)} for name in sorted(all_scopes)
                    if not name.startswith('__rag__:')]
    except Exception as e:
        logger.error(f"Error getting knowledge scopes: {e}")
        return [{"name": "default", "count": 0}]


def status_summary(scope=None):
    """People + knowledge counts for the status plugin — answered here
    because knowledge.db is ours (2026-09-11). Counts only; never creates
    the DB."""
    out = {'people': 0, 'people_by_scope': {}, 'knowledge_total': 0,
           'knowledge_scopes': {}, 'scopes': {}, 'current': None}
    try:
        if not _get_db_path().exists():
            return out
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT scope, COUNT(*) FROM people GROUP BY scope')
            out['people_by_scope'] = {row[0]: row[1] for row in cursor.fetchall()}
            cursor.execute('SELECT t.scope, COUNT(e.id) FROM knowledge_tabs t '
                           'LEFT JOIN knowledge_entries e ON e.tab_id = t.id GROUP BY t.scope')
            out['knowledge_scopes'] = {row[0]: row[1] for row in cursor.fetchall()}
            cursor.execute('SELECT name FROM knowledge_scopes')
            out['scopes'] = {row[0]: 0 for row in cursor.fetchall()}
        out['people'] = sum(out['people_by_scope'].values())
        out['knowledge_total'] = sum(out['knowledge_scopes'].values())
        for counts in (out['people_by_scope'], out['knowledge_scopes']):
            for name, n in counts.items():
                out['scopes'][name] = out['scopes'].get(name, 0) + n
        if scope:
            out['current'] = {'people': out['people_by_scope'].get(scope, 0),
                              'knowledge': out['knowledge_scopes'].get(scope, 0)}
    except Exception as e:
        logger.warning(f"knowledge status_summary failed: {e}")
    return out


def create_scope(name: str) -> bool:
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO knowledge_scopes (name) VALUES (?)", (name,))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Failed to create knowledge scope '{name}': {e}")
        return False


def rename_scope(old_name: str, new_name: str) -> bool:
    """Rename a knowledge scope in place (tabs follow; entries key on tab_id).

    Used by chat rename to carry a chat's `__rag__:{name}` scope along.
    No-op (True) if the old scope doesn't exist — a chat without RAG docs
    has no scope to move. False only on a real failure or collision."""
    if old_name == 'default':
        return False
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            if not cursor.execute('SELECT 1 FROM knowledge_scopes WHERE name = ?',
                                  (old_name,)).fetchone():
                return True  # nothing to rename
            if cursor.execute('SELECT 1 FROM knowledge_scopes WHERE name = ?',
                              (new_name,)).fetchone():
                logger.warning(f"rename_scope: target '{new_name}' already exists")
                return False
            cursor.execute('UPDATE knowledge_scopes SET name = ? WHERE name = ?',
                           (new_name, old_name))
            cursor.execute('UPDATE knowledge_tabs SET scope = ? WHERE scope = ?',
                           (new_name, old_name))
            conn.commit()
        logger.info(f"Renamed knowledge scope '{old_name}' -> '{new_name}'")
        return True
    except Exception as e:
        logger.error(f"Failed to rename scope '{old_name}' -> '{new_name}': {e}")
        return False


def delete_scope(name: str) -> dict:
    """Delete a knowledge scope, ALL its tabs, and ALL entries within those tabs."""
    if name == 'default':
        return {"error": "Cannot delete the default scope"}
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM knowledge_tabs WHERE scope = ?', (name,))
            tab_count = cursor.fetchone()[0]
            cursor.execute('SELECT COUNT(*) FROM knowledge_entries WHERE tab_id IN (SELECT id FROM knowledge_tabs WHERE scope = ?)', (name,))
            entry_count = cursor.fetchone()[0]
            cursor.execute('DELETE FROM knowledge_entries WHERE tab_id IN (SELECT id FROM knowledge_tabs WHERE scope = ?)', (name,))
            cursor.execute('DELETE FROM knowledge_tabs WHERE scope = ?', (name,))
            cursor.execute('DELETE FROM knowledge_scopes WHERE name = ?', (name,))
            conn.commit()
            logger.info(f"Deleted knowledge scope '{name}' with {tab_count} tabs and {entry_count} entries")
        try:
            from core.chat.scope_cleanup import sweep_orphaned_scope_ref
            sweep_orphaned_scope_ref('knowledge_scope', name)
        except Exception as e:
            logger.warning(f"knowledge_scope sweep after delete failed: {e}")
        return {"deleted_tabs": tab_count, "deleted_entries": entry_count}
    except Exception as e:
        logger.error(f"Failed to delete knowledge scope '{name}': {e}")
        return {"error": str(e)}


# ─── People Scope CRUD ────────────────────────────────────────────────────────

def get_people_scopes():
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT scope, COUNT(*) FROM people GROUP BY scope')
            counts = {row[0]: row[1] for row in cursor.fetchall()}
            cursor.execute('SELECT name FROM people_scopes ORDER BY name')
            registered = [row[0] for row in cursor.fetchall()]
            all_scopes = set(registered) | set(counts.keys()) | {'default'}
            return [{"name": name, "count": counts.get(name, 0)} for name in sorted(all_scopes)]
    except Exception as e:
        logger.error(f"Error getting people scopes: {e}")
        return [{"name": "default", "count": 0}]


def create_people_scope(name: str) -> bool:
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO people_scopes (name) VALUES (?)", (name,))
            conn.commit()
            return True
    except Exception as e:
        logger.error(f"Failed to create people scope '{name}': {e}")
        return False


def delete_people_scope(name: str) -> dict:
    if name == 'default':
        return {"error": "Cannot delete the default scope"}
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM people WHERE scope = ?', (name,))
            count = cursor.fetchone()[0]
            cursor.execute('DELETE FROM people WHERE scope = ?', (name,))
            cursor.execute('DELETE FROM people_scopes WHERE name = ?', (name,))
            conn.commit()
            logger.info(f"Deleted people scope '{name}' with {count} people")
        try:
            from core.chat.scope_cleanup import sweep_orphaned_scope_ref
            sweep_orphaned_scope_ref('people_scope', name)
        except Exception as e:
            logger.warning(f"people_scope sweep after delete failed: {e}")
        return {"deleted_people": count}
    except Exception as e:
        logger.error(f"Failed to delete people scope '{name}': {e}")
        return {"error": str(e)}


# ─── People CRUD ──────────────────────────────────────────────────────────────

def get_people(scope='default'):
    with _get_connection() as conn:
        cursor = conn.cursor()
        scope_sql, scope_params = _scope_condition(scope)
        cursor.execute(f'SELECT id, name, relationship, phone, email, address, notes, created_at, updated_at, email_whitelisted, call_whitelisted FROM people WHERE {scope_sql} ORDER BY name', scope_params)
        rows = cursor.fetchall()
        return [{"id": r[0], "name": r[1], "relationship": r[2], "phone": r[3],
                 "email": r[4], "address": r[5], "notes": r[6],
                 "created_at": r[7], "updated_at": r[8],
                 "email_whitelisted": bool(r[9]), "call_whitelisted": bool(r[10])} for r in rows]


MAX_PEOPLE_PER_SCOPE = 50_000


def create_or_update_person(name, relationship=None, phone=None, email=None, address=None, notes=None, scope='default', person_id=None, email_whitelisted=None, call_whitelisted=None):
    with _get_connection() as conn:
        cursor = conn.cursor()
        # Cap check — only for new person insertions; updates to existing
        # rows don't change the count. person_id or name match = update path.
        if not person_id:
            cursor.execute(
                'SELECT COUNT(*) FROM people WHERE LOWER(name) = LOWER(?) AND scope = ?',
                (name.strip(), scope)
            )
            name_match = cursor.fetchone()[0]
            if name_match == 0:
                cursor.execute('SELECT COUNT(*) FROM people WHERE scope = ?', (scope,))
                total = cursor.fetchone()[0]
                if total >= MAX_PEOPLE_PER_SCOPE:
                    raise ValueError(
                        f"People scope '{scope}' is at the row limit ({MAX_PEOPLE_PER_SCOPE:,}). "
                        f"Delete some entries or use a different scope before adding more."
                    )

        # If ID provided, update by ID directly (allows name changes)
        if person_id:
            cursor.execute('SELECT id FROM people WHERE id = ? AND scope = ?', (person_id, scope))
        else:
            # Fallback: match by name (for AI tool calls)
            cursor.execute('SELECT id FROM people WHERE LOWER(name) = LOWER(?) AND scope = ?', (name.strip(), scope))
        existing = cursor.fetchone()

        # Build embed text for semantic search
        parts = [name.strip()]
        if relationship: parts.append(f"relationship: {relationship}")
        if phone: parts.append(f"phone: {phone}")
        if email: parts.append(f"email: {email}")
        if address: parts.append(f"address: {address}")
        if notes: parts.append(f"notes: {notes}")
        embed_text = '. '.join(parts)

        embedding_blob = None
        embedding_provider = None
        embedding_dim = None
        embedder = _get_embedder()
        if embedder and embedder.available:
            embs = embedder.embed([embed_text], prefix='search_document')
            if embs is not None:
                from core.embeddings import stamp_embedding
                embedding_blob, embedding_provider, embedding_dim = stamp_embedding(embs[0], embedder)
            else:
                # Embed returned None (transient failure) — a NEW person row
                # lands with a NULL vector, invisible to semantic search while
                # the backfill latch stays set. Warn + re-arm (mirrors
                # memory_tools 2026-05-07 #H; negspace N22, 2026-08-31).
                global _backfill_done
                _backfill_done = False
                logger.warning("[KNOWLEDGE] people embed returned None — "
                               "row may store NULL vector; backfill re-armed.")

        now = datetime.now().isoformat()

        if existing:
            pid = existing[0]
            # Update provided fields — empty string clears to NULL, None means "don't touch"
            updates, params = [], []
            for col, val in [('relationship', relationship), ('phone', phone),
                             ('email', email), ('address', address), ('notes', notes)]:
                if val is not None:
                    updates.append(f'{col} = ?'); params.append(val if val else None)
            if email_whitelisted is not None:
                updates.append('email_whitelisted = ?'); params.append(int(email_whitelisted))
            if call_whitelisted is not None:
                updates.append('call_whitelisted = ?'); params.append(int(call_whitelisted))
            if name.strip():
                updates.append('name = ?'); params.append(name.strip())
            # Only overwrite embedding + provenance if we produced a fresh one;
            # a transient embed failure shouldn't strip a good vector off an
            # existing row. Scout finding: update_memory used to NULL-out the
            # vector on embed failure; applying the guard here too.
            if embedding_blob is not None:
                updates.append('embedding = ?'); params.append(embedding_blob)
                updates.append('embedding_provider = ?'); params.append(embedding_provider)
                updates.append('embedding_dim = ?'); params.append(embedding_dim)
            updates.append('updated_at = ?'); params.append(now)
            params.append(pid)
            params.append(scope)
            # Belt-and-suspenders scope guard. The existing-lookup above is
            # scope-filtered, but a concurrent deletion + reinsert could
            # repurpose the id between the SELECT and this UPDATE. Adding
            # AND scope=? makes the UPDATE atomic against scope drift.
            # Day-ruiner scout 2026-05-07 #G.
            cursor.execute(
                f'UPDATE people SET {", ".join(updates)} WHERE id = ? AND scope = ?',
                params
            )
            conn.commit()
            is_new_flag = False
        else:
            cursor.execute(
                'INSERT INTO people (name, relationship, phone, email, address, notes, scope, embedding, '
                'embedding_provider, embedding_dim, updated_at, email_whitelisted, call_whitelisted) '
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (name.strip(), relationship, phone, email, address, notes, scope,
                 embedding_blob, embedding_provider, embedding_dim, now,
                 int(email_whitelisted) if email_whitelisted else 0,
                 int(call_whitelisted) if call_whitelisted else 0)
            )
            pid = cursor.lastrowid
            conn.commit()
            is_new_flag = True
    try:
        from core.mind_events import publish_mind_changed
        publish_mind_changed('people', scope, 'save' if is_new_flag else 'update')
    except Exception:
        pass
    return pid, is_new_flag


def delete_person(person_id):
    scope = _get_current_people_scope()
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT name FROM people WHERE id = ? AND scope = ?', (person_id, scope))
        row = cursor.fetchone()
        if not row:
            return False
        cursor.execute('DELETE FROM people WHERE id = ? AND scope = ?', (person_id, scope))
        conn.commit()
    try:
        from core.mind_events import publish_mind_changed
        publish_mind_changed('people', scope, 'delete')
    except Exception:
        pass
    return True


# ─── Knowledge Tabs CRUD ─────────────────────────────────────────────────────

def get_tabs(scope='default', tab_type=None):
    with _get_connection() as conn:
        cursor = conn.cursor()
        scope_sql, scope_params = _scope_condition(scope, 't.scope')
        if tab_type:
            cursor.execute(f'''
                SELECT t.id, t.name, t.description, t.type, t.scope, t.created_at, t.updated_at,
                       (SELECT COUNT(*) FROM knowledge_entries WHERE tab_id = t.id) as entry_count
                FROM knowledge_tabs t WHERE {scope_sql} AND t.type = ? ORDER BY t.name
            ''', scope_params + [tab_type])
        else:
            cursor.execute(f'''
                SELECT t.id, t.name, t.description, t.type, t.scope, t.created_at, t.updated_at,
                       (SELECT COUNT(*) FROM knowledge_entries WHERE tab_id = t.id) as entry_count
                FROM knowledge_tabs t WHERE {scope_sql} ORDER BY t.name
            ''', scope_params)
        rows = cursor.fetchall()
        return [{"id": r[0], "name": r[1], "description": r[2], "type": r[3],
                 "scope": r[4], "created_at": r[5], "updated_at": r[6],
                 "entry_count": r[7]} for r in rows]


def get_tab_entries(tab_id, scope=None):
    with _get_connection() as conn:
        cursor = conn.cursor()
        if scope:
            # Validate tab belongs to requested scope before returning entries
            cursor.execute('SELECT scope FROM knowledge_tabs WHERE id = ?', (tab_id,))
            row = cursor.fetchone()
            if not row or row[0] != scope:
                return []
        cursor.execute(
            'SELECT id, content, chunk_index, source_filename, created_at, updated_at FROM knowledge_entries WHERE tab_id = ? ORDER BY chunk_index, created_at',
            (tab_id,)
        )
        rows = cursor.fetchall()
        return [{"id": r[0], "content": r[1], "chunk_index": r[2],
                 "source_filename": r[3], "created_at": r[4], "updated_at": r[5]} for r in rows]


def create_tab(name, scope='default', description=None, tab_type='user'):
    tab_id = None
    with _get_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute(
                'INSERT INTO knowledge_tabs (name, description, type, scope) VALUES (?, ?, ?, ?)',
                (name.strip(), description, tab_type, scope)
            )
            tab_id = cursor.lastrowid
            conn.commit()
        except sqlite3.IntegrityError:
            return None  # Already exists
    try:
        from core.mind_events import publish_mind_changed
        publish_mind_changed('knowledge', scope, 'save')
    except Exception:
        pass
    return tab_id


def update_tab(tab_id, name=None, description=None):
    scope = _get_current_scope()
    with _get_connection() as conn:
        cursor = conn.cursor()
        updates, params = [], []
        if name is not None:
            updates.append('name = ?'); params.append(name.strip())
        if description is not None:
            updates.append('description = ?'); params.append(description)
        if not updates:
            return False
        updates.append('updated_at = ?'); params.append(datetime.now().isoformat())
        params.extend([tab_id, scope])
        cursor.execute(f'UPDATE knowledge_tabs SET {", ".join(updates)} WHERE id = ? AND scope = ?', params)
        changed = cursor.rowcount > 0
        conn.commit()
    if changed:
        try:
            from core.mind_events import publish_mind_changed
            publish_mind_changed('knowledge', scope, 'update')
        except Exception:
            pass
    return changed


def delete_tab(tab_id):
    scope = _get_current_scope()
    tab_scope_for_event = None
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT name, scope FROM knowledge_tabs WHERE id = ? AND scope = ?', (tab_id, scope))
        row = cursor.fetchone()
        if not row:
            return False
        tab_scope_for_event = row[1]
        cursor.execute('DELETE FROM knowledge_entries WHERE tab_id = ?', (tab_id,))
        cursor.execute('DELETE FROM knowledge_tabs WHERE id = ? AND scope = ?', (tab_id, scope))
        conn.commit()
    try:
        from core.mind_events import publish_mind_changed
        publish_mind_changed('knowledge', tab_scope_for_event or scope, 'delete')
    except Exception:
        pass
    return True


# ─── Knowledge Entries CRUD ───────────────────────────────────────────────────

MAX_ENTRIES_PER_SCOPE = 50_000  # ~20MB of text + embeddings

def add_entry(tab_id, content, chunk_index=0, source_filename=None):
    embedding_blob = None
    embedding_provider = None
    embedding_dim = None
    embedder = _get_embedder()
    if embedder and embedder.available:
        embs = embedder.embed([content], prefix='search_document')
        if embs is not None:
            from core.embeddings import stamp_embedding
            embedding_blob, embedding_provider, embedding_dim = stamp_embedding(embs[0], embedder)
        else:
            # Embed returned None — row stores a NULL vector. Warn + re-arm the
            # backfill latch so the next search sweeps it up (mirrors
            # memory_tools 2026-05-07 #H; negspace N22, 2026-08-31).
            global _backfill_done
            _backfill_done = False
            logger.warning("[KNOWLEDGE] add_entry embed returned None — "
                           "row stored with NULL vector; backfill re-armed.")

    with _get_connection() as conn:
        cursor = conn.cursor()
        # Check scope entry cap
        cursor.execute('''
            SELECT COUNT(*) FROM knowledge_entries
            WHERE tab_id IN (SELECT id FROM knowledge_tabs WHERE scope = (
                SELECT scope FROM knowledge_tabs WHERE id = ?
            ))
        ''', (tab_id,))
        count = cursor.fetchone()[0]
        if count >= MAX_ENTRIES_PER_SCOPE:
            raise ValueError(f"Knowledge scope entry limit reached ({MAX_ENTRIES_PER_SCOPE:,})")

        cursor.execute(
            'INSERT INTO knowledge_entries (tab_id, content, chunk_index, source_filename, '
            'embedding, embedding_provider, embedding_dim) VALUES (?, ?, ?, ?, ?, ?, ?)',
            (tab_id, content, chunk_index, source_filename,
             embedding_blob, embedding_provider, embedding_dim)
        )
        entry_id = cursor.lastrowid
        # Bump tab updated_at
        cursor.execute('UPDATE knowledge_tabs SET updated_at = ? WHERE id = ?',
                       (datetime.now().isoformat(), tab_id))
        cursor.execute('SELECT scope FROM knowledge_tabs WHERE id = ?', (tab_id,))
        tab_row = cursor.fetchone()
        tab_scope = tab_row[0] if tab_row else None
        conn.commit()
    try:
        from core.mind_events import publish_mind_changed
        if tab_scope:
            publish_mind_changed('knowledge', tab_scope, 'save')
    except Exception:
        pass
    return entry_id


def update_entry(entry_id, content):
    embedding_blob = None
    embedding_provider = None
    embedding_dim = None
    embedder = _get_embedder()
    if embedder and embedder.available:
        embs = embedder.embed([content], prefix='search_document')
        if embs is not None:
            from core.embeddings import stamp_embedding
            embedding_blob, embedding_provider, embedding_dim = stamp_embedding(embs[0], embedder)
        else:
            # Embed returned None — the OLD vector is kept for the NEW content
            # (guard below). Not NULL, so backfill can't fix it; stale-vector
            # re-embed is a separate board item. At least say so in the log
            # (negspace N22, 2026-08-31).
            logger.warning("[KNOWLEDGE] update_entry embed returned None — "
                           "content updated but its stored vector is now STALE.")

    tab_scope = None
    with _get_connection() as conn:
        cursor = conn.cursor()
        # Only overwrite embedding columns when we actually produced a fresh
        # embedding — a transient embed failure shouldn't strip the existing
        # vector. Scout finding: this was a silent data-loss path.
        if embedding_blob is not None:
            cursor.execute(
                'UPDATE knowledge_entries SET content = ?, embedding = ?, '
                'embedding_provider = ?, embedding_dim = ?, updated_at = ? WHERE id = ?',
                (content, embedding_blob, embedding_provider, embedding_dim,
                 datetime.now().isoformat(), entry_id)
            )
        else:
            cursor.execute(
                'UPDATE knowledge_entries SET content = ?, updated_at = ? WHERE id = ?',
                (content, datetime.now().isoformat(), entry_id)
            )
        changed = cursor.rowcount > 0
        if changed:
            cursor.execute('''
                SELECT t.scope FROM knowledge_tabs t JOIN knowledge_entries e
                ON e.tab_id = t.id WHERE e.id = ?
            ''', (entry_id,))
            row = cursor.fetchone()
            tab_scope = row[0] if row else None
        conn.commit()
    if changed and tab_scope:
        try:
            from core.mind_events import publish_mind_changed
            publish_mind_changed('knowledge', tab_scope, 'update')
        except Exception:
            pass
    return changed


def delete_entry(entry_id):
    tab_scope = None
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT t.scope FROM knowledge_tabs t JOIN knowledge_entries e
            ON e.tab_id = t.id WHERE e.id = ?
        ''', (entry_id,))
        row = cursor.fetchone()
        if not row:
            return False
        tab_scope = row[0]
        cursor.execute('DELETE FROM knowledge_entries WHERE id = ?', (entry_id,))
        conn.commit()
    try:
        from core.mind_events import publish_mind_changed
        publish_mind_changed('knowledge', tab_scope, 'delete')
    except Exception:
        pass
    return True


def delete_entries_by_filename(tab_id, filename):
    """Delete all entries in a tab that came from a specific uploaded file."""
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM knowledge_entries WHERE tab_id = ? AND source_filename = ?',
                       (tab_id, filename))
        count = cursor.fetchone()[0]
        if count:
            cursor.execute('DELETE FROM knowledge_entries WHERE tab_id = ? AND source_filename = ?',
                           (tab_id, filename))
            conn.commit()
        return count


def get_tabs_by_id(tab_id):
    """Get a single tab by ID."""
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT id, name, type, scope FROM knowledge_tabs WHERE id = ?', (tab_id,))
        row = cursor.fetchone()
        if not row:
            return None
        return {"id": row[0], "name": row[1], "type": row[2], "scope": row[3]}


# ─── RAG Helpers ─────────────────────────────────────────────────────────────

def get_entries_by_scope(scope):
    """Get all entries in a scope, grouped by source_filename."""
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT e.source_filename, COUNT(*), SUM(LENGTH(e.content))
            FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
            WHERE t.scope = ?
            GROUP BY e.source_filename
        ''', (scope,))
        rows = cursor.fetchall()
        return [{"filename": r[0] or "(untitled)", "chunks": r[1], "chars": r[2]} for r in rows]


def search_rag(query, scope, limit=5, threshold=0.40, max_tokens=4000):
    """Search RAG scope via vector search, token-capped. Strict scope (no global overlay)."""
    embedder = _get_embedder()
    if not embedder or not embedder.available:
        return []

    query_emb = embedder.embed([query], prefix='search_query')
    if query_emb is None:
        return []
    query_vec = query_emb[0]
    query_dim = int(query_vec.shape[0])
    active_provider = getattr(embedder, 'provider_id', None)

    with _get_connection() as conn:
        cursor = conn.cursor()
        # Strict scope match — no global overlay for RAG. Filter by provenance
        # so stale-provider vectors don't corrupt RAG retrieval.
        cursor.execute('''
            SELECT e.id, e.content, t.name, e.embedding, e.source_filename
            FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
            WHERE t.scope = ? AND e.embedding IS NOT NULL
              AND e.embedding_provider = ? AND e.embedding_dim = ?
            ORDER BY e.updated_at DESC LIMIT 10000
        ''', (scope, active_provider, query_dim))
        rows = cursor.fetchall()

    scored = []
    for eid, content, tname, emb_blob, src_file in rows:
        try:
            emb = np.frombuffer(emb_blob, dtype=np.float32)
            if emb.shape[0] != query_dim:
                continue
            sim = float(np.dot(query_vec, emb))
            if np.isnan(sim) or np.isinf(sim):
                continue
            if sim >= threshold:
                scored.append({"content": content, "filename": src_file or tname, "score": sim})
        except Exception:
            continue
    scored.sort(key=lambda x: x["score"], reverse=True)

    # Accumulate up to token budget
    output = []
    token_count = 0
    for r in scored[:limit]:
        chunk_tokens = len(r["content"].split())
        if token_count + chunk_tokens > max_tokens:
            break
        output.append(r)
        token_count += chunk_tokens

    return output


def cleanup_orphaned_rag_scopes(valid_chat_names):
    """Delete RAG scopes whose chat no longer exists. Called at startup."""
    try:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT DISTINCT scope FROM knowledge_tabs WHERE scope LIKE '__rag__:%'")
            rag_scopes = [r[0] for r in cursor.fetchall()]

        if not rag_scopes:
            return

        valid = {f"__rag__:{name}" for name in valid_chat_names}
        orphaned = [s for s in rag_scopes if s not in valid]

        for scope in orphaned:
            result = delete_scope(scope)
            logger.info(f"[RAG] Cleaned up orphaned scope '{scope}': {result}")
    except Exception as e:
        logger.warning(f"[RAG] Orphan cleanup failed: {e}")


def delete_entries_by_scope_and_filename(scope, filename):
    """Delete all entries for a specific file within a RAG scope."""
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            SELECT e.id FROM knowledge_entries e
            JOIN knowledge_tabs t ON e.tab_id = t.id
            WHERE t.scope = ? AND e.source_filename = ?
        ''', (scope, filename))
        entry_ids = [r[0] for r in cursor.fetchall()]
        if entry_ids:
            placeholders = ','.join('?' * len(entry_ids))
            cursor.execute(f'DELETE FROM knowledge_entries WHERE id IN ({placeholders})', entry_ids)
        # Clean up empty tabs
        cursor.execute('''
            DELETE FROM knowledge_tabs WHERE scope = ? AND id NOT IN (
                SELECT DISTINCT tab_id FROM knowledge_entries
            )
        ''', (scope,))
        conn.commit()
        return len(entry_ids)


# ─── Chunking ─────────────────────────────────────────────────────────────────

def _chunk_text(text, max_tokens=400, overlap_tokens=50):
    """Split text into chunks respecting token limits.

    Cascade: split on \\n\\n → \\n → sentence boundaries → hard word split.
    """
    text = text.strip()
    if not text:
        return []

    # --- Break into atomic segments using cascading splitters ---

    # 1. Paragraph breaks (best semantic boundary)
    segments = [p.strip() for p in text.split('\n\n') if p.strip()]
    if not segments:
        return [text]

    # 2. Single line breaks for oversized paragraphs
    refined = []
    for seg in segments:
        if len(seg.split()) <= max_tokens:
            refined.append(seg)
        else:
            refined.extend(l.strip() for l in seg.split('\n') if l.strip())
    segments = refined

    # 3. Sentence boundaries for oversized lines
    refined = []
    for seg in segments:
        if len(seg.split()) <= max_tokens:
            refined.append(seg)
        else:
            parts = re.split(r'(?<=[.!?])\s+(?=[A-Z])', seg)
            refined.extend(s.strip() for s in parts if s.strip())
    segments = refined

    # 4. Hard word-boundary split (last resort)
    refined = []
    for seg in segments:
        if len(seg.split()) <= max_tokens:
            refined.append(seg)
        else:
            words = seg.split()
            for i in range(0, len(words), max_tokens):
                piece = ' '.join(words[i:i + max_tokens])
                if piece:
                    refined.append(piece)
    segments = refined

    # --- Accumulate segments into chunks with overlap ---
    chunks = []
    current = []
    current_len = 0

    for seg in segments:
        seg_len = len(seg.split())
        if current and current_len + seg_len > max_tokens:
            chunks.append('\n\n'.join(current))
            if overlap_tokens > 0 and current:
                last = current[-1]
                if len(last.split()) <= overlap_tokens:
                    current = [last]
                    current_len = len(last.split())
                else:
                    current = []
                    current_len = 0
            else:
                current = []
                current_len = 0
        current.append(seg)
        current_len += seg_len

    if current:
        chunks.append('\n\n'.join(current))

    return chunks if chunks else [text]


# ─── Search ───────────────────────────────────────────────────────────────────

def _sanitize_fts_query(query, use_or=False, use_prefix=False):
    sanitized = re.sub(r'[^\w\s"*]', ' ', query)
    sanitized = re.sub(r'\s+', ' ', sanitized).strip()
    if not sanitized or '"' in sanitized:
        return sanitized
    terms = sanitized.split()
    if use_prefix:
        terms = [t + '*' if not t.endswith('*') else t for t in terms]
    if use_or and len(terms) > 1:
        return ' OR '.join(terms)
    return ' '.join(terms)


def _search_entries(query, scope, category=None, limit=10):
    """Search knowledge entries with cascading FTS + vector + LIKE."""
    with _get_connection() as conn:
        cursor = conn.cursor()

        # Resolve category filter
        scope_sql, scope_params = _scope_condition(scope)
        tab_filter = ""
        tab_params = []
        if category:
            cursor.execute(f'SELECT id FROM knowledge_tabs WHERE LOWER(name) = LOWER(?) AND {scope_sql}',
                           [category] + scope_params)
            tab = cursor.fetchone()
            if not tab:
                return []
            tab_filter = " AND e.tab_id = ?"
            tab_params = [tab[0]]
        else:
            # All tabs in scope
            cursor.execute(f'SELECT id FROM knowledge_tabs WHERE {scope_sql}', scope_params)
            tab_ids = [r[0] for r in cursor.fetchall()]
            if not tab_ids:
                return []
            placeholders = ','.join('?' * len(tab_ids))
            tab_filter = f" AND e.tab_id IN ({placeholders})"
            tab_params = tab_ids

        results = []
        seen_ids = set()

        # Strategy 0: Filename match
        cursor.execute(f'''
            SELECT e.id, e.content, t.name as tab_name, e.source_filename
            FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
            WHERE e.source_filename LIKE ?{tab_filter}
            ORDER BY e.chunk_index LIMIT ?
        ''', [f'%{query}%'] + tab_params + [limit])
        for r in cursor.fetchall():
            results.append({"id": r[0], "content": r[1], "tab": r[2], "file": r[3], "source": "knowledge", "score": 0.96})
            seen_ids.add(r[0])

        # Strategy 1: FTS AND
        fts_results = []
        fts_exact = _sanitize_fts_query(query)
        if fts_exact:
            try:
                cursor.execute(f'''
                    SELECT e.id, e.content, t.name as tab_name, e.source_filename
                    FROM knowledge_fts f
                    JOIN knowledge_entries e ON f.rowid = e.id
                    JOIN knowledge_tabs t ON e.tab_id = t.id
                    WHERE knowledge_fts MATCH ?{tab_filter}
                    ORDER BY bm25(knowledge_fts) LIMIT ?
                ''', [fts_exact] + tab_params + [limit])
                fts_results = cursor.fetchall()

                # Strategy 2: FTS OR + prefix
                if not fts_results:
                    fts_broad = _sanitize_fts_query(query, use_or=True, use_prefix=True)
                    if fts_broad != fts_exact:
                        cursor.execute(f'''
                            SELECT e.id, e.content, t.name as tab_name, e.source_filename
                            FROM knowledge_fts f
                            JOIN knowledge_entries e ON f.rowid = e.id
                            JOIN knowledge_tabs t ON e.tab_id = t.id
                            WHERE knowledge_fts MATCH ?{tab_filter}
                            ORDER BY bm25(knowledge_fts) LIMIT ?
                        ''', [fts_broad] + tab_params + [limit])
                        fts_results = cursor.fetchall()
            except sqlite3.OperationalError as e:
                logger.warning(f"Knowledge FTS query failed: {e}")

    # Add FTS results
    for r in fts_results:
        if r[0] not in seen_ids:
            entry = {"id": r[0], "content": r[1], "tab": r[2], "source": "knowledge", "score": 0.95}
            if r[3]: entry["file"] = r[3]
            results.append(entry)
            seen_ids.add(r[0])

    # Always run vector search — finds semantically related chunks FTS misses
    vec_results = _vector_search_entries(query, scope, category, limit)
    for r in vec_results:
        if r["id"] not in seen_ids:
            results.append(r)
            seen_ids.add(r["id"])

    # LIKE fallback only when nothing else worked
    if not results:
        with _get_connection() as conn:
            cursor = conn.cursor()
            terms = query.lower().split()[:5]
            if terms:
                conditions = ' OR '.join(['e.content LIKE ?' for _ in terms])
                params = [f'%{t}%' for t in terms]
                cursor.execute(f'''
                    SELECT e.id, e.content, t.name as tab_name, e.source_filename
                    FROM knowledge_entries e
                    JOIN knowledge_tabs t ON e.tab_id = t.id
                    WHERE ({conditions}){tab_filter}
                    ORDER BY e.updated_at DESC LIMIT ?
                ''', params + tab_params + [limit])
                for r in cursor.fetchall():
                    if r[0] not in seen_ids:
                        entry = {"id": r[0], "content": r[1], "tab": r[2], "source": "knowledge", "score": 0.35}
                        if r[3]: entry["file"] = r[3]
                        results.append(entry)

    return results


def _backfill_knowledge_embeddings():
    """Generate embeddings + stamp provenance for knowledge_entries and
    people rows that lack either. Called lazily on first vector search.

    Without this, a transient embed failure at write time (remote down during
    add_entry / save_person) permanently stranded the row with NULL embedding
    because there was no backfill path. Scout finding: memory had backfill;
    knowledge/people didn't.
    """
    global _backfill_done
    if _backfill_done:
        return

    embedder = _get_embedder()
    if not embedder or not embedder.available:
        _backfill_done = True
        return

    transient_failure = False
    filled_total = 0
    from core.embeddings import stamp_embedding

    # Knowledge entries
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            'SELECT id, content FROM knowledge_entries '
            'WHERE embedding IS NULL OR embedding_provider IS NULL OR embedding_dim IS NULL'
        )
        entry_rows = cursor.fetchall()

    if entry_rows:
        logger.info(f"Backfilling embeddings for {len(entry_rows)} knowledge entries...")
        batch_size = 32
        for i in range(0, len(entry_rows), batch_size):
            batch = entry_rows[i:i + batch_size]
            ids = [r[0] for r in batch]
            texts = [r[1] for r in batch]
            embs = embedder.embed(texts, prefix='search_document')
            if embs is None:
                transient_failure = True
                break
            try:
                with _get_connection() as conn:
                    cursor = conn.cursor()
                    for row_id, emb in zip(ids, embs):
                        blob, provider_id, dim = stamp_embedding(emb, embedder)
                        cursor.execute(
                            'UPDATE knowledge_entries SET embedding = ?, '
                            'embedding_provider = ?, embedding_dim = ? WHERE id = ?',
                            (blob, provider_id, dim, row_id)
                        )
                    conn.commit()
                    filled_total += len(batch)
            except Exception as e:
                logger.error(f"Knowledge entry backfill batch failed: {e}")
                transient_failure = True
                break

    # People
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            'SELECT id, name, relationship, phone, email, address, notes FROM people '
            'WHERE embedding IS NULL OR embedding_provider IS NULL OR embedding_dim IS NULL'
        )
        people_rows = cursor.fetchall()

    if people_rows and not transient_failure:
        logger.info(f"Backfilling embeddings for {len(people_rows)} people...")
        for pid, name, rel, phone, email, addr, notes in people_rows:
            parts = [name or '']
            if rel: parts.append(f"relationship: {rel}")
            if phone: parts.append(f"phone: {phone}")
            if email: parts.append(f"email: {email}")
            if addr: parts.append(f"address: {addr}")
            if notes: parts.append(f"notes: {notes}")
            embed_text = '. '.join(parts)
            embs = embedder.embed([embed_text], prefix='search_document')
            if embs is None:
                transient_failure = True
                break
            try:
                blob, provider_id, dim = stamp_embedding(embs[0], embedder)
                with _get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute(
                        'UPDATE people SET embedding = ?, embedding_provider = ?, embedding_dim = ? '
                        'WHERE id = ?',
                        (blob, provider_id, dim, pid)
                    )
                    conn.commit()
                    filled_total += 1
            except Exception as e:
                logger.error(f"People backfill row failed: {e}")
                transient_failure = True
                break

    if transient_failure:
        logger.warning(
            f"Knowledge/people backfill incomplete ({filled_total} filled). Will retry next search."
        )
    else:
        _backfill_done = True
        if filled_total:
            logger.info(f"Knowledge/people backfill complete: {filled_total} rows embedded")


def _vector_search_entries(query, scope, category=None, limit=10):
    _backfill_knowledge_embeddings()
    embedder = _get_embedder()
    if not embedder or not embedder.available:
        return []

    query_emb = embedder.embed([query], prefix='search_query')
    if query_emb is None:
        return []
    query_vec = query_emb[0]
    query_dim = int(query_vec.shape[0])
    active_provider = getattr(embedder, 'provider_id', None)

    with _get_connection() as conn:
        cursor = conn.cursor()

        # Filter by provenance: rows from other providers / wrong dim are
        # skipped at the SQL level. Each search is already re-embedding the
        # query under the active provider.
        scope_sql, scope_params = _scope_condition(scope, 't.scope')
        provenance_sql = (
            'e.embedding IS NOT NULL AND e.embedding_provider = ? AND e.embedding_dim = ?'
        )
        provenance_params = [active_provider, query_dim]
        # LIMIT caps per-query memory — 50MB+ RSS spike at 50k rows otherwise.
        # Matches memory_tools.py's ORDER BY updated_at DESC LIMIT 10000. M10.
        if category:
            cursor.execute(f'''
                SELECT e.id, e.content, t.name, e.embedding, e.source_filename
                FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
                WHERE {scope_sql} AND LOWER(t.name) = LOWER(?) AND {provenance_sql}
                ORDER BY e.updated_at DESC LIMIT 10000
            ''', scope_params + [category] + provenance_params)
        else:
            cursor.execute(f'''
                SELECT e.id, e.content, t.name, e.embedding, e.source_filename
                FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
                WHERE {scope_sql} AND {provenance_sql}
                ORDER BY e.updated_at DESC LIMIT 10000
            ''', scope_params + provenance_params)

        rows = cursor.fetchall()

    scored = []
    for eid, content, tname, emb_blob, src_file in rows:
        try:
            emb = np.frombuffer(emb_blob, dtype=np.float32)
            if emb.shape[0] != query_dim:
                continue
            sim = float(np.dot(query_vec, emb))
            if np.isnan(sim) or np.isinf(sim):
                continue
            if sim >= SIMILARITY_THRESHOLD:
                entry = {"id": eid, "content": content, "tab": tname, "source": "knowledge", "score": sim}
                if src_file:
                    entry["file"] = src_file
                scored.append(entry)
        except Exception:
            continue

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:limit]


def _search_people(query, scope='default', limit=10):
    """Search people via vector + LIKE. Only returns actual matches."""
    results = []

    _backfill_knowledge_embeddings()
    # Vector search — use higher threshold for people (their embeddings are dense info strings)
    embedder = _get_embedder()
    if embedder and embedder.available:
        query_emb = embedder.embed([query], prefix='search_query')
        if query_emb is not None:
            query_vec = query_emb[0]
            query_dim = int(query_vec.shape[0])
            active_provider = getattr(embedder, 'provider_id', None)
            with _get_connection() as conn:
                cursor = conn.cursor()
                scope_sql, scope_params = _scope_condition(scope)
                # LIMIT caps per-query memory (150MB+ RSS at 50k rows).
                # ORDER BY updated_at DESC matches memory_tools. M10.
                cursor.execute(
                    f'SELECT id, name, relationship, phone, email, address, notes, embedding '
                    f'FROM people WHERE {scope_sql} AND embedding IS NOT NULL '
                    f'AND embedding_provider = ? AND embedding_dim = ? '
                    f'ORDER BY updated_at DESC LIMIT 10000',
                    scope_params + [active_provider, query_dim]
                )
                rows = cursor.fetchall()
            for pid, name, rel, phone, email, addr, notes, emb_blob in rows:
                try:
                    emb = np.frombuffer(emb_blob, dtype=np.float32)
                    if emb.shape[0] != query_dim:
                        continue
                    sim = float(np.dot(query_vec, emb))
                    if np.isnan(sim) or np.isinf(sim):
                        continue
                    # Higher threshold for people — their dense contact strings match too broadly at 0.40
                    if sim >= 0.55:
                        results.append({"id": pid, "name": name, "relationship": rel,
                                        "phone": phone, "email": email, "address": addr,
                                        "notes": notes, "source": "people", "score": sim})
                except Exception:
                    continue
            results.sort(key=lambda x: x["score"], reverse=True)
            return results[:limit]

    # LIKE fallback (only when embeddings unavailable) — must actually match query terms
    with _get_connection() as conn:
        cursor = conn.cursor()
        terms = query.lower().split()[:5]
        if terms:
            conditions = ' OR '.join(['(LOWER(name) LIKE ? OR LOWER(relationship) LIKE ? OR LOWER(notes) LIKE ?)' for _ in terms])
            params = []
            for t in terms:
                params.extend([f'%{t}%', f'%{t}%', f'%{t}%'])
            scope_sql, scope_params = _scope_condition(scope)
            cursor.execute(f'''
                SELECT id, name, relationship, phone, email, address, notes
                FROM people WHERE {scope_sql} AND ({conditions}) ORDER BY name LIMIT ?
            ''', scope_params + params + [limit])
            rows = cursor.fetchall()
            # LIKE results get a low fixed score so they sort below vector matches
            return [{"id": r[0], "name": r[1], "relationship": r[2], "phone": r[3],
                     "email": r[4], "address": r[5], "notes": r[6], "source": "people", "score": 0.3} for r in rows]

        return []


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _format_person(p):
    pid = f"[id:{p['id']}] " if p.get("id") else ""
    parts = [f"{pid}{p['name']}"]
    if p.get("relationship"): parts.append(f"({p['relationship']})")
    details = []
    if p.get("phone"): details.append(f"phone: {p['phone']}")
    if p.get("email"): details.append(f"email: {p['email']}")
    if p.get("address"): details.append(f"address: {p['address']}")
    if p.get("notes"): details.append(f"notes: {p['notes']}")
    if details:
        parts.append("— " + ", ".join(details))
    return " ".join(parts)


def _expand_with_neighbors(results):
    """For chunked entries, expand with adjacent chunks for surrounding context."""
    if not results:
        return results

    knowledge_results = [r for r in results if r.get("source") == "knowledge" and r.get("file")]
    if not knowledge_results:
        return results

    result_ids = {r["id"] for r in results}
    with _get_connection() as conn:
        cursor = conn.cursor()

        expanded = []
        for r in results:
            if r.get("source") != "knowledge" or not r.get("file"):
                expanded.append(r)
                continue

            cursor.execute(
                'SELECT chunk_index, tab_id FROM knowledge_entries WHERE id = ?',
                (r["id"],))
            row = cursor.fetchone()
            if not row or row[0] is None:
                expanded.append(r)
                continue

            chunk_idx, tab_id = row
            cursor.execute('''
                SELECT id, chunk_index, content FROM knowledge_entries
                WHERE tab_id = ? AND source_filename = ? AND chunk_index IN (?, ?)
                ORDER BY chunk_index
            ''', (tab_id, r["file"], chunk_idx - 1, chunk_idx + 1))
            neighbors = {n[1]: n[2] for n in cursor.fetchall() if n[0] not in result_ids}

            parts = []
            if chunk_idx - 1 in neighbors:
                parts.append(neighbors[chunk_idx - 1])
            parts.append(r["content"])
            if chunk_idx + 1 in neighbors:
                parts.append(neighbors[chunk_idx + 1])

            r = dict(r)
            r["content"] = '\n\n'.join(parts)
            expanded.append(r)

        return expanded


def _format_entry(r, query=None, max_len=4000):
    content = r["content"]
    eid = f"[id:{r['id']}] " if r.get("id") else ""
    tab_info = f"[{r['tab']}] " if r.get("tab") else ""
    file_info = f"[file: {r['file']}] " if r.get("file") else ""

    if len(content) <= max_len:
        preview = content
    else:
        preview = content[:max_len] + '...'

    return f"{tab_info}{file_info}{eid}{preview}"


# ─── Tool Operations ─────────────────────────────────────────────────────────

def _save_person(name, relationship=None, phone=None, email=None, address=None,
                 notes=None, append_notes=None, person_id=None, scope='default'):
    if not name or not name.strip():
        return "Person name is required.", False
    if len(name) > 100:
        return "Name too long (max 100 chars).", False
    if notes is not None and append_notes is not None:
        return "Use notes OR append_notes, not both.", False

    # id-based edit: verify the row exists before we call the backend, which
    # would otherwise fall through to INSERT on a bad id and silently create
    # a duplicate "John" next to the one she meant to edit.
    if person_id is not None:
        with _get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT 1 FROM people WHERE id = ? AND scope = ?', (person_id, scope))
            if not cursor.fetchone():
                return f"Person id {person_id} not found in scope '{scope}'.", False

    # append_notes: fetch current, concat, treat as a notes update. Embedding
    # refreshes because the backend re-embeds on any field change.
    if append_notes is not None:
        with _get_connection() as conn:
            cursor = conn.cursor()
            if person_id:
                cursor.execute('SELECT id, notes FROM people WHERE id = ? AND scope = ?', (person_id, scope))
            else:
                cursor.execute('SELECT id, notes FROM people WHERE LOWER(name) = LOWER(?) AND scope = ?', (name.strip(), scope))
            row = cursor.fetchone()
        if not row:
            return f"Person not found — can't append. Use save_person without append_notes to create.", False
        person_id = row[0]
        existing = row[1] or ''
        notes = (existing + '\n' + append_notes).strip() if existing else append_notes.strip()

    pid, is_new = create_or_update_person(name, relationship, phone, email, address, notes,
                                          scope=scope, person_id=person_id)
    action = "Saved new" if is_new else "Updated"
    logger.info(f"{action} person [{pid}] '{name.strip()}' (scope: {scope})")
    return f"{action} contact: {name.strip()} (ID: {pid})", True


def _save_knowledge(category, content, description=None, scope='default'):
    if not category or not category.strip():
        return "Category name is required.", False
    if not content or not content.strip():
        return "Content is required.", False
    if len(category) > 100:
        return "Category name too long (max 100 chars).", False

    category = category.strip()
    content = content.strip()

    # Get or create category (stored as knowledge_tab)
    with _get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM knowledge_tabs WHERE LOWER(name) = LOWER(?) AND scope = ?',
                       (category, scope))
        row = cursor.fetchone()

    if row:
        tab_id = row[0]
    else:
        tab_id = create_tab(category, scope, description, tab_type='ai')
        if not tab_id:
            # Race condition: another thread created it between our SELECT and INSERT
            with _get_connection() as conn2:
                cursor2 = conn2.cursor()
                cursor2.execute('SELECT id FROM knowledge_tabs WHERE LOWER(name) = LOWER(?) AND scope = ?',
                               (category, scope))
                row2 = cursor2.fetchone()
            tab_id = row2[0] if row2 else None
        if not tab_id:
            return f"Failed to create category '{category}'.", False

    # Chunk if needed
    chunks = _chunk_text(content)
    entry_ids = []
    try:
        for i, chunk in enumerate(chunks):
            eid = add_entry(tab_id, chunk, chunk_index=i)
            entry_ids.append(eid)
    except sqlite3.IntegrityError as e:
        # Most likely the tab was deleted between our SELECT and these INSERTs.
        # Without this guard the user loses their content silently after we've
        # already burned embedding compute. Tell them clearly so they can retry.
        logger.warning(f"Knowledge write to '{category}' (scope '{scope}') hit FK error: {e}. "
                       f"Likely the tab was deleted mid-write. Saved {len(entry_ids)} of {len(chunks)} chunks.")
        partial = f" (partial: {len(entry_ids)}/{len(chunks)} chunks saved)" if entry_ids else ""
        return (f"Category '{category}' was deleted while saving{partial}. "
                f"Re-create it (or pick a different category) and try again."), False

    ids_str = ', '.join(f'id:{eid}' for eid in entry_ids)
    chunk_note = f" ({len(chunks)} chunks)" if len(chunks) > 1 else ""
    logger.info(f"Saved knowledge to '{category}' in scope '{scope}': {len(chunks)} entries")
    return f"Saved to '{category}'{chunk_note} [{ids_str}] — {len(content)} chars", True


def _search_knowledge(query=None, category=None, entry_id=None, limit=10, scope='default', people_scope='default'):
    # Mode 1: Read a single entry in full by ID
    if entry_id:
        with _get_connection() as conn:
            cursor = conn.cursor()
            # Scope filter via the parent tab so an AI in scope `work` can't
            # read entries from `personal` by guessing the integer id. The
            # AI tool description encourages passing ids around — that's
            # safe within scope but used to leak across. Day-ruiner scout
            # 2026-05-07 #B. `_scope_condition` allows the current scope
            # plus the 'global' overlay, matching all other scoped reads.
            scope_sql, scope_params = _scope_condition(scope, 't.scope')
            cursor.execute(f'''
                SELECT e.id, e.content, t.name, t.type
                FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
                WHERE e.id = ? AND {scope_sql}
            ''', [entry_id] + scope_params)
            row = cursor.fetchone()
        if not row:
            return f"Entry {entry_id} not found.", True
        return f"=== Entry [id:{row[0]}] from '{row[2]}' ({row[3]}) ===\n{row[1]}", True

    # Mode 2: Browse a category (no query needed)
    if category and not query:
        with _get_connection() as conn:
            cursor = conn.cursor()
            scope_sql, scope_params = _scope_condition(scope)
            cursor.execute(f'SELECT id FROM knowledge_tabs WHERE LOWER(name) = LOWER(?) AND {scope_sql}',
                           [category] + scope_params)
            tab = cursor.fetchone()
        if not tab:
            return f"Category '{category}' not found in scope '{scope}'.", True
        entries = get_tab_entries(tab[0])
        if not entries:
            return f"Category '{category}' is empty.", True
        lines = [f"=== {category} ({len(entries)} entries) ==="]
        for e in entries:
            lines.append(f"  [id:{e['id']}] {e['content']}")
        return '\n'.join(lines), True

    # Mode 3: Overview (no query, no category, no id)
    if not query:
        lines = []
        people = get_people(people_scope) if people_scope else []
        lines.append(f"=== People ({len(people)}) ===")
        if people:
            for p in people[:10]:
                lines.append(f"  {_format_person(p)}")
            if len(people) > 10:
                lines.append(f"  ... and {len(people) - 10} more")
        else:
            lines.append("  (none)")

        tabs = get_tabs(scope)
        lines.append(f"\n=== Categories (scope: {scope}, {len(tabs)}) ===")
        if tabs:
            for t in tabs:
                type_tag = f" [{t['type']}]" if t['type'] == 'ai' else ""
                lines.append(f"  {t['name']}{type_tag} — {t['entry_count']} entries")
        else:
            lines.append("  (none)")

        # Per-chat uploaded documents
        rag_scope = _get_current_rag_scope()
        if rag_scope:
            rag_docs = get_entries_by_scope(rag_scope)
            if rag_docs:
                lines.append(f"\n=== Uploaded Documents ({len(rag_docs)}) ===")
                for d in rag_docs:
                    lines.append(f"  {d['filename']} — {d['chunks']} chunks, {d['chars']} chars")

        if not lines:
            return "Your knowledge base is empty.", True
        return '\n'.join(lines), True

    # Mode 4: Search (query provided)
    results = []
    if people_scope:
        results.extend(_search_people(query, people_scope, limit))
    results.extend(_search_entries(query, scope, category, limit))
    # Also search per-chat RAG documents
    rag_scope = _get_current_rag_scope()
    if rag_scope:
        rag_results = _vector_search_entries(query, rag_scope, limit=limit)
        seen_ids = {r["id"] for r in results}
        for r in rag_results:
            if r["id"] not in seen_ids:
                r["source"] = "document"
                results.append(r)

    if not results:
        return f"No results for '{query}'.", True

    # Sort all results by score (highest first) — unified ranking across sources
    results.sort(key=lambda r: r.get("score", 0), reverse=True)
    results = results[:limit]

    # Expand chunked entries with neighboring chunks for context
    results = _expand_with_neighbors(results)

    lines = [f"Found {len(results)} results:"]
    for r in results:
        if r["source"] == "people":
            lines.append(f"---\n[Person] {_format_person(r)}")
        elif r["source"] == "document":
            lines.append(f"---\n[Document] {_format_entry(r, query=query)}")
        else:
            lines.append(f"---\n[Knowledge] {_format_entry(r, query=query)}")

    return '\n'.join(lines), True


def _delete_knowledge(entry_id=None, category=None, scope='default'):
    if not entry_id and not category:
        return "Provide id or category to delete.", False

    with _get_connection() as conn:
        cursor = conn.cursor()

        if entry_id:
            # Delete single entry — must belong to an AI tab AND the caller's
            # scope (or 'global'). Without the scope filter, an AI in scope
            # `work` can wipe entries in `personal` with a guessed id. The
            # delete itself happens via `delete_entry` below; gating the
            # lookup here is the simplest spot to enforce scope. Day-ruiner
            # scout 2026-05-07 #B.
            scope_sql, scope_params = _scope_condition(scope, 't.scope')
            cursor.execute(f'''
                SELECT e.id, e.content, t.id, t.name, t.type
                FROM knowledge_entries e JOIN knowledge_tabs t ON e.tab_id = t.id
                WHERE e.id = ? AND {scope_sql}
            ''', [entry_id] + scope_params)
            row = cursor.fetchone()
            if not row:
                return f"Entry {entry_id} not found.", False
            if row[4] != 'ai':
                return f"Cannot delete user-created content (entry {entry_id} in tab '{row[3]}').", False
            tab_id, tab_name_str = row[2], row[3]

        if category and not entry_id:
            # Delete entire category — must be AI type
            cursor.execute('SELECT id, type FROM knowledge_tabs WHERE LOWER(name) = LOWER(?) AND scope = ?',
                           (category, scope))
            row = cursor.fetchone()
            if not row:
                return f"Category '{category}' not found in scope '{scope}'.", False
            if row[1] != 'ai':
                return f"Cannot delete user-created category '{category}'.", False

    if entry_id:
        delete_entry(entry_id)
        preview = row[1][:100] + ('...' if len(row[1]) > 100 else '')
        logger.info(f"AI deleted entry [{entry_id}] from tab '{tab_name_str}'")
        # Auto-delete empty AI tab
        remaining = get_tab_entries(tab_id)
        if not remaining:
            delete_tab(tab_id)
            logger.info(f"Auto-deleted empty AI tab '{tab_name_str}'")
            return f"Deleted entry [id:{entry_id}] from tab '{tab_name_str}': {preview}\nTab '{tab_name_str}' is now empty and was removed.", True
        return f"Deleted entry [id:{entry_id}] from tab '{tab_name_str}': {preview}", True

    if category:
        delete_tab(row[0])
        logger.info(f"AI deleted category '{category}' (scope: {scope})")
        return f"Deleted category '{category}' and all its entries.", True

    return "Nothing to delete.", False


# ─── Executor ─────────────────────────────────────────────────────────────────

def execute(function_name, arguments, config):
    try:
        scope = _get_current_scope()
        people_scope = _get_current_people_scope()

        # People tools check people_scope, knowledge tools check knowledge scope
        if function_name == "save_person":
            if people_scope is None:
                return "People contacts are disabled for this chat.", False
            if people_scope == 'global':
                return "Cannot write to the global scope. Global is read-only for the AI — only the user can add entries there via the UI.", False
            return _save_person(
                name=arguments.get('name'),
                relationship=arguments.get('relationship'),
                phone=arguments.get('phone'),
                email=arguments.get('email'),
                address=arguments.get('address'),
                notes=arguments.get('notes'),
                append_notes=arguments.get('append_notes'),
                person_id=arguments.get('id'),
                scope=people_scope,
            )

        elif function_name == "save_knowledge":
            if scope is None:
                return "Knowledge base is disabled for this chat.", False
            if scope == 'global':
                return "Cannot write to the global scope. Global is read-only for the AI — only the user can add entries there via the UI.", False
            return _save_knowledge(
                category=arguments.get('category'),
                content=arguments.get('content'),
                description=arguments.get('description'),
                scope=scope,
            )

        elif function_name == "search_knowledge":
            # Search spans both scopes — either can be active
            if scope is None and people_scope is None:
                return "Knowledge base is disabled for this chat.", False
            return _search_knowledge(
                query=arguments.get('query'),
                category=arguments.get('category'),
                entry_id=arguments.get('id'),
                # Clamp: LIMIT -1 = unlimited in SQLite — a stray negative
                # would dump the whole scope into one permanent history row.
                limit=min(max(int(arguments.get('limit', 10) or 10), 1), 50),
                scope=scope or 'default',
                people_scope=people_scope,
            )

        elif function_name == "delete_knowledge":
            if scope is None:
                return "Knowledge base is disabled for this chat.", False
            return _delete_knowledge(
                entry_id=arguments.get('id'),
                category=arguments.get('category'),
                scope=scope,
            )

        else:
            return f"Unknown knowledge function '{function_name}'.", False

    except Exception as e:
        logger.error(f"Knowledge function error in {function_name}: {e}", exc_info=True)
        return f"Knowledge system error: {str(e)}", False
