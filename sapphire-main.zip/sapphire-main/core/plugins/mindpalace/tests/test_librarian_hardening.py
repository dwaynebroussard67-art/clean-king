"""Pre-campaign hardening batch (2026-07-19 scout sweep, Batch A+B):

- the groundskeeper latch releases even when a worker crashes pre-try
- _run_messages reports per-message success; degraded runs count as failure
- dedup stamps dedup_at ONLY for messages that completed (no false drain)
- a fully-failed pass spends no cap and writes no ledger
- set_event_dates empty verdict PRESERVES already-resolved dates
- mark_processed: string 'false' is false; importance=true (bool) refused
- atomize refuses non-list parts; promote caps entity names
- dates + mark verbs write ledger children now
- all sheet sections version (no more hard-delete on edit)
- embedder-down backfill does NOT latch
- get_messages_for_llm honors a per-call context_limit override

Package-path imports on purpose (see test_mindpalace_metadata's docstring).
"""
import json
import re

import numpy as np
import pytest

import core.chat.function_manager as fm
from plugins.mindpalace.tools import palace_tools as pt
from plugins.mindpalace.tools import librarian
from plugins.mindpalace.tools import librarian_tools as lt
from plugins.mindpalace.tools import self_tools as st


class _FakeEmbedder:
    provider_id = "fake"

    @property
    def available(self):
        return False

    def embed(self, texts, prefix="search_document"):
        return None


@pytest.fixture(autouse=True)
def _clean_tool_context():
    fm.tool_context.set(None)
    lt.close_pass()
    yield
    fm.tool_context.set(None)
    lt.close_pass()


@pytest.fixture
def palace(tmp_path, monkeypatch):
    monkeypatch.setattr(pt, "_db_path", tmp_path / "mind.db", raising=False)
    monkeypatch.setattr(pt, "_db_initialized", False, raising=False)
    monkeypatch.setattr(pt, "_backfill_done", True, raising=False)
    monkeypatch.setattr(pt, "_get_embedder", lambda: _FakeEmbedder(), raising=False)
    monkeypatch.setattr(librarian, "_snapshots", {}, raising=False)
    monkeypatch.setattr(librarian, "_enabled", lambda: True)
    return pt


def _save(content, scope='default', **kw):
    msg, ok = pt._save_memory(content, scope, **kw)
    assert ok, msg
    return int(re.search(r'ID: (\d+)', msg).group(1))


def _meta(cid):
    with pt._get_connection() as conn:
        raw = conn.execute('SELECT meta FROM chunks WHERE id = ?',
                           (cid,)).fetchone()[0]
    return json.loads(raw) if raw else {}


def _set_vec(cid, vec):
    v = np.asarray(vec, dtype=np.float32)
    v = v / np.linalg.norm(v)
    with pt._get_connection() as conn:
        conn.execute('UPDATE chunks SET embedding = ?, embedding_provider = ?, '
                     'embedding_dim = ? WHERE id = ?',
                     (v.tobytes(), 'fake', v.shape[0], cid))
        conn.commit()


def _passes_today(kind, scope='default'):
    row = next((r for r in librarian.get_status(scope)['scopes']
                if r['pass'] == kind), None)
    return row['passes_today'] if row else 0


# ─── The latch ───────────────────────────────────────────────────────────────

def test_latch_releases_when_worker_crashes(palace, monkeypatch):
    def boom(scope):
        raise ImportError("module vanished mid-reload")
    monkeypatch.setattr(librarian, "_worker_dates", boom)
    librarian.run_blocking('default', kind='dates', chat='librarian-t')
    with librarian._state_lock:
        assert librarian._state['running'] is False        # slot released
        assert 'crashed' in (librarian._state['last_message'] or '')
    # And the NEXT pass can claim — the jam is gone.
    msg, ok = librarian.run_blocking('default', kind='sort', chat='librarian-t')
    assert 'already running' not in msg


# ─── Degraded visibility ─────────────────────────────────────────────────────

def test_run_messages_flags_errors_and_degraded(palace, monkeypatch):
    results = [{'success': True, 'errors': []},
               {'success': True, 'errors': [], 'degraded': 'tool exhaustion'},
               {'success': False, 'errors': ['boom']}]

    class _Exec:
        def run(self, task):
            return results.pop(0)

    class _Sys:
        class continuity_scheduler:
            executor = _Exec()

    import core.api_fastapi as api
    monkeypatch.setattr(api, "get_system", lambda: _Sys)
    monkeypatch.setattr(librarian, "_ensure_toolset_and_chat", lambda: None)
    monkeypatch.setattr(librarian, "_session_snapshot", lambda c, s: '')
    monkeypatch.setattr(librarian, "_persona_for_chat", lambda: 'sapphire')
    oks = librarian._run_messages('default', ['a', 'b', 'c'], {}, 'librarian', 'Test pass',
                                  lambda g, p, t: g, verbs_required=False)
    assert oks == [True, False, False]


def test_run_messages_counts_a_verbless_success_as_failed(palace, monkeypatch):
    """The 2026-10-07 find: a model that replies but never calls a pass verb
    is not a completed message — for dedup that silence used to read as
    'ruled distinct' and drain the cluster. A verb ATTEMPT counts (a refused
    one too: the model acted); the self pass opts out, since a sheet that
    reads true needs no call."""
    calls = []

    class _Exec:
        def run(self, task):
            calls.append(task)
            if len(calls) == 2:          # second message: the model acts — refused, still an attempt
                lt.execute('keep_separate', {'memory_ids': [999]}, None)
            return {'success': True, 'errors': []}

    class _Sys:
        class continuity_scheduler:
            executor = _Exec()

    import core.api_fastapi as api
    monkeypatch.setattr(api, "get_system", lambda: _Sys)
    monkeypatch.setattr(librarian, "_ensure_toolset_and_chat", lambda: None)
    monkeypatch.setattr(librarian, "_session_snapshot", lambda c, s: '')
    monkeypatch.setattr(librarian, "_persona_for_chat", lambda: 'sapphire')
    lt.open_pass('default', [1], kind='dedup')
    oks = librarian._run_messages('default', ['a', 'b'], {}, 'librarian-dedup', 'Dedup pass',
                                  lambda g, p, t: g)
    assert oks == [False, True]
    assert librarian._run_messages('default', ['tend'], {}, 'librarian-self', 'Self pass',
                                   lambda g, p, t: g, verbs_required=False) == [True]


# ─── Dedup: no false drain ───────────────────────────────────────────────────

def _dedup_setup():
    a = _save('Zebra visited the house today')
    b = _save('Zebra came by the house for a visit')
    c = _save('completely unrelated soldering note')
    _set_vec(a, [1, 0, 0])
    _set_vec(b, [1, 0, 0])       # a+b cluster at 1.0
    _set_vec(c, [0, 1, 0])       # clean — no partner
    return a, b, c


def test_dedup_failed_message_leaves_clusters_unstamped(palace, monkeypatch):
    a, b, c = _dedup_setup()
    monkeypatch.setattr(librarian, "_run_messages",
                        lambda *args, **kw: [False])       # message degraded
    msg, ok = librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'failed' in msg.lower() and 'rescan' in msg.lower()
    assert 'dedup_at' not in _meta(a) and 'dedup_at' not in _meta(b)
    assert 'dedup_at' in _meta(c)          # mechanical fact — no LLM needed
    assert _passes_today('dedup') == 0     # failed pass spends nothing


def test_dedup_scan_error_stamps_nothing(palace, monkeypatch):
    """An error is not an empty shelf (scout find 2026-10-30): the scan
    returned {} on any exception, the worker read 'scanned clean' and
    stamped the whole batch dedup_at — one bad blob in a drain filed the
    entire queue as checked. Now the pass fails with nothing stamped."""
    a, b, c = _dedup_setup()

    def boom(*args, **kw):
        raise RuntimeError('odd blob')
    monkeypatch.setattr(librarian, 'find_duplicates', boom)
    msg, _ok = librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'failed' in msg.lower() and 'odd blob' in msg
    for cid in (a, b, c):
        assert 'dedup_at' not in _meta(cid)
    assert _passes_today('dedup') == 0


def test_a_run_owns_one_notification_row(palace, monkeypatch):
    """Krem's ruling 2026-10-30: a round or a drain is ONE row per scope in
    the notification center — the passes inside it move the row's text,
    run_end closes it with the after-action line; a lone ▶ Run now keeps a
    row of its own. The per-verb notes stay in the ledger."""
    import core.notify as notify
    calls = []
    monkeypatch.setattr(notify, 'begin',
                        lambda title, *a, **k: calls.append(('begin', title, k)) or f"n{len(calls)}")
    monkeypatch.setattr(notify, 'tick', lambda rid, **k: calls.append(('tick', rid, k)))
    monkeypatch.setattr(notify, 'finish', lambda rid, **k: calls.append(('finish', rid, k)))
    monkeypatch.setattr(librarian, "_run_messages", lambda *a, **kw: [False])
    _dedup_setup()
    tok = librarian.run_begin('default', 'nightly tending')
    librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    librarian.run_end('default', token=tok)
    assert [c[0] for c in calls] == ['begin', 'tick', 'finish']
    assert calls[0][2]['key'] == 'librarian-run:default'
    assert calls[0][2]['go'] == {'view': 'self'}
    assert calls[1][1] == 'n1' and 'Dedup pass' in calls[1][2]['text']
    assert calls[2][1] == 'n1' and 'nightly tending' in calls[2][2]['body']
    calls.clear()
    librarian.run_blocking('default', kind='dedup', chat='librarian-t')     # no run open
    assert [c[0] for c in calls] == ['begin', 'finish']
    assert calls[0][2]['key'] == 'librarian:default:dedup'


def test_self_pass_never_clears_or_opens_sections(palace):
    """A bad night blanked identity and the next night's 'first tending'
    rewrote it from nothing (scout audit 2026-10-30). During a self pass
    the write path refuses an empty section and a new box; a human from
    the Self page may do both."""
    assert st.write_section('default', 'identity', 'I am Sapphire.')[1]
    lt.open_pass('default', [], kind='self')
    try:
        msg, ok = st.write_section('default', 'identity', '')
        assert not ok and 'never clears' in msg
        msg, ok = st.write_section('default', 'brand-new-box', 'something')
        assert not ok and 'by hand' in msg
        assert st.write_section('default', 'identity', 'I am Sapphire, still.')[1]
    finally:
        lt.close_pass()
    assert st.write_section('default', 'brand-new-box', 'a human may')[1]


def test_self_pass_aborts_when_the_sheet_is_unreadable(palace, monkeypatch):
    _save("one memory so the scope is not empty")
    monkeypatch.setattr(st, '_read_self', lambda *a, **k: ('boom', False))
    monkeypatch.setattr(librarian, '_run_messages',
                        lambda scope, groups, cfg, toolset, name, present, **kw:
                        [bool(present(g, 1, 1)) for g in groups])
    msg, _ok = librarian.run_blocking('default', kind='self', chat='librarian-t')
    assert 'failed' in msg.lower() and 'unreadable' in msg.lower()


def test_dedup_preview_reports_a_failed_scan(palace, monkeypatch):
    from plugins.mindpalace.routes import browse
    _dedup_setup()

    def boom(*args, **kw):
        raise RuntimeError('odd blob')
    monkeypatch.setattr(librarian, 'find_duplicates', boom)
    out, code = browse.librarian_dedup_preview(query={'scope': 'default'})
    assert code == 500 and 'scan failed' in out['error']


def test_dates_presenter_shows_local_day_and_weekday(palace, monkeypatch):
    """`created` is UTC: a 10:30pm EDT save presented as the NEXT day, and
    the model's 'tonight' verdict landed a day late — terminally (scout
    find 2026-10-30). The pass sees the local day plus its weekday name."""
    from zoneinfo import ZoneInfo
    from plugins.mindpalace.tools import temporal
    monkeypatch.setattr(temporal, '_local_tz', ZoneInfo('America/New_York'))
    text = librarian._present_dates(
        [(7, 'events', 'we fly out on Friday', None, 0,
          '2026-07-16T02:30:00+00:00', None)], 'default', 1, 1)
    assert '[7] saved 2026-07-15 (Wednesday)' in text


def test_dedup_verbless_message_leaves_the_cluster_queued(palace, monkeypatch):
    """A message that 'completed' but fired no verb is NOT a judgment (the
    2026-10-07 find: a tool-incapable model's prose read as 'ruled distinct'
    and stamped the whole cluster). Only a verb drains a cluster now; the
    scan's clean ids still stamp mechanically."""
    a, b, c = _dedup_setup()
    monkeypatch.setattr(librarian, "_run_messages", lambda *args, **kw: [True])
    librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'dedup_at' not in _meta(a) and 'dedup_at' not in _meta(b)   # unjudged → requeue
    assert 'dedup_at' in _meta(c)                                       # scanned clean → mechanical


def test_dedup_prose_only_model_through_the_real_executor_contract(palace, monkeypatch):
    """The exact shape of the incident, end to end through _run_messages: a
    clean executor result (success, no errors, not degraded) and no tool
    call. Before: cluster stamped, 'complete: 0 of 1 merged'. Now: the
    message counts as failed, the cluster stays queued, no cap is spent."""
    a, b, c = _dedup_setup()

    class _Exec:
        def run(self, task):
            return {'success': True, 'errors': [],
                    'responses': [{'output': 'Sure! Looking at these memories, they seem similar.'}]}

    class _Sys:
        class continuity_scheduler:
            executor = _Exec()

    import core.api_fastapi as api
    monkeypatch.setattr(api, "get_system", lambda: _Sys)
    monkeypatch.setattr(librarian, "_ensure_toolset_and_chat", lambda: None)
    monkeypatch.setattr(librarian, "_session_snapshot", lambda c, s: '')
    monkeypatch.setattr(librarian, "_persona_for_chat", lambda: 'sapphire')
    msg, ok = librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'failed' in msg.lower() and 'rescan' in msg.lower()
    assert 'dedup_at' not in _meta(a) and 'dedup_at' not in _meta(b)
    assert 'dedup_at' in _meta(c)
    assert _passes_today('dedup') == 0


def test_dedup_keep_separate_is_the_distinct_verdict(palace, monkeypatch):
    """keep_separate: the explicit 'similar, not the same' ruling — stamps
    the group, files a 'distinct' ledger child, counts as handled, and the
    next pass finds nothing left to judge."""
    a, b, c = _dedup_setup()

    def fake_run(scope, groups, cfg, toolset, name, present, **kw):
        msg, ok = lt.execute('keep_separate', {'memory_ids': [a, b]}, None)
        assert ok, msg
        return [True]
    monkeypatch.setattr(librarian, "_run_messages", fake_run)
    msg, ok = librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'complete' in msg.lower()
    for cid in (a, b, c):
        assert 'dedup_at' in _meta(cid)
    assert _passes_today('dedup') == 1
    with pt._get_connection() as conn:
        n = conn.execute("SELECT COUNT(*) FROM ledger WHERE actor='librarian' "
                         "AND action='distinct'").fetchone()[0]
    assert n == 1
    msg, ok = librarian.run_blocking('default', kind='dedup', chat='librarian-t')
    assert 'nothing awaiting' in msg.lower()


def test_keep_separate_guards_like_every_verb(palace):
    a, b, c = _dedup_setup()
    msg, ok = lt.execute('keep_separate', {'memory_ids': [a, b]}, None)
    assert not ok and 'No librarian pass is open' in msg
    lt.open_pass('default', [a, b], kind='sort')
    msg, ok = lt.execute('keep_separate', {'memory_ids': [a, b]}, None)
    assert not ok and 'dedup' in msg                       # wrong pass kind
    lt.open_pass('default', [a], kind='dedup')
    msg, ok = lt.execute('keep_separate', {'memory_ids': [a, b]}, None)
    assert not ok and 'not in the current pass' in msg     # blast shield
    msg, ok = lt.execute('keep_separate', {'memory_ids': 'a'}, None)
    assert not ok
    assert 'dedup_at' not in _meta(a) and 'dedup_at' not in _meta(b)


def test_reopen_dedup_puts_verdicts_back_in_the_queue(palace):
    from plugins.mindpalace.routes import browse
    a, b, c = _dedup_setup()
    assert librarian._stamp_meta_at([a, b, c], 'dedup_at') == 3
    assert librarian._queue_depth('default', 'dedup') == 0
    out = browse.maintenance(body={'action': 'reopen_dedup', 'scope': 'default'})
    assert out['success'] and out['reopened'] == 3
    assert librarian._queue_depth('default', 'dedup') == 3
    with pt._get_connection() as conn:
        n = conn.execute("SELECT COUNT(*) FROM ledger WHERE action='maintenance' "
                         "AND summary LIKE 'reopened 3 dedup%'").fetchone()[0]
    assert n == 1


def test_sort_failed_pass_spends_nothing(palace, monkeypatch):
    _save('an old memory awaiting review')
    monkeypatch.setattr(librarian, "_run_messages",
                        lambda *args, **kw: [False])
    msg, ok = librarian.run_blocking('default', kind='sort', chat='librarian-t')
    assert 'failed' in msg.lower() and 'requeues' in msg.lower()
    assert _passes_today('sort') == 0
    with pt._get_connection() as conn:      # no misleading pass ledger row
        n = conn.execute("SELECT COUNT(*) FROM ledger WHERE actor='librarian'"
                         ).fetchone()[0]
    assert n == 0


# ─── Dates: empty verdict preserves resolved dates ───────────────────────────

def test_dateless_verdict_keeps_existing_dates(palace):
    cid = _save('lunch on the 12th went well')
    with pt._get_connection() as conn:
        m = _meta(cid)
        m.update({'event_dates': ['2026-08-12'], 'event_date_src': 'regex'})
        conn.execute('UPDATE chunks SET meta=? WHERE id=?',
                     (json.dumps(m), cid))
        conn.commit()
    lt.open_pass('default', [cid], kind='dates')
    msg, ok = lt.execute('set_event_dates',
                         {'entries': [{'memory_id': cid, 'dates': []}]}, None)
    assert ok, msg
    m = _meta(cid)
    assert m['event_dates'] == ['2026-08-12']      # the resolver's data stands
    assert m['event_date_src'] == 'regex'
    assert m['temporal_at']                        # verdict still filed
    stats = lt.close_pass()
    actions = {c['action'] for c in stats['ledger']}
    assert 'dateless' in actions                   # and ledgered now


def test_dated_verdict_writes_ledger_child(palace):
    cid = _save('the launch is on the 20th')
    lt.open_pass('default', [cid], kind='dates')
    msg, ok = lt.execute('set_event_dates',
                         {'entries': [{'memory_id': cid,
                                       'dates': ['2026-08-20']}]}, None)
    assert ok, msg
    stats = lt.close_pass()
    assert any(c['action'] == 'dated' for c in stats['ledger'])


# ─── mark_processed hardening ────────────────────────────────────────────────

def test_mark_string_false_does_not_set_favorite(palace):
    cid = _save('an ordinary memory')
    lt.open_pass('default', [cid])
    msg, ok = lt.execute('mark_processed',
                         {'memory_id': cid, 'favorite': 'false'}, None)
    assert ok, msg
    with pt._get_connection() as conn:
        fav = conn.execute('SELECT favorite FROM chunks WHERE id=?',
                           (cid,)).fetchone()[0]
    assert fav == 0
    stats = lt.close_pass()
    assert any(c['action'] == 'marked' for c in stats['ledger'])


def test_mark_bool_importance_refused(palace):
    cid = _save('another ordinary memory')
    lt.open_pass('default', [cid])
    msg, ok = lt.execute('mark_processed',
                         {'memory_id': cid, 'importance': True}, None)
    assert not ok and 'number' in msg


# ─── atomize / promote guards ────────────────────────────────────────────────

def test_atomize_refuses_bare_string(palace):
    cid = _save('lunch')
    lt.open_pass('default', [cid])
    msg, ok = lt.execute('atomize_memory',
                         {'memory_id': cid, 'parts': 'lunch'}, None)
    assert not ok and 'LIST' in msg
    with pt._get_connection() as conn:      # nothing shredded
        n = conn.execute('SELECT COUNT(*) FROM chunks').fetchone()[0]
    assert n == 1


def test_promote_refuses_huge_entity_name(palace):
    cid = _save('a fact about someone important')
    lt.open_pass('default', [cid])
    msg, ok = lt.execute('promote_memory',
                         {'memory_id': cid, 'layer': 'entities',
                          'entity': 'x' * 200}, None)
    assert not ok and 'too long' in msg


# ─── Sheet: every section versions ───────────────────────────────────────────

def test_relationships_edits_archive_not_delete(palace):
    st.write_section('default', 'relationships', 'Krem — builds the boat')
    st.write_section('default', 'relationships', 'Krem — sails the boat')
    with pt._get_connection() as conn:
        rows = conn.execute(
            "SELECT content, json_extract(meta,'$.superseded_at') FROM chunks "
            "WHERE json_extract(meta,'$.section') = 'relationships'").fetchall()
    assert len(rows) == 2                              # old version SURVIVES
    old = next(r for r in rows if r[1] is not None)
    assert 'builds the boat' in old[0]


def test_origin_edits_archive_not_delete(palace):
    st.write_section('default', 'origin', 'It began in a garage.')
    st.write_section('default', 'origin', 'It began with a promise.')
    with pt._get_connection() as conn:
        n = conn.execute(
            "SELECT COUNT(*) FROM chunks WHERE "
            "json_extract(meta,'$.section') = 'origin'").fetchone()[0]
    assert n == 2


# ─── Backfill latch ──────────────────────────────────────────────────────────

def test_backfill_does_not_latch_when_embedder_down(palace, monkeypatch):
    monkeypatch.setattr(pt, "_backfill_done", False, raising=False)
    _save('a row that will lack a vector')
    pt._backfill_embeddings()
    assert pt._backfill_done is False                  # retries next search


# ─── History: per-call context override ──────────────────────────────────────

def test_get_messages_for_llm_context_override():
    from core.chat.history import ConversationHistory
    ch = ConversationHistory()
    ch.messages = [{'role': 'user', 'content': 'x' * 8000},
                   {'role': 'assistant', 'content': 'y' * 8000},
                   {'role': 'user', 'content': 'the tail survives'}]
    small = ch.get_messages_for_llm(context_limit=600)
    big = ch.get_messages_for_llm(context_limit=1_000_000)
    assert len(big) == 3
    assert len(small) < 3
    assert small[-1]['content'] == 'the tail survives'


# ─── Hunt 2026-10-31 ─────────────────────────────────────────────────────────

def _last_run_id():
    with pt._get_connection() as conn:
        return conn.execute("SELECT id FROM ledger WHERE target = 'run' "
                            "ORDER BY id DESC LIMIT 1").fetchone()[0]


def _write_batch(stats, kind='sort'):
    with pt._get_connection() as conn:
        librarian._write_ledger(conn.cursor(), 'default', stats, f'{kind} batch', kind)
        conn.commit()


def _run(fn, args):
    return lt.execute(fn, args, None)


def test_run_end_closes_only_its_own_run(palace):
    """A nightly that started during a drain popped the DRAIN's run and
    closed its row mid-drain. run_begin hands the opener a token; a busy
    scope hands out none; only the matching token closes."""
    tok = librarian.run_begin('default', 'Run ALL (sort)')
    assert tok is not None
    assert librarian.run_begin('default', 'nightly tending') is None     # busy tonight
    librarian.run_end('default')                                          # no token: nothing
    librarian.run_end('default', token=tok + 1)
    assert librarian.run_open('default')
    librarian.run_end('default', token=tok)
    assert not librarian.run_open('default')


def test_revert_leaves_what_changed_since_and_keeps_the_stamps(palace, monkeypatch):
    """Revert is 'undo what THIS run did': a memory retired again since (a
    different stamp) or rated again since stays; a reverted retirement
    keeps librarian_at so the next night does not redo the review; a run
    reverts once."""
    import json
    monkeypatch.setattr(lt, '_importance_enabled', lambda: True)
    a, b, c = _save("ping"), _save("rate me"), _save("clean revert")
    tok = librarian.run_begin('default', 'test run')
    lt.open_pass('default', [a, b, c])
    assert _run('prune_memory', {'memory_id': a, 'reason': 'ping'})[1]
    assert _run('prune_memory', {'memory_id': c, 'reason': 'noise'})[1]
    assert _run('mark_processed', {'memory_id': b, 'importance': 0.8})[1]
    _write_batch(lt.close_pass())
    librarian.run_end('default', token=tok)
    with pt._get_connection() as conn:
        conn.execute("UPDATE chunks SET importance = 0.3 WHERE id = ?", (b,))   # re-rated since
        m = _meta(a)
        m['pruned_at'] = '2099-01-01T00:00:00+00:00'                              # retired again since
        conn.execute("UPDATE chunks SET meta = ? WHERE id = ?", (json.dumps(m), a))
        conn.commit()
    run_id = _last_run_id()
    counts, err = lt.revert_run('default', run_id)
    assert err is None and counts['restored'] == 1 and counts['ratings'] == 0
    assert counts['skipped'] == 2
    assert _meta(a)['pruned_at'].startswith('2099')
    assert 'pruned_at' not in _meta(c) and 'librarian_at' in _meta(c) and 'reverted_at' in _meta(c)
    with pt._get_connection() as conn:
        assert conn.execute('SELECT importance FROM chunks WHERE id = ?', (b,)).fetchone()[0] == 0.3
        led = conn.execute("SELECT summary FROM ledger WHERE action = 'reverted'").fetchone()[0]
    assert 'changed since' in led
    assert lt.revert_run('default', run_id) == (None, 'this run was already reverted')


def test_revert_never_retires_a_favorite_survivor(palace):
    a, b = _save("Zebra visited the house"), _save("Zebra visited the house today")
    _set_vec(a, [1, 0, 0]); _set_vec(b, [1, 0, 0])
    tok = librarian.run_begin('default', 'test run')
    lt.open_pass('default', [a, b], kind='dedup')
    msg, ok = _run('merge_memories', {'memory_ids': [a, b]})
    assert ok, msg
    survivor = int(re.search(r'→ \[(\d+)\]', msg).group(1))
    _write_batch(lt.close_pass(), 'dedup')
    librarian.run_end('default', token=tok)
    with pt._get_connection() as conn:
        conn.execute("UPDATE chunks SET favorite = 1 WHERE id = ?", (survivor,))   # the human starred it
        conn.commit()
    counts, _ = lt.revert_run('default', _last_run_id())
    assert counts['retired'] == 0 and counts['skipped'] == 1
    assert 'pruned_at' not in _meta(survivor) and _meta(a).get('merged_into') == survivor


def test_cap_refused_ids_cannot_be_filed_as_reviewed(palace):
    """After the cap says no, the model's fallback was mark_processed —
    thousands stamped reviewed forever in a drain. A refused id refuses
    the stamp too; it stays in the queue."""
    ids = [_save(f"noise {i}") for i in range(8)]
    lt.open_pass('default', ids)
    assert _run('prune_memory', {'memory_id': ids[0], 'reason': 'ping'})[1]
    assert _run('prune_memory', {'memory_id': ids[1], 'reason': 'ping'})[1]
    msg, ok = _run('prune_memory', {'memory_id': ids[2], 'reason': 'ping'})
    assert not ok and 'mark_processed the rest' in msg
    msg, ok = _run('mark_processed', {'memory_id': ids[2]})
    assert not ok and 'refused by the retirement cap' in msg
    assert 'librarian_at' not in _meta(ids[2])
    assert _run('mark_processed', {'memory_id': ids[3]})[1]
    assert lt.close_pass()['capped'] == 'pass'


def test_dedup_is_exempt_from_the_share_and_its_refusal_names_no_verb(palace, monkeypatch):
    ids = [_save("the same note" + " again" * i) for i in range(6)]
    for i in ids:
        _set_vec(i, [1, 0, 0])
    lt.open_pass('default', ids, kind='dedup')
    msg, ok = _run('merge_memories', {'memory_ids': ids})   # retires 5 of 6 presented
    assert ok, msg
    _write_batch(lt.close_pass(), 'dedup')                    # tonight's count: 5
    monkeypatch.setattr(lt, '_retire_per_night', lambda: 5)
    c, d = _save("Zebra visited the house"), _save("Zebra visited the house today")
    _set_vec(c, [0, 1, 0]); _set_vec(d, [0, 1, 0])
    assert not lt.night_capped('default')
    lt.open_pass('default', [c, d], kind='dedup')
    msg, ok = _run('merge_memories', {'memory_ids': [c, d]})
    assert not ok and 'another night' in msg and 'mark_processed' not in msg
    assert lt.close_pass()['capped'] == 'night'
    assert lt.night_capped('default') and not lt.night_capped('default')


def test_night_count_charges_a_merge_its_losers(palace, monkeypatch):
    from plugins.mindpalace.tools import ledger as lg
    monkeypatch.setattr(lt, '_retire_per_night', lambda: 2)
    lg.record('default', 'librarian', 'merged', target=1, summary='earlier tonight',
              detail={'members': [1, 2, 3]})                       # a 3-merge = 2 retirements
    ids = [_save(f"noise {i}") for i in range(4)]
    lt.open_pass('default', ids)
    msg, ok = _run('prune_memory', {'memory_id': ids[0], 'reason': 'ping'})
    assert not ok and 'tonight' in msg.lower()


def test_fact_gap_is_unicode_and_forgives_paraphrase():
    assert lt._fact_gap("Zoë and José came at 3pm on March 3",
                        ["Zoë and José came at 3pm on March 3, with cake"]) == []
    assert lt._fact_gap("We met the team",
                        ["Then we met Zoë, José and Kirill at 7:30"]) == ['zoë', 'josé', 'kirill', '7:30']
    assert lt._fact_gap("the dog ran home", ["The dog ran home. Later it slept."]) == []
    assert lt._grounding_gap("Zoë visited José", ["Zoë visited", "José was visited"]) is None


def test_self_pass_skips_an_empty_scope(palace, monkeypatch):
    monkeypatch.setattr(librarian, '_run_messages', lambda *a, **k: [True, True])
    msg, _ok = librarian.run_blocking('default', kind='self', chat='librarian-t')
    assert 'no memories yet' in msg


def test_preview_shows_the_error_not_an_empty_queue(palace, monkeypatch):
    _save("one memory")
    monkeypatch.setattr(st, '_read_self', lambda *a, **k: ('boom', False))
    out = librarian.preview_message('default', 'self', stage='tend')
    assert not out['live'] and 'preview failed' in out['text'] and 'unreadable' in out['text']


def test_one_date_verdict_per_memory_per_pass(palace):
    """The dev drain (2026-10-31): 357 rows, 652 verdicts — a model that
    re-sends earlier entries dated one memory sixteen times. The second
    verdict refuses; the first stands."""
    a = _save("we met on 2026-03-03 at the dock")
    lt.open_pass('default', [a], kind='dates')
    msg, ok = _run('set_event_dates', {'entries': [
        {'memory_id': a, 'dates': ['2026-03-03']},
        {'memory_id': a, 'dates': ['2026-03-04']}]})
    assert ok and 'already filed' in msg
    msg, ok = _run('set_event_dates', {'entries': [{'memory_id': a, 'dates': ['2026-03-05']}]})
    assert not ok and 'already filed' in msg
    assert _meta(a)['event_dates'] == ['2026-03-03']
    lt.close_pass()


def test_backfill_re_embeds_rows_stamped_by_another_provider(palace, monkeypatch):
    """The latch holds the provenance it completed under: a provider swap
    re-opens it, and rows under the old provider are re-embedded alongside
    the NULL ones (migration hunt 2026-11-01, C3)."""
    import numpy as np

    def live(pid):
        return type('E', (), {'provider_id': pid, 'dimension': 3, 'available': True,
                              'embed': lambda self, t, prefix='': [np.ones(3, dtype=np.float32) for _ in t]})()
    monkeypatch.setattr(pt, '_get_embedder', lambda: live('fake2'), raising=False)
    monkeypatch.setattr(pt, '_backfill_done', False, raising=False)
    with pt._get_connection() as conn:
        now = pt._now()
        conn.execute("INSERT INTO chunks (layer, scope, content, created, updated, embedding, "
                     "embedding_provider, embedding_dim) VALUES ('events', 'default', 'old vector', ?, ?, ?, 'old', 3)",
                     (now, now, b'\x00' * 12))
        conn.execute("INSERT INTO chunks (layer, scope, content, created, updated) "
                     "VALUES ('events', 'default', 'never embedded', ?, ?)", (now, now))
        conn.commit()
    pt._backfill_embeddings()
    with pt._get_connection() as conn:
        stamps = {r[0] for r in conn.execute("SELECT embedding_provider FROM chunks")}
    assert stamps == {'fake2'} and pt._backfill_done == ('fake2', 3)
    monkeypatch.setattr(pt, '_get_embedder', lambda: live('fake3'), raising=False)
    pt._backfill_embeddings()                                   # the swap re-opens the latch
    with pt._get_connection() as conn:
        stamps = {r[0] for r in conn.execute("SELECT embedding_provider FROM chunks")}
    assert stamps == {'fake3'} and pt._backfill_done == ('fake3', 3)


def test_sweep_never_overwrites_an_edit_made_during_the_pass(palace, monkeypatch):
    """The sweep snapshots (id, text) then wrote unconditionally: an edit in the
    middle got the OLD text's vector over its new one (hunt of the hunt H4).
    Now a row is written only if its words are still the ones embedded, and
    the next pass picks up the new text."""
    import numpy as np
    seen = []

    class _Live:
        provider_id, dimension, available = 'fake2', 3, True

        def embed(self, texts, prefix=''):
            seen.append(list(texts))
            if len(seen) == 1:                       # the edit lands while we embed the old words
                with pt._get_connection() as conn:
                    conn.execute("UPDATE chunks SET content = 'new words', embedding = NULL, "
                                 "embedding_provider = NULL, embedding_dim = NULL WHERE content = 'old words'")
                    conn.commit()
            return [np.ones(3, dtype=np.float32) for _ in texts]
    monkeypatch.setattr(pt, '_get_embedder', lambda: _Live(), raising=False)
    monkeypatch.setattr(pt, '_backfill_done', False, raising=False)
    with pt._get_connection() as conn:
        now = pt._now()
        conn.execute("INSERT INTO chunks (layer, scope, content, created, updated) "
                     "VALUES ('events', 'default', 'old words', ?, ?)", (now, now))
        conn.commit()
    pt._backfill_embeddings()
    with pt._get_connection() as conn:
        rows = conn.execute("SELECT content, embedding_provider FROM chunks").fetchall()
    assert rows == [('new words', 'fake2')] and seen == [['old words'], ['new words']]
    assert pt._backfill_done == ('fake2', 3)


def test_one_sweep_at_a_time_whoever_asks(palace, monkeypatch):
    """The import kick started a second sweep beside the search's (H5)."""
    monkeypatch.setattr(pt, '_backfill_done', False, raising=False)
    monkeypatch.setattr(pt, '_backfill_running', True, raising=False)   # one is running
    calls = []
    monkeypatch.setattr(pt, '_sweep', lambda: calls.append(1))
    pt._backfill_embeddings()
    pt._backfill_embeddings(background=True)
    assert calls == []
    monkeypatch.setattr(pt, '_backfill_running', False, raising=False)
    pt._backfill_embeddings()
    assert calls == [1] and pt._backfill_running is False
