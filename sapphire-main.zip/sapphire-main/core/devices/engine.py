# core/devices/engine.py - the device engine (tmp/device-manager-plan.md)
#
# ONE module holds the rows, loads the drivers, and answers every question.
# The three tools (functions/devices.py) and the routes (core/routes/devices.py)
# are thin doors into it: the Test button and device_status are one function,
# the Try button and device_action are one function.
#
# Core since 2026-09-27 (the ruling: satellites make voice a device matter,
# and devices are never meant to be switched off). Drivers are NOT core: a
# plugin that knows a transport declares one in its manifest
# (capabilities.devices) and registry.py holds the list.
#
# A device row (user/plugin_state/devices.json, key "devices"):
#   {"id", "label", "location", "enabled", "created", "locked": [...],
#    "parts": [{"driver", "plugin", "config": {...}}]}
# "locked" names the capabilities SHE may not use on this device. The user's
# own buttons on the Devices page always work. Only the capabilities in
# LOCKABLE carry that switch. A row without the key uses its drivers' defaults.
# "location" is the room or place, in the user's words. She reads it in
# device_list and at the top of anything a device hears.
# A part's config may hold one FILTER (a field of type "found"): which of the
# things its driver can see count as this device. {"all": bool, "only":
# [{"id", "name"}]}. The engine applies it (passing()). Things that come and
# go are kept by presence.py.
# A part may hold "has": the capabilities the DEVICE ITSELF said it has (its
# driver's status() answered 'has'). From then on the device shows only
# those, also while it is offline. A part without the key has everything its
# driver can do: a device that never said.
# A part may hold "takes": the finer things the device said it takes (its
# driver's status() answered 'takes', names like "screen.flip"). A config
# field that names one (`takes`) is shown only on a device that takes it. A
# part without the key takes everything: a device that never said.
# The file kept its place when the engine moved into core, so no device list
# ever had to be migrated. Secrets never sit in a row. They live in
# secret_store.py under "<driver>.<field>".

import importlib
import json
import logging
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

STORE = 'devices'          # the state file's name: user/plugin_state/devices.json
ID_RE = re.compile(r'[a-z0-9][a-z0-9_-]{0,32}$')
MAX_DEVICES = 64
MAX_PARTS = 4        # connections on one device
MAX_ROWS = 50            # items in one rows field
MAX_PICTURES = 4         # pictures one action may answer with
MAX_PICTURE = 12 * 1024 * 1024       # characters of base64 in one picture
PICTURE_TYPES = ('image/jpeg', 'image/png', 'image/webp')
LOCKABLE = ('power', 'camera', 'screen', 'mic', 'storage', 'ptz', 'sms', 'wake')    # these carry a "Sapphire may use this" switch (wake: its install restarts the board, 2026-10-19)
MAX_FOUND = 64           # things one driver may report as found
ALL = 'all'              # the composite device: her voice on every device that can speak
RESERVED = ('found', ALL, 'firmware', 'provision', 'here', 'flash')   # names a device may not have: the routes and `all` use them
CLEAR = '__CLEAR__'
KEPT = 'set'            # what public() shows for a stored secret; sent back, it means "as it is"
PAGE = 'Settings > Devices'
SCREEN = 4000            # characters of one help screen, about 1k tokens
MOST = 8                 # actions a capability shows when the screen is over that
READINGS = 4             # readings on the head of a help screen
FLEET_ENUM = 10          # devices or fewer: the tool schema lists their names

_lock = threading.RLock()
_modules = {}            # driver id -> loaded driver module
_modules_gen = None
_pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix='device-status')   # health.py probes on it


class DeviceError(Exception):
    """A message fit to show her or the user as it is."""


# --- doors to core (patched in tests) ----------------------------------------

def _store():
    from core.plugin_loader import plugin_loader
    return plugin_loader.get_plugin_state(STORE)


def _secrets():
    from core.devices import secret_store
    return secret_store


def _health():
    from core.devices import health
    return health


def _registry():
    """The registry, with the drivers that ship inside core always present.
    They are registered here, on first use, because nothing at boot may
    import a driver."""
    from core.devices import registry
    for name in registry.CORE_DRIVERS:
        if not registry.has(name):
            try:
                mod = importlib.import_module(f"core.devices.drivers.{name}")
                registry.register_driver(name, mod.SPEC, registry.CORE, builtin=True)
            except Exception as e:
                logger.error(f"[DEVICES] core driver '{name}' failed to load: {e}", exc_info=True)
    return registry


def _managed():
    from core.settings_manager import settings
    return bool(settings.is_managed())


def refusal():
    """Why devices cannot be used on this install, or ''. A hosted Sapphire
    has no home network: its devices would be the hosting company's."""
    try:
        if _managed():
            return "Devices are not available on hosted Sapphire."
    except Exception as e:
        logger.warning(f"[DEVICES] could not tell whether this install is hosted: {e}")
    return ''


def _plugin_info(name):
    from core.plugin_loader import plugin_loader
    return plugin_loader.get_plugin_info(name)


def _all_plugin_info():
    from core.plugin_loader import plugin_loader
    return plugin_loader.get_all_plugin_info()


def _function_manager():
    from core.api_fastapi import get_system
    return get_system().llm_chat.function_manager


def _changed():
    """A device was added, changed or removed: presence looks again, and the
    tool descriptions are rebuilt (they carry the fleet)."""
    try:
        from core.devices import presence
        presence.poke()
    except Exception as e:
        logger.warning(f"[DEVICES] presence could not be told of a change: {e}")
    retell()


def retell():
    """The device tools' descriptions name the devices, what each can do,
    and whether it is online (functions/devices.py get_tools). Rebuild them.
    Never raises: before the system is up there is nothing to rebuild."""
    try:
        _function_manager().refresh_core_tool_descriptions()
    except Exception as e:
        logger.debug(f"[DEVICES] tool descriptions not rebuilt: {e}")


# --- rows --------------------------------------------------------------------

def _slug(name):
    return str(name or '').strip().lower()


def _name_from(label):
    """A device id from what the user called it: 'Kitchen Pocket' -> 'kitchen-pocket'."""
    return re.sub(r'[^a-z0-9_-]+', '-', _slug(label)).strip('-_')[:33]


def _place(text):
    """A location as one short line."""
    return ' '.join(str(text or '').split())[:60]


def rows():
    """Every device row, by id. A copy - callers may change it freely."""
    data = _store().get('devices', {}) or {}
    return json.loads(json.dumps({k: v for k, v in sorted(data.items()) if isinstance(v, dict)}))


def look_soon(device_id):
    """Have the health keeper look at this device soon. A save calls it AFTER the device was told its
    settings, never before: a probe landing mid-save sent the wake word under the save's own send and the
    board restarted under it (2026-10-19)."""
    _health().poke(_slug(device_id))


def get(device_id):
    row = rows().get(_slug(device_id))
    if not row:
        raise DeviceError(f"There is no device named '{device_id}'.")
    return row


def _write(mutator):
    """Atomic read-change-write of the whole table. mutator(table) edits in place."""
    def step(table):
        table = dict(table or {})
        mutator(table)
        return table
    _store().update_with_lock('devices', step, default={})


# --- drivers -----------------------------------------------------------------

def drivers():
    """Every driver a plugin declares: the usable ones, and the ones whose
    plugin is off (greyed in the UI, with the plugin to enable)."""
    ready = {d['driver']: d for d in _registry().list_drivers()}
    out = [dict(d, available=True, note='') for d in ready.values()]
    try:
        for info in _all_plugin_info():
            manifest = (info or {}).get('manifest') or {}
            for dd in (manifest.get('capabilities', {}).get('devices') or []):
                did = _slug(dd.get('driver')) if isinstance(dd, dict) else ''
                if not did or did in ready or any(o['driver'] == did for o in out):
                    continue
                title = manifest.get('short_display_name') or info['name']
                out.append({'driver': did, 'label': str(dd.get('label') or did),
                            'kind': str(dd.get('kind') or dd.get('label') or did),
                            'icon': str(dd.get('icon') or ''), 'module': '',
                            'capabilities': [str(c) for c in (dd.get('capabilities') or [])],
                            'config_schema': [], 'plugin_name': info['name'],
                            'available': False,
                            'note': f"Enable the {title} plugin to use this"})
    except Exception as e:
        logger.warning(f"[DEVICES] could not list drivers of disabled plugins: {e}")
    return sorted(out, key=lambda d: (not d['available'], d['label'].lower()))


def _driver(driver_id, plugin_hint=''):
    """(module, spec) of a driver that may run right now, or DeviceError."""
    global _modules_gen
    spec = _registry().get_driver(driver_id)
    if not spec:
        who = plugin_hint or driver_id
        raise DeviceError(f"The '{driver_id}' driver is not loaded. Enable the "
                          f"{who} plugin in Settings > Plugins.")
    if plugin_hint and spec['plugin_name'] != plugin_hint:
        # a row keeps the plugin it was set up with: another plugin taking the
        # same driver id must never be handed this device's secrets
        raise DeviceError(f"This device was set up with the {plugin_hint} plugin's '{driver_id}' "
                          f"driver; the one loaded now is {spec['plugin_name']}'s. It stays untouched.")
    if spec['plugin_name'] == _registry().CORE:       # ships inside core: always there
        try:
            return importlib.import_module(f"core.devices.drivers.{driver_id}"), spec
        except Exception as e:
            logger.error(f"[DEVICES] core driver '{driver_id}' failed to import: {e}", exc_info=True)
            raise DeviceError(f"The '{driver_id}' driver failed to load: {e}")
    # The owning plugin must still be enabled and loaded - checked on every
    # call, not only at first import (game-room finding 4.14).
    info = _plugin_info(spec['plugin_name'])
    if not info or not (info.get('enabled') and info.get('loaded')):
        raise DeviceError(f"The {spec['plugin_name']} plugin is off, so its "
                          f"'{driver_id}' driver cannot run.")
    with _lock:
        gen = _registry().generation()
        if gen != _modules_gen:          # a plugin came, went, or reloaded
            for mod in _modules.values():
                sys.modules.pop(mod.__name__, None)
            _modules.clear()
            _modules_gen = gen
        mod = _modules.get(driver_id)
        if mod is None:
            dotted = spec['module'][:-3].replace('/', '.')
            try:
                mod = importlib.import_module(f"plugins.{spec['plugin_name']}.{dotted}")
            except Exception as e:
                logger.error(f"[DEVICES] driver '{driver_id}' failed to import: {e}", exc_info=True)
                raise DeviceError(f"The '{driver_id}' driver failed to load: {e}")
            missing = [fn for fn in ('describe', 'status', 'run') if not callable(getattr(mod, fn, None))]
            if missing:
                raise DeviceError(f"The '{driver_id}' driver is missing {', '.join(missing)}().")
            _modules[driver_id] = mod
    return mod, spec


def _call_tool_for(plugin, uses=()):
    """The tool door handed to a driver: it runs one of its OWN plugin's tools
    through the function manager - same executor, same state, same gates.
    A driver that ships inside core owns no plugin. It may run the tools it
    names in its SPEC (`uses_tools`), so core holds no second copy of what a
    plugin already does."""
    def call_tool(name, args=None):
        fm = _function_manager()
        owner = fm.tool_plugin(name)
        if plugin == _registry().CORE:
            if name not in uses or not owner:
                return f"'{name}' is not there to be used. Its plugin may be switched off.", False
        elif owner != plugin:
            return f"The {plugin} driver may only run its own plugin's tools, not '{name}'.", False
        return fm.execute_function(name, dict(args or {}), allowed_tools={name}, with_success=True)
    return call_tool


def _part_secrets(device_id, driver_id):
    """This part's secrets, keyed by bare field name. Raises DeviceError when
    a stored secret cannot be read on this machine."""
    mod = _secrets()
    try:
        every = mod.resolve(device_id)
    except Exception as e:
        raise DeviceError(str(e))
    prefix = driver_id + '.'
    return mod.Secrets(device_id, {f[len(prefix):]: every.get(f)
                                   for f in every.fields() if f.startswith(prefix)})


# --- config ------------------------------------------------------------------

def _is_rows(field):
    return field.get('widget') == 'rows' or field.get('type') == 'rows'


def _columns(field):
    return [c if isinstance(c, str) else str(c.get('key') or '')
            for c in (field.get('columns') or []) if c]


def _is_found(field):
    return field.get('widget') == 'found' or field.get('type') == 'found'


def _is_bindings(field):
    return field.get('type') == 'bindings'


_SLOT = re.compile(r'[a-z0-9][a-z0-9_.-]{0,39}$')
_DO = re.compile(r'[a-z0-9][a-z0-9_-]{0,23}$')
MAX_SLOTS = 32           # slots one bindings field keeps
MAX_OPTIONS = 200        # choices one dynamic select offers
BINDING_TEXT = 500       # characters of the text a pick may carry


def _bound(value):
    """A bindings field as it is stored: {slot: {'do': name, 'text': words}}.
    A slot is something of the device's that can be given a job (a button's
    short press); 'do' names the job from the menu its driver offers. A slot
    with no job is not kept."""
    out = {}
    for slot, pick in (value.items() if isinstance(value, dict) else ()):
        pick = pick if isinstance(pick, dict) else {'do': pick}
        slot, do = _slug(slot), _slug(pick.get('do'))
        if _SLOT.match(slot) and _DO.match(do) and len(out) < MAX_SLOTS:
            out[slot] = {'do': do, 'text': ' '.join(str(pick.get('text') or '').split())[:BINDING_TEXT]}
    return out


def _menu(row, part, field):
    """What a bindings field offers on this device, from its driver's
    bindings(device, config, key): {'slots': [{'key', 'label', 'own'}],
    'choices': [{'value', 'label', 'text'?}], 'note'}. Never raises."""
    try:
        mod, _ = _driver(part['driver'], part.get('plugin', ''))
        said = mod.bindings(dict(_brief(row), has=part.get('has')), dict(part.get('config') or {}), field['key'])
        return said if isinstance(said, dict) else {}
    except Exception as e:
        logger.warning(f"[DEVICES] {row['id']}: {part['driver']} could not say what {field['key']} offers: {e}")
        return {}


def _options(row, part, field):
    """What a dynamic select offers on this device, from its driver's
    options(device, config, key) -> [{'value', 'label'}]: a list that is this
    device's own (the wake words of the family it runs). Never raises. The
    stored value is always among the choices, so a save round-trips even when
    the driver cannot say (the library unreadable, a model since removed)."""
    out = []
    try:
        mod, _ = _driver(part['driver'], part.get('plugin', ''))
        said = mod.options(dict(_brief(row), has=part.get('has'), takes=part.get('takes'),
                                fingerprint=str(row.get('fingerprint') or '')),
                           dict(part.get('config') or {}), field['key'])
        for o in said if isinstance(said, (list, tuple)) else []:
            if isinstance(o, dict) and 'value' in o:
                out.append({'value': str(o['value'])[:200], 'label': str(o.get('label') or o['value'])[:80]})
    except Exception as e:
        logger.warning(f"[DEVICES] {row['id']}: {part['driver']} could not say what {field['key']} offers: {e}")
    out = out[:MAX_OPTIONS]
    have = str((part.get('config') or {}).get(field['key']) or '')
    if have and have not in [o['value'] for o in out]:
        out.append({'value': have, 'label': f"{have} (not in the library now)"})
    return out


def _picks(field, value):
    """A filter as it is stored: {'all': bool, 'only': [{'id', 'name'}]}.
    Never set = everything counts. "only" is kept while "all" is on, so the
    user's ticks are still there when they switch back."""
    value = value if isinstance(value, dict) else {}
    only, seen = [], set()
    for item in (value.get('only') if isinstance(value.get('only'), list) else []):
        ident = str(item.get('id') or '').strip()[:200] if isinstance(item, dict) else ''
        if ident and ident not in seen:
            seen.add(ident)
            only.append({'id': ident, 'name': ' '.join(str(item.get('name') or ident).split())[:80]})
    every = value.get('all', True)
    if isinstance(every, str):
        every = every.strip().lower() in ('1', 'true', 'yes', 'on')
    return {'all': bool(every), 'only': only[:MAX_FOUND if field.get('many', True) else 1]}


def _coerce(field, value):
    default = field.get('default')
    if _is_found(field):
        return _picks(field, value)
    if _is_bindings(field):
        return _bound(value)
    if _is_rows(field):
        cols = _columns(field)
        out = []
        for item in (value if isinstance(value, list) else []):
            if not isinstance(item, dict):
                continue
            row = {c: str(item.get(c) or '').strip()[:1000] for c in cols}
            if any(row.values()):
                out.append(row)
        return out[:MAX_ROWS]
    kind = field.get('type')
    if kind == 'boolean':
        if isinstance(value, str):
            return value.strip().lower() in ('1', 'true', 'yes', 'on')
        return bool(value)
    if kind == 'number':
        try:
            n = float(value)
            return int(n) if n == int(n) else n
        except (TypeError, ValueError):
            return default if isinstance(default, (int, float)) else 0
    text = '' if value is None else str(value).strip()[:2000]
    options = [str(o.get('value')) for o in (field.get('options') or []) if isinstance(o, dict)]
    if options and text not in options:
        return str(default) if str(default) in options else options[0]
    return text


def _clean(schema, incoming, previous):
    """(config, secret_ops) from a submitted form. Only schema keys survive.
    secret_ops: {field: str to store | None to forget}; a field that was not
    sent is kept as it is."""
    incoming = incoming if isinstance(incoming, dict) else {}
    config, ops = {}, {}
    for field in schema:
        key = field['key']
        if field.get('secret'):
            if key in incoming and incoming[key] != KEPT:    # the page's own word for "stored" is not a key
                v = incoming[key]
                ops[key] = None if v in ('', None, CLEAR) else str(v)[:16000]
            continue
        if key in incoming:
            config[key] = _coerce(field, incoming[key])
        elif key in previous:
            config[key] = previous[key]
        else:
            config[key] = _coerce(field, field.get('default'))
    return config, ops


def _apply_secrets(device_id, driver_id, ops):
    """Store or forget each secret. Returns the fields that failed."""
    failed = []
    for field, value in ops.items():
        name = f"{driver_id}.{field}"
        done = _secrets().clear(device_id, name) if value is None else _secrets().put(device_id, name, value)
        if not done:
            failed.append(field)
    return failed


def _part(row, driver_id):
    return next((p for p in row.get('parts', []) if p.get('driver') == driver_id), None)


# --- what is here right now ----------------------------------------------------

def found(driver_id, config=None):
    """What a driver can see right now: [{'id', 'name', 'kind'}], by name.
    A thing may carry a `note` (a line under it) and `actions` ([{'do',
    'label'}], at most three buttons) for what is done to it BEFORE it is a
    device: a phone is paired in the pick list (setup_found). A driver
    without discover() sees nothing. Raises DeviceError."""
    mod, _ = _driver(_slug(driver_id))
    look = getattr(mod, 'discover', None)
    if not callable(look):
        return []
    try:
        told = look(dict(config or {})) or []
    except Exception as e:
        logger.error(f"[DEVICES] {driver_id}.discover failed: {e}", exc_info=True)
        raise DeviceError(f"The '{driver_id}' driver could not look ({type(e).__name__}).")
    out, seen = [], set()
    for item in told if isinstance(told, (list, tuple)) else []:
        ident = str(item.get('id') or '').strip()[:200] if isinstance(item, dict) else ''
        if not ident or ident in seen:
            continue
        seen.add(ident)
        thing = {'id': ident, 'name': ' '.join(str(item.get('name') or ident).split())[:80],
                 'kind': ' '.join(str(item.get('kind') or '').split())[:24]}
        note = ' '.join(str(item.get('note') or '').split())[:200]
        if note:
            thing['note'] = note
        actions = [{'do': _slug(a.get('do')), 'label': ' '.join(str(a.get('label') or a.get('do')).split())[:24]}
                   for a in (item.get('actions') or []) if isinstance(a, dict) and _slug(a.get('do'))]
        if actions:
            thing['actions'] = actions[:3]
        out.append(thing)
        if len(out) >= MAX_FOUND:
            break
    return sorted(out, key=lambda t: (t['name'].lower(), t['id']))


def setup_found(driver_id, thing_id, action, config=None):
    """One of a found thing's actions, before it is a device: the driver's
    setup(thing_id, action, config) -> (text, ok). {'text', 'ok'}. Raises
    DeviceError when the driver sets nothing up, or the words are missing."""
    mod, spec = _driver(_slug(driver_id))
    fn = getattr(mod, 'setup', None)
    if not callable(fn):
        raise DeviceError(f"The '{driver_id}' driver sets nothing up before a device is added.")
    thing_id, action = str(thing_id or '').strip()[:200], _slug(action)
    if not thing_id or not action:
        raise DeviceError("Say which thing, and what to do with it.")
    try:
        told, ok = fn(thing_id, action, dict(config or {}))
    except DeviceError:
        raise
    except Exception as e:
        logger.error(f"[DEVICES] {driver_id}.setup({action}) failed: {e}", exc_info=True)
        raise DeviceError(f"The '{driver_id}' driver could not do that ({type(e).__name__}).")
    return {'text': str(told or ''), 'ok': bool(ok)}


def filter_field(spec):
    """The field of a driver that holds its filter, or None."""
    return next((f for f in (spec or {}).get('config_schema') or [] if _is_found(f)), None)


def passing(spec, config, things):
    """The found things that count as this device: its filter, applied. A
    driver without a filter field takes everything."""
    field = filter_field(spec)
    if not field:
        return list(things)
    picks = _picks(field, (config or {}).get(field['key']))
    if picks['all']:
        kept = list(things)
    else:
        wanted = {p['id'] for p in picks['only']}
        kept = [t for t in things if t['id'] in wanted]
    return kept if field.get('many', True) else kept[:1]


def here_now(row, part):
    """The things that are here and count as this device. Raises DeviceError."""
    _, spec = _driver(part['driver'], part.get('plugin', ''))
    config = dict(part.get('config') or {})
    return passing(spec, config, found(part['driver'], config))


def field_capability(field, has, every):
    """The capability a config field rides on for a device that has `has`:
    the first one named that the device has, '' for a field that names none
    (always shown), None when the device has none of them (hidden). A name
    the driver never declared counts as always shown, as it always did."""
    named = field.get('capability')
    if not named:
        return ''
    for cap in (named if isinstance(named, (list, tuple)) else [named]):
        if cap in has or cap not in every:
            return cap
    return None


def capabilities(part, spec):
    """What this part can do: what its driver can do, held to what the device
    itself said it has. A device that never said has all of it."""
    said = part.get('has')
    every = list((spec or {}).get('capabilities') or [])
    return [c for c in every if c in said] if isinstance(said, list) else every


def _learn(row, part, spec, said):
    """Keep what the device said it has. A name its driver does not know is
    dropped and logged. Written only when the list changed."""
    if not isinstance(said, (list, tuple)):
        return
    names = {_slug(n) for n in said}
    kept = [c for c in spec['capabilities'] if c in names]
    if kept == part.get('has'):
        return
    odd = sorted(n for n in names - set(kept) if n)
    if odd:
        logger.warning(f"[DEVICES] {row['id']}: it says it has {', '.join(odd)[:200]}, which the "
                       f"{part['driver']} driver does not know. Left out.")
    part['has'] = kept

    def step(table):
        mine = _part(table.get(row['id']) or {}, part['driver'])
        if mine is not None:
            mine['has'] = kept
    _write(step)
    logger.info(f"[DEVICES] {row['id']}: it says it has {', '.join(kept) or 'nothing'}")


def _learn_takes(row, part, said):
    """Keep the finer things the device said it takes. Written only when the list changed."""
    if not isinstance(said, (list, tuple)):
        return
    kept = sorted({str(n)[:48] for n in said if isinstance(n, str) and n})[:200]
    if kept == part.get('takes'):
        return
    part['takes'] = kept

    def step(table):
        mine = _part(table.get(row['id']) or {}, part['driver'])
        if mine is not None:
            mine['takes'] = kept
    _write(step)


def taken(field, part):
    """False for a field that names something (`takes`) this device said it does not take."""
    takes = part.get('takes')
    return not field.get('takes') or not isinstance(takes, list) or field['takes'] in takes


def _shut(row):
    names = row.get('locked')
    if not isinstance(names, list):              # never set: what its drivers ask for
        names = []
        for part in row.get('parts', []):
            spec = _registry().get_driver(part.get('driver')) or {}
            names += spec.get('locked_by_default') or []
    return sorted({str(n) for n in names if n in LOCKABLE})


def locked(row):
    """The capabilities she may not use on this device."""
    return _shut(row)


def _build_part(device_id, driver_id, incoming, previous=None):
    mod, spec = _driver(driver_id)
    config, ops = _clean(spec['config_schema'], incoming, previous or {})
    if callable(getattr(mod, 'validate', None)):
        config, error = mod.validate(config)
        if error:
            raise DeviceError(error)
    return {'driver': driver_id, 'plugin': spec['plugin_name'], 'config': config}, ops, spec


def tell(row):
    """After a save: each part's driver may have apply(device, config,
    secrets), which hands the settings to the hardware. Returns what went
    wrong, in words, one line per part. Never raises."""
    problems = []
    for part in row.get('parts', []):
        secrets = None
        try:
            mod, _ = _driver(part['driver'], part.get('plugin', ''))
            apply = getattr(mod, 'apply', None)
            if not callable(apply):
                continue
            secrets = _part_secrets(row['id'], part['driver'])
            apply(_brief(row), dict(part.get('config') or {}), secrets)
        except DeviceError as e:
            problems.append(f"{part['driver']}: {e}")
        except Exception as e:
            logger.error(f"[DEVICES] {part['driver']}.apply failed: {e}", exc_info=True)
            problems.append(f"{part['driver']}: {secrets.scrub(str(e)) if secrets else e}")
    return problems


# --- add, change, remove (the Devices page only - never a tool) --------------

def add(device_id, label, driver_id, config=None, location=''):
    device_id = _slug(device_id)
    if not ID_RE.fullmatch(device_id):
        raise DeviceError("A device name is lowercase letters, digits, dashes and "
                          "underscores, up to 33 characters, starting with a letter or digit.")
    if device_id in RESERVED:
        raise DeviceError(f"'{device_id}' is a name Sapphire uses herself. Pick another.")
    table = rows()
    if device_id in table:
        raise DeviceError(f"A device named '{device_id}' already exists.")
    if len(table) >= MAX_DEVICES:
        raise DeviceError(f"The limit is {MAX_DEVICES} devices.")
    part, ops, spec = _build_part(device_id, _slug(driver_id), config)
    row = {'id': device_id, 'label': str(label or '').strip()[:80] or device_id,
           'location': _place(location),
           'enabled': True, 'created': int(time.time()), 'parts': [part]}
    row['locked'] = locked(row)
    # A name that was used before must not inherit the old device's secrets.
    _secrets().delete(device_id)
    _write(lambda t: t.__setitem__(device_id, row))
    failed = _apply_secrets(device_id, part['driver'], ops)
    _health().forget(device_id)          # a reused name inherits no belief: offline until it answers
    _health().poke(device_id)
    _changed()
    return row, failed


def update(device_id, label=None, enabled=None, parts=None, new_id=None, location=None,
           locked=None, order=None, poke=True):
    """Change a device. parts: {driver: submitted config}. order: its
    connections' drivers, first to last (the first that has a capability is
    the one that does it). locked: what she
    may not use. A map {capability: bool} changes only the capabilities it
    names, so a switch the page did not show is never touched (a device that
    was off showed none, and saving it opened every lock, 2026-09-28). A list
    is the whole truth. Returns (row, failed secret fields)."""
    row = get(device_id)
    device_id = row['id']
    if isinstance(locked, dict):
        names = set(_shut(row))
        for name, shut in locked.items():
            if _slug(name) in LOCKABLE:
                (names.add if shut else names.discard)(_slug(name))
        row['locked'] = sorted(names)
    elif locked is not None:
        row['locked'] = sorted({_slug(n) for n in locked if _slug(n) in LOCKABLE}) \
            if isinstance(locked, (list, tuple)) else []
    if label is not None:
        row['label'] = str(label).strip()[:80] or device_id
    if location is not None:
        row['location'] = _place(location)
    if enabled is not None:
        row['enabled'] = bool(enabled)
    pending = []
    if parts is not None and not isinstance(parts, dict):
        raise DeviceError("parts is an object keyed by driver: {\"satellite\": {...}}.")
    for driver_id, incoming in (parts or {}).items():
        old = _part(row, _slug(driver_id))
        if not old:
            raise DeviceError(f"'{device_id}' has no '{driver_id}' part.")
        part, ops, _ = _build_part(device_id, old['driver'], incoming, old.get('config'))
        old.update(part)
        pending.append((old['driver'], ops))

    if order is not None:
        want = [_slug(d) for d in order] if isinstance(order, (list, tuple)) else []
        if sorted(want) != sorted(p['driver'] for p in row['parts']):
            raise DeviceError("order names each of the device's connections once.")
        row['parts'].sort(key=lambda p: want.index(p['driver']))

    target = device_id
    if new_id is not None and _slug(new_id) != device_id:
        target = _slug(new_id)
        if not ID_RE.fullmatch(target) or target in RESERVED:
            raise DeviceError("That new name is not a valid device name.")
        if target in rows():
            raise DeviceError(f"A device named '{target}' already exists.")
        if not _secrets().rename(device_id, target):
            raise DeviceError("The device's secrets could not be moved, so it was not renamed.")
        row['id'] = target

    def step(table):
        table.pop(device_id, None)
        table[target] = row
    try:
        _write(step)
    except Exception:
        if target != device_id:
            _secrets().rename(target, device_id)     # put the secrets back
        raise
    failed = []
    for driver_id, ops in pending:
        failed += _apply_secrets(target, driver_id, ops)
    _seen_from.pop(device_id, None)               # a typed address, or a new name: learn afresh
    _declined.pop(device_id, None)
    if target != device_id:
        _voice_forget(device_id)
        _health().rename(device_id, target)
    elif poke:
        _health().poke(target)           # its settings may have changed: look again soon (poke=False: the caller looks after telling)
    _changed()
    return row, failed


def connect(device_id, driver_id, config=None):
    """One more way to reach a device that exists: a second connection of
    its own kind (a Computer over SSH, say). Last in line, so what the device
    already does it keeps doing the same way. Returns (row, failed secrets)."""
    row = get(device_id)
    device_id, driver_id = row['id'], _slug(driver_id)
    if _part(row, driver_id):
        raise DeviceError(f"'{device_id}' already has a '{driver_id}' connection.")
    if len(row['parts']) >= MAX_PARTS:
        raise DeviceError(f"The limit is {MAX_PARTS} connections on one device.")
    _, first = _driver(row['parts'][0]['driver'], row['parts'][0].get('plugin', ''))
    part, ops, spec = _build_part(device_id, driver_id, config)
    if spec['kind'] != first['kind']:
        raise DeviceError(f"'{spec['label']}' reaches a {spec['kind']}, and '{device_id}' is a {first['kind']}.")
    if isinstance(row.get('locked'), list):       # what is new on the device starts as its driver asks
        had = {c for p in row['parts'] for c in capabilities(p, _registry().get_driver(p['driver']))}
        row['locked'] = sorted(set(row['locked']) | {c for c in spec.get('locked_by_default') or []
                                                     if c in LOCKABLE and c not in had})
    row['parts'].append(part)
    _write(lambda t: t.__setitem__(device_id, row))
    failed = _apply_secrets(device_id, driver_id, ops)
    _health().poke(device_id)
    _changed()
    return row, failed


def disconnect(device_id, driver_id):
    """Take one connection off a device, and forget that connection's secrets."""
    row = get(device_id)
    device_id, driver_id = row['id'], _slug(driver_id)
    part = _part(row, driver_id)
    if not part:
        raise DeviceError(f"'{device_id}' has no '{driver_id}' connection.")
    if len(row['parts']) == 1:
        raise DeviceError("That is its only connection. Delete the device instead.")
    row['parts'].remove(part)
    _write(lambda t: t.__setitem__(device_id, row))
    for name in list(_secrets().status(device_id)):
        if name.startswith(driver_id + '.'):
            _secrets().clear(device_id, name)
    _health().poke(device_id)
    _changed()
    return row


def _voice_forget(device_id):
    try:
        from core.devices import voice
        voice.forget(device_id)
    except Exception as e:
        logger.warning(f"[DEVICES] {device_id}: its voice state was not cleared: {e}")


def _mac(text):
    """A chip's MAC as 'aa:bb:cc:dd:ee:ff', or '' for anything else."""
    hexes = re.sub(r'[^0-9a-f]', '', str(text or '').lower())
    return ':'.join(hexes[i:i + 2] for i in range(0, 12, 2)) if len(hexes) == 12 else ''


def provision(label, driver_id, location='', mac='', replace=False):
    """A board about to be set up from the browser (the Devices page's
    flasher): its name and the two keys it will carry. A new name is a new
    row with NO address: that is learned when the board calls in. A name in
    use is that device with fresh keys: the board is being flashed again.
    `mac` is the chip's own id, read over USB: it is kept as the device's
    fingerprint, so two boards are never mixed up (a board that is already
    some device keeps that name; a name cannot be taken by a second board).
    A device that exists keeps its keys, its name and its address until the
    board calls in with the new ones (promote): a setup that fails leaves it
    working. A board that is already some device, given a new name, is that
    device renamed when it calls in. A name in use by a board this one cannot
    be proven to be (no fingerprint on either side) needs replace=True: the
    page asks first, since that board stops working.
    Returns (row, {'token', 'voice_key'})."""
    import secrets as rand
    driver_id = _slug(driver_id)
    device_id = _name_from(label)
    mac = _mac(mac)
    if not ID_RE.fullmatch(device_id) or device_id in RESERVED:
        raise DeviceError("Give the board a name: letters and digits, up to 33 characters.")
    table = rows()
    keys = {'token': rand.token_urlsafe(24), 'voice_key': rand.token_urlsafe(24)}
    mine = next((r for r in table.values() if mac and r.get('fingerprint') == mac), None)
    if mine and mine['id'] != device_id and device_id in table:
        raise DeviceError(f"This board is the device '{mine['id']}', and '{device_id}' is another device. "
                          f"Keep its name, pick a free one, or remove '{device_id}' in {PAGE} first.")
    source = mine or table.get(device_id)
    if source is None:
        row, failed = add(device_id, label, driver_id, dict(keys, url=''), location=location)
        if failed:
            raise DeviceError("The board's keys could not be stored: " + ", ".join(failed) + ".")
        if mac:
            def step(table):
                if row['id'] in table:
                    table[row['id']]['fingerprint'] = mac
            _write(step)
            row['fingerprint'] = mac
        return row, keys
    if not _part(source, driver_id):
        raise DeviceError(f"'{source['id']}' is a different kind of device. Pick another name.")
    if not mine:                                  # the name is taken; is it this board?
        if mac and source.get('fingerprint'):     # both known and different: never
            raise DeviceError(f"'{device_id}' is a different board (id {source['fingerprint']}). Pick another "
                              f"name, or remove '{device_id}' in {PAGE} first.")
        if not replace:
            raise DeviceError(f"'{device_id}' {REPLACE_NEEDED}. Give this board another name, or replace "
                              f"'{device_id}' with it: its current board then stops working.")
    _prune_pending()
    _pending[device_id] = {'from': source['id'], 'driver': driver_id, 'keys': keys, 'mac': mac, 'ts': time.time()}
    logger.info(f"[DEVICES] {source['id']}: new keys minted" + (f", to be '{device_id}'" if device_id != source['id'] else '')
                + "; they take effect when the board calls in")
    return dict(source, id=device_id), keys


def _prune_pending():
    now = time.time()
    for k in [k for k, p in _pending.items() if now - p['ts'] > PENDING_FOR]:
        _pending.pop(k, None)


def promote(device_id, presented):
    """A board calling in with a key that is not the stored one: when it is
    the key provision() minted for this name, the device takes its new keys
    now, and its new name, and the board's id becomes its fingerprint. A
    different board than the one the device had loses the old address, so
    this call teaches the new one. True when that happened. Never raises."""
    import hmac
    device_id = _slug(device_id)
    _prune_pending()
    p = _pending.get(device_id)
    if not p or not presented or not hmac.compare_digest(str(presented).encode(), p['keys']['voice_key'].encode()):
        return False
    try:
        if p['from'] != device_id:
            update(p['from'], new_id=device_id)
        row = get(device_id)
        config = dict(p['keys'])
        if p['mac'] and row.get('fingerprint') != p['mac']:
            config['url'] = ''                    # another board: where it lives is learned from this call
        _, failed = update(device_id, parts={p['driver']: config})
        if failed:
            raise DeviceError("its keys could not be stored: " + ", ".join(failed))
        if p['mac'] and row.get('fingerprint') != p['mac']:
            def step(table):
                if device_id in table:
                    table[device_id]['fingerprint'] = p['mac']
            _write(step)
        _pending.pop(device_id, None)
        logger.info(f"[DEVICES] {device_id}: the board called in with its new keys; they are its keys now")
        return True
    except DeviceError as e:
        logger.warning(f"[DEVICES] {device_id}: the board called in with its new keys, but {e}")
        return False


def learned(device_id, host):
    """The device just called in from `host` with its own key: that is
    where it lives. Each part whose driver `learns_address` takes it as its
    url - one it never had (a board set up from the browser), or one whose
    host changed (a new DHCP lease). The scheme and port it had are kept.
    Only an address on this network is believed, and only for a device that
    does not answer at the address it has: while the health keeper reaches
    it there, a caller from elsewhere - a typed address behind a gateway, or
    someone else with its key - is not followed. Never raises."""
    from urllib.parse import urlsplit
    from core import net
    try:
        host = str(host or '').strip()
        device_id = _slug(device_id)
        if not host or _seen_from.get(device_id) == host:     # a screen pulls many times a second
            return
        was, when = _declined.get(device_id, ('', 0.0))
        if was == host and time.monotonic() - when < DECLINE_FOR:
            return
        if net.classify(host) != 'lan':
            return
        literal = f'[{host}]' if ':' in host and not host.startswith('[') else host    # an IPv6 literal in a URL
        row = rows().get(device_id)
        if not row:
            return
        changes, kept = {}, []
        for part in row.get('parts', []):
            spec = _registry().get_driver(part.get('driver')) or {}
            if not spec.get('learns_address'):
                continue
            old = str((part.get('config') or {}).get('url') or '')
            p = urlsplit(old) if old else None
            new = f"{p.scheme if p and p.scheme else 'http'}://{literal}" + (f":{p.port}" if p and p.port else '')
            if new == old:
                continue
            if old and _health().reached(device_id):
                kept.append(old)
            else:
                changes[part['driver']] = new
        if kept:
            _declined[device_id] = (host, time.monotonic())
            _health().look(device_id)             # is it still there? asked now, so a real move is followed soon
            logger.info(f"[DEVICES] {row['id']}: called from {host}, but it still answers at {kept[0]}: not followed")
            return
        _seen_from[device_id] = host
        if not changes:
            return

        def step(table):
            for driver_id, url in changes.items():
                mine = _part(table.get(row['id']) or {}, driver_id)
                if mine is not None:
                    mine.setdefault('config', {})['url'] = url
        _write(step)
        for driver_id, url in changes.items():
            logger.info(f"[DEVICES] {row['id']}: address learned, {url} ({driver_id})")
        _health().poke(row['id'])
        # it can take its settings now that it can be reached; off this thread,
        # which is the device's own request
        threading.Timer(2.0, _tell_later, (row['id'],)).start()
    except Exception as e:
        logger.warning(f"[DEVICES] learned({device_id}) failed: {e}")


_seen_from = {}                # device id -> the host it last called from
_declined = {}                 # device id -> (host not followed, when): asked again after a while
DECLINE_FOR = 30               # seconds before a host that was not followed is weighed again
_pending = {}                  # device id (the name the board will carry) -> what provision() minted for it
PENDING_FOR = 15 * 60          # seconds a board has to call in with its new keys before they are forgotten
REPLACE_NEEDED = "is already a device, and I cannot tell whether this is the same board"


def _tell_later(device_id):
    try:
        tell(get(device_id))
    except DeviceError:
        pass                                      # removed in the meantime


def remove(device_id):
    row = get(device_id)
    _write(lambda t: t.pop(row['id'], None))
    _secrets().delete(row['id'])
    _seen_from.pop(row['id'], None)
    _declined.pop(row['id'], None)
    _voice_forget(row['id'])
    for k in [k for k, p in _pending.items() if row['id'] in (k, p['from'])]:
        _pending.pop(k, None)
    _health().forget(row['id'])
    _changed()
    return row


def public(row):
    """A row for the Devices page: every part with its schema and its values.
    A secret field reads 'set' or '' - never the secret."""
    held = _secrets().status(row['id'])
    parts = []
    for part in row.get('parts', []):
        spec = _registry().get_driver(part['driver'])
        has = capabilities(part, spec)
        # a field that belongs to something this device does not have is not
        # shown. A field may name several (the key a satellite sends rides on
        # its mic or its keyboard): the page sees the one this device has.
        schema = []
        for f in (spec['config_schema'] if spec else []):
            cap = field_capability(f, has, spec['capabilities'])
            if cap is None or not taken(f, part):
                continue
            f = dict(f, capability=cap) if isinstance(f.get('capability'), (list, tuple)) else f
            # a bindings field's menu is the device's own (its buttons, what it can do by itself)
            if _is_bindings(f):
                schema.append(dict(f, menu=_menu(row, part, f)))
            elif f.get('dynamic') and f.get('type') == 'select':   # its choices are this device's own (driver.options)
                schema.append(dict(f, options=_options(row, part, f)))
            else:
                schema.append(f)
        values = dict(part.get('config') or {})
        unreadable = []
        for field in schema:
            if field.get('secret'):
                state = held.get(f"{part['driver']}.{field['key']}")
                values[field['key']] = KEPT if state == 'set' else ''
                if state == 'undecryptable':
                    unreadable.append(field['key'])
        parts.append({'driver': part['driver'], 'plugin': part.get('plugin', ''),
                      'label': spec['label'] if spec else part['driver'],
                      'kind': spec['kind'] if spec else '',
                      'available': bool(spec), 'schema': schema, 'values': values,
                      'capabilities': has,
                      'unreadable': unreadable})
    return {'id': row['id'], 'label': row.get('label', row['id']),
            'location': _place(row.get('location')), 'locked': locked(row),
            'enabled': bool(row.get('enabled', True)), 'parts': parts,
            'fingerprint': str(row.get('fingerprint') or '')}      # the chip's MAC, from the flasher


# --- describe ----------------------------------------------------------------

def describe(row):
    """What this device can do, in tab order:
    [{'capability', 'label', 'help', 'driver', 'actions': {name: {'help', 'example'}},
      'error', 'lockable', 'locked'}]. locked = she may not use it."""
    out = []
    shut = locked(row)
    for part in row.get('parts', []):
        try:
            mod, spec = _driver(part['driver'], part.get('plugin', ''))
            told = mod.describe(dict(_brief(row), has=part.get('has'), takes=part.get('takes')), dict(part.get('config') or {})) or {}
        except DeviceError as e:
            out.append({'capability': part['driver'], 'label': part['driver'], 'help': '',
                        'driver': part['driver'], 'actions': {}, 'error': str(e),
                        'lockable': False, 'locked': False})
            continue
        except Exception as e:
            logger.error(f"[DEVICES] {part['driver']}.describe failed: {e}", exc_info=True)
            out.append({'capability': part['driver'], 'label': part['driver'], 'help': '',
                        'driver': part['driver'], 'actions': {}, 'error': f"driver error: {e}",
                        'lockable': False, 'locked': False})
            continue
        for cap in capabilities(part, spec):
            if not isinstance(told.get(cap), dict):
                continue            # this device does not have it (self-describing drivers)
            if any(c['capability'] == cap for c in out):
                continue            # an earlier connection does it: the order is the user's (Connections tab)
            info = told[cap]
            actions = {}
            for name, a in (info.get('actions') or {}).items():
                a = a if isinstance(a, dict) else {}
                actions[_slug(name)] = {'help': str(a.get('help') or '')[:160],
                                        'example': str(a.get('example') or '')[:200],
                                        'values': str(a.get('values') or '')[:80],
                                        # owner: the person at the page only, never her
                                        # (run() refuses). danger: the page asks for
                                        # I UNDERSTAND first, with these words.
                                        'owner': bool(a.get('owner')),
                                        'danger': str(a.get('danger') or '')[:200],
                                        # wait: seconds the action may take; the page's
                                        # button waits that long (a 300 s update is not a
                                        # 30 s request, 2026-10-07)
                                        'wait': _seconds(a.get('wait'))}
            out.append({'capability': cap, 'label': str(info.get('label') or cap),
                        'help': str(info.get('help') or '')[:120],
                        # tab: the page's tab these actions sit on; '' = one of their own,
                        # 'Status' = with the device's health (a phone's pair and unpair)
                        'tab': str(info.get('tab') or '')[:40],
                        'driver': part['driver'], 'actions': actions, 'error': '',
                        'lockable': cap in LOCKABLE, 'locked': cap in shut})
    return out


def _hers(action):
    """May she run this? Not an owner-only action, and not a dangerous one:
    danger means the page asks I UNDERSTAND first, which she cannot answer."""
    return not (action.get('owner') or action.get('danger'))


def _seconds(v, most=900):
    try:
        return max(0, min(int(v or 0), most))
    except (TypeError, ValueError):
        return 0


def _brief(row):
    return {'id': row['id'], 'label': row.get('label', row['id']),
            'location': _place(row.get('location'))}


# --- status ------------------------------------------------------------------
# What is BELIEVED about a device lives in health.py (online or offline, with
# hysteresis, kept across restarts). _probe only asks.

def _probe(row):
    """Ask every part how it is, right now. Never raises. The answer is raw:
    health.told() decides what it means."""
    parts = []
    for part in row.get('parts', []):
        entry = {'driver': part['driver'], 'online': False, 'detail': '', 'readings': {}}
        try:
            mod, spec = _driver(part['driver'], part.get('plugin', ''))
            secrets = _part_secrets(row['id'], part['driver'])
            told = mod.status(_brief(row), dict(part.get('config') or {}), secrets) or {}
            entry['online'] = bool(told.get('online'))
            _learn(row, part, spec, told.get('has'))
            _learn_takes(row, part, told.get('takes'))
            entry['detail'] = secrets.scrub(str(told.get('detail') or ''))[:300]
            readings = told.get('readings')
            if isinstance(readings, dict):
                entry['readings'] = {str(k)[:40]: secrets.scrub(str(v))[:80]
                                     for k, v in list(readings.items())[:20]}
            if spec.get('presence'):             # said the same way for every driver
                here = here_now(row, part)
                entry['readings'] = dict({'connected': ', '.join(
                    t['name'] + (f" ({t['kind']})" if t['kind'] else '') for t in here)[:80] or 'nothing'},
                    **entry['readings'])
        except DeviceError as e:
            entry['detail'] = str(e)
        except Exception as e:
            logger.error(f"[DEVICES] {part['driver']}.status failed: {e}", exc_info=True)
            entry['detail'] = f"driver error: {e}"
        parts.append(entry)
    # reached by any of its connections, it is here; each says how it is itself
    return {'online': any(p['online'] for p in parts),
            'parts': parts, 'ts': time.time()}


def status(device_id, fresh=True):
    """What is believed about one device: {'online', 'checking', 'ts',
    'misses', 'parts'}. fresh=True asks the device first and believes the
    answer; fresh=False never blocks."""
    row = get(device_id)
    return _health().check(row) if fresh else _health().view(row['id'])


def statuses():
    """{id: belief} for every enabled device. Never blocks: the health
    keeper asks the devices on its own clock."""
    return _health().views()


# --- what she reads ----------------------------------------------------------

def _call(*args):
    return 'device_action(' + ','.join(json.dumps(str(a)) for a in args) + ')'


def _age(ts):
    s = max(0, int(time.time() - ts))
    return f"{s}s ago" if s < 90 else f"{s // 60}m ago"


def _columns_text(lines):
    """Left-aligned columns, two spaces apart, indented two."""
    if not lines:
        return ''
    widths = [max(len(str(r[i])) for r in lines) for i in range(len(lines[0]) - 1)]
    return '\n'.join('  ' + '  '.join(str(c).ljust(w) for c, w in zip(r, widths)) + '  ' + str(r[-1])
                     for r in lines).rstrip()


LOCKED_NOTE = f"the user has not allowed you this. They can change it in {PAGE}"


def _caps(row):
    """What this device can do, by name. A part whose driver is off is said
    so, and so is a capability she may not use."""
    return [c['capability'] + (' (driver off)' if c['error'] else ' (locked)' if c['locked'] else '')
            for c in describe(row)]


def fleet():
    """[{'id', 'location', 'online', 'caps'}] for every enabled device: what the
    tool descriptions say, so she can act without a list call."""
    found = statuses()
    out = [{'id': k, 'location': _place(row.get('location')), 'online': found[k]['online'],
            'caps': _caps(row)}
           for k, row in rows().items() if row.get('enabled', True)]
    if len(speakers(online=False)) >= 2:
        out.append({'id': ALL, 'location': '', 'online': True, 'caps': ['speaker'], 'every': True})
    return out


def list_text():
    table = {k: v for k, v in rows().items() if v.get('enabled', True)}
    if not table:
        return f"No devices yet. The user adds them in {PAGE}.", True
    found = statuses()
    placed = any(_place(row.get('location')) for row in table.values())
    lines = []
    for device_id, row in table.items():
        state = 'online' if found[device_id]['online'] else 'offline'
        where = (_place(row.get('location')) or '-',) if placed else ()
        lines.append((device_id, state) + where + (', '.join(_caps(row)) or '-',))
    if len(speakers(online=False)) >= 2:
        lines.append((ALL, 'online') + (('-',) if placed else ()) + ('speaker: say on every device that can, and stop',))
    first = next(iter(table))
    return f"Devices ({len(table)}):\n{_columns_text(lines)}\nNext: {_call(first)}", True


def _usable(device_id):
    """The row she named, or DeviceError with the way forward."""
    row = rows().get(_slug(device_id))
    if row and not row.get('enabled', True):
        raise DeviceError(f"'{row['id']}' is turned off in {PAGE}.")
    if _slug(device_id) == ALL:
        raise DeviceError(f"'{ALL}' is not one device: it is her voice on every device that can speak. "
                          f"{_call(ALL, 'speaker', 'say', '<text>')}")
    if not row:
        names = [k for k, v in rows().items() if v.get('enabled', True)]
        known = f" Devices: {', '.join(names)}." if names else f" No devices exist yet. The user adds them in {PAGE}."
        raise DeviceError(f"There is no device named '{device_id}'.{known}")
    return row


def _head(row, st):
    state = 'online' if st['online'] else 'offline'
    label = row.get('label') or row['id']
    name = row['id'] if label == row['id'] else f"{row['id']} - {label}"
    where = _place(row.get('location'))
    return name + (f" ({where})" if where else '') + f" - {state}"


def status_text(device_id):
    try:
        row = _usable(device_id)
    except DeviceError as e:
        return str(e), False
    st = _health().check(row)
    lines = [(p['driver'], 'ok' if p['online'] else 'down', p['detail'] or '-') for p in st['parts']]
    out = [f"{_head(row, st)} (checked just now)", _columns_text(lines)]
    if st['online'] and st['misses']:
        out.append("It did not answer just now. It counts as offline if it misses again.")
    for p in st['parts']:
        for k, v in p['readings'].items():
            out.append(f"  {k}: {v}")
    out.append(f"Can do: {', '.join(_caps(row)) or 'nothing'}")
    out.append(f"Next: {_call(row['id'])}")
    return '\n'.join(x for x in out if x), True


def _down_note(st, driver=None):
    """One line that saves her a wasted call when the device is believed
    offline. A single miss says nothing here."""
    down = [p for p in st['parts'] if not p['online']]
    if st['online']:
        mine = next((p for p in down if p['driver'] == driver), None)     # here, but not by this connection
        return f"Its {driver} connection is down: {mine['detail'] or 'no answer'}" if mine else ''
    mine = [p for p in down if p['driver'] == driver] or down
    why = (mine[0]['detail'] if mine else '') or ('not heard from yet' if not st['ts'] else 'no answer')
    return f"Offline: {why}\nCommands will fail until it is back."


def _block(row, c, limit):
    """One capability: its actions, each with the value it takes and what it does."""
    if c['error']:
        return f"{c['capability']} - {c['error']}"
    if c['locked']:
        return f"{c['capability']} (locked) - {LOCKED_NOTE}"
    title = c['capability'] + (f" - {c['help']}" if c['help'] else '')
    items = [(n, a) for n, a in c['actions'].items() if _hers(a)]   # hers to read: not the owner-only ones
    lines = [(f"{name} {a['values']}".strip(), a['help'] or '-') for name, a in items[:limit]]
    body = _columns_text(lines) or f"  (no actions yet - the user adds them in {PAGE})"
    more = f"  ... {len(items) - limit} more: {_call(row['id'], c['capability'])}" if len(items) > limit else ''
    return '\n'.join(x for x in (title, body, more) if x)


def _screen(row, caps, only=None):
    """What she reads for device_action(device) and device_action(device,
    capability): how the device is (believed, never asked), then everything it
    can do with the value each action takes, then ONE example call. Kept
    under SCREEN characters: a long capability is cut to its first MOST
    actions and says how to see the rest."""
    st = _health().view(row['id'])
    shown = [only] if only else caps
    head = f"{_head(row, st)}, " + (f"checked {_age(st['ts'])}" if st['ts'] else 'not checked yet')
    readings = [f"{k} {v}" for p in st['parts'] for k, v in p['readings'].items()][:READINGS]
    usable = [c for c in shown if not c['error'] and not c['locked'] and c['actions']]
    pick = next(((c, n, a) for c in usable for n, a in c['actions'].items() if a['example'] and _hers(a)), None) \
        or next(((c, n, a) for c in usable for n, a in c['actions'].items() if _hers(a)), None)
    if pick:
        c, n, a = pick
        foot = 'Run one: ' + _call(*([row['id'], c['capability'], n] + ([a['example']] if a['example'] else [])))
    else:
        foot = f'Run one: device_action("{row["id"]}", capability, action, value)'
    down = _down_note(st, only['driver'] if only else None)

    def build(limit):
        parts = [head, '  ' + ' · '.join(readings) if readings else '']
        parts += [_block(row, c, limit) for c in shown] or ['  (nothing it can do yet)']
        return '\n'.join(x for x in parts + [foot, down] if x)
    text = build(MAX_ROWS + 1)
    # asked for one capability, she gets all of it (MAX_ROWS bounds it): that is what "N more" promised
    return text if only or len(text) <= SCREEN else build(MOST)


def _result(told, secrets):
    """What an action answered: text, or {'text', 'images'} when it took
    pictures. The text is scrubbed of secrets. Pictures are checked, never
    trusted: a known type, a sane size, a few at most."""
    if isinstance(told, dict) and isinstance(told.get('images'), list):
        text = secrets.scrub(str(told.get('text') or '')).strip()
        images = []
        for img in told['images'][:MAX_PICTURES * 8]:
            if len(images) >= MAX_PICTURES:
                break
            if not isinstance(img, dict):
                continue
            data, kind = img.get('data'), str(img.get('media_type') or '').lower()
            if isinstance(data, str) and data and len(data) <= MAX_PICTURE and kind in PICTURE_TYPES:
                images.append({'data': data, 'media_type': kind})
        if images:
            return {'text': text or 'A picture.', 'images': images}
        return text or 'No picture came back.'
    return secrets.scrub(str(told if told is not None else '(no output)'))


def speaker(device_id):
    """Core only, for her voice as it is made: (module, brief, config, secrets)
    of the part that gives this device a speaker AND can take sound itself
    (a driver `play(audio, kind, device, config, secrets)`), or None. Her
    tools never come this way; run() is theirs."""
    row = rows().get(_slug(device_id))
    if not row or not row.get('enabled', True):
        return None
    for part in row.get('parts', []):
        try:
            mod, spec = _driver(part['driver'], part.get('plugin', ''))
        except DeviceError:
            continue
        if 'speaker' in capabilities(part, spec) and callable(getattr(mod, 'play', None)):
            secrets = _secrets_or_none(row, part)
            if secrets is not None:
                return mod, _brief(row), dict(part.get('config') or {}), secrets
    return None


def doors(capability, hook, online=True):
    """Core only: (module, brief, config, secrets) of every enabled part that
    has `capability` and a callable driver function `hook` — the shape
    speaker() has for sound, for any capability core drives itself (storage:
    hook 'storage_target'). With online=True, devices the health keeper
    believes offline are left out; one never asked yet is tried."""
    found = statuses() if online else {}
    out = []
    for device_id, row in rows().items():
        if not row.get('enabled', True):
            continue
        view = found.get(device_id) or {}
        if online and view.get('ts') and not view.get('online'):
            continue
        for part in row.get('parts', []):
            try:
                mod, spec = _driver(part['driver'], part.get('plugin', ''))
            except DeviceError:
                continue
            if capability in capabilities(part, spec) and callable(getattr(mod, hook, None)):
                secrets = _secrets_or_none(row, part)
                if secrets is not None:
                    out.append((mod, _brief(row), dict(part.get('config') or {}), secrets))
    return out


def door(device_id, capability, hook):
    """Core only: (module, brief, config, secrets) of ONE device, for a part
    whose driver has `capability` and a callable `hook`. What the health
    keeper believes about the device - offline, or that it said it has
    nothing - is not consulted: the caller is about to ask the device itself,
    and the device's own words are the better answer. DeviceError, in words,
    when there is no such device, it is switched off here, no part fits, or
    its secrets cannot be read on this machine."""
    row = get(device_id)
    who = row.get('label') or row['id']
    if not row.get('enabled', True):
        raise DeviceError(f"{who} is switched off here (Settings > Devices).")
    for part in row.get('parts', []):
        try:
            mod, spec = _driver(part['driver'], part.get('plugin', ''))
        except DeviceError:
            continue
        if capability in (spec.get('capabilities') or []) and callable(getattr(mod, hook, None)):
            try:
                secrets = _part_secrets(row['id'], part['driver'])
            except DeviceError as e:
                raise DeviceError(f"{who}'s secrets cannot be read on this machine: {e}")
            return mod, _brief(row), dict(part.get('config') or {}), secrets
    raise DeviceError(f"{who} is not that kind of device.")


_unreadable = set()           # (device, driver) already said to have secrets this machine cannot read


def _secrets_or_none(row, part):
    """This part's secrets, or None when they cannot be read here (said
    once in the log; the Devices page shows it on the device). One bad key
    must never blind the fleet: her list, her voice, the backup targets."""
    try:
        return _part_secrets(row['id'], part['driver'])
    except DeviceError as e:
        key = (row['id'], part['driver'])
        if key not in _unreadable:
            _unreadable.add(key)
            logger.warning(f"[DEVICES] {row['id']} is left out: {e}")
        return None


def speakers(online=True):
    """The doors of every enabled device whose speaker takes her sound
    itself (see speaker()): the devices `all` speaks on. With online=True,
    those the health keeper has asked and believes offline are left out; one
    never asked yet is tried."""
    found = statuses() if online else {}
    out = []
    for device_id in rows():
        view = found.get(device_id) or {}
        if online and view.get('ts') and not view.get('online'):
            continue
        door = speaker(device_id)
        if door:
            out.append(door)
    return out


def _run_all(capability, action, value):
    """`all`: say it on every device that can speak, or stop them."""
    from core.devices import voice
    cap, act = _slug(capability), _slug(action)
    names = ', '.join(d[1]['id'] for d in speakers(online=False)) or 'none yet'
    screen = (f"'{ALL}' speaks on every device that can ({names}). "
              f"{_call(ALL, 'speaker', 'say', '<text>')} says it everywhere at once; "
              f"{_call(ALL, 'speaker', 'stop')} stops it. For anything else, name one device.")
    if not cap or not act:
        return screen, True
    if cap != 'speaker' or act not in ('say', 'stop'):
        return screen, False
    return voice.say_all(value) if act == 'say' else voice.stop_all()


def text_of(result):
    """The words of what run() answered, for a caller that shows no pictures."""
    return str(result.get('text') or '') if isinstance(result, dict) else str(result)


def run(device_id=None, capability=None, action=None, value=None, owner=False):
    """device_action. Every level of missing or wrong argument answers with
    the list one level up, so a wrong guess costs one call, never a dead end.
    Returns (result, ok). result is text, or {'text', 'images'} when the
    action took pictures (the shape every picture-taking tool answers with).
    owner=True is the user at the Devices page, or core itself: a capability
    that is locked for her still runs."""
    if not _slug(device_id):
        return list_text()
    if _slug(device_id) == ALL:
        return _run_all(capability, action, value)
    try:
        row = _usable(device_id)
    except DeviceError as e:
        return str(e), False
    caps = describe(row)

    cap_name = _slug(capability)
    if not cap_name:
        return _screen(row, caps), True
    cap = next((c for c in caps if c['capability'] == cap_name), None)
    if not cap:
        return f"'{row['id']}' has no '{capability}'.\n{_screen(row, caps)}", False
    if cap['error']:
        return f"{row['id']} / {cap_name}: {cap['error']}", False
    if cap['locked'] and not owner:
        return f"'{cap_name}' on '{row['id']}' is locked: {LOCKED_NOTE}.", False

    act = _slug(action)
    if not act:
        return _screen(row, caps, only=cap), True
    if act not in cap['actions']:
        return f"'{cap_name}' has no action '{action}'.\n{_screen(row, caps, only=cap)}", False
    if not _hers(cap['actions'][act]) and not owner:
        return f"'{act}' on '{row['id']}' is for the person at {PAGE} only.", False

    part = _part(row, cap['driver'])
    try:
        mod, spec = _driver(part['driver'], part.get('plugin', ''))
        secrets = _part_secrets(row['id'], part['driver'])
        told, ok = mod.run(_brief(row), cap_name, act, '' if value is None else str(value),
                           dict(part.get('config') or {}), secrets,
                           _call_tool_for(spec['plugin_name'], spec.get('uses_tools') or ()))
        if ok and owner and cap_name in ('firmware', 'power', 'storage', 'wake'):
            _health().poke(row['id'])         # the board changed under the page: its strip should say so soon
        return _result(told, secrets), bool(ok)
    except DeviceError as e:
        return str(e), False
    except Exception as e:
        logger.error(f"[DEVICES] {part['driver']}.run({cap_name}, {act}) failed: {e}", exc_info=True)
        return f"{row['id']} / {cap_name} / {act} failed: {type(e).__name__}", False
