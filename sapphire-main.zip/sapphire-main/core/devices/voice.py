# core/devices/voice.py - voice through devices (tmp/device-manager-plan.md)
#
# The halves of an Alexa-like satellite:
#   hear()  a device heard its wake word and sends what was said. hear()
#           answers as soon as the words are known. The turn runs on its own
#           thread, and the answer is spoken on the SAME device.
#   say()   speak on a device, whole: her `say` action, and the reply lane
#           of cadence.run_turn when a reply could not be spoken as it was
#           made. say_all() is the same on every device that can speak at
#           once (the composite device `all`): rendered once, played on each.
#   halt()  core's half of a stop: her sentences still to be sent to a
#           device are dropped. The driver's `stop` action calls it, then
#           tells the device to cut what is playing.
#   Speech  her reply spoken on a device sentence by sentence, as the turn
#           makes it: the device hears the first sentence while she is still
#           writing the third. The turn feeds it, a worker plays in order.
#   cue()   what a device's light should show: thinking, tool, idle, error.
#           Only the device whose turn it is gets them. A device holds one
#           stream open to receive them (GET /api/devices/{id}/events).
#   typed() a device with a keyboard sends what was typed (a pocket
#           terminal). The turn runs the same way; her reply goes to the
#           device's SCREEN, not its speaker: Reply keeps the text as she
#           writes it and rings the device's stream with a `text` doorbell
#           ({msg, rev, have, done}); the device pulls what it lacks from
#           reply_text(). A doorbell can be dropped, the text never is.
#   said()  a device hands her words with neither microphone nor screen: a
#           phone sharing a picture, a text message that arrived on it. The
#           turn runs in the device's chat; her reply stays there. Pictures
#           that come with the words are kept like a pasted picture.
#   pressed() a device's button was pressed and its press is set to send her
#           a message (the device's Buttons tab). The words set there land
#           in the device's chat as a turn; her reply goes where the device
#           can take it: its screen, else its speaker, else only the chat.
#           What else a press can do, the board does by itself: bound() is
#           what it is told, on its events stream.
# One wake gets one answer: hear() asks wake.py whether the main app or
# another satellite already holds the room, and drops a repeat of its words.
#
# Both privacy gates apply: a private chat never sends audio to a cloud
# speech engine, and never sends its reply to a cloud voice engine.
#
# A device may state the ONE format it plays: {"type": "audio/wav", "rate":
# 16000, "channels": 1}. wav is always 16 bit PCM. fit() is the only place
# her voice is converted. A device that states nothing gets the audio as the
# voice engine made it.
import asyncio
import base64
import contextvars
import hmac
import io
import json
import logging
import re
import os
import queue
import tempfile
import threading
import time
import uuid

from core.devices import wake
from core.stt.providers.base import STTFailed

logger = logging.getLogger(__name__)

MAX_AUDIO = 20 * 1024 * 1024
MAX_WAITING = 3            # questions one device may have waiting or running
MAX_LISTENERS = 4          # light streams one device may hold open
RATES = (8000, 48000)      # the sample rates a device may ask for, lowest and highest
QUIET = 0.01               # below this a sample is silence, for the trim
HEAD, TAIL = 0.08, 0.20    # seconds of silence left before and after her words
CUE_FRESH = 300            # seconds a cue is still worth showing to a late stream
CUES = ('thinking', 'tool', 'idle', 'error', 'standdown', 'text', 'buttons')   # standdown: another listener took this wake; text: a doorbell; buttons: what its presses do
HOWS = ('short', 'long', 'double')     # the ways a button is pressed
TELL = 'tell'              # a press that sends her a message; any other job is the board's own
SPEECH_WAIT = 600          # seconds a turn waits for the last sentence to finish playing
SAY_ALL_WAIT = 180         # seconds say_all waits for the slowest device
TYPED_MAX = 2000           # chars a device may type at once
SAID_MAX = 24000           # chars a device may hand her at once (a shared document)
TEXT_MAX = 12000           # chars of one reply kept for a screen
TEXT_KEEP = 4              # replies kept per device, for a pull that comes late
DOORBELL_GAP = 0.25        # seconds between doorbells while she writes
PULL_MAX = 2000            # chars one pull may ask for

_speaking_for = contextvars.ContextVar('device_voice_chat_settings', default=None)
_voice_for = contextvars.ContextVar('device_voice_own', default=None)      # {voice, speed, pitch} inside say(): a chat-room seat's own
_lane = contextvars.ContextVar('device_voice_reply_lane', default=False)   # inside say(): the reply lane, not her tool call
_lock = threading.Lock()
_announcing = {}           # device id -> until when a say_all plays there (monotonic)
_waiting = {}              # device id -> questions waiting or running
_showing = {}              # device id -> the cue its light should show right now
_listeners = {}            # device id -> [(loop, queue)] of open light streams
_live = {}                 # device id -> [Speech] with sentences still to play
_replies = {}              # device id -> [Reply] to typed questions, newest last
wake.told = lambda device_id: cue(device_id, 'standdown')   # the main app took a satellite's claim
room_sink = None           # callable(device_id, audio_bytes, meta) -> {'ok', 'accepted'}: who collects room sound (the Wakeword Maker's room watch sets it)
ROOM_FIRES_MAX = 50        # wake fires a board may stamp into one piece of the room
_spoke = threading.local() # did the reply lane manage to speak, on this thread


def forget(device_id):
    """A device removed or renamed: nothing it said or was told waits for a
    device that takes its name later."""
    with _lock:
        for table in (_waiting, _showing, _live, _replies):
            table.pop(device_id, None)


def _system():
    from core.api_fastapi import get_system
    return get_system()


def _engine():
    from core.devices import engine
    return engine


# --- the clock -------------------------------------------------------------------

def local_tz():
    """This machine's time zone as the POSIX string a small board's C library
    takes, like EST5EDT,M3.2.0,M11.1.0: the footer of the system zone file.
    Without one, the plain offset, which knows no summer time."""
    try:
        with open('/etc/localtime', 'rb') as f:
            data = f.read()
        if data[:4] == b'TZif' and data[4:5] >= b'2':
            foot = data.rstrip(b'\n').rsplit(b'\n', 1)[-1]
            if 0 < len(foot) < 64 and b'\x00' not in foot:
                return foot.decode('ascii', 'replace')
    except (OSError, ValueError):
        pass
    # the offset as it is NOW, summer time and all (a Windows host has no zone file): right until
    # the next change of the clocks, and sent again whenever the board's stream opens
    here = time.localtime()
    name = ''.join(c for c in (here.tm_zone or 'UTC') if c.isascii() and c.isalpha())[:5] or 'UTC'   # a localized Windows zone name
    name = name if len(name) >= 3 else 'LOC'          # POSIX wants three letters or more
    hours = -(here.tm_gmtoff or 0) / 3600             # POSIX counts west as positive
    return f"{name}{int(hours) if hours == int(hours) else hours:g}"


def clock():
    """{'now': seconds since 1970, 'tz': POSIX zone}, for a device that keeps time."""
    return {'now': int(time.time()), 'tz': local_tz()}


# --- used by drivers -----------------------------------------------------------

def render(text):
    """Her voice as (bytes, content_type), or (None, the reason). Gated by the
    chat that produced the text when say() set one, else the effective chat.
    fit() makes it the format a device plays."""
    tts = getattr(_system(), 'tts', None)
    if tts is None or not hasattr(tts, 'render'):
        return None, "Speech is not available right now."
    return tts.render(text, chat_settings=_speaking_for.get(), **(_voice_for.get() or {}))


def wanted(plays):
    """The format a device stated, checked: {'type', 'rate', 'channels',
    'codec'}, or None when it stated none that can be made."""
    if not isinstance(plays, dict) or str(plays.get('type') or '').lower() != 'audio/wav':
        return None
    try:
        rate, channels = int(plays.get('rate') or 0), int(plays.get('channels') or 1)
    except (TypeError, ValueError):
        return None
    if not RATES[0] <= rate <= RATES[1] or channels not in (1, 2):
        return None
    from core.devices.audio_codecs import normalize
    return {'type': 'audio/wav', 'rate': rate, 'channels': channels, 'codec': normalize(plays.get('codec'))}


def _resample(sound, was, to):
    """One channel at another sample rate. Going down, what the new rate
    cannot carry is filtered out first, or it would come back as noise."""
    import numpy as np
    if was == to or not len(sound):
        return sound
    if to < was:
        edge = 0.46 * to / was                   # a little under half the new rate
        reach = 16 * int(np.ceil(was / to))
        n = np.arange(-reach, reach + 1)
        taps = 2 * edge * np.sinc(2 * edge * n) * np.hamming(len(n))
        sound = np.convolve(sound, taps / taps.sum(), mode='same')
    count = max(1, int(round(len(sound) * to / was)))
    return np.interp(np.arange(count) * (was / to), np.arange(len(sound)), sound)


def _trim(sound, rate):
    """Her words with a breath of silence each side, no more. A sentence
    rendered on its own comes with ~0.3 s of silence before and ~0.4 s after
    (Kokoro, measured 2026-10-03); joined one after another on a device that
    was a hole at every sentence, twice what a whole reply has between them."""
    import numpy as np
    loud = np.flatnonzero(np.abs(sound).max(axis=1) > QUIET)
    if not len(loud):
        return sound
    start = max(0, int(loud[0]) - int(HEAD * rate))
    end = min(len(sound), int(loud[-1]) + 1 + int(TAIL * rate))
    return sound[start:end]


def fit(audio, kind, plays):
    """Audio in the format a device plays: (bytes, content_type), or (None,
    the reason), with the silence at its ends trimmed to a breath. Audio that
    already fits is handed on untouched."""
    import numpy as np
    import soundfile as sf
    from core.devices.audio_codecs import encode
    want = wanted(plays)
    if want is None:
        return None, "This device stated a sound format I cannot make."
    try:
        with sf.SoundFile(io.BytesIO(audio)) as f:
            fits = (f.format == 'WAV' and f.subtype == 'PCM_16'
                    and f.samplerate == want['rate'] and f.channels == want['channels'])
            if fits and want['codec'] == 'pcm':
                return audio, want['type']       # already the exact PCM this board wants
            rate = f.samplerate
            sound = _trim(f.read(dtype='float32', always_2d=True), rate)
        one = sound.mean(axis=1)
        one = np.clip(_resample(one, rate, want['rate']), -1.0, 1.0)
        samples = np.column_stack([one] * want['channels'])
        return encode(samples, want['rate'], want['channels'], want['codec'])
    except Exception as e:
        logger.error(f"[DEVICES] could not convert {kind} speech: {e}", exc_info=True)
        return None, f"Her voice could not be converted for this device ({type(e).__name__})."


def duration(audio):
    """Seconds of sound in a WAV body, from its header (any codec, no decode).
    0 when it cannot be read. For a log line, not a decision."""
    import soundfile as sf
    try:
        info = sf.info(io.BytesIO(audio))
        return round(info.frames / info.samplerate, 2) if info.samplerate else 0
    except Exception:
        return 0


def stt_refusal(chat_settings=None):
    """Why audio may not be transcribed for this chat, or ''."""
    from core.voice_privacy import stt_gate_reason
    if chat_settings is None:
        chat_settings = _system().llm_chat.session_manager.get_chat_settings()
    return stt_gate_reason(chat_settings) or ''


def transcribe(audio, suffix='.wav'):
    """(what was said, '') or ('', the problem). Silence is ('', '')."""
    stt = getattr(_system(), 'whisper_client', None)
    if stt is None:
        return '', "Speech recognition is not available right now."
    fd, path = tempfile.mkstemp(suffix=suffix)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(audio)
        text = stt.transcribe_file(path)
    except STTFailed as e:
        return '', f"Speech recognition failed: {e}"
    except Exception as e:
        logger.error(f"[DEVICES] transcribe failed: {e}", exc_info=True)
        return '', f"Speech recognition failed ({type(e).__name__})."
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass
    return (text or '').strip(), ''


# --- which device, which chat --------------------------------------------------

def _part_with(row, *names):
    """The part of this device that has one of these capabilities, or None."""
    e = _engine()
    for part in row.get('parts', []):
        caps = e.capabilities(part, e._registry().get_driver(part.get('driver')))
        if any(n in caps for n in names):
            return part
    return None


def _voice_part(row):
    """The part of this device that has a microphone, or None."""
    return _part_with(row, 'mic')


def _talk_part(row):
    """The part that talks to her: a microphone or a keyboard. It holds the
    key the device sends and the chat its words land in."""
    return _part_with(row, 'mic', 'keyboard')


def chat_named(text):
    """The name to keep for what was typed into a device's chat setting: a
    chat that exists as it is, else the form a new chat is given."""
    from core.chat.history import sanitize_chat_name
    text = str(text or '').strip()[:64]
    if not text:
        return ''
    try:
        if _system().llm_chat.session_manager.chat_exists(text):
            return text
    except Exception:
        return text
    return sanitize_chat_name(text)[:64]


def chat_for(config, device_id=''):
    """(chat, its settings, '') for a device's settings: the chat it names,
    else the last chat used. A name that is no chat yet is made here (Krem
    2026-10-09: a typed name makes the chat). (chat, None, why) when the
    chat cannot be used: it is locked, or it could not be made."""
    from core.chat.history import landing_chat
    sm = _system().llm_chat.session_manager
    named = str((config or {}).get('chat') or '').strip()
    chat = named or landing_chat(sm)            # unnamed: where voice lands (a chat room open on the screen, else the active chat)
    settings = sm.get_settings_for(chat)
    if settings is None and named and not sm.chat_exists(named):
        from core.chat.history import sanitize_chat_name
        new = sanitize_chat_name(named)              # the name a chat made from these words gets
        if new and (sm.chat_exists(new) or sm.create_chat(new)):
            chat, settings = new, sm.get_settings_for(new)
            logger.info(f"[DEVICES] {device_id or 'a device'}: talks in the chat '{chat}', made for it if it was not there")
    if settings is None:
        return chat, None, f"The chat '{chat}' set for '{device_id}' cannot be opened."
    return chat, settings, ''


def bound_of(config):
    """{button: {how: job}} from a part's `buttons` setting: what its board
    is told. `tell` = send the press to Sapphire; any other job is one the
    board said it can do by itself."""
    out = {}
    held = (config or {}).get('buttons')
    for slot, pick in (held.items() if isinstance(held, dict) else ()):
        button, _, how = str(slot).rpartition('.')
        do = str(pick.get('do') or '') if isinstance(pick, dict) else ''
        if button and how in HOWS and do:
            out.setdefault(button, {})[how] = do
    return out


LABEL_MAX = 24


def labels(device_id):
    """The first words of the message set for each button's `tell` press, for
    a board that draws its buttons on a screen: {button: words}. The short
    press names it, else the long, else the double. {} when none. Never raises."""
    try:
        row = _engine().rows().get(str(device_id or '').strip().lower())
        part = _part_with(row, 'buttons') if row and row.get('enabled', True) else None
        held = (part.get('config') or {}).get('buttons') if part and 'buttons' in (part.get('has') or ()) else None
        out = {}
        for how in ('short', 'long', 'double'):
            for slot, pick in (held.items() if isinstance(held, dict) else ()):
                button, _, way = str(slot).rpartition('.')
                text = ' '.join(str(pick.get('text') or '').split()) if isinstance(pick, dict) else ''
                if way == how and button and button not in out and pick.get('do') == TELL and text:
                    out[button] = text[:LABEL_MAX].rstrip()
        return out
    except Exception as e:
        logger.warning(f"[DEVICES] {device_id}: its buttons' words could not be read: {e}")
        return {}


def bound(device_id):
    """What a device's presses are set to, for its events stream. None for a
    device with no buttons. Never raises."""
    try:
        row = _engine().rows().get(str(device_id or '').strip().lower())
        part = _part_with(row, 'buttons') if row and row.get('enabled', True) else None
        if not part or 'buttons' not in (part.get('has') or ()):     # only a board that SAID it has buttons knows the word
            return None
        return bound_of(part.get('config'))
    except Exception as e:
        logger.warning(f"[DEVICES] {device_id}: what its buttons do could not be read: {e}")
        return None


def key_ok(device_id, presented):
    """True when `presented` is the key stored for this device's voice - or
    the one provision() minted for this name, which becomes the stored one
    now (engine.promote): a board proves its new keys by calling in."""
    if not presented:
        return False
    return _key_stored(device_id, presented) or \
        (_engine().promote(device_id, presented) and _key_stored(device_id, presented))


def _key_part(row):
    """The part whose key the device presents: one whose driver says the
    device calls in on its own (learns_address), else the one that talks.
    A board with no microphone still has a light, sensors and a door."""
    e = _engine()
    for part in row.get('parts', []):
        if (e._registry().get_driver(part.get('driver')) or {}).get('learns_address'):
            return part
    return _talk_part(row)


def _key_stored(device_id, presented):
    e = _engine()
    row = e.rows().get(str(device_id or '').strip().lower())
    part = _key_part(row) if row and row.get('enabled', True) else None
    if not part:
        return False
    try:
        stored = e._part_secrets(row['id'], part['driver']).get('voice_key')
    except Exception:
        return False
    return bool(stored) and hmac.compare_digest(str(presented).encode(), stored.encode())


# --- the light ----------------------------------------------------------------

def _offer(queue, item):
    """On the stream's own loop. A full queue loses its oldest cue."""
    while True:
        try:
            return queue.put_nowait(item)
        except asyncio.QueueFull:
            try:
                queue.get_nowait()
            except asyncio.QueueEmpty:
                pass


def _send(loop, queue, item):
    try:
        loop.call_soon_threadsafe(_offer, queue, item)
    except RuntimeError:                 # that loop has closed
        pass


def cue(device_id, state, **more):
    """Tell ONE device what its light should show. Never waits, never raises."""
    if state not in CUES:
        return
    payload = dict(more, state=state, src='device', ts=time.time())
    with _lock:
        if state in ('thinking', 'tool'):
            _showing[device_id] = payload
        elif state not in ('text', 'buttons'):   # a doorbell, or what its buttons do, says nothing about the light
            _showing.pop(device_id, None)
        streams = list(_listeners.get(device_id, ()))
    for loop, queue in streams:
        _send(loop, queue, payload)


def listen(device_id, loop, queue):
    """A device opened its light stream. Returns the cue it should show right
    now, or None - a stream that reconnects mid-turn is not left behind."""
    with _lock:
        held = _listeners.setdefault(device_id, [])
        while len(held) >= MAX_LISTENERS:
            _send(*held.pop(0), None)    # None ends the oldest stream
        held.append((loop, queue))
        now = _showing.get(device_id)
    return now if now and time.time() - now['ts'] < CUE_FRESH else None


def unlisten(device_id, loop, queue):
    with _lock:
        held = _listeners.get(device_id, [])
        if (loop, queue) in held:
            held.remove((loop, queue))
        if not held:
            _listeners.pop(device_id, None)


def _follow(device_id, event, speech=None, reply=None):
    """The light follows the tools of this device's own turn, and each
    sentence of her voice goes to the device as it is made; for a typed
    question each piece of her text goes to its Reply instead."""
    kind = event.get('type')
    if kind == 'tool_start':
        cue(device_id, 'tool', tool_name=str(event.get('name') or '')[:60])
    elif kind == 'tool_end':
        cue(device_id, 'thinking')
    elif kind == 'tts_chunk' and speech is not None:
        speech.feed(event)
    elif kind == 'content' and reply is not None:
        reply.add(event.get('text') or '')


# --- her words, as they are written -------------------------------------------------

class Reply:
    """Her reply to one typed question, as a screen follows it: the text so
    far, a revision that goes up when her final text differs from what
    streamed (a tool round joined, thinking stripped), and a doorbell on the
    device's stream at most every DOORBELL_GAP seconds saying how much there
    is. The device pulls the words with reply_text(); a doorbell lost on a
    full stream is made good by the next one."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.msg = uuid.uuid4().hex[:12]
        self.rev = 0
        self.text = ''                   # what a screen may show: the stream with its thinking taken out
        self.done = False
        self._raw = ''
        self._rang = 0.0
        with _lock:
            held = _replies.setdefault(device_id, [])
            held.append(self)
            del held[:-TEXT_KEEP]

    def add(self, text):
        """A piece of her stream. A model that thinks inside its text
        (<think>...</think>) streams that too; only what she is saying
        reaches the screen (Krem saw the tags on the glass, 2026-10-06)."""
        if not text or self.done:
            return
        from core import think
        self._raw = (self._raw + text)[:TEXT_MAX * 4]
        shown = small_screen(think.strip(self._raw))[:TEXT_MAX]
        if shown == self.text:
            return
        if not shown.startswith(self.text):      # the visible text changed under the device: a new revision
            self.rev += 1
        self.text = shown
        self.ring()

    def ring(self, force=False):
        now = time.monotonic()
        if not force and now - self._rang < DOORBELL_GAP:
            return
        self._rang = now
        cue(self.device_id, 'text', msg=self.msg, rev=self.rev, have=len(self.text), done=self.done)

    def finish(self, final):
        """Her text as the turn kept it. More of the same is just more to
        pull; a different text (tool rounds joined, a prefill) is a new
        revision, pulled from the start."""
        final = small_screen(str(final or ''))[:TEXT_MAX]
        if final and final != self.text:
            if not final.startswith(self.text):
                self.rev += 1
            self.text = final
        self.done = True
        self.ring(force=True)

    def slice(self, start, limit):
        start = max(0, min(int(start), len(self.text)))
        limit = max(1, min(int(limit), PULL_MAX))
        return {'msg': self.msg, 'rev': self.rev, 'from': start, 'text': self.text[start:start + limit],
                'have': len(self.text), 'done': self.done}


def reply_text(device_id, msg='', start=0, limit=PULL_MAX):
    """A piece of her reply for a device's screen: the message named, or the
    latest when none is (a device that just connected). A message that is no
    longer kept answers with the latest, whose id the device will not match."""
    with _lock:
        held = list(_replies.get(str(device_id or '').strip().lower(), ()))
    if not held:
        return {'msg': '', 'rev': 0, 'from': 0, 'text': '', 'have': 0, 'done': True}
    rec = next((r for r in held if r.msg == msg), None) if msg else held[-1]
    return (rec or held[-1]).slice(start if rec else 0, limit)


# --- her voice, as it is made ----------------------------------------------------

class Speech:
    """Her reply spoken on one device sentence by sentence. The turn's TTS
    pump renders each sentence and feed() takes it; one worker plays them in
    order, each play returning when the device has finished it, so a
    sentence that is ready early waits its turn. feed() never blocks the
    turn. wait() at the end does, until the last sentence has played.
    The device's own stop (the Pi's button) ends the rest of the reply."""

    def __init__(self, device_id):
        self.device_id = device_id
        self.door = _engine().speaker(device_id)     # None: this device cannot take sound as it is made
        self.queue = queue.Queue()
        self.spoken = 0                              # sentences the device has played
        self.stopped = False                         # the device stopped it, or a play failed
        self.turn = None                             # the turn it speaks for (_turn's box): a stop at the device ends that turn
        self.problem = None
        self._thread = None

    @property
    def ready(self):
        return self.door is not None

    def feed(self, event):
        if not self.ready or self.stopped:
            return
        try:
            audio = base64.b64decode(event.get('audio_b64') or '')
        except (TypeError, ValueError):
            return
        if not audio:
            return
        self.queue.put((audio, str(event.get('content_type') or 'audio/ogg'), str(event.get('stream_id') or '')))
        if self._thread is None:
            with _lock:
                _live.setdefault(self.device_id, []).append(self)
            self._thread = threading.Thread(target=self._play_all, daemon=True,
                                            name=f'device-speech-{self.device_id}')
            self._thread.start()

    def finish(self):
        """No more sentences are coming."""
        self.queue.put(None)

    def wait(self, timeout=SPEECH_WAIT):
        """Until the device has played everything it was given. True when it did."""
        if self._thread is None:
            return True
        self._thread.join(timeout)
        if self._thread.is_alive():
            logger.warning(f"[DEVICES] {self.device_id}: still speaking after {timeout}s, not waited for")
            return False
        return True

    def _forget(self):
        with _lock:
            held = _live.get(self.device_id, [])
            if self in held:
                held.remove(self)
            if not held:
                _live.pop(self.device_id, None)

    def _play_all(self):
        mod, device, config, secrets = self.door
        while True:
            item = self.queue.get()
            if item is None:
                return self._forget()
            if self.stopped:
                continue                             # drain what is left, play nothing
            audio, kind, sid = item
            t0 = time.monotonic()
            try:
                said = mod.play(audio, kind, device, config, secrets, sid=sid)   # the reply's stream id: a board whose face stream claimed this reply skips it (glass.av_carried)
            except Exception as e:
                self.problem, self.stopped = str(e), True
                logger.warning(f"[DEVICES] {self.device_id}: a sentence could not be played: {e}")
                continue
            self.spoken += 1
            took = time.monotonic() - t0
            sound = said.get('seconds') if isinstance(said, dict) else None
            logger.info(f"[DEVICES] {self.device_id}: sentence {self.spoken}"
                        + (f", {sound}s of sound" if sound is not None else '') + f", taken in {took:.2f}s")
            if isinstance(said, dict) and said.get('stopped'):
                self.stopped = True
                logger.info(f"[DEVICES] {self.device_id}: stopped at the device after {self.spoken} sentence(s)")
                interrupt(self.device_id, only=self.turn)


# --- the halves ----------------------------------------------------------------

def say(device_id, text, chat_settings=None, voice=None, speed=None, pitch=None):
    """Speak on a device. Returns (what happened, ok). voice/speed/pitch: a
    chat-room seat's own (core/rooms.py), within the active engine; None = the
    live client's."""
    own = {k: v for k, v in (('voice', voice), ('speed', speed), ('pitch', pitch)) if v} or None
    token, lane, mine = _speaking_for.set(chat_settings), _lane.set(True), _voice_for.set(own)
    try:
        said, ok = _engine().run(device_id, 'speaker', 'say', text, owner=True)
    finally:
        _speaking_for.reset(token)
        _lane.reset(lane)
        _voice_for.reset(mine)
    _spoke.ok = bool(ok)
    return _engine().text_of(said), ok


def halt(device_id):
    """Her sentences still to be sent to this device are dropped, and her face
    stream to it with them (glass.av_clear: its source holds the rest of the reply).
    True when a reply was being spoken there. What the device is playing this
    moment is the driver's to cut. Every door that stops her passes here (the
    wake word said over her, the stop tool, a room, the board's own button), so
    every one clears the stream: only the button did (scouts 2026-11-05)."""
    with _lock:
        live = list(_live.get(device_id, ()))
    for speech in live:
        speech.stopped = True
    cleared = False
    try:
        from core.devices import glass
        cleared = glass.av_clear(device_id)  # cheap when no stream of hers goes there
    except Exception as e:
        logger.info(f"[DEVICES] {device_id}: her stream not stopped ({e})")
    return bool(live) or cleared


_running = {}        # device id -> (its turn's box, chat): the turn she is answering that device with, while it runs
_turns = {}          # device id -> [box, ...]: every turn of that device not yet over, the waiting ones too


def answering(device_id):
    """True while her reply to that device is being spoken there as she
    writes it. A `say` on it then would be her answer said a second way, as a
    tool call a stop cannot keep (2026-10-11): the driver refuses it."""
    if _lane.get():                      # the reply lane's own say, when no sentence was made as she wrote
        return False
    with _lock:
        turn, _ = _running.get(device_id, (None, None))
    speech = turn.get('speech') if turn else None
    # only her own turn: a reminder or another chat speaking there is not her answer said twice
    return bool(speech and speech.ready and turn.get('thread') == threading.get_ident())


def interrupt(device_id, only=None):
    """The person at a device cut her off (its stop, or its wake word said
    over her): what she was still to say there is dropped AND the turn stops
    being written, so the next question is not left waiting behind an answer
    nobody will hear (24 s, 2026-10-11). `only`: that turn and no other, for
    a stop that is learned late, when the device's next turn may be running.
    True when there was something to end. Never raises."""
    if only is not None:                 # that turn's voice and no other's
        speech = only.get('speech')
        was = bool(speech and not speech.stopped)
        if speech:
            speech.stopped = True
    else:
        was = halt(device_id)
    with _lock:
        turn, chat = _running.get(device_id, (None, None))
        if only is None:                 # and the questions still waiting their turn: asked, then asked over
            for box in _turns.get(device_id, ()):
                if box is not turn and not box.get('dropped'):
                    box['dropped'] = was = True
    if turn is None or (only is not None and turn is not only):
        return was
    try:
        n = _system().llm_chat.cancel_streams(chat)
        if n:
            logger.info(f"[DEVICES] {device_id}: cut off at the device, the turn in chat '{chat}' is ended")
        return was or bool(n)
    except Exception as e:
        logger.warning(f"[DEVICES] {device_id}: the turn could not be ended: {e}")
        return was


def say_all(text):
    """Say it on every device that can speak, at once: her voice rendered
    once (gated like render), fitted and played on each device on its own
    thread. A device whose button stops it stops the others. Returns (one
    line per device, ok). say('all', ...) comes here through the engine."""
    e = _engine()
    text = str(text or '').strip()
    if not text:
        return "say: the value is what to say. Example: Dinner is ready", True
    doors = e.speakers()
    if not doors:
        return "No device can speak right now.", False
    audio, kind = render(text)
    if audio is None:
        return f"Nothing was said: {kind}", False
    said, first = {}, []

    def one(door):
        mod, device, config, secrets = door
        try:
            out = mod.play(audio, kind, device, config, secrets)
        except Exception as ex:
            said[device['id']] = f"not said: {ex}"
            return
        if not (isinstance(out, dict) and out.get('stopped')):
            said[device['id']] = 'said'
            seconds = out.get('seconds') if isinstance(out, dict) else None
            if isinstance(seconds, (int, float)):      # a board that answers when it has taken the sound plays on: a stop there asks us (_ask_stop)
                with _lock:
                    _announcing[device['id']] = time.monotonic() + seconds + 2
            return
        with _lock:
            lead = not first
            first.append(device['id'])
        if lead:                                     # the one that was stopped first stops the rest
            said[device['id']] = 'stopped there, so stopped everywhere'
            stop_all(but=device['id'])
        else:
            said[device['id']] = 'stopped'
    threads = [threading.Thread(target=one, args=(d,), daemon=True, name=f"say-all-{d[1]['id']}") for d in doors]
    for t in threads:
        t.start()
    end = time.monotonic() + SAY_ALL_WAIT
    for t in threads:
        t.join(max(0.0, end - time.monotonic()))
    lines = [f"{d[1]['id']}: {said.get(d[1]['id'], 'still playing')}" for d in doors]
    ok = any(v in ('said', 'stopped', 'stopped there, so stopped everywhere') for v in said.values())
    short = text if len(text) <= 80 else text[:77] + '...'
    return f'Said on {len(doors)} device(s): "{short}"\n' + '\n'.join(lines), ok


def stop_all(but=None):
    """Stop her voice on every device whose speaker has a `stop` action,
    each on its own thread. Returns (one line per device, ok)."""
    e = _engine()
    todo = []
    for device_id, row in e.rows().items():
        if device_id == but or not row.get('enabled', True):
            continue
        cap = next((c for c in e.describe(row) if c['capability'] == 'speaker'), None)
        if cap and not cap['error'] and 'stop' in cap['actions']:
            todo.append(device_id)
    if not todo:
        return "No device has a stop.", False
    said = {}

    def one(device_id):
        told, ok = e.run(device_id, 'speaker', 'stop', owner=True)
        said[device_id] = e.text_of(told) if ok else f"not stopped: {e.text_of(told)}"
    threads = [threading.Thread(target=one, args=(d,), daemon=True, name=f'stop-all-{d}') for d in todo]
    for t in threads:
        t.start()
    for t in threads:
        t.join(30)
    return '\n'.join(f"{d}: {said.get(d, 'no answer yet')}" for d in todo), any(not v.startswith('not stopped') for v in said.values())


# The end of the line above what a device heard. "Just answer": she once called say for her own
# reply, as a tool call a stop at the device could not keep (2026-10-11).
ALOUD = "Your reply is spoken aloud there by itself: just answer, never call say on that device for it."


def origin_line(row):
    """The line she reads above anything a device heard: which device, where
    it is, and that her answer is said out loud there."""
    def clean(text):
        return ' '.join(str(text or '').replace('[', '(').replace(']', ')').split())
    label, where = clean(row.get('label')), clean(row.get('location'))
    name = f'"{row["id"]}"' + (f" ({label})" if label and label != row['id'] else '')
    return (f"[Voice from device {name}." + (f" Location: {where}." if where else '')
            + f" {ALOUD}]")


def typed_line(row):
    """The same line for words typed on a device's keyboard: her reply is
    read on its small screen, not heard."""
    spoken = origin_line(row)
    return spoken.replace('[Voice from device', '[Typed on device', 1) \
                 .replace(ALOUD, 'Your reply is shown on its small screen.', 1)


def pressed_line(row, out):
    """The line above a button's message. `out` is where her reply goes:
    'voice', 'screen', or 'none' for a device that can do neither."""
    spoken = origin_line(row).replace('[Voice from device', '[Button pressed on device', 1)
    told = {'screen': 'Your reply is shown on its small screen.',
            'none': 'It can neither speak nor show a reply.'}.get(out)
    return spoken.replace(ALOUD, told, 1) if told else spoken


def _ask_backup(row):
    """A press that asks for a backup onto the device's own card, now.
    (taken, a line short enough for a small screen)."""
    from core.devices import storage
    target = storage.target_for(row['id'])
    if target is None:
        return False, 'No card to back up to'
    text, ok = storage.backup_now(target)
    return bool(ok), ('Backup is on its way' if ok and 'already' not in text else 'A backup is already on its way' if ok else text[:60])


def _ask_stop(row):
    """She was stopped at the device (a tap, a button): the turn she is making
    for it ends, and the ones waiting. During a say_all there, every other
    device stops too, as a stop answered `stopped` does."""
    with _lock:
        until = _announcing.pop(row['id'], 0)
        if until > time.monotonic():
            _announcing.clear()
    if until > time.monotonic():
        threading.Thread(target=stop_all, kwargs={'but': row['id']}, daemon=True, name='stop-all-asked').start()
        interrupt(row['id'])
        return True, 'Stopped everywhere'
    was = interrupt(row['id'])           # halt() inside clears her face stream too (glass.av_clear)
    return True, ('Stopped' if was else 'Nothing to stop')


# Work a board asks of Sapphire, with no chat turn: POST /api/devices/{id}/ask {"job": ...}
# (asked(), below), or the `job` of a press left to the board (pressed()). A new one is a
# function (row) -> (taken, a line short enough for a small screen) and a name here.
ASKS = {'backup': _ask_backup, 'stop': _ask_stop}


def asked(device_id, job):
    """A board asks Sapphire for a job that is hers to do (ASKS). {'ok',
    'accepted', 'job', 'said'}, or {'ok': False, 'error'}. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        job = str(job or '').strip().lower()[:24]
        if job not in ASKS:
            return {'ok': False, 'error': f"'{job}' is not a job a board can ask for. Known: {', '.join(sorted(ASKS))}."}
        ok, said = ASKS[job](row)
        logger.info(f"[DEVICES] {row['id']} asked for {job}: {said}")
        return {'ok': True, 'accepted': bool(ok), 'job': job, 'said': said}
    except Exception as e:
        logger.error(f"[DEVICES] asked({device_id}, {job}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


CHATS_MAX = 40                     # names a board is handed: a picker on a small screen


def _board_chats():
    """The chats a board may pick and read, newest first: plain ones. No
    private chat, nothing archived, no game or story session. All of them:
    chats() hands a board the newest CHATS_MAX, but the one it was set to
    stays pickable and readable however old (it read back as nothing past
    the cap, 2026-10-16)."""
    out = []
    for c in _system().llm_chat.session_manager.list_chat_files():
        if c.get('private_chat') or c.get('archived') or c.get('kind', 'chat') != 'chat':
            continue
        out.append(c['name'])
    return out


def _browse(part):
    """May this board's picker list every open chat? Off, the default: the one
    it talks in only, and its key reaches no other (Settings > Devices)."""
    return bool((part.get('config') or {}).get('browse'))


def _now(part):
    """The chat a board talks in: its own setting, else where voice lands."""
    from core.chat.history import landing_chat
    return str((part.get('config') or {}).get('chat') or '').strip() or landing_chat(_system().llm_chat.session_manager)


def chats(device_id):
    """The chats a board can pick from, for a picker on its own screen (GET
    /chats): {'ok', 'chat': the one it talks in now, 'chats': [names]}. A
    private chat is never named to a board, not even as the one it talks in.
    With Browse chats off (the default) the list is that one chat alone.
    Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _talk_part(row) or _chat_part(row)
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has nothing that talks in a chat."}
        names = _board_chats()
        now = _now(part)
        now = now if now in names else ''
        if not _browse(part):
            return {'ok': True, 'chat': now, 'chats': [now] if now else []}
        handed = names[:CHATS_MAX]
        if now and now not in handed:
            handed.insert(0, now)                          # the one it talks in is on its picker however old
        return {'ok': True, 'chat': now, 'chats': handed}
    except Exception as e:
        logger.error(f"[DEVICES] chats({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def pick_chat(device_id, name):
    """A board picked the chat it talks in (POST /chat {"name"}). Kept as the
    talking part's `chat` setting, the same as typing it on the Devices page:
    what the board sends lands there from now on, and the glass is brought
    up to date so the name comes back to its screen. Only a chat the board
    could be handed (chats()) can be picked: no guessing a private one, and
    with Browse chats off only the one it shows (which changes nothing). The
    chat open in the browser is never changed. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _talk_part(row) or _chat_part(row)
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has nothing that talks in a chat."}
        name = str(name or '').strip()[:64]
        if name not in _board_chats():
            return {'ok': False, 'error': f"'{name}' is not a chat this board can pick."}
        if not _browse(part):
            if name == _now(part):
                return {'ok': True, 'chat': name}                  # the one it shows: nothing to keep
            return {'ok': False, 'error': f"'{row['id']}' may not browse chats (Settings > Devices > Browse chats)."}
        e.update(row['id'], parts={part['driver']: {'chat': name}})
        kept = e.rows().get(row['id']) or {}
        if not any(str((p.get('config') or {}).get('chat') or '') == name for p in kept.get('parts') or []):
            return {'ok': False, 'error': f"'{row['id']}' has no chat setting to keep the pick in."}
        from core.devices import glass
        glass.sync_soon(row['id'])
        logger.info(f"[DEVICES] {row['id']} picked the chat '{name}'")
        return {'ok': True, 'chat': name}
    except Exception as e:
        logger.error(f"[DEVICES] pick_chat({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


_following = False


def follow_chats():
    """A device's `chat` setting names a chat (typed, or picked on the board): a rename
    carries the name along and a delete clears it, as core/hooks.py asks of anything
    keying data by chat name. Else the board talked into a fresh empty chat made under
    the old name (voice.chat_for). Once; safe to call again."""
    global _following
    if _following:
        return
    _following = True
    from core.event_bus import get_event_bus
    get_event_bus().on(('chat_renamed',), lambda ev: _spawn(_chat_moved, (ev.get('data') or {}).get('old'), (ev.get('data') or {}).get('new')))
    get_event_bus().on(('chat_deleted',), lambda ev: _spawn(_chat_moved, (ev.get('data') or {}).get('name'), ''))


def _chat_moved(old, new):
    """Every part that talks in `old` talks in `new` now ('': its own setting goes, its
    voice lands where voice lands), and its glass is brought up to date."""
    old, new = str(old or '').strip(), str(new or '').strip()
    if not old or old == new:
        return
    try:
        e = _engine()
        for row in e.rows().values():
            parts = {p['driver']: {'chat': new} for p in row.get('parts') or []
                     if p.get('driver') and str((p.get('config') or {}).get('chat') or '').strip() == old}
            if not parts:
                continue
            e.update(row['id'], parts=parts)
            from core.devices import glass
            glass.sync_soon(row['id'])
            logger.info(f"[DEVICES] {row['id']}: the chat '{old}' it talked in is {'now ' + repr(new) if new else 'gone, its setting is cleared'}")
    except Exception as ex:
        logger.warning(f"[DEVICES] following the chat '{old}' into the device settings failed: {ex}")


# Emoji on a small screen: the fonts there have none. The common ones become
# the faces they came from; the rest, with the joiners and variation marks that
# ride along, are left out. Applied wherever her words go to a board's screen.
FACES = {'🙂': ':)', '🙃': ':)', '😊': ':)', '😀': ':)', '😃': ':)', '😄': ':)', '😁': ':)', '☺': ':)', '😉': ';)',
         '😂': ':D', '🤣': ':D', '😆': ':D', '😢': ":'(", '😭': ":'(", '😞': ':(', '😔': ':(', '🙁': ':(', '☹': ':(',
         '😮': ':o', '😲': ':o', '😛': ':P', '😜': ':P', '🤔': 'hmm', '😍': '<3', '🥰': '<3', '😘': '<3',
         '❤': '<3', '🧡': '<3', '💛': '<3', '💚': '<3', '💙': '<3', '💜': '<3', '🖤': '<3', '🤍': '<3', '💕': '<3', '💖': '<3',
         '💗': '<3', '💓': '<3', '👍': '+1', '👎': '-1', '👋': '(wave)', '✅': '[x]', '⭐': '*', '✨': '*', '🔥': '(fire)'}
_FACES = re.compile('|'.join(re.escape(k) for k in sorted(FACES, key=len, reverse=True)) + r'\uFE0F?')
_EMOJI = re.compile(r'[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE00-\uFE0F\u200D\u20E3\U000E0020-\U000E007F]')
_SPACES = re.compile(r'[ \t]{2,}')
_LEAD = re.compile(r'(?m)^ +')


def small_screen(text):
    """Her words as a board's small screen can draw them: the common emoji as
    faces, the rest left out, the spacing tidied."""
    text = str(text or '')
    if not _EMOJI.search(text):
        return text
    text = _FACES.sub(lambda m: FACES[m.group(0).rstrip('\uFE0F')], text)
    text = _EMOJI.sub('', text)
    return _LEAD.sub('', _SPACES.sub(' ', text).replace(' \n', '\n'))


HISTORY_MAX = 1500                 # bytes of text one history pull hands a board (its buffer is small)
HISTORY_EACH = 3000                # bytes one message is cut to; the reader draws that much of a reply
_ORIGIN = re.compile(r'^\[(?:Voice from|Typed on|Button pressed on) device [^\]]*\]\s*')
_MARKER = re.compile(r'<!--[A-Z]+:.*?-->\s*', re.S)


def _plain_text(message):
    """A message as a small screen reads it: the words only. '' for a message
    with none (a tool round, a picture alone). An attached file is named,
    never sent: its body stays on the box. Thinking goes the way the UI
    strips it (every form, closed or not), and the browser's widget markers."""
    from core import think
    from core.ui_markers import UI_MARKER_RE
    content = message.get('content')
    if isinstance(content, list):
        bits = []
        for b in content:
            if isinstance(b, str):
                bits.append(b)
            elif isinstance(b, dict) and b.get('type') == 'text':
                bits.append(str(b.get('text') or ''))
            elif isinstance(b, dict) and b.get('type') == 'file':
                bits.append(f"({b.get('filename') or 'a file'})")
        content = ' '.join(bits)
    text = str(content or '')
    if message.get('role') == 'user':
        text = _ORIGIN.sub('', text, count=1)
    text = UI_MARKER_RE.sub('', _MARKER.sub('', think.strip(text)))
    return small_screen(text).strip()


def _wire_bytes(text):
    """What one message costs the board's buffer: its JSON, as the door sends
    it (UTF-8, compact), with the row around it. The board's buffer is sized
    for `most` plus one whole message; counting the words alone overran it
    for a chat of short lines (2026-10-16)."""
    return len(json.dumps(text, ensure_ascii=False).encode('utf-8')) + 22


def _cut_bytes(text, most):
    """The first `most` bytes of text, on a whole character, '...' when cut."""
    raw = text.encode('utf-8')
    if len(raw) <= most:
        return text
    return raw[:most].decode('utf-8', 'ignore').rstrip() + '...'


def history(device_id, before=None, most=HISTORY_MAX):
    """The chat a board talks in, read back for its screen (GET /history):
    {'ok', 'chat', 'messages': [{'who': 'you' | 'her', 'text'}] newest first,
    'before': the cursor for the next older pull (0 = nothing older),
    'total'}. `before` in is that cursor; left out = the newest. Whole
    messages, at least one, until `most` bytes; each cut to HISTORY_EACH.
    A private chat reads back as nothing. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _talk_part(row) or _chat_part(row)
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has nothing that talks in a chat."}
        sm = _system().llm_chat.session_manager
        chat = _now(part)
        nothing = {'ok': True, 'chat': '', 'messages': [], 'before': 0, 'total': 0}
        if chat not in _board_chats():
            return nothing
        plain = []
        for m in sm.get_display_messages_for(chat) or []:
            if m.get('role') in ('user', 'assistant'):
                text = _plain_text(m)
                if text:
                    plain.append(('you' if m['role'] == 'user' else 'her', text))
        try:
            end = min(int(before), len(plain)) if before not in (None, '') else len(plain)
        except (TypeError, ValueError):
            end = len(plain)
        most = max(200, min(int(most or HISTORY_MAX), 8000))
        out, used, at = [], 0, end
        while at > 0:
            who, text = plain[at - 1]
            text = _cut_bytes(text, HISTORY_EACH)
            size = _wire_bytes(text)
            while size > HISTORY_EACH + 64 and len(text) > 16:    # quotes and newlines grow on the wire: cut to what fits
                text = _cut_bytes(text, int(len(text.encode('utf-8')) * 0.8))
                size = _wire_bytes(text)
            if out and used + size > most:
                break
            out.append({'who': who, 'text': text})
            used += size
            at -= 1
        return {'ok': True, 'chat': chat, 'messages': out, 'before': at, 'total': len(plain)}
    except Exception as e:
        logger.error(f"[DEVICES] history({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def press_text(row, button, how):
    """What a press says when no message was set for it."""
    return f"The {button} button on {row['id']} was pressed{ {'long': ' and held', 'double': ' twice'}.get(how, '') }."


def _spawn(fn, *args):
    threading.Thread(target=fn, args=args, daemon=True, name='device-turn').start()


def _take_slot(device_id):
    with _lock:
        if _waiting.get(device_id, 0) >= MAX_WAITING:
            return False
        _waiting[device_id] = _waiting.get(device_id, 0) + 1
        return True


def _free_slot(device_id):
    with _lock:
        left = _waiting.get(device_id, 0) - 1
        if left > 0:
            _waiting[device_id] = left
        else:
            _waiting.pop(device_id, None)


def _turn(row, chat, heard, reply=None, line=None, mute=False, images=None):
    """One question from start to finish, on its own thread. Never raises.
    Her reply is spoken on the device as it is made (Speech); a device whose
    driver cannot take sound that way hears it whole at the end, through
    the reply lane. With a Reply (a typed question) nothing is spoken: her
    text goes to the device's screen as she writes it. `mute` is a device
    that can do neither (a button and a light): her reply stays in the chat.
    `line` is the line above the words when it is neither heard nor typed.
    `images` are pictures that came with the words (a photo shared from a
    phone): kept in the chat like a pasted picture, not a glance.
    The light ends on idle, or on error when the person got no answer."""
    device_id, failed, speech, box = row['id'], False, None, {}
    lane = f"device:{device_id}"
    with _lock:
        _turns.setdefault(device_id, []).append(box)
    try:
        from core import cadence
        from core.chat import inbox
        cue(device_id, 'thinking')
        text = f"{line or (typed_line(row) if reply else origin_line(row))}\n{heard}"

        def _body():
            # Runs when it is the chat's turn (core/chat/inbox.py, 'now' lane:
            # a person is waiting - it never drops, Krem 2026-10-06; before,
            # a chat busy for BUSY_WAIT dropped the question). Speech is made
            # HERE so its door is fresh after a wait, and _spoke - a
            # threading.local set by voice.say inside run_turn - is read on
            # this same thread before returning.
            _spoke.ok = None
            if box.get('dropped'):       # cut off while it waited: the person has asked something else since
                return ''
            sp = Speech(device_id) if reply is None and not mute else None
            box['speech'] = sp
            if sp:
                sp.turn = box
            box['thread'] = threading.get_ident()
            with _lock:
                _running[device_id] = (box, chat)
            try:
                with_pictures = {'images': images, 'keep_images': True} if images else {}   # the old call shape otherwise
                return cadence.run_turn(chat, text, speak=lane if sp else None, source=lane,
                                        on_event=lambda ev: _follow(device_id, ev, sp, reply),
                                        stream_speech=bool(sp and sp.ready), **with_pictures)
            finally:
                box['spoke_ok'] = getattr(_spoke, 'ok', None)
                with _lock:
                    if _running.get(device_id, (None,))[0] is box:
                        _running.pop(device_id, None)

        said = inbox.turn(chat, _body, source=lane, lane='now', text=heard)   # a room: the words land as a line
        speech = box.get('speech')
        if box.get('dropped') and speech is None:
            if reply is not None:
                reply.finish('')
            logger.info(f"[DEVICES] {device_id}: a question that was waiting was cut off at the device, not answered")
            return
        if reply is not None:
            reply.finish(said)
            failed = not said
            logger.info(f"[DEVICES] {device_id}: answered in chat '{chat}' on its screen, "
                        f"{len(said or '')} chars, rev {reply.rev}")
            return
        if speech is None:               # nowhere to say it: it is in the chat
            failed = not said
            logger.info(f"[DEVICES] {device_id}: answered in chat '{chat}', {len(said or '')} chars, kept in the chat")
            return
        speech.finish()
        speech.wait()
        if said and (box.get('spoke_ok') is False or (speech.problem and not speech.spoken)):
            failed = True                # she answered, and the device could not say it
        logger.info(f"[DEVICES] {device_id}: answered in chat '{chat}', {len(said or '')} chars"
                    + (f', {speech.spoken} sentence(s) as made' if speech.spoken else '')
                    + (', stopped at the device' if speech.stopped and speech.spoken else '')
                    + (', NOT spoken' if failed else ''))
    except Exception as e:
        failed = True
        speech = speech or box.get('speech')     # the body made it before the turn broke off
        if speech is not None:
            speech.stopped = True        # a reply that broke off is not read out to the end
        if reply is not None:
            reply.finish(reply.text)     # what came through stays; the device learns it is over
        logger.error(f"[DEVICES] {device_id}: the turn failed: {e}", exc_info=True)
    finally:
        speech = speech or box.get('speech')
        if speech is not None:
            speech.finish()              # the worker goes home whatever happened
        _free_slot(device_id)
        wake.release(device_id)
        with _lock:
            held = _turns.get(device_id, [])
            if box in held:
                held.remove(box)
            if not held:
                _turns.pop(device_id, None)
            more = _waiting.get(device_id, 0) > 0
        # Its next question is already waiting (asked over this one): that turn said
        # 'thinking' before this one ended, and an 'idle' now would land on top of it.
        cue(device_id, 'thinking' if more else 'error' if failed else 'idle')


def room(device_id, audio, meta=None):
    """A device sends a piece of its room (POST /api/devices/{id}/room): the
    seconds its microphone heard since the last piece, capture after capture,
    with the wake fires that fell in it (meta['fires']: [[seconds, score]]).
    Handed to whoever collects room sound (`room_sink`); with nobody there
    the answer says `accepted: false` and the board ends its capture. Never
    raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        if not _voice_part(row):
            return {'ok': False, 'error': f"'{row['id']}' has no microphone."}
        if not audio:
            return {'ok': False, 'error': 'No audio arrived.'}
        if len(audio) > MAX_AUDIO:
            return {'ok': False, 'error': 'The audio is too large.'}
        sink = room_sink
        if sink is None:
            return {'ok': True, 'accepted': False, 'error': 'Nobody is collecting room sound from this device.'}
        out = sink(row['id'], audio, dict(meta or {}))
        if not isinstance(out, dict):
            out = {'ok': True, 'accepted': bool(out)}
        return out
    except Exception as e:
        logger.error(f"[DEVICES] room({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def woke(device_id):
    """A device's wake word fired and it asks for the room before it has
    anything to send (POST /api/devices/{id}/wake). {'ok', 'yours'} and, when
    not, 'taken_by'. A device that is refused records nothing and shows its
    resting light. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True) or not _voice_part(row):
            return {'ok': False, 'error': f"There is no device named '{device_id}' with a microphone, or it is turned off."}
        yours, taken_by = wake.claim(row['id'])
        if not yours:
            logger.info(f"[DEVICES] {row['id']} woke; the room is {taken_by}'s")
            return {'ok': True, 'yours': False, 'taken_by': taken_by}
        if interrupt(row['id']):           # said over her: the reply she was making for that device ends, spoken and written
            logger.info(f"[DEVICES] {row['id']} woke over her own answer: that turn is ended")
        logger.info(f"[DEVICES] {row['id']} woke and holds the room")
        return {'ok': True, 'yours': True}
    except Exception as e:
        logger.error(f"[DEVICES] woke({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def typed(device_id, text):
    """A device with a keyboard sends what was typed. {'ok', 'accepted',
    'chat', 'msg'} or {'ok': False, 'error'}. accepted = a turn has started;
    her reply reaches the device's screen through `text` doorbells and
    reply_text(). Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _part_with(row, 'keyboard')
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has no keyboard."}
        text = str(text or '').strip()
        if not text:
            return {'ok': False, 'error': 'Nothing was typed.'}
        if len(text) > TYPED_MAX:
            return {'ok': False, 'error': f'That is more than {TYPED_MAX} characters.'}
        chat, settings, why = chat_for(part['config'], row['id'])
        if settings is None:
            return {'ok': False, 'error': why}
        logger.info(f"[DEVICES] {row['id']} typed {len(text)} chars for chat '{chat}'")
        if not _take_slot(row['id']):
            return {'ok': False, 'busy': True, 'chat': chat,
                    'error': f"'{row['id']}' already has {MAX_WAITING} questions waiting."}
        reply = Reply(row['id'])
        try:
            _spawn(_turn, row, chat, text, reply)
        except Exception:
            _free_slot(row['id'])
            raise
        return {'ok': True, 'accepted': True, 'chat': chat, 'msg': reply.msg}
    except Exception as e:
        logger.error(f"[DEVICES] typed({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def _chat_part(row):
    """The part whose settings name the device's chat: the one with a `chat`
    field, else the first. A phone has neither microphone nor keyboard."""
    parts = row.get('parts') or []
    return next((p for p in parts if 'chat' in (p.get('config') or {})), parts[0] if parts else None)


def said(device_id, line, text, images=None):
    """A device hands her words with no microphone and no screen (a phone
    through KDE Connect: a shared picture, a text message). The turn runs in
    the device's chat; her reply stays there. `line` is the line she reads
    above the words: what this is, which device, how to answer. `images`:
    [{'type': 'image', 'data': <base64>, 'media_type'}], kept in the chat as
    a pasted picture would be. {'ok', 'accepted', 'chat'} or {'ok': False,
    'error'}; busy = the device already has MAX_WAITING waiting. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        text = str(text or '').strip()[:SAID_MAX]
        images = [i for i in (images or []) if isinstance(i, dict) and i.get('data')][:4]
        if not text and not images:
            return {'ok': False, 'error': 'Nothing was said.'}
        part = _chat_part(row)
        chat, settings, why = chat_for((part or {}).get('config'), row['id'])
        if settings is None:
            return {'ok': False, 'error': why}
        logger.info(f"[DEVICES] {row['id']} said {len(text)} chars"
                    + (f" and {len(images)} picture(s)" if images else '') + f" for chat '{chat}'")
        if not _take_slot(row['id']):
            return {'ok': False, 'busy': True, 'chat': chat,
                    'error': f"'{row['id']}' already has {MAX_WAITING} questions waiting."}
        try:
            _spawn(_turn, row, chat, text or 'A picture.', None, str(line or '').strip() or origin_line(row),
                   True, images)
        except Exception:
            _free_slot(row['id'])
            raise
        return {'ok': True, 'accepted': True, 'chat': chat}
    except Exception as e:
        logger.error(f"[DEVICES] said({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def pressed(device_id, button, how, job=None):
    """A device's button was pressed (POST /api/devices/{id}/press). Answers
    {'ok', 'accepted', 'chat', 'text'} and 'msg' when her reply goes to its
    screen; accepted = a turn has started with the message set for that
    press. A press that is not set to send one is {'ok': True, 'accepted':
    False}: the board does everything else by itself. `job` is what the
    board says the press does when it is one of ASKS (work that is
    Sapphire's, with no chat turn): then {'ok', 'accepted', 'said'}.
    Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _part_with(row, 'buttons')
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has no buttons."}
        button, how = str(button or '').strip().lower()[:24], str(how or 'short').strip().lower()
        if not button or how not in HOWS:
            return {'ok': False, 'error': f"A press is a button's name and one of {', '.join(HOWS)}."}
        from core.devices import glass
        if glass.press(row['id'], button, how):      # a stream owns the board's taps (a game on its glass): the press is its, never a turn
            return {'ok': True, 'accepted': True, 'taken': 'glass'}
        held = part['config'].get('buttons')
        pick = (held if isinstance(held, dict) else {}).get(f'{button}.{how}')
        # what the page set wins; a press left to the board is the board's word, and only for a job in ASKS
        do = pick.get('do') if isinstance(pick, dict) and pick.get('do') else str(job or '').strip().lower()
        if do in ASKS:
            ok, said = ASKS[do](row)
            logger.info(f"[DEVICES] {row['id']}: {button} {how} pressed, {do}: {said}")
            return {'ok': True, 'accepted': ok, 'job': do, 'said': said}
        if not isinstance(pick, dict) or pick.get('do') != TELL:
            logger.info(f"[DEVICES] {row['id']}: {button} {how} pressed, nothing is set to be sent for it")
            return {'ok': True, 'accepted': False}
        text = str(pick.get('text') or '').strip()[:TYPED_MAX] or press_text(row, button, how)
        chat, settings, why = chat_for(part['config'], row['id'])
        if settings is None:
            return {'ok': False, 'error': why}
        caps = {c for p in row.get('parts', []) for c in e.capabilities(p, e._registry().get_driver(p.get('driver')))}
        logger.info(f"[DEVICES] {row['id']}: {button} {how} pressed, {len(text)} chars for chat '{chat}'")
        if not _take_slot(row['id']):
            return {'ok': False, 'busy': True, 'chat': chat,
                    'error': f"'{row['id']}' already has {MAX_WAITING} questions waiting."}
        # where her reply goes: a screen that pulls her words (the lane typed words use), else a speaker, else nowhere
        reply = Reply(row['id']) if 'keyboard' in caps else None
        mute = reply is None and 'speaker' not in caps
        line = pressed_line(row, 'screen' if reply else 'none' if mute else 'voice')
        try:
            _spawn(_turn, row, chat, text, reply, line, mute)
        except Exception:
            _free_slot(row['id'])
            raise
        out = {'ok': True, 'accepted': True, 'chat': chat, 'text': text}
        if reply is not None:
            out['msg'] = reply.msg
        return out
    except Exception as e:
        logger.error(f"[DEVICES] pressed({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}


def hear(device_id, audio, suffix='.wav'):
    """A device heard something. Answers as soon as the words are known:
    {'ok', 'heard', 'accepted', 'chat'} or {'ok': False, 'error'}.
    accepted = a turn has started, and its answer will be spoken on the
    device. Never raises."""
    try:
        e = _engine()
        why = e.refusal()
        if why:
            return {'ok': False, 'error': why}
        row = e.rows().get(str(device_id or '').strip().lower())
        if not row or not row.get('enabled', True):
            return {'ok': False, 'error': f"There is no device named '{device_id}', or it is turned off."}
        part = _voice_part(row)
        if not part:
            return {'ok': False, 'error': f"'{row['id']}' has no microphone."}
        if not audio:
            return {'ok': False, 'error': 'No audio arrived.'}
        if len(audio) > MAX_AUDIO:
            return {'ok': False, 'error': 'The audio is too large.'}

        chat, settings, why = chat_for(part['config'], row['id'])
        if settings is None:
            return {'ok': False, 'error': why}
        gate = stt_refusal(settings)
        if gate:
            return {'ok': False, 'error': gate, 'chat': chat}

        # One wake, one answer: the main app or another satellite may have
        # heard the same words (core/devices/wake.py). With nobody ahead,
        # this device holds the room from here; behind someone, its words
        # are compared with theirs and a repeat is dropped unanswered.
        others = wake.shadowed(row['id'])
        mine = not others
        if mine and not wake.holds(row['id']):      # a device that claimed at its wake holds it already
            wake.claim(row['id'])
        try:
            heard, problem = transcribe(audio, suffix)
            if problem:
                return {'ok': False, 'error': problem, 'chat': chat}
            if not heard:
                logger.info(f"[DEVICES] {row['id']}: audio arrived, no speech in it")
                return {'ok': True, 'heard': '', 'accepted': False, 'chat': chat}
            if mine:
                wake.heard(row['id'], heard)
            else:
                twin = next((o for o in others if wake.same(wake.words_of(o), heard)), None)
                if twin:
                    logger.info(f"[DEVICES] {row['id']} heard what {twin['who']} heard "
                                f"({len(heard)} chars), not answered twice")
                    return {'ok': True, 'heard': '', 'accepted': False, 'chat': chat, 'taken_by': twin['who']}
            logger.info(f"[DEVICES] {row['id']} heard {len(heard)} chars for chat '{chat}'")

            if not _take_slot(row['id']):
                return {'ok': False, 'busy': True, 'heard': heard, 'chat': chat,
                        'error': f"'{row['id']}' already has {MAX_WAITING} questions waiting."}
            try:
                _spawn(_turn, row, chat, heard)
            except Exception:
                _free_slot(row['id'])
                raise
            mine = False                     # the turn releases the room when it ends
            return {'ok': True, 'heard': heard, 'accepted': True, 'chat': chat}
        finally:
            if mine:
                wake.release(row['id'])
    except Exception as e:
        logger.error(f"[DEVICES] hear({device_id}) failed: {e}", exc_info=True)
        return {'ok': False, 'error': f"Something went wrong ({type(e).__name__})."}
