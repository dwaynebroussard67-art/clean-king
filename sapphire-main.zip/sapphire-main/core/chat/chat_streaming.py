import json
import logging
import re
import time
from typing import Generator, Union, Dict, Any
import config
from .chat_tool_calling import strip_ui_markers, _extract_tool_images, filter_to_thinking_only, cap_tool_result_text, bad_args_result, cut_call
from core.ui_markers import stage_cards
from core import think as _think
from .llm_providers import LLMResponse, get_generation_params
from .llm_providers.base import LENGTH_FINISH
from .llm_errors import explain_finish, is_context_error
from . import budget
from core import documents
from core.event_bus import publish, Events
from core.hooks import hook_runner, HookEvent
from core.metrics import metrics as token_metrics
from core.tts.stream_pump import StreamingTTSPump

logger = logging.getLogger(__name__)


PRIVATE_GATE_WORDS = ("🔒 Private mode is on, but this chat isn't private, so nothing "
                      "was sent. Pick a private chat or make this one private. "
                      "To talk here, lock the vault.")


def private_gate(session_manager):
    """THE gate (2026-11-07, replaces the talk-stamp): an operator turn in a
    PUBLIC chat while the vault is OPEN is refused — returns the refusal
    words, or None to let the turn run. A private expectation never routes
    public, and nothing decides privacy for the person: they choose in the
    app (shared/private-picker.js), which flips the chat through the
    settings PUT (that encrypts it). Voice can't show a picker, so voice
    hears these words. Skips: no/locked vault (no private mode), managed
    mode, already-private, MODE-TAGGED chats (game/story/room/limbo are
    plugin surfaces, public by nature — Krem 2026-11-07). Reads the
    override-aware settings, so a by-name operator turn is gated on ITS
    chat. Unreadable state REFUSES (fail closed)."""
    try:
        from core import prompt_vault
        vs = prompt_vault.vault_status()
        if not (vs.get('exists') and vs.get('unlocked')):
            return None
        from core.settings_manager import settings as sm_settings
        if sm_settings.is_managed():
            return None
        cur = session_manager.get_chat_settings() or {}
        if cur.get('private_chat') or cur.get('mode'):
            return None
        logger.info("[VAULT] turn refused — public chat while the vault is open")
        return PRIVATE_GATE_WORDS
    except Exception as e:
        logger.warning(f"[VAULT] private gate couldn't check — turn refused: {e}")
        return ("🔒 Couldn't check whether this chat is private, so nothing was "
                "sent. Try again in a moment.")


def _stash_pasted(images):
    """One img: handle per pasted image, or None where the store refused (that
    one stays inline in the row). Bytes are stored as they arrive — the upload
    route already applied IMAGE_UPLOAD_MAX_WIDTH; nothing resizes twice."""
    import base64
    from core import images as ci
    out = []
    for img in images:
        try:
            out.append(ci.stash(base64.b64decode(img.get("data", "")), visible=True))
        except Exception as e:
            logger.warning(f"[STREAM] pasted image kept inline (store refused: {e})")
            out.append(None)
    return out



def usage_metadata(provider_key, model, response, content, thinking, start, end):
    """The metrics block an assistant row carries (the ui.js footer): the
    provider's usage when it sent one, else chars/4 estimates. ONE builder:
    the chat turn, the forced final and the game room's seat all stamp it."""
    usage = getattr(response, 'usage', None) if response else None
    thinking_tokens = len(thinking) // 4 if thinking else 0
    if usage:
        content_tokens = usage.get("completion_tokens", 0)
        prompt_tokens = usage.get("prompt_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)
    else:
        content_tokens = len(content) // 4 if content else 0
        prompt_tokens = 0
        total_tokens = content_tokens + thinking_tokens
    duration = round(end - start, 2)
    meta = {
        "provider": provider_key,
        "model": model,
        "start_time": time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(start)),
        "end_time": time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(end)),
        "duration_seconds": duration,
        "tokens": {
            "content": content_tokens,
            "thinking": thinking_tokens,
            "prompt": prompt_tokens,
            "total": total_tokens,
            "estimated": not usage
        },
        "tokens_per_second": round(content_tokens / duration, 1) if duration > 0 else 0
    }
    for k in ("cache_read_tokens", "cache_write_tokens"):
        if usage and usage.get(k):
            meta["tokens"][k] = usage[k]
    return meta


def _stamp_finish(metadata, finish, content, provider_key, note=True):
    """A row's metadata learns how its generation ended: `finish`, plus the
    cutoff words (llm_errors.explain_finish, ui.js renders them) when that was
    the reply token ceiling. The one stamp every row builder here calls."""
    if metadata is None or not finish:
        return
    metadata["finish"] = finish
    cutoff = (explain_finish(finish, bool((_think.split(content)[0] or '').strip()), provider_key,
                             metadata.get("model")) if note else None)
    if cutoff:
        metadata["cutoff"] = cutoff

class StreamingChat:
    def __init__(self, main_chat):
        self.main_chat = main_chat
        self.tool_engine = main_chat.tool_engine
        self.cancel_flag = False
        self.current_stream = None
        # Voice-mute for the current message (left-button "stop TTS"): drops this
        # stream's TTS without cancelling the LLM. Read by the pump's cancel_check
        # (flush_and_close bails) + set on the pump's _skip_turn (push no-ops). NOT
        # the same as cancel_flag, which stops the LLM — TTS/STT is the left button's
        # domain; the LLM has its own Stop button.
        self.tts_stopped = False
        self.tts_pump = None
        # LLM half of the turn is over (history row + metrics written); only
        # the streaming-TTS drain may still be running. begin_stream(exclusive)
        # stops counting a stream as live once this is set. See _emit_llm_done.
        self.llm_done = False
        # Every history write of this turn is behind it (end of chat_stream's
        # finally). A STOPPED stream holds its chat until then, so a Send right
        # after Stop can't land inside its open tool cycle (ChatManager._live).
        self.writes_done = False
        self._my_tool_ids = set()   # tool_call ids THIS stream wrote: cleanup closes only these
        self._typing_ended = False
        self.ephemeral = False
        self.is_streaming = False
        # Name of the chat currently streaming — lets /api/cancel refuse to
        # cancel a DIFFERENT chat's stream (was global, cross-chat tabs
        # interfered). Full per-request streaming state is H4 architecture
        # work; this is the narrow scoping fix. H5 2026-04-22.
        self.active_chat_name = None
        # A1: the explicit chat this stream targets (None = web/active chat). When
        # set to a non-active chat (a phone call), the turn runs a per-stream brain
        # override so it reads/writes ITS chat, not the UI's active one.
        self.target_chat = None
        # A caller-built brain (core/rooms.py, 2026-10-11): a complete stream-brain
        # carrier the A1 block installs INSTEAD of the target chat's stored
        # settings. Set alongside target_chat; the engine runs it and, on an
        # ephemeral carrier, persists nothing.
        self.brain = None

    def _effective_enabled_tools(self):
        """A1: the tool list for THIS turn — a per-stream override's tools when the
        turn targets a non-active chat, else the global active toolset. An override
        with tools=None means that chat's toolset is 'none' → no tools this turn."""
        try:
            from core.chat.stream_brain import get_override
            o = get_override()
            if o is not None:
                return o.get("tools") or []
        except Exception:
            pass
        return self.main_chat.function_manager.enabled_tools

    def _add_user(self, content, **kw):
        """The turn's user row, written: from here an error row follows it."""
        self._user_row_pending = None
        return self.main_chat.session_manager.add_user_message(content, **kw)

    def _keep_partial(self, e, provider_key, partial, thinking=None):
        """A turn that died after some of the reply streamed keeps it: the
        prose as a real reply (she sees it, Continue can finish it) with the
        failure as its note (metadata.cutoff, the amber line), not an error
        row in its place. The person deletes it if they want (Krem, hunt 20).
        True when it was saved."""
        partial = (partial or '').strip()
        if not partial or self.llm_done:        # llm_done: her row is already written
            return False
        from core.chat.llm_errors import history_row
        try:
            sm = self.main_chat.session_manager
            if sm._in_tool_cycle:
                self._close_dangling_tool_calls()
            words, _meta = history_row(e, provider_key)
            sm.add_assistant_final(content=partial, thinking=thinking or None,
                                   metadata={'cutoff': f"{words} What came before it is kept."})
            return True
        except Exception as se:
            logger.warning(f"[STREAMING] partial reply not kept: {se}")
            return False

    def _save_error_row(self, e, provider_key):
        """A failed turn's row: plain words that show, the raw text under its
        Details fold, marked so it never reaches the LLM (a model repeats the
        errors it reads). Also keeps history from ending on a dangling user
        row. Returns the words.

        A failure before the user row was written (building the prompt, the
        ghost, a paste) wrote it first now: the error row followed her
        previous reply, the person's words were lost, and Regen on it redid
        the turn before (hunt 20)."""
        from core.chat.llm_errors import history_row
        pending = getattr(self, '_user_row_pending', None)
        if pending:
            try:
                self._add_user(pending, source=getattr(self, 'turn_source', None))
            except Exception as ue:
                logger.warning(f"[STREAMING] the failed turn's user row was not saved: {ue}")
        text, meta = history_row(e, provider_key)
        self.main_chat.session_manager.add_assistant_final(text, metadata=meta)
        return text

    def _cleanup_stream(self):
        """Safely close current stream if it exists."""
        if self.current_stream:
            try:
                self.current_stream.close()
                logger.info("[CLEANUP] Stream closed")
            except Exception as e:
                logger.warning(f"[CLEANUP] Stream close warning: {e}")
            finally:
                self.current_stream = None

    def stop_tts(self):
        """Left-button "stop TTS": mute her voice for THIS message without cancelling
        the LLM. Sets tts_stopped (pump's flush_and_close bails within ~100ms via
        cancel_check) + the pump's _skip_turn (push() stops submitting new synth).
        Both are bool writes — safe from the API thread while the stream runs in its
        own thread (no cross-thread list mutation). Idempotent."""
        self.tts_stopped = True
        p = self.tts_pump
        if p is not None:
            try:
                p._skip_turn = True
            except Exception as e:
                logger.warning(f"[STREAMING] stop_tts failed: {e}")

    def _emit_llm_done(self, tts_pump, refused=False):
        """The LLM half of the turn is over — history row written, metrics
        saved. Returns the wire event. The audio tail (flush_and_close) can
        take seconds on a slow CPU and nothing that isn't audio should wait
        on it: the browser flips Stop→Send + paints metrics on this event,
        mirror tabs + avatar get AI_TYPING_END now (once — the finally covers
        cancel/error exits), and begin_stream(exclusive) stops counting this
        stream as live. `tts_streamed` = the pump ran this turn (streamed,
        user-muted, plugin-skipped alike); False only when no pump ever
        started — the ONE case the browser falls back to whole-blob playback.
        Every clean-exit `done` on the wire is preceded by exactly one of
        these. 2026-09-08, record tmp/llm-done-split-plan.md."""
        self.llm_done = True
        if not self._typing_ended:
            self._typing_ended = True
            publish(Events.AI_TYPING_END, self._typing_payload())
        # `ephemeral` rides here, not only on `done`: the browser settles the
        # turn at llm_done, so a flag that only arrived on the later `done`
        # was never read (pre-push hunt 2026-09-08, E1#2).
        # `refused`: the turn never ran (vault, a Continue the provider can't
        # do). The browser neither speaks nor swaps in the previous reply
        # as if it were this turn's (hunt 20: a refused Continue re-read it).
        return {"type": "llm_done",
                "ephemeral": bool(getattr(self, "ephemeral", False)),
                "tts_streamed": bool(getattr(tts_pump, "_stream_started", False)),
                "refused": bool(refused or getattr(self, "_refused", False))}

    def _typing_payload(self):
        """AI_TYPING_* payload. `foreign` = this turn's chat is NOT the one
        the operator's Chat view shows — ONE definition (F1, 2026-09-08),
        the same `chat != active` the driver and wake doors compute. Before
        this any target-chat stream was foreign even when the operator was
        watching that very chat. `chat` = the turn's chat, so a rail bound
        by name can filter on it."""
        tgt = getattr(self, "target_chat", None)
        try:
            active = self.main_chat.session_manager.get_active_chat_name()
        except Exception:
            active = None
        return {"foreign": bool(tgt) and tgt != active, "chat": tgt or active}

    def _private_gate(self):
        """Streaming-lane wrapper — see private_gate (module level)."""
        return private_gate(self.main_chat.session_manager)

    def _close_dangling_tool_calls(self):
        """Inject dummy tool_results for tool_calls that never got one, so
        provider history stays valid (tool_use without tool_result -> 400).
        Idempotent; call while the tool cycle is still open. Shared by the
        cancel partial-save and the finally (S1 #2, hunt 2026-08-30).
        Only THIS stream's own cycle: when the open one belongs to a newer
        turn, stamping "[Cancelled]" on its calls mangled that turn (release
        hunt 2026-11-06). True when the open cycle was ours."""
        try:
            msgs = self.main_chat.session_manager._effective_chat().messages
            for msg in reversed(msgs):
                if msg.get("role") == "assistant" and msg.get("tool_calls"):
                    if not any(tc.get("id") in self._my_tool_ids for tc in msg["tool_calls"]):
                        return False
                    existing = {m.get("tool_call_id") for m in msgs if m.get("role") == "tool"}
                    for tc in msg["tool_calls"]:
                        tc_id = tc.get("id", "")
                        if tc_id and tc_id not in existing:
                            self.main_chat.session_manager.add_tool_result(
                                tc_id, tc.get("function", {}).get("name", "unknown"),
                                "[Cancelled by user]"
                            )
                    return True
        except Exception as e:
            logger.warning(f"[CLEANUP] Failed to inject cancel tool results: {e}")
        return False

    def chat_stream(self, user_input: str, prefill: str = None, skip_user_message: bool = False, images: list = None, files: list = None, continue_from: str = None) -> Generator[Union[str, Dict[str, Any]], None, None]:
        """
        Stream chat responses. Yields typed events:
        - {"type": "stream_started"} immediately when processing begins
        - {"type": "content", "text": "..."} for text content
        - {"type": "thinking", "text": "..."} for thinking content (rendered with tags by UI)
        - {"type": "tool_start", "id": "...", "name": "...", "args": {...}} when tool begins
        - {"type": "tool_end", "id": "...", "result": "...", "error": bool} when tool completes
        - {"type": "iteration_start", "iteration": N} before each LLM call
        - {"type": "reload"} for page reload signal
        - {"type": "final", "text": str, "cancelled": bool, "error": bool}
          terminal event on every clean exit — the definitive turn text for
          blocking consumers (LLMChat.chat). Raise paths emit none; consumers
          catch the raise instead. SSE drops it (clients already streamed
          the content); the phone driver ignores it.
        - str for legacy compatibility (module responses, prefills)

        Args:
            user_input: Text input from user
            prefill: Optional assistant prefill for continue mode
            skip_user_message: Don't add user message to history (continue mode)
            continue_from: In-place Continue — the assistant turn's timestamp. The
                chat's last reply is resumed from its OWN row (no user row, the row
                is edited on success, untouched on Stop). Sets prefill/skip itself.
            images: Optional list of {"type": "image", "data": "...", "media_type": "..."}
            files: Optional list of {"filename": "...", "text": "..."}
        """
        logger.info(f"[START] [STREAMING START] cancel_flag={self.cancel_flag}, prefill={bool(prefill)}, skip_user={skip_user_message}, continue_from={continue_from!r}, images={len(images) if images else 0}, files={len(files) if files else 0}")
        # the person's words until their row is written (_save_error_row)
        self._user_row_pending = None if (skip_user_message or continue_from or not user_input) else user_input

        # Publish typing start event. D4: tag the surface so the operator's browser
        # ignores a phone call / background conversation's typing (target_chat set =
        # foreign stream). Untagged, a live call flickered the operator's avatar +
        # Stop button and re-fetched their active chat.
        self.is_streaming = True
        publish(Events.AI_TYPING_START, self._typing_payload())

        # Immediate feedback that backend received the request
        yield {"type": "stream_started"}

        # Streaming TTS pump — emits per-chunk audio SSE events alongside
        # LLM token content. Inert when TTS_STREAMING_ENABLED is off or
        # provider lacks supports_streaming. Single pump spans the whole
        # turn (across tool iterations); only the final-content iteration
        # actually feeds it text and closes it. Defined here (outside the
        # main try) so the cleanup-finally can always reach it. The
        # cancel_check lambda lets flush_and_close bail mid-drain when
        # the user hits Stop AFTER the LLM is done but synth is still
        # finishing (M7 stop coordination).
        tts_pump = StreamingTTSPump(
            system=self.main_chat.system,
            cancel_check=lambda: self.cancel_flag or self.tts_stopped,
            # Set by the conversation driver for phone calls (sentence-split =
            # first audio at the first sentence, not end-of-generation). None
            # everywhere else — global Settings > TTS behavior unchanged.
            split_override=getattr(self, "tts_split_override", None),
            # Blocking consumer lane (LLMChat.chat, merge 2026-08-17): the
            # door speaks the returned blob itself (process_llm_query →
            # tts.speak), so the pump stays inert — no synth, no tts hooks,
            # no double-speak. Must gate HERE, not via tts_stopped: the
            # generator resets tts_stopped just below.
            disabled=bool(getattr(self, "suppress_tts", False)),
            # A device's turn (cadence.run_turn stream_speech): the pump runs
            # whatever the streaming switch says, gated by THAT chat's settings.
            force=bool(getattr(self, "tts_force", False)),
            chat_settings=getattr(self, "tts_chat_settings", None),
            # Where the chunks play. A web turn plays here (the browser), so
            # Settings > Voice > Play speech here governs it; a satellite's
            # turn (cadence) or a phone's (the conversation driver) stamps
            # False - elsewhere, never muted by that switch.
            plays_here=bool(getattr(self, "tts_plays_here", True)),
            device=str(getattr(self, "tts_device", "") or ""),
        )
        self.tts_pump = tts_pump   # expose for stop_tts() (left-button voice mute)

        # Prompt-privacy enforcement moved to _select_provider (2026-08-09) —
        # one server-side gate covering ALL doors (web, /api/chat, voice,
        # phone target-chats), target-chat aware. The old pre-flight here
        # checked only this door, read the GLOBAL active prompt (wrong chat
        # for phone streams), and silently self-disabled on ImportError.

        _brain_token = None   # A1: declared before the try so the finally is always safe
        _reg_chat, _reg_pinned = None, False   # F1: what begin_streaming was told; the finally mirrors it
        provider_key = None   # named in a failed turn's words (llm_errors)

        try:
            # H4 counter, moved to the TOP of the try (vault hunt R3 2026-08-15):
            # count this stream BEFORE any setup so (a) a vault lock's eviction
            # defers to end_streaming instead of racing the setup below, and
            # (b) the unconditional end_streaming in the finally can never
            # double-decrement a concurrent stream's count when setup throws.
            # (H4 2026-04-22 history: single bool let two concurrent streams
            # corrupt mid-turn history; counter fix.)
            # F1 (2026-09-08): count under THIS stream's chat. A pinned
            # by-name turn (target_chat) never blocks a pointer switch; the
            # chat it writes to still refuses delete/rename/clear/append.
            _reg_chat = getattr(self, "active_chat_name", None) or None
            _reg_pinned = bool(getattr(self, "target_chat", None))
            self.main_chat.session_manager.begin_streaming(_reg_chat, pinned=_reg_pinned)
            # No cancel_flag reset here: StreamingChat is per-request
            # (__init__ starts it False) -- a reset only EATS a /api/cancel
            # that landed between registration and this generator's first
            # next() (S1 #5, hunt 2026-08-30).
            self.tts_stopped = False
            self.current_stream = None
            self.ephemeral = False
            self._refused = False      # set when the turn ends having changed nothing (see _emit_llm_done)
            # begin_stream() stamped the route-accept active chat on us; the
            # gap between that and this generator starting is UNCOUNTED — an
            # eviction may have landed in it.
            _intended_chat = getattr(self, "active_chat_name", None) or None
            try:
                self.active_chat_name = self.main_chat.session_manager.get_active_chat_name()
            except Exception:
                self.active_chat_name = None

            # Vault hunt R3/R4: operator lane — if a lock's eviction moved the
            # world in that uncounted gap, refuse the turn instead of writing
            # the user's private-intent text into the eviction landing chat.
            # Same refusal when the active chat is private in a sealed world
            # (failed-eviction state): its turns can't persist honestly.
            if not getattr(self, "target_chat", None):
                if _intended_chat and self.active_chat_name \
                        and _intended_chat != self.active_chat_name:
                    logger.warning("[VAULT] active chat changed during stream "
                                   "setup — turn refused")
                    _refusal = ("🔒 The vault locked while this message was "
                                "in flight and the active chat changed. "
                                "Please resend.")
                    yield {"type": "content", "text": _refusal}
                    yield self._emit_llm_done(tts_pump, refused=True)
                    yield {"type": "final", "text": _refusal,
                           "cancelled": False, "error": True}
                    return
                try:
                    from core import prompt_vault as _pv
                    _vs_gate = _pv.vault_status()
                    if _vs_gate.get('exists') and not _vs_gate.get('unlocked') \
                            and self.main_chat.session_manager.get_chat_settings().get('private_chat'):
                        logger.warning("[VAULT] turn refused — active chat is "
                                       "private and the vault is sealed")
                        _refusal = ("🔒 The vault is locked and this chat is "
                                    "private — unlock the vault to continue "
                                    "here.")
                        yield {"type": "content", "text": _refusal}
                        yield self._emit_llm_done(tts_pump, refused=True)
                        yield {"type": "final", "text": _refusal,
                               "cancelled": False, "error": True}
                        return
                except Exception:
                    pass

            # A1: if this stream has an EXPLICIT target chat (driver/phone — web
            # passes None), install a per-context brain override so the whole turn
            # — messages, provider, persona, tools, scopes — runs in THAT chat from
            # its STORED settings. Unconditional on the target: comparing against
            # the active chat let a phone call inherit the UI session's in-memory
            # brain whenever the user was WATCHING the call's chat (2026-07-03:
            # Alfred greeting, Sapphire brain). Reset in the outer finally.
            _brain_token = None
            _tgt = getattr(self, "target_chat", None)
            _gate_words = None   # phone/background targets never gate
            if _tgt:
                _installed = False
                try:
                    from core.chat import stream_brain
                    from core import prompts as _prompts
                    # A caller-built brain wins over the chat's stored settings
                    # (core/rooms.py: a seat's settings, prompt, tools and a
                    # projected history on an ephemeral carrier, 2026-10-11).
                    _given = getattr(self, "brain", None)
                    sess = _given or self.main_chat.session_manager.make_stream_session(_tgt)
                    if sess and not _given:
                        _pn = sess["settings"].get("prompt", "default")
                        _pd = _prompts.get_prompt(_pn)
                        if not isinstance(_pd, dict):
                            # Missing name — run on assembled default this turn
                            # (heals when the prompt re-registers), never the
                            # literal "System prompt not loaded."
                            _pd = _prompts.get_prompt("default")
                        sess["system_prompt"] = (_pd.get("content", "") if isinstance(_pd, dict) else "") or ""
                        sess["tools"] = self.main_chat._resolve_toolset_tools(
                            sess["settings"].get("toolset", "all"),
                            sess["settings"].get("extra_toolsets"))
                    if sess:
                        _brain_token = stream_brain.set_override(sess)
                        _installed = True
                        logger.info(f"[A1] stream brain override → chat '{_tgt}' "
                                    f"({'caller-built' if _given else 'stored'}; "
                                    f"provider={sess['settings'].get('llm_primary')}, "
                                    f"tools={len(sess['tools']) if sess['tools'] else 0})")
                except Exception as _e:
                    logger.warning(f"[A1] stream brain override failed for '{_tgt}': {_e}")
                    _brain_token = None
                if not _installed:
                    # F1 (2026-09-08): a by-name turn whose brain can't be
                    # built (chat missing, sealed, read error) REFUSES —
                    # never falls through to the operator's active chat.
                    # That fall-through is the cross-chat class this door
                    # exists to close.
                    logger.warning(f"[A1] turn refused — no brain for '{_tgt}'")
                    _refusal = (f"🔒 Chat '{_tgt}' isn't reachable right now "
                                f"(missing or sealed) — the turn was not run.")
                    yield {"type": "content", "text": _refusal}
                    yield self._emit_llm_done(tts_pump, refused=True)
                    yield {"type": "final", "text": _refusal,
                           "cancelled": False, "error": True}
                    return
                if getattr(self, "operator_lane", False):
                    # A human typed this by name (a room's bound rail while
                    # the pointer is elsewhere): the operator rulings ride —
                    # vault idle touch + the private gate on THIS chat (mode-
                    # tagged sessions pass the gate). Phone and background
                    # lanes never reach here.
                    try:
                        from core import prompt_vault as _pv_touch
                        _pv_touch.touch()
                    except Exception:
                        pass
                    _gate_words = self._private_gate()
            else:
                # THE private gate (2026-11-07, replaced talk-marks-private):
                # an operator turn in a public chat while the vault is open
                # is refused — the person chooses in the app, nothing
                # decides for them. Operator lanes only: web typing, browser
                # voice and wake word ride target_chat=None; phone/background
                # streams carry an explicit target and never gate. Runs
                # BEFORE the user row is written, so refused words never
                # land in the public chat.
                # An operator turn is USER ACTIVITY for the vault idle clock
                # (Krem's ruling 2026-08-15): chatting in a private chat must
                # not read as "idle" to the auto-lock.
                try:
                    from core import prompt_vault as _pv_touch
                    _pv_touch.touch()
                except Exception:
                    pass
                _gate_words = self._private_gate()

            if _gate_words:
                # private_gate first: the web tab opens the picker and
                # restores the draft; voice hears the words.
                yield {"type": "private_gate"}
                yield {"type": "content", "text": _gate_words}
                yield self._emit_llm_done(tts_pump, refused=True)
                yield {"type": "final", "text": _gate_words,
                       "cancelled": False, "error": True}
                return

            # NULL ROOM (2026-09-03): a mode:limbo chat ('backrooms') is the
            # vault-eviction holding room — a pointer parking space, not a
            # conversation. It only ever hosts the active pointer when EVERY
            # chat is private and sealed, so anything said in it is by
            # construction the continuation of a private life in a plaintext
            # row (the private gate passes mode chats). Refuse the turn — same
            # yield-refusal shape as the vault gates above; the outer finally
            # handles end_streaming/AI_TYPING_END. After the A1 install so a
            # stream pinned to the room reads its mode through the override.
            try:
                _mode = (self.main_chat.session_manager.get_chat_settings()
                         or {}).get('mode')
            except Exception:
                _mode = None
            if _mode == 'limbo':
                logger.info("[LIMBO] turn refused — mode:limbo is a null room")
                _refusal = ("🔒 Your chats are private and the vault is "
                            "locked, so this is just a holding room. Unlock "
                            "the vault with the 🔒 button to get them back, "
                            "or create a new chat to talk.")
                yield {"type": "content", "text": _refusal}
                yield self._emit_llm_done(tts_pump, refused=True)
                yield {"type": "final", "text": _refusal,
                       "cancelled": False, "error": True}
                return

            # Spice rail AFTER the A1 override install: before this, a phone
            # turn's spice cadence read the OPERATOR'S chat settings and turn
            # count (the ContextVar wasn't set yet) and could rewrite the
            # global prompt from a foreign stream. Never under a caller-built
            # brain: the rail rewrites the GLOBAL prompt and spice state, which
            # a room's seat must not touch (core/rooms.py, 2026-10-11).
            if getattr(self, "brain", None) is None:
                self.main_chat.refresh_spice_if_needed()

            # In-place Continue (2026-09-10): the reply's row stays in history.
            # Resolve the prose she resumes from; refuse — nothing touched —
            # unless that turn is the chat's last row and ends in plain prose.
            if continue_from:
                prefill = self.main_chat.session_manager.continue_target(continue_from)
                if prefill is None:
                    logger.info(f"[CONTINUE] refused — turn {continue_from} is not the chat's last prose row")
                    yield {"type": "notice", "severity": "warning",
                           "message": "Continue works on the last reply only, and only when it ended in prose."}
                    yield self._emit_llm_done(tts_pump, refused=True)
                    yield {"type": "final", "text": "", "cancelled": False, "error": True}
                    return
                skip_user_message = True

            # Plugin pre_chat hook — can modify input, bypass LLM, or stop propagation
            # (not on a Continue: there is no new input to react to).
            if hook_runner.has_handlers("pre_chat") and not continue_from:
                hook_event = HookEvent(input=user_input, config=config,
                                       metadata={"system": self.main_chat.system})
                hook_runner.fire("pre_chat", hook_event)
                if hook_event.skip_llm:
                    response = hook_event.response or ""
                    if response:
                        if not hook_event.ephemeral:
                            self._add_user(user_input, source=getattr(self, 'turn_source', None))
                            self.main_chat.session_manager.add_assistant_final(response)
                        else:
                            self.ephemeral = True
                        yield {"type": "content", "text": response}
                    yield self._emit_llm_done(tts_pump)   # publishes AI_TYPING_END
                    yield {"type": "final", "text": response,
                           "cancelled": False, "error": False}
                    self.is_streaming = False
                    return
                user_input = hook_event.input  # may have been mutated

            # Pasted images → the chat's image store NOW (visible=1: the model
            # sees them this turn and the vision window can replay them), so
            # the persisted row carries handles + receipts, never base64 (image
            # upgrade 2026-09-10). Perception frames (images_ephemeral) stay
            # model-only: never stashed, never persisted.
            image_handles = []
            if images and not skip_user_message and not getattr(self, 'images_ephemeral', False):
                image_handles = _stash_pasted(images)
            extra = {'image_handles': image_handles} if image_handles else {}   # old call shape otherwise
            if continue_from:
                extra['continue_mode'] = True
            messages = self.main_chat._build_base_messages(user_input, images=images, files=files, **extra)
            if continue_from:
                # History's own tail IS the prefill row. Trailing whitespace off
                # (Claude rejects it), string content (llama.cpp continues a
                # string tail only), no thinking keys on the row being resumed.
                if not messages or messages[-1].get("role") != "assistant":
                    messages.append({"role": "assistant", "content": ""})
                messages[-1]["content"] = prefill.rstrip()
                messages[-1].pop("thinking", None)
                messages[-1].pop("thinking_raw", None)
            # This turn's own row: the person's message - for a Continue, the
            # question whose reply it resumes. It and all after it stay whole
            # in every fit (budget.py).
            _live = messages[-1] if messages else None
            if continue_from:
                _live = next((m for m in reversed(messages[:-1]) if budget._is_person(m)), _live)

            if not skip_user_message:
                # Build content list if files or images present, otherwise just text
                if files or images:
                    user_content = []
                    if user_input:
                        user_content.append({"type": "text", "text": user_input})
                    for f in (files or []):
                        user_content.append({
                            "type": "file",
                            "filename": f.get("filename", ""),
                            "text": f.get("text", "")
                        })
                    # images_ephemeral (cadence organ, F3 2026-09-09): perception
                    # frames reach the MODEL this turn only (they're already in
                    # `messages`); the persisted row keeps the words. F2's blob
                    # lane replaces this with a marker per frame.
                    if not getattr(self, 'images_ephemeral', False):
                        handles = image_handles or [None] * len(images or [])
                        for img, handle in zip(images or [], handles):
                            part = {"type": "image", "media_type": img.get("media_type", "image/jpeg")}
                            if handle:
                                part["handle"] = handle          # the store has the bytes
                            else:
                                part["data"] = img.get("data", "")   # store refused → inline, as before
                            user_content.append(part)
                    if len(user_content) == 1 and user_content[0].get("type") == "text":
                        self._add_user(user_input, source=getattr(self, 'turn_source', None))
                    else:
                        self._add_user(user_content, source=getattr(self, 'turn_source', None))
                else:
                    self._add_user(user_input, source=getattr(self, 'turn_source', None))
            else:
                logger.info("[CONTINUE] Skipping user message addition (continuing from existing)")
            
            # Prefill lanes. External prefill (the raw API lane): appended as the
            # tail message, echoed to the wire, and PREFIXED onto whatever row
            # this turn writes (inline_prefill). In-place Continue: the prefill
            # already is a row and stays on the page — nothing echoed, nothing
            # prefixed onto tool rows; the final prose goes INTO that row.
            has_prefill = bool(prefill)
            inline_prefill = has_prefill and not continue_from
            if inline_prefill:
                # Strip trailing whitespace - Claude API rejects it
                clean_prefill = prefill.rstrip()
                messages.append({"role": "assistant", "content": clean_prefill})
                logger.info(f"[CONTINUE] Continuing with {len(clean_prefill)} char prefill")
                yield {"type": "content", "text": prefill}  # Show original to user
            elif has_prefill:
                logger.info(f"[CONTINUE] in place from {continue_from}: {len(prefill)} char prefill")
            
            # Set scopes for this chat context
            # Reset first to prevent bleed across chats when plugin scopes come and go
            # (a chat saved before a plugin was enabled wouldn't have its scope key in settings,
            # and apply_scopes only sets keys present in the dict → stale value survives).
            from core.chat.function_manager import reset_scopes
            reset_scopes()
            chat_settings = self.main_chat.session_manager.get_chat_settings()
            self.main_chat.function_manager.apply_scopes(chat_settings)
            # Effective chat (matches the get_chat_settings() applied above) — a phone
            # call reads ITS RAG scope, never the operator's active-chat documents.
            chat_name = self.main_chat.session_manager._effective_chat_name()
            self.main_chat.function_manager.set_rag_scope(f"__rag__:{chat_name}")

            # Snapshot scopes as a plain dict — survives across Starlette's
            # per-yield context resets, re-applied in execute_function()
            _scopes = self.main_chat.function_manager.snapshot_scopes()

            # Send only enabled tools - model should only know about active tools
            # Snapshot names too — used to validate tool calls against what LLM actually received
            # Snapshot executors to protect against reload yanking executors mid-chat
            # tools_filter hook (2026-08-24): plugins subtract tools from THIS
            # turn's schema — the game-room scenario fence. Subtract-only by
            # construction (intersection against the resolved list), fail-open
            # on any error. Sits at the ONE seam both lanes cross (active
            # chat + stream-brain override), so _allowed_tool_names below is
            # derived from the FILTERED list — a hallucinated call to a
            # fenced tool is refused like any unknown tool.
            # Closure so the post-tool-cycle refresh applies the SAME filter:
            # pre-fix the refresh rebuilt from the RAW list, so the fence
            # evaporated after the first tool call of every turn — and
            # story_act is NEVER_FENCED, so essentially every story turn
            # disarmed it (negspace N4, 2026-08-31).
            def _filtered_enabled_tools():
                tools = documents.fence_tools(self._effective_enabled_tools(), chat_name,
                                              self.main_chat.function_manager.all_possible_tools,
                                              chat_settings.get('rag_context'))
                try:
                    # NO local import here: binding hook_runner OR HookEvent
                    # locally shadows the module-level names for the WHOLE
                    # function → UnboundLocal at the pre_chat fire above
                    # (both bitten and caught by --long, 2026-08-24).
                    _ev = HookEvent(chat_name=chat_name, tools=list(tools))
                    hook_runner.fire("tools_filter", _ev)
                    _kept = {t["function"]["name"] for t in (_ev.tools or [])
                             if isinstance(t, dict) and "function" in t}
                    tools = [t for t in tools
                             if t.get("function", {}).get("name") in _kept]
                except Exception as e:
                    logger.warning(f"tools_filter hook failed (unfiltered list ships): {e}")
                return tools

            enabled_tools = _filtered_enabled_tools()
            _allowed_tool_names = {t["function"]["name"] for t in enabled_tools if "function" in t}
            _executor_snapshot = self.main_chat.function_manager.snapshot_executors()

            # Drain dangling-toolset state and surface as SSE notice (parallel
            # to non-streaming chat.py logic). Cleared after consume so it
            # only fires once per detection. getattr is defensive — some tests
            # mock function_manager without this attribute.
            bad_ts = getattr(self.main_chat.function_manager, 'last_dangling_toolset', None)
            if bad_ts:
                self.main_chat.function_manager.last_dangling_toolset = None
                yield {
                    "type": "notice",
                    "message": f"Toolset '{bad_ts}' is missing — tools disabled for this chat. Fix in chat settings.",
                    "severity": "warning",
                }

            provider_key, provider, model_override = self.main_chat._select_provider()

            # Continue only where the provider really resumes a reply: elsewhere
            # refuse with words, history untouched (resolve.continues_in_place).
            if continue_from:
                from .llm_providers.resolve import continues_in_place, display_name
                if not continues_in_place(provider_key):
                    logger.info(f"[CONTINUE] refused - {provider_key} doesn't continue a reply in place")
                    yield {"type": "notice", "severity": "warning",
                           "message": f"{display_name(provider_key)} can't continue a reply in place. "
                                      f"Ask it to go on in a new message instead."}
                    yield self._emit_llm_done(tts_pump, refused=True)
                    yield {"type": "final", "text": "", "cancelled": False, "error": True}
                    return

            # The chat's documents, now the real window is known (core/documents.py).
            # For a Continue the person's row is the question, so they sit before it.
            self.main_chat.insert_documents(
                messages, _live,
                user_input if not continue_from else (_live.get('content') if isinstance(_live.get('content'), str) else ''),
                provider, tools=any(t.get('function', {}).get('name') in documents.TOOL_NAMES for t in enabled_tools))

            # A model with no vision reads a description in place of each stored
            # image on the wire — pasted this turn or replayed by the vision
            # window (Settings › Images › Image describer). The caption lives on
            # the image's row: described once. 2026-09-26.
            try:
                from core import image_describe
                image_describe.caption_blind(messages, provider,
                                             store=self.main_chat.session_manager)
            except Exception as e:
                logger.warning(f"[DESCRIBE] caption pass skipped: {e}")

            # Determine effective model (per-chat override or provider default)
            effective_model = model_override if model_override else provider.model

            # Provenance for tool executors (mindpalace metadata). Patches the
            # _scopes snapshot taken above, since the model resolves only here.
            from core.chat.function_manager import set_tool_context
            set_tool_context(_scopes, chat=chat_name,
                             persona=chat_settings.get('prompt'),
                             model=effective_model)

            gen_params = get_generation_params(
                provider_key,
                effective_model,
                {**getattr(config, 'LLM_PROVIDERS', {}), **getattr(config, 'LLM_CUSTOM_PROVIDERS', {})}
            )
            
            # Pass model override to provider if set
            if model_override:
                gen_params['model'] = model_override
            
            # CRITICAL: Disable thinking for continue operations
            # Claude requires thinking blocks with signatures - we can't fake them
            if has_prefill:
                gen_params['disable_thinking'] = True
                logger.info("[CONTINUE] Disabled thinking for continue (can't replay signatures)")

            # The one budgeter (core/chat/budget.py): every call below sends what
            # fit() makes of `messages` - the real window, room for the reply,
            # expired tool results as one line, the oldest turns out of view.
            # `messages` itself keeps everything, so each round fits afresh.
            _fm = self.main_chat.function_manager

            def _expiry(name):
                meta = _fm.tool_meta(name) if hasattr(_fm, 'tool_meta') else None
                return meta.get('expires') if isinstance(meta, dict) else False   # False: not loaded, never expires

            try:
                _label = self.main_chat.session_manager.metrics_chat_label()      # '__private__' for a private chat
            except Exception:
                _label = None

            def _fitted(tools):
                f = budget.fit(messages, tools, provider, provider_key, effective_model,
                               gen_params.get('max_tokens'), chat=chat_name, live=_live, expiry=_expiry,
                               label=_label if isinstance(_label, str) else None)
                gp = gen_params if f.max_tokens == gen_params.get('max_tokens') else {**gen_params, 'max_tokens': f.max_tokens}
                return f, gp
            _fit, _ctx_retried = None, False

            tool_call_count = 0
            loop_counts = {}  # per-turn per-tool call counts (loop guard); turn-local by design
            # Accumulate token usage across all iterations for final summary
            cumulative_tokens = {"prompt": 0, "completion": 0, "thinking": 0, "total": 0,
                                 "cache_read": 0, "cache_write": 0, "iterations": 0}

            # Bind the per-iteration vars the cancel-save path (below) reads, so a barge-in that
            # sets cancel_flag before iteration 0 reaches their in-loop init can't UnboundLocalError.
            current_content = ""
            current_thinking = ""
            metadata = None
            finish = None          # how the last LLM call ended (finish_reason); rides on the row and on `final`
            cut_streak, cut_stop = 0, False   # tool-call rounds cut at max_tokens, in a row

            for iteration in range(config.MAX_TOOL_ITERATIONS):
                if self.cancel_flag:
                    logger.info(f"[STOP] [STREAMING] Cancelled at iteration {iteration + 1}")
                    break
                
                logger.info(f"--- Streaming Iteration {iteration + 1}/{config.MAX_TOOL_ITERATIONS} ---")
                
                # Signal UI that we're starting a new LLM call (useful after tool completion)
                yield {"type": "iteration_start", "iteration": iteration + 1}
                
                # Track content and thinking separately
                current_content = ""
                current_thinking = ""
                thinking_raw = None
                metadata = None
                in_thinking = False
                
                tool_calls = []
                tool_pending_sent = set()  # Track which tool indices got early UI hint
                final_response = None
                first_chunk_time = None  # Track when generation actually starts
                chunk_count = 0  # init BEFORE the try — the except reads it, and creation can raise

                try:
                    _fit, _gp = _fitted(enabled_tools)
                    logger.info(f"[STREAM] Creating provider stream [{provider.provider_name}] (effective_model={effective_model})")
                    self.current_stream = provider.chat_completion_stream(
                        _fit.messages,
                        tools=enabled_tools if enabled_tools else None,
                        generation_params=_gp
                    )
                    for event in self.current_stream:
                        chunk_count += 1
                        
                        # Start timing from first actual chunk (not stream creation)
                        if first_chunk_time is None:
                            first_chunk_time = time.time()
                        
                        if self.cancel_flag:
                            logger.info(f"[STOP] [STREAMING] Cancelled at chunk {chunk_count}")
                            self._cleanup_stream()
                            break
                        
                        event_type = event.get("type")
                        
                        if event_type == "content":
                            text = event.get("text", "")
                            # Close thinking tag if transitioning from think to prose
                            if in_thinking:
                                yield {"type": "content", "text": _think.CLOSE + "\n\n"}
                                in_thinking = False
                            current_content += text
                            yield {"type": "content", "text": text}
                            # Streaming TTS: push the same text to the chunker.
                            # Returned events are tts_stream_start (first push)
                            # and any tts_chunks whose synth completed in time.
                            for tts_ev in tts_pump.push(text):
                                yield tts_ev

                        elif event_type == "thinking":
                            # Thinking from Claude - emit as content with tags for UI
                            text = event.get("text", "")
                            current_thinking += text

                            # Emit thinking wrapped in tags for UI rendering
                            if not in_thinking:
                                yield {"type": "content", "text": _think.OPEN}
                                in_thinking = True
                            yield {"type": "content", "text": text}

                        elif event_type == "tool_call":
                            # Close thinking tag if open before tool calls
                            if in_thinking:
                                yield {"type": "content", "text": _think.CLOSE + "\n\n"}
                                in_thinking = False
                            
                            idx = event.get("index", 0)
                            while len(tool_calls) <= idx:
                                tool_calls.append({
                                    "id": "",
                                    "type": "function",
                                    "function": {"name": "", "arguments": ""}
                                })
                            
                            if event.get("id"):
                                tool_calls[idx]["id"] = event["id"]
                            if event.get("name"):
                                tool_calls[idx]["function"]["name"] = event["name"]
                            if event.get("arguments"):
                                tool_calls[idx]["function"]["arguments"] = event["arguments"]
                            if event.get("extra_content"):   # Gemini thought_signature — rides into history
                                tool_calls[idx]["extra_content"] = event["extra_content"]

                            # Early UI hint: show accordion as soon as we know the tool name
                            # Only for indices within MAX_PARALLEL_TOOLS — excess tools won't execute
                            tc = tool_calls[idx]
                            if idx not in tool_pending_sent and tc["function"]["name"] and idx < config.MAX_PARALLEL_TOOLS:
                                tool_pending_sent.add(idx)
                                yield {"type": "tool_pending", "name": tc["function"]["name"], "index": idx}
                        
                        elif event_type == "done":
                            # Close thinking tag if still open
                            if in_thinking:
                                yield {"type": "content", "text": _think.CLOSE + "\n\n"}
                                in_thinking = False
                            
                            final_response = event.get("response")
                            # Capture thinking data from done event
                            if event.get("thinking"):
                                current_thinking = event["thinking"]
                            if event.get("thinking_raw"):
                                thinking_raw = event["thinking_raw"]
                            if event.get("metadata"):
                                metadata = event["metadata"]
                    
                    logger.info(f"[STREAM] Stream iteration complete ({chunk_count} chunks)")
                    # how the call ended and how much of it was thinking: the line that tells
                    # a length-death (a reasoning model thinking to max_tokens, no words) from
                    # a short answer. The blocking lane has had it since 2026-04-24; here a
                    # silent turn left nothing to read (room field report, 2026-10-12).
                    finish = getattr(final_response, 'finish_reason', None)
                    _said, _thought = _think.split(current_content)
                    logger.info(f"[STREAM] iteration {iteration + 1} ended: finish={finish or '?'}, "
                                f"{len(_said)} chars said, {len(_thought) + len(current_thinking)} chars thinking")
                    self._cleanup_stream()
                    
                    if self.cancel_flag:
                        break
                
                except Exception as e:
                    # Silent regen (surface opt-in via stream attrs, set by the
                    # conversation driver for phone calls): a timeout with ZERO
                    # chunks received retries once with a fresh provider stream —
                    # same messages, no error row in history, no spoken apology.
                    _en = type(e).__name__.lower()
                    _timeoutish = "timeout" in _en or "timed out" in str(e).lower()
                    if (_timeoutish and chunk_count == 0 and not self.cancel_flag
                            and int(getattr(self, "timeout_retry", 0) or 0) > 0):
                        self.timeout_retry = int(self.timeout_retry) - 1
                        logger.warning("[STREAMING] first-token timeout — silent retry with a fresh stream")
                        self._cleanup_stream()
                        _cb = getattr(self, "on_timeout_retry", None)
                        if _cb:
                            try:
                                _cb()
                            except Exception:
                                pass
                        continue    # burns one tool-iteration slot; messages unchanged
                    # The server says it's too long though we counted it in: count
                    # this model heavier and fit again, once (budget.tighten).
                    if (is_context_error(e) and chunk_count == 0 and not _ctx_retried and not self.cancel_flag
                            and _fit is not None and _fit.window):     # no window = nothing to fit tighter into
                        _ctx_retried = True
                        self._cleanup_stream()
                        budget.tighten(provider_key, effective_model, provider)
                        continue
                    logger.error(f"[ERR] [STREAMING] Iteration {iteration + 1} failed: {e}", exc_info=True)
                    self._cleanup_stream()
                    raise
                
                # Build metadata if not provided by provider
                if not metadata:
                    metadata = usage_metadata(provider_key, effective_model, final_response, current_content,
                                              current_thinking, first_chunk_time or time.time(), time.time())
                budget.learn(_fit, (metadata or {}).get("tokens"))
                
                # a tool-call row gets no "Press Continue" note: its bad-args result is the signal
                _stamp_finish(metadata, finish, (prefill or '') + current_content if has_prefill else current_content,
                              provider_key, note=not tool_calls)

                # Accumulate tokens across iterations
                if metadata and metadata.get("tokens"):
                    t = metadata["tokens"]
                    cumulative_tokens["prompt"] += t.get("prompt", 0)
                    cumulative_tokens["completion"] += t.get("content", 0)
                    cumulative_tokens["thinking"] += t.get("thinking", 0)
                    cumulative_tokens["total"] += t.get("total", 0)
                    cumulative_tokens["cache_read"] += t.get("cache_read_tokens", 0)
                    cumulative_tokens["cache_write"] += t.get("cache_write_tokens", 0)
                    cumulative_tokens["iterations"] += 1

                    # Record per-call metrics
                    call_type = "tool_call" if tool_calls else "conversation"
                    estimated = metadata["tokens"].get("estimated", False)
                    try:
                        # effective chat: a phone call's tokens attribute to ITS
                        # chat ('__private__' for private chats — plaintext deposit).
                        _label = self.main_chat.session_manager.metrics_chat_label()   # never chat_name: the turn reads that after
                        token_metrics.record(_label, provider_key, effective_model,
                                             call_type, metadata, estimated=estimated)
                    except Exception:
                        pass  # Metrics are best-effort

                # Generate fallback IDs for tool calls missing them (GLM, some OpenAI-compat APIs)
                for tc in tool_calls:
                    if tc.get("function", {}).get("name") and not tc.get("id"):
                        tc["id"] = f"call_{iteration}_{tool_calls.index(tc)}"
                        logger.info(f"[TOOL] Generated fallback ID for tool call: {tc['function']['name']}")

                # Drop sparse-index padding stubs (id="" name="") BEFORE anything
                # persists: they used to ride into history whole and emit a
                # dangling tool_use next turn on providers with non-contiguous
                # tool-call indexes. openai_compat filters its OWN final list;
                # the accumulator that writes history didn't (negspace N18,
                # 2026-08-31).
                tool_calls = [tc for tc in tool_calls
                              if tc.get("id") and tc.get("function", {}).get("name")]

                if tool_calls and any(tc.get("id") and tc.get("function", {}).get("name") for tc in tool_calls):
                    logger.info(f"[TOOL] Processing {len(tool_calls)} tool call(s)")
                    
                    tool_calls_to_execute = tool_calls[:config.MAX_PARALLEL_TOOLS]
                    
                    # Combine prefill with current content for history
                    full_content = prefill + current_content if inline_prefill else current_content

                    # When the content carries inline <think> reasoning (Qwen/GLM-style),
                    # keep only the thinking and drop the trailing decision-prose ("okay,
                    # I'll generate the image"). Replaying that prose as committed history
                    # nudges the model to repeat the action — the non-streaming path
                    # already filters here; streaming didn't. Gated on inline think tags
                    # so providers whose reasoning lives in thinking_raw (Claude) are
                    # untouched and never get their prose wrapped. Only `content` changes;
                    # thinking_raw/thinking are preserved. 2026-06-14.
                    if _think.has(full_content):
                        stored_content = filter_to_thinking_only(full_content)
                    else:
                        stored_content = full_content

                    # Store message with tool calls - include thinking_raw for Claude
                    # tool cycles, AND `thinking` for DeepSeek-reasoner's required
                    # reasoning_content round-trip on subsequent iterations. Without
                    # the `thinking` field here, the in-memory messages list omits
                    # it, the openai_compat sanitizer's gate at line 427-430 finds
                    # `msg.get('thinking') == None`, and the next API call after
                    # tool execution hits 400 "Missing reasoning_content". 2026-05-14.
                    messages.append({
                        "role": "assistant",
                        "content": stored_content,
                        "tool_calls": tool_calls_to_execute,
                        "thinking_raw": thinking_raw,  # Has signatures for Claude API
                        "thinking": current_thinking if current_thinking else None,
                    })

                    # Save to history with new schema
                    self._my_tool_ids.update(tc.get("id") for tc in tool_calls_to_execute if tc.get("id"))
                    self.main_chat.session_manager.add_assistant_with_tool_calls(
                        content=stored_content,
                        tool_calls=tool_calls_to_execute,
                        thinking=current_thinking if current_thinking else None,
                        thinking_raw=thinking_raw,
                        metadata=metadata
                    )
                    
                    iteration_tool_images = []

                    for tool_call in tool_calls_to_execute:
                        if self.cancel_flag:
                            logger.info(f"[STOP] [STREAMING] Cancelled before tool execution")
                            break

                        if not tool_call.get("id") or not tool_call.get("function", {}).get("name"):
                            continue

                        tool_call_count += 1
                        function_name = tool_call["function"]["name"]
                        tool_call_id = tool_call["id"]
                        # Loop guard: count every attempt this turn (success, throw, or bad JSON).
                        self.main_chat.function_manager.bump_loop_count(loop_counts, function_name)

                        raw_args = tool_call.get("function", {}).get("arguments", "")
                        # Empty string is valid for no-arg tools — Claude/Anthropic
                        # sends arguments='' (not '{}') when a tool has no params.
                        # json.loads('') would fail. Treat empty as {} explicitly.
                        # 2026-05-15.
                        # A response cut at max_tokens right after its last call's name
                        # leaves '' args: a cut-off call, never a no-arg run (cut_call).
                        function_args = None
                        if not cut_call(tool_call, tool_calls, finish):
                            try:
                                function_args = json.loads(raw_args) if raw_args not in ("", None) else {}
                            except json.JSONDecodeError:
                                pass
                        if not isinstance(function_args, dict):
                            # Mirror the non-streaming path (chat_tool_calling.py:372-385):
                            # surface the parse error back to the LLM as a tool result
                            # instead of silently calling the tool with empty args.
                            # Smaller/quantized models occasionally emit malformed JSON;
                            # without feedback the LLM can't self-correct and the tool
                            # runs with default args (potentially destructive for tools
                            # with permissive defaults). 2026-05-14.
                            logger.error(
                                f"[STREAMING] Failed to parse tool arguments for "
                                f"{function_name} (finish={finish}): {raw_args!r}"
                            )
                            error_result = bad_args_result(finish)
                            # Loop-warn to the LLM only; history keeps raw error.
                            llm_result = error_result + self.main_chat.function_manager.loop_warn_suffix(function_name, loop_counts)
                            # CRITICAL: also append to messages — without this, the next
                            # LLM call sees a tool_use with no matching tool_result and
                            # Anthropic returns a 400 that kills the whole turn.
                            # 2026-05-15.
                            wrapped_err = provider.format_tool_result(
                                tool_call_id, function_name, llm_result
                            )
                            messages.append(wrapped_err)
                            self.main_chat.session_manager.add_tool_result(
                                tool_call_id, function_name, error_result
                            )
                            yield {
                                "type": "tool_end",
                                "id": tool_call_id,
                                "name": function_name,
                                "result": error_result,
                                "error": True,   # was `is_error` — a key with zero consumers, so the failed tool rendered green (broadsword M-C6)
                            }
                            continue

                        # Emit typed tool_start event
                        yield {
                            "type": "tool_start",
                            "id": tool_call_id,
                            "name": function_name,
                            "args": function_args
                        }

                        # Publish to event bus for avatar/plugins
                        publish(Events.TOOL_EXECUTING, {"name": function_name})

                        try:
                            function_result = self.main_chat.function_manager.execute_function(function_name, function_args, scopes=_scopes, allowed_tools=_allowed_tool_names, executor_snapshot=_executor_snapshot)
                            result_str, tool_imgs = _extract_tool_images(function_result, self.main_chat.session_manager, provider, function_name)
                            if tool_imgs:
                                iteration_tool_images.extend(tool_imgs)
                                logger.info(f"[TOOL] {function_name} returned {len(tool_imgs)} image(s)")
                            clean_result = strip_ui_markers(result_str)
                            clean_result += self.main_chat.function_manager.loop_warn_suffix(function_name, loop_counts)

                            publish(Events.TOOL_COMPLETE, {"name": function_name, "success": True})

                            # Emit typed tool_end event
                            end = {
                                "type": "tool_end",
                                "id": tool_call_id,
                                "name": function_name,
                                "result": clean_result[:500] if len(clean_result) > 500 else clean_result,
                                "error": False
                            }
                            # open_stage's own card only: a STAGE marker in a web page or an email is not one
                            stage = stage_cards(result_str) if function_name == 'open_stage' else None
                            if stage:
                                end["stage"] = stage
                            yield end

                            wrapped_msg = provider.format_tool_result(
                                tool_call_id,
                                function_name,
                                clean_result
                            )
                            messages.append(wrapped_msg)
                            logger.info(f"[OK] [STREAMING] Tool {function_name} executed successfully")

                            self.main_chat.session_manager.add_tool_result(
                                tool_call_id,
                                function_name,
                                result_str,
                                inputs=function_args
                            )

                        except Exception as tool_error:
                            logger.error(f"Tool execution error: {tool_error}", exc_info=True)
                            # Exception strings can embed whole payloads — this
                            # path bypasses _extract_tool_images, so cap here.
                            error_result = cap_tool_result_text(f"Error: {str(tool_error)}", function_name)
                            # Loop-warn to the LLM only; history + SSE keep the raw error.
                            llm_result = error_result + self.main_chat.function_manager.loop_warn_suffix(function_name, loop_counts)

                            publish(Events.TOOL_COMPLETE, {"name": function_name, "success": False})

                            yield {
                                "type": "tool_end",
                                "id": tool_call_id,
                                "name": function_name,
                                "result": error_result,
                                "error": True
                            }

                            wrapped_msg = provider.format_tool_result(
                                tool_call_id,
                                function_name,
                                llm_result
                            )
                            messages.append(wrapped_msg)

                            self.main_chat.session_manager.add_tool_result(
                                tool_call_id,
                                function_name,
                                error_result,
                                inputs=function_args
                            )

                    # Inject tool-returned images for next LLM turn
                    if iteration_tool_images:
                        from .chat import _inject_tool_images
                        _inject_tool_images(messages, iteration_tool_images, provider)

                    # Refresh tools list — tool_load may have added new tools.
                    # Also refresh the allowed_tool_names guard set and the
                    # executor snapshot so newly-loaded tools become callable
                    # on the next iteration. Without this, the LLM would see
                    # new tools in tools= but execute_function would reject
                    # them as "not in active toolset". Mirrors chat.py:680.
                    enabled_tools = _filtered_enabled_tools()  # re-fence (N4)
                    _allowed_tool_names = {t["function"]["name"] for t in enabled_tools if "function" in t}
                    _executor_snapshot = self.main_chat.function_manager.snapshot_executors()

                    if self.cancel_flag:
                        # This iteration's prose is already persisted on the
                        # tool_calls row -- clear it or the cancel partial-
                        # save stores it a second time as a standalone
                        # assistant message (S1 #2b).
                        current_content = ""
                        break

                    # Two tool-call rounds in a row cut at max_tokens: the model keeps
                    # writing more than one reply holds, and each retry costs a full
                    # max_tokens. Stop the tools; the forced final says why.
                    cut_streak = cut_streak + 1 if finish in LENGTH_FINISH else 0
                    if cut_streak >= 2:
                        logger.warning(f"[STREAMING] {cut_streak} tool-call rounds in a row cut at max_tokens - stopping tools")
                        cut_stop = True
                        break

                    continue

                # Check for text-based tool calls (LM Studio, Qwen, GLM compatibility)
                # Check both content AND thinking - GLM puts tool calls in reasoning_content
                else:
                    function_call_data = None
                    # Check content first
                    if current_content:
                        function_call_data = self.tool_engine.extract_function_call_from_text(current_content)
                    # Also check thinking content (GLM reasoning_content may contain tool calls)
                    if not function_call_data and current_thinking:
                        function_call_data = self.tool_engine.extract_function_call_from_text(current_thinking)
                        if function_call_data:
                            logger.info("[TOOL] Found text-based tool call in thinking/reasoning content")
                    if function_call_data:
                        text_tool_name = function_call_data["function_call"]["name"]
                        logger.info(f"[TOOL] Text-based tool call detected: {text_tool_name}")

                        tool_call_count += 1
                        full_content = prefill + current_content if inline_prefill else current_content

                        # Execute text-based tool call (function_manager returns error if not active).
                        # allowed_tools + executor_snapshot were missing here for a year
                        # (validation-bypass drift vs the native tool_calls path above and
                        # the old blocking lane) — closed in the 2026-08-17 merge.
                        _, text_tool_images = self.tool_engine.execute_text_based_tool_call(
                            function_call_data,
                            full_content,
                            messages,
                            self.main_chat.session_manager,
                            provider,
                            scopes=_scopes,
                            allowed_tools=_allowed_tool_names,
                            executor_snapshot=_executor_snapshot,
                            loop_counts=loop_counts
                        )

                        # Inject tool-returned images for next LLM turn
                        if text_tool_images:
                            from .chat import _inject_tool_images
                            _inject_tool_images(messages, text_tool_images, provider)

                        # Emit tool events for UI
                        tool_name = function_call_data["function_call"]["name"]
                        tool_args = function_call_data["function_call"].get("arguments", {})
                        yield {"type": "tool_start", "id": f"text_{iteration}", "name": tool_name, "args": tool_args}

                        # Get the result that was added to messages
                        last_msg = messages[-1] if messages else {}
                        result = last_msg.get("content", "Tool executed")
                        is_error = "Error:" in result or "not currently available" in result

                        yield {"type": "tool_end", "id": f"text_{iteration}", "name": tool_name, "result": result[:500], "error": is_error}

                        logger.info(f"[TOOL] Text-based tool iteration {iteration + 1} completed")
                        continue

                    logger.info(f"[OK] Final response received after {iteration + 1} iteration(s)")

                    full_content = current_content

                    # In-place continue writes INTO the prefill row when the
                    # continuation was pure prose (no tools ran); once tools
                    # ran, the prefill row stays as-is and this is a new row.
                    in_place = bool(continue_from) and tool_call_count == 0
                    if has_prefill and (inline_prefill or in_place):
                        full_content = prefill + full_content

                    # post_llm hook — plugins can mutate response before save + TTS
                    if hook_runner.has_handlers("post_llm"):
                        llm_event = hook_runner.fire("post_llm", HookEvent(
                            input=user_input, response=full_content,
                            config=config, metadata={"system": self.main_chat.system}
                        ))
                        full_content = llm_event.response or full_content

                    # Attach cumulative token stats from all iterations
                    if cumulative_tokens["iterations"] > 1 and metadata:
                        metadata["cumulative_tokens"] = {
                            "prompt": cumulative_tokens["prompt"],
                            "completion": cumulative_tokens["completion"],
                            "thinking": cumulative_tokens["thinking"],
                            "total": cumulative_tokens["total"],
                            "iterations": cumulative_tokens["iterations"]
                        }
                        if cumulative_tokens["cache_read"]:
                            metadata["cumulative_tokens"]["cache_read"] = cumulative_tokens["cache_read"]
                        if cumulative_tokens["cache_write"]:
                            metadata["cumulative_tokens"]["cache_write"] = cumulative_tokens["cache_write"]

                    # Save final response with thinking separated
                    if in_place and not current_content.strip():
                        # Providers without prefill (Fireworks, OpenAI, GLM/Z.AI)
                        # answer a trailing assistant message with nothing. The
                        # row is untouched — say so instead of a silent no-op.
                        logger.info("[CONTINUE] provider added nothing — row left as it was")
                        self._refused = True
                        yield {"type": "notice", "severity": "warning",
                               "message": "Nothing to add — this provider doesn't continue a reply in place. The message is unchanged."}
                    elif in_place:
                        self.main_chat.session_manager.continue_assistant(
                            continue_from, full_content,
                            thinking=current_thinking if current_thinking else None,
                            metadata=metadata)
                    else:
                        self.main_chat.session_manager.add_assistant_final(
                            content=full_content,
                            thinking=current_thinking if current_thinking else None,
                            metadata=metadata
                        )

                    if hook_runner.has_handlers("post_chat"):
                        hook_runner.fire("post_chat", HookEvent(
                            input=user_input, response=full_content,
                            config=config, metadata={"system": self.main_chat.system}
                        ))

                    # The turn's history is complete — tell the wire BEFORE the
                    # audio drain below, which blocks on synth (seconds on a
                    # slow CPU; the whole reply in paragraph split mode).
                    yield self._emit_llm_done(tts_pump)

                    # Flush remaining audio chunks (blocks on synth) + tts_stream_end
                    for tts_ev in tts_pump.flush_and_close():
                        yield tts_ev

                    yield {"type": "final", "text": full_content,
                           "cancelled": False, "error": False, "finish": finish}
                    return
            
            # If cancelled, KEEP whatever she generated before the interrupt (was:
            # discard the whole turn — barge-in left a hole in the history). Save the
            # partial prose as a TEXT assistant message — never a tool_use, so the
            # tool_use->tool_result contract is untouched. Then fall through. 2026-06-19.
            if self.cancel_flag:
                # Stop with a tool cycle still open (e.g. between parallel
                # tool calls): close dangling ids BEFORE the partial save --
                # add_assistant_final clears _in_tool_cycle, which disarmed
                # the finally's injector and left tool_calls without results
                # -> next-turn repair orphaned the tool rows -> provider 400
                # (S1 #2, hunt 2026-08-30).
                if self.main_chat.session_manager._in_tool_cycle:
                    self._close_dangling_tool_calls()
                partial = (current_content or "").strip()
                save_content = ""
                # In-place continue: partial prose goes INTO the prefill row;
                # nothing generated → the row never left history, nothing lost.
                in_place = bool(continue_from) and tool_call_count == 0
                if partial:
                    save_content = (prefill + current_content
                                    if has_prefill and (inline_prefill or in_place)
                                    else current_content)
                    try:
                        if in_place:
                            self.main_chat.session_manager.continue_assistant(
                                continue_from, save_content,
                                thinking=current_thinking if current_thinking else None,
                                metadata=metadata)
                        else:
                            self.main_chat.session_manager.add_assistant_final(
                                content=save_content,
                                thinking=current_thinking if current_thinking else None,
                                metadata=metadata,
                            )
                    except Exception as e:
                        logger.warning(f"[STREAMING] partial save on cancel failed: {e}")
                yield {"type": "final", "text": save_content,
                       "cancelled": True, "error": False, "finish": finish}
                return

            # Loop exhausted (or stopped on repeated cut-offs) - force final response
            if not cut_stop:
                logger.warning(f"[STREAMING] Exceeded max iterations ({config.MAX_TOOL_ITERATIONS}). Forcing final answer.")

            messages.append({
                "role": "user", "_inject": True,
                "content": ("Your last two tool calls were cut off: each reply hit its max_tokens limit while "
                            "writing the arguments, so those tools did not run. Stop using tools now. Briefly "
                            "tell the user what you were trying to do and that it was too long for one reply."
                            if cut_stop else
                            "You've used tools multiple times. Stop using tools now and provide your final answer based on the information you gathered.")
            })
            
            forced_finish = None     # how the forced final ended; rides the `final` event
            try:
                yield {"type": "content", "text": "\n\n"}
                
                _fit, _gp = _fitted(None)
                final_stream = provider.chat_completion_stream(
                    _fit.messages,
                    tools=None,
                    generation_params=_gp
                )
                
                final_content = ""
                final_thinking = ""
                final_metadata = None
                forced_final_response = None
                in_thinking = False
                final_start_time = time.time()
                
                for event in final_stream:
                    if self.cancel_flag:
                        break
                    
                    event_type = event.get("type")
                    
                    if event_type == "content":
                        chunk = event.get("text", "")
                        if in_thinking:
                            yield {"type": "content", "text": _think.CLOSE + "\n\n"}
                            in_thinking = False
                        final_content += chunk
                        yield {"type": "content", "text": chunk}
                        for tts_ev in tts_pump.push(chunk):
                            yield tts_ev

                    elif event_type == "thinking":
                        text = event.get("text", "")
                        final_thinking += text
                        if not in_thinking:
                            yield {"type": "content", "text": _think.OPEN}
                            in_thinking = True
                        yield {"type": "content", "text": text}
                    
                    elif event_type == "done":
                        if in_thinking:
                            yield {"type": "content", "text": _think.CLOSE + "\n\n"}
                        if event.get("thinking"):
                            final_thinking = event["thinking"]
                        if event.get("metadata"):
                            final_metadata = event["metadata"]
                        forced_final_response = event.get("response")
                        break

                if not final_metadata:
                    final_metadata = usage_metadata(provider_key, effective_model, forced_final_response,
                                                    final_content, final_thinking, final_start_time, time.time())
                
                budget.learn(_fit, (final_metadata or {}).get("tokens"))
                forced_finish = getattr(forced_final_response, 'finish_reason', None)
                _stamp_finish(final_metadata, forced_finish, final_content, provider_key)

                if final_content:
                    full_final = final_content
                else:
                    # Empty content after tool calls — short placeholder + toast.
                    # Old text ("I used N tools and gathered information") was
                    # a confident lie when tools had silently errored. Mirrors
                    # non-streaming chat.py fix. 2026-05-16. A token-ceiling death
                    # says so instead of blaming a tool.
                    full_final = "(no response)"
                    yield {"type": "content", "text": full_final}
                    _cut = (final_metadata or {}).get("cutoff")
                    yield {
                        "type": "notice",
                        "message": _cut["text"] if _cut else (
                            f"The reply came back empty after {tool_call_count} tool call(s). "
                            f"A tool may have failed. Try again, or ask a different way."
                        ),
                        "severity": "warning",
                    }

                # post_llm hook — plugins can mutate forced-final response
                if hook_runner.has_handlers("post_llm"):
                    llm_event = hook_runner.fire("post_llm", HookEvent(
                        input=user_input, response=full_final,
                        config=config, metadata={"system": self.main_chat.system}
                    ))
                    full_final = llm_event.response or full_final

                self.main_chat.session_manager.add_assistant_final(
                    content=full_final,
                    thinking=final_thinking if final_thinking and final_content else None,
                    metadata=final_metadata
                )
                _post_response = full_final

                if hook_runner.has_handlers("post_chat"):
                    hook_runner.fire("post_chat", HookEvent(
                        input=user_input, response=_post_response,
                        config=config, metadata={"system": self.main_chat.system}
                    ))

                yield self._emit_llm_done(tts_pump)

                # Flush streaming TTS for the forced-final path too.
                for tts_ev in tts_pump.flush_and_close():
                    yield tts_ev

                _forced_text, _forced_error = full_final, False

            except Exception as final_error:
                logger.error(f"[STREAMING] Forced final response failed: {final_error}")
                error_msg = self._save_error_row(final_error, provider_key)
                yield {"type": "content", "text": error_msg}
                _forced_text, _forced_error = error_msg, True

            if not self.llm_done:   # the except path above saved its row too
                yield self._emit_llm_done(tts_pump)
            yield {"type": "final", "text": _forced_text,
                   "cancelled": False, "error": _forced_error, "finish": forced_finish}

        except ConnectionError as e:
            logger.warning(f"[STREAMING] {e}")
            # Save error so history doesn't end with a dangling user message
            # (a Continue's history already ends on the reply row — leave it).
            # What streamed before the failure is kept as her reply (hunt 20).
            if not continue_from and not self._keep_partial(
                    e, provider_key, locals().get('current_content'), locals().get('current_thinking')):
                self._save_error_row(e, provider_key)
            # Synthetic tts_stream_end so the frontend's audio queue can
            # finalize even though we're aborting before flush_and_close.
            # Without this, isStreaming stays true / mute pill orphaned
            # until the next stream. 2026-05-18 herring-table #10.
            #
            # WIRE-ONLY — DO NOT FIRE THE HOOK HERE. Looks tempting to also
            # call _fire_hook("tts_stream_end", ...) but the `finally` block
            # below calls `tts_pump.cancel()` which fires the hook exactly
            # once (cancel() respects `_closed` guard at stream_pump.py:290,
            # so flush_and_close's normal-path hook fire is also single-fire).
            # The wire-vs-hook split is intentional: SSE goes to the browser
            # for UI cleanup; the hook goes to plugins for state finalize.
            # Three scouts independently flagged this as a "double fire" —
            # they were wrong; the wiring is asymmetric on purpose. 2026-05-20.
            if tts_pump._stream_started and not tts_pump._closed:
                yield {
                    "type": "tts_stream_end",
                    "stream_id": tts_pump._stream_id,
                    "chunk_count": tts_pump._chunk_count,
                    "interrupted": True,
                }
            self._cleanup_stream()
            raise
        except Exception as e:
            logger.error(f"[ERR] [STREAMING FATAL] Unhandled error: {e}", exc_info=True)
            # Learn-once proxy hint — this is the one catcher every streaming
            # provider failure funnels through (claude stream-enter included),
            # so proxy-blocked errors get named here. (SOCKS-for-all, 2026-08-31)
            try:
                from core.socks_proxy import maybe_llm_proxy_hint
                maybe_llm_proxy_hint('LLM provider', str(e))
            except Exception:
                pass
            # Save error so history doesn't end with a dangling user message
            # (consecutive user messages break Claude's alternating requirement;
            # a Continue's history already ends on the reply row — leave it).
            # What streamed before the failure is kept as her reply (hunt 20).
            if not continue_from and not self._keep_partial(
                    e, provider_key, locals().get('current_content'), locals().get('current_thinking')):
                self._save_error_row(e, provider_key)
            if tts_pump._stream_started and not tts_pump._closed:
                yield {
                    "type": "tts_stream_end",
                    "stream_id": tts_pump._stream_id,
                    "chunk_count": tts_pump._chunk_count,
                    "interrupted": True,
                }
            self._cleanup_stream()
            raise
        
        finally:
            logger.info(f"[CLEANUP] [STREAMING FINALLY] Cleaning up, cancel_flag={self.cancel_flag}")
            # Drop any in-flight TTS synth — no events flow after this point.
            try:
                tts_pump.cancel()
            except Exception as _tts_e:
                logger.warning(f"[CLEANUP] TTS pump cancel failed: {_tts_e!r}")
            # Close any open tool cycle so history isn't left in a broken state
            # (e.g. user hit Stop mid-tool-execution)
            # Past llm_done this stream's own cycle is provably closed
            # (add_assistant_final precedes the emit) — an open cycle then
            # belongs to a NEWER stream admitted past this audio tail; don't
            # inject "[Cancelled…]" rows into its turn (E1#5).
            if self.main_chat.session_manager._in_tool_cycle and not self.llm_done \
                    and self._close_dangling_tool_calls():
                logger.info("[CLEANUP] Closing orphaned tool cycle from cancelled stream")
                self.main_chat.session_manager.add_assistant_final(
                    content="[Cancelled during tool execution]"
                )
            self._cleanup_stream()
            # cancel_flag intentionally NOT reset (S1 #5): flipping it False
            # here made a cancelled stream read as live-not-cancelled in the
            # gap before the route's end_stream.
            self.is_streaming = False
            self.active_chat_name = None
            # A1: drop the per-stream brain override AFTER the cleanup that
            # persists via the effective chat (tool-cycle close above) but
            # BEFORE end_streaming — the 1→0 boundary inside end_streaming
            # runs the vault eviction (set_active_chat → flush/load of the
            # ACTIVE chat) and must not resolve through this stream's
            # override: it would skip the outgoing chat's flush and resync
            # the override chat's store from a trimmed in-memory window
            # (day-ruiner hunt 2026-08-17).
            if _brain_token is not None:
                try:
                    from core.chat import stream_brain
                    stream_brain.reset_override(_brain_token)
                except Exception:
                    pass
            self.main_chat.session_manager.end_streaming(_reg_chat, pinned=_reg_pinned)
            # What her slash_command asked for lands now the store allows it, unless
            # the turn that asked was stopped.
            # Never raises into the turn's end.
            try:
                from core import commands
                _sm = self.main_chat.session_manager
                commands.finish_turn(_sm, _reg_chat or _sm.active_chat_name)
            except Exception as _cmd_e:
                logger.error(f"[CLEANUP] Waiting commands failed: {_cmd_e!r}")
            # Clean exits already published this at llm_done; cancel/error
            # exits land here.
            if not self._typing_ended:
                self._typing_ended = True
                publish(Events.AI_TYPING_END, self._typing_payload())
            self.writes_done = True