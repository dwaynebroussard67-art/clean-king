# chat.py — the turn CHASSIS, not an engine.
#
# LLMChat owns everything a turn needs — provider selection, system prompt
# assembly, RAG, spice, the per-request stream registry, tool-image
# injection — and hands it to THE one turn pipeline in chat_streaming.py.
# chat() below is a blocking CONSUMER of that pipeline, not a second one.
# (Until the 2026-08-17 "Million Dollar Bug Hunt" merge this file carried a
# parallel ~470-line blocking engine that drifted from streaming for a year.)
import base64
import logging
import re
import time
from typing import Dict, Any, Optional, List

import config
from .history import ConversationHistory, ChatSessionManager, count_tokens
from .function_manager import FunctionManager
from core.hooks import hook_runner, HookEvent
from .chat_streaming import StreamingChat
from .chat_tool_calling import ToolCallingEngine

logger = logging.getLogger(__name__)

# Stop -> Send: the new turn waits for the stopped one's writes this long at
# most (tools have no timeout of their own; one that hangs must not lock the chat).
CANCEL_GRACE_S = 15.0


def _detect_image_media_type(b64_data: str) -> str:
    """Best-effort detect media_type from base64 image bytes.

    Tools that return images often forget to set `media_type`. Pre-fix
    we defaulted to 'image/jpeg', which Claude rejects with a 400 when
    the actual bytes are PNG (header/data mismatch). Peeking the magic
    bytes covers PNG/JPEG/GIF/WEBP — the four formats real tool-image
    outputs actually produce. Returns 'image/png' as the safer default
    since most tool-gen images are PNG (image-gen tools, screenshots,
    matplotlib charts). Wildcard scout 2026-05-07 multimodal #2.
    """
    if not b64_data:
        return 'image/png'
    try:
        import base64 as _b64
        # Decode just the prefix — a 24-byte head is plenty for sigs
        head = _b64.b64decode(b64_data[:64], validate=False)[:16]
    except Exception:
        return 'image/png'
    if head.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    if head.startswith(b'\xff\xd8\xff'):
        return 'image/jpeg'
    if head.startswith(b'GIF87a') or head.startswith(b'GIF89a'):
        return 'image/gif'
    if head.startswith(b'RIFF') and head[8:12] == b'WEBP':
        return 'image/webp'
    # Unknown — PNG default is safer than JPEG (broader provider support)
    return 'image/png'


def _inject_tool_images(messages, tool_images, provider=None):
    """Inject tool-returned images as a user message for the next LLM turn.

    Images are added as content blocks so providers can convert them
    to their native format (Claude source blocks, OpenAI image_url, etc).

    The message rides the `user` role because OpenAI-compatible APIs can't
    carry images in a `tool` message. But it must NOT read as the user
    talking - models (notably Qwen) otherwise treat it as a fresh request and
    re-call the image tool. So the text self-labels as tool output and carries
    a gentle brake. 2026-06-14. (The per-image `inject_note` override never
    grew a producer — deleted 2026-09-09.)

    If the provider doesn't support vision, fall back to a text-only
    placeholder. Without this the next LLM call blows up with a 400
    "model does not support image inputs" the moment any image-returning
    tool (body_see, webcam, etc) fires on a text-only model. 2026-05-15.
    """
    supports = bool(provider and getattr(provider, 'supports_images', False))
    if not supports:
        messages.append({
            "role": "user", "_inject": True,
            "content": f"[Tool returned {len(tool_images)} image(s), saved and shown to the user. "
                       f"The current model does not support image inputs, so the image "
                       f"contents are not available for analysis this turn.]"
        })
        logger.info(f"[TOOL] Skipped image injection ({len(tool_images)} image(s)) - provider does not support vision")
        return

    # Self-labeling, non-imperative framing that carries the brake into the
    # highest-authority/most-recent message (where the model actually listens),
    # instead of leaving it stranded in the distrusted tool result.
    # "You are seeing them" (2026-10-27): the old line said only "already shown
    # to the user", and a vision model read that as "not for you" - Sapphire,
    # handed her own browser screenshot, told the user she can't see images.
    note = (
        "[The image(s) below came back from the tool call you just made. You are "
        "seeing them now, and they have also been shown to the user. This is NOT a "
        "message from the user. Use what you see; do not call the tool again unless "
        "the user asks for a change. Continue your reply.]"
    )
    content = [{"type": "text", "text": note}]
    for img in tool_images:
        data = img.get("data", "")
        media_type = img.get("media_type") or _detect_image_media_type(data)
        content.append({
            "type": "image",
            "data": data,
            "media_type": media_type,
        })
    messages.append({"role": "user", "content": content, "_inject": True})   # the app's row, not a turn (core/chat/budget.py)
    logger.info(f"[TOOL] Injected {len(tool_images)} tool image(s) into conversation")



class ChatBusy(Exception):
    """A turn is already live on this chat (begin_stream exclusive=True)."""
    def __init__(self, chat_name):
        self.chat_name = chat_name
        super().__init__(f"chat '{chat_name}' already has a live turn")


def friendly_llm_error(e, provider_key=None):
    """Plain words for a provider failure of a known shape, else None (callers
    that keep the raw text for an unknown one). The words: core/chat/llm_errors.py."""
    from core.chat.llm_errors import explain
    w = explain(e, provider_key)
    return w['text'] if w['known'] else None


def fallback_error_text(e, provider_key=None):
    """The doors' never-raise contract: ANY exception -> words to show or speak."""
    from core.chat.llm_errors import explain
    return explain(e, provider_key)['text']


# Extension → language map for fenced code blocks
TEXT_EXTENSIONS = {
    '.py': 'python', '.txt': 'text', '.md': 'markdown',
    '.js': 'javascript', '.ts': 'typescript', '.json': 'json',
    '.yaml': 'yaml', '.yml': 'yaml', '.toml': 'toml',
    '.ini': 'ini', '.cfg': 'ini', '.conf': 'ini',
    '.sh': 'bash', '.bash': 'bash',
    '.html': 'html', '.css': 'css', '.xml': 'xml',
    '.csv': 'csv', '.log': 'text', '.env': 'bash',
    '.rs': 'rust', '.go': 'go', '.java': 'java',
    '.c': 'c', '.cpp': 'cpp', '.h': 'c',
}

def _ext_to_lang(filename: str) -> str:
    """Map filename extension to language identifier for fenced code blocks."""
    import os
    ext = os.path.splitext(filename)[1].lower()
    return TEXT_EXTENSIONS.get(ext, 'text')


class LLMChat:
    def __init__(self, history=None, system=None):
        logger.info("LLMChat.__init__ starting...")
        self.system = system
        
        # Provider cache - populated lazily
        self._provider_cache = {}
        
        logger.info(f"Using LLM_PROVIDERS config with {len(config.LLM_PROVIDERS)} providers")

        if isinstance(history, ChatSessionManager):
            self.session_manager = history
        elif isinstance(history, ConversationHistory):
            self.session_manager = ChatSessionManager(max_history=config.LLM_MAX_HISTORY)
            if history.messages:
                self.session_manager.current_chat.messages = history.messages.copy()
                self.session_manager._save_current_chat()
        else:
            self.session_manager = ChatSessionManager(max_history=config.LLM_MAX_HISTORY)
        
        self.history = self.session_manager
        
        self.current_system_prompt = None
        self.function_manager = FunctionManager()
        # Notices to surface to the user as toasts (e.g. dangling toolset
        # detected, empty-content fallback). Populated by chat() and the
        # streaming generator; consumed + cleared by the API route layer.
        self.pending_notices: list = []
        
        self.tool_engine = ToolCallingEngine(self.function_manager)

        # Per-request StreamingChat isolation — H4 2026-04-22.
        # Was: `self.streaming_chat = StreamingChat(self)` (one shared
        # instance; two tabs corrupt each other's state).
        # Now: each chat_stream call gets its own StreamingChat via
        # begin_stream(); tracked in dicts below so /api/cancel can target
        # per-chat, and status can report any-streaming. Enables the
        # many-personas/heartbeats isolation Krem wants.
        import threading as _threading
        self._streams_by_id = {}       # {stream_id: StreamingChat}
        self._streams_by_chat = {}     # {chat_name: set(stream_id)}
        self._streams_lock = _threading.Lock()

        logger.info("LLMChat.__init__ completed")

    # ── Per-request streaming state API ──

    def queued_target(self, chat_name):
        """begin_stream's chat argument for a turn that waited in the inbox for
        `chat_name`: None (pointer-bound, today's path) while that chat is still
        the active one, the name itself (pinned, A1) once the pointer has moved.
        None for no chat. The web door gets the same rule from operator=True."""
        if not chat_name:
            return None
        try:
            active = self.session_manager.get_active_chat_name() or ''
        except Exception:
            active = ''
        return None if chat_name == active else chat_name

    def begin_stream(self, chat_name=None, exclusive=False, operator=False):
        """Create a fresh StreamingChat, register it. Caller owns the ref.

        Returns (stream, stream_id, chat_name_used). Pair with end_stream().

        operator=True (F1, 2026-09-08): a HUMAN turn addressed by name — a
        room's rail bound to its session. If that chat IS the active one the
        turn stays pointer-bound (target_chat None: today's path, in-memory
        brain, blocks pointer switches like any typed turn). Only when the
        pointer has moved elsewhere does it pin an A1 override to the named
        chat — the phone-call lane, browser as the phone. Driver lanes
        (operator=False) keep the unconditional override they rely on.

        exclusive=True: one operator turn per chat at a time. Refuses
        (raises ChatBusy) while the chat has a live stream that has NOT been
        cancelled — a second turn on a busy chat interleaves its rows into
        the first turn's history (user message inside an open tool cycle,
        a final landing between tool_use and tool_result → provider 400s
        on the next turn). A cancelled stream counts until its writes are
        done, CANCEL_GRACE_S at most (see _live). Check + register
        are one critical section so two simultaneous sends can't both pass.
        2026-08-29.
        """
        if getattr(self, 'closing', False):
            # shutting down: nothing new starts while the live turns drain (2026-10-16)
            raise ChatBusy(chat_name or '')
        import secrets as _secrets
        stream = StreamingChat(self)
        stream.operator_lane = bool(operator)
        sid = _secrets.token_hex(8)
        try:
            _active = self.session_manager.get_active_chat_name() or ''
        except Exception:
            _active = ''
        _requested = chat_name
        if chat_name is None:
            chat_name = _active
        if _requested is None or (operator and chat_name == _active):
            stream.target_chat = None        # bound to the active pointer
        else:
            stream.target_chat = chat_name   # A1: explicit target (pinned)
        tails = []
        with self._streams_lock:
            if exclusive:
                # A stream past llm_done is an audio tail: its history row is
                # written, only the streaming-TTS drain is still running. It
                # doesn't occupy the chat (2026-09-08, llm-done split) — the
                # new turn preempts it below.
                mine = [self._streams_by_id[i]
                        for i in self._streams_by_chat.get(chat_name, set())
                        if i in self._streams_by_id]
                live = [s for s in mine if self._live(s)]
                if live:
                    logger.info(f"begin_stream: refused — chat '{chat_name}' "
                                f"has {len(live)} live stream(s)")
                    raise ChatBusy(chat_name)
                # Web tails only: a phone/driver stream (explicit target_chat)
                # draining on the chat the operator happens to be viewing is
                # the CALLER's voice — never muted by a web send (E1#4). A
                # typed turn's own tail (operator_lane, pinned once the view
                # moved) is the operator's voice: the next turn cuts it.
                tails = [s for s in mine if s.llm_done and not s.cancel_flag
                         and (not s.target_chat or getattr(s, 'operator_lane', False))]
            self._streams_by_id[sid] = stream
            self._streams_by_chat.setdefault(chat_name, set()).add(sid)
        stream.active_chat_name = chat_name
        # The browser already drops the old tail's chunks (stream_id mismatch
        # on the new tts_stream_start); mute the pump too so a slow CPU
        # doesn't keep synthesizing audio nobody will play. Outside the lock:
        # stop_tts is two bool writes.
        for t in tails:
            t.stop_tts()
        if tails:
            logger.info(f"begin_stream: muted {len(tails)} audio tail(s) on '{chat_name}'")
        return stream, sid, chat_name

    def end_stream(self, stream_id, chat_name):
        """Unregister a stream. Idempotent. When the chat's last stream goes,
        the inbox is told the chat may be free (core/chat/inbox.py)."""
        freed = False
        with self._streams_lock:
            self._streams_by_id.pop(stream_id, None)
            ids = self._streams_by_chat.get(chat_name)
            if ids is not None:
                ids.discard(stream_id)
                if not ids:
                    self._streams_by_chat.pop(chat_name, None)
                    freed = True
        if freed and chat_name:
            try:
                from core.chat import inbox
                inbox.kick(chat_name)
            except Exception as e:
                logger.debug(f"inbox kick for '{chat_name}' failed: {e}")

    def _target_stream_ids(self, chat_name, exclude_chats):
        """Shared targeting for cancel/stop: one chat's streams, or all streams
        minus exclude_chats (e.g. live phone-call chats — surface isolation)."""
        if chat_name:
            return list(self._streams_by_chat.get(chat_name, set()))
        ids = list(self._streams_by_id.keys())
        if exclude_chats:
            skip = set()
            for c in exclude_chats:
                skip |= self._streams_by_chat.get(c, set())
            ids = [i for i in ids if i not in skip]
        return ids

    def cancel_streams(self, chat_name=None, exclude_chats=None):
        """Set cancel_flag on active streams. If chat_name given, only that
        chat's streams (including every tab concurrently on it). Otherwise
        all active streams across all chats, minus exclude_chats (live
        phone-call chats — their streams belong to the phone surface).
        Returns count of streams flagged.
        """
        with self._streams_lock:
            ids = self._target_stream_ids(chat_name, exclude_chats)
            targets = [self._streams_by_id[i] for i in ids if i in self._streams_by_id]
        for s in targets:
            s.cancel_flag = True
        return len(targets)

    def stop_tts_streams(self, chat_name=None, exclude_chats=None, stream_id=None):
        """Mute the VOICE on active streams (left-button "stop TTS") WITHOUT
        cancelling generation — the LLM keeps writing, only this message's audio
        stops. Returns count of streams muted.

        stream_id: the streaming-TTS pump the browser is hearing (every
        tts_stream_start carries one) — mute exactly that pump, wherever it
        is registered. Without it: chat-scoped like cancel_streams, but only
        pumps that have STARTED. The ⏹ means "stop the voice I'm hearing";
        it used to also mute the NEXT turn while it was still thinking (its
        pump existed, unstarted) — that turn then streamed in silent and fell
        back to a whole-blob at the end. 2026-09-08.
        """
        with self._streams_lock:
            if stream_id:
                targets = []
                for chat, ids in self._streams_by_chat.items():
                    if exclude_chats and chat in exclude_chats:
                        continue
                    for i in ids:
                        s = self._streams_by_id.get(i)
                        pump = getattr(s, "tts_pump", None)
                        if s is not None and getattr(pump, "_stream_id", None) == stream_id:
                            targets.append(s)
            else:
                ids = self._target_stream_ids(chat_name, exclude_chats)
                targets = [self._streams_by_id[i] for i in ids if i in self._streams_by_id]
                targets = [s for s in targets
                           if getattr(getattr(s, "tts_pump", None), "_stream_started", False)]
        for s in targets:
            try:
                s.stop_tts()
            except Exception:
                pass
        return len(targets)

    def any_streaming(self):
        """True if at least one stream is active."""
        with self._streams_lock:
            return bool(self._streams_by_id)

    def streams_for_chat(self, chat_name):
        """List of active StreamingChat instances for a chat (may be empty)."""
        with self._streams_lock:
            ids = list(self._streams_by_chat.get(chat_name, set()))
            return [self._streams_by_id[i] for i in ids if i in self._streams_by_id]

    @staticmethod
    def _live(s):
        """begin_stream(exclusive)'s one rule: a stream occupies its chat until
        its LLM half is over. Past llm_done it is an audio tail - the row is
        written, the next turn preempts it. A STOPPED stream still occupies it
        until its writes are done (a tool mid-run finishes, then the finally
        closes its cycle): a Send right after Stop used to land between its
        tool call and its result (release hunt 2026-11-06). The inbox re-asks
        every sweep, so the Send just waits its turn. A tool that won't return
        holds the chat at most CANCEL_GRACE_S."""
        if s.llm_done:
            return False
        if not s.cancel_flag:
            return True
        if getattr(s, 'writes_done', True):
            return False
        seen = s.__dict__.setdefault('_cancel_seen', time.monotonic())
        return time.monotonic() - seen < CANCEL_GRACE_S

    def chat_free(self, chat_name):
        """Would begin_stream(exclusive) take `chat_name` right now? The inbox's
        idle hint (core/chat/inbox.py) asks THIS, not the session counters,
        which stay up through the audio tail - the line used to wait for her
        voice to finish, not her words (Krem, 2026-10-08)."""
        return not any(self._live(s) for s in self.streams_for_chat(chat_name))

    def live_turn(self, chat_name):
        """The server-owned Turn (core/chat/turn.py) still running on a chat,
        or None. A viewer that lost its feed reattaches through this."""
        for s in self.streams_for_chat(chat_name):
            t = getattr(s, 'turn', None)
            if t is not None and not t.done.is_set():
                return t
        return None

    def set_system_prompt(self, prompt_content: str) -> bool:
        self.current_system_prompt = prompt_content
        return True

    def get_system_prompt_template(self) -> Optional[str]:
        return self.current_system_prompt

    def refresh_spice_if_needed(self):
        turn_count = self.session_manager.get_turn_count()
        from core import prompts

        # Transient prompt pieces ride the same per-turn rail as spice: drop
        # expired ones and re-snapshot so a tried-on mood falls off by itself.
        try:
            if prompts.expire_transients() and prompts.is_assembled_mode():
                prompt_data = prompts.get_current_prompt()
                content = prompt_data['content'] if isinstance(prompt_data, dict) else str(prompt_data)
                self.set_system_prompt(content)
                logger.info("[PIECES] Transient piece(s) expired — reassembled prompt")
        except Exception as e:
            logger.error(f"[PIECES] Transient expiry check failed: {e}")

        # Check per-chat spice setting
        chat_settings = self.session_manager.get_chat_settings()
        if not chat_settings.get('spice_enabled', True):
            if prompts.get_current_spice():
                # Clear stale spice AND reassemble prompt so AI stops seeing it
                prompts.clear_spice()
                if prompts.is_assembled_mode():
                    prompt_data = prompts.get_current_prompt()
                    content = prompt_data['content'] if isinstance(prompt_data, dict) else str(prompt_data)
                    self.set_system_prompt(content)
                    logger.info("[SPICE] Spice disabled — cleared and reassembled prompt")
            return False

        if not prompts.is_assembled_mode():
            return False

        spice_turns = chat_settings.get('spice_turns', 3)
        current_spice = prompts.get_current_spice()

        # Pick spice if: none set (just enabled) OR rotation interval hit
        if not current_spice or turn_count % spice_turns == 0:
            logger.info(f"[SPICE] SPICE REFRESH at turn {turn_count} (had_spice={bool(current_spice)})")
            try:
                spice_result = prompts.set_random_spice()
                prompt_data = prompts.get_current_prompt()
                content = prompt_data['content'] if isinstance(prompt_data, dict) else str(prompt_data)
                self.set_system_prompt(content)
                logger.info(f"[SPICE] Spice refresh completed: {spice_result}")
                return True
            except Exception as e:
                logger.error(f"[SPICE] Error refreshing spice: {e}")
                return False
        return False


    def _get_system_prompt(self):
        username = getattr(config, 'DEFAULT_USERNAME', 'Human Scum')
        ai_name = 'Sapphire'
        # Sanitize curly brackets to prevent template injection
        username = username.replace('{', '').replace('}', '')
        # Per-stream brain override: a stream on a non-active chat uses THAT chat's
        # persona prompt, not the globally-primed active-chat one. Unset → active.
        prompt_template = self.current_system_prompt or "System prompt not loaded."
        try:
            from core.chat.stream_brain import get_override
            _o = get_override()
            if _o and _o.get("system_prompt") is not None:
                prompt_template = _o["system_prompt"] or "System prompt not loaded."
        except Exception:
            pass
        prompt = prompt_template

        # Build context parts from chat settings
        context_parts = []
        chat_settings = self.session_manager.get_chat_settings()

        # Vault warmth: a turn actually WEARING a vault prompt is vault
        # activity — idle-lock is for walking away, not for chatting.
        # Listing/browsing reads of the merged views deliberately never
        # touch (an open Prompts page must not keep the vault warm).
        try:
            from core import prompt_vault, prompt_state
            if prompt_vault.vault_has_prompt(chat_settings.get('prompt')) \
                    or prompt_vault.vault_has_prompt(
                        prompt_state.get_active_preset_name()):
                prompt_vault.touch()
        except Exception:
            pass

        # Datetime moved to the ghost-message rail (core/ghost_messages.py)
        # 2026-05-08 — same per-turn freshness, but injected as a separate
        # operator-metadata message right before the new user input. Keeps
        # the system prompt cacheable across turns.

        # Inject custom context if present (LONG-LIVED character info — stays
        # in system prompt where caching it is fine and the AI treats it as
        # part of "who I am"). Per-turn ephemera goes through ghost instead.
        custom_ctx = chat_settings.get('custom_context', '').strip()
        if custom_ctx:
            context_parts.append(custom_ctx)

        # Spice in system-prompt mode (SPICE_DELIVERY='system'): woven in
        # unattributed so the AI wears it as its own inclination. Ghost mode
        # (default) delivers it as labeled app context instead — cache-friendly
        # but third-person. Rebuilt every call, so rotation lands immediately;
        # the prompt mutating on rotation turns is this mode's documented cost.
        if (getattr(config, 'SPICE_DELIVERY', 'ghost') == 'system'
                and chat_settings.get('spice_enabled', True)):
            from core import prompts
            sp = (prompts.get_current_spice() or '').strip()
            if sp:
                context_parts.append(sp)

        # Plugin prompt_inject hook — append to context_parts
        if hook_runner.has_handlers("prompt_inject"):
            # surface stamp: presence plugins (avatar…) only inject where
            # they're actually shown — chat setting `surface`, default chat
            # F1 (2026-09-08): derived from the mode tag when no explicit
            # surface is stamped (core.hooks.surface_for — one derivation).
            from core.hooks import surface_for as _surface_for
            inject_event = HookEvent(context_parts=context_parts, config=config,
                                     surface=_surface_for(chat_settings))
            hook_runner.fire("prompt_inject", inject_event)

        # Combine all static context into main prompt
        if context_parts:
            prompt = f"{prompt}\n\n{chr(10).join(context_parts)}"

        # Template replacement runs AFTER the appends so {user_name} in
        # custom_context, spice, or plugin prompt_inject text renders too —
        # replacing first left those reaching the model as literal braces.
        prompt = prompt.replace("{user_name}", username).replace("{ai_name}", ai_name)

        return prompt, username, None

    def _resolve_toolset_tools(self, toolset_name, extra_toolsets=None):
        """Toolset name -> tool-schema list, READ-ONLY (mirrors
        ExecutionContext._resolve_tools; no function_manager mutation).
        extra_toolsets unions module/toolset function sets on top — same
        semantics as update_enabled_functions (chat setting `extra_toolsets`;
        'none' + extras is the story engine's default)."""
        # ONE rule, in the manager (broadsword H12): this mirror skipped the
        # hidden-tool filter, so every stream-brain lane with toolset "all"
        # offered the librarian ritual verbs + elevate_toolset to the model.
        try:
            return self.function_manager.resolve_tools(toolset_name, extra_toolsets)
        except Exception as e:
            logger.warning(f"_resolve_toolset_tools('{toolset_name}') failed: {e}")
            return None

    def _build_base_messages(self, user_input: str, images: list = None, files: list = None,
                             image_handles: list = None, continue_mode: bool = False):
        system_prompt, user_name, dynamic_context = self._get_system_prompt()

        if continue_mode:
            # In-place Continue (2026-09-10): history's own tail IS the reply
            # being resumed. No new user turn, no ghost, no RAG — any of those
            # after the assistant row opens a fresh turn and the model answers
            # it instead of continuing (the old flow re-sent the user text).
            messages = [
                {"role": "system", "content": system_prompt},
                *self.session_manager.get_messages_for_llm(context_limit=0),     # fit at send time (budget.py)
            ]
            if dynamic_context:
                messages.insert(1, {"role": "system", "content": dynamic_context, "_dynamic": True})
            return messages

        # A UI marker in the turn's own text (a plugin's turn that hands the
        # user a player - FILES, GALLERY, ASK, <<IMG>>: core/ui_markers.py) is
        # the browser's, not hers. History keeps it; this turn's wire copy
        # drops it, as replay does - the ONE list, here too (seam scout, 2026-10-07).
        if user_input:
            from core.ui_markers import has_marker, UI_MARKER_RE
            if has_marker(user_input):
                user_input = UI_MARKER_RE.sub('', user_input).strip()

        # Receipts for pasted images (the store's img: handles) ride the wire
        # text too, so she can hand THIS turn's image to any image tool.
        receipts = [f"(image {h})" for h in (image_handles or []) if h]
        if receipts:
            user_input = "\n".join(([user_input] if user_input else []) + receipts)

        # Flatten files into user_input as fenced code blocks
        if files:
            parts = [user_input]
            for f in files:
                lang = _ext_to_lang(f.get('filename', ''))
                parts.append(f"```{lang}\n# {f['filename']}\n{f['text']}\n```")
            user_input = "\n\n".join(parts)

        # Whole history: chat_streaming fits what is really sent, at send time,
        # against the real window and room for the reply (core/chat/budget.py)
        history_messages = self.session_manager.get_messages_for_llm(context_limit=0)

        # Build user message content - list if images, string otherwise
        if images:
            user_content = []
            if user_input:
                user_content.append({"type": "text", "text": user_input})
            handles = list(image_handles or [])
            for idx, img in enumerate(images):
                block = {
                    "type": "image",
                    "data": img.get("data", ""),
                    "media_type": img.get("media_type", "image/jpeg")
                }
                # A stored image names its row, so a model with no vision can be
                # told what it shows (core.image_describe.caption_blind). Perception
                # frames are never stored: no id, they stay blind.
                handle = str(handles[idx] or '') if idx < len(handles) else ''
                if handle.startswith('img:'):
                    block["id"] = handle[4:]
                user_content.append(block)
        else:
            user_content = user_input

        # Ghost message — per-turn ephemera (spice, datetime, plugin context)
        # injected as a labeled operator-metadata user-role message between
        # history and the new user input. Never persisted to chat history.
        # Keeps the system prompt + history cacheable across turns. See
        # core/ghost_messages.py for design + envelope format. 2026-05-08.
        # `system` attr may be unset in test fixtures; getattr default keeps
        # build_ghost_message happy (its hook firing tolerates a None system).
        from core.ghost_messages import build_ghost_message
        chat_settings_for_ghost = self.session_manager.get_chat_settings()
        try:
            _ghost_chat = self.session_manager._effective_chat_name()
        except Exception:
            _ghost_chat = None
        ghost_text = build_ghost_message(
            getattr(self, 'system', None),
            chat_settings_for_ghost,
            user_input or "",
            chat_name=_ghost_chat if isinstance(_ghost_chat, str) else None,
        )

        messages = [
            {"role": "system", "content": system_prompt},
            *history_messages,
        ]
        if ghost_text:
            messages.append({"role": "user", "content": ghost_text, "_inject": True})
        messages.append({"role": "user", "content": user_content})

        # Dynamic story context — injected as separate system content for cache efficiency
        # This changes every turn (state vars, clues, exits) while the main system prompt stays cached
        if dynamic_context:
            messages.insert(1, {"role": "system", "content": dynamic_context, "_dynamic": True})

        return messages

    def insert_documents(self, messages, live, words, provider=None, tools=True):
        """This chat's documents, right before `live` (the person's row). Runs once the
        provider is chosen: the budget needs the model's real window, or a small local
        model is sent more than it holds and every turn fails the same way. Before the
        person's row, not the tail, so a Continue has its documents too."""
        at = next((i for i, m in enumerate(messages) if m is live), None)
        if at is None:
            return
        doc_text, doc_pictures = self._get_rag_context(words, messages[:at], provider, tools)
        rows = []
        if doc_text:
            rows.append({"role": "user", "content": doc_text, "_inject": True})
        if doc_pictures:
            blocks = [{"type": "image", "data": base64.b64encode(raw).decode('ascii'), "media_type": mt}
                      for raw, mt in doc_pictures]
            rows.append({"role": "user", "_inject": True, "content":
                         [{"type": "text", "text": "[Pages of the scanned documents above]"}] + blocks})
        messages[at:at] = rows

    def _get_rag_context(self, words, history_messages=(), provider=None, tools=True):
        """(text, pictures) from this chat's documents. `words` are what the person
        typed, with no attached text or image receipts in them: those swamped the
        search. The turn before rides along, so "and the second one?" can find it."""
        chat_settings = self.session_manager.get_chat_settings()
        level = chat_settings.get('rag_context', 'normal')
        if level == 'off':
            return None, []

        # Effective chat, not active (matches the get_chat_settings() above): a phone
        # call / background conversation reads ITS chat's RAG docs, never the operator's
        # active-chat documents. Without this a stranger's call could pull owner files.
        chat_name = self.session_manager._effective_chat_name()
        previous = next((m.get('content') for m in reversed(history_messages)
                         if m.get('role') == 'user' and not m.get('_inject')
                         and isinstance(m.get('content'), str)), '')
        query = f"{previous[-500:]}\n{words[-2000:]}" if words else ''
        try:
            from core import documents
            from core.chat import budget
            from core.chat.llm_providers.resolve import provider_sees
            window = min([n for n in (budget._limit(), budget.server_window(provider)) if n] or [0])
            sees = provider is None or provider_sees(provider)
            return documents.context(chat_name, query, level, tools=tools, window=window, sees=sees)
        except Exception as e:
            logger.error(f"[RAG] Failed to get context: {e}", exc_info=True)
            return f"[Reference Documents]\nThis chat's documents failed to load: {e}", []

    def chat(self, user_input: str, on_event=None):
        """Blocking consumer of THE turn engine (chat_streaming.chat_stream).

        Runs the generator to completion, keeps the final text, discards the
        play-by-play — "blocking" is a consumer property, not a second
        pipeline. Callers: wake voice, POST /api/chat, body (all via
        process_llm_query). TTS stays with the caller (it speaks the
        returned blob); suppress_tts keeps the engine's streaming pump
        inert so nothing double-speaks.

        on_event: optional callback fired with EVERY engine event before the
        consumer processes it — lets a door observe the live turn (the wake
        door publishes VOICE_TURN_CHUNK to the web UI from it) without
        growing a second consumer. Exceptions in the callback are logged and
        never kill the turn.

        Million Dollar Bug Hunt merge, 2026-08-17: this replaced a second
        ~470-line blocking pipeline that had drifted from the streaming
        engine for a year (tool-cycle rows dropped thinking/metadata,
        per-iteration tokens under-reported, no cancel path, no tool
        events). THE TURN PIPELINE EXISTS EXACTLY ONCE. A future
        non-streaming provider fakes chat_completion_stream in the provider
        layer (~15 lines) — it never gets a second pipeline here.

        Inbox (2026-10-06): this door waits its turn. The LANDING chat (a chat
        room open on the screen, else the active chat; history.landing_chat) is the
        queue; the turn itself runs on the inbox's drainer thread in this
        caller's context, exclusive like a typed turn — before this it began a
        NON-exclusive stream and could land on top of a live turn (interleaved
        rows, a tool_use split from its result, a provider 400).
        """
        from core.chat import inbox
        from core.chat.history import landing_chat
        try:
            chat_name = landing_chat(self.session_manager) or ''
        except Exception:
            chat_name = ''
        if not chat_name:
            return self._chat_turn(user_input, on_event)
        try:
            return inbox.turn(chat_name, lambda: self._chat_turn(user_input, on_event, chat_name),
                              source='voice', lane='now', text=user_input)
        except inbox.InboxRefused as e:
            # the chat cannot take it (sealed, gone, or this is her own turn
            # asking to wait on itself): say so - running it unqueued on the
            # pointer bypassed the very refusal (seam scout, 2026-10-07)
            logger.warning(f"chat: inbox refused the turn: {type(e).__name__}")
            return str(e)

    def _chat_turn(self, user_input, on_event=None, queued_on=None):
        """The blocking turn itself (see chat()). Raises ChatBusy when the
        chat already has a live turn - the inbox requeues on that.
        queued_on: the chat this turn waited in line for. It runs THERE:
        pointer-bound while that chat is still the active one (today's path),
        pinned once the pointer moved - never in whatever chat happens to be
        active when the line reaches it (2026-10-07)."""
        stream, sid, chat_name = self.begin_stream(self.queued_target(queued_on), exclusive=True)
        stream.suppress_tts = True   # the caller voices the blob; pump stays inert
        final_text = None
        fallback_parts = []
        try:
            for event in stream.chat_stream(user_input):
                if on_event is not None:
                    try:
                        on_event(event)
                    except Exception as cb_err:
                        logger.warning(f"chat on_event callback failed: {cb_err}")
                        on_event = None   # broken observer: stop calling, keep the turn
                if not isinstance(event, dict):
                    fallback_parts.append(str(event))
                    continue
                et = event.get("type")
                if et == "final":
                    final_text = event.get("text", "")
                elif et == "content":
                    fallback_parts.append(event.get("text", ""))
                elif et == "notice":
                    # REST door reads pending_notices as toasts; the voice
                    # door drains them in process_llm_query's finally.
                    self.pending_notices.append({
                        "message": event.get("message", ""),
                        "severity": event.get("severity", "warning"),
                    })
                # tool/tts/iteration events: play-by-play, nothing to keep
        except Exception as e:
            # The doors never see a raise. The engine already saved the
            # error row before raising (chat_stream's outer handlers), so
            # no history write here — one more would double-log the turn.
            logger.error(f"Chat error: {e}", exc_info=True)
            return fallback_error_text(e)
        finally:
            self.end_stream(sid, chat_name)

        if final_text is not None:
            return final_text
        # Defensive: an exit path missed its final event. Reconstruct from
        # the content stream — which wraps thinking in <think> tags for UI
        # rendering; strip them so voice doesn't read reasoning aloud.
        text = "".join(fallback_parts)
        from core import think
        text = think.strip(text)
        return text

    def _select_provider(self):
        """Select this turn's provider from the chat's settings. Returns
        (provider_key, provider, model_override) or raises ConnectionError.

        Thin door onto core.chat.llm_providers.resolve — the ONE resolver
        (2026-09-21). The 3-tuple entry point stays because the engine, 21
        test files and a user plugin drive it. get_chat_settings() is
        stream-override aware, so this reads the TARGET chat (phone streams,
        VC chats, by-name room turns), never blindly the web tab's."""
        from core.chat.llm_providers.resolve import resolve, GLOBAL
        chat_settings = self.session_manager.get_chat_settings()
        try:
            _rt = float(chat_settings.get('llm_request_timeout') or 0)
        except (TypeError, ValueError):
            _rt = 0.0
        return resolve(
            chat_settings.get('llm_primary', 'auto'),
            chat_settings.get('llm_model', ''),
            private=bool(chat_settings.get('private_chat', False)),
            # A chat with no prompt key runs whatever is globally active, so
            # the global flag IS the right one; a named prompt answers for
            # itself (the old pre-flight read the GLOBAL prompt for phone
            # streams — the wrong chat).
            prompt_name=chat_settings.get('prompt') or GLOBAL,
            timeout=_rt,
            # Session affinity ({session}): the EFFECTIVE chat, same one the
            # settings above came from — a phone stream keys its own chat.
            conversation=self.session_manager._effective_chat_name(),
        ).as_tuple()

    def reset(self):
        self.session_manager.clear()
        from core.chat.function_manager import reset_scopes
        reset_scopes()
        return True

    def list_chats(self) -> List[Dict[str, Any]]:
        return self.session_manager.list_chat_files()

    def create_chat(self, chat_name: str, settings=None) -> bool:
        return self.session_manager.create_chat(chat_name, settings=settings)

    def delete_chat(self, chat_name: str) -> bool:
        return self.session_manager.delete_chat(chat_name)

    def switch_chat(self, chat_name: str) -> bool:
        return self.session_manager.set_active_chat(chat_name)

    def get_active_chat(self) -> str:
        return self.session_manager.get_active_chat_name()

