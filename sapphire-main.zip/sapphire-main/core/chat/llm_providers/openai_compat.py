# llm_providers/openai_compat.py
"""
OpenAI-compatible provider.

Handles:
- LM Studio (local)
- llama.cpp server (local)
- Fireworks.ai (cloud)
- OpenRouter (cloud)
- Any OpenAI-compatible API

This is the default provider and your 99% use case.
"""

import json
import logging
import re
import threading
import time
from typing import Dict, Any, List, Optional, Generator

from openai import OpenAI

from .base import BaseProvider, LLMResponse, ToolCall, retry_on_rate_limit, server_answered, http_status, AUTH_DEAD_STATUSES

logger = logging.getLogger(__name__)

# ── Shared HTTP transport pool ───────────────────────────────────────────────
# Provider objects are rebuilt every turn (cheap), but the TRANSPORT persists
# here so the TCP+TLS connection to each endpoint stays warm across turns.
# Without this, every voice/phone turn paid a fresh DNS+TCP+TLS handshake:
# each new OpenAI() got its own httpx pool, and httpx's default
# keepalive_expiry (5s) is shorter than any conversational gap anyway.
# API keys ride per-request headers, so providers sharing an endpoint can
# safely share a pool; per-request timeouts still come from each provider's
# own OpenAI(timeout=...) (explicit timeout wins over the client's). 2026-07-15.
_HTTP_POOL = {}
_HTTP_POOL_LOCK = threading.Lock()
_KEEPALIVE_SECONDS = 120.0


def _shared_http_client(base_url):
    import httpx
    key = (base_url or "").rstrip("/")
    with _HTTP_POOL_LOCK:
        cli = _HTTP_POOL.get(key)
        if cli is None or cli.is_closed:
            cli = httpx.Client(
                limits=httpx.Limits(max_connections=100,
                                    max_keepalive_connections=20,
                                    keepalive_expiry=_KEEPALIVE_SECONDS),
                timeout=httpx.Timeout(600.0, connect=10.0),
            )
            _HTTP_POOL[key] = cli
        return cli


def _drop_http_pool():
    """Proxy config changed — drop pooled clients so the next construction
    picks up the new env mounts (httpx reads proxy env at CLIENT build).
    References only: in-flight requests finish on their old client, GC
    reaps. (SOCKS-for-all, 2026-08-31)"""
    with _HTTP_POOL_LOCK:
        _HTTP_POOL.clear()


try:
    from core.socks_proxy import register_invalidator as _reg_inv
    _reg_inv(_drop_http_pool)
except Exception:
    pass


# Params a strict endpoint may refuse; each is optional to the request. A
# 400 naming one is learned ONCE per provider instance (Krem's F1a,
# 2026-08-23): stripped, the request retried, never sent again until
# restart — one warning + toast names it and where to clear it.
# stream_options rides the same law (it used to re-pay the double request
# on EVERY streaming call to an endpoint that refused it).
OPTIONAL_PARAMS = ('presence_penalty', 'frequency_penalty', 'repeat_penalty',
                   'top_k', 'stream_options')
# Not in the OpenAI SDK's signature — passing them as kwargs is a TypeError,
# so they ride extra_body (LM Studio / llama.cpp honor them there).
EXTRA_BODY_PARAMS = ('repeat_penalty', 'top_k',
                     # local-server samplers someone adds by hand (hunt 20: a
                     # min_p as a kwarg raised TypeError on every turn)
                     'min_p', 'typical_p', 'repetition_penalty', 'tfs_z',
                     'mirostat', 'mirostat_tau', 'mirostat_eta')
PENALTY_PARAMS = ('presence_penalty', 'frequency_penalty', 'repeat_penalty', 'top_k')


# endpoint|model → optional params that endpoint refused (learn-once, lives
# until restart — the toast says so). See OpenAICompatProvider.__init__.
_REJECTED_PARAMS: Dict[str, set] = {}

# endpoint → (model its server named, trusted_until): a provider with no model
# set asks once a minute, never per turn. Misses are never kept.
_FOUND_MODEL: Dict[str, tuple] = {}
_FOUND_TTL = 60.0
# (server root, model) → (tokens it holds for one request | None, trusted_until).
# A reload in LM Studio can change it, so it is asked again each minute.
_WINDOW: Dict[tuple, tuple] = {}
_LAST_WINDOW: Dict[tuple, int] = {}          # the last window a server really reported, per (root, model)
_LAN_NAMES = ('.local', '.lan', '.home', '.home.arpa', '.internal', '.ts.net')


def near_host(base_url) -> bool:
    """This machine, the LAN or Tailscale: a server the person runs, never a
    cloud API. One test for the window probe (context_window) and Continue
    (resolve.continues_in_place)."""
    from urllib.parse import urlparse
    import ipaddress
    host = (urlparse(base_url or '').hostname or '').lower()
    if not host:
        return False
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip in ipaddress.ip_network('100.64.0.0/10')   # + Tailscale
    except ValueError:
        return host == 'localhost' or '.' not in host or host.endswith(_LAN_NAMES)
_NOT_CHAT = re.compile(r'embed|rerank|whisper|tts|moderation', re.I)


def _notify(message: str, severity: str = 'warning') -> None:
    """Surface a provider notice as a UI toast (best effort, never raises)."""
    try:
        from core.event_bus import publish, Events
        publish(Events.PLUGIN_NOTICE, {'plugin': 'llm', 'message': message,
                                       'severity': severity})
    except Exception:
        pass


def _join_user(a, b):
    """Two user contents as one: strings join with a blank line; a multimodal
    list on either side keeps every part."""
    if isinstance(a, str) and isinstance(b, str):
        return f"{a}\n\n{b}".strip()
    parts = lambda c: c if isinstance(c, list) else ([{"type": "text", "text": c}] if c else [])
    return parts(a) + parts(b)


class OpenAICompatProvider(BaseProvider):
    """
    Provider for OpenAI-compatible APIs.
    
    Works with any server implementing the OpenAI chat completions API:
    - POST /v1/chat/completions
    - GET /v1/models (for health check)
    """

    # A subclass that speaks its own thinking switch (Gemini) sets this, so the
    # family dispatch in _inject_thinking_control stays out of its way.
    OWNS_THINKING_SWITCH = False
    # Send a tool call's provider-opaque `extra_content` back to the endpoint.
    # Off by default: strict endpoints 400 on fields they don't know.
    REPLAYS_TOOL_EXTRA = False

    def __init__(self, llm_config: Dict[str, Any], request_timeout: float = 240.0):
        super().__init__(llm_config, request_timeout)
        
        self._client = OpenAI(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout=self.request_timeout,
            http_client=_shared_http_client(self.base_url),
        )

        # Session affinity (Fireworks `user`, OpenCode `x-opencode-session`, …)
        # is config now: `{session}` in extra_body / extra_headers, filled per
        # request by BaseProvider.fill. The Fireworks host-sniff that used to
        # live here retired 2026-09-25 (settings_manager migrates old configs).

        # Optional params this endpoint has refused (learn-once, see OPTIONAL_PARAMS).
        # Process-lifetime memory keyed by endpoint+model: the provider object is
        # rebuilt from config EVERY turn, so a per-instance set forgot the lesson
        # immediately — every turn paid 400 → retry → toast (scout F1, 2026-09-20).
        self._rejected_params: set = _REJECTED_PARAMS.setdefault(f"{self.base_url}|{self.model}", set())

        logger.info(f"OpenAI-compat provider initialized: {self.base_url}")
    
    @property
    def provider_name(self) -> str:
        return self.config.get('provider', 'openai')
    
    @property
    def supports_images(self) -> bool:
        """Whether this provider instance supports vision/image inputs."""
        return self._supports_multimodal()
    
    def _supports_multimodal(self) -> bool:
        """
        Whether this provider instance supports multimodal (image) inputs.

        Priority:
        1. Explicit per-provider override `supports_images` in the config (wins).
        2. OpenAI official API → always.
        3. Self-hosted endpoints (localhost OR private LAN IPs OR .local) and
           known model marketplaces → detect by VLM model-name token.
        4. Unknown public endpoint → conservative (off).
        """
        import re as _re
        base_url = (self.base_url or '').lower()
        model = (self.model or '').lower()

        # 1. Explicit override — lets any vision-capable endpoint be declared
        #    regardless of host/name heuristics. Set supports_images on the provider.
        override = self.config.get('supports_images')
        logger.debug(f"[VISION-DEBUG] supports_images: base_url={base_url!r} model={model!r} config_flag={override!r}")
        if override is not None:
            logger.debug(f"[VISION-DEBUG]   -> config override decides: {bool(override)}")
            return bool(override)

        vision_indicators = ['llava', 'vision', 'vl', 'pixtral', 'bakllava', 'cogvlm',
                             'minicpm-v', 'internvl', 'gemma-3', 'qwen2-vl', 'qwen2.5-vl',
                             'qwen3-vl', 'gpt-4o', 'gpt-4-vision']

        # 2. OpenAI official
        if 'api.openai.com' in base_url:
            return True

        # 3. Self-hosted (user-run servers) + known marketplaces → detect by model name.
        #    Private-LAN IPs are self-hosted too — a Qwen-VL on the box at 192.168.x.x
        #    is just as vision-capable as one on localhost.
        is_self_hosted = (
            any(h in base_url for h in
                ['localhost', '127.0.0.1', '0.0.0.0', '.local', 'host.docker.internal'])
            or bool(_re.search(r'//(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)', base_url))
        )
        if is_self_hosted or 'fireworks.ai' in base_url or 'openrouter.ai' in base_url:
            supported = any(ind in model for ind in vision_indicators)
            logger.debug(f"[VISION-DEBUG]   -> heuristic (self_hosted={is_self_hosted}) name-match = {supported}")
            return supported

        # 4. Unknown public endpoint — conservative.
        logger.debug(f"[VISION-DEBUG]   -> unknown endpoint, defaulting OFF")
        return False
    
    def _is_deepseek_official(self) -> bool:
        """
        Check if this is DeepSeek's official endpoint (api.deepseek.com).

        V4 contract (api-docs.deepseek.com/guides/thinking_mode, verified
        2026-09-20): every model there (deepseek-v4-pro, deepseek-flash) thinks
        by default, switched via extra_body {"thinking": {"type": ...}}, and
        "for requests carrying the tools parameter, the reasoning_content must
        be fully passed back in all subsequent requests — even for turns where
        the model did not perform a tool call", else 400. The old name gate
        (`reasoner` in model) matched a model that was discontinued 2026-07-24
        and would have silently disarmed the round-trip for every V4 name.
        Other DeepSeek hosts (Fireworks, OpenRouter, Featherless) accept the
        plain OpenAI shape and ignore the field.
        """
        base_url = (self.base_url or '').lower()
        return 'api.deepseek.com' in base_url

    def _is_fireworks_reasoning_model(self) -> bool:
        """
        Check if this is a Fireworks reasoning model that needs reasoning_effort param.

        These models output thinking in reasoning_content field when reasoning_effort is set.
        """
        base_url = (self.base_url or '').lower()
        model = (self.model or '').lower()
        
        if 'fireworks.ai' not in base_url:
            return False
        
        # Models known to support reasoning_effort parameter
        reasoning_indicators = [
            'deepseek',      # DeepSeek V3
            'glm',           # GLM 4.7
            'kimi',          # Kimi K2
            'thinking',      # Any model with "thinking" in name
            'qwq',           # QwQ
        ]
        
        return any(ind in model for ind in reasoning_indicators)
    
    @property
    def client(self) -> OpenAI:
        """Access the underlying OpenAI client if needed."""
        return self._client
    
    def _try_v1_autocorrect(self) -> bool:
        """A missing /v1 suffix is the classic llama.cpp / Ollama misconfig
        (`http://box:11434` instead of `…:11434/v1`). Probe the corrected URL
        once; on success adopt it for this instance."""
        base = self.base_url.rstrip('/')
        if base.endswith('/v1'):
            return False
        corrected = base + '/v1'
        try:
            test_client = OpenAI(
                base_url=corrected,
                api_key=self.api_key,
                timeout=self.request_timeout,
                http_client=_shared_http_client(corrected),
            )
            test_client.models.list(timeout=self.health_check_timeout, **self._hdr_kwargs())
        except Exception:
            return False
        logger.info(f"Auto-corrected base_url: {self.base_url} -> {corrected}")
        self.base_url = corrected
        self._client = test_client
        return True

    def health_check(self) -> bool:
        """Reachability probe via models.list().

        Verdicts (2026-09-20 rework of the 2026-06-21 "any status = reachable"):
        - 200 → healthy.
        - 401/402/403 → DEAD. A refused key never fixes itself mid-turn; the old
          verdict picked the provider every turn in Auto mode, the completion
          failed, and everything behind it in the fallback order never ran.
        - 404 → try the /v1 auto-correct first (Ollama answers 404 on
          `{base}/models` when /v1 is missing — the old code only ran the fix
          on connection errors, where it can't help). If that doesn't take,
          count it reachable: a gateway without /models can still complete.
        - any other status (500, 429, …) → reachable; the completion is the
          judge (Fireworks' /models 500 must not mark a working box dead).
        - connection/DNS/timeout → /v1 auto-correct, else dead.
        One try, no SDK retries: a probe that waits 3x its budget plus backoff
        is a stall, not a verdict.
        """
        try:
            self._client.with_options(max_retries=0).models.list(
                timeout=self.health_check_timeout, **self._hdr_kwargs())
            return True
        except Exception as e:
            status = http_status(e)
            self.last_health_error = type(e).__name__ + (f" HTTP {status}" if status else "")
            if status in AUTH_DEAD_STATUSES:
                logger.info(f"Health check: {self.base_url} /models answered {status} — key refused, provider skipped")
                return False
            if status == 404 and self._try_v1_autocorrect():
                return True
            if server_answered(e):
                logger.debug(f"Health check: {self.base_url} /models errored ({e}) but server is reachable")
                return True
            logger.debug(f"Health check failed for {self.base_url}: {e}")
            return self._try_v1_autocorrect()

    def ensure_model(self, fetch: bool = True) -> bool:
        """A provider with no model set (the stock LM Studio entry, any box
        with auto_discover_models) names the model its server serves, so a
        blank model never goes out on the wire (Teri, 2026-10-23: Auto sent
        model "" to LM Studio while her pinned chat sent a real one). LM
        Studio is asked what is LOADED on every fetch, never guessed: it
        JIT-loads whatever name it is sent, so a stale or alphabetical pick
        loads the wrong model (2026-10-26: nothing loaded -> "altworld_..."
        won on the letter a, failed to load, the game room checked forever).
        Nothing loaded = False with `no_model` set to the words. Other
        servers: the first chat model /v1/models offers. fetch=False only
        uses what was found in the last minute."""
        if self.model:
            return True
        key, now = self.base_url.rstrip('/'), time.time()
        hit = _FOUND_MODEL.get(key)
        model = hit[0] if hit and now < hit[1] else ''
        if fetch:
            loaded = self._loaded_model()
            if loaded is not None:       # LM Studio: what's loaded now, or nothing
                model = loaded
                self.no_model = '' if loaded else 'has no model loaded. Load one in LM Studio, or set a model on its card in Settings › LLM.'
            elif not model:
                model = next((m['id'] for m in (self.list_models() or []) if not _NOT_CHAT.search(m['id'])), '')
            if model:
                if not hit or hit[0] != model:
                    logger.info(f"{self.base_url} has no model set: using '{model}', the one its server serves")
                _FOUND_MODEL[key] = (model, now + _FOUND_TTL)
            else:
                _FOUND_MODEL.pop(key, None)
        if not model:
            return False
        self.model = model
        self._rejected_params = _REJECTED_PARAMS.setdefault(f"{self.base_url}|{model}", set())
        return True

    def context_window(self) -> Optional[int]:
        """The tokens this server holds for one request (prompt + reply), as
        it says itself: LM Studio's loaded_context_length (/api/v0/models),
        llama.cpp's per-slot n_ctx (/props), Ollama's context_length
        (/api/ps). Asked of a local or LAN server only, once a minute; None =
        unknown (a cloud API, a server that doesn't say), and the app's own
        Context Limit stands alone. core/chat/budget.py reads it."""
        if not (near_host(self.base_url) or self.config.get('is_local')):
            return None
        root = re.sub(r'/v1/?$', '', self.base_url.rstrip('/'))
        key, now = (root, self.model or ''), time.time()
        hit = _WINDOW.get(key)
        if hit and now < hit[1]:
            return hit[0]
        found = None
        client = _shared_http_client(self.base_url)
        hdrs = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}

        def ask(path):
            try:
                r = client.get(f"{root}{path}", headers=hdrs, timeout=1.5)
                return r.json() if r.status_code == 200 else None
            except Exception:
                return None

        def tokens(v):
            try:
                n = int(v)
                return n if n > 0 else None
            except (TypeError, ValueError):
                return None

        lms = ask('/api/v0/models')
        if isinstance(lms, dict) and isinstance(lms.get('data'), list):
            loaded = [m for m in lms['data'] if isinstance(m, dict) and m.get('state') == 'loaded'
                      and m.get('type') in ('llm', 'vlm')]
            pick = next((m for m in loaded if m.get('id') == self.model), loaded[0] if loaded and not self.model else None)
            found = tokens(pick.get('loaded_context_length')) if pick else None
        else:
            props = ask('/props')
            if isinstance(props, dict):
                found = tokens((props.get('default_generation_settings') or {}).get('n_ctx') or props.get('n_ctx'))
            else:
                ps = ask('/api/ps')
                if isinstance(ps, dict) and isinstance(ps.get('models'), list):
                    tag = lambda n: str(n or '') if ':' in str(n or '') else f"{n}:latest"   # Ollama: llama3 = llama3:latest
                    pick = next((m for m in ps['models'] if isinstance(m, dict)
                                 and tag(self.model) in (tag(m.get('name')), tag(m.get('model')))), None)
                    found = tokens(pick.get('context_length')) if pick else None
        if found is None and _LAST_WINDOW.get(key):
            found = _LAST_WINDOW[key]      # unloaded while idle: it reloads as it was, so the last real answer stands
        elif found:
            _LAST_WINDOW[key] = found
        if found != (hit[0] if hit else None):
            logger.info(f"[CONTEXT] {root} ({self.model or 'its loaded model'}) holds {found or 'an unknown number of'} tokens per request")
        _WINDOW[key] = (found, now + (_FOUND_TTL if found else 10.0))      # a miss is asked again soon
        return found

    def forget_window(self):
        """The server refused a request as too long: ask its window afresh next time."""
        root = re.sub(r'/v1/?$', '', (self.base_url or '').rstrip('/'))
        _WINDOW.pop((root, self.model or ''), None)

    def _loaded_model(self):
        """LM Studio's native list (/api/v0/models: type + state per model):
        the first chat model that is loaded, '' when none is. None from any
        other server (no such list)."""
        root = re.sub(r'/v1/?$', '', self.base_url.rstrip('/'))
        try:
            hdrs = {'Authorization': f'Bearer {self.api_key}'} if self.api_key else {}
            r = _shared_http_client(self.base_url).get(
                f"{root}/api/v0/models", headers=hdrs, timeout=max(self.health_check_timeout, 1.0))
            data = r.json().get('data') if r.status_code == 200 else None
            if not isinstance(data, list):
                return None
            for m in data:
                if m.get('state') == 'loaded' and m.get('type') in ('llm', 'vlm'):
                    return str(m.get('id') or '')
            return ''
        except Exception:
            return None

    def list_models(self) -> Optional[list]:
        """Discover available models via /v1/models endpoint (one try: a
        dead box answers 'none' now, not after the SDK's retries)."""
        try:
            response = self._client.with_options(max_retries=0).models.list(
                timeout=self.health_check_timeout, **self._hdr_kwargs())
            models = []
            for m in response.data:
                models.append({
                    'id': m.id,
                    'name': getattr(m, 'name', m.id) or m.id,
                })
            models.sort(key=lambda x: x['name'].lower())
            return models
        except Exception as e:
            logger.debug(f"Model discovery failed for {self.base_url}: {e}")
            return None

    def _transform_params_for_model(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Transform generation params for model compatibility.
        
        GPT-5+ and o1/o3 reasoning models:
        - Use max_completion_tokens instead of max_tokens
        - Don't support temperature, top_p, presence_penalty, frequency_penalty
        
        This handles conversions transparently so callers don't need to care.
        """
        if not params:
            return params

        # Blank = absent = never sent (None would go out as JSON null).
        result = {k: v for k, v in params.items() if v is not None and v != ''}

        # Strip internal Sapphire params that aren't part of the OpenAI API
        result.pop('disable_thinking', None)

        model_lower = (self.model or '').lower()

        # Detect reasoning models (GPT-5+/GPT-6, o1, o3)
        is_reasoning_model = (
            model_lower.startswith(('gpt-5', 'gpt-6')) or
            model_lower.startswith('o1') or
            model_lower.startswith('o3')
        )

        # Detect models that don't support penalty params (Grok, etc.)
        is_grok = (
            model_lower.startswith('grok-') or
            self.config.get('strip_penalties', False)
        )

        if is_reasoning_model:
            # max_tokens → max_completion_tokens
            if 'max_tokens' in result:
                result['max_completion_tokens'] = result.pop('max_tokens')

            # Remove unsupported sampling params (reasoning models don't use these)
            removed = []
            for unsupported in ['temperature', 'top_p', *PENALTY_PARAMS]:
                if unsupported in result:
                    result.pop(unsupported)
                    removed.append(unsupported)

            if removed:
                logger.debug(f"Filtered unsupported params for {self.model}: {removed}")

        elif is_grok:
            removed = []
            for unsupported in [*PENALTY_PARAMS, 'stop']:
                if unsupported in result:
                    result.pop(unsupported)
                    removed.append(unsupported)

            if removed:
                logger.debug(f"Filtered unsupported params for {self.model}: {removed}")

        # Non-schema knobs ride extra_body — as kwargs they'd TypeError in the SDK.
        for k in EXTRA_BODY_PARAMS:
            if k in result:
                result.setdefault('extra_body', {})[k] = result.pop(k)

        return result

    # ── Learn-once param stripping ─────────────────────────────────────────

    def _strip_rejected(self, kwargs: Dict[str, Any]) -> None:
        for p in self._rejected_params:
            kwargs.pop(p, None)
            eb = kwargs.get('extra_body')
            if isinstance(eb, dict):
                eb.pop(p, None)
                if not eb:
                    kwargs.pop('extra_body', None)

    def _params_named(self, err: Exception, kwargs: Dict[str, Any]) -> List[str]:
        """Which OPTIONAL params of THIS request the error names."""
        text = f"{err} {getattr(err, 'body', '') or ''}".lower()
        eb = kwargs.get('extra_body') or {}
        sent = [p for p in OPTIONAL_PARAMS if p in kwargs or p in eb]
        named = [p for p in sent if p in text]
        if not named and 'stream_options' in sent and any(
                h in text for h in ('unrecognized', 'unknown parameter', 'unknown field')):
            # endpoints that refuse stream_options without naming it (llama.cpp lineage)
            named = ['stream_options']
        return named

    def _create(self, request_kwargs: Dict[str, Any]):
        """chat.completions.create with learn-once stripping of refused
        optional params: strip what this endpoint already refused, try,
        and on a refusal naming an optional param remember it, warn once
        (log + toast), retry once without it."""
        request_kwargs.update(self._hdr_kwargs())   # extra_headers ({session}/{version}), if configured
        self._strip_rejected(request_kwargs)
        try:
            return retry_on_rate_limit(self._client.chat.completions.create, **request_kwargs)
        except Exception as e:
            bad = self._params_named(e, request_kwargs)
            if not bad:
                from core.socks_proxy import maybe_llm_proxy_hint
                maybe_llm_proxy_hint(self.config.get('display_name') or self.provider_name, str(e))
                raise
            self._rejected_params.update(bad)
            self._strip_rejected(request_kwargs)
            where = self.config.get('display_name') or self.provider_name
            msg = (f"{where} ({self.model}) rejected {', '.join(bad)} — sent without it from "
                   f"now on (until restart). Clear it under Settings › LLM › {where} to stop this.")
            logger.warning(f"[OPENAI-COMPAT] {msg} | {e}")
            _notify(msg)
            try:
                return retry_on_rate_limit(self._client.chat.completions.create, **request_kwargs)
            except Exception as e2:
                from core.socks_proxy import maybe_llm_proxy_hint
                maybe_llm_proxy_hint(self.config.get('display_name') or self.provider_name, str(e2))
                raise
    
    def _sanitize_messages(self, messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Sanitize messages for OpenAI-compatible APIs.
        
        Handles cross-provider compatibility:
        - Strips Claude-specific fields (thinking_raw, thinking, metadata)
        - Converts content lists to strings (Claude uses content blocks)
        - Normalizes tool results from Claude format to OpenAI format
        - Ensures proper message structure for tool calls
        """
        clean = []
        
        for msg in messages:
            role = msg.get('role', '')
            content = msg.get('content')
            
            # Handle Claude-format tool results: {"role": "user", "content": [{"type": "tool_result", ...}]}
            # Convert to OpenAI format: {"role": "tool", "tool_call_id": ..., "content": ...}
            if role == 'user' and isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get('type') == 'tool_result':
                        tool_use_id = block.get('tool_use_id', '')
                        # Convert Claude tool ID format if needed
                        if tool_use_id.startswith('toolu_'):
                            tool_use_id = 'call_' + tool_use_id[6:]
                        clean.append({
                            'role': 'tool',
                            'tool_call_id': tool_use_id,
                            'name': block.get('name', 'unknown'),
                            'content': block.get('content', '')
                        })
                # If we processed tool_result blocks, skip the original message
                if any(isinstance(b, dict) and b.get('type') == 'tool_result' for b in content):
                    continue
            
            # Normalize content - handle multimodal content lists
            if isinstance(content, list):
                # Images ride only when the vision checkbox (supports_images) is
                # on. Pre-fix this "always sent images and let the provider
                # reject" — with the vision window replaying last turn's contact
                # sheet, a text-only model 400'd on the very next message
                # (Krem, 2026-09-10). Off → the placeholder branch below, like
                # the Anthropic converter.
                has_images = self.supports_images and any(
                    isinstance(b, dict) and b.get('type') == 'image'
                    for b in content
                )
                
                if has_images:
                    # Convert to OpenAI multimodal format
                    openai_content = []
                    for block in content:
                        if isinstance(block, dict):
                            if block.get('type') == 'text':
                                openai_content.append({"type": "text", "text": block.get('text', '')})
                            elif block.get('type') == 'image':
                                # Internal: {"type": "image", "data": "...", "media_type": "..."}
                                # OpenAI:   {"type": "image_url", "image_url": {"url": "data:...;base64,..."}}
                                from core.images import wire_safe
                                data, media_type = wire_safe(block.get('data', ''), block.get('media_type', 'image/jpeg'))
                                openai_content.append({
                                    "type": "image_url",
                                    "image_url": {"url": f"data:{media_type};base64,{data}"}
                                })
                            elif block.get('type') in ('thinking', 'tool_use'):
                                # Skip thinking and tool_use blocks
                                continue
                        elif isinstance(block, str):
                            openai_content.append({"type": "text", "text": block})
                    content = openai_content if openai_content else ""
                else:
                    # No images - flatten to string
                    text_parts = []
                    for block in content:
                        if isinstance(block, dict):
                            if block.get('type') == 'text':
                                text_parts.append(block.get('text', ''))
                            elif block.get('type') == 'thinking':
                                # Skip thinking blocks - they shouldn't be sent to other providers
                                continue
                            elif block.get('type') == 'tool_use':
                                # Tool use blocks are handled via tool_calls field
                                continue
                            elif block.get('type') == 'image':
                                # Vision off: the pixels stay home, the model is told why
                                text_parts.append('[image not sent: this model has no vision]')
                        elif isinstance(block, str):
                            text_parts.append(block)
                    content = ' '.join(text_parts).strip()
            
            # Build clean message with only allowed fields
            clean_msg = {'role': role}
            
            # Handle content - preserve list for multimodal, stringify otherwise
            if content is not None:
                if isinstance(content, list):
                    clean_msg['content'] = content  # Keep list for multimodal
                else:
                    clean_msg['content'] = str(content) if content else ''
            elif 'tool_calls' in msg:
                # OpenAI requires content field, use empty string if tool_calls present
                clean_msg['content'] = ''
            else:
                clean_msg['content'] = ''
            
            # Handle tool_calls (assistant messages)
            if msg.get('tool_calls'):
                # Normalize tool_calls format for OpenAI-compat APIs
                normalized_calls = []
                for tc in msg['tool_calls']:
                    if isinstance(tc, dict):
                        func = tc.get('function', {})

                        # Get arguments - MUST be a valid JSON-encoded string per OpenAI spec.
                        # Strict providers (Ollama Cloud, etc.) reject dicts or malformed strings.
                        args = func.get('arguments', '{}')
                        if args is None or args == '':
                            args = '{}'
                        elif isinstance(args, dict):
                            args = json.dumps(args)
                        elif isinstance(args, str):
                            try:
                                json.loads(args)
                            except (json.JSONDecodeError, ValueError):
                                logger.warning(f"[OPENAI-COMPAT] Tool call arguments not valid JSON, defaulting to empty ({len(args)} chars)")
                                args = '{}'
                        else:
                            args = '{}'

                        # Get tool ID - convert Claude format if needed
                        tool_id = tc.get('id', '')
                        if tool_id.startswith('toolu_'):
                            # Convert Claude ID to OpenAI-compatible format
                            tool_id = 'call_' + tool_id[6:]
                        
                        normalized_tc = {
                            'id': tool_id,
                            'type': 'function',
                            'function': {
                                'name': func.get('name', ''),
                                'arguments': args
                            }
                        }
                        if self.REPLAYS_TOOL_EXTRA and isinstance(tc.get('extra_content'), dict):
                            normalized_tc['extra_content'] = tc['extra_content']
                        normalized_calls.append(normalized_tc)
                if normalized_calls:
                    clean_msg['tool_calls'] = normalized_calls
            
            # Handle tool results (tool messages)
            if role == 'tool':
                tool_call_id = msg.get('tool_call_id', '')
                # Convert Claude tool ID format if needed
                if tool_call_id.startswith('toolu_'):
                    tool_call_id = 'call_' + tool_call_id[6:]
                clean_msg['tool_call_id'] = tool_call_id
                clean_msg['name'] = msg.get('name', 'unknown')
            
            # Include name field for function calls if present
            if msg.get('name') and role != 'tool':
                clean_msg['name'] = msg['name']

            # DeepSeek official API requires reasoning_content round-tripped
            # on assistant turns — V4 (2026-09-20) says EVERY assistant turn
            # once tools are in play, not just the tool-calling ones (the
            # 2026-05-11 rule). Without it the next request 400s "Missing
            # reasoning_content field in the assistant message at index N".
            # Only the official endpoint; other hosts ignore the field.
            if self._is_deepseek_official() and msg.get('thinking'):
                clean_msg['reasoning_content'] = msg['thinking']

            # Two user rows in a row (a ghost line, a retry after a failed
            # turn whose error row the history hides, a task appending its cue)
            # become one: Gemma/Mistral chat templates in LM Studio, Ollama and
            # llama.cpp refuse a conversation whose roles don't alternate.
            prev = clean[-1] if clean else None
            if (role == 'user' and prev is not None and prev['role'] == 'user'
                    and not prev.get('name') and not clean_msg.get('name')):
                prev['content'] = _join_user(prev['content'], clean_msg['content'])
                continue

            clean.append(clean_msg)

        # (The old Qwen `/no_think` token trick was removed 2026-07-02 — it never
        #  reliably worked. Thinking-disable now goes through _inject_thinking_control
        #  via extra_body, which is the mechanism Qwen/vLLM actually honor.)
        return clean
    
    def chat_completion(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        generation_params: Optional[Dict[str, Any]] = None
    ) -> LLMResponse:
        """Send non-streaming chat completion request."""

        params = self._transform_params_for_model(generation_params or {})

        # Some OpenAI-compat providers (Zhipu GLM, others) enforce:
        #   "Requests with max_tokens > 4096 must have stream=true"
        # at the endpoint. The non-streaming path here would silently 400 for
        # any caller (voice path, continuity tasks, agents) whose gen_params
        # exceed that threshold. Rather than cap max_tokens or force callers
        # to track provider quirks, when we'd cross the gate we consume the
        # streaming endpoint internally and return the same LLMResponse the
        # non-streaming path would have produced. Caller sees no behavior
        # change. Bug surfaced on voice + glm51 (max_tokens=8192) 2026-04-20.
        mt = params.get('max_tokens') or 0
        if mt and mt > 4096:
            logger.info(
                f"[OPENAI-COMPAT] max_tokens={mt} > 4096 — using streaming "
                f"internally to satisfy provider stream-required contract; "
                f"caller still receives a single LLMResponse."
            )
            final, thinking = None, None
            for event in self.chat_completion_stream(messages, tools=tools,
                                                     generation_params=generation_params):
                if event.get("type") == "done":
                    final, thinking = event.get("response"), event.get("thinking")
            if final is None:
                raise ValueError(
                    "Internal stream-accumulate produced no 'done' event — "
                    "provider may have closed the stream without finishing."
                )
            # The same response _parse_response makes: the reasoning rides as
            # `thinking` (DeepSeek official 400s round 2 of a tool loop
            # without it) and wrapped ahead of real content (GLM-style tool
            # calls in the reasoning stay findable). Dropped since the 8192
            # default sent every background lane here (hunt 19).
            if thinking:
                final.thinking = thinking
                if final.content and not final.content_is_reasoning:
                    from core import think as _think
                    final.content = _think.wrap(thinking, final.content)
            return final

        # Sanitize messages - only keep fields the OpenAI API understands
        clean_messages = self._sanitize_messages(messages)
        
        logger.debug(f"[OPENAI-COMPAT] Non-streaming: {len(clean_messages)} messages to {self.model}")
        
        request_kwargs = {
            "model": self.model,
            "messages": clean_messages,
            **params
        }

        # Add reasoning_effort for Fireworks reasoning models
        if self._is_fireworks_reasoning_model():
            request_kwargs["reasoning_effort"] = params.get("reasoning_effort", "medium")

        if tools:
            request_kwargs["tools"] = self.convert_tools_for_api(tools)
            # Note: tool_choice omitted intentionally. Per OpenAI spec, "auto" is the
            # default when tools are present, so setting it is redundant. Omitting it
            # reduces the rejection surface with strict OpenAI-compat providers.
            # (Matches the Anthropic provider, which also never sets tool_choice.)

        # Thinking control (universal, family-gated) + raw extra_body passthrough.
        self._inject_thinking_control(
            request_kwargs, want_disable=(generation_params or {}).get('disable_thinking', False))

        response = self._create(request_kwargs)

        return self._parse_response(response)

    def _inject_thinking_control(self, kwargs: dict, want_disable: bool = False) -> None:
        """Merge thinking-control + a raw extra_body passthrough into the request.

        Universal, best-effort, per-provider "disable thinking" (replaces the old
        Qwen-only /no_think trick). Family-GATED: a model's own off-switch is sent
        ONLY to that family, so a strict endpoint never sees a param it 400s on.
        Unknown models are a logged no-op — the user's raw `extra_body` config is the
        escape hatch for those. OFF path (no flag, no extra_body config) leaves kwargs
        untouched → byte-identical to a no-op.

        "Disable" comes from any of: the per-provider `disable_thinking` config (the
        Settings checkbox), the per-request `disable_thinking` gen param (continue/
        prefill), or the legacy `disable_thinking_qwen` flag (migrated transparently).
        """
        cfg = self.config
        disable = not self.OWNS_THINKING_SWITCH and (
            want_disable or cfg.get('disable_thinking', False)
            or cfg.get('disable_thinking_qwen', False))
        raw = cfg.get('extra_body')
        if not (disable or raw):
            return                                    # OFF path — leave kwargs untouched

        extra = dict(kwargs.get('extra_body') or {})

        if disable:
            model = (self.model or '').lower()
            base = (self.base_url or '').lower()
            if self._is_fireworks_reasoning_model():
                # Fireworks disables reasoning via the top-level `reasoning_effort`
                # param (none/false), NOT extra_body — its schema is strict and 400s
                # on unknown fields like `thinking` / `chat_template_kwargs`. This
                # overrides the "medium" default set in build_request_kwargs.
                kwargs['reasoning_effort'] = 'none'
                fam = 'fireworks'
            elif 'api.deepseek.com' in base:
                extra['thinking'] = {'type': 'disabled'}          # DeepSeek V4 official (on by default)
                fam = 'deepseek'
            elif model.startswith('glm') or any(h in base for h in ('z.ai', 'bigmodel', 'zhipu')):
                extra['thinking'] = {'type': 'disabled'}          # GLM / Z.AI convention
                fam = 'glm'
            elif 'qwen' in model:
                ctk = dict(extra.get('chat_template_kwargs') or {})
                ctk['enable_thinking'] = False                    # Qwen 3 (vLLM / LM Studio)
                extra['chat_template_kwargs'] = ctk
                fam = 'qwen'
            else:
                fam = None                                        # unknown → don't guess (avoid 400)
            if fam:
                logger.info(f"[OPENAI-COMPAT] disable_thinking ({fam}) → {self.model}")
            else:
                logger.info(f"[OPENAI-COMPAT] disable_thinking requested but no known switch "
                            f"for {self.model}; set extra_body manually if it's a reasoning model")

        if raw:
            try:
                rb = self.fill(raw if isinstance(raw, dict) else json.loads(raw))   # {session}/{version}
                if isinstance(rb, dict):
                    extra.update(rb)                              # user's raw extra_body wins
                else:
                    logger.warning("[OPENAI-COMPAT] extra_body config is not a JSON object; ignoring")
            except (ValueError, TypeError) as e:
                logger.warning(f"[OPENAI-COMPAT] extra_body config not valid JSON, ignoring: {e}")

        if extra:
            kwargs['extra_body'] = extra

    def chat_completion_stream(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        generation_params: Optional[Dict[str, Any]] = None
    ) -> Generator[Dict[str, Any], None, None]:
        """Send streaming chat completion request."""
        
        params = self._transform_params_for_model(generation_params or {})
        
        # Sanitize messages - only keep fields the OpenAI API understands
        clean_messages = self._sanitize_messages(messages)
        
        # DEBUG: Log message structure (reduced verbosity)
        logger.info(f"[OPENAI-COMPAT] Sending {len(clean_messages)} messages to {self.base_url} model={self.model}")
        logger.debug(f"[OPENAI-COMPAT] Multimodal supported: {self._supports_multimodal()}")
        for i, msg in enumerate(clean_messages):
            role = msg.get('role')
            content = msg.get('content')
            content_type = type(content).__name__
            has_tc = 'tool_calls' in msg
            
            if isinstance(content, str):
                preview = content[:60] + '...' if len(content) > 60 else content
            elif isinstance(content, list):
                preview = f"[list with {len(content)} items]"
            else:
                preview = str(content)[:60]
            
            logger.debug(f"[OPENAI-COMPAT]   [{i}] role={role}, content_type={content_type}, has_tool_calls={has_tc}, preview={preview}")
        
        request_kwargs = {
            "model": self.model,
            "messages": clean_messages,
            "stream": True,
            "stream_options": {"include_usage": True},
            **params
        }

        # Add reasoning_effort for Fireworks reasoning models to enable thinking output
        if self._is_fireworks_reasoning_model():
            request_kwargs["reasoning_effort"] = params.get("reasoning_effort", "medium")
            logger.info(f"[REASONING] Enabled reasoning_effort={request_kwargs['reasoning_effort']} for {self.model}")

        if tools:
            request_kwargs["tools"] = self.convert_tools_for_api(tools)
            # Note: tool_choice omitted intentionally. Per OpenAI spec, "auto" is the
            # default when tools are present, so setting it is redundant. Omitting it
            # reduces the rejection surface with strict OpenAI-compat providers.
            # (Matches the Anthropic provider, which also never sets tool_choice.)

        # Thinking control (universal, family-gated) + raw extra_body — streaming path too.
        self._inject_thinking_control(
            request_kwargs, want_disable=(generation_params or {}).get('disable_thinking', False))

        logger.info(f"[OPENAI-COMPAT] Request params: model={request_kwargs.get('model')}, tools={len(request_kwargs.get('tools', []))}")

        # Refused optional params (stream_options on llama.cpp-lineage servers,
        # a penalty a strict cloud endpoint won't take) are learned once and
        # retried without — see _create. Anything else fails loud.
        try:
            stream = self._create(request_kwargs)
        except Exception as e:
            logger.error(f"[OPENAI-COMPAT] REQUEST FAILED: {e}")
            logger.error(f"[OPENAI-COMPAT] Message count: {len(clean_messages)}, has tool_calls: {any('tool_calls' in m for m in clean_messages)}")
            raise
        
        # Track accumulated state for final response
        full_content = ""
        full_thinking = ""
        tool_calls_acc = []  # List of dicts being built
        finish_reason = None
        usage = None

        for chunk in stream:
            # Final chunk with usage data (stream_options=include_usage)
            if hasattr(chunk, 'usage') and chunk.usage:
                usage = {
                    "prompt_tokens": chunk.usage.prompt_tokens or 0,
                    "completion_tokens": chunk.usage.completion_tokens or 0,
                    "total_tokens": chunk.usage.total_tokens or 0
                }
                # Some providers include cache stats. OpenAI/Fireworks report
                # prompt_tokens INCLUSIVE of cached; normalize to the Anthropic
                # convention (prompt_tokens = NON-cached input, cached counted
                # separately) so the shared cache% formula — cache_read /
                # (prompt + cache_read) — isn't double-counted (which otherwise
                # caps the displayed hit rate at ~50%). 2026-05-30.
                cache_read = getattr(chunk.usage, 'prompt_tokens_details', None)
                if cache_read and hasattr(cache_read, 'cached_tokens'):
                    cached = cache_read.cached_tokens or 0
                    if cached > 0:
                        usage["cache_read_tokens"] = cached
                        usage["prompt_tokens"] = max(0, usage["prompt_tokens"] - cached)
                        logger.info(f"[CACHE] Stream usage: {cached} cached of {usage['prompt_tokens'] + cached} prompt tokens")
                _ctd = getattr(chunk.usage, 'completion_tokens_details', None)
                _rt = getattr(_ctd, 'reasoning_tokens', None) if _ctd else None
                if _rt:
                    usage["reasoning_tokens"] = int(_rt)

            if not chunk.choices:
                continue
            
            choice = chunk.choices[0]
            delta = choice.delta
            
            if choice.finish_reason:
                finish_reason = choice.finish_reason
            
            # Reasoning content (Fireworks GLM, DeepSeek, etc.)
            # These models return thinking in reasoning_content field instead of <think> tags
            reasoning = getattr(delta, 'reasoning_content', None)
            if reasoning:
                full_thinking += reasoning
                yield {"type": "thinking", "text": reasoning}
            
            # Debug: log all delta attributes on first content chunk to diagnose missing reasoning
            if delta.content and not full_content:
                delta_attrs = [a for a in dir(delta) if not a.startswith('_')]
                logger.debug(f"[REASONING] Delta attributes: {delta_attrs}")
                # Check for alternative reasoning field names
                for attr in ['reasoning', 'reasoning_content', 'thought', 'thinking']:
                    val = getattr(delta, attr, None)
                    if val:
                        logger.info(f"[REASONING] Found {attr} ({len(val)} chars)")
            
            # Content chunk
            if delta.content:
                full_content += delta.content
                yield {"type": "content", "text": delta.content}
            
            # Tool call chunks
            if delta.tool_calls:
                for tc_delta in delta.tool_calls:
                    idx = tc_delta.index
                    if idx is None:
                        # No index (Gemini streams each parallel call whole): a new
                        # id is a new call, no id continues the last. Defaulting to
                        # 0 glued Paris+Rome into one call, '{..}{..}' → '{}'.
                        ids = [a["id"] for a in tool_calls_acc]
                        if tc_delta.id in ids:
                            idx = ids.index(tc_delta.id)
                        else:
                            idx = len(ids) if (tc_delta.id or not ids) else len(ids) - 1

                    # Expand list if needed
                    while len(tool_calls_acc) <= idx:
                        tool_calls_acc.append({
                            "id": "",
                            "name": "",
                            "arguments": ""
                        })

                    if tc_delta.id:
                        tool_calls_acc[idx]["id"] = tc_delta.id
                    if tc_delta.function and tc_delta.function.name:
                        tool_calls_acc[idx]["name"] = tc_delta.function.name
                    if tc_delta.function and tc_delta.function.arguments:
                        tool_calls_acc[idx]["arguments"] += tc_delta.function.arguments
                    extra = (getattr(tc_delta, 'model_extra', None) or {}).get('extra_content')
                    if isinstance(extra, dict):
                        tool_calls_acc[idx]["extra_content"] = extra

                    event = {
                        "type": "tool_call",
                        "index": idx,
                        "id": tool_calls_acc[idx]["id"],
                        "name": tool_calls_acc[idx]["name"],
                        "arguments": tool_calls_acc[idx]["arguments"]
                    }
                    if tool_calls_acc[idx].get("extra_content"):
                        event["extra_content"] = tool_calls_acc[idx]["extra_content"]
                    yield event

        # Build final response
        final_tool_calls = [
            ToolCall(id=tc["id"], name=tc["name"], arguments=tc["arguments"],
                     extra_content=tc.get("extra_content"))
            for tc in tool_calls_acc
            if tc["id"] and tc["name"]
        ]
        
        # If no visible content but we have thinking, use thinking as content
        # This handles providers that put the full response in reasoning_content
        # (e.g., DashScope Qwen3 thinking mode)
        content_is_reasoning = False
        if not full_content and full_thinking:
            logger.info(f"[REASONING] No content but have thinking ({len(full_thinking)} chars) — using as content")
            full_content = full_thinking
            content_is_reasoning = True

        final_response = LLMResponse(
            content=full_content if full_content else None,
            tool_calls=final_tool_calls,
            finish_reason=finish_reason,
            usage=usage,
            content_is_reasoning=content_is_reasoning,
        )

        done_event = {"type": "done", "response": final_response}
        if full_thinking:
            done_event["thinking"] = full_thinking
        yield done_event
    
    def _parse_response(self, response) -> LLMResponse:
        """Parse OpenAI response into normalized LLMResponse."""
        
        if not response.choices:
            raise ValueError("LLM returned empty response (no choices)")
        choice = response.choices[0]
        message = choice.message
        
        # Check for reasoning_content (Fireworks reasoning models)
        # Prepend as <think> tags to match streaming behavior
        reasoning = getattr(message, 'reasoning_content', None)
        content_is_reasoning = False
        if reasoning:
            logger.info(f"[REASONING] Non-stream response has reasoning_content ({len(reasoning)} chars)")
            content = message.content or ""
            if content:
                from core import think as _think
                message_content = _think.wrap(reasoning, content)
            else:
                # No visible content — use reasoning as the response
                # (some providers put everything in reasoning_content)
                message_content = reasoning
                content_is_reasoning = True
        else:
            message_content = message.content

        # Parse tool calls if present
        tool_calls = []
        if message.tool_calls:
            for tc in message.tool_calls:
                extra = (getattr(tc, 'model_extra', None) or {}).get('extra_content')
                tool_calls.append(ToolCall(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=tc.function.arguments,
                    extra_content=extra if isinstance(extra, dict) else None,
                ))
        
        # Parse usage if present
        usage = None
        if response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            }
            # Normalize cached tokens to the Anthropic convention (see streaming
            # path above) — prompt_tokens = non-cached, cache_read separate.
            cache_read = getattr(response.usage, 'prompt_tokens_details', None)
            if cache_read and hasattr(cache_read, 'cached_tokens'):
                cached = cache_read.cached_tokens or 0
                if cached > 0:
                    usage["cache_read_tokens"] = cached
                    usage["prompt_tokens"] = max(0, usage["prompt_tokens"] - cached)
            _ctd = getattr(response.usage, 'completion_tokens_details', None)
            _rt = getattr(_ctd, 'reasoning_tokens', None) if _ctd else None
            if _rt:
                usage["reasoning_tokens"] = int(_rt)

        return LLMResponse(
            content=message_content,
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason,
            usage=usage,
            thinking=reasoning,  # raw reasoning_content for DeepSeek round-trip
            content_is_reasoning=content_is_reasoning,
        )
