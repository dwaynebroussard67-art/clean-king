# llm_providers/__init__.py
"""
Provider registry — manages core providers, user instances, and plugin providers.

Three layers:
1. Core: Claude, OpenAI, Gemini — dedicated classes, custom behavior
2. Custom: User-created instances from templates (OpenAI/Anthropic/Responses compat)
3. Plugin: Plugin-registered custom provider classes

Usage:
    from core.chat.llm_providers import provider_registry
    provider = provider_registry.get_provider_by_key('claude')

    # Backward compat still works:
    from core.chat.llm_providers import get_provider_by_key
    provider = get_provider_by_key('claude', config.LLM_PROVIDERS)
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Any, Optional, List, Callable

from .base import BaseProvider, LLMResponse, ToolCall
from .openai_compat import OpenAICompatProvider
from .openai_responses import OpenAIResponsesProvider
from .claude import ClaudeProvider
from .gemini import GeminiProvider
from .anthropic_compat import AnthropicCompatProvider

logger = logging.getLogger(__name__)

# Default generation params for new instances. Penalties / top_k are NOT
# here on purpose (Krem 2026-08-23): blank = never sent. A 0.1 presence/
# frequency penalty used to ride silently into every custom provider.
# Temperature / top_p neither (Krem, hunt 20): blank = the server's own
# default. A baked 0.7 loops Gemini 3 (Google: keep its 1.0), overrode a
# local model's tuned samplers, and 400'd gateways that refuse them.
DEFAULT_GENERATION_PARAMS = {
    'max_tokens': 8192,
}
_SAMPLING = ('temperature', 'top_p', 'max_tokens')


from core.provider_registry import BaseProviderRegistry as _BaseRegistry


# Template keys accepted from UI/config → class key. 'responses' was what the
# "+ Add Provider" wizard, get_templates() and the legacy migration all used
# for a class registered as 'openai_responses' — every manual Responses
# provider 400'd at creation and a migrated one could never build (scouts
# S1/F5, 2026-09-20). Configs written with the old key resolve through here.
TEMPLATE_ALIASES = {'responses': 'openai_responses'}


class ProviderRegistry(_BaseRegistry):
    """
    LLM provider registry — extends shared base with multi-instance,
    presets, model discovery, generation params, and fallback order.
    """

    def __init__(self):
        super().__init__('llm', 'LLM_PROVIDERS')
        # Template classes: type_key -> provider class
        self._classes: Dict[str, type] = {
            'openai': OpenAICompatProvider,
            'openai_responses': OpenAIResponsesProvider,
            'claude': ClaudeProvider,
            'anthropic': AnthropicCompatProvider,
            'gemini': GeminiProvider,
        }

        # Core provider metadata (fixed, ships with Sapphire)
        self._core_providers: Dict[str, dict] = {
            'claude': {
                'display_name': 'Claude',
                'provider_class': 'claude',
                'required_fields': ['api_key', 'model'],
                'optional_fields': ['timeout'],
                # Dropdown = current lineup + still-served legacy (vendor pages
                # verified 2026-09-30: Sonnet 5.5 shipped 2026-09-28, Opus 5
                # and Sonnet 5 moved to legacy; no Haiku past 4.5).
                # A saved id that isn't listed renders as
                # "Other (custom)" and keeps working — dropping a row never
                # breaks an install.
                'model_options': {
                    'claude-fable-5-1': 'Fable 5.1',
                    'claude-opus-5-5': 'Opus 5.5',
                    'claude-sonnet-5-5': 'Sonnet 5.5',
                    'claude-haiku-4-5': 'Haiku 4.5',
                    'claude-opus-5': 'Opus 5 (legacy)',
                    'claude-sonnet-5': 'Sonnet 5 (legacy)',
                    'claude-fable-5': 'Fable 5 (legacy)',
                    'claude-opus-4-8': 'Opus 4.8 (legacy)',
                    'claude-sonnet-4-6': 'Sonnet 4.6 (legacy)',
                },
                'is_local': False,
                'default_timeout': 10.0,
                'api_key_env': 'ANTHROPIC_API_KEY',
            },
            'openai': {
                'display_name': 'OpenAI',
                'provider_class': 'openai',
                'required_fields': ['base_url', 'api_key', 'model'],
                'optional_fields': ['timeout', 'reasoning_effort'],
                'model_options': {
                    'gpt-6-astra': 'GPT-6 Astra (Flagship)',
                    'gpt-5.6-sol': 'GPT-5.6 Sol',
                    'gpt-5.6-terra': 'GPT-5.6 Terra (Balanced)',
                    'gpt-5.6-luna': 'GPT-5.6 Luna (Budget)',
                    'gpt-5.5': 'GPT-5.5',
                    'gpt-5.4': 'GPT-5.4',
                    'gpt-5.4-mini': 'GPT-5.4 Mini',
                    'gpt-4o': 'GPT-4o (Legacy)',
                },
                'is_local': False,
                'default_timeout': 10.0,
                'api_key_env': 'OPENAI_API_KEY',
                'supports_reasoning': True,
            },
            'gemini': {
                'display_name': 'Gemini',
                'provider_class': 'gemini',
                'required_fields': ['api_key', 'model'],
                'optional_fields': ['timeout', 'reasoning_effort'],
                # gemini-2.0-* were shut down 2026-06-01; the only 3.x Pro is
                # still preview-only.
                'model_options': {
                    'gemini-3.8-flash': 'Gemini 3.8 Flash',
                    'gemini-3.7-flash': 'Gemini 3.7 Flash',
                    'gemini-3.5-flash': 'Gemini 3.5 Flash',
                    'gemini-3.5-flash-lite': 'Gemini 3.5 Flash Lite',
                    'gemini-3.1-pro-preview': 'Gemini 3.1 Pro (Preview)',
                    'gemini-2.5-flash': 'Gemini 2.5 Flash (legacy)',
                    'gemini-2.5-pro': 'Gemini 2.5 Pro (legacy)',
                },
                'is_local': False,
                'default_timeout': 10.0,
                'api_key_env': 'GOOGLE_API_KEY',
                'supports_reasoning': True,
            },
        }

        # Plugin-registered classes: type_key -> {class, display_name, plugin_name, ...}
        self._plugin_classes: Dict[str, dict] = {}

        # Cached presets
        self._presets: Optional[dict] = None

    # =========================================================================
    # CLASS REGISTRATION (for plugins)
    # =========================================================================

    def register_plugin_provider(self, type_key: str, display_name: str,
                                  provider_class: type, plugin_name: str,
                                  required_fields: list = None,
                                  model_options: list = None):
        """Register a custom provider class from a plugin."""
        self._classes[type_key] = provider_class
        self._plugin_classes[type_key] = {
            'class': provider_class,
            'display_name': display_name,
            'plugin_name': plugin_name,
            # None = unset (use the compat default); an explicit [] means the
            # provider genuinely needs no inputs (a plugin brain like
            # claude-in-sapphire) — `or` would wrongly swallow that empty list.
            'required_fields': (['base_url', 'api_key', 'model']
                                if required_fields is None else required_fields),
            'model_options': model_options,
        }
        logger.info(f"Plugin provider registered: {type_key} ({display_name}) from {plugin_name}")

    def register_plugin(self, key: str, provider_class, display_name: str,
                        plugin_name: str, **metadata):
        """Manifest lane (plugin_loader capabilities.providers) — WIRED to the
        real template registry. The inherited base method wrote self._plugins,
        a dict the LLM path never reads: a plugin-declared LLM provider logged
        'registered' at INFO and then never appeared anywhere (negspace N12,
        2026-08-31). Delegate to register_plugin_provider so the class lands
        in _classes (instantiable) + _plugin_classes (attributed)."""
        if key in self._classes and key not in self._plugin_classes:
            logger.warning(f"[llm] Plugin '{plugin_name}' tried to register core "
                           f"template key '{key}' — skipping")
            return
        self.register_plugin_provider(
            type_key=key,
            display_name=display_name,
            provider_class=provider_class,
            plugin_name=plugin_name,
            required_fields=metadata.get('required_fields'),
            model_options=metadata.get('model_options'),
        )

    def unregister_plugin(self, plugin_name: str):
        """Unload lane (plugin_loader) — remove this plugin's template
        classes. The base method only popped the unread self._plugins dict
        (N12)."""
        self.unregister_plugin_providers(plugin_name)

    def unregister_plugin_providers(self, plugin_name: str):
        """Remove all provider classes from a plugin."""
        to_remove = [k for k, v in self._plugin_classes.items() if v['plugin_name'] == plugin_name]
        for key in to_remove:
            self._plugin_classes.pop(key, None)
            self._classes.pop(key, None)
            logger.info(f"Plugin provider unregistered: {key}")

    # =========================================================================
    # PROVIDER CREATION
    # =========================================================================

    def get_provider_by_key(self, provider_key: str,
                             providers_config: Dict[str, Dict[str, Any]] = None,
                             request_timeout: float = 240.0,
                             model_override: str = '') -> Optional[BaseProvider]:
        """
        Create provider instance by key.

        Checks core providers (LLM_PROVIDERS) and custom providers (LLM_CUSTOM_PROVIDERS).
        """
        if providers_config is None:
            providers_config = self._get_all_configs()

        if provider_key not in providers_config:
            logger.error(f"Unknown provider key: {provider_key}")
            return None

        config = providers_config[provider_key]
        if not isinstance(config, dict):
            logger.error(f"Provider '{provider_key}' config is not a dict ({type(config).__name__}); skipping")
            return None

        if not config.get('enabled', False):
            logger.debug(f"Provider '{provider_key}' is disabled")
            return None

        # Determine provider class — template (custom) or provider (core)
        provider_type = config.get('template') or config.get('provider', 'openai')
        provider_type = TEMPLATE_ALIASES.get(provider_type, provider_type)
        model = model_override or config.get('model', '')

        # Auto-select Responses API for OpenAI reasoning models — on OpenAI's
        # own endpoint only. A LiteLLM / Azure / corporate gateway that exposes
        # gpt-5.x/6 ids over chat.completions 404'd on `{base}/responses` every
        # turn (scout F6, 2026-09-20); such a gateway picks the explicit
        # "Responses API" template if it really speaks it.
        base = (config.get('base_url') or '').lower()
        openai_official = (not base) or ('api.openai.com' in base)
        if (provider_type == 'openai' and openai_official
                and OpenAIResponsesProvider.should_use_responses_api(model)):
            provider_type = 'openai_responses'
            logger.info(f"[AUTO-SELECT] Using Responses API for model '{model}'")

        if provider_type not in self._classes:
            logger.error(f"Unknown provider type: {provider_type}")
            return None

        provider_class = self._classes[provider_type]

        # Build config for provider init
        api_key = self.get_api_key(provider_key, config)

        # Resolve timeout: config -> core metadata -> preset -> 5.0
        default_timeout = self._core_providers.get(provider_key, {}).get('default_timeout', 5.0)
        if config.get('is_local'):
            default_timeout = 0.3

        llm_config = {
            'provider': provider_type,
            'base_url': config.get('base_url', ''),
            'api_key': api_key,
            'model': model,
            'timeout': config.get('timeout', default_timeout),
            'enabled': True,
            # Claude-specific (thinking_budget is anthropic_compat-only now —
            # the main ClaudeProvider uses adaptive thinking + reasoning_effort)
            'thinking_enabled': config.get('thinking_enabled'),
            'thinking_budget': config.get('thinking_budget'),
            'cache_enabled': config.get('cache_enabled', False),
            'cache_ttl': config.get('cache_ttl', '5m'),
            # Responses API / reasoning (Claude adaptive thinking defaults to
            # high — matches the API default and pre-adaptive thinking depth)
            'reasoning_effort': config.get('reasoning_effort', 'high' if provider_type == 'claude' else 'medium'),
            'reasoning_summary': config.get('reasoning_summary', 'auto'),
            # Config hints from presets
            'strip_penalties': config.get('strip_penalties', False),
            # Universal thinking-disable (per-provider, best-effort family dispatch)
            # + raw extra_body passthrough — read by openai_compat's
            # _inject_thinking_control. Replaces the old Qwen-only /no_think trick;
            # `disable_thinking_qwen` kept for back-compat migration. Opt-in.
            'disable_thinking': config.get('disable_thinking', False),
            'extra_body': config.get('extra_body'),
            # Per-request headers — same escape-hatch shape as extra_body; both
            # take {session} / {version} (BaseProvider.fill). 2026-09-25.
            'extra_headers': config.get('extra_headers'),
            'disable_thinking_qwen': config.get('disable_thinking_qwen', False),
            # Vision override — config-driven supports_images, read by
            # BaseProvider.supports_images (and openai_compat's heuristic chain).
            # None = fall through to provider default; True/False = force on/off.
            'supports_images': config.get('supports_images'),
        }

        try:
            provider = provider_class(llm_config, request_timeout)
            logger.info(f"Created provider '{provider_key}' [{provider_type}]")
            return provider
        except Exception as e:
            logger.error(f"Failed to create provider '{provider_key}': {e}")
            return None

    # =========================================================================
    # PROVIDER LISTING (for UI)
    # =========================================================================

    def get_all_providers(self, providers_config: Dict[str, Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Return merged list of all providers for UI rendering."""
        if providers_config is None:
            providers_config = self._get_all_configs()

        result = []
        for key, config in providers_config.items():
            is_core = key in self._core_providers
            metadata = self._core_providers.get(key, {})

            api_key = self.get_api_key(key, config)
            has_api_key = bool(api_key and api_key != 'not-needed')
            needs_api_key = 'api_key' in metadata.get('required_fields', config.get('required_fields', []))

            # Key source info
            try:
                from core.credentials_manager import credentials
                has_config_key = credentials.has_stored_api_key(key)
                has_env_key = credentials.has_env_api_key(key)
                env_var = credentials.get_env_var_name(key)
            except (ImportError, AttributeError):
                has_config_key = False
                has_env_key = bool(config.get('api_key_env') and os.environ.get(config.get('api_key_env', ''), '').strip())
                env_var = config.get('api_key_env', metadata.get('api_key_env', ''))

            result.append({
                'key': key,
                'display_name': config.get('display_name', metadata.get('display_name', key)),
                'enabled': config.get('enabled', False),
                'has_api_key': has_api_key or not needs_api_key,
                'is_local': config.get('is_local', metadata.get('is_local', False)),
                'is_core': is_core,
                'template': config.get('template', config.get('provider', '')),
                'model': config.get('model', ''),
                'model_options': metadata.get('model_options') if is_core else None,
                'suggested_models': config.get('suggested_models'),
                'has_config_key': has_config_key,
                'has_env_key': has_env_key,
                'env_var': env_var,
                'base_url': config.get('base_url', ''),
                'supports_reasoning': metadata.get('supports_reasoning', False),
                'generation_params': config.get('generation_params'),
                'supports_images': self._sees(key, providers_config),
            })

        return result

    def _sees(self, key: str, providers_config: Dict[str, Dict[str, Any]]) -> bool:
        """The vision verdict the UI shows (Images › describer picker): build the
        enabled provider and ask it — class default (claude, gemini), the 👁
        checkbox, or openai_compat's host/model heuristic. Disabled = False."""
        try:
            from core.chat.llm_providers.resolve import provider_sees
            provider = self.get_provider_by_key(key, providers_config)
            return bool(provider) and provider_sees(provider)
        except Exception:
            return False

    def get_core_keys(self) -> list:
        """Return list of core provider keys."""
        return list(self._core_providers.keys())

    def get_metadata(self, provider_key: str) -> Dict[str, Any]:
        """Get metadata for a specific provider (core only)."""
        return self._core_providers.get(provider_key, {})

    # =========================================================================
    # FALLBACK / AUTO MODE
    # =========================================================================

    def get_first_available_provider(self,
                                      providers_config: Dict[str, Dict[str, Any]],
                                      fallback_order: List[str],
                                      request_timeout: float = 240.0,
                                      exclude: Optional[List[str]] = None,
                                      force_privacy: bool = False,
                                      health_cache: Optional[dict] = None,
                                      health_ttl: float = 60.0,
                                      probe: bool = True,
                                      require_images: bool = False,
                                      trail: Optional[list] = None) -> Optional[tuple]:
        """Get first available provider following fallback order.

        probe=False returns the first candidate that constructs without a
        health round-trip (per-image lanes, dry runs). require_images skips
        candidates that can't see (the Discord vision auto scan, 2026-08-06:
        'auto' = first provider that SEES, not first that constructs).

        health_cache: {provider_key: trusted_until_epoch}. A pass is trusted for
        health_ttl seconds — the pinned path got this in 2026-07-15, the Auto
        path kept probing every candidate every turn (a BILLED call on Claude /
        anthropic-compat, plus a stall on a slow cloud box) (scout F7,
        2026-09-20). Fails are never cached: the next turn re-probes.

        trail: a list the caller hands in gets (key, why) for every candidate
        passed over, so Auto finding nothing (or picking the third choice)
        can say why in ONE line instead of a DEBUG trickle (2026-10-23)."""
        exclude = exclude or []
        trail = trail if trail is not None else []
        import time as _time

        for provider_key in fallback_order:
            if provider_key in exclude:
                continue

            if provider_key not in providers_config:
                trail.append((provider_key, 'not configured'))
                continue

            config = providers_config[provider_key]
            if not isinstance(config, dict):
                logger.warning(f"Provider '{provider_key}' config is not a dict; skipping in fallback")
                trail.append((provider_key, 'broken config'))
                continue

            if not config.get('enabled', False):
                trail.append((provider_key, 'off'))
                continue

            if not config.get('use_as_fallback', True):
                trail.append((provider_key, 'left out of Auto'))
                continue

            # Private chat (auto mode passes force_privacy from private_chat)
            if force_privacy:
                is_local = config.get('is_local', self._core_providers.get(provider_key, {}).get('is_local', False))
                if not is_local:
                    trail.append((provider_key, 'not local (private chat)'))
                    continue

            provider = self.get_provider_by_key(provider_key, providers_config, request_timeout)
            if not provider:
                trail.append((provider_key, "couldn't start (check its API key and URL)"))
                continue
            if require_images:
                from core.chat.llm_providers.resolve import provider_sees
                if not provider_sees(provider):
                    trail.append((provider_key, 'cannot see images'))
                    continue
            now = _time.time()
            if probe and not (health_cache is not None and now < health_cache.get(provider_key, 0)):
                try:
                    healthy = provider.health_check()
                except Exception as e:
                    healthy = False
                    provider.last_health_error = type(e).__name__
                if not healthy:
                    why = getattr(provider, 'last_health_error', '') or 'no answer'
                    trail.append((provider_key, f"not answering ({why}, {getattr(provider, 'health_check_timeout', '?')}s)"))
                    continue
                if health_cache is not None:
                    health_cache[provider_key] = now + health_ttl
            # Auto works harder than a pin: a provider with no model set asks
            # its server what it serves (unprobed lanes use only what is known).
            ensure = getattr(provider, 'ensure_model', None)      # a plugin's provider may not subclass BaseProvider
            if ensure and not ensure(fetch=probe):
                why = getattr(provider, 'no_model', '')
                trail.append((provider_key, why.split('.')[0] if isinstance(why, str) and why
                              else 'has no model set, and its server named none'))
                continue
            return (provider_key, provider)

        return None

    # =========================================================================
    # GENERATION PARAMS
    # =========================================================================

    def get_generation_params(self, provider_key: str, model: str,
                               providers_config: Dict[str, Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Get generation parameters for a provider instance.

        Layers, each over the last, key by key:
        1. Default params
        2. MODEL_GENERATION_PROFILES by model name, else its __fallback__
        3. Instance generation_params — only the keys it sets (a blanked
           field persists null and inherits). It used to REPLACE the
           profile whole, so a card's stock 4096 hid a model's tuned values.
           A custom card owns its penalties: the profile's never ride in
           under it (blank = never sent, Krem 2026-08-23 + 2026-10-26).
        """
        if providers_config is None:
            providers_config = self._get_all_configs()

        config = providers_config.get(provider_key, {})
        inst = {k: v for k, v in (config.get('generation_params') or {}).items() if v is not None}
        profile, named = {}, False
        try:
            import config as app_config
            profiles = getattr(app_config, 'MODEL_GENERATION_PROFILES', {}) or {}
            named = bool(model and model in profiles)
            profile = (profiles.get(model) if named else profiles.get('__fallback__')) or {}
        except ImportError:
            pass
        if not self.is_core_provider(provider_key):
            # A custom card takes a profile's sampling only when the profile
            # names its model; the catch-all's never rides in (hunt 20).
            profile = {k: v for k, v in profile.items()
                       if k in (_SAMPLING if named else DEFAULT_GENERATION_PARAMS)}
        return {**DEFAULT_GENERATION_PARAMS, **profile, **inst}

    # =========================================================================
    # API KEYS
    # =========================================================================

    def get_api_key(self, provider_key: str, config: Dict[str, Any] = None) -> str:
        """
        Get API key for any provider (core or custom).

        Priority:
        1. credentials_manager stored key (under provider_key)
        2. Environment variable (from config.api_key_env or core metadata)
        3. Explicit api_key in config (backward compat)
        4. 'not-needed' for local providers
        """
        # Explicit override — only the Test routes set it, so a key typed into
        # the edit form is what gets tested, not the stored one (scout F4,
        # 2026-09-20). Never persisted: the PUT pops api_key into credentials.
        override = (config or {}).get('api_key_override', '')
        if override and str(override).strip():
            return str(override).strip()

        # Stored credential
        try:
            from core.credentials_manager import credentials
            key = credentials.get_llm_api_key(provider_key)
            if key:
                return key
        except ImportError:
            pass

        # Env var — check config, then core metadata
        if config is None:
            config = self._get_all_configs().get(provider_key, {})
        env_var = config.get('api_key_env') or self._core_providers.get(provider_key, {}).get('api_key_env', '')
        if env_var:
            val = os.environ.get(env_var, '')
            if val and val.strip():
                logger.debug(f"Using API key from env var {env_var} for {provider_key}")
                return val

        # Backward compat: explicit config value
        explicit_key = config.get('api_key', '')
        if explicit_key and explicit_key.strip():
            return explicit_key

        # Local providers
        is_local = config.get('is_local', self._core_providers.get(provider_key, {}).get('is_local', False))
        if is_local:
            return 'not-needed'

        return ''

    # =========================================================================
    # PRESETS
    # =========================================================================

    def get_presets(self) -> dict:
        """Load curated presets from provider_presets.json."""
        if self._presets is None:
            presets_path = Path(__file__).parent.parent.parent / "provider_presets.json"
            try:
                self._presets = json.loads(presets_path.read_text(encoding='utf-8')).get('presets', {})
            except Exception as e:
                logger.warning(f"Could not load provider presets: {e}")
                self._presets = {}
        return self._presets

    @staticmethod
    def normalize_template(key: str) -> str:
        """Canonical class key for a template name (see TEMPLATE_ALIASES)."""
        return TEMPLATE_ALIASES.get(key, key)

    def get_templates(self) -> list:
        """Return available template types for '+ Add Provider' UI. Plugin
        templates carry is_plugin + their required_fields so the wizard knows
        which inputs to ask for (a plugin brain like claude-in-sapphire needs
        none — it talks to its own backend, not a base_url)."""
        templates = [
            {'key': 'openai', 'name': 'OpenAI Compatible'},
            {'key': 'anthropic', 'name': 'Anthropic Compatible'},
            {'key': 'openai_responses', 'name': 'Responses API'},
        ]
        for key, info in self._plugin_classes.items():
            templates.append({'key': key, 'name': info['display_name'],
                              'is_plugin': True,
                              'required_fields': info.get('required_fields') or []})
        return templates

    def template_required_fields(self, template: str) -> list:
        """Which inputs a template needs in the Add-Provider form. A plugin
        template declares its own; a core template implicitly needs a base URL."""
        info = self._plugin_classes.get(template)
        if info is not None:
            return info.get('required_fields') or []
        return ['base_url']

    # =========================================================================
    # MODEL DISCOVERY
    # =========================================================================

    def discover_models(self, provider_key: str,
                         providers_config: Dict[str, Dict[str, Any]] = None) -> Optional[list]:
        """
        Discover available models from a provider.

        For OpenAI-compat providers, hits /v1/models.
        Returns list of {"id": str, "name": str} or None.
        """
        provider = self.get_provider_by_key(provider_key, providers_config)
        if not provider:
            return None

        if hasattr(provider, 'list_models'):
            try:
                return provider.list_models()
            except Exception as e:
                logger.debug(f"Model discovery failed for {provider_key}: {e}")
                return None

        return None

    # =========================================================================
    # CONFIG HELPERS
    # =========================================================================

    def _get_all_configs(self) -> Dict[str, Dict[str, Any]]:
        """Merge core and custom provider configs from settings."""
        try:
            from core.settings_manager import settings
            core = settings.get('LLM_PROVIDERS', {})
            custom = settings.get('LLM_CUSTOM_PROVIDERS', {})
            return {**core, **custom}
        except ImportError:
            return {}

    def is_core_provider(self, key: str) -> bool:
        return key in self._core_providers


# Singleton
provider_registry = ProviderRegistry()


def set_active_model(system, provider_key: str) -> tuple:
    """Blessed in-process model switch: validate the provider, write the
    active chat's llm_primary, publish the settings event.

    Takes effect next turn — chat.py reads llm_primary per-message. Single
    entry point for any tool/plugin that switches models (meta switch_model,
    future cost-savers/rotators) so none of them hand-roll chat-settings
    writes.

    Returns (ok, message) — message is the display name on success.
    """
    providers = {p['key']: p for p in provider_registry.get_all_providers()}
    target = providers.get(provider_key)
    if not target:
        return False, f"Unknown provider '{provider_key}'"
    if not target.get('enabled'):
        return False, f"Provider '{provider_key}' is not enabled"
    sm = system.llm_chat.session_manager
    # ONE pin writer (2026-09-21): writes the pair (a switch to Claude never
    # keeps asking Anthropic for a Qwen model — S6), publishes with origin.
    if not sm.set_llm_pin(sm._effective_chat_name(), provider_key, '', origin=None):
        return False, "Failed to save chat settings"
    return True, target.get('display_name', provider_key)


# =============================================================================
# BACKWARD COMPATIBILITY EXPORTS
# =============================================================================
# These functions maintain the old API so chat.py, execution_context.py, etc.
# don't need immediate changes. They delegate to the registry.

# Legacy dicts — kept as properties that read from registry
PROVIDER_CLASSES = provider_registry._classes

def _build_legacy_metadata():
    """Build PROVIDER_METADATA from registry for backward compat."""
    meta = dict(provider_registry._core_providers)
    # Add custom providers from settings as metadata entries
    try:
        from core.settings_manager import settings
        custom = settings.get('LLM_CUSTOM_PROVIDERS', {})
        for key, config in custom.items():
            meta[key] = {
                'display_name': config.get('display_name', key),
                'provider_class': config.get('template', 'openai'),
                'required_fields': ['base_url', 'api_key', 'model'],
                'is_local': config.get('is_local', False),
                'default_timeout': config.get('timeout', 5.0),
                'api_key_env': config.get('api_key_env', ''),
                'model_options': None,
            }
    except ImportError:
        pass
    return meta

# Lazy property — rebuilt when accessed
class _MetadataProxy(dict):
    def __getitem__(self, key):
        return _build_legacy_metadata()[key]
    def get(self, key, default=None):
        return _build_legacy_metadata().get(key, default)
    def __contains__(self, key):
        return key in _build_legacy_metadata()
    def items(self):
        return _build_legacy_metadata().items()
    def keys(self):
        return _build_legacy_metadata().keys()
    def values(self):
        return _build_legacy_metadata().values()

PROVIDER_METADATA = _MetadataProxy()


def get_api_key(provider_config: Dict[str, Any], provider_key: str) -> str:
    """Legacy — delegates to registry."""
    return provider_registry.get_api_key(provider_key, provider_config)


def get_generation_params(provider_key: str, model: str,
                           providers_config: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Legacy — delegates to registry."""
    return provider_registry.get_generation_params(provider_key, model, providers_config)


def get_provider_by_key(provider_key: str,
                         providers_config: Dict[str, Dict[str, Any]],
                         request_timeout: float = 240.0,
                         model_override: str = '') -> Optional[BaseProvider]:
    """Legacy — delegates to registry."""
    return provider_registry.get_provider_by_key(provider_key, providers_config, request_timeout, model_override)


def get_first_available_provider(providers_config: Dict[str, Dict[str, Any]],
                                  fallback_order: List[str],
                                  request_timeout: float = 240.0,
                                  exclude: Optional[List[str]] = None,
                                  force_privacy: bool = False,
                                  health_cache: Optional[dict] = None,
                                  health_ttl: float = 60.0,
                                  probe: bool = True,
                                  require_images: bool = False,
                                  trail: Optional[list] = None) -> Optional[tuple]:
    """Legacy — delegates to registry."""
    return provider_registry.get_first_available_provider(
        providers_config, fallback_order, request_timeout, exclude, force_privacy,
        health_cache=health_cache, health_ttl=health_ttl, probe=probe,
        require_images=require_images, trail=trail)


def get_available_providers(providers_config: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Legacy — delegates to registry."""
    return provider_registry.get_all_providers(providers_config)


def get_provider_metadata(provider_key: str) -> Dict[str, Any]:
    """Legacy — delegates to registry."""
    return provider_registry.get_metadata(provider_key)


# Legacy functions that may still be used
def get_provider(llm_config: Dict[str, Any], request_timeout: float = 240.0) -> Optional[BaseProvider]:
    """Legacy — create provider directly from config dict."""
    if not llm_config.get('enabled', False):
        return None
    provider_type = llm_config.get('provider', 'openai')
    provider_class = provider_registry._classes.get(provider_type, OpenAICompatProvider)
    try:
        return provider_class(llm_config, request_timeout)
    except Exception as e:
        logger.error(f"Failed to create provider: {e}")
        return None


def get_provider_for_url(base_url: str) -> str:
    """Auto-detect provider type from URL."""
    url_lower = base_url.lower()
    if 'anthropic.com' in url_lower:
        return 'claude'
    elif 'generativelanguage.googleapis.com' in url_lower:
        return 'gemini'
    return 'openai'


__all__ = [
    'provider_registry',
    'ProviderRegistry',
    'get_provider_by_key',
    'get_first_available_provider',
    'get_available_providers',
    'get_provider_metadata',
    'get_api_key',
    'get_generation_params',
    'get_provider',
    'get_provider_for_url',
    'BaseProvider',
    'LLMResponse',
    'ToolCall',
    'OpenAICompatProvider',
    'OpenAIResponsesProvider',
    'ClaudeProvider',
    'GeminiProvider',
    'AnthropicCompatProvider',
    'PROVIDER_CLASSES',
    'PROVIDER_METADATA',
    'DEFAULT_GENERATION_PARAMS',
]
