# core/chat/function_manager.py

import json
import logging
import time
import os
import importlib
import threading
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path
import config
from core.toolsets import toolset_manager

logger = logging.getLogger(__name__)


# Per-context scope isolation — each thread/async-task gets its own values.
#
# Only CORE scopes (rag, private) are hardcoded at module load. Everything else —
# memory, goal, knowledge, people, email, bitcoin, gcal, telegram, discord — is
# registered dynamically by plugins via register_plugin_scope() at plugin-scan
# time. Memory/goal/knowledge/people come from the memory plugin's manifest
# (Phase 4). email/bitcoin/gcal/telegram/discord come from their respective
# plugin manifests (Phase 3).
#
# `rag` is not a user-settable dropdown — it's set programmatically per-chat via
# `scope_rag.set(f'__rag__:{chat_name}')` in chat.py. `private` is a boolean
# toggle, also not a plugin scope. Both stay hardcoded forever.
scope_rag:       ContextVar       = ContextVar('scope_rag',       default=None)
scope_private:   ContextVar[bool] = ContextVar('scope_private',   default=False)

# Save-time provenance context for tool executors ({chat, persona, model,
# channel} dict or None). Not a scope — setting=None keeps it out of
# apply_scopes, sidebar dropdowns, persona inheritance, continuity task
# fields, and the force-None closure. Registry membership is what buys it
# snapshot/restore, so it survives Starlette's per-yield context resets on
# the same rail scopes do. Consumers read it via set at chat setup →
# snapshot → restore in execute_function. First consumer: mindpalace metadata.
tool_context:    ContextVar       = ContextVar('tool_context',    default=None)
# The tool names THIS turn was given (execute_function's allowed_tools, set on
# every lane): get_self_info's tool list. The live palette is the operator's
# web chat, never a Discord / task / satellite turn's (hunt, 2026-10-28).
turn_tools:      ContextVar       = ContextVar('turn_tools',      default=None)

# Scope registry — single source of truth for all scope operations.
# Only rag + private at module load; everything else added by plugin_loader.
# 'setting' is the key in chat_settings dict (None = not user-settable via sidebar).
SCOPE_REGISTRY = {
    'rag':       {'var': scope_rag,       'default': None,      'setting': None},
    'private':   {'var': scope_private,   'default': False,     'setting': 'private_chat'},
    'tool_context': {'var': tool_context, 'default': None,      'setting': None},
}


# The twelve tool categories (Krem, 2026-10-08). A tool file names one with
# TOOL_CATEGORY = '...'; a tool overrides with its own top-level "category".
# Not listed here → the tool's plugin name (its own group, asked for by name:
# bitcoin, wordpress) or its module name. `meta_danger` is the label on the
# tools that change HER - prompt, voice, model, toolset, scene; the name is
# the warning. CATEGORY_SCOPE: the data scope a category's tools read or
# write; a lane that closed that scope (an agent with memory_scope none)
# sheds the whole category instead of carrying tools that answer "disabled".
CATEGORIES = ('web', 'memory', 'knowledge', 'people', 'goals', 'files', 'system',
              'devices', 'comms', 'media', 'meta_danger', 'agents')
CATEGORY_SCOPE = {'memory': 'memory', 'knowledge': 'knowledge', 'people': 'people', 'goals': 'goal'}


def set_tool_context(scopes: dict = None, **fields):
    """Set provenance fields for tool executors, dropping falsy values.
    When `scopes` (a snapshot dict from snapshot_scopes) is given, updates it
    in place — call sites snapshot scopes before provider selection resolves
    the model, so the snapshot needs patching after the fact."""
    ctx = {k: v for k, v in fields.items() if v} or None
    tool_context.set(ctx)
    if scopes is not None:
        scopes['tool_context'] = ctx
    return ctx


def __getattr__(name):
    """Backcompat shim for `from core.chat.function_manager import scope_email`
    style imports. Resolves `scope_<key>` attribute access against SCOPE_REGISTRY.

    IMPORTANT: This catches module attribute access from OUTSIDE the module. It
    does NOT catch in-module global name lookups (Python doesn't call module
    __getattr__ for global name resolution inside a function's own body). All
    legacy per-scope setter methods that did `scope_email.set(s)` as a global
    lookup were deleted in Phase 1c. Only `_check_privacy_allowed()` still does
    a direct global lookup on `scope_private`, which is a core scope that stays
    hardcoded as a real module-level name below.
    """
    if name.startswith('scope_'):
        key = name[6:]
        reg = SCOPE_REGISTRY.get(key)
        if reg:
            return reg['var']
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def register_plugin_scope(key: str, plugin_name: str = "", default='default'):
    """Register a scope ContextVar from a plugin manifest. Called by plugin_loader.

    Idempotent: if the key is already registered, logs a warning and returns the existing var.
    Validates that `key` is a proper identifier to prevent malformed registry entries.
    """
    if key in SCOPE_REGISTRY:
        logger.warning(f"Scope key '{key}' already registered, skipping duplicate from '{plugin_name}'")
        return SCOPE_REGISTRY[key]['var']
    if not key or not isinstance(key, str) or not key.isidentifier():
        logger.error(f"Invalid scope key '{key}' from '{plugin_name}' — must be a valid Python identifier")
        return None
    var = ContextVar(f'scope_{key}', default=default)
    SCOPE_REGISTRY[key] = {'var': var, 'default': default, 'setting': f'{key}_scope', 'plugin': plugin_name}
    logger.info(f"Registered scope '{key}' from plugin '{plugin_name}'")
    return var


def unregister_plugin_scope(key: str, plugin_name: str = None):
    """Remove a scope from the registry. Called by plugin_loader on unload so
    the next register_plugin_scope for the same key picks up manifest changes
    (different default, etc.) instead of hitting the idempotent early-return
    and silently keeping the stale registration.

    plugin_name: when given, unregister only if this plugin is the recorded
    OWNER. Shared keys (memory + mindpalace both declare 'memory'/'people')
    used to be stripped from the LIVE owner when the OTHER plugin was
    unloaded/removed (negspace N16, 2026-08-31)."""
    entry = SCOPE_REGISTRY.get(key)
    if not entry:
        return
    if plugin_name is not None and entry.get('plugin') != plugin_name:
        logger.info(f"Scope '{key}' owned by '{entry.get('plugin')}', "
                    f"not '{plugin_name}' — leaving registered")
        return
    SCOPE_REGISTRY.pop(key, None)
    logger.info(f"Unregistered scope '{key}'")


def apply_scopes_from_settings(fm, settings: dict):
    """Apply scope values from a chat_settings dict to ContextVars.
    Converts 'none' string to None (disabled). Used by chat.py, chat_streaming.py, api_fastapi.py.

    Uses list() snapshot over SCOPE_REGISTRY to protect against concurrent modification
    during plugin hot-reload (would otherwise raise RuntimeError: dict changed size during iteration).
    """
    # Build set of known scope setting keys for unknown-key detection (debug log)
    known_settings = set()
    for name, reg in list(SCOPE_REGISTRY.items()):
        key = reg.get('setting')
        if not key:
            continue
        known_settings.add(key)
        if key in settings:
            val = settings[key]
            # Bool settings (private_chat) — coerce to bool
            if reg['default'] is False or reg['default'] is True:
                val = val not in (False, 0, '', 'false', '0', 'no', 'off', None)
            # String 'none' means disabled
            elif isinstance(val, str) and val == 'none':
                val = None
            elif isinstance(val, str) and val == '':
                val = reg['default']
            reg['var'].set(val)

    # Debug: log settings keys that look like scopes but have no matching registry entry
    # (helps diagnose plugin load-order issues)
    for k in settings:
        if isinstance(k, str) and k.endswith('_scope') and k not in known_settings:
            logger.debug(f"apply_scopes_from_settings: key '{k}' has no matching scope in SCOPE_REGISTRY (plugin not loaded?)")


def reset_scopes():
    """Reset all scopes to defaults. Uses list() snapshot for hot-reload safety."""
    for reg in list(SCOPE_REGISTRY.values()):
        reg['var'].set(reg['default'])


def snapshot_all_scopes() -> dict:
    """Capture all ContextVar scopes as a plain dict. Uses list() snapshot."""
    return {name: reg['var'].get() for name, reg in list(SCOPE_REGISTRY.items())}


def restore_scopes(scopes: dict):
    """Restore scopes from a snapshot dict. Missing keys reset to default.
    Uses list() snapshot for hot-reload safety."""
    for name, reg in list(SCOPE_REGISTRY.items()):
        if name in scopes:
            reg['var'].set(scopes[name])
        else:
            reg['var'].set(reg['default'])


def scope_setting_keys() -> list:
    """Return all setting keys that map to scopes (for defaults/persona reset).
    Uses list() snapshot for hot-reload safety. Excludes private_chat (bool, not a dropdown)."""
    return [reg['setting'] for reg in list(SCOPE_REGISTRY.values())
            if reg.get('setting') and reg['setting'] != 'private_chat']


def scope_defaults_dict() -> dict:
    """Return a dict mapping scope setting keys to their default values.
    Used by get_system_defaults() and similar merge sites."""
    result = {}
    for name, reg in list(SCOPE_REGISTRY.items()):
        setting = reg.get('setting')
        if setting and setting != 'private_chat':
            result[setting] = reg['default'] if reg['default'] is not None else 'default'
    return result


def _coerce_num(val, target):
    """Coerce a string to int/number. Returns (value, ok). Non-strings pass
    through untouched (already numeric / not our problem). Never raises."""
    if not isinstance(val, str):
        return val, True
    try:
        f = float(val.strip())
    except (ValueError, TypeError):
        return val, False
    if target == "integer":
        return (int(f), True) if f.is_integer() else (val, False)
    return f, True


def _coerce_args(arguments, parameters):
    """Best-effort coerce LLM-supplied string args to their schema-declared
    types. Returns (arguments, error). `error` is an LLM-actionable message when
    a declared-typed arg is present but can't be coerced (e.g. "abc" for an
    integer), else None. Never raises.

    Only coerces TOWARD a declared non-string type — string params (zip codes,
    ids) are left untouched. Models, especially local ones (Qwen/GLM), routinely
    stringify numbers ("2", "1,2,3"); without this they reach the tool as str and
    crash on numeric comparisons."""
    props = (parameters or {}).get("properties", {})
    bad = []
    for key, val in list(arguments.items()):
        spec = props.get(key)
        if not isinstance(spec, dict):
            continue
        t = spec.get("type")
        if t in ("integer", "number"):
            new, ok = _coerce_num(val, t)
            if ok:
                arguments[key] = new
            elif isinstance(val, str):
                bad.append((key, t, val))
        elif t == "boolean" and isinstance(val, str):
            low = val.strip().lower()
            if low in ("true", "1", "yes"):
                arguments[key] = True
            elif low in ("false", "0", "no"):
                arguments[key] = False
        elif t == "array":
            item_t = (spec.get("items") or {}).get("type")
            # A string for a numeric array is a comma-list ("1,2,3"); splitting is
            # safe only because numeric elements never contain commas.
            seq = [s.strip() for s in val.split(",")] if isinstance(val, str) else val
            if isinstance(seq, list) and item_t in ("integer", "number"):
                coerced, failed = [], False
                for x in seq:
                    new, ok = _coerce_num(x, item_t)
                    if not ok:
                        failed = True
                        break
                    coerced.append(new)
                if failed:
                    bad.append((key, f"array of {item_t}", val))
                else:
                    arguments[key] = coerced
    if bad:
        parts = "; ".join(f"'{k}' expects {ty}, got {v!r}" for k, ty, v in bad)
        return arguments, (
            f"Error: invalid argument type(s) — {parts}. "
            f"Re-call the tool with the correct types."
        )
    return arguments, None


def _tool_load_error(plugin_name, error, hint):
    """A plugin's tool file that would not import: on the boot-toast lane
    (plugin_loader._load_errors, read by /api/init) as well as the bus. A bare
    publish at boot reached no tab, so the AI just lost the tools and the
    plugin still looked on (hunt 21)."""
    err = {"plugin": plugin_name, "error": error, "hint": hint}
    try:
        from core.plugin_loader import plugin_loader
        if not any(e.get("plugin") == plugin_name and e.get("error") == error for e in plugin_loader._load_errors):
            plugin_loader._load_errors.append(err)
    except Exception:
        pass
    try:
        from core.event_bus import publish, Events
        publish(Events.PLUGIN_LOAD_ERROR, err)
    except Exception:
        pass


class FunctionManager:
    
    def __init__(self):
        self._tools_lock = threading.Lock()
        self.tool_history_file = 'user/history/tools/chat_tool_history.json'
        self.tool_history = []
        self.system_instance = None
        self._load_tool_history()

        # Dynamically load all function modules from functions/
        self.function_modules = {}
        self.execution_map = {}
        self.all_possible_tools = []
        self._enabled_tools = []  # Internal storage (ability-filtered)
        self._mode_filters = {}   # module_name -> MODE_FILTER dict
        self._settings_gates = {}  # module_name -> {func_name: settings_key} (SETTINGS_GATED)
        self._network_functions = set()  # Function names that require network access
        self._is_local_map = {}  # function_name -> is_local value (True, False, or "endpoint")
        self._function_module_map = {}  # function_name -> module_name (for endpoint lookups)
        self._loop_warn_map = {}  # function_name -> (threshold:int, message:str) — loop guard
        # Tools with top-level 'hidden': true — excluded from 'all'/module/
        # custom selection and UI enumeration, but resolvable by NAME through
        # a saved toolset (that's how the librarian's system toolset reaches
        # its verbs). Never filter the named-toolset path against this set.
        self._hidden_tools = set()
        # Tool metadata (2026-10-08): function_name -> {category, writes, module,
        # plugin}. The first thing Sapphire has ever known about a tool beyond
        # its schema. `category` is one of CATEGORIES (a module's TOOL_CATEGORY,
        # a tool's own top-level "category"), else the plugin's name, else the
        # module's. A category resolves like a module name (an agent's
        # toolset 'web, memory'), carries the scope its tools need (a lane
        # whose scope is closed sheds them), and `writes` tells a reader from
        # a writer (a self agent's read-only memory). Lives BESIDE the schema,
        # like `hidden`/`network`: providers never see it.
        self._tool_meta = {}
        # Track what was REQUESTED, not reverse-engineered
        self.current_toolset_name = "none"
        # Set when update_enabled_functions() is called with a dangling toolset
        # name; consumed by API layer to surface a toast, then cleared.
        self.last_dangling_toolset = None
        
        self._load_function_modules()
        
        # Initialize with no tools - user/chat settings will override
        self.update_enabled_functions(['none'])

    def _load_function_modules(self):
        """Dynamically load all function modules from functions/ and user/functions/."""
        base_functions_dir = Path(__file__).parent.parent.parent / "functions"
        base_dir = Path(__file__).parent.parent.parent 

        user_functions = base_dir / "user/functions"
        if user_functions.exists() and any(user_functions.glob("*.py")):
            logger.warning("Deprecated: user/functions/ detected. Migrate to user/plugins/ format (use toolmaker).")

        search_paths = [
            base_functions_dir,
            user_functions,
        ]

        for search_dir in search_paths:
            if not search_dir.exists():
                continue
            
            for py_file in search_dir.glob("*.py"):
                if py_file.name.startswith("_"):
                    continue
                    
                module_name = py_file.stem
                
                try:
                    spec = importlib.util.spec_from_file_location(
                        f"sapphire.functions.{module_name}", 
                        py_file
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    if not getattr(module, 'ENABLED', True):
                        logger.info(f"Function module '{module_name}' is disabled")
                        continue
                    
                    available_functions = getattr(module, 'AVAILABLE_FUNCTIONS', None)
                    # Door-B: settings/library-aware schema. If the module exposes
                    # get_tools(), use it (dynamic description, e.g. the scene tool's
                    # live menu) and stash the callable so refresh can rebuild it.
                    get_tools_fn = getattr(module, 'get_tools', None)
                    if callable(get_tools_fn):
                        try:
                            tools = get_tools_fn() or []
                        except Exception as e:
                            logger.warning(f"Module '{module_name}' get_tools() failed, using TOOLS: {e}")
                            tools = getattr(module, 'TOOLS', [])
                    else:
                        get_tools_fn = None
                        tools = getattr(module, 'TOOLS', [])
                    executor = getattr(module, 'execute', None)
                    mode_filter = getattr(module, 'MODE_FILTER', None)
                    settings_gate = getattr(module, 'SETTINGS_GATED', None)
                    emoji = getattr(module, 'EMOJI', '')
                    group = getattr(module, 'GROUP', None)
                    category = getattr(module, 'TOOL_CATEGORY', None)
                    expires = getattr(module, 'TOOL_EXPIRES', None)

                    if not tools or not executor:
                        logger.warning(f"Module '{module_name}' missing TOOLS or execute()")
                        continue

                    if available_functions is not None:
                        tools = [t for t in tools if t['function']['name'] in available_functions]
                    self._record_tool_meta(tools, module_name, category, expires=expires)

                    self.function_modules[module_name] = {
                        'module': module,
                        'tools': tools,
                        'executor': executor,
                        'available_functions': available_functions if available_functions else [t['function']['name'] for t in tools],
                        'emoji': emoji,
                        'group': group,  # optional display-group (Toolsets UI merges)
                        'get_tools': get_tools_fn,  # settings/library-aware rebuilder, or None
                    }

                    # Register tool-declared settings
                    tool_settings = getattr(module, 'SETTINGS', None)
                    if tool_settings and isinstance(tool_settings, dict):
                        from core.settings_manager import settings as sm
                        tool_help = getattr(module, 'SETTINGS_HELP', None)
                        sm.register_tool_settings(module_name, tool_settings, tool_help)
                    
                    # Track network functions, is_local (per-tool flags)
                    for tool in tools:
                        func_name = tool['function']['name']
                        if tool.get('network', False):
                            self._network_functions.add(func_name)
                        if 'is_local' in tool:
                            self._is_local_map[func_name] = tool['is_local']
                        if tool.get('hidden', False):
                            self._hidden_tools.add(func_name)
                        lw = self._parse_loop_warn(tool)
                        if lw:
                            self._loop_warn_map[func_name] = lw
                        self._function_module_map[func_name] = module_name
                    
                    # Store mode filter if present
                    if mode_filter:
                        self._mode_filters[module_name] = mode_filter
                        logger.info(f"Module '{module_name}' has mode filtering: {list(mode_filter.keys())}")

                    if settings_gate:
                        self._settings_gates[module_name] = settings_gate
                        logger.info(f"Module '{module_name}' has settings-gated tools: {list(settings_gate.keys())}")
                    
                    # Dedup: warn and skip tools with names already registered
                    existing_names = {t['function']['name'] for t in self.all_possible_tools}
                    for tool in tools:
                        fname = tool['function']['name']
                        if fname in existing_names:
                            logger.warning(f"Duplicate tool name '{fname}' in module '{module_name}' — skipping (already registered by '{self._function_module_map.get(fname, '?')}')")
                        else:
                            self.all_possible_tools.append(tool)
                            existing_names.add(fname)

                    for tool in tools:
                        self.execution_map[tool['function']['name']] = executor
                    
                    logger.info(f"Loaded function module '{module_name}' with {len(tools)} tools")
                    
                except Exception as e:
                    logger.error(f"Failed to load function module '{module_name}': {e}")

    def register_plugin_tools(self, plugin_name: str, plugin_dir, tool_paths: list, expires=None):
        """Register tools from a plugin directory.

        Args:
            plugin_name: Plugin name for tracking
            plugin_dir: Path to plugin root directory
            tool_paths: List of relative paths to tool files (e.g., ["tools/ha.py"])
            expires: the manifest's `tool_expires`, the default for every tool
                here that declares none (a file's TOOL_EXPIRES comes first)

        Returns:
            None on success (including per-module non-fatal errors, which are
            logged and skipped as before). On a tool-NAME collision with an
            already-registered tool, returns a refusal dict {plugin, error,
            hint} — mutual exclusivity: the caller must unwind this plugin and
            not load it. First-loaded plugin wins.

        Phase 4 sys.modules idempotency: for each plugin tool file, we compute a
        canonical module name (e.g., ``plugins.memory.tools.memory_tools``). If
        that name is already in ``sys.modules``, we REUSE the existing module —
        this happens when something imports the module via normal Python import
        before plugin_loader runs (e.g., ``from plugins.memory.tools import
        memory_tools as mem`` in another file). Reusing prevents the "two module
        instances with split state" hazard that would otherwise split ``_db_lock``,
        ``_db_initialized``, ``_backfill_done``, and any other module-level state.

        If the module is NOT in sys.modules, we exec the file into a fresh
        namespace as before AND install it in sys.modules under the canonical
        name so subsequent regular-Python imports find the SAME module object.
        """
        import sys
        import types
        plugin_dir = Path(plugin_dir)

        for tool_rel_path in tool_paths:
            tool_path = plugin_dir / tool_rel_path
            try:
                tool_path.resolve().relative_to(plugin_dir.resolve())
            except ValueError:
                logger.error(f"Plugin '{plugin_name}' path traversal blocked: {tool_rel_path}")
                continue
            if not tool_path.exists():
                logger.warning(f"Plugin '{plugin_name}' tool not found: {tool_path}")
                continue

            module_name = f"plugin_{plugin_name}_{tool_path.stem}"

            # Canonical name matching Python's namespace package import path.
            # For plugin_dir="plugins/memory" and tool_rel_path="tools/memory_tools.py"
            # → canonical_name = "plugins.memory.tools.memory_tools"
            rel_path_obj = Path(tool_rel_path)
            parts = [plugin_dir.name] + list(rel_path_obj.with_suffix('').parts)
            canonical_name = "plugins." + ".".join(parts)

            try:
                # Phase 4 (v2): the sys.modules idempotency check + install must happen
                # INSIDE `_tools_lock` to close the race where a concurrent route handler
                # could do a lazy `from plugins.memory.tools import memory_tools` via
                # PEP 420 namespace package between our None-check and our install,
                # creating a shadow module with split `_db_lock` state. Acquiring the
                # lock before the check ensures exactly one module object wins.
                with self._tools_lock:
                    # sys.modules idempotency check — reuse if already imported
                    existing_mod = sys.modules.get(canonical_name)
                    if existing_mod is not None and hasattr(existing_mod, '__dict__'):
                        logger.debug(f"Plugin '{plugin_name}' tool '{canonical_name}' already in sys.modules — reusing")
                        namespace = existing_mod.__dict__
                    else:
                        source = tool_path.read_text(encoding="utf-8")
                        # Exec DIRECTLY into the module stub's __dict__. The old
                        # copy (`mod_stub.__dict__.update(namespace)`) left the
                        # exec'd functions closing over ONE dict while
                        # sys.modules held ANOTHER: external rebinds like
                        # `mem._backfill_done = False` (the embedding-swap
                        # re-arm) silently wrote the dead copy, so NULL vectors
                        # stayed invisible until restart (negspace N5,
                        # 2026-08-31). One dict = reads AND writes coherent.
                        mod_stub = types.ModuleType(canonical_name)
                        mod_stub.__file__ = str(tool_path)
                        namespace = mod_stub.__dict__
                        namespace["__file__"] = str(tool_path)
                        exec(compile(source, str(tool_path), "exec"), namespace)
                        # Install as a real module in sys.modules so future
                        # `from plugins.memory.tools import memory_tools` calls
                        # resolve to the SAME module object (no split state).
                        sys.modules[canonical_name] = mod_stub

                    if not namespace.get('ENABLED', True):
                        logger.info(f"Plugin tool '{module_name}' is disabled")
                        continue

                    # Settings-aware schema: if the module exposes get_tools(),
                    # use it so the tool schema (e.g. a dynamic description built
                    # from plugin settings) is correct from first load. The same
                    # callable is stored below so refresh_plugin_tools() can rebuild
                    # in place when settings change. Falls back to static TOOLS.
                    get_tools_fn = namespace.get('get_tools')
                    if callable(get_tools_fn):
                        try:
                            tools = get_tools_fn() or []
                        except Exception as e:
                            logger.warning(f"Plugin '{plugin_name}' get_tools() failed, using static TOOLS: {e}")
                            tools = namespace.get('TOOLS', [])
                    else:
                        get_tools_fn = None
                        tools = namespace.get('TOOLS', [])
                    executor = namespace.get('execute')

                    if not tools or not executor:
                        logger.warning(f"Plugin tool '{tool_path}' missing TOOLS or execute()")
                        continue

                    available_functions = namespace.get('AVAILABLE_FUNCTIONS')
                    if available_functions:
                        tools = [t for t in tools if t['function']['name'] in available_functions]

                    emoji = namespace.get('EMOJI', '')
                    group = namespace.get('GROUP')
                    mode_filter = namespace.get('MODE_FILTER')
                    settings_gate = namespace.get('SETTINGS_GATED')
                    category = namespace.get('TOOL_CATEGORY')
                    module_expires = namespace.get('TOOL_EXPIRES', expires)

                    # Check for function name conflicts BEFORE mutating state.
                    # A collision means mutual exclusivity by design (e.g. the
                    # memory and mindpalace plugins share tool names on purpose):
                    # refuse THIS plugin cleanly, first-loaded wins. Return the
                    # refusal so _load_plugin unwinds and reports it — before
                    # 2026-07-06 the ValueError raised here was swallowed by the
                    # generic except below and the plugin half-loaded with its
                    # tools silently missing.
                    existing_names = {t['function']['name'] for t in self.all_possible_tools}
                    for tool in tools:
                        fname = tool['function']['name']
                        if fname in existing_names:
                            owner_mod = self._function_module_map.get(fname, '')
                            owner = self.function_modules.get(owner_mod, {}).get('_plugin') or owner_mod or 'core'
                            logger.warning(
                                f"Plugin '{plugin_name}' tool '{fname}' is already provided by "
                                f"'{owner}' — refusing '{plugin_name}' (mutually exclusive)")
                            return {
                                "plugin": plugin_name,
                                "error": (f"Tool '{fname}' is already active from '{owner}'. "
                                          f"'{plugin_name}' and '{owner}' are mutually exclusive — "
                                          f"enable one, not both."),
                                "hint": f"Disable plugin '{owner}' to use '{plugin_name}'.",
                            }

                    self.function_modules[module_name] = {
                        'module': None,
                        'tools': tools,
                        'executor': executor,
                        'available_functions': available_functions or [t['function']['name'] for t in tools],
                        'emoji': emoji,
                        'group': group,  # optional display-group (Toolsets UI merges)
                        '_plugin': plugin_name,
                        'canonical': canonical_name,  # its sys.modules name, for shutdown()
                        'get_tools': get_tools_fn,  # settings-aware rebuilder, or None
                    }
                    self._record_tool_meta(tools, module_name, category, plugin_name, expires=module_expires)

                    # Track per-tool flags (safe — conflict check passed)
                    for tool in tools:
                        func_name = tool['function']['name']
                        if tool.get('network', False):
                            self._network_functions.add(func_name)
                        if 'is_local' in tool:
                            self._is_local_map[func_name] = tool['is_local']
                        if tool.get('hidden', False):
                            self._hidden_tools.add(func_name)
                        lw = self._parse_loop_warn(tool)
                        if lw:
                            self._loop_warn_map[func_name] = lw
                        self._function_module_map[func_name] = module_name

                    if mode_filter:
                        self._mode_filters[module_name] = mode_filter

                    if settings_gate:
                        self._settings_gates[module_name] = settings_gate

                    for tool in tools:
                        self.all_possible_tools.append(tool)
                        self.execution_map[tool['function']['name']] = executor

                    # If "all" toolset is active, add new tools to _enabled_tools too
                    # (hidden tools excluded — 'all' never includes them)
                    if self.current_toolset_name == "all":
                        enabled_names = {t['function']['name'] for t in self._enabled_tools}
                        for tool in tools:
                            fname = tool['function']['name']
                            if fname not in enabled_names and fname not in self._hidden_tools:
                                self._enabled_tools.append(tool)
                    # If a SAVED toolset is active and it references one of
                    # these new tools by name, auto-add it too. Without this,
                    # a freshly-loaded plugin's tools sit in all_possible_tools
                    # but not _enabled_tools — LLM never sees them, even though
                    # the active toolset definition says they should be on.
                    # 2026-05-16 fix.
                    elif self.current_toolset_name not in ("none", "custom") \
                            and toolset_manager.toolset_exists(self.current_toolset_name):
                        # Defensive: a user-hand-edited toolsets.json could have
                        # 'functions' set to null or a string. set() of either
                        # raises (TypeError) or silently iterates characters
                        # (string). Either case ends up in the broad except
                        # below, which swallows the error and leaves the plugin
                        # partially registered. Guard explicitly. 2026-05-16.
                        raw_funcs = toolset_manager.get_toolset_functions(self.current_toolset_name)
                        if isinstance(raw_funcs, list):
                            active_funcs = set(raw_funcs)
                            enabled_names = {t['function']['name'] for t in self._enabled_tools}
                            for tool in tools:
                                fname = tool['function']['name']
                                if fname in active_funcs and fname not in enabled_names:
                                    self._enabled_tools.append(tool)
                        else:
                            logger.warning(
                                f"Toolset '{self.current_toolset_name}' has malformed "
                                f"functions field ({type(raw_funcs).__name__}, expected list) "
                                f"— skipping auto-add for plugin '{plugin_name}'"
                            )

                logger.info(f"Plugin '{plugin_name}' tool '{module_name}': {len(tools)} tools registered")
                self._startup_tool_module(canonical_name, plugin_name)

            except ModuleNotFoundError as e:
                logger.error(f"Missing dependency for plugin tool '{tool_path}': {e}")
                _tool_load_error(plugin_name, f"Missing pip package: {e.name or e}",
                                 f"pip install {e.name}" if e.name else str(e))
            except Exception as e:
                logger.error(f"Failed to load plugin tool '{tool_path}': {e}", exc_info=True)
                _tool_load_error(plugin_name, f"Its tools in {tool_path} failed to load: {e}",
                                 "The plugin is on, but the AI can't use these tools until it's fixed")

    @staticmethod
    def _startup_tool_module(canonical, plugin_name):
        """A tool module that registers something with core (a contacts
        provider, an audit sink, a timer) does it in its optional
        module-level on_load(), which runs every time the loader registers
        the module: fresh, or REUSED from sys.modules. Registration at import
        time was the bug: a module imported while its plugin was off (a lazy
        import from a leftover thread) registered nothing, and the loader
        then reused that silent copy for the rest of the session (hunt of
        the hunt 2026-11-01, H2). The mirror of shutdown(). Never raises."""
        import sys
        fn = getattr(sys.modules.get(canonical or ''), 'on_load', None)
        if not callable(fn):
            return
        try:
            fn()
        except Exception as e:
            logger.warning(f"Plugin '{plugin_name}' tool module on_load() failed: {e}")

    @staticmethod
    def _shutdown_tool_module(canonical, plugin_name):
        """A tool module that holds something (an open port, a thread, a child
        process) lets go here, before it is dropped from sys.modules: its
        optional module-level shutdown(). Never raises into core."""
        import sys
        fn = getattr(sys.modules.get(canonical or ''), 'shutdown', None)
        if not callable(fn):
            return
        try:
            fn()
            logger.info(f"Plugin '{plugin_name}' tool module {canonical} shut down")
        except Exception as e:
            logger.warning(f"Plugin '{plugin_name}' tool module shutdown() failed: {e}")

    def shutdown_all_plugin_tools(self):
        """Sapphire is stopping: every plugin tool module lets go of what it holds."""
        with self._tools_lock:
            leaving = [(i.get('canonical'), i.get('_plugin')) for i in self.function_modules.values()
                       if i.get('_plugin') and i.get('canonical')]
        for canonical, plugin_name in leaving:
            self._shutdown_tool_module(canonical, plugin_name)

    def unregister_plugin_tools(self, plugin_name: str):
        """Remove all tools belonging to a plugin.

        Phase 4: also purges the canonical module names from sys.modules so a
        subsequent reload_plugin() can freshly re-exec the source file. Without
        this purge, the sys.modules idempotency fix in register_plugin_tools
        would reuse the stale module on reload and the edits would never take
        effect. Since unregister is always called as part of a reload cycle,
        it's safe (and necessary) to drop sys.modules entries here.

        Before any of that, each tool module's optional shutdown() runs (2026-10-18):
        a module whose globals hold an open MIDI port or a player thread would
        otherwise be orphaned by the purge, and on Windows an orphaned open
        port blocks the next open.
        """
        import sys
        with self._tools_lock:
            leaving = [info.get('canonical') for info in self.function_modules.values()
                       if info.get('_plugin') == plugin_name]
        for canonical in leaving:                # outside the lock: a shutdown may wait on a thread
            self._shutdown_tool_module(canonical, plugin_name)
        with self._tools_lock:
            to_remove = [name for name, info in self.function_modules.items()
                         if info.get('_plugin') == plugin_name]

            for module_name in to_remove:
                info = self.function_modules.pop(module_name, None)
                if not info:
                    continue

                func_names = set(info['available_functions'])

                for fname in func_names:
                    self.execution_map.pop(fname, None)
                    self._network_functions.discard(fname)
                    self._is_local_map.pop(fname, None)
                    self._loop_warn_map.pop(fname, None)
                    self._function_module_map.pop(fname, None)
                    self._hidden_tools.discard(fname)
                    self._meta().pop(fname, None)

                self.all_possible_tools = [t for t in self.all_possible_tools
                                           if t['function']['name'] not in func_names]
                self._enabled_tools = [t for t in self._enabled_tools
                                       if t['function']['name'] not in func_names]
                self._mode_filters.pop(module_name, None)
                self._settings_gates.pop(module_name, None)

            # Purge sys.modules entries for this plugin's canonical module names
            # so the next register_plugin_tools() call freshly re-execs the source.
            # Canonical names are of the form "plugins.<plugin_name>.tools.<stem>"
            # (or deeper paths depending on tool_rel_path). Match by prefix.
            prefix = f"plugins.{plugin_name}."
            stale = [k for k in list(sys.modules.keys()) if k.startswith(prefix)]
            for k in stale:
                sys.modules.pop(k, None)
            if stale:
                logger.debug(f"Plugin '{plugin_name}' sys.modules purged: {stale}")

        if to_remove:
            logger.info(f"Plugin '{plugin_name}' tools unregistered: {to_remove}")

    def refresh_plugin_tools(self, plugin_name: str) -> int:
        """Rebuild a plugin's tool SCHEMAS from its current settings, in place.

        For plugins whose tool module defines ``get_tools()`` (a settings-aware
        schema builder), re-invoke it and copy the fresh description/parameters
        onto the EXISTING tool dict objects. Because ``all_possible_tools`` and
        ``_enabled_tools`` hold the same dict references the LLM reads each turn,
        the update is seen on the next chat turn — no re-register, no module
        re-exec (so module-level state is preserved), and no toolset/membership
        change (tool NAMES are stable). Lets a plugin's tool description react to
        a settings save without a reload.

        No-op for plugins without ``get_tools()``. Only matching tool names are
        updated; adding/removing tools still requires a full reload.

        NOTE: this only refreshes description/parameters. The registration-time
        side-maps (``_loop_warn_map``, ``_network_functions``, ``_is_local_map``)
        are NOT re-read here — so a flag like ``loop_warn_after`` must stay static
        (not settings-derived) or it would go stale on a settings save until a full
        reload. Today all such flags are static, so this is safe.
        """
        updated = 0
        with self._tools_lock:
            for module_name, info in self.function_modules.items():
                if info.get('_plugin') != plugin_name:
                    continue
                get_tools_fn = info.get('get_tools')
                if not callable(get_tools_fn):
                    continue
                try:
                    fresh = get_tools_fn() or []
                except Exception as e:
                    logger.warning(f"refresh_plugin_tools: '{plugin_name}' get_tools() failed: {e}")
                    continue
                fresh_by_name = {t['function']['name']: t for t in fresh
                                 if isinstance(t, dict) and isinstance(t.get('function'), dict)
                                 and 'name' in t['function']}
                for tool in info['tools']:
                    new = fresh_by_name.get(tool['function']['name'])
                    if not new:
                        continue
                    # Update schema fields in place; never touch 'name' (membership
                    # and execution_map are keyed on it).
                    for key in ('description', 'parameters'):
                        if key in new['function']:
                            tool['function'][key] = new['function'][key]
                    updated += 1
        if updated:
            logger.info(f"Plugin '{plugin_name}' tool schemas refreshed ({updated} tool(s))")
        return updated

    # ── Loop guard (per-tool, per-turn) ──────────────────────────────────────
    # A tool schema may declare a top-level `loop_warn_after: N` (+ optional
    # `loop_warn_message`). When that tool is called >= N times in ONE user turn,
    # the chat loop appends the message to the tool-result text the LLM reads, to
    # discourage runaway repeat calls (e.g. image-gen spirals). The flag is read
    # into `_loop_warn_map` at registration and stripped from the wire by the
    # provider denylist (base.py), so it never reaches the LLM API.

    DEFAULT_LOOP_WARN_MESSAGE = (
        "You have now called this tool {count} times this turn, and each call has a "
        "real cost. If the results are not matching your intent, stop and reconsider - "
        "the request may be impossible to satisfy, or you may need to ask the user. "
        "Do not keep retrying the same thing."
    )

    @staticmethod
    def _parse_loop_warn(tool):
        """Read (threshold:int, message:str) from a tool dict, or None. Never raises.
        A malformed flag must NOT break registration (it would silently drop the
        whole module's tools), so all parsing is defensive."""
        try:
            raw = tool.get('loop_warn_after')
            if raw is None:
                return None
            threshold = int(raw)
            if threshold < 1:
                return None
            msg = tool.get('loop_warn_message')
            if not isinstance(msg, str) or not msg.strip():
                msg = FunctionManager.DEFAULT_LOOP_WARN_MESSAGE
            return (threshold, msg)
        except Exception:
            return None

    def bump_loop_count(self, loop_counts, function_name):
        """Increment the per-turn call count for function_name. Never raises.
        `loop_counts` is a per-turn dict owned by the caller's turn frame (NEVER
        stored on self — that would bleed across concurrent turns/chats)."""
        try:
            if loop_counts is not None:
                loop_counts[function_name] = loop_counts.get(function_name, 0) + 1
        except Exception:
            pass

    def loop_warn_suffix(self, function_name, loop_counts):
        """Return '\\n\\n<message>' if function_name hit its loop-warn threshold this
        turn, else ''. Never raises, never mutates. Uses str.replace (NOT .format) so
        literal braces in a (settings-derived) message can't crash the turn."""
        try:
            if loop_counts is None:
                return ""
            entry = self._loop_warn_map.get(function_name)
            if not entry:
                return ""
            threshold, message = entry
            n = loop_counts.get(function_name, 0)
            if n >= threshold:
                logger.info(f"[LOOP-WARN] '{function_name}' hit {n}/{threshold} call(s) this turn - warning appended to tool result")
                return "\n\n" + message.replace("{count}", str(n))
            return ""
        except Exception:
            return ""

    def refresh_core_tool_descriptions(self) -> int:
        """Re-run get_tools() for every loaded tool module that defines one (the
        scene tool's live menu, etc.) and copy the fresh description/parameters onto
        the EXISTING tool dicts in place — so a core tool's description can react to
        external state (a scene upload/delete) without a restart. Never raises."""
        updated = 0
        try:
            with self._tools_lock:
                for module_name, info in self.function_modules.items():
                    get_tools_fn = info.get('get_tools')
                    if not callable(get_tools_fn):
                        continue
                    try:
                        fresh = get_tools_fn() or []
                    except Exception as e:
                        logger.warning(f"refresh_core_tool_descriptions: '{module_name}' get_tools() failed: {e}")
                        continue
                    fresh_by_name = {t['function']['name']: t for t in fresh
                                     if isinstance(t, dict) and isinstance(t.get('function'), dict)
                                     and 'name' in t['function']}
                    for tool in info.get('tools', []):
                        new = fresh_by_name.get(tool['function']['name'])
                        if not new:
                            continue
                        for key in ('description', 'parameters'):
                            if key in new['function']:
                                tool['function'][key] = new['function'][key]
                        updated += 1
        except Exception as e:
            logger.warning(f"refresh_core_tool_descriptions failed: {e}")
        if updated:
            logger.info(f"Tool descriptions refreshed ({updated} tool(s))")
        return updated

    def register_dynamic_tools(self, module_name: str, tools: list, executor, plugin_name: str = '', emoji: str = ''):
        """Register tools from a dynamic source (MCP servers, runtime generators, etc.).

        Unlike register_plugin_tools which loads from Python files, this accepts
        pre-built tool definitions and an executor callable directly.

        Args:
            module_name: Unique module key (e.g. "mcp:filesystem")
            tools: List of tool dicts in OpenAI format [{type: "function", function: {name, description, parameters}}]
            executor: Callable(function_name, arguments, config) -> (result, success)
            plugin_name: Owner plugin for cleanup tracking (used by unregister_plugin_tools)
            emoji: Display emoji for toolset UI
        """
        available = [t['function']['name'] for t in tools]

        with self._tools_lock:
            # Check for conflicts
            existing_names = {t['function']['name'] for t in self.all_possible_tools}
            for tool in tools:
                fname = tool['function']['name']
                if fname in existing_names:
                    owner = self._function_module_map.get(fname, 'unknown')
                    logger.warning(f"Dynamic tool '{fname}' conflicts with '{owner}' — skipping")
                    tools = [t for t in tools if t['function']['name'] != fname]
                    available = [a for a in available if a != fname]

            if not tools:
                return

            self.function_modules[module_name] = {
                'module': None,
                'tools': tools,
                'executor': executor,
                'available_functions': available,
                'emoji': emoji,
                '_plugin': plugin_name,
            }
            self._record_tool_meta(tools, module_name, None, plugin_name)

            for tool in tools:
                fname = tool['function']['name']
                self.execution_map[fname] = executor
                self._function_module_map[fname] = module_name
                if tool.get('hidden', False):
                    self._hidden_tools.add(fname)
                lw = self._parse_loop_warn(tool)
                if lw:
                    self._loop_warn_map[fname] = lw
                self.all_possible_tools.append(tool)

            # If "all" toolset is active, add to enabled too (hidden excluded)
            if self.current_toolset_name == "all":
                enabled_names = {t['function']['name'] for t in self._enabled_tools}
                for tool in tools:
                    fname = tool['function']['name']
                    if fname not in enabled_names and fname not in self._hidden_tools:
                        self._enabled_tools.append(tool)
            # Same auto-add for saved toolsets that reference these tools
            # (mirrors register_plugin_tools fix). 2026-05-16.
            elif self.current_toolset_name not in ("none", "custom") \
                    and toolset_manager.toolset_exists(self.current_toolset_name):
                # See register_plugin_tools for the malformed-functions-field
                # rationale — defensive guard against corrupted user JSON.
                raw_funcs = toolset_manager.get_toolset_functions(self.current_toolset_name)
                if not isinstance(raw_funcs, list):
                    logger.warning(
                        f"Toolset '{self.current_toolset_name}' has malformed "
                        f"functions field ({type(raw_funcs).__name__}, expected list) "
                        f"— skipping dynamic auto-add for module '{module_name}'"
                    )
                    raw_funcs = []
                active_funcs = set(raw_funcs)
                enabled_names = {t['function']['name'] for t in self._enabled_tools}
                for tool in tools:
                    fname = tool['function']['name']
                    if fname in active_funcs and fname not in enabled_names:
                        self._enabled_tools.append(tool)

        logger.info(f"Dynamic tools registered: {module_name} ({len(tools)} tools)")

    def unregister_dynamic_tools(self, module_name: str):
        """Remove a dynamically registered tool module by name."""
        with self._tools_lock:
            info = self.function_modules.pop(module_name, None)
            if not info:
                return

            func_names = set(info['available_functions'])
            for fname in func_names:
                self.execution_map.pop(fname, None)
                self._function_module_map.pop(fname, None)
                self._loop_warn_map.pop(fname, None)
                self._hidden_tools.discard(fname)
                self._meta().pop(fname, None)

            self.all_possible_tools = [t for t in self.all_possible_tools
                                       if t['function']['name'] not in func_names]
            self._enabled_tools = [t for t in self._enabled_tools
                                   if t['function']['name'] not in func_names]

        logger.info(f"Dynamic tools unregistered: {module_name}")

    def _get_current_prompt_mode(self) -> str:
        """Get current prompt mode for filtering. Returns 'monolith' or 'assembled'."""
        try:
            from core.prompt_state import get_prompt_mode
            return get_prompt_mode()
        except ImportError:
            logger.warning("Could not import get_prompt_mode, defaulting to 'monolith'")
            return "monolith"

    def _apply_mode_filter(self, tools: list) -> list:
        """Filter tools based on current prompt mode."""
        if not self._mode_filters:
            return tools
        
        current_mode = self._get_current_prompt_mode()
        
        # Build set of allowed function names for current mode
        allowed_functions = set()
        for module_name, mode_filter in self._mode_filters.items():
            if current_mode in mode_filter:
                allowed_functions.update(mode_filter[current_mode])
        
        # Also include all functions from modules that don't have mode filtering
        modules_with_filters = set(self._mode_filters.keys())
        for module_name, module_info in self.function_modules.items():
            if module_name not in modules_with_filters:
                allowed_functions.update(module_info['available_functions'])
        
        # Filter tools
        filtered = []
        for tool in tools:
            func_name = tool['function']['name']
            # Check if this function is from a module with mode filtering
            has_mode_filter = any(
                func_name in mf.get(current_mode, []) or func_name in mf.get('monolith', []) + mf.get('assembled', [])
                for mf in self._mode_filters.values()
            )
            
            if has_mode_filter:
                # Only include if allowed for current mode
                if func_name in allowed_functions:
                    filtered.append(tool)
            else:
                # No mode filter for this function's module, include it
                filtered.append(tool)
        
        if len(filtered) != len(tools):
            logger.debug(f"Mode filter ({current_mode}): {len(tools)} -> {len(filtered)} tools")
        
        return filtered

    def _apply_settings_gate(self, tools: list) -> list:
        """Hide tools whose gating setting is off (module SETTINGS_GATED attr:
        {func_name: settings_key}). Gated tools are INVISIBLE when disabled,
        not just refused — a fresh install's AI never sees them, so it can't
        surprise a new user. Settings are hot keys, read per-request."""
        if not self._settings_gates:
            return tools
        blocked = set()
        for gates in self._settings_gates.values():
            for func_name, setting_key in gates.items():
                if not getattr(config, setting_key, False):
                    blocked.add(func_name)
        if not blocked:
            return tools
        return [t for t in tools if t['function']['name'] not in blocked]

    @property
    def enabled_tools(self) -> list:
        """Get enabled tools filtered by current prompt mode."""
        tools = self._apply_settings_gate(self._apply_mode_filter(self._enabled_tools))

        # Final dedup — Claude API requires unique tool names
        seen = set()
        deduped = []
        for tool in tools:
            name = tool['function']['name']
            if name not in seen:
                seen.add(name)
                deduped.append(tool)
            else:
                logger.warning(f"Duplicate tool '{name}' removed from enabled_tools")
        return deduped

    def snapshot_executors(self) -> dict:
        """Snapshot current execution_map — use to protect against reload during tool execution."""
        with self._tools_lock:
            return dict(self.execution_map)

    def update_enabled_functions(self, enabled_names: list, extra_toolsets: list = None):
        """Update enabled tools from a toolset/ability name, optionally
        unioning extra module/toolset function sets on top WITHOUT changing
        current_toolset_name — the "toolset + extras" primitive. Driven by
        the per-chat `extra_toolsets` settings list (first customer: the
        story engine's "include story tools" checkbox; 'none' + extras is
        the story default). Read-only mirrors (_resolve_toolset_tools,
        ExecutionContext._resolve_tools) implement the same union."""
        self._update_enabled_base(enabled_names)
        if extra_toolsets:
            self._union_extra_toolsets(extra_toolsets)

    def _union_extra_toolsets(self, extras: list):
        with self._tools_lock:
            have = {t['function']['name'] for t in self._enabled_tools}
            fn_set = self._extra_names(extras, have)
            if fn_set:
                self._enabled_tools.extend(
                    t for t in self.all_possible_tools
                    if t['function']['name'] in fn_set)

    # ── tool metadata: category, writes, scope ──────────────────────────────
    def _record_tool_meta(self, tools, module_name, category=None, plugin_name='', expires=None):
        meta = self.__dict__.setdefault('_tool_meta', {})    # fixtures build the manager bare
        for tool in tools:
            if not isinstance(tool, dict) or not isinstance(tool.get('function'), dict):
                continue
            name = tool['function'].get('name')
            if not name:
                continue
            cat = str(tool.get('category') or category or plugin_name or module_name)
            meta[name] = {'category': cat, 'writes': bool(tool.get('writes')),
                          'module': module_name, 'plugin': plugin_name or '',
                          'expires': self.parse_expires(tool['expires'] if 'expires' in tool else expires, name)}

    @staticmethod
    def parse_expires(raw, name=''):
        """A tool's `expires` (or its file's TOOL_EXPIRES, its plugin's
        `tool_expires`), as the budgeter reads it: {'after': 'never' |
        'superseded' | N user turns, 'group', 'hint'}, or None = undeclared
        (the global TOOL_EXPIRES_AFTER applies). Expiry only shortens what the
        MODEL is sent of an old result (core/chat/budget.py); the stored row
        and the transcript stay whole. Never raises: a malformed value is
        undeclared, logged."""
        if raw is None:
            return None
        try:
            spec = dict(raw) if isinstance(raw, dict) else {'after': raw}
            after = spec.get('after')
            if isinstance(after, str):
                after = after.strip().lower()
                if after.isdigit():
                    after = int(after)
            if after not in ('never', 'superseded') and not (isinstance(after, int) and not isinstance(after, bool) and after > 0):
                raise ValueError(f"after={spec.get('after')!r}")
            return {'after': after, 'group': str(spec.get('group') or name),
                    'hint': str(spec.get('hint') or '').strip()[:200]}
        except Exception as e:
            logger.warning(f"[TOOLS] '{name}': expires {raw!r} not understood ({e}) - treated as undeclared")
            return None

    def _meta(self):
        return getattr(self, '_tool_meta', None) or {}        # fixtures build the manager bare

    def tool_meta(self, name):
        return self._meta().get(name)

    def categories(self):
        """{category: [function names]} for every tool loaded, hidden ones out
        (a category resolves like a module: stale state never reaches it)."""
        out = {}
        for name, m in self._meta().items():
            if name not in self._hidden_tools:
                out.setdefault(m['category'], []).append(name)
        return out

    def tools_in_category(self, category, writes=None):
        """Function names of one category; writes=False → the readers only,
        True → the writers only (a self agent's read-only memory)."""
        return [n for n, m in self._meta().items()
                if m['category'] == category and n not in self._hidden_tools
                and (writes is None or m['writes'] is writes)]

    def _group_names(self, name):
        """A category or a plugin's name → its tool names, or None. The third
        thing a toolset word can be, after a module and a saved toolset."""
        if not isinstance(name, str) or not name:
            return None
        meta = self._meta()
        by_cat = [n for n, m in meta.items() if m['category'] == name and n not in self._hidden_tools]
        if by_cat:
            return by_cat
        by_plugin = [n for n, m in meta.items() if m['plugin'] and m['plugin'] == name
                     and n not in self._hidden_tools]
        return by_plugin or None

    def tool_scope(self, name):
        """The data scope `name` needs, or None: its category's (CATEGORY_SCOPE),
        else the ONE scope its plugin registered (an email tool needs email_scope),
        else nothing - a web tool works with every scope closed."""
        m = self._meta().get(name)
        if not m:
            return None
        if m['category'] in CATEGORY_SCOPE:
            key = CATEGORY_SCOPE[m['category']]
            if key in SCOPE_REGISTRY or not m['plugin']:
                return key
            # The category's scope is not registered: the palace keeps goals
            # and knowledge under its one memory scope, so a task that shut
            # memory sheds those tools too (migration hunt 2026-11-01, D3).
            if SCOPE_REGISTRY.get('memory', {}).get('plugin') == m['plugin']:
                return 'memory'
            return key
        if m['plugin']:
            own = [k for k, r in SCOPE_REGISTRY.items() if r.get('plugin') == m['plugin'] and r.get('setting')]
            if len(own) == 1:
                return own[0]
        return None

    def resolve_tool_names(self, enabled_names: list) -> tuple:
        """THE toolset name rule — pure, no state touched (broadsword H12).

        `enabled_names` is what a chat/task setting carries: ["all"], ["none"],
        [<module>], [<saved toolset>], [<category or plugin>], [<unknown>] or
        an ad-hoc function list.
        Returns (names, label, dangling):
          names    — function names the selection resolves to
          label    — what current_toolset_name would become
                     ("all"/"none"/module/toolset/"custom"; "none" for dangling)
          dangling — the unknown single name, else None
        Hidden tools (`_hidden_tools`: librarian ritual verbs, elevate_toolset)
        drop out of "all", a module, and an ad-hoc list; ONLY a saved toolset
        naming them resolves them — that is intent, the others are stale state.
        The live setter and every read-only lane (stream-brain chats, cron,
        Discord/Telegram/email auto-replies) share this; the two mirrors that
        skipped the hidden rule offered `run_librarian` to a phone call."""
        names = list(enabled_names or [])
        if len(names) == 1:
            one = names[0]
            if one == "all":
                return ([t['function']['name'] for t in self.all_possible_tools
                         if t['function']['name'] not in self._hidden_tools], "all", None)
            if one == "none":
                return ([], "none", None)
            if one in self.function_modules:
                return ([n for n in self.function_modules[one]['available_functions']
                         if n not in self._hidden_tools], one, None)
            if toolset_manager.toolset_exists(one):
                return (list(toolset_manager.get_toolset_functions(one)), one, None)
            group = self._group_names(one)          # a category, or a plugin by name (2026-10-08)
            if group is not None:
                return (group, one, None)
            # Single-name input that's NOT a known toolset / module → a dangling
            # reference (deleted toolset, plugin removed, stale chat settings).
            # "none" is safe-by-default; the caller surfaces the bad name.
            return ([], "none", one)
        return ([n for n in names if n not in self._hidden_tools], "custom", None)

    def _extra_names(self, extras: list, have: set) -> set:
        """Function names an `extra_toolsets` list unions on top (module or
        saved toolset each; unknown names skipped with a warning)."""
        out = set()
        for name in extras or []:
            try:
                if name in self.function_modules:
                    # same hidden rule as a module named as THE toolset
                    fn_names = [n for n in self.function_modules[name]['available_functions']
                                if n not in self._hidden_tools]
                elif toolset_manager.toolset_exists(name):
                    fn_names = toolset_manager.get_toolset_functions(name)
                elif self._group_names(name) is not None:
                    fn_names = self._group_names(name)
                else:
                    logger.warning(f"extra_toolsets: '{name}' is no known module/toolset/category — skipped")
                    continue
                out |= set(fn_names) - have - out
            except Exception as e:
                logger.warning(f"extra_toolsets '{name}' union failed: {e}")
        return out

    def resolve_tools(self, toolset_name, extra_toolsets=None, add_tools=None, drop_tools=None,
                      closed_scopes=None):
        """READ-ONLY tool schemas for a toolset setting + extras: the same
        names as the live setter would enable, then the mode filter and the
        settings gate. None when nothing resolves. Used by every lane that
        must not mutate the manager (stream-brain chats, ExecutionContext).
        add_tools / drop_tools: function NAMES taken off, then put on, before
        the filters - a lane's own rule about single tools. DROP FIRST: a lane
        that names a tool in both means "whatever the toolset said, THIS one
        is on" (a `self` agent drops every memory tool and adds the read set;
        add-then-drop erased the adds and the agent ran memory-less, 2026-10-08).
        closed_scopes: scope keys ('memory', 'email', ...) the lane has shut;
        a tool whose scope (tool_scope) is among them is shed - the lean agent
        carried nine tools that could only answer "scope disabled"."""
        if (not toolset_name or toolset_name == "none") and not extra_toolsets and not add_tools:
            return None
        names, _label, dangling = self.resolve_tool_names([toolset_name] if toolset_name else ["none"])
        if dangling:
            logger.warning(f"resolve_tools: toolset '{dangling}' does not exist — no tools")
        want = set(names)
        want |= self._extra_names(extra_toolsets, want)
        want -= set(drop_tools or ())
        want |= set(add_tools or ())
        if closed_scopes:
            shed = {n for n in want if self.tool_scope(n) in closed_scopes}
            if shed:
                logger.info(f"resolve_tools: {len(shed)} tool(s) shed, their scope is closed here: {sorted(shed)}")
                want -= shed
        tools = [t for t in self.all_possible_tools if t['function']['name'] in want]
        tools = self._apply_settings_gate(self._apply_mode_filter(tools))
        return tools or None

    def _update_enabled_base(self, enabled_names: list):
        """Update enabled tools based on function names from config or ability name."""
        with self._tools_lock:
            # "custom" is a sentinel for "ad-hoc selection", not a real
            # toolset name. Callers (plugin toggle/reload re-sync) often pass
            # back current_toolset_name without realizing this — and naively
            # filtering all_possible_tools against ["custom"] yields zero
            # matches, wiping _enabled_tools silently. Re-derive from the
            # current selection. 2026-05-16.
            if len(enabled_names) == 1 and enabled_names[0] == "custom":
                enabled_names = [t['function']['name'] for t in self._enabled_tools]
                if not enabled_names:
                    self.current_toolset_name = "custom"
                    self._enabled_tools = []
                    logger.info("Re-apply 'custom' with empty selection — no tools enabled")
                    return

            enabled_names, label, dangling = self.resolve_tool_names(enabled_names)
            self.current_toolset_name = label
            if dangling:
                # Record the bad name so the API layer can surface a toast;
                # the next chat demonstrates the failure (no tools) if the
                # user ignores it. Old behaviour silently fell through to
                # "custom" → zero tools with no signal. 2026-05-16.
                logger.warning(
                    f"Toolset/ability '{dangling}' does not exist (likely deleted or "
                    f"a stale chat setting). Falling back to 'none' — fix the "
                    f"chat's toolset setting to restore tool access."
                )
                self.last_dangling_toolset = dangling
                self._enabled_tools = []
                logger.info(f"Fallback applied: zero tools enabled (dangling reference: {dangling!r})")
                return
            if label == "none":
                self._enabled_tools = []
                logger.debug("Ability 'none' - all functions disabled")
                return

            # Store expected count before filtering
            expected_count = len(enabled_names)

            # Filter to only functions that actually exist
            self._enabled_tools = [
                tool for tool in self.all_possible_tools
                if tool['function']['name'] in enabled_names
            ]

            actual_names = [tool['function']['name'] for tool in self._enabled_tools]
            missing = set(enabled_names) - set(actual_names)

            if missing:
                # Not a failure — the toolset still loads minus the missing
                # functions. Most common cause: a plugin removed a tool or
                # a plugin is currently disabled. Logging at INFO so this
                # doesn't surface as a "Recent error" on the status page.
                logger.info(
                    f"Toolset '{self.current_toolset_name}' references "
                    f"{len(missing)} unavailable function(s) (likely a "
                    f"removed/disabled plugin tool): {missing}"
                )

            logger.debug(f"Toolset '{self.current_toolset_name}': {len(self._enabled_tools)}/{expected_count} functions loaded")
            logger.debug(f"Enabled: {actual_names}")

    def is_valid_toolset(self, ability_name: str) -> bool:
        """Check if a toolset name is valid (exists in toolsets, modules, or is special)."""
        if ability_name in ["all", "none"]:
            return True
        if ability_name in self.function_modules:
            return True
        if toolset_manager.toolset_exists(ability_name):
            return True
        return False
    
    def get_available_toolsets(self) -> list:
        """Get list of all available toolset names."""
        toolsets = ["all", "none"]
        toolsets.extend(list(self.function_modules.keys()))
        toolsets.extend(toolset_manager.get_toolset_names())
        return sorted(set(toolsets))

    def get_enabled_function_names(self):
        """Get list of currently enabled function names (mode-filtered)."""
        return [tool['function']['name'] for tool in self.enabled_tools]

    def _get_tool_parameters(self, function_name):
        """Return a tool's JSON-Schema `parameters` dict, or None if unavailable.
        Used by execute_function() to coerce arg types. Reads the internal
        (pre-mode-filter) list so the schema is found even when the executing
        tool isn't in the current mode-filtered view."""
        for tool in self._enabled_tools:
            fn = tool.get('function', {})
            if fn.get('name') == function_name:
                return fn.get('parameters')
        return None

    def has_network_tools_enabled(self) -> bool:
        """Check if any currently enabled tools require network access."""
        enabled_names = set(self.get_enabled_function_names())
        return bool(enabled_names & self._network_functions)

    def get_network_functions(self) -> list:
        """Get list of all functions that require network access."""
        return list(self._network_functions)

    def get_hidden_functions(self) -> set:
        """Names of tools flagged 'hidden': true — kept out of UI enumeration
        and 'all'/module/custom selection; saved toolsets resolve them by name."""
        return set(self._hidden_tools)

    def get_current_toolset_info(self):
        """Get info about current toolset configuration."""
        actual_count = len(self.enabled_tools)  # Uses property, so mode-filtered
        base_count = len(self._enabled_tools)   # Pre-mode-filter count
        expected_count = base_count
        
        if self.current_toolset_name == "all":
            expected_count = len([t for t in self.all_possible_tools
                                  if t['function']['name'] not in self._hidden_tools])
        elif self.current_toolset_name == "none":
            expected_count = 0
        elif self.current_toolset_name in self.function_modules:
            expected_count = len([n for n in self.function_modules[self.current_toolset_name]['available_functions']
                                  if n not in self._hidden_tools])
        elif toolset_manager.toolset_exists(self.current_toolset_name):
            expected_count = len(toolset_manager.get_toolset_functions(self.current_toolset_name))
        
        mode = self._get_current_prompt_mode()

        return {
            "name": self.current_toolset_name,
            "function_count": actual_count,
            "base_count": base_count,
            "expected_count": expected_count,
            "enabled_functions": self.get_enabled_function_names(),
            "prompt_mode": mode,
            "status": "ok" if base_count == expected_count else "partial",
        }

    # --- Scope methods (thin wrappers around registry functions) ---

    def set_scope(self, name: str, value):
        """Generic scope setter. Use for any registered scope."""
        SCOPE_REGISTRY[name]['var'].set(value)

    def get_scope(self, name: str):
        """Generic scope getter."""
        return SCOPE_REGISTRY[name]['var'].get()

    # rag and private are core scopes (not plugin-registered, not deleted in any phase)
    # Their wrappers stay as thin convenience methods. Per-scope setters for the 7 plugin-style
    # scopes (memory/goal/knowledge/people/email/bitcoin/gcal) were deleted in v7 — use the
    # generic set_scope('memory', val) / get_scope('memory') at lines 632-638 instead.
    def set_rag_scope(self, s): scope_rag.set(s)
    def set_private_chat(self, enabled): scope_private.set(bool(enabled))

    def snapshot_scopes(self) -> dict:
        """Capture current ContextVar scopes as a plain dict."""
        return snapshot_all_scopes()

    def apply_scopes(self, settings: dict):
        """Apply scopes from chat_settings dict."""
        apply_scopes_from_settings(self, settings)

    def _check_privacy_allowed(self, function_name: str) -> tuple:
        """
        Check if function is allowed in the current private chat.

        Returns:
            (allowed: bool, error_message: str or None)
        """
        if not scope_private.get():
            return True, None

        is_local = self._is_local_map.get(function_name)

        # Explicitly local tools are always allowed
        if is_local is True:
            return True, None

        # No flag = assume non-local for safety — unless the user opted in
        # (Settings > Privacy). The opt-out covers ONLY unflagged tools:
        # a tool that DECLARES is_local False/"endpoint" stays blocked, or
        # "private" stops meaning anything. ALLOW_UNSIGNED_PLUGINS pattern —
        # safe default, sovereign override (Krem's ruling 2026-08-15).
        if is_local is None:
            if getattr(config, 'PRIVATE_ALLOW_UNFLAGGED_TOOLS', False):
                return True, None
            logger.warning(f"Tool '{function_name}' has no is_local flag, blocking in private chat")
            return False, (f"Tool '{function_name}' is blocked in this private chat "
                           f"(no locality flag). If this plugin only talks to local "
                           f"hardware, Settings > Privacy can allow unflagged tools.")

        # False, "endpoint", or anything else — network access, blocked
        return False, f"Tool '{function_name}' requires network access and is blocked in this private chat. Inform the user."

    def tool_plugin(self, function_name: str):
        """The plugin that owns a tool, or None (a core tool, or unknown)."""
        info = self.function_modules.get(self._function_module_map.get(function_name) or '')
        return (info or {}).get('_plugin') or None

    def _get_plugin_settings_for(self, function_name: str):
        """Get plugin settings for a function, or None if it's not a plugin tool."""
        module_name = self._function_module_map.get(function_name)
        if not module_name:
            return None
        info = self.function_modules.get(module_name)
        if not info or '_plugin' not in info:
            return None
        try:
            from core.plugin_loader import plugin_loader
            return plugin_loader.get_plugin_settings(info['_plugin'])
        except Exception:
            return None

    def execute_function(self, function_name, arguments, scopes=None, allowed_tools=None, executor_snapshot=None,
                         with_success=False):
        """_execute_function with this turn's tool names in `turn_tools` for the
        call's duration (get_self_info reads them), reset after so they never
        outlive it into an unrelated call on the same thread."""
        token = turn_tools.set(frozenset(allowed_tools)) if allowed_tools else None
        try:
            return self._execute_function(function_name, arguments, scopes, allowed_tools,
                                          executor_snapshot, with_success)
        finally:
            if token is not None:
                turn_tools.reset(token)

    def _execute_function(self, function_name, arguments, scopes=None, allowed_tools=None, executor_snapshot=None,
                          with_success=False):
        """Execute a function using the mapped executor.

        scopes: optional dict to re-apply ContextVars before execution.
                 Needed because Starlette's iterate_in_threadpool creates
                 fresh context copies per generator yield.
        allowed_tools: optional set/list of function names that were sent to the LLM.
                       When provided, validates against this snapshot instead of
                       current enabled_tools (prevents race conditions on plugin reload).
        executor_snapshot: optional dict of {name: executor} captured at stream start.
                           Prevents reload from yanking executor mid-chat.
        with_success: when True, returns (result, success) instead of the bare
                      result - for a tool that runs another tool and must not
                      report a failure as a success (device drivers).
        """
        def _ret(value, ok):
            return (value, ok) if with_success else value

        if scopes:
            restore_scopes(scopes)

        start_time = time.time()

        # Validate function was available when sent to LLM (snapshot)
        # or is currently enabled (fallback)
        check_names = set(allowed_tools) if allowed_tools else self.get_enabled_function_names()
        if function_name not in check_names:
            logger.warning(f"Function '{function_name}' called but not enabled. Enabled: {check_names}")
            # Make the error LLM-actionable. The old terse message ("not currently
            # available") caused models to respond with empty content, which then
            # hit the canned "I have completed the requested actions" fallback —
            # appearing to the user as a silent conk-out. This message tells the
            # LLM exactly what to do next. 2026-05-16.
            sample_names = sorted(check_names)[:10] if check_names else []
            available_hint = (
                f" Tools available in current toolset: {sample_names}."
                if sample_names else " No tools are currently enabled."
            )
            result = (
                f"Error: '{function_name}' is not in the active toolset, so it cannot run.{available_hint} "
                f"Either call one of the available tools, or respond directly to the user without tools."
            )
            self._log_tool_call(function_name, arguments, result, time.time() - start_time, False)
            return _ret(result, False)

        # Privacy mode check
        allowed, error_msg = self._check_privacy_allowed(function_name)
        if not allowed:
            logger.info(f"Function '{function_name}' blocked by privacy mode: {error_msg}")
            self._log_tool_call(function_name, arguments, error_msg, time.time() - start_time, False)
            return _ret(error_msg, False)

        logger.info(f"Executing function: {function_name}")

        # Coerce arg types against the tool schema BEFORE the pre_execute hook,
        # so plugins and the executor both see typed args. Fixes the common
        # local-model failure where numbers arrive stringified ("2", "1,2,3").
        params = self._get_tool_parameters(function_name)
        if params and isinstance(arguments, dict):
            arguments, type_err = _coerce_args(arguments, params)
            if type_err:
                logger.warning(f"Arg type coercion failed for '{function_name}': {type_err}")
                self._log_tool_call(function_name, arguments, type_err, time.time() - start_time, False)
                return _ret(type_err, False)

        # pre_execute hook — plugins can mutate arguments or skip execution
        from core.hooks import hook_runner, HookEvent
        if hook_runner.has_handlers("pre_execute"):
            exec_event = HookEvent(
                function_name=function_name,
                arguments=dict(arguments) if arguments else {},
                config=config, metadata={"system": self.system_instance}
            )
            hook_runner.fire("pre_execute", exec_event)
            arguments = exec_event.arguments
            if exec_event.skip_llm:
                result = exec_event.result or "Execution skipped by plugin."
                self._log_tool_call(function_name, arguments, result, time.time() - start_time, True)
                return _ret(result, True)

        # Execute tool
        result = None
        success = False
        emap = executor_snapshot if executor_snapshot else self.execution_map
        executor = emap.get(function_name)
        if not executor:
            logger.error(f"No executor found for function '{function_name}'")
            result = f"The tool {function_name} is recognized but has no execution logic."
            self._log_tool_call(function_name, arguments, result, time.time() - start_time, False)
            return _ret(result, False)

        try:
            # For plugin tools, inject plugin settings (4th arg) + credentials (5th arg)
            plugin_settings = self._get_plugin_settings_for(function_name)
            if plugin_settings is not None:
                from core.credentials_manager import credentials
                import inspect
                try:
                    sig = inspect.signature(executor)
                    nparams = len(sig.parameters)
                except (ValueError, TypeError):
                    nparams = 5  # assume full signature
                if nparams >= 5:
                    raw = executor(function_name, arguments, config, plugin_settings, credentials)
                elif nparams >= 4:
                    raw = executor(function_name, arguments, config, plugin_settings)
                else:
                    raw = executor(function_name, arguments, config)
            else:
                raw = executor(function_name, arguments, config)
            # Plugin convention is (result, success) tuple, but user-made tools
            # (toolmaker output, third-party plugins) often return a bare value.
            # Don't crash with "cannot unpack non-iterable X" — that error string
            # used to flow straight to the LLM and make it think the tool failed
            # when it actually ran fine. Accept either shape. 2026-05-16.
            if isinstance(raw, tuple) and len(raw) == 2 and isinstance(raw[1], bool):
                result, success = raw
            else:
                result, success = raw, True
        except Exception as e:
            logger.error(f"Error executing function {function_name}: {e}")
            result = f"Error executing {function_name}: {str(e)}"
            success = False

        execution_time = time.time() - start_time
        if result is None:
            result = "(no output)"
        # widget markers survive only if core's builders made them: a marker
        # written in a web page or an email is the outside drawing in her chat
        from core.ui_markers import only_minted
        result = only_minted(result)

        self._log_tool_call(function_name, arguments, result, execution_time, success)

        # post_execute hook — plugins can observe results
        if hook_runner.has_handlers("post_execute"):
            hook_runner.fire("post_execute", HookEvent(
                function_name=function_name, arguments=arguments,
                result=result, config=config
            ))

        return _ret(result, success)

    def _load_tool_history(self):
        """Load tool history from disk. Disabled - legacy debug feature."""
        max_entries = getattr(config, 'TOOL_HISTORY_MAX_ENTRIES', 0)
        if max_entries == 0:
            self.tool_history = []
            return
        
        try:
            os.makedirs(os.path.dirname(self.tool_history_file), exist_ok=True)
            if os.path.exists(self.tool_history_file):
                with open(self.tool_history_file, 'r', encoding='utf-8') as f:
                    self.tool_history = json.load(f)
        except Exception as e:
            logger.error(f"Error loading tool history: {e}")
            self.tool_history = []

    def _save_tool_history(self):
        """Save tool history to disk. Disabled - legacy debug feature."""
        max_entries = getattr(config, 'TOOL_HISTORY_MAX_ENTRIES', 0)
        if max_entries == 0:
            return
        
        try:
            os.makedirs(os.path.dirname(self.tool_history_file), exist_ok=True)
            with open(self.tool_history_file, 'w', encoding='utf-8') as f:
                json.dump(self.tool_history, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving tool history: {e}")

    def _log_tool_call(self, function_name, arguments, result, execution_time, success):
        """Log tool call to history. Disabled - legacy debug feature."""
        max_entries = getattr(config, 'TOOL_HISTORY_MAX_ENTRIES', 0)
        if max_entries == 0:
            return
        
        tool_entry = {
            "timestamp": datetime.now().isoformat(),
            "function_name": function_name,
            "arguments": arguments,
            "result": str(result),
            "execution_time_ms": round(execution_time * 1000, 2),
            "success": success
        }
        self.tool_history.append(tool_entry)
        
        if len(self.tool_history) > max_entries:
            self.tool_history = self.tool_history[-max_entries:]
        
        self._save_tool_history()