-- Forge Load: shifts, live location, fleet checks, daily itineraries.
--
-- Earl's crew drive delivery trucks the owner has never been able to see.
-- This migration adds the four things he asked for:
--
--   1. QR clock-in.           sites + shifts
--   2. GPS while on shift.    location_pings (+ last-known position on shifts)
--   3. Morning truck check.   vehicles + vehicle_checks
--   4. Next-day orders.       itineraries + itinerary_acks
--
-- Everything is append-friendly: shifts close but are never deleted, pings
-- are insert-only, checks are insert-only, and an itinerary ack is the proof
-- the phone showed the order at clock-in.

CREATE TABLE "sites" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"address" text,
	"token" text NOT NULL,
	"latitude" double precision,
	"longitude" double precision,
	"radius_m" integer DEFAULT 250 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "sites_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "shifts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"client_uuid" text NOT NULL,
	"user_id" uuid NOT NULL,
	"site_id" uuid,
	"status" text DEFAULT 'active' NOT NULL,
	"method" text DEFAULT 'qr' NOT NULL,
	"clock_in_at" timestamp with time zone DEFAULT now() NOT NULL,
	"clock_in_lat" double precision,
	"clock_in_lng" double precision,
	"clock_in_accuracy_m" double precision,
	"clock_in_distance_m" double precision,
	"clock_in_device_id" text,
	"clock_out_at" timestamp with time zone,
	"clock_out_lat" double precision,
	"clock_out_lng" double precision,
	"clock_out_accuracy_m" double precision,
	"clock_out_by" uuid,
	"last_lat" double precision,
	"last_lng" double precision,
	"last_accuracy_m" double precision,
	"last_speed_mps" double precision,
	"last_ping_at" timestamp with time zone,
	"ping_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "shifts_client_uuid_unique" UNIQUE("client_uuid")
);
--> statement-breakpoint
CREATE TABLE "location_pings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"shift_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"latitude" double precision NOT NULL,
	"longitude" double precision NOT NULL,
	"accuracy_m" double precision,
	"speed_mps" double precision,
	"heading" double precision,
	"recorded_at" timestamp with time zone NOT NULL,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vehicles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"plate" text,
	"description" text,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "vehicle_checks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"client_uuid" text NOT NULL,
	"vehicle_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"shift_id" uuid,
	"check_date" text NOT NULL,
	"items" jsonb NOT NULL,
	"status" text NOT NULL,
	"odometer" integer,
	"fuel_level" text,
	"notes" text,
	"latitude" double precision,
	"longitude" double precision,
	"device_id" text,
	"device_time" timestamp with time zone,
	"checked_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "vehicle_checks_client_uuid_unique" UNIQUE("client_uuid")
);
--> statement-breakpoint
CREATE TABLE "itineraries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"for_date" text NOT NULL,
	"title" text NOT NULL,
	"body" text,
	"assignee_id" uuid,
	"priority" text DEFAULT 'normal' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_by" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "itinerary_acks" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"itinerary_id" uuid NOT NULL,
	"user_id" uuid NOT NULL,
	"shift_id" uuid,
	"delivered_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "itinerary_acks_once" UNIQUE("itinerary_id","user_id")
);
--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_site_id_sites_id_fk" FOREIGN KEY ("site_id") REFERENCES "public"."sites"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_clock_out_by_users_id_fk" FOREIGN KEY ("clock_out_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "location_pings" ADD CONSTRAINT "location_pings_shift_id_shifts_id_fk" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "location_pings" ADD CONSTRAINT "location_pings_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_vehicle_id_vehicles_id_fk" FOREIGN KEY ("vehicle_id") REFERENCES "public"."vehicles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_shift_id_shifts_id_fk" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "itineraries" ADD CONSTRAINT "itineraries_assignee_id_users_id_fk" FOREIGN KEY ("assignee_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "itineraries" ADD CONSTRAINT "itineraries_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "itinerary_acks" ADD CONSTRAINT "itinerary_acks_itinerary_id_itineraries_id_fk" FOREIGN KEY ("itinerary_id") REFERENCES "public"."itineraries"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "itinerary_acks" ADD CONSTRAINT "itinerary_acks_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "itinerary_acks" ADD CONSTRAINT "itinerary_acks_shift_id_shifts_id_fk" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_shifts_user" ON "shifts" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_shifts_status" ON "shifts" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_shifts_clock_in" ON "shifts" USING btree ("clock_in_at");--> statement-breakpoint
CREATE INDEX "idx_pings_shift_time" ON "location_pings" USING btree ("shift_id","recorded_at");--> statement-breakpoint
CREATE INDEX "idx_pings_user_time" ON "location_pings" USING btree ("user_id","recorded_at");--> statement-breakpoint
CREATE INDEX "idx_vchecks_vehicle_date" ON "vehicle_checks" USING btree ("vehicle_id","check_date");--> statement-breakpoint
CREATE INDEX "idx_vchecks_date" ON "vehicle_checks" USING btree ("check_date");--> statement-breakpoint
CREATE INDEX "idx_vchecks_user" ON "vehicle_checks" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "idx_itineraries_date" ON "itineraries" USING btree ("for_date");--> statement-breakpoint
CREATE INDEX "idx_itineraries_assignee" ON "itineraries" USING btree ("assignee_id");--> statement-breakpoint
CREATE INDEX "idx_acks_user" ON "itinerary_acks" USING btree ("user_id");--> statement-breakpoint

-- ── Guards the ORM can't express ─────────────────────────────────────────────

-- One open shift per person. Two phones scanning the same badge, or a retry
-- after a dropped connection, must not produce two running clocks. The
-- partial index makes the second INSERT fail with 23505, which the API turns
-- into "you're already clocked in" and returns the existing shift.
CREATE UNIQUE INDEX "shifts_one_active_per_user"
  ON "shifts" ("user_id") WHERE "status" = 'active';--> statement-breakpoint

ALTER TABLE "shifts" ADD CONSTRAINT "shifts_status_valid"
  CHECK ("status" IN ('active', 'closed'));--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_method_valid"
  CHECK ("method" IN ('qr', 'manual'));--> statement-breakpoint
-- A closed shift must say when it closed, and the clock can't run backwards.
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_closed_has_time"
  CHECK ("status" <> 'closed' OR "clock_out_at" IS NOT NULL);--> statement-breakpoint
ALTER TABLE "shifts" ADD CONSTRAINT "shifts_out_after_in"
  CHECK ("clock_out_at" IS NULL OR "clock_out_at" >= "clock_in_at");--> statement-breakpoint

ALTER TABLE "location_pings" ADD CONSTRAINT "pings_lat_range"
  CHECK ("latitude" >= -90 AND "latitude" <= 90);--> statement-breakpoint
ALTER TABLE "location_pings" ADD CONSTRAINT "pings_lng_range"
  CHECK ("longitude" >= -180 AND "longitude" <= 180);--> statement-breakpoint

ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_status_valid"
  CHECK ("status" IN ('ok', 'attention', 'needs_repair'));--> statement-breakpoint
ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_date_format"
  CHECK ("check_date" ~ '^\d{4}-\d{2}-\d{2}$');--> statement-breakpoint
ALTER TABLE "vehicle_checks" ADD CONSTRAINT "vehicle_checks_odometer_sane"
  CHECK ("odometer" IS NULL OR "odometer" >= 0);--> statement-breakpoint

ALTER TABLE "itineraries" ADD CONSTRAINT "itineraries_priority_valid"
  CHECK ("priority" IN ('normal', 'high'));--> statement-breakpoint
ALTER TABLE "itineraries" ADD CONSTRAINT "itineraries_date_format"
  CHECK ("for_date" ~ '^\d{4}-\d{2}-\d{2}$');--> statement-breakpoint

-- Site tokens are what the poster encodes; keep them scanner-friendly.
ALTER TABLE "sites" ADD CONSTRAINT "sites_token_format"
  CHECK ("token" ~ '^[A-Z0-9]{6,32}$');--> statement-breakpoint
ALTER TABLE "sites" ADD CONSTRAINT "sites_radius_sane"
  CHECK ("radius_m" > 0 AND "radius_m" <= 5000);
