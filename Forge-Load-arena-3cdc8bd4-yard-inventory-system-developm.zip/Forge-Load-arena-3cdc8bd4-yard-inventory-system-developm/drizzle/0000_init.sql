CREATE TABLE "bundles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" text NOT NULL,
	"product_id" uuid NOT NULL,
	"unit" text DEFAULT 'piece' NOT NULL,
	"qty_received" numeric NOT NULL,
	"qty_remaining" numeric NOT NULL,
	"location" text,
	"status" text DEFAULT 'active' NOT NULL,
	"receipt_id" uuid,
	"received_by" uuid,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "bundles_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "customers" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"ref" text,
	"phone" text,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "jobs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" text NOT NULL,
	"customer_id" uuid,
	"customer_name" text NOT NULL,
	"customer_ref" text,
	"status" text DEFAULT 'open' NOT NULL,
	"notes" text,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"closed_at" timestamp with time zone,
	CONSTRAINT "jobs_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "movements" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"client_uuid" text NOT NULL,
	"bundle_id" uuid NOT NULL,
	"product_id" uuid NOT NULL,
	"type" text NOT NULL,
	"qty_delta" numeric NOT NULL,
	"unit" text NOT NULL,
	"job_id" uuid,
	"employee_id" uuid NOT NULL,
	"device_id" text,
	"device_time" timestamp with time zone NOT NULL,
	"server_time" timestamp with time zone DEFAULT now() NOT NULL,
	"note" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "movements_client_uuid_unique" UNIQUE("client_uuid")
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"sku" text NOT NULL,
	"name" text NOT NULL,
	"category" text,
	"base_unit" text DEFAULT 'piece' NOT NULL,
	"pieces_per_bundle" numeric,
	"reorder_threshold" numeric,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "products_sku_unique" UNIQUE("sku")
);
--> statement-breakpoint
CREATE TABLE "receipt_lines" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"receipt_id" uuid NOT NULL,
	"product_id" uuid NOT NULL,
	"qty_per_bundle" numeric NOT NULL,
	"bundle_count" integer NOT NULL,
	"unit" text DEFAULT 'piece' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "receipts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" text NOT NULL,
	"supplier" text,
	"po_number" text,
	"notes" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "receipts_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"email" text NOT NULL,
	"password_hash" text NOT NULL,
	"full_name" text NOT NULL,
	"role" text DEFAULT 'crew' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "bundles" ADD CONSTRAINT "bundles_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bundles" ADD CONSTRAINT "bundles_receipt_id_receipts_id_fk" FOREIGN KEY ("receipt_id") REFERENCES "public"."receipts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "bundles" ADD CONSTRAINT "bundles_received_by_users_id_fk" FOREIGN KEY ("received_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "movements" ADD CONSTRAINT "movements_bundle_id_bundles_id_fk" FOREIGN KEY ("bundle_id") REFERENCES "public"."bundles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "movements" ADD CONSTRAINT "movements_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "movements" ADD CONSTRAINT "movements_job_id_jobs_id_fk" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "movements" ADD CONSTRAINT "movements_employee_id_users_id_fk" FOREIGN KEY ("employee_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipt_lines" ADD CONSTRAINT "receipt_lines_receipt_id_receipts_id_fk" FOREIGN KEY ("receipt_id") REFERENCES "public"."receipts"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipt_lines" ADD CONSTRAINT "receipt_lines_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "receipts" ADD CONSTRAINT "receipts_created_by_users_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_bundles_product" ON "bundles" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_bundles_status" ON "bundles" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_bundles_code" ON "bundles" USING btree ("code");--> statement-breakpoint
CREATE INDEX "idx_jobs_customer" ON "jobs" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX "idx_mov_bundle" ON "movements" USING btree ("bundle_id");--> statement-breakpoint
CREATE INDEX "idx_mov_job" ON "movements" USING btree ("job_id");--> statement-breakpoint
CREATE INDEX "idx_mov_employee" ON "movements" USING btree ("employee_id");--> statement-breakpoint
CREATE INDEX "idx_mov_server_time" ON "movements" USING btree ("server_time");--> statement-breakpoint
-- ── Code sequences ──────────────────────────────────────────────────────────
-- Back the human-readable codes in src/lib/codes.ts (BND-2026-000001 etc).
-- These live here rather than in application code so a fresh deploy is complete
-- after `db:migrate` alone; previously they were created as a side effect of a
-- public setup endpoint, and any deploy that never called it threw on the first
-- bundle, job, or receipt.
CREATE SEQUENCE IF NOT EXISTS "bundle_code_seq" START 1;--> statement-breakpoint
CREATE SEQUENCE IF NOT EXISTS "job_code_seq" START 1;--> statement-breakpoint
CREATE SEQUENCE IF NOT EXISTS "receipt_code_seq" START 1;--> statement-breakpoint

-- ── Data integrity guards ───────────────────────────────────────────────────
-- Enforced in the database as well as the API, so a bad client, a manual psql
-- session, or a future endpoint can't drive stock negative.
ALTER TABLE "bundles" ADD CONSTRAINT "bundles_qty_remaining_non_negative"
  CHECK ("qty_remaining" >= 0);--> statement-breakpoint
-- Note: deliberately NOT enforcing qty_remaining <= qty_received. A physical
-- recount can legitimately find more than the paperwork said was received, and
-- count_correction movements need to be able to record that.
ALTER TABLE "bundles" ADD CONSTRAINT "bundles_status_valid"
  CHECK ("status" IN ('active', 'retired', 'quarantined'));--> statement-breakpoint
ALTER TABLE "movements" ADD CONSTRAINT "movements_type_valid"
  CHECK ("type" IN ('receive', 'pull', 'return', 'adjust', 'count_correction'));--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_role_valid"
  CHECK ("role" IN ('admin', 'crew'));--> statement-breakpoint
ALTER TABLE "jobs" ADD CONSTRAINT "jobs_status_valid"
  CHECK ("status" IN ('open', 'closed', 'cancelled'));--> statement-breakpoint

-- Case-insensitive uniqueness for emails and SKUs. The plain UNIQUE constraint
-- still allowed Admin@yard.com alongside admin@yard.com, and the login path
-- lower-cases before lookup, so the second account was simply unreachable.
CREATE UNIQUE INDEX IF NOT EXISTS "users_email_lower_idx" ON "users" (LOWER("email"));--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "products_sku_upper_idx" ON "products" (UPPER("sku"));--> statement-breakpoint

-- Hot paths: the movement ledger for a bundle, and open-job lookups.
CREATE INDEX IF NOT EXISTS "idx_movements_bundle_time" ON "movements" ("bundle_id", "server_time" DESC);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_bundles_product_status" ON "bundles" ("product_id", "status");
