-- Proof of load-out.
--
-- The first pass only modelled delivery, but most product never gets delivered
-- --- it's loaded onto the customer's own truck in the yard and driven off. So
-- the dispute that actually happens is "you never loaded it", not "you never
-- delivered it", and the photo that refutes it is of their truck sitting in the
-- yard with the material on it.
--
-- 'load' is a separate subject from 'delivery' rather than a flag on it: the
-- two answer different accusations, are taken by different people at different
-- places, and a job can involve both (part picked up, rest delivered).

ALTER TABLE "photos" DROP CONSTRAINT IF EXISTS "photos_subject_type_valid";--> statement-breakpoint

ALTER TABLE "photos" ADD CONSTRAINT "photos_subject_type_valid"
  CHECK ("subject_type" IN ('product', 'bundle', 'damage', 'delivery', 'load'));
