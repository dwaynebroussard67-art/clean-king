CREATE TABLE "damage_reports" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"code" text NOT NULL,
	"bundle_id" uuid,
	"product_id" uuid,
	"subject" text DEFAULT 'material' NOT NULL,
	"qty_affected" numeric,
	"unit" text,
	"reason" text NOT NULL,
	"severity" text DEFAULT 'minor' NOT NULL,
	"stage" text,
	"location" text,
	"latitude" double precision,
	"longitude" double precision,
	"job_id" uuid,
	"customer_id" uuid,
	"movement_id" uuid,
	"write_off" boolean DEFAULT false NOT NULL,
	"notes" text,
	"status" text DEFAULT 'open' NOT NULL,
	"reported_by" uuid NOT NULL,
	"device_id" text,
	"device_time" timestamp with time zone,
	"reviewed_by" uuid,
	"reviewed_at" timestamp with time zone,
	"client_uuid" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "damage_reports_code_unique" UNIQUE("code"),
	CONSTRAINT "damage_reports_client_uuid_unique" UNIQUE("client_uuid")
);
--> statement-breakpoint
CREATE TABLE "photos" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"subject_type" text NOT NULL,
	"subject_id" uuid,
	"data" "bytea" NOT NULL,
	"content_type" text DEFAULT 'image/jpeg' NOT NULL,
	"byte_size" integer NOT NULL,
	"width" integer,
	"height" integer,
	"taken_by" uuid,
	"device_id" text,
	"device_time" timestamp with time zone,
	"latitude" double precision,
	"longitude" double precision,
	"accuracy_m" double precision,
	"caption" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "primary_photo_id" uuid;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_bundle_id_bundles_id_fk" FOREIGN KEY ("bundle_id") REFERENCES "public"."bundles"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_product_id_products_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."products"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_job_id_jobs_id_fk" FOREIGN KEY ("job_id") REFERENCES "public"."jobs"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_customer_id_customers_id_fk" FOREIGN KEY ("customer_id") REFERENCES "public"."customers"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_movement_id_movements_id_fk" FOREIGN KEY ("movement_id") REFERENCES "public"."movements"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_reported_by_users_id_fk" FOREIGN KEY ("reported_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_reports_reviewed_by_users_id_fk" FOREIGN KEY ("reviewed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "photos" ADD CONSTRAINT "photos_taken_by_users_id_fk" FOREIGN KEY ("taken_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_damage_bundle" ON "damage_reports" USING btree ("bundle_id");--> statement-breakpoint
CREATE INDEX "idx_damage_product" ON "damage_reports" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "idx_damage_status" ON "damage_reports" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_damage_created" ON "damage_reports" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_photos_subject" ON "photos" USING btree ("subject_type","subject_id");--> statement-breakpoint
CREATE INDEX "idx_photos_created" ON "photos" USING btree ("created_at");--> statement-breakpoint
-- Damage report codes (DMG-2026-0001), same pattern as bundles/jobs/receipts.
CREATE SEQUENCE IF NOT EXISTS "damage_code_seq" START 1;--> statement-breakpoint

-- Valid value guards, enforced in the database as well as the API.
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_severity_valid"
  CHECK ("severity" IN ('minor', 'major', 'total'));--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_status_valid"
  CHECK ("status" IN ('open', 'reviewed', 'resolved', 'written_off'));--> statement-breakpoint
ALTER TABLE "damage_reports" ADD CONSTRAINT "damage_subject_valid"
  CHECK ("subject" IN ('material', 'property', 'equipment', 'vehicle'));--> statement-breakpoint
ALTER TABLE "photos" ADD CONSTRAINT "photos_subject_type_valid"
  CHECK ("subject_type" IN ('product', 'bundle', 'damage', 'delivery'));--> statement-breakpoint

-- Reject empty or absurd uploads outright.
ALTER TABLE "photos" ADD CONSTRAINT "photos_byte_size_sane"
  CHECK ("byte_size" > 0 AND "byte_size" <= 12582912);
