/**
 * Service worker.
 *
 * The yard has dead spots. Before this existed, the IndexedDB movement queue
 * only survived as long as the tab stayed alive — a crew member who reloaded,
 * or whose phone locked and evicted the tab, got a blank screen and couldn't
 * reach their own pending movements until they found signal again.
 *
 * Strategy:
 *   - App shell (HTML/JS/CSS): stale-while-revalidate, so the app always opens.
 *   - GET /api/*: network-first with a cache fallback, so recently viewed data
 *     is readable offline and clearly marked as cached.
 *   - Mutations (POST/PATCH/DELETE): never cached, never intercepted. Those go
 *     through the IndexedDB queue in the app, which owns idempotency.
 */

// Bumped to v4: icons are generated per tenant at /icon, so the old static
// PNG paths no longer exist. A stale precache list is not a soft failure —
// addAll() rejects as a unit, so one 404 would abort the whole install and
// leave the app with no offline shell at all.
const VERSION = "v6";
const SHELL_CACHE = `yard-shell-${VERSION}`;
const DATA_CACHE = `yard-data-${VERSION}`;

// Routes worth having available cold. Next.js fingerprints its own assets, so
// we let those populate lazily rather than trying to enumerate them here.
const SHELL_URLS = [
  "/",
  "/clock-in",
  "/truck-check",
  "/scan",
  "/jobs",
  "/queue",
  "/offline",
  "/manifest.webmanifest",
  "/icon",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      // addAll is atomic — one 404 would throw away the whole install, and a
      // half-cached shell is worse than none. Take what we can get.
      await Promise.allSettled(SHELL_URLS.map((url) => cache.add(url)));
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((key) => key !== SHELL_CACHE && key !== DATA_CACHE)
          .map((key) => caches.delete(key))
      );
      await self.clients.claim();
    })()
  );
});

/** Let the page tell a waiting worker to take over immediately. */
self.addEventListener("message", (event) => {
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

function isApiRequest(url) {
  return url.pathname.startsWith("/api/");
}

/** Never serve a stale session or a stale AI answer. */
function isUncacheableApi(url) {
  return (
    url.pathname.startsWith("/api/auth/") ||
    url.pathname.startsWith("/api/assistant") ||
    url.pathname.startsWith("/api/extract-inventory")
  );
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle same-origin GETs. Mutations must reach the network or fail
  // loudly so the app can queue them itself.
  if (request.method !== "GET" || url.origin !== self.location.origin) return;

  if (isApiRequest(url)) {
    if (isUncacheableApi(url)) return;
    event.respondWith(networkFirst(request));
    return;
  }

  // Navigations: serve the app shell so a reload offline still boots.
  if (request.mode === "navigate") {
    event.respondWith(navigationHandler(request));
    return;
  }

  event.respondWith(staleWhileRevalidate(request, event));
});

async function networkFirst(request) {
  const cache = await caches.open(DATA_CACHE);
  try {
    const response = await fetch(request);
    if (response.ok) cache.put(request, response.clone());
    return response;
  } catch {
    const cached = await cache.match(request);
    if (cached) {
      // Flag it so the UI can show "showing last known data".
      const headers = new Headers(cached.headers);
      headers.set("X-Forge-From-Cache", "1");
      return new Response(cached.body, {
        status: cached.status,
        statusText: cached.statusText,
        headers,
      });
    }
    return new Response(
      JSON.stringify({ error: "offline", offline: true }),
      { status: 503, headers: { "Content-Type": "application/json" } }
    );
  }
}

async function navigationHandler(request) {
  try {
    const response = await fetch(request);
    if (response.ok) {
      const cache = await caches.open(SHELL_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    const cache = await caches.open(SHELL_CACHE);
    return (
      (await cache.match(request)) ||
      (await cache.match("/")) ||
      (await cache.match("/queue",
  "/offline")) ||
      new Response("Offline", { status: 503, headers: { "Content-Type": "text/plain" } })
    );
  }
}

async function staleWhileRevalidate(request, event) {
  const cache = await caches.open(SHELL_CACHE);
  const cached = await cache.match(request);

  const network = fetch(request)
    .then((response) => {
      if (response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => null);

  if (cached) {
    // Serve the cached copy immediately, but keep the worker alive long enough
    // to finish refreshing it in the background.
    event.waitUntil(network);
    return cached;
  }

  const response = await network;
  return response || new Response("", { status: 504 });
}
