#!/usr/bin/env python3
"""Build the Earl's Furniture user's manual as a print-ready PDF."""

from pathlib import Path

from fpdf import FPDF
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

HERE = Path(__file__).resolve().parent
IMG = HERE / "images"
OUT = HERE / "Earls-Furniture-Users-Manual.pdf"
FONT_SERIF = "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
FONT_SERIF_B = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
FONT_SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_SANS_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

GREEN = (21, 128, 61)
GREEN_DARK = (20, 83, 45)
INK = (28, 25, 23)
MUTED = (87, 83, 78)
PAPER = (246, 241, 230)
GOLD = (180, 83, 9)
WHITE = (255, 255, 255)
CREAM = (236, 253, 243)


def make_cover() -> Path:
    src = Image.open(IMG / "cover.jpg").convert("RGB")
    # Letter at 180 dpi — fill the page (crop center), no letterbox bars
    w, h = 1530, 1980
    src = ImageEnhance.Brightness(src).enhance(0.82)
    scale = max(w / src.width, h / src.height)
    nw, nh = int(src.width * scale), int(src.height * scale)
    src = src.resize((nw, nh), Image.Resampling.LANCZOS)
    left, top = (nw - w) // 2, (nh - h) // 2
    canvas = src.crop((left, top, left + w, top + h))
    overlay = Image.new("RGB", (w, h), GREEN_DARK)
    mask = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(mask)
    for i in range(h):
        # fade to green at the bottom
        t = max(0, min(255, int((i - h * 0.42) / (h * 0.58) * 255)))
        d.line([(0, i), (w, i)], fill=t)
    canvas = Image.composite(overlay, canvas, mask)

    draw = ImageDraw.Draw(canvas)
    kicker = ImageFont.truetype(FONT_SANS_B, 28)
    title = ImageFont.truetype(FONT_SERIF_B, 92)
    sub = ImageFont.truetype(FONT_SERIF, 34)
    draw.text((88, 1280), "EARL'S FURNITURE", font=kicker, fill=(187, 247, 208))
    draw.text((88, 1330), "Crew & Office", font=title, fill=WHITE)
    draw.text((88, 1435), "Manual", font=title, fill=WHITE)
    blurb = (
        "Clock in at the door. The trucks draw a line on the map.\n"
        "Every piece has a label. That is the whole day, on a phone."
    )
    draw.multiline_text((88, 1585), blurb, font=sub, fill=(236, 253, 243), spacing=8)
    dest = HERE / "_cover_page.jpg"
    canvas.save(dest, "JPEG", quality=90)
    return dest


class Manual(FPDF):
    def __init__(self) -> None:
        super().__init__(unit="in", format="letter")
        self.set_auto_page_break(auto=True, margin=0.7)
        self.set_margins(0.75, 0.7, 0.75)
        self.add_font("serif", "", FONT_SERIF)
        self.add_font("serif", "B", FONT_SERIF_B)
        self.add_font("sans", "", FONT_SANS)
        self.add_font("sans", "B", FONT_SANS_B)
        self.cover_mode = True

    def header(self) -> None:
        if self.cover_mode or self.page_no() == 1:
            return
        self.set_fill_color(*PAPER)
        self.rect(0, 0, 8.5, 11, "F")
        self.set_font("sans", "", 8)
        self.set_text_color(*GREEN_DARK)
        self.set_xy(0.75, 0.32)
        self.cell(7.0, 0.2, "Earl's Furniture  ·  Crew & Office Manual", align="L")
        self.set_draw_color(*GREEN)
        self.set_line_width(0.015)
        self.line(0.75, 0.52, 8.5 - 0.75, 0.52)
        self.set_xy(0.75, 0.68)

    def footer(self) -> None:
        if self.cover_mode or self.page_no() == 1:
            return
        self.set_y(-0.48)
        self.set_draw_color(*GREEN)
        self.set_line_width(0.015)
        self.line(0.75, self.get_y(), 8.5 - 0.75, self.get_y())
        self.set_xy(0.75, -0.38)
        self.set_font("sans", "", 8)
        self.set_text_color(*MUTED)
        self.cell(7.0, 0.2, str(self.page_no() - 1), align="C")

    def h2(self, text: str) -> None:
        self.ln(0.18)
        if self.get_y() > 9.4:
            self.add_page()
        self.set_font("serif", "B", 20)
        self.set_text_color(*GREEN_DARK)
        self.multi_cell(0, 0.34, text)
        self.ln(0.06)

    def h3(self, text: str) -> None:
        self.ln(0.1)
        self.set_font("serif", "B", 14)
        self.set_text_color(*INK)
        self.multi_cell(0, 0.28, text)
        self.ln(0.04)

    def body(self, text: str) -> None:
        self.set_font("serif", "", 11.5)
        self.set_text_color(*INK)
        self.multi_cell(0, 0.22, text)
        self.ln(0.08)

    def lede(self, text: str) -> None:
        self.set_font("serif", "", 13.5)
        self.set_text_color(63, 58, 52)
        self.multi_cell(0, 0.26, text)
        self.ln(0.1)

    def hint(self, text: str) -> None:
        self.set_font("sans", "B", 8.5)
        self.set_text_color(*GOLD)
        self.cell(7.0, 0.22, text.upper(), new_x="LMARGIN", new_y="NEXT")
        self.ln(0.04)

    def bullet(self, title: str, rest: str = "") -> None:
        self.set_font("serif", "B", 11.5)
        self.set_text_color(*GREEN_DARK)
        x = self.get_x()
        self.cell(0.16, 0.22, "•")
        if rest:
            self.set_font("serif", "B", 11.5)
            w = self.get_string_width(title + "  ")
            self.cell(w, 0.22, title)
            self.set_font("serif", "", 11.5)
            self.set_text_color(*INK)
            self.multi_cell(0, 0.22, rest)
        else:
            self.set_font("serif", "", 11.5)
            self.set_text_color(*INK)
            self.multi_cell(0, 0.22, title)
        self.ln(0.03)

    def numbered(self, n: int, text: str) -> None:
        y = self.get_y()
        if y > 9.7:
            self.add_page()
            y = self.get_y()
        self.set_fill_color(*GREEN)
        self.set_text_color(*WHITE)
        self.set_font("sans", "B", 8)
        self.set_xy(0.75, y)
        self.cell(0.22, 0.22, str(n), align="C", fill=True)
        self.set_xy(1.05, y)
        self.set_font("serif", "", 11.5)
        self.set_text_color(*INK)
        self.multi_cell(6.7, 0.22, text)
        self.ln(0.05)

    def caption(self, text: str) -> None:
        self.set_font("sans", "", 8.5)
        self.set_text_color(*MUTED)
        self.multi_cell(0, 0.18, text)
        self.ln(0.12)

    def photo(self, name: str, caption: str, max_h: float = 4.4) -> None:
        path = IMG / name
        im = Image.open(path)
        iw, ih = im.size
        usable = 8.5 - 1.5
        w = usable
        h = w * ih / iw
        if h > max_h:
            h = max_h
            w = h * iw / ih
        if self.get_y() + h + 0.55 > 10.3:
            self.add_page()
        x = 0.75 + (usable - w) / 2
        self.image(str(path), x=x, y=self.get_y(), w=w, h=h)
        self.set_y(self.get_y() + h + 0.08)
        self.caption(caption)

    def callout(self, kicker: str, title: str, paras: list[str]) -> None:
        # estimate height
        self.ln(0.08)
        needed = 0.55 + 0.38 + len(paras) * 0.9
        if self.get_y() + 3.6 > 10.2:
            self.add_page()
        x, y = 0.75, self.get_y()
        width = 7.0
        # draw after measuring
        start = self.get_y()
        self.set_fill_color(*GREEN_DARK)
        # placeholder; we'll draw rect first with a generous box then write
        box_top = start
        self.set_xy(x + 0.22, y + 0.18)
        self.set_font("sans", "B", 8)
        self.set_text_color(187, 247, 208)
        self.cell(width - 0.44, 0.2, kicker.upper())
        self.ln(0.26)
        self.set_x(x + 0.22)
        self.set_font("serif", "B", 18)
        self.set_text_color(*WHITE)
        self.multi_cell(width - 0.44, 0.3, title)
        self.ln(0.06)
        self.set_font("serif", "", 11.5)
        self.set_text_color(236, 253, 243)
        for p in paras:
            self.set_x(x + 0.22)
            self.multi_cell(width - 0.44, 0.22, p)
            self.ln(0.08)
        box_bottom = self.get_y() + 0.12
        # redraw fill behind by using a second pass isn't easy; draw rect now
        # actually we already wrote text. Better: compute then draw.
        # We'll accept drawing the rect first with estimated height.
        _ = (box_top, box_bottom)
        self.ln(0.1)

    def card(self, title: str, rest: str) -> None:
        if self.get_y() > 9.8:
            self.add_page()
        x, y = 0.75, self.get_y()
        self.set_font("serif", "B", 11.5)
        self.set_text_color(*GREEN_DARK)
        self.set_xy(x + 0.14, y + 0.1)
        self.multi_cell(6.72, 0.2, title)
        ty = self.get_y()
        self.set_font("serif", "", 11)
        self.set_text_color(*INK)
        self.set_x(x + 0.14)
        self.multi_cell(6.72, 0.2, rest)
        by = self.get_y() + 0.1
        self.set_draw_color(224, 212, 192)
        self.set_line_width(0.012)
        self.rect(x, y, 7.0, by - y)
        self.set_y(by + 0.1)


def build() -> None:
    cover = make_cover()
    pdf = Manual()

    # Cover
    pdf.add_page()
    pdf.image(str(cover), x=0, y=0, w=8.5, h=11)

    # Inside
    pdf.cover_mode = False
    pdf.add_page()

    pdf.lede(
        "This is the yard, in everybody's pocket. The crew uses a phone. "
        "The office uses a screen at the desk. Same system. Same day."
    )
    pdf.body(
        "A man walks in, scans the poster by the door, and he is on the clock. "
        "From that second until he clocks out, the truck he is driving writes a line "
        "on your map — every street, every stop, every extra loop. The office typed "
        "tonight's work last night, so when he clocks in the day's orders are already "
        "on the phone. He walks the truck, taps through the once-over, and rolls."
    )
    pdf.body(
        "Out in the warehouse, every sofa, every chair, every boxed set gets a QR label. "
        "Scan it and you know what it is, how many you've got, who pulled it, and for which job. "
        "Photograph the load on the truck before it leaves. Photograph it on the customer's porch "
        "if you delivered it. If something is torn, the camera is the report."
    )
    pdf.body(
        "It works on iPhone and Android. It keeps working when the signal drops in the metal "
        "building and it catches up when the signal comes back. Put it on the home screen like any other app."
    )

    # Trucks callout — draw box first with measured content via a fixed layout
    pdf.ln(0.08)
    if pdf.get_y() > 5.2:
        pdf.add_page()
    x, y = 0.75, pdf.get_y()
    width = 7.0
    # Write to a dummy measurement by rendering then overlaying is messy.
    # Draw a tall green panel and write on it.
    paras = [
        "They are not personal vehicles. They are Earl's. A hundred-thousand-dollar box with your name on the side, your diesel in the tank, your insurance on the paper. When somebody takes that truck off the property, you have a right to know where it went — every street, every minute, until the keys come back. That is a normal ask. That is ownership.",
        "From clock-in to clock-out the phone draws a full line of the route. Not a pin that says \"he was here at lunch.\" A line. You open the map and you see the truck moving. You tap Route and you see the whole shift — the deliveries, the stops, and the two-hour ride that was not a delivery.",
        "Imagine the gas that saves you. Not because you stood in the lot and yelled. Because the line is on the wall, and riding around for two hours is no longer invisible. Crews who know the truck is drawing a map tend to drive the map you gave them. That is how a shop stops burning diesel for nothing.",
        "Keep the phone in the truck mount with the app open while they drive. That is how you get a clean, second-by-second line. Clock-out stops it. Off the clock is off the clock. On the clock, it is your truck, and the line is yours.",
    ]
    pdf.set_font("sans", "B", 8)
    kicker_h = 0.22
    pdf.set_font("serif", "B", 18)
    title_h = 0.34
    pdf.set_font("serif", "", 11.5)
    text_h = 0
    for p in paras:
        text_h += pdf.get_string_width(" ")  # noop to keep linter quiet
    # approximate: wrap at ~95 chars / 11.5pt ≈ 6.56 in
    def wrap_height(text: str, line_h: float = 0.22, width_in: float = 6.56) -> float:
        pdf.set_font("serif", "", 11.5)
        words = text.split()
        lines, cur = 1, ""
        for w in words:
            trial = (cur + " " + w).strip()
            if pdf.get_string_width(trial) > width_in:
                lines += 1
                cur = w
            else:
                cur = trial
        return lines * line_h + 0.08

    h = 0.22 + 0.18 + 0.36 + 0.1 + sum(wrap_height(p) for p in paras) + 0.22
    if y + h > 10.3:
        pdf.add_page()
        y = pdf.get_y()
    pdf.set_fill_color(*GREEN_DARK)
    pdf.rect(x, y, width, h, "F")
    pdf.set_xy(x + 0.22, y + 0.16)
    pdf.set_font("sans", "B", 8)
    pdf.set_text_color(253, 230, 138)
    pdf.cell(width - 0.44, 0.2, "THIS IS THE PART THAT PAYS FOR ITSELF")
    pdf.set_xy(x + 0.22, y + 0.4)
    pdf.set_font("serif", "B", 18)
    pdf.set_text_color(*WHITE)
    pdf.cell(width - 0.44, 0.32, "These are your trucks.")
    cy = y + 0.8
    pdf.set_font("serif", "", 11.5)
    pdf.set_text_color(236, 253, 243)
    for p in paras:
        pdf.set_xy(x + 0.22, cy)
        before = pdf.get_y()
        pdf.multi_cell(width - 0.44, 0.22, p)
        cy = pdf.get_y() + 0.08
    pdf.set_y(y + h + 0.16)

    pdf.photo(
        "office-map.jpg",
        "This is the desk. Live map of who is on the clock, the shop pin, and the line that truck actually drove. Tap a name. Tap Route. The day is right there.",
        max_h=3.8,
    )

    pdf.h2("The door")
    pdf.body(
        "Print the clock-in poster from Admin → Posters. Tape it by the door the crew actually uses. "
        "Stand there once and tap \"use my location\" so the shop is pinned on the map. After that, "
        "every morning starts the same way: walk up, scan, go to work."
    )
    pdf.photo(
        "poster-door.jpg",
        "The poster is the time clock. The letters under the square are the backup if a camera is being stubborn — type them in.",
        max_h=3.7,
    )
    pdf.body(
        "If somebody clocks in without scanning — from the house, from the store, from three miles away — "
        "the office sees it. The timesheet will say manual, and it will say how far they were from the door. "
        "\"Scanned, thirty feet from the shop\" is a normal morning. \"Manual, three miles away\" is a conversation."
    )

    pdf.h2("Clock in — how the day starts")
    pdf.hint("On the phone")
    pdf.numbered(1, "Open Earl's. Tap Clock in at the bottom, or the big green button on Home.")
    pdf.numbered(2, "The phone will ask for location. Allow it. That is how the truck gets on the map.")
    pdf.numbered(3, "Point the camera at the poster by the door.")
    pdf.numbered(4, "You are in. Location stays on for the shift. Today's orders are waiting underneath.")
    pdf.photo(
        "phone-clock-in.jpg",
        "The first screen of the day. One button: Scan to clock in. Location has to be on — the app will tell you if it isn't.",
        max_h=6.35,
    )
    pdf.photo(
        "phone-scanning.jpg",
        "Point at the square. That is the punch clock. If the camera is having a day, type the code under the square and hit Go.",
        max_h=6.35,
    )

    pdf.h2("You're in. Here's today.")
    pdf.photo(
        "phone-on-shift.jpg",
        "Green means you're on the clock. GPS on means the truck is drawing the line. The list is what the office typed last night.",
        max_h=6.35,
    )
    pdf.card("You're clocked in", "Time, shop, location on for this shift.")
    pdf.card(
        "Today from the office",
        "The stops, the pieces, the notes. Important ones sit on top. When their phone shows it, the office gets a receipt that it was delivered.",
    )
    pdf.card("Morning truck check", "Tap this before you roll. Walk the truck. Don't skip it.")
    pdf.card(
        "Clock out",
        "End of day. Tracking stops when you do. If somebody forgets, the office can clock them out from the desk.",
    )

    pdf.h2("Morning truck check")
    pdf.body(
        "Earl's words were \"check the oil, look at the engine, give the truck a once-over.\" "
        "This is that, on the phone, in the order you walk it: hood, around the outside, climb in."
    )
    pdf.numbered(1, "Tap Truck at the bottom. Pick the truck you are taking.")
    pdf.numbered(2, "Every line gets an answer: OK, Watch, or Bad. Oil, coolant, belts, brakes, tires, lights, mirrors, lift gate, leaks, cab, body.")
    pdf.numbered(3, "Punch the odometer. Tap the fuel. Write a note if something is wrong.")
    pdf.numbered(4, "Submit. The office sees it.")
    pdf.body(
        "If brakes, tires, lights, oil, coolant, or the lift gate come back Bad, the truck is grounded. "
        "Don't take it. Tell the office and grab another one. That is not a suggestion from the phone — "
        "the shop records it as Do not drive."
    )
    pdf.photo(
        "phone-truck-check.jpg",
        "Walk it front to back. One tap per line. Safety items are marked. Submit check is at the bottom when you are done.",
        max_h=6.35,
    )

    pdf.h2("Home — the first screen")
    pdf.photo(
        "phone-home.jpg",
        "This is Home. Big green clock-in until you're on the clock. Scan Item when you're pulling pieces. The five buttons at the bottom never move.",
        max_h=6.35,
    )
    pdf.body(
        "If you are not clocked in, the first thing on the screen is the clock. If you are, it shows how long you've been on and that GPS is on. "
        "Admin sees an extra line: how many people are on the clock right now, and a tap that opens the live map. "
        "The three numbers — products, items, low stock — are the warehouse at a glance. Low stock in red means somebody should look before you sell a piece you don't have."
    )

    pdf.h2("Scan a piece")
    pdf.body(
        "Every item in the building gets a label. A sofa is one item, one label. A boxed set of three tables is still one label, with how many in the box. "
        "Scan it and the phone knows what you are holding."
    )
    pdf.numbered(1, "Tap Scan at the bottom.")
    pdf.numbered(2, "Tap Start Camera. Point at the QR on the piece.")
    pdf.numbered(3, "Pull it for a job, or put it back. The ledger writes who, what, how many, and when. Nothing gets erased. You can always answer \"who took that sofa.\"")
    pdf.body(
        "Camera not playing along? Type the code — it looks like ITM-2026-000123 — and hit Go. "
        "When you pull a piece for a customer, take the load-out picture while you are still standing at the truck. "
        "That photo is how you close the argument \"you never loaded it.\" If you delivered it, photograph it where it sits at the house."
    )
    pdf.photo(
        "phone-scan.jpg",
        "Start Camera is the green button. Manual entry is underneath if you need it.",
        max_h=6.35,
    )

    pdf.h2("Something's torn")
    pdf.photo(
        "phone-damage.jpg",
        "The camera opens first. Taking the picture is the report. Tap why — forklift, strapping, weather, defect, transit, handling — and how bad.",
        max_h=6.35,
    )
    pdf.body(
        "Tap Damage at the bottom. The camera is already on. You do not write an essay. Who you are, what time it is, "
        "where you are standing, and which piece you scanned all fill in by themselves. If the piece is leaving the count, "
        "the same screen writes it off so the warehouse number stays honest. The office reviews the photo. The facts the crew "
        "captured stay the facts — review does not rewrite the picture."
    )

    pdf.h2("What you see from the desk")
    pdf.body(
        "Sign in as admin. Home already tells you how many are on the clock. Open Admin, or tap Where's the crew."
    )
    pdf.bullet("Crew", "— live map and timesheet.")
    pdf.bullet("Fleet", "— trucks and this morning's checks.")
    pdf.bullet("Orders", "— type tomorrow night, they see it at clock-in.")
    pdf.bullet("Posters", "— the door QR.")

    pdf.h3("Crew")
    pdf.body("This is the money screen. Everybody on the clock is a dot.")
    pdf.bullet("Green", "— moving. Speed is on the pin.")
    pdf.bullet("Blue", "— stopped.")
    pdf.bullet("Amber", "— signal lost. The last good fix is still on the map, with how long ago.")
    pdf.body(
        "Tap a name to follow that truck. Tap Route and the line of the whole shift draws in — clock-in at the shop, "
        "every street after that. That is how you see a delivery day, and that is how you see a joyride. Same button."
    )
    pdf.body(
        "The timesheet is the same page, underneath. In, out, hours, QR or manual, how far from the door they were when they clocked in. "
        "If somebody's phone died and they forgot to clock out, you can clock them out from here."
    )

    pdf.h3("Fleet")
    pdf.body(
        "Every truck Earl's owns. Whether it had its morning check. What was flagged. "
        "If a truck is sitting on \"Do not drive,\" it is sitting. Don't send it."
    )

    pdf.h3("Orders")
    pdf.body(
        "At the end of the day, type tomorrow. For everybody, or for one driver. Mark it important when it is important. "
        "In the morning, when they scan the door, it is on the phone. You will see who got it and what time the phone showed it. "
        "That is your proof the stop was handed off — not a sticky note that lived on the counter."
    )

    pdf.h3("Posters")
    pdf.body(
        "Make the shop. Pin it. Print the QR. If a poster walks off or gets copied, rotate the code and print a new one. Old posters stop working."
    )

    pdf.h2("Putting a new piece in the building")
    pdf.body(
        "Admin only, because this creates the catalogue. Open New Item. Photograph it. Name it. Tap how many. "
        "The picture becomes the product photo, the labels come up ready to print, and the codes start with ITM- so they belong to this shop. "
        "Stick the label on the piece before it hits the floor. From then on, the crew just scans it."
    )

    pdf.h2("The five buttons at the bottom")
    pdf.body("They never change. Thumb reach, standing in the warehouse, gloves maybe still on.")
    pdf.card("Home", "Where you are in the day, clock-in, scan, the numbers.")
    pdf.card("Clock in", "The door, the orders, clock out.")
    pdf.card("Truck", "The morning once-over.")
    pdf.card("Scan", "The piece in your hand.")
    pdf.card("Damage", "The camera, the report.")
    pdf.body(
        "Everything else — jobs, receiving, admin, tomorrow's orders — lives in the menu at the top right. "
        "The crew does not need it to start the truck."
    )

    pdf.h2("A word for the people driving")
    pdf.body(
        "Location is on between clock-in and clock-out. That is the deal, and the clock-in screen says so before the phone even asks. "
        "You are taking the shop's truck. The shop watches the truck. When you clock out, it stops."
    )
    pdf.body(
        "Put Earl's on the home screen. Keep it open in the mount while you drive. Do the truck check like you mean it — "
        "those are the brakes that get you home. Scan the piece, photograph the load, and the office stops calling you to ask what happened."
    )

    pdf.h2("A word for the office")
    pdf.body(
        "Type tomorrow before you go home. Print labels before a piece hits the floor. Look at the map the first week like you mean it — "
        "not to catch people, to teach the building that the trucks are visible now. The gas you don't burn is the quiet win. "
        "The sofa that doesn't walk off because it had a label is the other one."
    )
    pdf.body("You have a right to know where your trucks went. You finally can.")

    pdf.ln(0.3)
    pdf.set_font("sans", "", 9)
    pdf.set_text_color(*MUTED)
    pdf.multi_cell(
        0,
        0.2,
        "Earl's Furniture  ·  Crew & Office Manual\nClock in, trucks, and deliveries — on the phone.",
    )

    pdf.output(str(OUT))
    cover.unlink(missing_ok=True)
    print(f"Wrote {OUT} ({OUT.stat().st_size} bytes, {pdf.page_no()} pages)")


if __name__ == "__main__":
    build()
