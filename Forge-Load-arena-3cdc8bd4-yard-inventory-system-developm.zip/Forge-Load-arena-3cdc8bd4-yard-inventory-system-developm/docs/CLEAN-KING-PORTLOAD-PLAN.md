# Clean King × PortLoad — Franchise Scaling Plan

_Clean King is the umbrella. PortLoad is the yard-inventory app that runs
under it. This document is the plan for taking the Forge Load codebase
(`yard-inventory-system-development`) to many Clean King franchises._

## What exists today

| Piece | State |
| --- | --- |
| `dwaynebroussard67-art/clean-king` | Live repo (PRs #2–13, Vercel project `clean-king`). Owner assistant, bilingual access, referral links, meeting workspace. **Not accessible from the current GitHub integration** (403) — see "Access" below. |
| `yard-inventory-system-development` ("Forge Load") | Mature yard inventory: QR bundles, append-only movement ledger, offline queue, GPS clock-in, truck checks, itineraries, damage + load-out photos. White-label via `src/lib/tenant.ts`. |
| Supabase projects | `misfit-backend`, `forge-mode` (active), one inactive project. No Clean King project yet. |

## Phase 1 — Clean King as a tenant (done, this branch)

`clean-king` is now a registered tenant in `src/lib/tenant.ts`:

- **Name:** Clean King · **Mark:** 👑 · **Monogram:** CK
- **Brand:** burgundy `#7f1d1d` fill (white ≈ 10:1), gold `#fbbf24` text tint
  (burgundy text on slate-950 is ~1.5:1 — the gold is what crews read)
- **Vocabulary:** a *kit* (caddy of bottles/tools) holding *bottles*;
  measures `bottle / case / kit / gallon`; synonyms `caddy, pack`
- **Stock codes:** `KIT-2026-000123` (prefix moved onto `TenantConfig.codePrefix`
  so codes.ts and the assistant no longer hard-code ITM/BND)
- **Deploy:** `NEXT_PUBLIC_TENANT=clean-king npm run build`

This gets **one** franchise live today with zero forks. It does **not** yet
serve many franchises from one deployment — that's Phase 2.

## Phase 2 — True multi-tenancy (the franchise layer)

Today the tenant is chosen by an env var at build time: one deployment =
one tenant = one database. To cover many franchises from one codebase we
need the franchise to become **data**, not a deploy:

1. **`franchises` table** — `id, slug, name, city, timezone, active,
   created_at`. One row per franchise location.
2. **`franchise_id` on every operational table** — users, customers,
   products, receipts, bundles, jobs, movements, photos, damage_reports,
   sites, shifts, location_pings, vehicles, vehicle_checks, itineraries,
   itinerary_acks. Nullable during migration, then NOT NULL.
3. **Scoped queries** — every API route filters by the session's
   `franchise_id`. The session JWT gains a `franchiseId` claim at login.
   Umbrella admins (Clean King HQ) get a franchise switcher; franchise
   crews only ever see their own rows.
4. **Shared catalogue, local stock** — products can be flagged
   `shared` (HQ catalogue: chemicals, SKUs) vs franchise-local. Bundles,
   movements and balances stay strictly per-franchise.
5. **Code sequences per franchise** — `bundle_code_seq` becomes
   `(franchise_id, year)` scoped, or codes gain a franchise segment
   (`KIT-BAT-2026-000123`). Decide before printing labels.
6. **Tenant resolution moves to the request** — subdomain
   (`batonrouge.portload.clean-king.com`) or path, resolved in middleware,
   instead of a build-time env var. Branding (name, colours, vocabulary)
   stays per-franchise in the `franchises` row, falling back to the
   Clean King tenant defaults.

## Phase 3 — Umbrella operations

- **Cross-franchise dashboard** for HQ: stock levels, low-stock alerts,
  crew activity, damage rates — aggregated, read-only.
- **Catalogue push** — HQ publishes a product/price list; franchises
  subscribe and receive it as draft products.
- **Inter-franchise transfers** — a movement type that moves stock between
  two franchises with both sides in one transaction.
- **Per-franchise billing/quotas** — usage metering keyed by `franchise_id`.

## Access — what I need from you

The `clean-king` repo returns **403 "Resource not accessible by
integration"** for the GitHub connection in this workspace, even though
Gmail/Vercel show it active. To clone and merge against it:

1. In GitHub → Settings → Applications → the Arena/GitHub App installation,
   add `clean-king` to the repository access list, **or**
2. Reconnect GitHub in Arena so the token picks up the new repo.

Once I can read it, the merge path is: PortLoad tenant (this branch) →
rebase onto `clean-king`'s owner-assistant/referral foundations → one
repo, two apps (Clean King front door + PortLoad yard).


## Decisions (confirmed by owner, 2026-11-21)

1. **One shared database** with `franchise_id` — cheaper, HQ reporting
   comes for free, one backup.
2. **Subdomain per franchise** — `batonrouge.portload.clean-king.com`.
   Tenant resolution moves into middleware (host → franchise row →
   branding), replacing the build-time env var.
3. **Shared catalogue from HQ** — chemicals/SKUs standardised across the
   franchise system; franchises subscribe. (Owner was unsure whether a
   shared system exists today; shared is the franchise standard and can
   be relaxed per-product later.)

## Official name

The app is **Forge Load** (repo name `yard-inventory-system-development`
is just the GitHub slug). `package.json` is now `forge-load` and
`forge-load` is the default tenant — a fresh deploy is Forge Load out of
the box. Earl's Furniture and Clean King remain available via
`NEXT_PUBLIC_TENANT=earls-furniture` / `clean-king`.

