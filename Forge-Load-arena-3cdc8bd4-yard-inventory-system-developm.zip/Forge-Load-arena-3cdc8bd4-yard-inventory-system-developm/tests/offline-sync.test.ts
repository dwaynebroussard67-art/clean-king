import { describe, it, expect } from "vitest";
import { nextSyncState, MAX_RETRIES, PERMANENT_REJECTIONS } from "@/lib/offline-queue";

/**
 * These cover the retry decision for both the movement queue and the damage
 * queue. Getting this wrong is expensive in a quiet way: a permanent refusal
 * retried forever burns battery and hides a real problem, while a transient
 * blip treated as permanent silently loses a crew's work.
 *
 * The IndexedDB plumbing around it needs a browser, so it isn't covered here.
 */
describe("nextSyncState", () => {
  it("marks any 2xx as synced", () => {
    for (const status of [200, 201, 204]) {
      expect(nextSyncState(status, 0)).toBe("synced");
    }
  });

  it("keeps a 401 pending without consuming a retry", () => {
    // The session expired, which says nothing about the queued item. If this
    // consumed retries, a crew logged out overnight would lose the queue.
    expect(nextSyncState(401, 0)).toBe("pending");
    expect(nextSyncState(401, MAX_RETRIES + 3)).toBe("pending");
  });

  it("rejects permanent refusals immediately, on the first try", () => {
    for (const status of PERMANENT_REJECTIONS) {
      expect(nextSyncState(status, 0)).toBe("rejected");
    }
  });

  it("retries a server error until the cap, then parks it", () => {
    for (let attempted = 0; attempted < MAX_RETRIES - 1; attempted++) {
      expect(nextSyncState(500, attempted)).toBe("pending");
    }
    // The attempt that reaches the cap is the one that gives up.
    expect(nextSyncState(500, MAX_RETRIES - 1)).toBe("rejected");
    expect(nextSyncState(503, MAX_RETRIES)).toBe("rejected");
  });

  it("treats 409 as permanent but 429 as worth retrying", () => {
    // 409 means someone else pulled the stock first — resending can't fix it.
    expect(nextSyncState(409, 0)).toBe("rejected");
    // 429 is just backpressure; the same request will succeed later.
    expect(nextSyncState(429, 0)).toBe("pending");
  });
});
