import { describe, it, expect } from "vitest";
import {
  haversineMeters,
  isOnSite,
  isCheckComplete,
  rollupCheckStatus,
  parseSiteToken,
  generateSiteToken,
  localDateKey,
  nextDateKey,
  formatDistance,
  formatDuration,
  CHECK_ITEMS,
} from "@/lib/fleet";

/**
 * Pure rules shared by the phone, the API and the office view. If these
 * drift, the crew's screen says "good to go" while the office sees "do not
 * drive" — so they're pinned here.
 */

describe("distance", () => {
  it("measures the shop to downtown Abbeville at roughly a mile", () => {
    // Veterans Memorial Dr to the courthouse square.
    const m = haversineMeters(29.9807, -92.1163, 29.9744, -92.1343);
    expect(m).toBeGreaterThan(1500);
    expect(m).toBeLessThan(2100);
  });

  it("is zero for the same point", () => {
    expect(haversineMeters(30, -92, 30, -92)).toBe(0);
  });

  it("formats in feet under ~1000 ft and miles above", () => {
    expect(formatDistance(30)).toBe("98 ft");
    expect(formatDistance(1609)).toBe("1.0 mi");
    expect(formatDistance(25_000)).toBe("16 mi");
    expect(formatDistance(null)).toBe("—");
  });
});

describe("on-site check", () => {
  it("counts a clock-in inside the radius as on site", () => {
    expect(isOnSite(40, 250, 10)).toBe(true);
  });

  it("gives the phone the benefit of its own accuracy under a metal roof", () => {
    // 300 m reported, but the fix was ±80 m — could well be inside 250.
    expect(isOnSite(300, 250, 80)).toBe(true);
  });

  it("caps that slack so a 2 km fix can't be 'on site' from anywhere", () => {
    expect(isOnSite(2000, 250, 1900)).toBe(false);
  });

  it("is unknown, not false, when there was no fix", () => {
    expect(isOnSite(null, 250, null)).toBeNull();
  });
});

describe("truck check roll-up", () => {
  const allOk = Object.fromEntries(CHECK_ITEMS.map((i) => [i.key, "ok" as const]));

  it("is 'ok' only when everything is ok", () => {
    expect(rollupCheckStatus(allOk)).toBe("ok");
  });

  it("grounds the truck on a bad safety item", () => {
    expect(rollupCheckStatus({ ...allOk, brakes: "bad" })).toBe("needs_repair");
    expect(rollupCheckStatus({ ...allOk, tires: "bad" })).toBe("needs_repair");
  });

  it("flags but doesn't ground on a bad non-safety item", () => {
    expect(rollupCheckStatus({ ...allOk, body: "bad" })).toBe("attention");
  });

  it("flags any 'watch'", () => {
    expect(rollupCheckStatus({ ...allOk, oil: "watch" })).toBe("attention");
  });

  it("treats an unfinished checklist as needing attention, never clean", () => {
    const { oil: _oil, ...missingOil } = allOk;
    void _oil;
    expect(rollupCheckStatus(missingOil)).toBe("attention");
    expect(isCheckComplete(missingOil)).toBe(false);
    expect(isCheckComplete(allOk)).toBe(true);
  });
});

describe("site tokens", () => {
  it("reads a token off the poster URL", () => {
    expect(parseSiteToken("https://earls.example/clock-in/K7XM2PQ9RT")).toBe("K7XM2PQ9RT");
  });

  it("accepts a typed code in any case, with stray spaces", () => {
    expect(parseSiteToken("  k7xm2pq9rt ")).toBe("K7XM2PQ9RT");
  });

  it("rejects anything that isn't a token", () => {
    expect(parseSiteToken("https://earls.example/bundle/BND-2026-000001")).toBeNull();
    expect(parseSiteToken("abc")).toBeNull();
    expect(parseSiteToken("")).toBeNull();
  });

  it("generates tokens that pass the database CHECK and avoid look-alike glyphs", () => {
    for (let i = 0; i < 50; i++) {
      const t = generateSiteToken();
      expect(t).toMatch(/^[A-Z0-9]{6,32}$/);
      expect(t).not.toMatch(/[01IO]/);
    }
  });
});

describe("calendar days in the shop's zone", () => {
  it("rolls the day over at midnight Central, not UTC", () => {
    // 11:30 pm Central on Sep 4 is 04:30 UTC on Sep 5.
    const lateEvening = new Date("2026-09-05T04:30:00Z");
    expect(localDateKey(lateEvening)).toBe("2026-09-04");
    expect(nextDateKey(lateEvening)).toBe("2026-09-05");
  });

  it("formats a shift length", () => {
    expect(formatDuration(6 * 3600_000 + 42 * 60_000)).toBe("6h 42m");
    expect(formatDuration(9 * 60_000)).toBe("9m");
  });
});
