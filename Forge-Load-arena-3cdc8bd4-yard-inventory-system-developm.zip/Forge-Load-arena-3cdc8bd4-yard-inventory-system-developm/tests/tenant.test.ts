import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

/**
 * The white-label contract.
 *
 * The goal is that adding a customer is a config change and nothing else, so
 * these tests pin down the parts that would silently break that promise: an
 * unknown tenant must not crash the app, and per-tenant namespacing must
 * actually differ between tenants or two yards on sibling subdomains will log
 * each other out.
 */
describe("tenant config", () => {
  const original = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
  });

  afterEach(() => {
    process.env = { ...original };
    vi.unstubAllEnvs();
  });

  it("defaults to Forge Load when nothing is set", async () => {
    delete process.env.NEXT_PUBLIC_TENANT;
    delete process.env.TENANT;
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.key).toBe("forge-load");
    expect(tenant.name).toBe("Forge Load");
  });

  it("switches every customer-visible string with one env var", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.name).toBe("Earl's Furniture");
    expect(tenant.shortName).toBe("Earl's");
    expect(tenant.mark).not.toBe("🔥");
    expect(tenant.theme.accentHex).not.toBe("#f97316");
  });

  it("serves Earl's Furniture as its own brand", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.name).toBe("Earl's Furniture");
    expect(tenant.domain).toContain("furniture");
  });

  it("falls back to the default rather than crashing on a typo", async () => {
    // A bad env var must never take a yard offline.
    vi.stubEnv("NEXT_PUBLIC_TENANT", "not-a-real-customer");
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.key).toBe("forge-load");
  });

  it("accepts TENANT as a server-side alias", async () => {
    delete process.env.NEXT_PUBLIC_TENANT;
    vi.stubEnv("TENANT", "earls-furniture");
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.key).toBe("earls-furniture");
  });

  it("namespaces the session cookie per tenant", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const a = await import("@/lib/tenant");
    expect(a.SESSION_COOKIE).toBe("earls-furniture_session");

    vi.resetModules();
    vi.stubEnv("NEXT_PUBLIC_TENANT", "forge-load");
    const b = await import("@/lib/tenant");
    expect(b.SESSION_COOKIE).toBe("forge-load_session");
    expect(b.SESSION_COOKIE).not.toBe(a.SESSION_COOKIE);
  });

  it("namespaces the offline database per tenant", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const a = await import("@/lib/tenant");
    vi.resetModules();
    vi.stubEnv("NEXT_PUBLIC_TENANT", "forge-load");
    const b = await import("@/lib/tenant");
    expect(a.OFFLINE_DB_NAME).not.toBe(b.OFFLINE_DB_NAME);
  });

  it("speaks each customer's vocabulary", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const ef = await import("@/lib/tenant");
    // A furniture warehouse should never see "bundle" or a lumber measure.
    expect(ef.terms.unit).toBe("item");
    expect(ef.Unit).toBe("Item");
    expect(ef.terms.measures).not.toContain("board_ft");
    expect(ef.terms.measures).not.toContain("linear_ft");

    vi.resetModules();
    vi.stubEnv("NEXT_PUBLIC_TENANT", "forge-load");
    const fl = await import("@/lib/tenant");
    expect(fl.terms.unit).toBe("bundle");
    expect(fl.terms.measures).toContain("board_ft");
  });

  it("never shows a crew a snake_case measure", async () => {
    const { measureLabel } = await import("@/lib/tenant");
    expect(measureLabel("board_ft")).toBe("board ft");
    expect(measureLabel("piece")).toBe("piece");
  });

  it("serves Clean King as its own brand", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "clean-king");
    const { tenant } = await import("@/lib/tenant");
    expect(tenant.name).toBe("Clean King");
    expect(tenant.domain).toContain("cleaning");
    // A cleaning franchise should never see furniture or lumber words.
    expect(tenant.terms.unit).toBe("kit");
    expect(tenant.terms.measures).not.toContain("board_ft");
    expect(tenant.terms.measures).not.toContain("set");
  });

  it("gives every tenant a stock code prefix", async () => {
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, t] of Object.entries(TENANTS)) {
      expect(t.codePrefix, `${key}.codePrefix`).toMatch(/^[A-Z]{2,4}$/);
    }
    expect(TENANTS["earls-furniture"].codePrefix).toBe("ITM");
    expect(TENANTS["forge-load"].codePrefix).toBe("BND");
    expect(TENANTS["clean-king"].codePrefix).toBe("KIT");
  });

  it("gives every registered tenant the fields the UI depends on", async () => {
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, t] of Object.entries(TENANTS)) {
      expect(t.key, `${key}.key must match its map key`).toBe(key);
      expect(t.name.length).toBeGreaterThan(0);
      expect(t.shortName.length).toBeGreaterThan(0);
      expect(t.tagline.length).toBeGreaterThan(0);
      expect(t.mark.length).toBeGreaterThan(0);
      expect(t.domain.length).toBeGreaterThan(0);
      expect(t.codePrefix.length).toBeGreaterThan(0);
      // Hex values feed the PWA manifest and CSS variables; a malformed one
      // silently renders the app colourless.
      expect(t.theme.accentHex).toMatch(/^#[0-9a-f]{6}$/i);
      expect(t.theme.accentHexDark).toMatch(/^#[0-9a-f]{6}$/i);

      // Vocabulary must be complete, and the default measure has to be one the
      // product form actually offers or new products save an unselectable unit.
      expect(t.terms.unit.length).toBeGreaterThan(0);
      expect(t.terms.unitPlural.length).toBeGreaterThan(0);
      expect(t.terms.item.length).toBeGreaterThan(0);
      expect(t.terms.measures.length).toBeGreaterThan(0);
      expect(
        t.terms.measures,
        `${key}: defaultMeasure must appear in measures`
      ).toContain(t.terms.defaultMeasure);
    }
  });
});

describe("stock grouping model", () => {
  beforeEach(() => {
    vi.resetModules();
    delete process.env.NEXT_PUBLIC_TENANT;
    delete process.env.TENANT;
  });
  afterEach(() => vi.unstubAllEnvs());

  it("groups stock for a lumber yard", async () => {
    // Forge Load genuinely receives a bundle of 200 boards, so intake has to
    // ask both how many per bundle and how many bundles.
    vi.stubEnv("NEXT_PUBLIC_TENANT", "forge-load");
    const { terms } = await import("@/lib/tenant");
    expect(terms.groupsItems).toBe(true);
    expect(terms.perPackLabel).toBeNull();
  });

  it("does not group stock for a furniture warehouse", async () => {
    // Earl's moves single pieces -- a sofa is one item with one label. There
    // is no such thing as a bundle, so intake must not ask about one.
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const { terms } = await import("@/lib/tenant");
    expect(terms.groupsItems).toBe(false);
    // The occasional boxed set of three tables still needs a way in.
    expect(terms.perPackLabel).toBeTruthy();
  });

  it("gives every non-grouping tenant a way to record a multi-item box", async () => {
    // Otherwise a box of three tables could only be entered as three separate
    // items, which is wrong -- they move as one box with one label.
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      if (!config.terms.groupsItems) {
        expect(config.terms.perPackLabel, `${key} needs a per-pack label`).toBeTruthy();
      }
    }
  });
});

describe("withArticle", () => {
  it("picks the right article for each tenant's unit word", async () => {
    // "Scan a item" shipped to a live manifest before this existed.
    const { withArticle } = await import("@/lib/tenant");
    expect(withArticle("bundle")).toBe("a bundle");
    expect(withArticle("item")).toBe("an item");
    expect(withArticle("order")).toBe("an order");
    expect(withArticle("box")).toBe("a box");
  });

  it("reads correctly for every registered tenant", async () => {
    const { TENANTS, withArticle } = await import("@/lib/tenant");
    for (const config of Object.values(TENANTS)) {
      const phrase = withArticle(config.terms.unit);
      const vowel = /^[aeiou]/i.test(config.terms.unit);
      expect(phrase).toBe(`${vowel ? "an" : "a"} ${config.terms.unit}`);
    }
  });
});

/**
 * Contrast guards for the accent ramp.
 *
 * The app is used on phones in warehouses and yards, often in bad light, so a
 * brand colour that looks fine in a design tool but scores 2:1 against the
 * chrome is a real usability problem rather than a nitpick. These encode the
 * rule so the next customer's brand colour gets checked automatically instead
 * of by eye.
 */
function relativeLuminance(hex: string): number {
  const h = hex.replace("#", "");
  const channels = [0, 2, 4].map((i) => {
    const c = parseInt(h.slice(i, i + 2), 16) / 255;
    return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
}

function contrast(a: string, b: string): number {
  const [x, y] = [relativeLuminance(a), relativeLuminance(b)];
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

describe("accent contrast", () => {
  const SLATE_950 = "#020617";
  const WHITE = "#ffffff";

  /**
   * Forge Load's orange predates this check and sits at 2.80:1 for white text
   * on the fill -- below the 3:1 large-text line. It's their existing brand
   * colour and changing it is the customer's call, not a silent restyle, so
   * it's recorded as a known exception rather than quietly excluded or fixed.
   *
   * Buttons using it are large and bold, which is the mitigating factor, but
   * it should be raised with them.
   */
  const KNOWN_LOW_CONTRAST = new Set(["forge-load"]);

  it("keeps white legible on every tenant's primary button", async () => {
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      if (KNOWN_LOW_CONTRAST.has(key)) continue;
      const ratio = contrast(WHITE, config.theme.accentHex);
      expect(ratio, `${key}: white on accentHex is ${ratio.toFixed(2)}:1`).toBeGreaterThan(3);
    }
  });

  it("does not let the known exception get any worse", async () => {
    // Pinned so a future tweak to Forge Load's orange has to improve it.
    const { TENANTS } = await import("@/lib/tenant");
    for (const key of KNOWN_LOW_CONTRAST) {
      const ratio = contrast(WHITE, TENANTS[key].theme.accentHex);
      expect(ratio, `${key} regressed to ${ratio.toFixed(2)}:1`).toBeGreaterThan(2.7);
    }
  });

  it("keeps accent text legible on the dark chrome", async () => {
    // This is the one Earl's hunter green fails without a tint: the fill
    // colour reads at about 2.2:1 as label text, which is unusable outdoors.
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      const textColour = config.theme.accentHexTint ?? config.theme.accentHex;
      const ratio = contrast(textColour, SLATE_950);
      expect(ratio, `${key}: accent text is ${ratio.toFixed(2)}:1`).toBeGreaterThan(4.5);
    }
  });

  it("uses a darker shade for the hover state, not a lighter one", async () => {
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      const base = relativeLuminance(config.theme.accentHex);
      const dark = relativeLuminance(config.theme.accentHexDark);
      expect(dark, `${key}: accentHexDark should be darker`).toBeLessThan(base);
    }
  });
});

describe("tenant synonyms", () => {
  beforeEach(() => {
    vi.resetModules();
    delete process.env.NEXT_PUBLIC_TENANT;
    delete process.env.TENANT;
  });
  afterEach(() => vi.unstubAllEnvs());

  it("records the words Earl's uses interchangeably", async () => {
    vi.stubEnv("NEXT_PUBLIC_TENANT", "earls-furniture");
    const { terms } = await import("@/lib/tenant");
    expect(terms.synonyms).toContain("piece");
    expect(terms.synonyms).toContain("unit");
  });

  it("never lists the primary word as its own synonym", async () => {
    // Would produce "item also means item" in the assistant prompt.
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      const { unit, synonyms } = config.terms;
      expect(synonyms ?? [], `${key} repeats its own unit`).not.toContain(unit);
    }
  });

  it("keeps synonyms distinct from the measure list", async () => {
    // A synonym is a word for the tracked group; a measure is a unit of count.
    // Earl's "unit" must not silently become a selectable measure.
    const { TENANTS } = await import("@/lib/tenant");
    for (const [key, config] of Object.entries(TENANTS)) {
      for (const s of config.terms.synonyms ?? []) {
        expect(
          config.terms.measures.includes(s) && s !== config.terms.defaultMeasure,
          `${key}: "${s}" is both a synonym and a measure`
        ).toBe(false);
      }
    }
  });
});
