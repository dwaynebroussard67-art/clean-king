import { describe, it, expect, beforeEach, vi, afterEach } from "vitest";
import { rateLimit, resetRateLimit, clientIp } from "@/lib/rate-limit";
import { randomUUID } from "node:crypto";

describe("rateLimit", () => {
  let key: string;

  beforeEach(() => {
    // Fresh key per test — the limiter keeps module-level state by design.
    key = `test:${randomUUID()}`;
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("allows requests up to the limit", () => {
    for (let i = 0; i < 5; i++) {
      expect(rateLimit(key, { limit: 5, windowMs: 1000 }).ok).toBe(true);
    }
  });

  it("blocks the request after the limit is exceeded", () => {
    for (let i = 0; i < 5; i++) rateLimit(key, { limit: 5, windowMs: 60_000 });
    const blocked = rateLimit(key, { limit: 5, windowMs: 60_000 });
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfter).toBeGreaterThan(0);
  });

  it("reports remaining attempts", () => {
    expect(rateLimit(key, { limit: 3, windowMs: 1000 }).remaining).toBe(2);
    expect(rateLimit(key, { limit: 3, windowMs: 1000 }).remaining).toBe(1);
    expect(rateLimit(key, { limit: 3, windowMs: 1000 }).remaining).toBe(0);
  });

  it("resets once the window has elapsed", () => {
    vi.useFakeTimers();
    for (let i = 0; i < 5; i++) rateLimit(key, { limit: 5, windowMs: 1000 });
    expect(rateLimit(key, { limit: 5, windowMs: 1000 }).ok).toBe(false);

    vi.advanceTimersByTime(1500);
    expect(rateLimit(key, { limit: 5, windowMs: 1000 }).ok).toBe(true);
  });

  it("clears a bucket on successful login", () => {
    for (let i = 0; i < 5; i++) rateLimit(key, { limit: 5, windowMs: 60_000 });
    expect(rateLimit(key, { limit: 5, windowMs: 60_000 }).ok).toBe(false);

    resetRateLimit(key);
    expect(rateLimit(key, { limit: 5, windowMs: 60_000 }).ok).toBe(true);
  });

  it("keeps separate buckets per key", () => {
    const other = `test:${randomUUID()}`;
    for (let i = 0; i < 5; i++) rateLimit(key, { limit: 5, windowMs: 60_000 });
    expect(rateLimit(key, { limit: 5, windowMs: 60_000 }).ok).toBe(false);
    expect(rateLimit(other, { limit: 5, windowMs: 60_000 }).ok).toBe(true);
  });
});

describe("clientIp", () => {
  it("prefers the first x-forwarded-for entry", () => {
    const req = new Request("https://example.com", {
      headers: { "x-forwarded-for": "203.0.113.5, 70.41.3.18" },
    });
    expect(clientIp(req)).toBe("203.0.113.5");
  });

  it("falls back to x-real-ip", () => {
    const req = new Request("https://example.com", {
      headers: { "x-real-ip": "198.51.100.7" },
    });
    expect(clientIp(req)).toBe("198.51.100.7");
  });

  it("returns 'unknown' when no headers are present", () => {
    expect(clientIp(new Request("https://example.com"))).toBe("unknown");
  });
});

describe("rateLimitAsync without Redis configured", () => {
  it("behaves exactly like the in-memory limiter", async () => {
    const { rateLimitAsync } = await import("@/lib/rate-limit");
    const key = `async:${randomUUID()}`;
    const opts = { limit: 3, windowMs: 60_000 };

    for (let i = 0; i < 3; i++) {
      expect((await rateLimitAsync(key, opts)).ok).toBe(true);
    }
    const blocked = await rateLimitAsync(key, opts);
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfter).toBeGreaterThan(0);
  });

  it("clears the bucket on reset", async () => {
    const { rateLimitAsync, resetRateLimitAsync } = await import("@/lib/rate-limit");
    const key = `async:${randomUUID()}`;
    const opts = { limit: 1, windowMs: 60_000 };

    await rateLimitAsync(key, opts);
    expect((await rateLimitAsync(key, opts)).ok).toBe(false);

    await resetRateLimitAsync(key);
    expect((await rateLimitAsync(key, opts)).ok).toBe(true);
  });
});

describe("rateLimitAsync when Redis is configured but broken", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    vi.unstubAllGlobals();
    vi.resetModules();
  });

  it("falls back to the in-memory limiter instead of failing the request", async () => {
    // A rate limiter that hard-fails takes login down for the whole yard the
    // moment the cache has a bad minute. Degrading to per-instance limiting is
    // strictly better than nobody being able to sign in.
    vi.stubEnv("UPSTASH_REDIS_REST_URL", "https://redis.invalid");
    vi.stubEnv("UPSTASH_REDIS_REST_TOKEN", "token");
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("ECONNREFUSED")));
    vi.spyOn(console, "error").mockImplementation(() => {});
    vi.resetModules();

    const { rateLimitAsync } = await import("@/lib/rate-limit");
    const key = `broken:${randomUUID()}`;
    const opts = { limit: 2, windowMs: 60_000 };

    expect((await rateLimitAsync(key, opts)).ok).toBe(true);
    expect((await rateLimitAsync(key, opts)).ok).toBe(true);
    // Still enforced, just per instance.
    expect((await rateLimitAsync(key, opts)).ok).toBe(false);
  });
});

describe("rateLimitAsync against a working Redis", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    vi.unstubAllGlobals();
    vi.resetModules();
  });

  it("counts in Redis and blocks once the shared count passes the limit", async () => {
    vi.stubEnv("UPSTASH_REDIS_REST_URL", "https://redis.test");
    vi.stubEnv("UPSTASH_REDIS_REST_TOKEN", "token");

    const store = new Map<string, number>();
    const calls: string[][] = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: string, init: { body: string }) => {
        const args = JSON.parse(init.body) as string[];
        calls.push(args);
        const [cmd, key] = args;
        let result: unknown = null;
        if (cmd === "INCR") result = store.set(key, (store.get(key) ?? 0) + 1).get(key);
        if (cmd === "EXPIRE") result = 1;
        if (cmd === "TTL") result = 42;
        if (cmd === "DEL") result = store.delete(key) ? 1 : 0;
        return { ok: true, json: async () => ({ result }) };
      })
    );
    vi.resetModules();

    const { rateLimitAsync, resetRateLimitAsync } = await import("@/lib/rate-limit");
    const key = "shared:key";
    const opts = { limit: 2, windowMs: 60_000 };

    expect((await rateLimitAsync(key, opts)).ok).toBe(true);
    expect((await rateLimitAsync(key, opts)).ok).toBe(true);

    const blocked = await rateLimitAsync(key, opts);
    expect(blocked.ok).toBe(false);
    // retryAfter comes from the key's real TTL, not a guess.
    expect(blocked.retryAfter).toBe(42);

    // The window is pinned on first request only, so a steady trickle can't
    // keep pushing the expiry out and hold the bucket open forever.
    expect(calls.filter((c) => c[0] === "EXPIRE")).toHaveLength(1);

    await resetRateLimitAsync(key);
    expect(store.has(key)).toBe(false);
  });

  it("repairs a key that somehow has no expiry", async () => {
    // If a crash landed between INCR and EXPIRE, the counter would never reset
    // and would lock that account out permanently.
    vi.stubEnv("UPSTASH_REDIS_REST_URL", "https://redis.test");
    vi.stubEnv("UPSTASH_REDIS_REST_TOKEN", "token");

    const seen: string[] = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: string, init: { body: string }) => {
        const [cmd] = JSON.parse(init.body) as string[];
        seen.push(cmd);
        const result = cmd === "INCR" ? 5 : cmd === "TTL" ? -1 : 1;
        return { ok: true, json: async () => ({ result }) };
      })
    );
    vi.resetModules();

    const { rateLimitAsync } = await import("@/lib/rate-limit");
    await rateLimitAsync("orphan", { limit: 10, windowMs: 60_000 });

    expect(seen).toContain("TTL");
    expect(seen).toContain("EXPIRE");
  });
});
