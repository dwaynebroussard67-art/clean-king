import { describe, it, expect, beforeAll } from "vitest";
import { NextRequest } from "next/server";
import { SignJWT } from "jose";

/**
 * Request-level tests for the Edge route policy.
 *
 * This is the layer that decides who gets to see which page, so it's worth
 * exercising as actual requests rather than by reading the prefix lists. The
 * failure that prompted it was real: /admin used to return the full admin
 * shell to anonymous visitors.
 *
 * No database is involved -- the proxy verifies a JWT and nothing else -- so
 * these run fast and can cover every combination of role and path.
 */

const SECRET = "route-policy-test-secret-at-least-32-chars-long";
const COOKIE = "earls-furniture_session";

let tokens: { admin: string; crew: string; expired: string; foreign: string };

async function mint(
  role: "admin" | "crew",
  { secret = SECRET, expiresIn = 3600 }: { secret?: string; expiresIn?: number } = {}
) {
  const now = Math.floor(Date.now() / 1000);
  return new SignJWT({ id: "u1", email: "a@b.c", fullName: "A", role })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt(now)
    .setExpirationTime(now + expiresIn)
    .sign(new TextEncoder().encode(secret));
}

/** Run one request through the proxy and describe what happened. */
async function request(
  path: string,
  token?: string
): Promise<{ status: number; location: string | null; refreshed: boolean }> {
  const { proxy } = await import("@/proxy");
  const req = new NextRequest(`https://yard.test${path}`, {
    headers: token ? { cookie: `${COOKIE}=${token}` } : {},
  });
  const res = await proxy(req);
  const location = res.headers.get("location");
  return {
    status: res.status,
    location: location ? new URL(location, "https://yard.test").pathname : null,
    refreshed: res.cookies.get(COOKIE) !== undefined,
  };
}

beforeAll(async () => {
  process.env.JWT_SECRET = SECRET;
  process.env.NEXT_PUBLIC_TENANT = "earls-furniture";
  tokens = {
    admin: await mint("admin"),
    crew: await mint("crew"),
    expired: await mint("crew", { expiresIn: -60 }),
    foreign: await mint("admin", { secret: "a-completely-different-secret-32-chars!!" }),
  };
});

describe("route policy: anonymous visitors", () => {
  it.each(["/", "/scan", "/jobs", "/damage", "/queue", "/clock-in", "/truck-check", "/admin", "/receiving", "/intake"])(
    "redirects %s to login",
    async (path) => {
      const res = await request(path);
      expect(res.status).toBe(307);
      expect(res.location).toBe("/login");
    }
  );

  it("preserves where they were going", async () => {
    const { proxy } = await import("@/proxy");
    const req = new NextRequest("https://yard.test/jobs?filter=open");
    const res = await proxy(req);
    const url = new URL(res.headers.get("location")!);
    expect(url.searchParams.get("next")).toBe("/jobs?filter=open");
  });

  it("keeps the poster token through login, so the scan still counts", async () => {
    // A crew member's first-ever scan lands here logged out. After login they
    // must arrive at the clock-in screen with the token, not the home page.
    const { proxy } = await import("@/proxy");
    const res = await proxy(new NextRequest("https://yard.test/clock-in/K7XM2PQ9RT"));
    expect(res.status).toBe(307);
    const url = new URL(res.headers.get("location")!);
    expect(url.pathname).toBe("/login");
    expect(url.searchParams.get("next")).toBe("/clock-in/K7XM2PQ9RT");
  });

  it.each(["/login", "/offline"])("leaves %s reachable", async (path) => {
    expect((await request(path)).status).toBe(200);
  });
});

describe("route policy: crew", () => {
  it.each(["/", "/scan", "/jobs", "/damage", "/queue", "/clock-in", "/clock-in/K7XM2PQ9RT", "/truck-check"])("allows %s", async (path) => {
    expect((await request(path, tokens.crew)).status).toBe(200);
  });

  it.each(["/admin", "/receiving", "/intake"])(
    "bounces %s to the home screen",
    async (path) => {
      const res = await request(path, tokens.crew);
      expect(res.status).toBe(307);
      expect(res.location).toBe("/");
    }
  );

  it("bounces nested admin paths too, not just the exact prefix", async () => {
    expect((await request("/admin/users", tokens.crew)).location).toBe("/");
  });
});

describe("route policy: admin", () => {
  it.each(["/", "/admin", "/receiving", "/intake", "/scan"])("allows %s", async (path) => {
    expect((await request(path, tokens.admin)).status).toBe(200);
  });

  it("redirects away from /login when already signed in", async () => {
    const res = await request("/login", tokens.admin);
    expect(res.status).toBe(307);
    expect(res.location).toBe("/");
  });
});

describe("route policy: bad tokens", () => {
  it("treats an expired token as anonymous", async () => {
    const res = await request("/admin", tokens.expired);
    expect(res.status).toBe(307);
    expect(res.location).toBe("/login");
  });

  it("does not refresh an expired token", async () => {
    // If it did, a session could renew itself forever and an expiry would
    // never actually take effect.
    expect((await request("/", tokens.expired)).refreshed).toBe(false);
  });

  it("rejects a token signed with someone else's secret", async () => {
    const res = await request("/admin", tokens.foreign);
    expect(res.status).toBe(307);
    expect(res.location).toBe("/login");
  });

  it("treats a malformed cookie as anonymous rather than erroring", async () => {
    const res = await request("/", "not-a-jwt");
    expect(res.status).toBe(307);
    expect(res.location).toBe("/login");
  });
});

describe("route policy: assets and APIs", () => {
  it.each(["/_next/static/chunk.js", "/sw.js", "/favicon.ico", "/icon-192.png"])(
    "lets %s through unauthenticated",
    async (path) => {
      expect((await request(path)).status).toBe(200);
    }
  );

  it("does not redirect API routes, which return their own JSON errors", async () => {
    // An HTML redirect in response to fetch() is far harder to debug on a
    // phone than a 401 body.
    const res = await request("/api/bundles");
    expect(res.status).toBe(200);
    expect(res.location).toBeNull();
  });
});

describe("route policy: session refresh", () => {
  it("re-issues a cookie for a session close to expiry", async () => {
    const nearlyDone = await mint("crew", { expiresIn: 60 * 60 });
    expect((await request("/", nearlyDone)).refreshed).toBe(true);
  });

  it("leaves a freshly issued session alone", async () => {
    const fresh = await mint("crew", { expiresIn: 7 * 24 * 3600 });
    expect((await request("/", fresh)).refreshed).toBe(false);
  });
});
