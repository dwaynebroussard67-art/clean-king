import { describe, it, expect } from "vitest";
import {
  shouldRefreshSession,
  SESSION_TTL_SECONDS,
  SESSION_REFRESH_THRESHOLD_SECONDS,
} from "@/lib/session-cookie";

/**
 * Sliding sessions, so a shared yard phone that's in daily use never bounces
 * someone to a login screen mid-shift, while one left in a drawer still goes
 * cold on schedule.
 */
describe("shouldRefreshSession", () => {
  const now = 1_700_000_000;

  it("leaves a freshly issued token alone", () => {
    expect(shouldRefreshSession(now + SESSION_TTL_SECONDS, now)).toBe(false);
  });

  it("refreshes once the token is inside the threshold", () => {
    expect(
      shouldRefreshSession(now + SESSION_REFRESH_THRESHOLD_SECONDS - 60, now)
    ).toBe(true);
  });

  it("does not refresh exactly at the threshold, only past it", () => {
    expect(shouldRefreshSession(now + SESSION_REFRESH_THRESHOLD_SECONDS, now)).toBe(false);
  });

  it("refuses to refresh an already-expired token", () => {
    // The important one. If an expired token could refresh itself, a session
    // would never actually end -- a lost phone would stay authenticated
    // forever, which is the opposite of what an expiry is for.
    expect(shouldRefreshSession(now - 1, now)).toBe(false);
    expect(shouldRefreshSession(now - SESSION_TTL_SECONDS, now)).toBe(false);
  });

  it("does not refresh a token that expires this very second", () => {
    expect(shouldRefreshSession(now, now)).toBe(false);
  });

  it("treats a token with no expiry as not refreshable", () => {
    expect(shouldRefreshSession(undefined, now)).toBe(false);
  });

  it("keeps the refresh window shorter than the full lifetime", () => {
    // Otherwise every request would re-issue, defeating the point.
    expect(SESSION_REFRESH_THRESHOLD_SECONDS).toBeLessThan(SESSION_TTL_SECONDS);
  });
});
