import { describe, it, expect } from "vitest";
import { isUniqueViolation, isForeignKeyViolation } from "@/lib/db-errors";

/**
 * These replaced `err.message.includes("unique")`, which happened to work with
 * the current driver and would have silently turned duplicate-key errors into
 * 500s the moment the wording changed.
 */
describe("db error classification", () => {
  it("detects a unique violation by SQLSTATE", () => {
    expect(isUniqueViolation(Object.assign(new Error("dup"), { code: "23505" }))).toBe(true);
  });

  it("detects a unique violation nested under cause (drizzle wrapping)", () => {
    const wrapped = Object.assign(new Error("Failed query"), {
      cause: Object.assign(new Error("dup"), { code: "23505" }),
    });
    expect(isUniqueViolation(wrapped)).toBe(true);
  });

  it("detects a foreign key violation", () => {
    expect(
      isForeignKeyViolation(Object.assign(new Error("fk"), { code: "23503" }))
    ).toBe(true);
  });

  it("does not confuse the two", () => {
    const fk = Object.assign(new Error("fk"), { code: "23503" });
    expect(isUniqueViolation(fk)).toBe(false);
  });

  it("is safe on non-errors", () => {
    expect(isUniqueViolation(null)).toBe(false);
    expect(isUniqueViolation(undefined)).toBe(false);
    expect(isUniqueViolation("unique")).toBe(false);
    expect(isUniqueViolation({})).toBe(false);
  });

  it("does not match on message text alone", () => {
    // The old implementation would have returned true here.
    expect(isUniqueViolation(new Error("violates unique constraint"))).toBe(false);
  });
});
