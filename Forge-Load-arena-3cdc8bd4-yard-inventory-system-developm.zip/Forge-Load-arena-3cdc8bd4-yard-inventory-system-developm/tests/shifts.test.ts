import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { PGlite } from "@electric-sql/pglite";
import { createTestDb, seedFixtures } from "./helpers/db";

/**
 * The shift ledger, against real Postgres.
 *
 * The thing worth testing is what the database refuses: a second open shift
 * for the same person, a closed shift with no clock-out time, a clock-out
 * before the clock-in. Those are the guards that keep the timesheet honest
 * when a phone retries a request or two devices scan the same badge.
 */

let db: PGlite;
let userId: string;
let siteId: string;

beforeAll(async () => {
  db = await createTestDb();
  ({ userId } = await seedFixtures(db));
  const site = await db.query<{ id: string }>(
    `INSERT INTO sites (name, token, latitude, longitude, radius_m)
     VALUES ('Main shop', 'TESTSHOP01', 29.9807, -92.1163, 250) RETURNING id`
  );
  siteId = site.rows[0].id;
});

afterAll(async () => {
  await db.close();
});

async function openShift(uid: string, clientUuid: string) {
  return db.query<{ id: string }>(
    `INSERT INTO shifts (client_uuid, user_id, site_id, method)
     VALUES ($1, $2, $3, 'qr') RETURNING id`,
    [clientUuid, uid, siteId]
  );
}

describe("shifts: one open shift per person", () => {
  it("refuses a second active shift for the same user", async () => {
    await openShift(userId, "shift-a");
    await expect(openShift(userId, "shift-b")).rejects.toMatchObject({ code: "23505" });
  });

  it("allows a new shift once the previous one is closed", async () => {
    await db.query(
      `UPDATE shifts SET status = 'closed', clock_out_at = now() WHERE user_id = $1 AND status = 'active'`,
      [userId]
    );
    const { rows } = await openShift(userId, "shift-c");
    expect(rows[0].id).toBeTruthy();
  });

  it("is idempotent on client_uuid, which is what makes offline retry safe", async () => {
    await expect(openShift(userId, "shift-c")).rejects.toMatchObject({ code: "23505" });
  });

  it("lets a different user clock in at the same time", async () => {
    const other = await db.query<{ id: string }>(
      `INSERT INTO users (email, password_hash, full_name, role)
       VALUES ('other@test.local', 'x', 'Other Crew', 'crew') RETURNING id`
    );
    const { rows } = await openShift(other.rows[0].id, "shift-d");
    expect(rows[0].id).toBeTruthy();
  });
});

describe("shifts: the clock can't lie", () => {
  it("won't close a shift without a clock-out time", async () => {
    await expect(
      db.query(`UPDATE shifts SET status = 'closed' WHERE client_uuid = 'shift-c'`)
    ).rejects.toMatchObject({ code: "23514" });
  });

  it("won't accept a clock-out earlier than the clock-in", async () => {
    await expect(
      db.query(
        `UPDATE shifts SET status = 'closed', clock_out_at = clock_in_at - interval '1 hour'
         WHERE client_uuid = 'shift-c'`
      )
    ).rejects.toMatchObject({ code: "23514" });
  });

  it("rejects an unknown method or status", async () => {
    await expect(
      db.query(
        `INSERT INTO shifts (client_uuid, user_id, method) VALUES ('bad-method', $1, 'telepathy')`,
        [userId]
      )
    ).rejects.toMatchObject({ code: "23514" });
  });
});

describe("location pings", () => {
  it("stores a breadcrumb against an open shift", async () => {
    const shift = await db.query<{ id: string }>(
      `SELECT id FROM shifts WHERE client_uuid = 'shift-c'`
    );
    await db.query(
      `INSERT INTO location_pings (shift_id, user_id, latitude, longitude, accuracy_m, speed_mps, recorded_at)
       VALUES ($1, $2, 29.98, -92.11, 12, 14.2, now())`,
      [shift.rows[0].id, userId]
    );
    const { rows } = await db.query<{ c: number }>(
      `SELECT count(*)::int AS c FROM location_pings WHERE shift_id = $1`,
      [shift.rows[0].id]
    );
    expect(rows[0].c).toBe(1);
  });

  it("rejects coordinates that aren't on the planet", async () => {
    const shift = await db.query<{ id: string }>(
      `SELECT id FROM shifts WHERE client_uuid = 'shift-c'`
    );
    await expect(
      db.query(
        `INSERT INTO location_pings (shift_id, user_id, latitude, longitude, recorded_at)
         VALUES ($1, $2, 95, -92.11, now())`,
        [shift.rows[0].id, userId]
      )
    ).rejects.toMatchObject({ code: "23514" });
  });
});

describe("sites", () => {
  it("only accepts scanner-friendly tokens", async () => {
    await expect(
      db.query(`INSERT INTO sites (name, token) VALUES ('Bad', 'lower-case!')`)
    ).rejects.toMatchObject({ code: "23514" });
  });

  it("tokens are unique", async () => {
    await expect(
      db.query(`INSERT INTO sites (name, token) VALUES ('Dup', 'TESTSHOP01')`)
    ).rejects.toMatchObject({ code: "23505" });
  });
});

describe("itineraries", () => {
  it("records that a person saw an order exactly once", async () => {
    const it = await db.query<{ id: string }>(
      `INSERT INTO itineraries (for_date, title, created_by)
       VALUES ('2026-09-05', 'Clean the yard', $1) RETURNING id`,
      [userId]
    );
    await db.query(
      `INSERT INTO itinerary_acks (itinerary_id, user_id) VALUES ($1, $2)`,
      [it.rows[0].id, userId]
    );
    // A second delivery (re-scan, reload) must not create a second ack; the
    // API uses ON CONFLICT DO NOTHING against exactly this constraint.
    await expect(
      db.query(`INSERT INTO itinerary_acks (itinerary_id, user_id) VALUES ($1, $2)`, [
        it.rows[0].id,
        userId,
      ])
    ).rejects.toMatchObject({ code: "23505" });
  });

  it("requires a real calendar day", async () => {
    await expect(
      db.query(
        `INSERT INTO itineraries (for_date, title, created_by) VALUES ('tomorrow', 'x', $1)`,
        [userId]
      )
    ).rejects.toMatchObject({ code: "23514" });
  });
});

describe("vehicle checks", () => {
  it("stores the checklist as JSON and enforces the rolled-up status", async () => {
    const v = await db.query<{ id: string }>(
      `INSERT INTO vehicles (name, plate) VALUES ('Truck 1', 'LA12345') RETURNING id`
    );
    await db.query(
      `INSERT INTO vehicle_checks (client_uuid, vehicle_id, user_id, check_date, items, status, odometer)
       VALUES ('chk-1', $1, $2, '2026-09-04', '{"oil":"ok","brakes":"bad"}'::jsonb, 'needs_repair', 184200)`,
      [v.rows[0].id, userId]
    );
    await expect(
      db.query(
        `INSERT INTO vehicle_checks (client_uuid, vehicle_id, user_id, check_date, items, status)
         VALUES ('chk-2', $1, $2, '2026-09-04', '{}'::jsonb, 'fine')`,
        [v.rows[0].id, userId]
      )
    ).rejects.toMatchObject({ code: "23514" });
  });
});
