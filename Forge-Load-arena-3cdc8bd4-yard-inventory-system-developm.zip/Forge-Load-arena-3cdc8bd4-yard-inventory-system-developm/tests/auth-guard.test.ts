import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

/**
 * The JWT secret guard is load-time behaviour, so each case needs a fresh
 * module registry.
 */
describe("JWT_SECRET guard", () => {
  const original = { ...process.env };

  beforeEach(() => {
    vi.resetModules();
    // auth.ts imports the db module, which requires a connection string to be
    // present at import time. It's never actually connected to in these tests.
    process.env.DATABASE_URL ??= "postgresql://u:p@127.0.0.1:5432/postgres";
  });
  afterEach(() => { process.env = { ...original }; });

  it("refuses to load in production without JWT_SECRET", async () => {
    vi.stubEnv("NODE_ENV", "production");
    delete process.env.JWT_SECRET;
    await expect(import("@/lib/auth")).rejects.toThrow(/JWT_SECRET is required/);
    vi.unstubAllEnvs();
  });

  it("refuses a too-short secret in production", async () => {
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("JWT_SECRET", "tooshort");
    await expect(import("@/lib/auth")).rejects.toThrow(/at least 32 characters/);
    vi.unstubAllEnvs();
  });

  it("loads with a strong secret", async () => {
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("JWT_SECRET", "a".repeat(48));
    const mod = await import("@/lib/auth");
    expect(typeof mod.createToken).toBe("function");
    vi.unstubAllEnvs();
  });

  it("round-trips a session token", async () => {
    vi.stubEnv("JWT_SECRET", "b".repeat(48));
    const { createToken, verifyToken } = await import("@/lib/auth");
    const user = { id: "u1", email: "a@b.com", fullName: "A B", role: "admin" as const };
    const token = await createToken(user);
    const decoded = await verifyToken(token);
    expect(decoded?.id).toBe("u1");
    expect(decoded?.role).toBe("admin");
    vi.unstubAllEnvs();
  });

  it("rejects a token signed with a different secret", async () => {
    vi.stubEnv("JWT_SECRET", "c".repeat(48));
    const first = await import("@/lib/auth");
    const token = await first.createToken({ id: "u1", email: "a@b.com", fullName: "A", role: "crew" });

    vi.resetModules();
    vi.stubEnv("JWT_SECRET", "d".repeat(48));
    const second = await import("@/lib/auth");
    expect(await second.verifyToken(token)).toBeNull();
    vi.unstubAllEnvs();
  });
});
