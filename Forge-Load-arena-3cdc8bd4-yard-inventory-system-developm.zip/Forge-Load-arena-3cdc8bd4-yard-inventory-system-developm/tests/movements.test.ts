import { describe, it, expect, beforeEach, afterEach } from "vitest";
import type { PGlite } from "@electric-sql/pglite";
import { createTestDb, seedFixtures, applyMovement, type Fixtures } from "./helpers/db";
import { randomUUID } from "node:crypto";

/**
 * These cover the riskiest logic in the app: the ledger + balance must never
 * disagree, and the yard must never hand out more than it has.
 */
describe("movements", () => {
  let db: PGlite;
  let fx: Fixtures;

  beforeEach(async () => {
    db = await createTestDb();
    fx = await seedFixtures(db, { qty: 100 });
  });

  afterEach(async () => {
    await db.close();
  });

  const pull = (delta: number, clientUuid = randomUUID()) =>
    applyMovement(db, { ...fx, employeeId: fx.userId, clientUuid, delta });

  const qtyOf = async () => {
    const r = await db.query<{ qty_remaining: string; status: string }>(
      `SELECT qty_remaining, status FROM bundles WHERE id = $1`,
      [fx.bundleId]
    );
    return { qty: Number(r.rows[0].qty_remaining), status: r.rows[0].status };
  };

  it("decrements the bundle on a pull", async () => {
    const result = await pull(-30);
    expect(result.ok).toBe(true);
    expect((await qtyOf()).qty).toBe(70);
  });

  it("adds quantity back on a return", async () => {
    await pull(-30);
    await pull(+10);
    expect((await qtyOf()).qty).toBe(80);
  });

  it("refuses a pull larger than what remains", async () => {
    const result = await pull(-150);
    expect(result.ok).toBe(false);
    expect(result.reason).toBe("insufficient");
    // and the ledger must not have kept the rejected row
    const count = await db.query<{ c: number }>(
      `SELECT COUNT(*)::int AS c FROM movements WHERE bundle_id = $1`,
      [fx.bundleId]
    );
    expect(count.rows[0].c).toBe(0);
    expect((await qtyOf()).qty).toBe(100);
  });

  it("retires the bundle when it hits zero", async () => {
    await pull(-100);
    const { qty, status } = await qtyOf();
    expect(qty).toBe(0);
    expect(status).toBe("retired");
  });

  it("blocks further movements once retired", async () => {
    await pull(-100);
    const result = await pull(-1);
    expect(result.ok).toBe(false);
  });

  it("treats a replayed clientUuid as idempotent (offline retry)", async () => {
    const uuid = randomUUID();
    const first = await pull(-25, uuid);
    const second = await pull(-25, uuid);

    expect(first.ok).toBe(true);
    expect(second.ok).toBe(true);
    expect(second.reason).toBe("idempotent");

    // Applied exactly once, despite two submissions.
    expect((await qtyOf()).qty).toBe(75);
    const count = await db.query<{ c: number }>(
      `SELECT COUNT(*)::int AS c FROM movements WHERE bundle_id = $1`,
      [fx.bundleId]
    );
    expect(count.rows[0].c).toBe(1);
  });

  it("never oversells under concurrent pulls", async () => {
    // Ten crew members each try to pull 20 from a bundle of 100.
    // Exactly five can succeed; the rest must be refused.
    const attempts = Array.from({ length: 10 }, () =>
      pull(-20).catch(() => ({ ok: false as const }))
    );
    const results = await Promise.all(attempts);

    const succeeded = results.filter((r) => r.ok).length;
    expect(succeeded).toBe(5);

    const { qty } = await qtyOf();
    expect(qty).toBe(0);
    expect(qty).toBeGreaterThanOrEqual(0);
  });

  it("keeps the ledger and the balance in agreement", async () => {
    await pull(-10);
    await pull(-5);
    await pull(+3);
    await pull(-40);

    const sum = await db.query<{ total: string }>(
      `SELECT COALESCE(SUM(qty_delta), 0) AS total FROM movements WHERE bundle_id = $1`,
      [fx.bundleId]
    );
    const { qty } = await qtyOf();

    // Bundle started at 100; the ledger deltas must explain the balance exactly.
    expect(100 + Number(sum.rows[0].total)).toBe(qty);
  });

  it("rejects an unknown movement type at the database level", async () => {
    await expect(
      applyMovement(db, {
        ...fx,
        employeeId: fx.userId,
        clientUuid: randomUUID(),
        delta: -1,
        type: "shenanigans",
      })
    ).rejects.toThrow();
  });
});
