import { describe, it, expect } from "vitest";
import { normalizeScannedValue } from "@/lib/scanner";

/**
 * Labels in the field encode a full URL, but crew also type codes by hand and
 * older labels may hold a bare code. All three have to resolve to the same thing.
 */
describe("normalizeScannedValue", () => {
  it("extracts the code from a full label URL", () => {
    expect(normalizeScannedValue("https://yard.example.com/bundle/BND-2026-000123")).toBe(
      "BND-2026-000123"
    );
  });

  it("handles a URL with a trailing slash or query string", () => {
    expect(normalizeScannedValue("https://yard.example.com/bundle/BND-2026-000123?x=1")).toBe(
      "BND-2026-000123"
    );
    expect(normalizeScannedValue("https://yard.example.com/bundle/BND-2026-000123#top")).toBe(
      "BND-2026-000123"
    );
  });

  it("passes a bare code straight through", () => {
    expect(normalizeScannedValue("BND-2026-000123")).toBe("BND-2026-000123");
  });

  it("upper-cases and trims hand-typed input", () => {
    expect(normalizeScannedValue("  bnd-2026-000123 ")).toBe("BND-2026-000123");
  });

  it("handles a URL printed from a different host", () => {
    // Labels printed from staging still have to scan against production.
    expect(normalizeScannedValue("http://localhost:3000/bundle/BND-2026-000999")).toBe(
      "BND-2026-000999"
    );
  });

  it("decodes percent-encoded codes", () => {
    expect(normalizeScannedValue("https://y.example/bundle/BND%2D2026%2D000123")).toBe(
      "BND-2026-000123"
    );
  });
});
