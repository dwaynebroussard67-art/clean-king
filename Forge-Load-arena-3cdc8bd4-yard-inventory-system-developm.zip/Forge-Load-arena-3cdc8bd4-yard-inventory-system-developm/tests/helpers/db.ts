import { PGlite } from "@electric-sql/pglite";
import { readdirSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

/**
 * Spin up a real Postgres (PGlite runs the actual engine compiled to WASM) and
 * apply every production migration to it, in order. Testing the movement logic
 * against a mock would defeat the point — the behaviour we care about is
 * concurrency and constraint enforcement, which only the real engine
 * reproduces.
 *
 * The migration list is read from disk rather than hard-coded so a new
 * migration is covered by the existing tests the moment it lands.
 */
export async function createTestDb() {
  const db = new PGlite();
  const dir = resolve(process.cwd(), "drizzle");

  const files = readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  for (const file of files) {
    const statements = readFileSync(resolve(dir, file), "utf8")
      .split("--> statement-breakpoint")
      .map((s) => s.trim())
      .filter(Boolean);

    for (const statement of statements) {
      await db.exec(statement);
    }
  }

  return db;
}

export interface Fixtures {
  userId: string;
  productId: string;
  bundleId: string;
}

/** A product with one 100-piece bundle, and a crew user to attribute moves to. */
export async function seedFixtures(
  db: PGlite,
  { qty = 100 }: { qty?: number } = {}
): Promise<Fixtures> {
  const user = await db.query<{ id: string }>(
    `INSERT INTO users (email, password_hash, full_name, role)
     VALUES ('crew@test.local', 'x', 'Test Crew', 'crew') RETURNING id`
  );
  const product = await db.query<{ id: string }>(
    `INSERT INTO products (sku, name, base_unit) VALUES ('TEST-SKU', 'Test Product', 'piece') RETURNING id`
  );
  const bundle = await db.query<{ id: string }>(
    `INSERT INTO bundles (code, product_id, unit, qty_received, qty_remaining, status)
     VALUES ('BND-TEST-000001', $1, 'piece', $2, $2, 'active') RETURNING id`,
    [product.rows[0].id, qty]
  );

  return {
    userId: user.rows[0].id,
    productId: product.rows[0].id,
    bundleId: bundle.rows[0].id,
  };
}

/**
 * The exact atomic write the movements route performs. Kept in one place so the
 * tests exercise the same SQL shape the API uses: the bounds check lives inside
 * the UPDATE, so a losing writer matches zero rows instead of overselling.
 */
export async function applyMovement(
  db: PGlite,
  {
    bundleId,
    productId,
    employeeId,
    clientUuid,
    delta,
    type = "pull",
  }: {
    bundleId: string;
    productId: string;
    employeeId: string;
    clientUuid: string;
    delta: number;
    type?: string;
  }
): Promise<{ ok: boolean; reason?: string; qtyRemaining?: number }> {
  await db.exec("BEGIN");
  try {
    try {
      await db.query(
        `INSERT INTO movements
           (client_uuid, bundle_id, product_id, type, qty_delta, unit, employee_id, device_time)
         VALUES ($1, $2, $3, $4, $5, 'piece', $6, now())`,
        [clientUuid, bundleId, productId, type, String(delta), employeeId]
      );
    } catch (err) {
      const code = (err as { code?: string }).code;
      if (code === "23505") {
        await db.exec("ROLLBACK");
        return { ok: true, reason: "idempotent" };
      }
      throw err;
    }

    const updated = await db.query<{ qty_remaining: string }>(
      `UPDATE bundles
          SET qty_remaining = qty_remaining + $2::numeric,
              status = CASE WHEN qty_remaining + $2::numeric <= 0 THEN 'retired' ELSE status END
        WHERE id = $1
          AND status <> 'retired'
          AND qty_remaining + $2::numeric >= 0
        RETURNING qty_remaining`,
      [bundleId, String(delta)]
    );

    if (updated.rows.length === 0) {
      await db.exec("ROLLBACK");
      return { ok: false, reason: "insufficient" };
    }

    await db.exec("COMMIT");
    return { ok: true, qtyRemaining: Number(updated.rows[0].qty_remaining) };
  } catch (err) {
    await db.exec("ROLLBACK");
    throw err;
  }
}
