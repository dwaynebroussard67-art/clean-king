import { describe, it, expect } from "vitest";
import { sniffImageType, optionalNumber, MAX_PHOTO_BYTES } from "@/lib/photo-validation";

/**
 * The upload route decides what an image is from its bytes, not from the
 * Content-Type the client claims. These cases pin that behaviour down, because
 * the whole point is that a browser (or a hostile client) can lie in the
 * header but not in the first eight bytes.
 */
describe("sniffImageType", () => {
  const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46]);
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const webp = Buffer.concat([
    Buffer.from("RIFF"),
    Buffer.from([0, 0, 0, 0]),
    Buffer.from("WEBP"),
  ]);

  it("identifies a JPEG", () => {
    expect(sniffImageType(jpeg)).toBe("image/jpeg");
  });

  it("identifies a PNG", () => {
    expect(sniffImageType(png)).toBe("image/png");
  });

  it("identifies a WebP", () => {
    expect(sniffImageType(webp)).toBe("image/webp");
  });

  it("rejects a text file renamed to .jpg", () => {
    expect(sniffImageType(Buffer.from("GIF89a and then some"))).toBeNull();
  });

  it("rejects an empty buffer without throwing", () => {
    expect(sniffImageType(Buffer.alloc(0))).toBeNull();
  });

  it("rejects a truncated header", () => {
    expect(sniffImageType(Buffer.from([0xff, 0xd8]))).toBeNull();
  });

  it("ignores a JPEG signature that does not start at byte zero", () => {
    const padded = Buffer.concat([Buffer.from("junk"), jpeg]);
    expect(sniffImageType(padded)).toBeNull();
  });
});

describe("optionalNumber", () => {
  it("parses a numeric string", () => {
    expect(optionalNumber("42.5")).toBe(42.5);
  });

  it("returns null for blank, missing and junk values", () => {
    expect(optionalNumber(null)).toBeNull();
    expect(optionalNumber("")).toBeNull();
    expect(optionalNumber("   ")).toBeNull();
    expect(optionalNumber("banana")).toBeNull();
  });

  it("rejects non-finite values rather than storing Infinity", () => {
    expect(optionalNumber("Infinity")).toBeNull();
    expect(optionalNumber("NaN")).toBeNull();
  });
});

describe("photo size ceiling", () => {
  it("matches the CHECK constraint in the migration", () => {
    // The DB CHECK and the route's 413 threshold have to agree, or an upload
    // passes validation and then dies on insert with a 500.
    expect(MAX_PHOTO_BYTES).toBe(12 * 1024 * 1024);
  });
});
