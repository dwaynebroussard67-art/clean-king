import { describe, it, expect, beforeEach, afterEach } from "vitest";
import type { PGlite } from "@electric-sql/pglite";
import { createTestDb, seedFixtures, type Fixtures } from "./helpers/db";

/**
 * Damage reports are the evidence trail behind a claim, so the parts that must
 * hold are: the schema refuses nonsense, the code sequence never collides, and
 * a write-off can't push a bundle negative any more than a pull can.
 *
 * These run against the real engine with every migration applied, so the CHECK
 * constraints under test are the ones that ship.
 */
describe("damage reports", () => {
  let db: PGlite;
  let fx: Fixtures;

  beforeEach(async () => {
    db = await createTestDb();
    fx = await seedFixtures(db, { qty: 100 });
  });

  afterEach(async () => {
    await db.close();
  });

  const insertDamage = (overrides: Record<string, unknown> = {}) => {
    const row = {
      code: "DMG-2026-0001",
      reason: "forklift",
      severity: "minor",
      subject: "material",
      status: "open",
      reported_by: fx.userId,
      ...overrides,
    };
    return db.query<{ id: string }>(
      `INSERT INTO damage_reports (code, reason, severity, subject, status, reported_by, bundle_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
      [
        row.code,
        row.reason,
        row.severity,
        row.subject,
        row.status,
        row.reported_by,
        (row as { bundle_id?: string }).bundle_id ?? null,
      ]
    );
  };

  it("stores a minimal report", async () => {
    const res = await insertDamage();
    expect(res.rows[0].id).toMatch(/^[0-9a-f-]{36}$/);
  });

  it("rejects an invalid severity", async () => {
    await expect(insertDamage({ severity: "catastrophic" })).rejects.toThrow();
  });

  it("rejects an invalid subject", async () => {
    await expect(insertDamage({ subject: "feelings" })).rejects.toThrow();
  });

  it("rejects an invalid status", async () => {
    await expect(insertDamage({ status: "whatever" })).rejects.toThrow();
  });

  it("refuses two reports with the same code", async () => {
    await insertDamage();
    await expect(insertDamage()).rejects.toThrow();
  });

  it("treats a duplicate client_uuid as a collision, so offline retries stay idempotent", async () => {
    await insertDamage({ code: "DMG-2026-0100", client_uuid: "dup" }).catch(() => {});
    await db.query(
      `INSERT INTO damage_reports (code, reason, severity, reported_by, client_uuid)
       VALUES ('DMG-2026-0101', 'weather', 'minor', $1, 'offline-1')`,
      [fx.userId]
    );
    await expect(
      db.query(
        `INSERT INTO damage_reports (code, reason, severity, reported_by, client_uuid)
         VALUES ('DMG-2026-0102', 'weather', 'minor', $1, 'offline-1')`,
        [fx.userId]
      )
    ).rejects.toThrow(/duplicate key|unique/i);
  });

  it("hands out sequential damage codes", async () => {
    const a = await db.query<{ n: string }>(`SELECT nextval('damage_code_seq') AS n`);
    const b = await db.query<{ n: string }>(`SELECT nextval('damage_code_seq') AS n`);
    expect(Number(b.rows[0].n)).toBe(Number(a.rows[0].n) + 1);
  });

  it("keeps the report after the bundle is retired, because the claim outlives the stock", async () => {
    const dmg = await insertDamage({ bundle_id: fx.bundleId });
    await db.query(`UPDATE bundles SET status = 'retired' WHERE id = $1`, [fx.bundleId]);

    const found = await db.query<{ id: string; bundle_id: string }>(
      `SELECT id, bundle_id FROM damage_reports WHERE id = $1`,
      [dmg.rows[0].id]
    );
    expect(found.rows[0].bundle_id).toBe(fx.bundleId);
  });
});

/**
 * A write-off is an `adjust` movement plus a guarded decrement — the same
 * invariant a pull uses. If it ever diverges, damage becomes a way to drive
 * inventory negative.
 */
describe("damage write-off", () => {
  let db: PGlite;
  let fx: Fixtures;

  beforeEach(async () => {
    db = await createTestDb();
    fx = await seedFixtures(db, { qty: 10 });
  });

  afterEach(async () => {
    await db.close();
  });

  const writeOff = async (n: number) => {
    const updated = await db.query<{ qty_remaining: string; status: string }>(
      `UPDATE bundles
          SET qty_remaining = qty_remaining - $2::numeric,
              status = CASE WHEN qty_remaining - $2::numeric <= 0 THEN 'retired' ELSE status END
        WHERE id = $1
          AND qty_remaining - $2::numeric >= 0
        RETURNING qty_remaining, status`,
      [fx.bundleId, String(n)]
    );
    return updated.rows[0] ?? null;
  };

  it("decrements the bundle by the damaged quantity", async () => {
    const row = await writeOff(3);
    expect(Number(row?.qty_remaining)).toBe(7);
    expect(row?.status).toBe("active");
  });

  it("refuses to write off more than remains", async () => {
    expect(await writeOff(11)).toBeNull();

    const check = await db.query<{ qty_remaining: string }>(
      `SELECT qty_remaining FROM bundles WHERE id = $1`,
      [fx.bundleId]
    );
    expect(Number(check.rows[0].qty_remaining)).toBe(10);
  });

  it("retires the bundle when damage consumes the last piece", async () => {
    const row = await writeOff(10);
    expect(Number(row?.qty_remaining)).toBe(0);
    expect(row?.status).toBe("retired");
  });

  it("links the movement it created so the audit trail is two-way", async () => {
    const mv = await db.query<{ id: string }>(
      `INSERT INTO movements (client_uuid, bundle_id, product_id, type, qty_delta, unit, employee_id, device_time)
       VALUES ('dmg-1', $1, $2, 'adjust', '-4', 'piece', $3, now()) RETURNING id`,
      [fx.bundleId, fx.productId, fx.userId]
    );
    await db.query(
      `INSERT INTO damage_reports (code, reason, severity, reported_by, bundle_id, movement_id, write_off, qty_affected)
       VALUES ('DMG-2026-0500', 'forklift', 'total', $1, $2, $3, true, '4')`,
      [fx.userId, fx.bundleId, mv.rows[0].id]
    );

    const joined = await db.query<{ qty_delta: string; qty_affected: string }>(
      `SELECT m.qty_delta, d.qty_affected
         FROM damage_reports d JOIN movements m ON m.id = d.movement_id
        WHERE d.code = 'DMG-2026-0500'`
    );
    expect(joined.rows[0].qty_delta).toBe("-4");
    expect(Number(joined.rows[0].qty_affected)).toBe(4);
  });
});

/** Photo rows are the evidence; the constraints protecting them matter. */
describe("photos table", () => {
  let db: PGlite;
  let fx: Fixtures;

  beforeEach(async () => {
    db = await createTestDb();
    fx = await seedFixtures(db);
  });

  afterEach(async () => {
    await db.close();
  });

  const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x01, 0x02, 0x03, 0x04]);

  it("round-trips binary data with a matching byte count", async () => {
    await db.query(
      `INSERT INTO photos (subject_type, subject_id, data, content_type, byte_size, taken_by)
       VALUES ('product', $1, $2, 'image/jpeg', $3, $4)`,
      [fx.productId, jpeg, jpeg.length, fx.userId]
    );

    const res = await db.query<{ len: number; byte_size: number }>(
      `SELECT octet_length(data) AS len, byte_size FROM photos WHERE subject_id = $1`,
      [fx.productId]
    );
    expect(res.rows[0].len).toBe(jpeg.length);
    expect(res.rows[0].byte_size).toBe(jpeg.length);
  });

  it("accepts a load-out photo, since most product is picked up rather than delivered", async () => {
    await db.query(
      `INSERT INTO photos (subject_type, data, content_type, byte_size, taken_by)
       VALUES ('load', $1, 'image/jpeg', $2, $3)`,
      [jpeg, jpeg.length, fx.userId]
    );
    const res = await db.query<{ c: number }>(
      `SELECT COUNT(*)::int AS c FROM photos WHERE subject_type = 'load'`
    );
    expect(res.rows[0].c).toBe(1);
  });

  it("keeps load and delivery as separate subjects, because they refute different claims", async () => {
    for (const kind of ["load", "delivery"]) {
      await db.query(
        `INSERT INTO photos (subject_type, subject_id, data, content_type, byte_size, taken_by)
         VALUES ($1, $2, $3, 'image/jpeg', $4, $5)`,
        [kind, fx.productId, jpeg, jpeg.length, fx.userId]
      );
    }
    const res = await db.query<{ subject_type: string }>(
      `SELECT subject_type FROM photos WHERE subject_id = $1 ORDER BY subject_type`,
      [fx.productId]
    );
    expect(res.rows.map((r) => r.subject_type)).toEqual(["delivery", "load"]);
  });

  it("rejects an unknown subject_type", async () => {
    await expect(
      db.query(
        `INSERT INTO photos (subject_type, data, content_type, byte_size, taken_by)
         VALUES ('selfie', $1, 'image/jpeg', $2, $3)`,
        [jpeg, jpeg.length, fx.userId]
      )
    ).rejects.toThrow();
  });

  it("rejects a byte_size above the ceiling the route enforces", async () => {
    await expect(
      db.query(
        `INSERT INTO photos (subject_type, data, content_type, byte_size, taken_by)
         VALUES ('damage', $1, 'image/jpeg', $2, $3)`,
        [jpeg, 13 * 1024 * 1024, fx.userId]
      )
    ).rejects.toThrow();
  });

  it("rejects a zero or negative byte_size", async () => {
    await expect(
      db.query(
        `INSERT INTO photos (subject_type, data, content_type, byte_size, taken_by)
         VALUES ('damage', $1, 'image/jpeg', 0, $2)`,
        [jpeg, fx.userId]
      )
    ).rejects.toThrow();
  });
});
