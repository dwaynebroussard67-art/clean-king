# Forge Load / Earl's Furniture — Launch Readiness

_Originally assessed 2026-08-15 against commit `542d80f`. Updated through
the Forge Load fleet/shift features and Earl's Furniture instance conversion
(`earls-furniture` default, ITM- code sequence, furniture terms)._

## Where things stand

| Gate | Before | Now |
| --- | --- | --- |
| `tsc --noEmit` | ✅ clean | ✅ clean |
| `next build` | ✅ 23 routes | ✅ 40 routes + proxy |
| `eslint .` | ❌ 5 errors | ✅ clean |
| Tests | ❌ none | ✅ 178 passing, real Postgres |
| Migrations | ❌ none | ✅ `0000_init`, `0001_camera…`, `0002_load_out_photos`, `0003_shifts_fleet_itineraries` |
| CI | ❌ none | ✅ staged in `ci/` (see note) |
| Docs | ❌ none | ✅ README + `.env.example` + LAUNCH_READINESS |
| Camera / photos | ❌ none | ✅ intake, damage, load-out, delivery |
| Fleet & Shifts | ❌ none | ✅ QR clock-in, live GPS map, morning truck checks, next-day orders |
| Multi-tenant | ❌ hardcoded brand | ✅ one env var, Earl's Furniture instance default (`ITM-` codes) |

---

## Credential: closed out

The Supabase connection string that was committed in `drizzle.config.json` is
gone. It is not reachable from any ref in the repository, and the four branches
that still carried it (`first-sale-launch`, `vercel-launch`,
`claude/app-status-check-lql7fo`, `claude/forge-load-fixes`) have been deleted.
Only `master` and the working branch remain.

**No rotation needed.** The repo was never cloned and the database was never
live, so nothing was ever exposed to anyone. Confirmed by the owner. The config
now reads `DATABASE_URL` from the environment and throws if it is missing, so
the same mistake can't be re-committed.

---

## ✅ Fixed in this pass

### Security

- **Credential removed from the config and from this branch's history.**
  `drizzle.config.ts` now reads `DATABASE_URL` and throws if it's missing.
  Verified: no object reachable from this branch contains the secret.
- **Deleted the `/api/setup` backdoor.** It was public and unauthenticated and
  created `admin@forgeload.com / admin123`. Replaced with `npm run db:seed`,
  which requires explicit env config, won't create a second admin without
  `--force`, generates a strong password when you don't supply one, and prints
  it exactly once. Confirmed the route now 404s.
- **`JWT_SECRET` fails fast.** Production refuses to boot without a secret of at
  least 32 characters instead of falling back to a value published in the
  source. Covered by tests, including that a token signed with a different
  secret is rejected.
- **Login is rate limited** — 5 attempts per account and 30 per IP per 15
  minutes, plus a dummy bcrypt comparison so response timing doesn't reveal
  which emails exist. Verified: the 6th attempt returns 429.
- **Password policy enforced in the API** (min 10 chars), not just as UI
  placeholder text.
- **Server-side route protection** via `src/proxy.ts`. `/admin` and `/receiving`
  now redirect anonymous users to login (preserving `?next=`) and bounce
  non-admins home. Verified for both anonymous and crew sessions.

### Data integrity

- **Movement attribution can no longer be spoofed.** `employeeId` comes from the
  session, not the request body. Verified end-to-end: a crew user posting a
  movement claiming the admin's ID is still recorded as the crew member.
- **The oversell race is fixed.** The bounds check now lives inside the `UPDATE`
  rather than being a read-then-check-then-write. Verified under real concurrent
  load: ten simultaneous pulls of 40 against a 200-piece bundle produced exactly
  five successes, five 422s, and a bundle at 0 — never negative.
- **Transactions everywhere they were missing.** Movements write the ledger row
  and the balance atomically; receipts build in one transaction so a failure
  can't leave orphaned bundles. Bundle codes are now allocated in one batch
  instead of one round-trip per bundle.
- **Database-level guards** in the migration: non-negative quantities, valid
  status/role/type values, and case-insensitive uniqueness on emails and SKUs
  (previously `Admin@x.com` and `admin@x.com` could both exist, and the second
  was unreachable because login lower-cases before lookup).
- **Postgres errors classified by SQLSTATE**, not by matching message text.
- **Product deletion no longer 500s.** Products with history are retired;
  only never-received products are hard-deleted.

### Scanning — the mixed iPhone/Android fleet

- **iOS now scans.** `BarcodeDetector` doesn't exist in iOS Safari, and the old
  code checked for it and then silently did nothing — the camera opened and
  never scanned, with no error. There's now a ZXing fallback, lazily imported so
  Android phones don't download a decoder they'll never use. Android still uses
  the faster native path; the active engine is labelled under the viewfinder,
  which is the first thing to check when someone reports a scanning problem.
- **Dead-end states explained.** Insecure origin, denied permission, or no
  camera now produce a specific message pointing at manual entry.
- **Input normalised** so label URLs, bare codes, and hand-typed lowercase all
  resolve identically. Manual entry auto-capitalises and disables autocorrect.

### Offline

- **Service worker added**, so a reload in a dead spot no longer yields a blank
  screen. App shell is stale-while-revalidate; GET APIs are network-first with a
  cache fallback; mutations are never intercepted and stay owned by the queue.
- **The missing icons now exist.** The manifest referenced `/icon-192.png`,
  which had never been created. They're now generated per tenant at build time
  from the monogram and accent colour rather than shipped as static files.
- **Permanent rejections are separated from transient failures.** A movement the
  yard refuses (bundle ran out while you were offline) is parked as `rejected`
  and surfaced on the dashboard instead of silently retrying forever.
- **Damage reports work offline too.** The report and its photo Blobs are held
  in IndexedDB and sent when signal returns, so a crew in a dead corner of the
  yard no longer loses the evidence the feature exists to capture.
- **`/queue` shows what the yard refused**, with the server's reason, and lets a
  crew member discard an entry once they've reconciled it by hand. Previously
  the dashboard reported a count and offered no way to act on it.

### Also

- Bundle search runs in SQL instead of filtering the newest 200 rows in memory,
  which had been reporting older bundles as nonexistent.
- `?next=` is honoured on login, so scanning a QR while logged out reaches the
  bundle. Only same-origin paths are accepted.
- Printed labels use `NEXT_PUBLIC_APP_URL`, with a visible warning before you
  print a batch that would bake a preview host into physical labels.
- 35 tests against real Postgres (PGlite), a local dev database needing no
  Docker (`npm run dev:db`), and `npm run verify` as one gate.
- All lint errors cleared; `useAuth` rewritten to avoid cascading renders.

---

## Note on CI

The pipeline is written and ready at `ci/github-actions-ci.yml`, but it is
**not active**. GitHub rejected the push because the app that authenticated this
session lacks the `workflows` permission. To turn it on:

```bash
mkdir -p .github/workflows
git mv ci/github-actions-ci.yml .github/workflows/ci.yml
git commit -m "Enable CI" && git push
```

It runs typecheck, lint, tests, and a build — plus a secret scan that fails the
build if a connection string with an embedded password is ever committed again.

---

## 📷 The camera system (built this session)

The pitch is that crews point a phone at things instead of writing them down.
Three places where typing used to happen now don't need it.

### New item intake — `/intake`

Photograph the item, name it, tap the count. The photo becomes the product's
catalogue image, bundles are minted, and the QR labels come up ready to print.
A SKU is generated when nobody supplies one, because inventing a SKU scheme
isn't a job for someone standing in the yard holding a phone.

Admin-only, since it creates catalogue entries.

### Damage logging — `/damage`

The camera opens first; taking the picture is what files the report. Everything
answerable without typing is captured automatically:

| Field | Where it comes from |
| --- | --- |
| Who | the session — never the request body |
| When | server clock, plus the device clock for offline ordering |
| Where | device GPS plus the bundle's yard location |
| What | the scanned bundle → product, unit, customer via the job |
| Why | a grid of buttons (forklift, strapping, weather, defect, transit, handling) |
| How bad | minor / major / total |
| Stage | receiving / storage / loading / delivery / return |

A report can also write the damaged quantity out of inventory in the same
action. That path reuses the movements invariant — an `adjust` movement plus a
guarded decrement — so damage can never drive stock negative, and it 409s with
the actual remaining count when someone tries to write off more than exists.

Not every report is about material. Yard property, equipment, and vehicles can
be logged with no bundle attached at all.

### Proof it left the yard — on the job page

Two galleries, because material leaves two ways and the resulting arguments are
different.

**Load-out** is the common one — roughly nine loads in ten are picked up: the
customer backs their own truck in, it gets loaded, they drive off. Nothing was
ever "delivered", so the claim that comes back is *"you never loaded it"* or
*"that was never on the truck."* The crew photographs the loaded truck before
it pulls off, and that's the refutation.

**Delivery** covers the rest, where the driver photographs the load where it
was dropped.

Both are timestamped and GPS-tagged. Closed jobs are read-only. A single job
can carry both, which happens when an order is split between pickup and drop.

The load-out camera is also offered on the pull success screen, since the crew
is standing at the truck with the phone already in their hand at that exact
moment. Asking them to come back to the job page for it later means it never
happens.

### Review — Admin → Damage

Reports were write-only until this: crews could file them and nobody could see
them, which is how a reporting feature quietly dies. The tab shows the photo,
the auto-captured context, a map link for the GPS fix, and review/resolve
actions. Only the status can change — the facts the crew captured are evidence.

### Decisions worth knowing about

**Photos live in Postgres as `bytea`, not on disk.** The deploy target is
serverless, where the filesystem is ephemeral and anything written to it
disappears between requests. Keeping the image beside the record also makes
backups atomic, which matters when the photo is the evidence behind a claim.
The client compresses to roughly 150–350 KB before upload.

**Uploads trust the bytes, not the headers.** Content type is sniffed from
magic numbers, so a text file renamed `.jpg` is refused rather than stored and
served back later. Serving is behind auth with `Cache-Control: private` — these
photos show customer sites, damage claims, and plates, and shouldn't land in a
shared CDN.

**Multipart, not base64 JSON.** Base64 inflates a payload by about a third,
which is real money on a phone with one bar in a metal-roofed yard.

**The camera degrades rather than failing.** Live `getUserMedia` is the primary
path; on an insecure origin, a denied permission, or an unsupported browser it
falls back to the native camera app via a file input, which works on both
iPhone and Android. Geolocation never blocks a capture — 6-second timeout, and
the photo saves without coordinates if the fix doesn't come.

---

## Still outstanding (nothing here blocks a pilot)

**Worth doing before the whole yard is on it**

- Photos are stored in Postgres as `bytea`. Right for now (see below), but
  watch the database size; at ~50 photos/day it's roughly 5 GB over a decade.
  `src/lib/photos.ts` is the only module touching the bytes, so a move to
  object storage is a one-file change.
- Damage photos are capped at 10 per report and never expire. If claims data
  needs a retention policy, that's a decision nobody has made yet.
- The AI assistant and photo extraction are unverified. They need a real
  `ANTHROPIC_API_KEY`; both correctly return 503 without one.
- `GET /api/movements` is unscoped — any crew user sees all yard activity.
  Probably fine for one yard, but it should be a conscious decision.
- No structured logging or error tracking. Add Sentry before you're supporting
  this over the phone.

**On the white-label goal**

The brand layer is done: name, mark, colour, manifest, cookie namespace, app
icons, the on-screen vocabulary and the assistant's wording all follow one env
var, and a fresh customer is one entry in `src/lib/tenant.ts`. Icons are
generated from the tenant's monogram and accent colour, so a new customer has a
correct home-screen icon with no design work; if they later supply real
artwork, `src/app/icon.tsx` and `apple-icon.tsx` are the only files to replace.

The vocabulary layer is worth understanding before adding a customer. The
database says `bundle` everywhere and always will — renaming columns per
customer would be madness. `TenantTerms` governs only the words a crew reads:
Forge Load says bundle/piece, Earl's says item/piece, and each tenant lists its
own measures so a furniture warehouse is never offered board feet.

It also covers the model, not just the words. Forge Load receives a bundle of
200 boards, so intake asks two numbers. Earl's moves single pieces of
furniture, so `groupsItems: false` collapses that to one question, with an
optional per-box count for the occasional boxed set of three tables. A test enforces that every tenant's `defaultMeasure` is one
of its own `measures`, since otherwise new products save a unit the dropdown
can't display.

What is *not* yet universal:

- **One deployment per customer, one database each.** That's the right shape
  for two or three customers and the wrong shape at twenty. Going further means
  either a `tenant_id` column on every table with row-level security, or a
  schema per customer. Both are real projects; neither should be started until
  a third paying customer makes it necessary.

**Adding a customer**

One entry in `TENANTS` (name, mark, monogram, accent, domain wording, terms),
then deploy with `NEXT_PUBLIC_TENANT` set to that key. Nothing else is
customer-specific. Verified for Earl's Furniture by changing that single
variable: manifest, colours, icons, cookie namespace, vocabulary and health
check all followed, with zero occurrences of "Forge Load", `board_ft`,
`linear_ft` or `orange-500` in any rendered page.

**Nice to have**

- `GET /api/products` is bounded at 1000 with limit/offset, and bundles at 500.
  Neither has a paging UI yet — a yard would have to pass the parameters by
  hand. Worth building the moment a catalogue gets big enough to notice.
- Photo retention: damage photos are capped at 10 per report and kept forever.

---

## Recommended next step

This is merged to `master` and ready. **Pilot with one crew for a week** before
putting the whole yard on it. The two failure modes that only appear under real
use — the oversell race and the offline gap — are both fixed and tested, but a
week of real traffic on real phones is what will tell you whether the scanner
fallback and the camera hold up across the actual mix of devices your people
carry.

For that pilot week, the things to watch are the ones no amount of local
testing can answer: whether the compression setting produces photos that are
actually legible when you zoom in on a cracked board, whether GPS gets a fix
under a metal roof often enough to be worth anything, and whether the crew
files damage reports at all once the novelty wears off. That last one is the
real test — the feature only pays for itself if it stays faster than saying
nothing.
