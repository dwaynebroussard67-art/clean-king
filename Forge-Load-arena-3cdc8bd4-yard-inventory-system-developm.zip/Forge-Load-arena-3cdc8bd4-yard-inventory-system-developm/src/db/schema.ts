import {
  pgTable,
  uuid,
  text,
  boolean,
  numeric,
  integer,
  timestamp,
  index,
  unique,
  customType,
  doublePrecision,
  jsonb,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

/**
 * Raw binary column for photo bytes.
 *
 * Photos live in Postgres rather than on disk because this app is expected to
 * run on serverless hosting, where the filesystem is ephemeral — images written
 * to disk would vanish on the next deploy. Keeping them in the database also
 * means one backup covers both the inventory record and its evidence, which
 * matters for damage claims.
 *
 * Images are downscaled and JPEG-compressed on the device before upload
 * (~150-350KB each), so a yard shooting 50 photos a day adds roughly 5GB over
 * a decade. If that ever becomes a problem, swap `photos.data` for an object
 * storage key — nothing outside src/lib/photos.ts reads the column directly.
 */
const bytea = customType<{ data: Buffer; notNull: false; default: false }>({
  dataType() {
    return "bytea";
  },
});

// ── USERS ───────────────────────────────────────────────────────────────────
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("crew"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── CUSTOMERS ────────────────────────────────────────────────────────────────
export const customers = pgTable("customers", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  ref: text("ref"),
  phone: text("phone"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── PRODUCTS ─────────────────────────────────────────────────────────────────
export const products = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  sku: text("sku").unique().notNull(),
  name: text("name").notNull(),
  category: text("category"),
  baseUnit: text("base_unit").notNull().default("piece"),
  piecesPerBundle: numeric("pieces_per_bundle"),
  reorderThreshold: numeric("reorder_threshold"),
  // Products are retired rather than deleted: bundles and movements reference
  // them, and the audit history has to stay readable years later.
  active: boolean("active").notNull().default(true),
  // Hero shot for the catalogue, so crew recognise material visually instead of
  // parsing SKUs. Deliberately not an FK: photos may be pruned independently,
  // and a dangling id just renders the placeholder.
  primaryPhotoId: uuid("primary_photo_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── RECEIPTS ─────────────────────────────────────────────────────────────────
export const receipts = pgTable("receipts", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").unique().notNull(),
  supplier: text("supplier"),
  poNumber: text("po_number"),
  notes: text("notes"),
  status: text("status").notNull().default("pending"),
  createdBy: uuid("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const receiptLines = pgTable("receipt_lines", {
  id: uuid("id").primaryKey().defaultRandom(),
  receiptId: uuid("receipt_id").notNull().references(() => receipts.id, { onDelete: "cascade" }),
  productId: uuid("product_id").notNull().references(() => products.id),
  qtyPerBundle: numeric("qty_per_bundle").notNull(),
  bundleCount: integer("bundle_count").notNull(),
  unit: text("unit").notNull().default("piece"),
});

// ── BUNDLES ──────────────────────────────────────────────────────────────────
export const bundles = pgTable("bundles", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").unique().notNull(),
  productId: uuid("product_id").notNull().references(() => products.id),
  unit: text("unit").notNull().default("piece"),
  qtyReceived: numeric("qty_received").notNull(),
  qtyRemaining: numeric("qty_remaining").notNull(),
  location: text("location"),
  status: text("status").notNull().default("active"),
  receiptId: uuid("receipt_id").references(() => receipts.id),
  receivedBy: uuid("received_by").references(() => users.id),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_bundles_product").on(t.productId),
  index("idx_bundles_status").on(t.status),
  index("idx_bundles_code").on(t.code),
]);

// ── JOBS ─────────────────────────────────────────────────────────────────────
export const jobs = pgTable("jobs", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").unique().notNull(),
  customerId: uuid("customer_id").references(() => customers.id),
  customerName: text("customer_name").notNull(),
  customerRef: text("customer_ref"),
  status: text("status").notNull().default("open"),
  notes: text("notes"),
  createdBy: uuid("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
}, (t) => [
  index("idx_jobs_customer").on(t.customerId),
]);

// ── MOVEMENTS ────────────────────────────────────────────────────────────────
export const movements = pgTable("movements", {
  id: uuid("id").primaryKey().defaultRandom(),
  clientUuid: text("client_uuid").unique().notNull(),
  bundleId: uuid("bundle_id").notNull().references(() => bundles.id),
  productId: uuid("product_id").notNull().references(() => products.id),
  type: text("type").notNull(),
  qtyDelta: numeric("qty_delta").notNull(),
  unit: text("unit").notNull(),
  jobId: uuid("job_id").references(() => jobs.id),
  employeeId: uuid("employee_id").notNull().references(() => users.id),
  deviceId: text("device_id"),
  deviceTime: timestamp("device_time", { withTimezone: true }).notNull(),
  serverTime: timestamp("server_time", { withTimezone: true }).notNull().defaultNow(),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_mov_bundle").on(t.bundleId),
  index("idx_mov_job").on(t.jobId),
  index("idx_mov_employee").on(t.employeeId),
  index("idx_mov_server_time").on(t.serverTime),
]);

// ── PHOTOS ───────────────────────────────────────────────────────────────────
/**
 * One row per captured image. Every photo is attached to something (a product,
 * a bundle, a damage report, a delivery) via `subjectType` + `subjectId` rather
 * than a hard FK, so new photo-bearing features don't need a schema change.
 *
 * Capture metadata is recorded automatically at the moment of capture — that's
 * the point of the feature. Nobody types any of this.
 */
export const photos = pgTable("photos", {
  id: uuid("id").primaryKey().defaultRandom(),

  // What this photo is of.
  subjectType: text("subject_type").notNull(), // product | bundle | damage | delivery | load
  subjectId: uuid("subject_id"),

  // Image itself.
  data: bytea("data").notNull(),
  contentType: text("content_type").notNull().default("image/jpeg"),
  byteSize: integer("byte_size").notNull(),
  width: integer("width"),
  height: integer("height"),

  // Automatic provenance — the "who/when/where" of the sales pitch.
  takenBy: uuid("taken_by").references(() => users.id),
  deviceId: text("device_id"),
  deviceTime: timestamp("device_time", { withTimezone: true }),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  accuracyM: doublePrecision("accuracy_m"),

  caption: text("caption"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_photos_subject").on(t.subjectType, t.subjectId),
  index("idx_photos_created").on(t.createdAt),
]);

// ── DAMAGE REPORTS ───────────────────────────────────────────────────────────
/**
 * A damage report is a photo plus the context the app can infer on its own.
 * The crew's job is: open the tab, point, shoot, tap a reason. Everything else
 * — who, when, where, which bundle, which job, which customer — is captured
 * without typing.
 */
export const damageReports = pgTable("damage_reports", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").unique().notNull(), // DMG-2026-0001

  // WHAT. A damage report may be against a scanned bundle, or just a product,
  // or neither (yard property, a truck, a customer's fence).
  bundleId: uuid("bundle_id").references(() => bundles.id),
  productId: uuid("product_id").references(() => products.id),
  subject: text("subject").notNull().default("material"), // material | property | equipment | vehicle

  // HOW MUCH.
  qtyAffected: numeric("qty_affected"),
  unit: text("unit"),

  // WHY / HOW — chosen from buttons, not typed.
  reason: text("reason").notNull(), // forklift | strapping | weather | defect | transit | unknown | other
  severity: text("severity").notNull().default("minor"), // minor | major | total
  stage: text("stage"), // receiving | storage | loading | delivery | return

  // WHERE — free-text yard location plus device GPS when granted.
  location: text("location"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),

  // Context, when the damage happened against a job/customer.
  jobId: uuid("job_id").references(() => jobs.id),
  customerId: uuid("customer_id").references(() => customers.id),

  // Did this pull stock out of inventory?
  movementId: uuid("movement_id").references(() => movements.id),
  writeOff: boolean("write_off").notNull().default(false),

  notes: text("notes"),
  status: text("status").notNull().default("open"), // open | reviewed | resolved | written_off

  // WHO / WHEN — always from the session and the device, never user input.
  reportedBy: uuid("reported_by").notNull().references(() => users.id),
  deviceId: text("device_id"),
  deviceTime: timestamp("device_time", { withTimezone: true }),
  reviewedBy: uuid("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),

  clientUuid: text("client_uuid").unique(), // offline idempotency
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_damage_bundle").on(t.bundleId),
  index("idx_damage_product").on(t.productId),
  index("idx_damage_status").on(t.status),
  index("idx_damage_created").on(t.createdAt),
]);

// ── SITES ────────────────────────────────────────────────────────────────────
/**
 * A place the crew clocks in. The QR poster on the wall encodes the site's
 * token; scanning it is how a shift starts.
 *
 * The token is not a secret in any strong sense — a photo of the poster works
 * from anywhere — which is why the clock-in also records the phone's position
 * and how far it was from the site. The two together are what the owner reads:
 * "scanned the shop code, 30 ft from the door" is a normal morning; "manual
 * clock-in, 4 miles away" is a conversation.
 */
export const sites = pgTable("sites", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  address: text("address"),
  /** Uppercase alphanumerics only: the scanner upper-cases what it reads. */
  token: text("token").unique().notNull(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  /** How close counts as "at the shop". Phones under a metal roof drift. */
  radiusM: integer("radius_m").notNull().default(250),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── SHIFTS ───────────────────────────────────────────────────────────────────
/**
 * One row per clock-in. A user has at most one open shift at a time (partial
 * unique index in the migration). The last-known position is denormalised
 * onto the shift so the live map is one cheap query; the full breadcrumb
 * trail lives in location_pings.
 */
export const shifts = pgTable("shifts", {
  id: uuid("id").primaryKey().defaultRandom(),
  clientUuid: text("client_uuid").unique().notNull(),
  userId: uuid("user_id").notNull().references(() => users.id),
  siteId: uuid("site_id").references(() => sites.id),
  status: text("status").notNull().default("active"), // active | closed
  /** qr = scanned the poster; manual = tapped "clock in without scanning". */
  method: text("method").notNull().default("qr"),

  clockInAt: timestamp("clock_in_at", { withTimezone: true }).notNull().defaultNow(),
  clockInLat: doublePrecision("clock_in_lat"),
  clockInLng: doublePrecision("clock_in_lng"),
  clockInAccuracyM: doublePrecision("clock_in_accuracy_m"),
  /** Metres from the site at clock-in; null when either side lacks a fix. */
  clockInDistanceM: doublePrecision("clock_in_distance_m"),
  clockInDeviceId: text("clock_in_device_id"),

  clockOutAt: timestamp("clock_out_at", { withTimezone: true }),
  clockOutLat: doublePrecision("clock_out_lat"),
  clockOutLng: doublePrecision("clock_out_lng"),
  clockOutAccuracyM: doublePrecision("clock_out_accuracy_m"),
  /** Who ended it: the crew member themselves, or an admin from the office. */
  clockOutBy: uuid("clock_out_by").references(() => users.id),

  lastLat: doublePrecision("last_lat"),
  lastLng: doublePrecision("last_lng"),
  lastAccuracyM: doublePrecision("last_accuracy_m"),
  lastSpeedMps: doublePrecision("last_speed_mps"),
  lastPingAt: timestamp("last_ping_at", { withTimezone: true }),
  pingCount: integer("ping_count").notNull().default(0),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_shifts_user").on(t.userId),
  index("idx_shifts_status").on(t.status),
  index("idx_shifts_clock_in").on(t.clockInAt),
]);

// ── LOCATION PINGS ───────────────────────────────────────────────────────────
/**
 * Breadcrumbs. Written in batches by the phone while a shift is open. Only
 * ever inserted — a trail that can be edited is not evidence of anything.
 */
export const locationPings = pgTable("location_pings", {
  id: uuid("id").primaryKey().defaultRandom(),
  shiftId: uuid("shift_id").notNull().references(() => shifts.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  accuracyM: doublePrecision("accuracy_m"),
  speedMps: doublePrecision("speed_mps"),
  heading: doublePrecision("heading"),
  /** The phone's clock at the fix; receivedAt is ours. They differ offline. */
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull(),
  receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_pings_shift_time").on(t.shiftId, t.recordedAt),
  index("idx_pings_user_time").on(t.userId, t.recordedAt),
]);

// ── VEHICLES ─────────────────────────────────────────────────────────────────
export const vehicles = pgTable("vehicles", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(), // "Truck 1", "The white Isuzu"
  plate: text("plate"),
  description: text("description"), // year/make/model, box size
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ── VEHICLE CHECKS ───────────────────────────────────────────────────────────
/**
 * The morning once-over. `items` is a JSON map of checklist key -> result
 * (ok | watch | bad) so the checklist can grow without a migration; the keys
 * in use are defined in src/lib/fleet.ts. `status` is rolled up server-side
 * from the worst item so the office can filter on it.
 */
export const vehicleChecks = pgTable("vehicle_checks", {
  id: uuid("id").primaryKey().defaultRandom(),
  clientUuid: text("client_uuid").unique().notNull(),
  vehicleId: uuid("vehicle_id").notNull().references(() => vehicles.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  shiftId: uuid("shift_id").references(() => shifts.id),
  /** Calendar day in the site's time zone, so "checked today" is unambiguous. */
  checkDate: text("check_date").notNull(), // YYYY-MM-DD
  items: jsonb("items").$type<Record<string, "ok" | "watch" | "bad">>().notNull(),
  status: text("status").notNull(), // ok | attention | needs_repair
  odometer: integer("odometer"),
  fuelLevel: text("fuel_level"), // E | 1/4 | 1/2 | 3/4 | F
  notes: text("notes"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  deviceId: text("device_id"),
  deviceTime: timestamp("device_time", { withTimezone: true }),
  checkedAt: timestamp("checked_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_vchecks_vehicle_date").on(t.vehicleId, t.checkDate),
  index("idx_vchecks_date").on(t.checkDate),
  index("idx_vchecks_user").on(t.userId),
]);

// ── ITINERARIES ──────────────────────────────────────────────────────────────
/**
 * The day's orders from the office, written the day before. Delivered to the
 * phone at clock-in; the ack table records who saw what and when, which is
 * the answer to "I never got told to clean the yard".
 */
export const itineraries = pgTable("itineraries", {
  id: uuid("id").primaryKey().defaultRandom(),
  forDate: text("for_date").notNull(), // YYYY-MM-DD in the site's time zone
  title: text("title").notNull(),
  body: text("body"),
  /** Null means everyone who clocks in that day. */
  assigneeId: uuid("assignee_id").references(() => users.id),
  priority: text("priority").notNull().default("normal"), // normal | high
  active: boolean("active").notNull().default(true),
  createdBy: uuid("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("idx_itineraries_date").on(t.forDate),
  index("idx_itineraries_assignee").on(t.assigneeId),
]);

export const itineraryAcks = pgTable("itinerary_acks", {
  id: uuid("id").primaryKey().defaultRandom(),
  itineraryId: uuid("itinerary_id").notNull().references(() => itineraries.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  shiftId: uuid("shift_id").references(() => shifts.id),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  unique("itinerary_acks_once").on(t.itineraryId, t.userId),
  index("idx_acks_user").on(t.userId),
]);

// ── RELATIONS ─────────────────────────────────────────────────────────────────
export const usersRelations = relations(users, ({ many }) => ({
  movements: many(movements),
  jobs: many(jobs),
  receipts: many(receipts),
  bundles: many(bundles),
}));

export const customersRelations = relations(customers, ({ many }) => ({
  jobs: many(jobs),
}));

export const productsRelations = relations(products, ({ many }) => ({
  bundles: many(bundles),
  movements: many(movements),
  receiptLines: many(receiptLines),
}));

export const receiptsRelations = relations(receipts, ({ one, many }) => ({
  createdBy: one(users, { fields: [receipts.createdBy], references: [users.id] }),
  lines: many(receiptLines),
  bundles: many(bundles),
}));

export const receiptLinesRelations = relations(receiptLines, ({ one }) => ({
  receipt: one(receipts, { fields: [receiptLines.receiptId], references: [receipts.id] }),
  product: one(products, { fields: [receiptLines.productId], references: [products.id] }),
}));

export const bundlesRelations = relations(bundles, ({ one, many }) => ({
  product: one(products, { fields: [bundles.productId], references: [products.id] }),
  receipt: one(receipts, { fields: [bundles.receiptId], references: [receipts.id] }),
  receivedBy: one(users, { fields: [bundles.receivedBy], references: [users.id] }),
  movements: many(movements),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  customer: one(customers, { fields: [jobs.customerId], references: [customers.id] }),
  createdBy: one(users, { fields: [jobs.createdBy], references: [users.id] }),
  movements: many(movements),
}));

export const movementsRelations = relations(movements, ({ one }) => ({
  bundle: one(bundles, { fields: [movements.bundleId], references: [bundles.id] }),
  product: one(products, { fields: [movements.productId], references: [products.id] }),
  job: one(jobs, { fields: [movements.jobId], references: [jobs.id] }),
  employee: one(users, { fields: [movements.employeeId], references: [users.id] }),
}));

export const photosRelations = relations(photos, ({ one }) => ({
  takenBy: one(users, { fields: [photos.takenBy], references: [users.id] }),
}));

export const damageReportsRelations = relations(damageReports, ({ one }) => ({
  bundle: one(bundles, { fields: [damageReports.bundleId], references: [bundles.id] }),
  product: one(products, { fields: [damageReports.productId], references: [products.id] }),
  job: one(jobs, { fields: [damageReports.jobId], references: [jobs.id] }),
  customer: one(customers, { fields: [damageReports.customerId], references: [customers.id] }),
  reportedBy: one(users, { fields: [damageReports.reportedBy], references: [users.id] }),
  reviewedBy: one(users, { fields: [damageReports.reviewedBy], references: [users.id] }),
  movement: one(movements, { fields: [damageReports.movementId], references: [movements.id] }),
}));

export const sitesRelations = relations(sites, ({ many }) => ({
  shifts: many(shifts),
}));

export const shiftsRelations = relations(shifts, ({ one, many }) => ({
  user: one(users, { fields: [shifts.userId], references: [users.id] }),
  site: one(sites, { fields: [shifts.siteId], references: [sites.id] }),
  pings: many(locationPings),
  checks: many(vehicleChecks),
}));

export const locationPingsRelations = relations(locationPings, ({ one }) => ({
  shift: one(shifts, { fields: [locationPings.shiftId], references: [shifts.id] }),
  user: one(users, { fields: [locationPings.userId], references: [users.id] }),
}));

export const vehiclesRelations = relations(vehicles, ({ many }) => ({
  checks: many(vehicleChecks),
}));

export const vehicleChecksRelations = relations(vehicleChecks, ({ one }) => ({
  vehicle: one(vehicles, { fields: [vehicleChecks.vehicleId], references: [vehicles.id] }),
  user: one(users, { fields: [vehicleChecks.userId], references: [users.id] }),
  shift: one(shifts, { fields: [vehicleChecks.shiftId], references: [shifts.id] }),
}));

export const itinerariesRelations = relations(itineraries, ({ one, many }) => ({
  assignee: one(users, { fields: [itineraries.assigneeId], references: [users.id] }),
  createdBy: one(users, { fields: [itineraries.createdBy], references: [users.id] }),
  acks: many(itineraryAcks),
}));

export const itineraryAcksRelations = relations(itineraryAcks, ({ one }) => ({
  itinerary: one(itineraries, { fields: [itineraryAcks.itineraryId], references: [itineraries.id] }),
  user: one(users, { fields: [itineraryAcks.userId], references: [users.id] }),
}));
