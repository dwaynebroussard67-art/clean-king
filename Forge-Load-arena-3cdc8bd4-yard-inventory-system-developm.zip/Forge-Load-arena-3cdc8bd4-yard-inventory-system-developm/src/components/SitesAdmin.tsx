"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import { tenant } from "@/lib/tenant";
import { getGeo } from "@/lib/camera";

interface Site {
  id: string;
  name: string;
  address: string | null;
  token: string;
  latitude: number | null;
  longitude: number | null;
  radiusM: number;
  active: boolean;
}

/**
 * Clock-in posters. One site per place the crew start their day — the shop,
 * and the warehouse if it has its own door. Prints a QR square with the
 * code under it, big enough to scan from a truck window.
 */
export function SitesAdmin() {
  const [sites, setSites] = useState<Site[]>([]);
  const [form, setForm] = useState({ name: "", address: "", latitude: "", longitude: "", radiusM: "250" });
  const [saving, setSaving] = useState(false);
  const [locating, setLocating] = useState(false);
  const [error, setError] = useState("");
  const [printing, setPrinting] = useState<Site | null>(null);

  const load = useCallback(async () => {
    const d = await fetch("/api/sites").then((r) => r.json());
    setSites(d.sites ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void load().catch(() => setError("Couldn't load sites."));
  }, [load]);

  const pinMyLocation = async () => {
    setLocating(true);
    const g = await getGeo(10_000);
    setLocating(false);
    if (g.latitude == null) {
      setError("Couldn't get a fix. Stand outside by the door and try again, or type the coordinates.");
      return;
    }
    setForm({ ...form, latitude: g.latitude.toFixed(6), longitude: g.longitude!.toFixed(6) });
  };

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          address: form.address,
          latitude: form.latitude ? Number(form.latitude) : null,
          longitude: form.longitude ? Number(form.longitude) : null,
          radiusM: Number(form.radiusM) || 250,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Couldn't add the site");
      setForm({ name: "", address: "", latitude: "", longitude: "", radiusM: "250" });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't add the site");
    } finally {
      setSaving(false);
    }
  };

  const rotate = async (s: Site) => {
    if (!confirm(`Issue a new code for ${s.name}? The old poster stops working immediately and you'll need to print a new one.`)) return;
    await fetch(`/api/sites/${s.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rotateToken: true }) });
    await load();
  };

  const toggle = async (s: Site) => {
    await fetch(`/api/sites/${s.id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ active: !s.active }) });
    await load();
  };

  if (printing) return <Poster site={printing} onBack={() => setPrinting(null)} />;

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-white font-semibold mb-3">Clock-in posters</h2>
        {sites.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">
            No sites yet. Add the shop below, then print its poster and put it by the door the crew come in.
          </div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-800">
            {sites.map((s) => (
              <div key={s.id} className={`px-4 py-3 flex items-center gap-3 ${!s.active ? "opacity-50" : ""}`}>
                <span className="text-2xl">🏬</span>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-medium text-sm">{s.name}</div>
                  <div className="text-slate-400 text-xs">
                    {s.address ? `${s.address} · ` : ""}
                    {s.latitude != null ? `pinned · ${s.radiusM} m radius` : <span className="text-amber-300">no location pinned — distance checks off</span>}
                    {" · code "}<span className="font-mono text-slate-300">{s.token}</span>
                  </div>
                </div>
                <button onClick={() => setPrinting(s)} className="text-xs px-2.5 py-1.5 rounded-lg bg-accent-500 text-white font-semibold">Print poster</button>
                <button onClick={() => void rotate(s)} className="text-xs text-slate-500 hover:text-slate-300 px-2">New code</button>
                <button onClick={() => void toggle(s)} className="text-xs text-slate-500 hover:text-slate-300 px-2">{s.active ? "Disable" : "Enable"}</button>
              </div>
            ))}
          </div>
        )}
      </section>

      <form onSubmit={add} className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
        <h3 className="text-white text-sm font-semibold">Add a site</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name (e.g. Main shop)" required className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500" />
          <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Address" className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500" />
        </div>
        <div className="grid grid-cols-[1fr_1fr_90px_auto] gap-2">
          <input value={form.latitude} onChange={(e) => setForm({ ...form, latitude: e.target.value })} placeholder="Latitude" inputMode="decimal" className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500" />
          <input value={form.longitude} onChange={(e) => setForm({ ...form, longitude: e.target.value })} placeholder="Longitude" inputMode="decimal" className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500" />
          <input value={form.radiusM} onChange={(e) => setForm({ ...form, radiusM: e.target.value })} placeholder="Radius m" inputMode="numeric" className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500" />
          <button type="button" onClick={() => void pinMyLocation()} disabled={locating} className="text-xs px-3 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap">
            {locating ? "Locating…" : "📍 Use my location"}
          </button>
        </div>
        <p className="text-slate-500 text-xs">
          Stand at the door with your phone and tap &ldquo;Use my location&rdquo; — that pins the site so clock-ins show how far away each person was. Radius is how close counts as &ldquo;at the shop&rdquo;; 250 m covers a lot and the parking.
        </p>
        {error && <div className="text-red-300 text-xs">{error}</div>}
        <button disabled={saving} className="bg-accent-500 hover:bg-accent-600 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2 rounded-lg">Add site</button>
      </form>
    </div>
  );
}

function Poster({ site, onBack }: { site: Site; onBack: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const base = (process.env.NEXT_PUBLIC_APP_URL || (typeof window !== "undefined" ? window.location.origin : "")).replace(/\/$/, "");
  const url = `${base}/clock-in/${site.token}`;
  const isLocal = /localhost|127\.0\.0\.1|e2b\.app/.test(base);

  useEffect(() => {
    if (!canvasRef.current) return;
    void QRCode.toCanvas(canvasRef.current, url, { width: 480, margin: 2, errorCorrectionLevel: "H", color: { dark: "#000000", light: "#ffffff" } });
  }, [url]);

  return (
    <div>
      <div className="no-print flex items-center justify-between mb-4">
        <button onClick={onBack} className="text-slate-400 text-sm">← Back</button>
        <button onClick={() => window.print()} className="bg-accent-500 text-white text-sm font-semibold px-4 py-2 rounded-lg">🖨 Print</button>
      </div>
      {isLocal && (
        <div className="no-print mb-4 bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-3 text-amber-300 text-sm">
          This poster encodes <span className="font-mono">{base}</span>. Set <span className="font-mono">NEXT_PUBLIC_APP_URL</span> to the real address before printing the one that goes on the wall — a poster is permanent.
        </div>
      )}
      <div className="print-label bg-white text-black rounded-2xl p-8 max-w-md mx-auto text-center">
        <div className="text-xs uppercase tracking-[0.3em] text-gray-500">{tenant.name}</div>
        <h1 className="text-3xl font-black mt-1">Clock in here</h1>
        <p className="text-gray-600 text-sm mt-1">{site.name}{site.address ? ` · ${site.address}` : ""}</p>
        <canvas ref={canvasRef} className="mx-auto my-6 w-full max-w-[320px] h-auto" />
        <div className="font-mono text-2xl font-bold tracking-[0.25em]">{site.token}</div>
        <ol className="text-left text-sm text-gray-700 mt-6 space-y-1.5 list-decimal list-inside">
          <li>Open <strong>{tenant.shortName}</strong> on your phone (or point your camera at the square).</li>
          <li>Tap <strong>Scan to clock in</strong> and allow location.</li>
          <li>Read what the office left for you today.</li>
          <li>Do your <strong>morning truck check</strong> before you roll.</li>
        </ol>
        <p className="text-[11px] text-gray-500 mt-6">Location is recorded only between clock-in and clock-out.</p>
      </div>
    </div>
  );
}
