"use client";

import { useCallback, useEffect, useState } from "react";
import { formatDateKey, localDateKey, nextDateKey } from "@/lib/fleet";

interface UserRow {
  id: string;
  fullName: string;
  role: string;
  active: boolean;
}

interface Itinerary {
  id: string;
  forDate: string;
  title: string;
  body: string | null;
  priority: "normal" | "high";
  assigneeId: string | null;
  assigneeName: string | null;
  createdByName: string | null;
  createdAt: string;
  acks: { userName: string; deliveredAt: string }[];
}

/**
 * Earl Jr.'s side of the itinerary. Type what needs doing, pick a day
 * (defaults to tomorrow), pick who (defaults to everyone), post. The list
 * below shows what's queued and — once the morning comes — who has had it
 * delivered to their phone and when.
 */
export function ItineraryAdmin() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [items, setItems] = useState<Itinerary[]>([]);
  const [form, setForm] = useState({
    forDate: nextDateKey(),
    title: "",
    body: "",
    assigneeId: "",
    priority: "normal" as "normal" | "high",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [u, i] = await Promise.all([
      fetch("/api/users").then((r) => r.json()),
      fetch("/api/itineraries?upcoming=1").then((r) => r.json()),
    ]);
    setUsers((u.users ?? []).filter((x: UserRow) => x.active));
    setItems(i.itineraries ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void load().catch(() => setError("Couldn't load."));
  }, [load]);

  const post = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const res = await fetch(editing ? `/api/itineraries/${editing}` : "/api/itineraries", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          forDate: form.forDate,
          title: form.title,
          body: form.body,
          assigneeId: form.assigneeId || null,
          priority: form.priority,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Couldn't save");
      setForm({ forDate: form.forDate, title: "", body: "", assigneeId: "", priority: "normal" });
      setEditing(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't save");
    } finally {
      setSaving(false);
    }
  };

  const remove = async (it: Itinerary) => {
    if (!confirm(`Remove "${it.title}"?${it.acks.length ? ` ${it.acks.length} people have already seen it.` : ""}`)) return;
    await fetch(`/api/itineraries/${it.id}`, { method: "DELETE" });
    await load();
  };

  const startEdit = (it: Itinerary) => {
    setEditing(it.id);
    setForm({
      forDate: it.forDate,
      title: it.title,
      body: it.body ?? "",
      assigneeId: it.assigneeId ?? "",
      priority: it.priority,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const today = localDateKey();
  const tomorrow = nextDateKey();
  const byDate = new Map<string, Itinerary[]>();
  for (const it of items) byDate.set(it.forDate, [...(byDate.get(it.forDate) ?? []), it]);
  const dates = [...byDate.keys()].sort();

  return (
    <div className="space-y-6">
      <form onSubmit={post} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-white font-semibold">{editing ? "Edit order" : "Post an order for the crew"}</h2>
          {editing && (
            <button type="button" onClick={() => { setEditing(null); setForm({ forDate: tomorrow, title: "", body: "", assigneeId: "", priority: "normal" }); }} className="text-xs text-slate-400">
              Cancel edit
            </button>
          )}
        </div>

        <input
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          placeholder="What needs doing — e.g. Clean the yard before deliveries"
          required
          maxLength={200}
          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-accent-500"
        />
        <textarea
          value={form.body}
          onChange={(e) => setForm({ ...form, body: e.target.value })}
          rows={3}
          placeholder="Details (optional). Delivery order, addresses, what goes on which truck…"
          className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-accent-500"
        />

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div>
            <label className="block text-[11px] text-slate-500 mb-1">For which day</label>
            <div className="flex gap-1">
              <button type="button" onClick={() => setForm({ ...form, forDate: today })} className={`flex-1 text-xs py-2 rounded-lg border ${form.forDate === today ? "bg-accent-500 border-accent-500 text-white" : "border-slate-700 text-slate-300"}`}>Today</button>
              <button type="button" onClick={() => setForm({ ...form, forDate: tomorrow })} className={`flex-1 text-xs py-2 rounded-lg border ${form.forDate === tomorrow ? "bg-accent-500 border-accent-500 text-white" : "border-slate-700 text-slate-300"}`}>Tomorrow</button>
            </div>
          </div>
          <div>
            <label className="block text-[11px] text-slate-500 mb-1">or pick a date</label>
            <input type="date" value={form.forDate} min={today} onChange={(e) => e.target.value && setForm({ ...form, forDate: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-2 text-xs text-white" />
          </div>
          <div>
            <label className="block text-[11px] text-slate-500 mb-1">Who</label>
            <select value={form.assigneeId} onChange={(e) => setForm({ ...form, assigneeId: e.target.value })} className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-2 text-xs text-white">
              <option value="">Everyone</option>
              {users.map((u) => <option key={u.id} value={u.id}>{u.fullName}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[11px] text-slate-500 mb-1">Priority</label>
            <button type="button" onClick={() => setForm({ ...form, priority: form.priority === "high" ? "normal" : "high" })} className={`w-full text-xs py-2 rounded-lg border ${form.priority === "high" ? "bg-amber-500 border-amber-500 text-black font-semibold" : "border-slate-700 text-slate-300"}`}>
              {form.priority === "high" ? "! Important" : "Normal"}
            </button>
          </div>
        </div>

        {error && <div className="text-red-300 text-xs">{error}</div>}

        <button disabled={saving || !form.title.trim()} className="w-full bg-accent-500 hover:bg-accent-600 disabled:opacity-40 text-white font-semibold py-3 rounded-xl">
          {saving ? "Saving…" : editing ? "Save changes" : `Post for ${formatDateKey(form.forDate, { weekday: "long", month: "short", day: "numeric" })}`}
        </button>
        <p className="text-slate-500 text-xs">
          Delivered to each person&rsquo;s phone the moment they clock in that day. You&rsquo;ll see who has seen it below.
        </p>
      </form>

      {dates.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">Nothing queued from today onward.</div>
      ) : (
        dates.map((d) => (
          <section key={d}>
            <h3 className="text-slate-300 text-sm font-semibold mb-2">
              {d === today ? "Today" : d === tomorrow ? "Tomorrow" : ""}{d === today || d === tomorrow ? " · " : ""}{formatDateKey(d)}
            </h3>
            <div className="space-y-2">
              {byDate.get(d)!.map((it) => (
                <article key={it.id} className={`rounded-xl border px-4 py-3 ${it.priority === "high" ? "bg-amber-500/5 border-amber-500/30" : "bg-slate-900 border-slate-800"}`}>
                  <div className="flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="text-white font-medium">{it.priority === "high" && <span className="text-amber-400 mr-1">!</span>}{it.title}</div>
                      {it.body && <p className="text-slate-400 text-sm mt-1 whitespace-pre-wrap">{it.body}</p>}
                      <div className="text-xs text-slate-500 mt-2">
                        {it.assigneeName ? `For ${it.assigneeName}` : "For everyone"}
                        {it.createdByName ? ` · posted by ${it.createdByName.split(" ")[0]}` : ""}
                      </div>
                      <div className="text-xs mt-1.5">
                        {it.acks.length === 0 ? (
                          <span className="text-slate-500">{d <= today ? "Nobody has clocked in to see it yet" : "Will deliver at clock-in"}</span>
                        ) : (
                          <span className="text-green-400">
                            Seen by {it.acks.map((a) => `${a.userName.split(" ")[0]} (${new Date(a.deliveredAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })})`).join(", ")}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <button onClick={() => startEdit(it)} className="text-xs text-slate-400 hover:text-white px-2 py-1">Edit</button>
                      <button onClick={() => void remove(it)} className="text-xs text-slate-500 hover:text-red-300 px-2 py-1">Remove</button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </section>
        ))
      )}
    </div>
  );
}
