"use client";

import { useCallback, useEffect, useState } from "react";
import { CHECK_ITEMS, CHECK_STATUS_LABEL, localDateKey, type CheckResult, type CheckStatus } from "@/lib/fleet";

interface Vehicle {
  id: string;
  name: string;
  plate: string | null;
  description: string | null;
  active: boolean;
  checkedToday: boolean;
  lastCheck: {
    id: string;
    checkDate: string;
    status: CheckStatus;
    checkedAt: string;
    odometer: number | null;
    fuelLevel: string | null;
    userName: string;
  } | null;
}

interface Check {
  id: string;
  vehicleId: string;
  vehicleName: string;
  userName: string;
  checkDate: string;
  items: Record<string, CheckResult>;
  status: CheckStatus;
  odometer: number | null;
  fuelLevel: string | null;
  notes: string | null;
  checkedAt: string;
}

const STATUS_PILL: Record<CheckStatus, string> = {
  ok: "bg-green-500/10 border-green-500/30 text-green-300",
  attention: "bg-amber-500/10 border-amber-500/30 text-amber-300",
  needs_repair: "bg-red-500/10 border-red-500/30 text-red-300",
};

const LABEL_BY_KEY = new Map(CHECK_ITEMS.map((i) => [i.key, i.label]));

/**
 * Fleet tab: the trucks, whether each has had its morning check, and the
 * history with what was flagged. The list is sorted so unchecked and
 * do-not-drive trucks float to the top — that's what the office needs to
 * see at 7:30.
 */
export function FleetAdmin() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [checks, setChecks] = useState<Check[]>([]);
  const [filterVehicle, setFilterVehicle] = useState<string>("");
  const [filterStatus, setFilterStatus] = useState<string>("");
  const [open, setOpen] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", plate: "", description: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const params = new URLSearchParams({ limit: "100" });
    if (filterVehicle) params.set("vehicleId", filterVehicle);
    if (filterStatus) params.set("status", filterStatus);
    const [v, c] = await Promise.all([
      fetch("/api/vehicles?all=1").then((r) => r.json()),
      fetch(`/api/vehicle-checks?${params}`).then((r) => r.json()),
    ]);
    setVehicles(v.vehicles ?? []);
    setChecks(c.checks ?? []);
  }, [filterVehicle, filterStatus]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void load().catch(() => setError("Couldn't load the fleet."));
  }, [load]);

  const addVehicle = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/vehicles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Couldn't add the truck");
      setForm({ name: "", plate: "", description: "" });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't add the truck");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (v: Vehicle) => {
    await fetch("/api/vehicles", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: v.id, active: !v.active }),
    });
    await load();
  };

  const today = localDateKey();
  const sorted = [...vehicles].sort((a, b) => {
    const rank = (v: Vehicle) =>
      !v.active ? 3 : v.lastCheck?.status === "needs_repair" && v.checkedToday ? 0 : !v.checkedToday ? 1 : 2;
    return rank(a) - rank(b) || a.name.localeCompare(b.name);
  });
  const activeCount = vehicles.filter((v) => v.active).length;
  const checkedCount = vehicles.filter((v) => v.active && v.checkedToday).length;

  return (
    <div className="space-y-6">
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-white font-semibold">Trucks</h2>
          <span className={`text-xs px-2.5 py-1 rounded-full border ${checkedCount === activeCount && activeCount > 0 ? STATUS_PILL.ok : STATUS_PILL.attention}`}>
            {checkedCount}/{activeCount} checked today
          </span>
        </div>

        {vehicles.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">
            No trucks yet. Add them below — the crew will see them on the morning check screen right away.
          </div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-800">
            {sorted.map((v) => (
              <div key={v.id} className={`px-4 py-3 flex items-center gap-3 ${!v.active ? "opacity-50" : ""}`}>
                <span className="text-2xl">🛻</span>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-medium text-sm">
                    {v.name}
                    {v.plate && <span className="text-slate-500 font-normal ml-2 text-xs">{v.plate}</span>}
                  </div>
                  <div className="text-slate-400 text-xs">
                    {v.description && <>{v.description} · </>}
                    {v.lastCheck
                      ? `last check ${v.lastCheck.checkDate === today ? "today" : v.lastCheck.checkDate} by ${v.lastCheck.userName.split(" ")[0]}${v.lastCheck.odometer ? ` · ${v.lastCheck.odometer.toLocaleString()} mi` : ""}`
                      : "never checked"}
                  </div>
                </div>
                {v.active && (
                  v.checkedToday && v.lastCheck ? (
                    <span className={`text-xs px-2 py-1 rounded-full border ${STATUS_PILL[v.lastCheck.status]}`}>
                      {CHECK_STATUS_LABEL[v.lastCheck.status]}
                    </span>
                  ) : (
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">Not checked today</span>
                  )
                )}
                <button onClick={() => void toggleActive(v)} className="text-xs text-slate-500 hover:text-slate-300 px-2">
                  {v.active ? "Retire" : "Restore"}
                </button>
              </div>
            ))}
          </div>
        )}

        <form onSubmit={addVehicle} className="mt-3 bg-slate-900 border border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-[1fr_120px_1fr_auto] gap-2">
          <input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Truck name (e.g. Truck 1)"
            required
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500"
          />
          <input
            value={form.plate}
            onChange={(e) => setForm({ ...form, plate: e.target.value })}
            placeholder="Plate"
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500"
          />
          <input
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Year / make / box size"
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white placeholder-slate-500"
          />
          <button disabled={saving} className="bg-accent-500 hover:bg-accent-600 disabled:opacity-50 text-white text-sm font-semibold px-4 py-2 rounded-lg">
            Add truck
          </button>
        </form>
        {error && <div className="mt-2 text-red-300 text-xs">{error}</div>}
      </section>

      <section>
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <h2 className="text-white font-semibold">Check history</h2>
          <div className="flex gap-2">
            <select value={filterVehicle} onChange={(e) => setFilterVehicle(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white">
              <option value="">All trucks</option>
              {vehicles.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
            </select>
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white">
              <option value="">Any result</option>
              <option value="needs_repair">Do not drive</option>
              <option value="attention">Needs attention</option>
              <option value="ok">Good to go</option>
            </select>
          </div>
        </div>

        {checks.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">No checks match.</div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-800">
            {checks.map((c) => {
              const flagged = Object.entries(c.items).filter(([, r]) => r !== "ok");
              const isOpen = open === c.id;
              return (
                <div key={c.id}>
                  <button onClick={() => setOpen(isOpen ? null : c.id)} className="w-full px-4 py-3 flex items-center gap-3 text-left">
                    <span className={`text-xs px-2 py-1 rounded-full border shrink-0 ${STATUS_PILL[c.status]}`}>{CHECK_STATUS_LABEL[c.status]}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-white text-sm font-medium">
                        {c.vehicleName} <span className="text-slate-500 font-normal">· {c.userName}</span>
                      </div>
                      <div className="text-slate-400 text-xs">
                        {c.checkDate} {new Date(c.checkedAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                        {c.odometer ? ` · ${c.odometer.toLocaleString()} mi` : ""}
                        {c.fuelLevel ? ` · fuel ${c.fuelLevel}` : ""}
                        {flagged.length > 0 && <span className="text-amber-300"> · {flagged.map(([k]) => LABEL_BY_KEY.get(k) ?? k).join(", ")}</span>}
                      </div>
                    </div>
                    <span className="text-slate-500 text-xs">{isOpen ? "▲" : "▼"}</span>
                  </button>
                  {isOpen && (
                    <div className="px-4 pb-4">
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                        {CHECK_ITEMS.map((i) => {
                          const r = c.items[i.key];
                          return (
                            <div key={i.key} className={`text-xs px-2.5 py-1.5 rounded-lg border flex items-center justify-between ${
                              r === "ok" ? "border-slate-800 text-slate-400" : r === "watch" ? "border-amber-500/40 text-amber-300 bg-amber-500/5" : r === "bad" ? "border-red-500/40 text-red-300 bg-red-500/5" : "border-slate-800 text-slate-600"
                            }`}>
                              <span>{i.label}</span>
                              <span className="font-semibold uppercase">{r ?? "—"}</span>
                            </div>
                          );
                        })}
                      </div>
                      {c.notes && <p className="mt-3 text-sm text-slate-300 whitespace-pre-wrap bg-slate-800/60 rounded-lg px-3 py-2">{c.notes}</p>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
