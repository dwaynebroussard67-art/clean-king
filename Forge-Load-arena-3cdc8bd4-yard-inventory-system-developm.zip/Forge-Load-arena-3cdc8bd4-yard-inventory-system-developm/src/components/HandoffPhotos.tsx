"use client";

import { useCallback, useEffect, useState } from "react";
import { CameraCapture } from "@/components/CameraCapture";
import { getGeo, type CaptureGeo } from "@/lib/camera";
import { uploadPhoto } from "@/lib/photo-upload";

interface PhotoMeta {
  id: string;
  caption: string | null;
  latitude: number | null;
  longitude: number | null;
  createdAt: string;
}

/**
 * The two ways material leaves the yard.
 *
 * Most of it — call it nine loads in ten — is picked up: the customer backs
 * their own truck in, it gets loaded, they drive off. The rest gets delivered.
 * Those produce two different accusations weeks later ("you never loaded it"
 * versus "you never delivered it"), so they're photographed separately and
 * shown separately. A job can have both when an order is split.
 */
export type HandoffKind = "load" | "delivery";

const COPY: Record<
  HandoffKind,
  { title: string; icon: string; prompt: string; empty: string; emptyClosed: string }
> = {
  load: {
    title: "Load-out photos",
    icon: "🚛",
    prompt: "Photograph the loaded truck",
    empty:
      "No proof of load-out yet. Photograph the truck loaded, before it pulls off the yard.",
    emptyClosed: "No load-out photos were taken for this job.",
  },
  delivery: {
    title: "Delivery photos",
    icon: "📸",
    prompt: "Photograph the delivered load",
    empty: "No proof of delivery yet. Photograph the load where it's dropped.",
    emptyClosed: "No delivery photos were taken for this job.",
  },
};

interface Props {
  jobId: string;
  kind: HandoffKind;
  /** Closed jobs are read-only: the record of what left the yard shouldn't move. */
  canAdd: boolean;
}

export function HandoffPhotos({ jobId, kind, canAdd }: Props) {
  const copy = COPY[kind];

  const [photos, setPhotos] = useState<PhotoMeta[]>([]);
  const [capturing, setCapturing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [geo, setGeo] = useState<CaptureGeo | null>(null);
  const [error, setError] = useState("");
  const [lightbox, setLightbox] = useState<string | null>(null);

  // Returns rather than sets, so calling it from an effect can't trigger a
  // synchronous cascading render.
  const fetchPhotos = useCallback(async (): Promise<PhotoMeta[]> => {
    const res = await fetch(
      `/api/photos?subjectType=${kind}&subjectId=${encodeURIComponent(jobId)}`
    );
    if (!res.ok) return [];
    const data = await res.json();
    return (data.photos || []) as PhotoMeta[];
  }, [jobId, kind]);

  useEffect(() => {
    let cancelled = false;
    fetchPhotos()
      .then((rows) => {
        if (!cancelled) setPhotos(rows);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [fetchPhotos]);

  const openCamera = async () => {
    setError("");
    // Warm up location while the camera is coming up, never blocking on it.
    void getGeo().then(setGeo);
    setCapturing(true);
  };

  if (capturing) {
    return (
      <CameraCapture
        prompt={copy.prompt}
        allowMultiple
        captureCount={photos.length}
        onCancel={() => setCapturing(false)}
        onCapture={async (photo) => {
          setCapturing(false);
          setUploading(true);
          try {
            await uploadPhoto(photo, {
              subjectType: kind,
              subjectId: jobId,
              geo,
            });
            setPhotos(await fetchPhotos());
          } catch (err) {
            setError(err instanceof Error ? err.message : "Upload failed");
          } finally {
            URL.revokeObjectURL(photo.previewUrl);
            setUploading(false);
          }
        }}
      />
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mb-4">
      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <h2 className="font-semibold text-white flex items-center gap-2">
          <span>{copy.icon}</span> {copy.title}
          {photos.length > 0 && (
            <span className="text-xs text-slate-500 font-normal">({photos.length})</span>
          )}
        </h2>
        {canAdd && (
          <button
            onClick={openCamera}
            disabled={uploading}
            className="no-print bg-accent-500 hover:bg-accent-600 disabled:opacity-50 text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
          >
            {uploading ? "Saving…" : "+ Photo"}
          </button>
        )}
      </div>

      {error && (
        <div className="px-4 py-2 text-xs text-red-400 bg-red-500/10">{error}</div>
      )}

      {photos.length === 0 ? (
        <div className="px-4 py-8 text-center text-slate-500 text-sm">
          {canAdd ? copy.empty : copy.emptyClosed}
        </div>
      ) : (
        <div className="p-3 grid grid-cols-3 sm:grid-cols-4 gap-2">
          {photos.map((p) => (
            <button
              key={p.id}
              onClick={() => setLightbox(p.id)}
              className="relative aspect-square rounded-lg overflow-hidden border border-slate-700 hover:border-accent-500 transition-colors"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`/api/photos/${p.id}`}
                alt={p.caption || copy.title}
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <span className="absolute bottom-0 inset-x-0 bg-slate-950/80 text-[10px] text-slate-300 px-1 py-0.5 text-left">
                {new Date(p.createdAt).toLocaleString("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "numeric",
                  minute: "2-digit",
                })}
                {p.latitude != null && " · 📍"}
              </span>
            </button>
          ))}
        </div>
      )}

      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={`/api/photos/${lightbox}`}
            alt={copy.title}
            className="max-w-full max-h-full object-contain rounded-lg"
          />
          <button
            onClick={() => setLightbox(null)}
            className="absolute top-4 right-4 text-white text-3xl leading-none"
            aria-label="Close"
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
