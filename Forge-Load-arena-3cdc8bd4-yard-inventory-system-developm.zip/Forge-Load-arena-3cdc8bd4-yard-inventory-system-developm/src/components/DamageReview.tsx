"use client";

import { useCallback, useEffect, useState } from "react";
import { tenant } from "@/lib/tenant";

interface Report {
  id: string;
  code: string;
  subject: string;
  reason: string;
  severity: string;
  stage: string | null;
  qtyAffected: string | null;
  unit: string | null;
  location: string | null;
  latitude: number | null;
  longitude: number | null;
  notes: string | null;
  status: string;
  writeOff: boolean;
  createdAt: string;
  bundleCode: string | null;
  productName: string | null;
  productSku: string | null;
  jobCode: string | null;
  reportedByName: string | null;
  photoId: string | null;
  photoCount: number;
}

const FILTERS = [
  { key: "open", label: "Open" },
  { key: "reviewed", label: "Reviewed" },
  { key: "resolved", label: "Resolved" },
  { key: "", label: "All" },
] as const;

const SEVERITY_STYLE: Record<string, string> = {
  total: "bg-red-500/20 text-red-400",
  major: "bg-accent-500/20 text-accent-400",
  minor: "bg-yellow-500/20 text-yellow-400",
};

/**
 * The office side of damage logging.
 *
 * Crews file reports from the yard in seconds; this is where someone goes
 * through them, sees the photo, and marks them handled. Without this the
 * reports pile up unseen and the crew stops bothering to file them.
 */
export function DamageReview() {
  const [reports, setReports] = useState<Report[]>([]);
  const [filter, setFilter] = useState<string>("open");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);

  // `reload` never touches state before its first await, so it's safe to call
  // from an effect without kicking off a cascading render.
  const reload = useCallback(async (status: string) => {
    const qs = status ? `?status=${status}&limit=100` : "?limit=100";
    const res = await fetch(`/api/damage${qs}`);
    const data = await res.json();
    return (data.reports || []) as Report[];
  }, []);

  useEffect(() => {
    let cancelled = false;
    reload(filter)
      .then((rows) => {
        if (cancelled) return;
        setReports(rows);
        setLoading(false);
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [filter, reload]);

  const setStatus = async (id: string, status: string) => {
    setBusyId(id);
    try {
      const res = await fetch(`/api/damage/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (res.ok) setReports(await reload(filter));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <div className="flex gap-2 mb-4 overflow-x-auto">
        {FILTERS.map((f) => (
          <button
            key={f.key || "all"}
            onClick={() => setFilter(f.key)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
              filter === f.key
                ? "bg-accent-500 text-white"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12 text-accent-500 animate-pulse text-2xl">{tenant.mark}</div>
      ) : reports.length === 0 ? (
        <div className="text-center py-12 text-slate-500 text-sm">
          {filter === "open" ? "Nothing damaged. Good day." : "No reports here."}
        </div>
      ) : (
        <div className="space-y-3">
          {reports.map((r) => (
            <div
              key={r.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex gap-4"
            >
              {r.photoId ? (
                <button onClick={() => setLightbox(r.photoId)} className="flex-shrink-0">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`/api/photos/${r.photoId}`}
                    alt={`Damage ${r.code}`}
                    loading="lazy"
                    className="w-24 h-24 rounded-lg object-cover border border-slate-700 hover:border-accent-500 transition-colors"
                  />
                  {r.photoCount > 1 && (
                    <span className="block text-[10px] text-slate-500 mt-1">
                      +{r.photoCount - 1} more
                    </span>
                  )}
                </button>
              ) : (
                <div className="w-24 h-24 rounded-lg bg-slate-800 flex items-center justify-center text-2xl flex-shrink-0">
                  ⚠️
                </div>
              )}

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="font-mono text-xs text-amber-400">{r.code}</span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      SEVERITY_STYLE[r.severity] || "bg-slate-700 text-slate-300"
                    }`}
                  >
                    {r.severity}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 capitalize">
                    {r.subject}
                  </span>
                  {r.writeOff && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/20 text-red-400">
                      written off
                    </span>
                  )}
                  {r.status !== "open" && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/20 text-green-400">
                      {r.status}
                    </span>
                  )}
                </div>

                <div className="text-sm text-white">
                  {r.productName || "—"}
                  {r.bundleCode && (
                    <span className="text-slate-500 font-mono text-xs"> · {r.bundleCode}</span>
                  )}
                </div>

                <div className="text-xs text-slate-400 capitalize mt-0.5">
                  {r.reason.replace(/_/g, " ")}
                  {r.stage && ` · during ${r.stage}`}
                  {Number(r.qtyAffected) > 0 && ` · ${r.qtyAffected} ${r.unit || ""}`}
                  {r.jobCode && ` · ${r.jobCode}`}
                </div>

                <div className="text-xs text-slate-500 mt-1">
                  {r.reportedByName} ·{" "}
                  {new Date(r.createdAt).toLocaleString("en-US", {
                    month: "short",
                    day: "numeric",
                    hour: "numeric",
                    minute: "2-digit",
                  })}
                  {r.location && ` · ${r.location}`}
                  {r.latitude != null && (
                    <a
                      href={`https://www.google.com/maps?q=${r.latitude},${r.longitude}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-accent-400 hover:underline ml-1"
                    >
                      📍 map
                    </a>
                  )}
                </div>

                {r.notes && (
                  <div className="text-xs text-slate-400 mt-1 italic">{r.notes}</div>
                )}

                {r.status === "open" && (
                  <div className="flex gap-2 mt-3">
                    <button
                      onClick={() => setStatus(r.id, "reviewed")}
                      disabled={busyId === r.id}
                      className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Mark reviewed
                    </button>
                    <button
                      onClick={() => setStatus(r.id, "resolved")}
                      disabled={busyId === r.id}
                      className="bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-xs px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Resolve
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={`/api/photos/${lightbox}`}
            alt="Damage evidence"
            className="max-w-full max-h-full object-contain rounded-lg"
          />
          <button
            onClick={() => setLightbox(null)}
            className="absolute top-4 right-4 text-white text-3xl leading-none"
            aria-label="Close"
          >
            ×
          </button>
        </div>
      )}
    </div>
  );
}
