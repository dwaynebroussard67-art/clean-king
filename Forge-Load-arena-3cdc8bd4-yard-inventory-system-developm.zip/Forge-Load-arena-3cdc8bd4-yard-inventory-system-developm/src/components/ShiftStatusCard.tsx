"use client";

import { useEffect, useState } from "react";
import type { ShiftSummary } from "@/hooks/useShift";
import type { TrackerState } from "@/lib/tracker";
import { formatAgo, formatDistance, formatDuration } from "@/lib/fleet";

/**
 * "You're on the clock" — how long, where you scanned in, and whether the
 * phone is actually reporting. The tracking row is deliberately blunt:
 * a driver should be able to glance at it in the mount and know the office
 * can see them.
 */
export function ShiftStatusCard({ shift, tracker }: { shift: ShiftSummary; tracker: TrackerState }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  const since = new Date(shift.clockInAt);
  const reporting = tracker.running && tracker.permission === "granted" && !tracker.lastError;
  const lastFixAge = tracker.lastFix ? now - tracker.lastFix.at : null;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
      <div className="px-4 py-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-slate-400 uppercase tracking-wide">On the clock</div>
          <div className="text-3xl font-bold text-white tabular-nums mt-0.5">
            {formatDuration(now - since.getTime())}
          </div>
          <div className="text-slate-400 text-sm mt-1">
            since {since.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
            {shift.siteName ? ` · ${shift.siteName}` : ""}
            {shift.method === "manual" ? " · manual" : ""}
          </div>
        </div>
        <div className="text-4xl">🕒</div>
      </div>

      <div
        className={`px-4 py-3 border-t flex items-center gap-3 ${
          reporting
            ? "border-green-500/20 bg-green-500/5"
            : "border-amber-500/20 bg-amber-500/5"
        }`}
      >
        <span className={`w-2.5 h-2.5 rounded-full ${reporting ? "bg-green-400 animate-pulse" : "bg-amber-400"}`} />
        <div className="flex-1 min-w-0 text-sm">
          <div className={reporting ? "text-green-300" : "text-amber-300"}>
            {reporting
              ? "Location is reporting"
              : tracker.permission === "denied"
                ? "Location blocked — turn it on in settings"
                : tracker.lastError || "Waiting for GPS…"}
          </div>
          <div className="text-slate-500 text-xs mt-0.5">
            {tracker.lastFix
              ? `Last fix ${lastFixAge != null && lastFixAge < 45_000 ? "just now" : formatAgo(new Date(tracker.lastFix.at), now)}${
                  tracker.lastFix.accuracyM != null ? ` · ±${Math.round(tracker.lastFix.accuracyM)} m` : ""
                }`
              : "No fix yet"}
            {tracker.buffered > 0 ? ` · ${tracker.buffered} waiting to send` : ""}
            {shift.clockInDistanceM != null
              ? ` · clocked in ${formatDistance(shift.clockInDistanceM)} from the shop`
              : ""}
          </div>
        </div>
      </div>
    </div>
  );
}
