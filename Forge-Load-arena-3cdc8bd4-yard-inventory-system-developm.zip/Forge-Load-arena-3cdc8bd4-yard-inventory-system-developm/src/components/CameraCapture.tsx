"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  openCameraStream,
  captureFrame,
  compressImage,
  formatBytes,
  type CapturedPhoto,
} from "@/lib/camera";

interface Props {
  onCapture: (photo: CapturedPhoto) => void;
  onCancel?: () => void;
  /** Shown over the viewfinder, e.g. "Photograph the damage". */
  prompt?: string;
  /** Let the crew keep shooting without leaving the camera. */
  allowMultiple?: boolean;
  captureCount?: number;
}

/**
 * Full-bleed camera with a single large shutter button.
 *
 * Falls back to the native file picker (with `capture="environment"`, which
 * opens the camera app directly on both iOS and Android) whenever the live
 * stream can't run — insecure origin, denied permission, or an unsupported
 * browser. That fallback is important: it means the feature degrades to "still
 * works, one extra tap" rather than "broken".
 */
export function CameraCapture({
  onCapture,
  onCancel,
  prompt = "Take a photo",
  allowMultiple = false,
  captureCount = 0,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [useFilePicker, setUseFilePicker] = useState(false);

  const stop = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const stream = await openCameraStream();
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          // iOS Safari refuses inline autoplay without these set directly.
          video.setAttribute("playsinline", "true");
          video.muted = true;
          video.srcObject = stream;
          await video.play().catch(() => {});
          setReady(true);
        }
      } catch (err) {
        if (cancelled) return;
        // Rather than dead-ending, drop to the OS camera app.
        setUseFilePicker(true);
        setError(
          err instanceof Error && err.name === "NotAllowedError"
            ? "Camera permission denied — you can still pick or shoot a photo below."
            : "Live camera unavailable — use the button below to take a photo."
        );
      }
    })();

    return () => {
      cancelled = true;
      stop();
    };
  }, [stop]);

  const handleShutter = async () => {
    const video = videoRef.current;
    if (!video || busy) return;
    setBusy(true);
    setError(null);
    try {
      const photo = await captureFrame(video);
      if (!allowMultiple) stop();
      onCapture(photo);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not capture the photo.");
    } finally {
      setBusy(false);
    }
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const photo = await compressImage(file);
      onCapture(photo);
    } catch {
      setError("Could not read that image. Try again.");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col">
      {/* Viewfinder */}
      <div className="relative flex-1 overflow-hidden">
        {!useFilePicker && (
          <video
            ref={videoRef}
            className="absolute inset-0 w-full h-full object-cover"
            autoPlay
            playsInline
            muted
          />
        )}

        {useFilePicker && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-8">
            <div className="text-6xl mb-4">📷</div>
            <p className="text-slate-300 text-sm">{error}</p>
          </div>
        )}

        {/* Prompt */}
        <div className="absolute top-0 left-0 right-0 pt-[env(safe-area-inset-top)] bg-gradient-to-b from-black/70 to-transparent">
          <div className="flex items-center justify-between px-4 py-3">
            <button
              onClick={() => {
                stop();
                onCancel?.();
              }}
              className="text-white/90 text-sm font-medium px-3 py-2 -ml-3"
            >
              Cancel
            </button>
            <span className="text-white text-sm font-semibold">{prompt}</span>
            <span className="text-white/70 text-sm w-14 text-right">
              {captureCount > 0 ? `${captureCount} 📸` : ""}
            </span>
          </div>
        </div>

        {!ready && !useFilePicker && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-accent-500 text-4xl animate-pulse">📷</div>
          </div>
        )}

        {error && !useFilePicker && (
          <div className="absolute bottom-4 left-4 right-4 bg-red-500/90 text-white text-sm rounded-xl px-4 py-2 text-center">
            {error}
          </div>
        )}
      </div>

      {/* Shutter tray */}
      <div className="bg-black pb-[max(env(safe-area-inset-bottom),1rem)] pt-5 px-6">
        {useFilePicker ? (
          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy}
            className="w-full bg-accent-500 hover:bg-accent-600 disabled:opacity-60 text-white font-bold py-4 rounded-2xl text-lg"
          >
            {busy ? "Processing…" : "Open camera"}
          </button>
        ) : (
          <div className="flex items-center justify-center gap-8">
            <button
              onClick={() => fileRef.current?.click()}
              className="text-white/70 text-xs w-16 text-center"
              aria-label="Choose from library"
            >
              🖼️
              <span className="block mt-1">Library</span>
            </button>

            {/* Big shutter — sized for gloves */}
            <button
              onClick={handleShutter}
              disabled={!ready || busy}
              aria-label="Take photo"
              className="w-20 h-20 rounded-full bg-white disabled:opacity-40 active:scale-95 transition-transform flex items-center justify-center shadow-lg"
            >
              <span className="w-16 h-16 rounded-full border-4 border-slate-900" />
            </button>

            <span className="w-16" />
          </div>
        )}

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      </div>
    </div>
  );
}

/** Small preview tile with a remove button, used in review screens. */
export function PhotoThumb({
  photo,
  onRemove,
}: {
  photo: CapturedPhoto;
  onRemove?: () => void;
}) {
  return (
    <div className="relative">
      {/* eslint-disable-next-line @next/next/no-img-element -- local blob URL, not a remote asset */}
      <img
        src={photo.previewUrl}
        alt="Captured"
        className="w-full h-28 object-cover rounded-xl border border-slate-700"
      />
      <span className="absolute bottom-1 left-1 bg-black/70 text-white text-[10px] px-1.5 py-0.5 rounded">
        {formatBytes(photo.byteSize)}
      </span>
      {onRemove && (
        <button
          onClick={onRemove}
          aria-label="Remove photo"
          className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-red-500 text-white text-sm font-bold shadow"
        >
          ×
        </button>
      )}
    </div>
  );
}
