"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { LiveMap, type MapPerson, type MapSite, type MapTrail } from "@/components/LiveMap";
import {
  FORGOTTEN_SHIFT_MS,
  STALE_PING_MS,
  formatAgo,
  formatDistance,
  formatDuration,
  formatSpeed,
  isOnSite,
  localDateKey,
} from "@/lib/fleet";

interface ShiftRow {
  id: string;
  userId: string;
  userName: string;
  siteId: string | null;
  siteName: string | null;
  status: "active" | "closed";
  method: "qr" | "manual";
  clockInAt: string;
  clockInDistanceM: number | null;
  clockInAccuracyM: number | null;
  clockOutAt: string | null;
  lastLat: number | null;
  lastLng: number | null;
  lastAccuracyM: number | null;
  lastSpeedMps: number | null;
  lastPingAt: string | null;
  pingCount: number;
}

interface SiteRow {
  id: string;
  name: string;
  latitude: number | null;
  longitude: number | null;
  radiusM: number;
}

const POLL_MS = 15_000;

/**
 * The owner's desk view. Who's on the clock, where they are right now, and
 * the day's timesheet — plus a tap on any name to see the route they drove.
 *
 * Polls every 15 s. That's plenty for a truck; the phone itself reports
 * every ~15 s while moving so the route is a real line, not a sketch.
 */
export function CrewBoard() {
  const [active, setActive] = useState<ShiftRow[]>([]);
  const [day, setDay] = useState<ShiftRow[]>([]);
  const [sites, setSites] = useState<SiteRow[]>([]);
  const [date, setDate] = useState(() => localDateKey());
  const [focus, setFocus] = useState<string | null>(null);
  const [trail, setTrail] = useState<MapTrail | null>(null);
  const [trailFor, setTrailFor] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  // "now" lives in state so the relative times re-render on a clock instead
  // of reading Date.now() during render.
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 15_000);
    return () => clearInterval(t);
  }, []);

  const load = useCallback(async () => {
    try {
      const [a, d, s] = await Promise.all([
        fetch("/api/shifts?active=1").then((r) => r.json()),
        fetch(`/api/shifts?date=${date}`).then((r) => r.json()),
        fetch("/api/sites").then((r) => r.json()),
      ]);
      setActive(a.shifts ?? []);
      setDay(d.shifts ?? []);
      setSites(s.sites ?? []);
      const t = Date.now();
      setUpdatedAt(t);
      setNow(t);
      setError("");
    } catch {
      setError("Couldn't refresh. Will keep trying.");
    }
  }, [date]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void load();
    const t = setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, POLL_MS);
    return () => clearInterval(t);
  }, [load]);

  const showTrail = useCallback(async (shiftId: string) => {
    if (trailFor === shiftId) {
      setTrail(null);
      setTrailFor(null);
      return;
    }
    try {
      const res = await fetch(`/api/shifts/${shiftId}`);
      const d = await res.json();
      const pts: [number, number][] = (d.trail ?? []).map((p: { latitude: number; longitude: number }) => [p.latitude, p.longitude]);
      if (d.shift?.clockInLat != null) pts.unshift([d.shift.clockInLat, d.shift.clockInLng]);
      setTrail({ points: pts });
      setTrailFor(shiftId);
    } catch {
      setError("Couldn't load that route.");
    }
  }, [trailFor]);

  const clockOutFromOffice = async (shift: ShiftRow) => {
    if (!confirm(`Clock ${shift.userName} out now? Use this when they forgot or their phone died.`)) return;
    setBusy(shift.id);
    try {
      const res = await fetch(`/api/shifts/${shift.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "clock_out" }),
      });
      if (!res.ok) throw new Error();
      await load();
    } catch {
      setError("Couldn't clock them out.");
    } finally {
      setBusy(null);
    }
  };

  const people: MapPerson[] = useMemo(
    () =>
      active
        .filter((s) => s.lastLat != null && s.lastLng != null)
        .map((s) => ({
          id: s.id,
          name: s.userName,
          lat: s.lastLat!,
          lng: s.lastLng!,
          accuracyM: s.lastAccuracyM,
          speedMps: s.lastSpeedMps,
          lastPingAt: s.lastPingAt,
          siteName: s.siteName,
        })),
    [active]
  );

  const mapSites: MapSite[] = useMemo(
    () =>
      sites
        .filter((s) => s.latitude != null && s.longitude != null)
        .map((s) => ({ id: s.id, name: s.name, lat: s.latitude!, lng: s.longitude!, radiusM: s.radiusM })),
    [sites]
  );

  const closedToday = day.filter((s) => s.status === "closed");
  const siteById = new Map(sites.map((s) => [s.id, s]));

  return (
    <div className="space-y-6">
      {/* Live */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-white font-semibold">On the clock now</h2>
            <p className="text-slate-500 text-xs">
              {active.length} {active.length === 1 ? "person" : "people"} · updated {updatedAt ? formatAgo(new Date(updatedAt), now) : "—"}
              {" · "}
              <button onClick={() => void load()} className="text-accent-400 hover:underline">refresh</button>
            </p>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-500 inline-block" />moving</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" />stopped</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" />no signal</span>
          </div>
        </div>

        {error && <div className="mb-3 text-amber-300 text-xs">{error}</div>}

        <LiveMap people={people} sites={mapSites} trail={trail} focus={focus} />

        {active.length === 0 ? (
          <div className="mt-3 bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">
            Nobody&rsquo;s clocked in. When someone scans the poster they&rsquo;ll appear here within a minute.
          </div>
        ) : (
          <div className="mt-3 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden divide-y divide-slate-800">
            {active.map((s) => {
              const stale = !s.lastPingAt || now - Date.parse(s.lastPingAt) > STALE_PING_MS;
              const moving = (s.lastSpeedMps ?? 0) > 1.5;
              const forgotten = now - Date.parse(s.clockInAt) > FORGOTTEN_SHIFT_MS;
              const site = s.siteId ? siteById.get(s.siteId) : null;
              const onSite = site ? isOnSite(s.clockInDistanceM, site.radiusM, s.clockInAccuracyM) : null;
              return (
                <div key={s.id} className={`px-4 py-3 flex items-center gap-3 ${focus === s.id ? "bg-slate-800/60" : ""}`}>
                  <span className={`w-3 h-3 rounded-full shrink-0 ${stale ? "bg-amber-500" : moving ? "bg-green-500 animate-pulse" : "bg-sky-400"}`} />
                  <button className="flex-1 min-w-0 text-left" onClick={() => setFocus(focus === s.id ? null : s.id)}>
                    <div className="text-white font-medium text-sm flex items-center gap-2 flex-wrap">
                      {s.userName}
                      {s.method === "manual" && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">manual clock-in</span>
                      )}
                      {onSite === false && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-300 border border-red-500/30">
                          clocked in {formatDistance(s.clockInDistanceM)} away
                        </span>
                      )}
                      {forgotten && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700 text-slate-300">14h+ — forgot to clock out?</span>
                      )}
                    </div>
                    <div className="text-slate-400 text-xs mt-0.5">
                      in at {new Date(s.clockInAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                      {s.siteName ? ` · ${s.siteName}` : ""}
                      {" · "}{formatDuration(now - Date.parse(s.clockInAt))}
                      {" · "}
                      {stale ? (
                        <span className="text-amber-300">signal lost {formatAgo(s.lastPingAt, now)}</span>
                      ) : (
                        <>{moving ? `moving${formatSpeed(s.lastSpeedMps) ? ` ${formatSpeed(s.lastSpeedMps)}` : ""}` : "stopped"} · {formatAgo(s.lastPingAt, now)}</>
                      )}
                    </div>
                  </button>
                  <button
                    onClick={() => void showTrail(s.id)}
                    className={`text-xs px-2.5 py-1.5 rounded-lg border ${trailFor === s.id ? "bg-sky-500/20 border-sky-500/40 text-sky-300" : "border-slate-700 text-slate-300 hover:bg-slate-800"}`}
                  >
                    {trailFor === s.id ? "Hide route" : "Route"}
                  </button>
                  <button
                    onClick={() => void clockOutFromOffice(s)}
                    disabled={busy === s.id}
                    className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-700 text-slate-400 hover:text-red-300 hover:border-red-500/40 disabled:opacity-50"
                  >
                    Clock out
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Timesheet */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-white font-semibold">Timesheet</h2>
          <input
            type="date"
            value={date}
            onChange={(e) => e.target.value && setDate(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white"
          />
        </div>
        {day.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">No shifts on this day.</div>
        ) : (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="text-left text-xs text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="px-4 py-2 font-medium">Who</th>
                  <th className="px-4 py-2 font-medium">In</th>
                  <th className="px-4 py-2 font-medium">Out</th>
                  <th className="px-4 py-2 font-medium">Hours</th>
                  <th className="px-4 py-2 font-medium hidden sm:table-cell">How</th>
                  <th className="px-4 py-2 font-medium hidden sm:table-cell">Pings</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {day.map((s) => {
                  const end = s.clockOutAt ? Date.parse(s.clockOutAt) : now;
                  const site = s.siteId ? siteById.get(s.siteId) : null;
                  const onSite = site ? isOnSite(s.clockInDistanceM, site.radiusM, s.clockInAccuracyM) : null;
                  return (
                    <tr key={s.id} className="text-slate-200">
                      <td className="px-4 py-2.5 font-medium">{s.userName}</td>
                      <td className="px-4 py-2.5 tabular-nums">{new Date(s.clockInAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}</td>
                      <td className="px-4 py-2.5 tabular-nums">
                        {s.clockOutAt ? new Date(s.clockOutAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }) : <span className="text-green-400">on clock</span>}
                      </td>
                      <td className="px-4 py-2.5 tabular-nums">{formatDuration(end - Date.parse(s.clockInAt))}</td>
                      <td className="px-4 py-2.5 hidden sm:table-cell text-xs">
                        {s.method === "qr" ? "QR" : <span className="text-amber-300">manual</span>}
                        {onSite === false && <span className="text-red-300"> · {formatDistance(s.clockInDistanceM)} away</span>}
                        {onSite === true && <span className="text-slate-500"> · on site</span>}
                      </td>
                      <td className="px-4 py-2.5 hidden sm:table-cell text-xs text-slate-400">{s.pingCount}</td>
                      <td className="px-4 py-2.5 text-right">
                        <button onClick={() => void showTrail(s.id)} className="text-xs text-accent-400 hover:underline">
                          {trailFor === s.id ? "hide" : "route"}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="text-slate-500 text-xs mt-2">
          {closedToday.length} finished · {day.filter((s) => s.status === "active").length} still on
        </p>
      </section>
    </div>
  );
}
