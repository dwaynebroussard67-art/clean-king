"use client";

import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import type { Map as LeafletMap, LayerGroup, Marker, Circle, Polyline } from "leaflet";
import { STALE_PING_MS, formatAgo, formatSpeed } from "@/lib/fleet";

export interface MapPerson {
  id: string;
  name: string;
  lat: number;
  lng: number;
  accuracyM: number | null;
  speedMps: number | null;
  lastPingAt: string | null;
  siteName: string | null;
}

export interface MapSite {
  id: string;
  name: string;
  lat: number;
  lng: number;
  radiusM: number;
}

export interface MapTrail {
  points: [number, number][];
  color?: string;
}

/**
 * Leaflet + OpenStreetMap. No API key, no per-load cost, and it works the
 * moment the app is deployed — which matters when the owner's first question
 * is "can I see it right now".
 *
 * Leaflet touches `window` on import, so it's loaded inside the effect. The
 * component is a thin imperative shell: React owns the data, Leaflet owns
 * the DOM inside the container.
 */
export function LiveMap({
  people,
  sites,
  trail,
  focus,
  height = 420,
}: {
  people: MapPerson[];
  sites: MapSite[];
  trail?: MapTrail | null;
  /** Person id to keep centred, if any. */
  focus?: string | null;
  height?: number | string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const layersRef = useRef<{ people: LayerGroup; sites: LayerGroup; trail: LayerGroup } | null>(null);
  const markersRef = useRef<Map<string, Marker>>(new Map());
  const fittedRef = useRef(false);

  // Mount once.
  useEffect(() => {
    let cancelled = false;
    const markers = markersRef.current;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !containerRef.current || mapRef.current) return;

      const map = L.map(containerRef.current, {
        zoomControl: true,
        attributionControl: true,
      }).setView([29.97, -92.13], 12); // Abbeville until data arrives

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(map);

      layersRef.current = {
        sites: L.layerGroup().addTo(map),
        trail: L.layerGroup().addTo(map),
        people: L.layerGroup().addTo(map),
      };
      mapRef.current = map;
      // Trigger the data effect now that the map exists.
      setTimeout(() => map.invalidateSize(), 0);
    })();
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      layersRef.current = null;
      markers.clear();
      fittedRef.current = false;
    };
  }, []);

  // Sync data -> layers.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      const map = mapRef.current;
      const layers = layersRef.current;
      if (cancelled || !map || !layers) return;

      // Sites
      layers.sites.clearLayers();
      for (const s of sites) {
        (L.circle([s.lat, s.lng], {
          radius: s.radiusM,
          color: "#22c55e",
          weight: 1,
          fillColor: "#22c55e",
          fillOpacity: 0.08,
        }) as Circle).bindTooltip(s.name, { permanent: false }).addTo(layers.sites);
        L.marker([s.lat, s.lng], { icon: siteIcon(L, s.name), interactive: false }).addTo(layers.sites);
      }

      // Trail
      layers.trail.clearLayers();
      if (trail && trail.points.length > 1) {
        (L.polyline(trail.points, {
          color: trail.color ?? "#38bdf8",
          weight: 4,
          opacity: 0.85,
        }) as Polyline).addTo(layers.trail);
        L.circleMarker(trail.points[0], { radius: 5, color: "#22c55e", fillColor: "#22c55e", fillOpacity: 1 })
          .bindTooltip("Clock-in")
          .addTo(layers.trail);
      }

      // People: update markers in place so the map doesn't flicker on poll.
      const seen = new Set<string>();
      const now = Date.now();
      for (const p of people) {
        seen.add(p.id);
        const stale = !p.lastPingAt || now - Date.parse(p.lastPingAt) > STALE_PING_MS;
        const moving = (p.speedMps ?? 0) > 1.5;
        const icon = personIcon(L, p.name, stale, moving);
        const popup = `<div style="font:13px system-ui;min-width:160px">
            <strong>${escapeHtml(p.name)}</strong><br/>
            ${stale ? "<span style='color:#f59e0b'>Signal lost</span>" : moving ? "<span style='color:#22c55e'>Moving</span>" : "Stopped"}
            ${formatSpeed(p.speedMps) ? ` · ${formatSpeed(p.speedMps)}` : ""}<br/>
            <span style="color:#64748b">Last fix ${formatAgo(p.lastPingAt, now)}${p.accuracyM != null ? ` · ±${Math.round(p.accuracyM)} m` : ""}</span>
            ${p.siteName ? `<br/><span style="color:#64748b">Clocked in at ${escapeHtml(p.siteName)}</span>` : ""}
          </div>`;
        const existing = markersRef.current.get(p.id);
        if (existing) {
          existing.setLatLng([p.lat, p.lng]);
          existing.setIcon(icon);
          existing.setPopupContent(popup);
        } else {
          const m = L.marker([p.lat, p.lng], { icon, zIndexOffset: 1000 }).bindPopup(popup).addTo(layers.people);
          markersRef.current.set(p.id, m);
        }
      }
      for (const [id, m] of markersRef.current) {
        if (!seen.has(id)) {
          layers.people.removeLayer(m);
          markersRef.current.delete(id);
        }
      }

      // Framing: follow the focused person, else fit everything once.
      if (focus) {
        const f = people.find((p) => p.id === focus);
        if (f) map.setView([f.lat, f.lng], Math.max(map.getZoom(), 14), { animate: true });
      } else if (!fittedRef.current) {
        const pts: [number, number][] = [
          ...people.map((p) => [p.lat, p.lng] as [number, number]),
          ...sites.map((s) => [s.lat, s.lng] as [number, number]),
          ...(trail?.points ?? []),
        ];
        if (pts.length === 1) {
          map.setView(pts[0], 15);
          fittedRef.current = true;
        } else if (pts.length > 1) {
          map.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 16 });
          fittedRef.current = true;
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [people, sites, trail, focus]);

  return (
    <div
      ref={containerRef}
      style={{ height }}
      className="w-full rounded-2xl overflow-hidden border border-slate-800 bg-slate-900 [&_.leaflet-container]:bg-slate-900 [&_.leaflet-control-attribution]:text-[10px]"
    />
  );
}

function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

function personIcon(L: typeof import("leaflet"), name: string, stale: boolean, moving: boolean) {
  const bg = stale ? "#f59e0b" : moving ? "#22c55e" : "#38bdf8";
  return L.divIcon({
    className: "",
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18],
    html: `<div style="width:36px;height:36px;border-radius:50%;background:${bg};color:#0f172a;display:flex;align-items:center;justify-content:center;font:700 13px system-ui;border:3px solid #0f172a;box-shadow:0 2px 8px rgba(0,0,0,.5);${stale ? "opacity:.75" : ""}">${escapeHtml(initials(name))}</div>`,
  });
}

function siteIcon(L: typeof import("leaflet"), name: string) {
  return L.divIcon({
    className: "",
    iconSize: [1, 1],
    iconAnchor: [0, 0],
    html: `<div style="transform:translate(-50%,-140%);white-space:nowrap;background:#0f172a;color:#86efac;border:1px solid #22c55e;border-radius:6px;padding:2px 6px;font:600 11px system-ui">🏬 ${escapeHtml(name)}</div>`,
  });
}
