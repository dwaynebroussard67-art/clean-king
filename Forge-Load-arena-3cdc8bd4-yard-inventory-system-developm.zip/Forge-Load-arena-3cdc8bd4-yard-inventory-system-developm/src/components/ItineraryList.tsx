"use client";

import { useEffect, useState } from "react";
import type { ItineraryItem } from "@/hooks/useShift";

/**
 * Today's orders, as the crew see them. Given `items` it renders them; given
 * null it fetches the caller's own for today. Either way the office's note
 * is shown big and plain — this is read on a phone in a truck cab.
 */
export function ItineraryList({
  items,
  emptyText = "Nothing posted for today.",
}: {
  items: ItineraryItem[] | null;
  emptyText?: string;
}) {
  const [fetched, setFetched] = useState<ItineraryItem[] | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (items !== null) return;
    let cancelled = false;
    fetch("/api/itineraries")
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => {
        if (!cancelled) setFetched(d.itineraries ?? []);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [items]);

  const list = items ?? fetched;

  if (failed) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-slate-400 text-sm">
        Couldn&rsquo;t load today&rsquo;s orders. They&rsquo;ll show once you&rsquo;re back in signal.
      </div>
    );
  }
  if (list === null) {
    return <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-slate-500 text-sm animate-pulse">Loading…</div>;
  }
  if (list.length === 0) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-slate-400 text-sm">
        {emptyText}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {list.map((it) => (
        <article
          key={it.id}
          className={`rounded-xl border px-4 py-3 ${
            it.priority === "high"
              ? "bg-amber-500/10 border-amber-500/30"
              : "bg-slate-900 border-slate-800"
          }`}
        >
          <div className="flex items-start gap-2">
            {it.priority === "high" && <span className="text-amber-400 text-lg leading-none mt-0.5">!</span>}
            <div className="flex-1 min-w-0">
              <h3 className="text-white font-semibold text-base leading-snug">{it.title}</h3>
              {it.body && (
                <p className="text-slate-300 text-sm mt-1.5 whitespace-pre-wrap leading-relaxed">{it.body}</p>
              )}
              <div className="text-slate-500 text-xs mt-2">
                {it.assigneeId ? "For you" : "For everyone"}
                {it.createdByName ? ` · from ${it.createdByName.split(" ")[0]}` : ""}
              </div>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}
