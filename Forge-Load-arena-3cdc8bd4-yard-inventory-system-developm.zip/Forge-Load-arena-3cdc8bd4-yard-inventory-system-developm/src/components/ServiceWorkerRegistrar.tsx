"use client";

import { useEffect } from "react";

/**
 * Registers the service worker that makes the app usable in the yard's dead
 * spots. Mounted once from the root layout.
 *
 * Deliberately skipped in development — a caching worker during `next dev`
 * serves stale bundles and produces very confusing debugging sessions.
 */
export function ServiceWorkerRegistrar() {
  useEffect(() => {
    if (process.env.NODE_ENV !== "production") return;
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;

    let cancelled = false;

    const register = async () => {
      try {
        const registration = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
        });
        if (cancelled) return;

        // If a new worker is already waiting from a previous visit, let it take
        // over now rather than pinning the crew to a stale build.
        if (registration.waiting) {
          registration.waiting.postMessage("SKIP_WAITING");
        }

        registration.addEventListener("updatefound", () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener("statechange", () => {
            if (
              installing.state === "installed" &&
              navigator.serviceWorker.controller
            ) {
              installing.postMessage("SKIP_WAITING");
            }
          });
        });
      } catch (err) {
        // A failed registration must never break the app — it just means no
        // offline support on this device.
        console.warn("[sw] registration failed", err);
      }
    };

    // Wait for load so the worker install doesn't compete with first paint.
    if (document.readyState === "complete") {
      void register();
    } else {
      window.addEventListener("load", register, { once: true });
    }

    // Reload once when a new worker takes control, so the UI matches the assets.
    let reloading = false;
    const onControllerChange = () => {
      if (reloading) return;
      reloading = true;
      window.location.reload();
    };
    navigator.serviceWorker.addEventListener("controllerchange", onControllerChange);

    return () => {
      cancelled = true;
      navigator.serviceWorker.removeEventListener(
        "controllerchange",
        onControllerChange
      );
    };
  }, []);

  return null;
}
