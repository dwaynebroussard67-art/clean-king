import { NextResponse } from "next/server";
import { tenant, withArticle } from "@/lib/tenant";

/**
 * The PWA manifest, generated per tenant.
 *
 * This used to be a static public/manifest.json, which meant the name a crew
 * saw on their home screen after "Add to Home Screen" was baked in at build
 * time and wrong for every customer but the first.
 */
export function GET() {
  return NextResponse.json(
    {
      name: tenant.name,
      short_name: tenant.shortName,
      description: tenant.tagline,
      start_url: "/",
      scope: "/",
      display: "standalone",
      orientation: "portrait",
      background_color: "#0f172a",
      theme_color: "#0f172a",
      categories: ["business", "productivity"],
      // Generated per tenant by src/app/icon.tsx — see that file. Served from
      // /icon so a rebrand doesn't require new artwork.
      icons: [
        { src: "/icon", sizes: "192x192", type: "image/png", purpose: "any" },
        { src: "/icon", sizes: "192x192", type: "image/png", purpose: "maskable" },
      ],
      shortcuts: [
        {
          name: "Clock in",
          short_name: "Clock in",
          url: "/clock-in",
          icons: [{ src: "/icon", sizes: "192x192" }],
        },
        {
          name: "Morning truck check",
          short_name: "Truck check",
          url: "/truck-check",
          icons: [{ src: "/icon", sizes: "192x192" }],
        },
        {
          name: `Scan ${withArticle(tenant.terms.unit)}`,
          short_name: "Scan",
          url: "/scan",
          icons: [{ src: "/icon", sizes: "192x192" }],
        },
        {
          name: "Report damage",
          short_name: "Damage",
          url: "/damage",
          icons: [{ src: "/icon", sizes: "192x192" }],
        },
      ],
    },
    {
      headers: {
        "Content-Type": "application/manifest+json",
        // Short cache: a rebrand should reach installed phones the same day.
        "Cache-Control": "public, max-age=3600",
      },
    }
  );
}
