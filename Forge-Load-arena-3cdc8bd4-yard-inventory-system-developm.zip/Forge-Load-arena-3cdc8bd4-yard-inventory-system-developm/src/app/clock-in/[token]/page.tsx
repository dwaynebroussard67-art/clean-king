import { redirect } from "next/navigation";

/**
 * The URL printed on the poster: /clock-in/K7XM2PQ9RT
 *
 * A phone's built-in camera app opens this directly, which means a crew
 * member never has to find the app first — scan, and you're on the clock-in
 * screen with the token already filled in. Kept as a redirect so the real
 * screen has one code path whichever way the token arrived.
 */
export default async function ClockInTokenPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  redirect(`/clock-in?t=${encodeURIComponent(token)}`);
}
