"use client";

import { Suspense, useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { useShift, type ItineraryItem } from "@/hooks/useShift";
import { NavBar } from "@/components/NavBar";
import { ShiftStatusCard } from "@/components/ShiftStatusCard";
import { ItineraryList } from "@/components/ItineraryList";
import {
  startScanner as startScannerEngine,
  cameraAvailability,
  type ScannerHandle,
} from "@/lib/scanner";
import { parseSiteToken } from "@/lib/fleet";
import { requestPosition } from "@/lib/tracker";
import { tenant } from "@/lib/tenant";

type Stage = "idle" | "locating" | "scanning" | "submitting" | "done";

/**
 * Clock in.
 *
 * The order of operations is the whole design:
 *   1. Ask for location *first*, with an explanation on screen. The browser
 *      prompt lands while the crew member is reading why.
 *   2. Then open the camera and scan the poster.
 *   3. Then POST. The server pairs the scan with the fix and works out how far
 *      from the shop they were.
 *   4. Show "you're in" plus whatever the office left for them today.
 *
 * A manual clock-in (no scan) is allowed but recorded as such, so the
 * timesheet shows the difference between "scanned at the door" and "tapped
 * the button from wherever".
 */
function ClockInScreen() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { shift, tracker, loading: shiftLoading, clockIn, clockOut, refresh } = useShift();

  const [stage, setStage] = useState<Stage>("idle");
  const [error, setError] = useState("");
  const [manualCode, setManualCode] = useState("");
  const [result, setResult] = useState<{
    itinerary: ItineraryItem[];
    alreadyActive: boolean;
    siteName: string | null;
  } | null>(null);
  const [clockingOut, setClockingOut] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerRef = useRef<ScannerHandle | null>(null);
  const autoTokenTried = useRef(false);

  const cameraBlocked = useSyncExternalStore(
    () => () => {},
    () => {
      const a = cameraAvailability();
      return a.ok ? null : (a.reason ?? "Camera unavailable");
    },
    () => null
  );

  useEffect(() => {
    if (!authLoading && !user) router.replace("/login?next=/clock-in");
  }, [user, authLoading, router]);

  const stopCamera = useCallback(() => {
    scannerRef.current?.stop();
    scannerRef.current = null;
  }, []);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const submit = useCallback(
    async (token: string | null) => {
      stopCamera();
      setStage("submitting");
      setError("");
      try {
        const r = await clockIn(token);
        setResult({ itinerary: r.itinerary, alreadyActive: r.alreadyActive, siteName: r.site?.name ?? null });
        setStage("done");
      } catch (e) {
        setError(e instanceof Error ? e.message : "Could not clock in");
        setStage("idle");
      }
    },
    [clockIn, stopCamera]
  );

  // Arrived via the poster URL (/clock-in/TOKEN redirects here with ?t=): a
  // phone's own camera app scanned it, so skip our scanner and go straight
  // to location + submit.
  useEffect(() => {
    const t = searchParams.get("t");
    if (!t || autoTokenTried.current || shiftLoading || authLoading || !user) return;
    if (shift) {
      autoTokenTried.current = true; // already in; the status card explains
      return;
    }
    // Deferred a tick: this kicks off a network round-trip in response to
    // arriving via the poster URL, and it shouldn't set state mid-effect. The
    // "tried" flag is set inside the callback so a cancelled timer can retry.
    const token = parseSiteToken(t) ?? "INVALID";
    const handle = setTimeout(() => {
      if (autoTokenTried.current) return;
      autoTokenTried.current = true;
      void submit(token);
    }, 0);
    return () => clearTimeout(handle);
  }, [searchParams, shiftLoading, authLoading, user, shift, submit]);

  const begin = useCallback(async () => {
    setError("");
    setStage("locating");
    const pos = await requestPosition();
    if (!pos) {
      // Denied or failed. Explain and stop: clocking in without location is
      // exactly the thing the owner doesn't want, so it's the manual path
      // with a warning rather than a silent fallback.
      setStage("idle");
      setError(
        tracker.lastError ||
          "We need your location to clock you in. Turn it on for this site and try again."
      );
      return;
    }

    if (cameraBlocked) {
      setStage("idle");
      return; // manual entry field is visible below
    }

    setStage("scanning");
    await new Promise((r) => requestAnimationFrame(r));
    const video = videoRef.current;
    if (!video) {
      setStage("idle");
      setError("Could not start the camera view.");
      return;
    }
    try {
      scannerRef.current = await startScannerEngine({
        video,
        onResult: (value) => {
          const token = parseSiteToken(value);
          if (!token) {
            setError("That's not a clock-in code. Scan the poster by the door.");
            return;
          }
          void submit(token);
        },
      });
    } catch (err) {
      setStage("idle");
      setError(
        err instanceof Error && err.name === "NotAllowedError"
          ? "Camera permission denied. Type the code from the poster below instead."
          : err instanceof Error
            ? err.message
            : "Camera unavailable. Type the code from the poster below."
      );
    }
  }, [cameraBlocked, submit, tracker.lastError]);

  const handleManual = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = parseSiteToken(manualCode);
    if (!token) {
      setError("Codes are the letters and numbers printed under the QR square.");
      return;
    }
    setStage("locating");
    const pos = await requestPosition();
    if (!pos) {
      setStage("idle");
      setError(tracker.lastError || "We need your location to clock you in.");
      return;
    }
    void submit(token);
  };

  const handleClockOut = async () => {
    if (!confirm("Clock out now? Location tracking stops when you do.")) return;
    setClockingOut(true);
    setError("");
    try {
      await clockOut();
      setResult(null);
      setStage("idle");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not clock out");
    } finally {
      setClockingOut(false);
    }
  };

  if (authLoading || !user || shiftLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  // ── Clocked in ────────────────────────────────────────────────────────────
  if (shift) {
    return (
      <div className="min-h-screen bg-slate-950">
        <NavBar />
        <main className="max-w-lg mx-auto px-4 py-6 pb-28 sm:pb-8 space-y-4">
          {stage === "done" && result && (
            <div className="bg-green-500/10 border border-green-500/30 rounded-2xl px-4 py-4">
              <div className="text-green-300 font-semibold text-lg">
                {result.alreadyActive ? "You were already clocked in" : "You're clocked in"}
                {result.siteName ? ` at ${result.siteName}` : ""}
              </div>
              <div className="text-green-400/80 text-sm mt-1">
                {new Date(shift.clockInAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                {" · "}location is on for this shift
              </div>
            </div>
          )}

          <ShiftStatusCard shift={shift} tracker={tracker} />

          <section>
            <h2 className="text-white font-semibold mb-2">Today from the office</h2>
            <ItineraryList
              items={result?.itinerary ?? null}
              emptyText="Nothing posted for today yet. Check back after you've started — the office can add to this during the day."
            />
          </section>

          <div className="grid grid-cols-2 gap-3">
            <Link
              href="/truck-check"
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex flex-col items-center gap-1 text-center"
            >
              <span className="text-2xl">🛻</span>
              <span className="text-white text-sm font-semibold">Morning truck check</span>
              <span className="text-slate-400 text-xs">Before you roll</span>
            </Link>
            <button
              onClick={handleClockOut}
              disabled={clockingOut}
              className="bg-slate-900 border border-slate-800 hover:border-red-500/40 rounded-xl p-4 flex flex-col items-center gap-1 text-center disabled:opacity-50"
            >
              <span className="text-2xl">🏁</span>
              <span className="text-white text-sm font-semibold">
                {clockingOut ? "Clocking out…" : "Clock out"}
              </span>
              <span className="text-slate-400 text-xs">End of day</span>
            </button>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-300 text-sm">
              {error}
            </div>
          )}

          <button onClick={() => void refresh()} className="w-full text-slate-500 text-xs py-2">
            Refresh
          </button>
        </main>
      </div>
    );
  }

  // ── Not clocked in ────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-lg mx-auto px-4 py-6 pb-28 sm:pb-8">
        <h1 className="text-2xl font-bold text-white mb-1">Clock in</h1>
        <p className="text-slate-400 text-sm mb-6">
          Scan the poster by the door. Your location stays on while you&rsquo;re on the clock so the
          office can see the trucks.
        </p>

        {stage === "scanning" ? (
          <div className="bg-black rounded-2xl overflow-hidden border border-slate-800 relative aspect-[3/4] max-h-[60vh]">
            <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-56 h-56 border-2 border-accent-400 rounded-2xl shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]" />
            </div>
            <div className="absolute bottom-0 inset-x-0 p-4 flex items-center justify-between bg-gradient-to-t from-black/80 to-transparent">
              <span className="text-white text-sm">Point at the QR square</span>
              <button
                onClick={() => {
                  stopCamera();
                  setStage("idle");
                }}
                className="text-slate-300 text-sm px-3 py-1.5 rounded-lg bg-slate-800/80"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={begin}
            disabled={stage === "locating" || stage === "submitting"}
            className="w-full bg-accent-500 hover:bg-accent-600 active:scale-[0.98] disabled:opacity-60 text-white font-bold text-xl rounded-2xl py-10 text-center transition-all shadow-lg shadow-accent-500/20"
          >
            <div className="text-5xl mb-2">
              {stage === "locating" ? "📍" : stage === "submitting" ? "⏳" : "📷"}
            </div>
            {stage === "locating"
              ? "Getting your location…"
              : stage === "submitting"
                ? "Clocking you in…"
                : "Scan to clock in"}
          </button>
        )}

        {/* Location permission state, spelled out. */}
        <div className="mt-4 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 flex items-start gap-3">
          <span className="text-xl leading-none mt-0.5">
            {tracker.permission === "granted" ? "✅" : tracker.permission === "denied" ? "⛔" : "📍"}
          </span>
          <div className="text-sm">
            <div className="text-white font-medium">
              {tracker.permission === "granted"
                ? "Location is on"
                : tracker.permission === "denied"
                  ? "Location is blocked for this site"
                  : "Location is required to clock in"}
            </div>
            <div className="text-slate-400 text-xs mt-0.5">
              {tracker.permission === "denied"
                ? "Open your phone's browser settings for this site and allow Location, then come back."
                : "Tracking runs only between clock-in and clock-out. It stops the moment you clock out."}
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-300 text-sm">
            {error}
          </div>
        )}

        {/* Manual code entry */}
        <form onSubmit={handleManual} className="mt-6">
          <label className="block text-xs text-slate-500 mb-1.5">
            {cameraBlocked ? `Camera unavailable (${cameraBlocked}). ` : "Camera not working? "}
            Type the code printed under the QR square.
          </label>
          <div className="flex gap-2">
            <input
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value.toUpperCase())}
              placeholder="e.g. K7XM2PQ9RT"
              autoCapitalize="characters"
              autoCorrect="off"
              spellCheck={false}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 font-mono tracking-wider focus:outline-none focus:border-accent-500"
            />
            <button
              type="submit"
              disabled={!manualCode.trim() || stage === "submitting"}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-white font-semibold px-5 rounded-xl"
            >
              Go
            </button>
          </div>
        </form>

        <div className="mt-8 border-t border-slate-800 pt-4">
          <button
            onClick={async () => {
              if (!confirm("Clock in without scanning? This is recorded as a manual clock-in, and the office will see how far you were from the shop.")) return;
              setStage("locating");
              const pos = await requestPosition();
              if (!pos) {
                setStage("idle");
                setError(tracker.lastError || "We need your location to clock you in.");
                return;
              }
              void submit(null);
            }}
            disabled={stage === "locating" || stage === "submitting"}
            className="w-full text-slate-500 hover:text-slate-300 text-sm py-2"
          >
            Can&rsquo;t reach the poster? Clock in manually
          </button>
        </div>
      </main>
    </div>
  );
}

export default function ClockInPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-950 flex items-center justify-center">
          <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
        </div>
      }
    >
      <ClockInScreen />
    </Suspense>
  );
}
