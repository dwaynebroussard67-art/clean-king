"use client";

import Link from "next/link";

/**
 * Shown by the service worker when a page is requested that isn't cached and
 * there's no signal. Kept deliberately dependency-free so it renders from cache.
 */
export default function OfflinePage() {
  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6">
      <div className="w-full max-w-sm text-center">
        <div className="text-6xl mb-4">📡</div>
        <h1 className="text-2xl font-bold text-white mb-2">No signal</h1>
        <p className="text-slate-400 text-sm mb-6">
          You&rsquo;re offline and this screen hasn&rsquo;t been loaded yet. Anything you
          scanned or pulled is saved on this device and will sync automatically
          once you&rsquo;re back in range.
        </p>

        <div className="space-y-2">
          <button
            onClick={() => window.location.reload()}
            className="w-full bg-accent-500 hover:bg-accent-600 text-white font-bold py-3 rounded-xl transition-colors"
          >
            Try again
          </button>
          <Link
            href="/"
            className="block w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl transition-colors"
          >
            Go to home
          </Link>
        </div>
      </div>
    </div>
  );
}
