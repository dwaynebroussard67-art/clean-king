import { ImageResponse } from "next/og";
import { tenant } from "@/lib/tenant";

/**
 * Per-tenant app icon, generated rather than shipped as artwork.
 *
 * Uses the tenant's letter monogram, not its emoji mark: @vercel/og renders
 * emoji by fetching an SVG from a public CDN at build time, which fails in
 * air-gapped CI and couples deploys to a third-party host. Letters render from
 * the bundled font with no network access.
 *
 * Every tenant used to install with the same home-screen icon, which is a poor
 * look when you're selling the app as theirs. Generating it from the tenant's
 * mark and accent colour means a new customer gets a correct icon on day one
 * with no design work — and if they later supply real artwork, this file is
 * the only thing that has to go.
 *
 * Next renders these at build time for static export and caches them, so
 * there's no per-request cost.
 */
export const size = { width: 192, height: 192 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          // Deep slate matches the app chrome, so the icon reads as the same
          // product on a home screen full of other apps.
          background: "#0f172a",
          // The accent sits behind the mark as a ring rather than a fill: a
          // solid bright square is hard to look at at 192px on a phone.
          borderRadius: 40,
          border: `10px solid ${tenant.theme.accentHex}`,
          fontSize: 80,
          fontWeight: 700,
          color: "#f8fafc",
          letterSpacing: -2,
        }}
      >
        {tenant.monogram}
      </div>
    ),
    size
  );
}
