"use client";

import { useEffect, useState, useRef, useCallback, useSyncExternalStore } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { NavBar } from "@/components/NavBar";
import { BundleDetail } from "@/components/BundleDetail";
import {
  startScanner as startScannerEngine,
  cameraAvailability,
  describeEngine,
  normalizeScannedValue,
  type ScannerHandle,
  type ScanEngine,
} from "@/lib/scanner";
import { tenant, Unit, terms } from "@/lib/tenant";

type ScanState = "idle" | "scanning" | "found" | "not_found";

const _prefix = tenant.key === "earls-furniture" ? "ITM" : "BND";
const codeHint = `${_prefix}-${new Date().getFullYear()}-000001`;

export default function ScanPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [scanState, setScanState] = useState<ScanState>("idle");
  const [manualCode, setManualCode] = useState("");
  const [bundleId, setBundleId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [engine, setEngine] = useState<ScanEngine | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerRef = useRef<ScannerHandle | null>(null);

  // Camera support is a property of the environment, not state to sync — read
  // it during render (post-hydration) so an iPhone on plain http, or a
  // locked-down browser, points the crew at manual entry instead of a dead button.
  const cameraBlocked = useSyncExternalStore(
    () => () => {},
    () => {
      const availability = cameraAvailability();
      return availability.ok ? null : (availability.reason ?? "Camera unavailable");
    },
    () => null // server render: assume available, corrected on hydration
  );

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/scan");
  }, [user, loading, router]);

  const stopCamera = useCallback(() => {
    scannerRef.current?.stop();
    scannerRef.current = null;
  }, []);

  const lookupBundle = useCallback(
    async (code: string) => {
      try {
        const res = await fetch(`/api/bundles/${encodeURIComponent(code)}`);
        if (res.ok) {
          const data = await res.json();
          setBundleId(data.bundle.id);
          setScanState("found");
        } else if (res.status === 404) {
          setError(`${Unit} "${code}" not found`);
          setScanState("not_found");
        } else {
          setError("Lookup failed. Check your connection and try again.");
          setScanState("not_found");
        }
      } catch {
        setError(`Error looking up ${terms.unit}. Check your connection.`);
        setScanState("not_found");
      } finally {
        stopCamera();
      }
    },
    [stopCamera]
  );

  const handleStart = useCallback(async () => {
    setScanState("scanning");
    setError("");
    setBundleId(null);
    setEngine(null);

    // The <video> only mounts with the "scanning" state, so wait a frame for it.
    await new Promise((resolve) => requestAnimationFrame(resolve));

    const video = videoRef.current;
    if (!video) {
      setError("Could not initialise the camera view.");
      setScanState("idle");
      return;
    }

    try {
      scannerRef.current = await startScannerEngine({
        video,
        onResult: (value) => void lookupBundle(value),
        onEngine: setEngine,
      });
    } catch (err) {
      const message =
        err instanceof Error && err.name === "NotAllowedError"
          ? "Camera permission denied. Allow camera access in your browser settings, or use manual entry below."
          : err instanceof Error
            ? err.message
            : "Camera unavailable. Use manual entry below.";
      setError(message);
      setScanState("idle");
    }
  }, [lookupBundle]);

  useEffect(() => () => stopCamera(), [stopCamera]);

  const handleManualLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    setError("");
    setScanState("scanning");
    await lookupBundle(normalizeScannedValue(manualCode));
  };

  const reset = () => {
    stopCamera();
    setScanState("idle");
    setBundleId(null);
    setError("");
    setManualCode("");
    setEngine(null);
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-2xl mx-auto px-4 py-6 pb-24 sm:pb-6">
        {scanState === "found" && bundleId ? (
          <BundleDetail bundleId={bundleId} user={user} onBack={reset} />
        ) : (
          <>
            <h1 className="text-2xl font-bold text-white mb-6">Scan {Unit}</h1>

            {/* Camera view */}
            {scanState === "scanning" && (
              <div
                className="relative bg-black rounded-2xl overflow-hidden mb-4"
                style={{ aspectRatio: "4/3" }}
              >
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  playsInline
                  muted
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-56 h-56 border-2 border-accent-500 rounded-2xl relative">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-accent-500 rounded-tl-xl" />
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-accent-500 rounded-tr-xl" />
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-accent-500 rounded-bl-xl" />
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-accent-500 rounded-br-xl" />
                    <div
                      className="absolute inset-x-0 h-0.5 bg-accent-500 opacity-80 animate-bounce"
                      style={{ top: "50%" }}
                    />
                  </div>
                </div>
                <div className="absolute bottom-4 left-0 right-0 text-center text-white text-sm">
                  Point camera at QR code
                  {engine && (
                    <span className="block text-[11px] text-slate-400 mt-0.5">
                      {describeEngine(engine)}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Idle state */}
            {scanState === "idle" && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center mb-4">
                <div className="text-6xl mb-4">📷</div>
                <h2 className="text-white font-semibold text-lg mb-2">Ready to Scan</h2>
                <p className="text-slate-400 text-sm mb-6">
                  {cameraBlocked
                    ? `Camera isn't available on this device — enter the ${terms.unit} code below.`
                    : `Point your camera at a ${terms.unit} QR code, or enter the code manually`}
                </p>
                {!cameraBlocked && (
                  <button
                    onClick={handleStart}
                    className="w-full bg-accent-500 hover:bg-accent-600 text-white font-bold py-4 rounded-xl text-lg transition-colors"
                  >
                    Start Camera
                  </button>
                )}
              </div>
            )}

            {scanState === "scanning" && (
              <button
                onClick={reset}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl mb-4 transition-colors"
              >
                Cancel
              </button>
            )}

            {/* Camera unsupported notice */}
            {cameraBlocked && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-3 text-amber-300 text-sm mb-4">
                {cameraBlocked}
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-4">
                {error}
              </div>
            )}

            {/* Manual entry */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <h3 className="text-sm font-semibold text-slate-300 mb-3">Manual Entry</h3>
              <form onSubmit={handleManualLookup} className="flex gap-2">
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder={`${codeHint} or UUID`}
                  autoCapitalize="characters"
                  autoCorrect="off"
                  spellCheck={false}
                  enterKeyHint="go"
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-accent-500"
                />
                <button
                  type="submit"
                  className="bg-accent-500 hover:bg-accent-600 text-white font-semibold px-4 py-2.5 rounded-xl text-sm transition-colors"
                >
                  Go
                </button>
              </form>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
