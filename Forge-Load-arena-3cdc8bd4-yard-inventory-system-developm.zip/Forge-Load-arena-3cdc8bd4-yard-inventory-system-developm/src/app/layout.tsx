import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ServiceWorkerRegistrar } from "@/components/ServiceWorkerRegistrar";
import { tenant } from "@/lib/tenant";

/**
 * Every customer-visible string here comes from the tenant config, so standing
 * the app up for a new yard is an env var, not an edit.
 */
export const metadata: Metadata = {
  title: tenant.name,
  description: tenant.tagline,
  manifest: "/manifest.webmanifest",
  // Icons come from src/app/icon.tsx and apple-icon.tsx, which generate them
  // per tenant. Declaring them here too would override those with stale files.
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: tenant.shortName,
  },
  formatDetection: {
    // Item codes like ITM-2026-000123 get mangled into phone links on iOS.
    telephone: false,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  // Pinch-zoom is left enabled deliberately: crew read small codes in bright
  // sun, and locking zoom is an accessibility problem on a work device.
  viewportFit: "cover",
  themeColor: "#0f172a",
};

/**
 * The tenant's accent, injected as CSS variables that Tailwind's `accent-*`
 * utilities resolve against. This indirection is what makes a brand swap a
 * config change instead of a find-and-replace across ~180 class names.
 *
 * Emitted as a real <style> tag rather than an inline style attribute so the
 * variables are inherited by portals and anything else rendered outside <html>.
 */
/**
 * The 300/400 steps are where the accent is used as *text* on the near-black
 * chrome; 500/600 are fills with white on top. A tenant whose brand colour is
 * dark (Earl's hunter green) can't use one hex for both jobs -- it's either an
 * unreadable label or a washed-out button. accentHexTint splits the two, and
 * falls back to the accent itself when a brand colour is light enough to do
 * both, which is the case for Forge Load's orange.
 */
const ACCENT_TINT = tenant.theme.accentHexTint ?? tenant.theme.accentHex;

const ACCENT_CSS = `:root{
  --tenant-accent-300:${ACCENT_TINT};
  --tenant-accent-400:${ACCENT_TINT};
  --tenant-accent-500:${tenant.theme.accentHex};
  --tenant-accent-600:${tenant.theme.accentHexDark};
}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <style dangerouslySetInnerHTML={{ __html: ACCENT_CSS }} />
      </head>
      <body className="bg-slate-950 text-slate-100 antialiased min-h-screen">
        {children}
        <ServiceWorkerRegistrar />
      </body>
    </html>
  );
}
