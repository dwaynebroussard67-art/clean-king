"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { NavBar } from "@/components/NavBar";
import { CameraCapture, PhotoThumb } from "@/components/CameraCapture";
import { getGeo, type CapturedPhoto, type CaptureGeo } from "@/lib/camera";
import { uploadPhotos } from "@/lib/photo-upload";
import { enqueueDamage } from "@/lib/offline-queue";
import { generateDeviceId } from "@/lib/offline-queue";
import {
  startScanner,
  cameraAvailability,
  normalizeScannedValue,
  type ScannerHandle,
} from "@/lib/scanner";
import { tenant, Unit, terms } from "@/lib/tenant";

interface BundleInfo {
  id: string;
  code: string;
  productName: string | null;
  productSku: string | null;
  qtyRemaining: string;
  unit: string;
  location: string | null;
}

interface Job {
  id: string;
  code: string;
  customerName: string;
  status: string;
}

const REASONS = [
  { key: "forklift", label: "Forklift", icon: "🚜" },
  { key: "strapping", label: "Strapping", icon: "🪢" },
  { key: "weather", label: "Weather", icon: "🌧️" },
  { key: "defect", label: "Mill defect", icon: "🪵" },
  { key: "transit", label: "In transit", icon: "🚚" },
  { key: "handling", label: "Handling", icon: "🧤" },
  { key: "unknown", label: "Unknown", icon: "❓" },
  { key: "other", label: "Other", icon: "⋯" },
] as const;

const SEVERITIES = [
  { key: "minor", label: "Minor", hint: "Still sellable", color: "amber" },
  { key: "major", label: "Major", hint: "Downgrade", color: "orange" },
  { key: "total", label: "Total loss", hint: "Scrap it", color: "red" },
] as const;

const SUBJECTS = [
  { key: "material", label: "Material", icon: "🪵" },
  { key: "property", label: "Property", icon: "🏗️" },
  { key: "equipment", label: "Equipment", icon: "🔧" },
  { key: "vehicle", label: "Vehicle", icon: "🚚" },
] as const;

const STAGES = [
  { key: "receiving", label: "Receiving" },
  { key: "storage", label: "In the yard" },
  { key: "loading", label: "Loading out" },
  { key: "delivery", label: "On delivery" },
  { key: "return", label: "Return" },
] as const;

type Step = "camera" | "details" | "saving" | "done";

export default function DamagePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const [step, setStep] = useState<Step>("camera");
  const [photos, setPhotos] = useState<CapturedPhoto[]>([]);
  const [geo, setGeo] = useState<CaptureGeo | null>(null);

  const [subject, setSubject] = useState<string>("material");
  const [reason, setReason] = useState<string>("");
  const [severity, setSeverity] = useState<string>("minor");
  const [stage, setStage] = useState<string>("");
  const [bundle, setBundle] = useState<BundleInfo | null>(null);
  const [qty, setQty] = useState("");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [jobId, setJobId] = useState("");
  const [jobs, setJobs] = useState<Job[]>([]);
  const [writeOff, setWriteOff] = useState(false);

  const [scanning, setScanning] = useState(false);
  const [manualCode, setManualCode] = useState("");
  const [error, setError] = useState("");
  const [savedCode, setSavedCode] = useState("");

  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerRef = useRef<ScannerHandle | null>(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/damage");
  }, [user, loading, router]);

  useEffect(() => {
    if (!user) return;
    fetch("/api/jobs")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setJobs((d?.jobs || []).filter((j: Job) => j.status === "open")))
      .catch(() => {});
  }, [user]);

  // Ask for location as soon as the page opens so it's ready by the time the
  // report is filed. Never blocks anything.
  useEffect(() => {
    if (!user) return;
    void getGeo().then(setGeo);
  }, [user]);

  const handleCapture = (photo: CapturedPhoto) => {
    setPhotos((prev) => [...prev, photo]);
    setStep("details");
  };

  // No state is touched before the first await: this is also called from an
  // effect (the ?bundle= deep link), and a synchronous setState there would
  // cascade an extra render on every mount.
  const lookupBundle = useCallback(async (code: string) => {
    try {
      const res = await fetch(`/api/bundles/${encodeURIComponent(code)}`);
      if (!res.ok) {
        setError(`${Unit} "${code}" not found`);
        return;
      }
      const data = await res.json();
      setError("");
      setBundle(data.bundle);
      setLocation((prev) => prev || data.bundle.location || "");
    } catch {
      setError(`Couldn't look up that ${terms.unit}.`);
    }
  }, []);

  // Arriving from a bundle screen ("Damage" button) — the code is already known,
  // so pre-attach it rather than making the crew scan the same tag twice.
  // Read from location rather than useSearchParams: this page is a client
  // component and useSearchParams would force a Suspense boundary around it.
  useEffect(() => {
    if (!user) return;
    const code = new URLSearchParams(window.location.search).get("bundle");
    if (!code) return;

    let cancelled = false;
    (async () => {
      const res = await fetch(`/api/bundles/${encodeURIComponent(code)}`);
      if (cancelled) return;
      if (!res.ok) {
        setError(`${Unit} "${code}" not found`);
        return;
      }
      const data = await res.json();
      if (cancelled) return;
      setBundle(data.bundle);
      setLocation((prev) => prev || data.bundle.location || "");
    })().catch(() => {
      if (!cancelled) setError(`Couldn't look up that ${terms.unit}.`);
    });

    return () => {
      cancelled = true;
    };
  }, [user]);

  const stopScan = useCallback(() => {
    scannerRef.current?.stop();
    scannerRef.current = null;
    setScanning(false);
  }, []);

  const beginScan = async () => {
    const availability = cameraAvailability();
    if (!availability.ok) {
      setError(availability.reason ?? "Camera unavailable");
      return;
    }
    setScanning(true);
    setError("");
    await new Promise((r) => requestAnimationFrame(r));
    const video = videoRef.current;
    if (!video) return;
    try {
      scannerRef.current = await startScanner({
        video,
        onResult: async (value) => {
          stopScan();
          await lookupBundle(value);
        },
      });
    } catch (err) {
      setScanning(false);
      setError(err instanceof Error ? err.message : "Could not start the scanner");
    }
  };

  useEffect(() => () => scannerRef.current?.stop(), []);

  const canSubmit = photos.length > 0 && reason && !!user;

  const submit = async () => {
    if (!canSubmit) return;
    setStep("saving");
    setError("");

    // Everything the report needs, built once so the online and offline paths
    // can't drift apart.
    const clientUuid = crypto.randomUUID();
    const payload = {
      clientUuid,
      bundleId: bundle?.id ?? null,
      subject,
      reason,
      severity,
      stage: stage || null,
      qtyAffected: qty || null,
      unit: bundle?.unit ?? null,
      location: location || null,
      latitude: geo?.latitude ?? null,
      longitude: geo?.longitude ?? null,
      jobId: jobId || null,
      notes: notes || null,
      writeOff,
      deviceId: generateDeviceId(),
      deviceTime: new Date().toISOString(),
    };

    // Known to be offline: don't even try, just bank it. Saves the crew
    // watching a spinner fail in a dead corner of the yard.
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      await enqueueDamage(payload, photos.map((p) => p.blob));
      setSavedCode("queued");
      setStep("done");
      return;
    }

    try {
      const photoIds = await uploadPhotos(photos, {
        subjectType: "damage",
        geo,
      });

      const res = await fetch("/api/damage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...payload, photoIds }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not file the report");
        setStep("details");
        return;
      }

      setSavedCode(data.report?.code || "filed");
      setStep("done");
    } catch {
      // The signal dropped mid-submit. Queue it rather than making the crew
      // re-shoot the damage, then tell them plainly that it's saved but unsent.
      try {
        await enqueueDamage(payload, photos.map((p) => p.blob));
        setSavedCode("queued");
        setStep("done");
      } catch {
        setError("Network problem and the report couldn't be saved offline. Try again.");
        setStep("details");
      }
    }
  };

  const reset = () => {
    photos.forEach((p) => URL.revokeObjectURL(p.previewUrl));
    setPhotos([]);
    setBundle(null);
    setReason("");
    setSeverity("minor");
    setStage("");
    setQty("");
    setNotes("");
    setJobId("");
    setWriteOff(false);
    setSavedCode("");
    setError("");
    setStep("camera");
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  if (step === "camera") {
    return (
      <CameraCapture
        prompt="Photograph the damage"
        onCapture={handleCapture}
        onCancel={() => router.push("/")}
      />
    );
  }

  if (step === "done") {
    return (
      <div className="min-h-screen bg-slate-950">
        <NavBar />
        <main className="max-w-2xl mx-auto px-4 py-6 pb-24 sm:pb-6">
          <div
            className={`bg-slate-900 border rounded-2xl p-8 text-center ${
              savedCode === "queued" ? "border-amber-500/40" : "border-green-500/30"
            }`}
          >
            <div className="text-6xl mb-4">{savedCode === "queued" ? "📥" : "✅"}</div>
            <h1 className="text-2xl font-bold text-white mb-1">
              {savedCode === "queued" ? "Saved on this phone" : "Damage logged"}
            </h1>
            {savedCode !== "queued" && (
              <p className="text-accent-400 font-mono text-sm mb-4">{savedCode}</p>
            )}
            <p className="text-slate-400 text-sm mb-6">
              {savedCode === "queued"
                ? "No signal out here, so the report and its photos are held on this phone. They send themselves as soon as you're back in range — you don't have to do anything."
                : "Recorded with your name, the time, the location and the photo. Nothing else to fill in."}
            </p>
            <div className="space-y-2">
              <button
                onClick={reset}
                className="w-full bg-accent-500 hover:bg-accent-600 text-white font-bold py-4 rounded-xl"
              >
                Report another
              </button>
              <button
                onClick={() => router.push("/")}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl"
              >
                Done
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-2xl mx-auto px-4 py-6 pb-32 sm:pb-6">
        <h1 className="text-2xl font-bold text-white mb-1">Report damage</h1>
        <p className="text-slate-400 text-sm mb-5">
          Photo and reason are all that&rsquo;s required — everything else is optional.
        </p>

        {/* Photos */}
        <section className="mb-5">
          <div className="grid grid-cols-3 gap-2">
            {photos.map((photo, i) => (
              <PhotoThumb
                key={i}
                photo={photo}
                onRemove={() => {
                  URL.revokeObjectURL(photo.previewUrl);
                  setPhotos((prev) => prev.filter((_, idx) => idx !== i));
                }}
              />
            ))}
            <button
              onClick={() => setStep("camera")}
              className="h-28 rounded-xl border-2 border-dashed border-slate-700 text-slate-400 text-sm hover:border-accent-500 hover:text-accent-400 transition-colors"
            >
              + Photo
            </button>
          </div>
          {photos.length === 0 && (
            <p className="text-red-400 text-xs mt-2">At least one photo is required.</p>
          )}
        </section>

        {/* Auto-captured context */}
        <section className="mb-5 bg-slate-900/60 border border-slate-800 rounded-2xl px-4 py-3">
          <h2 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">
            Logged automatically
          </h2>
          <dl className="text-sm space-y-1">
            <div className="flex justify-between">
              <dt className="text-slate-500">Who</dt>
              <dd className="text-slate-200">{user.fullName}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">When</dt>
              <dd className="text-slate-200">{new Date().toLocaleString()}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Where</dt>
              <dd className="text-slate-200">
                {geo?.latitude != null
                  ? `${geo.latitude.toFixed(5)}, ${geo.longitude?.toFixed(5)}`
                  : "GPS unavailable"}
              </dd>
            </div>
          </dl>
        </section>

        {/* What was damaged */}
        <section className="mb-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-2">What was damaged?</h2>
          <div className="grid grid-cols-4 gap-2">
            {SUBJECTS.map((s) => (
              <button
                key={s.key}
                onClick={() => setSubject(s.key)}
                className={`py-3 rounded-xl text-xs font-medium border transition-colors ${
                  subject === s.key
                    ? "bg-accent-500 border-accent-500 text-white"
                    : "bg-slate-900 border-slate-800 text-slate-300"
                }`}
              >
                <span className="block text-xl mb-1">{s.icon}</span>
                {s.label}
              </button>
            ))}
          </div>
        </section>

        {/* Bundle link */}
        {subject === "material" && (
          <section className="mb-5">
            <h2 className="text-sm font-semibold text-slate-300 mb-2">
              Which {terms.unit}? <span className="text-slate-500 font-normal">(optional)</span>
            </h2>

            {bundle ? (
              <div className="bg-slate-900 border border-accent-500/40 rounded-2xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-mono text-accent-400 text-sm">{bundle.code}</p>
                    <p className="text-white text-sm truncate">{bundle.productName}</p>
                    <p className="text-slate-400 text-xs mt-0.5">
                      {bundle.qtyRemaining} {bundle.unit} remaining
                    </p>
                  </div>
                  <button
                    onClick={() => setBundle(null)}
                    className="text-slate-400 text-xs px-2 py-1"
                  >
                    Clear
                  </button>
                </div>
              </div>
            ) : scanning ? (
              <div className="relative bg-black rounded-2xl overflow-hidden" style={{ aspectRatio: "4/3" }}>
                <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
                <button
                  onClick={stopScan}
                  className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-white/90 text-slate-900 text-sm font-semibold px-4 py-2 rounded-full"
                >
                  Cancel scan
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <button
                  onClick={beginScan}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl font-medium"
                >
                  📷 Scan {terms.unit} QR
                </button>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (manualCode.trim()) void lookupBundle(normalizeScannedValue(manualCode));
                  }}
                  className="flex gap-2"
                >
                  <input
                    value={manualCode}
                    onChange={(e) => setManualCode(e.target.value)}
                    placeholder="or type the code"
                    autoCapitalize="characters"
                    autoCorrect="off"
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-accent-500"
                  />
                  <button type="submit" className="bg-slate-700 text-white px-4 rounded-xl text-sm">
                    Go
                  </button>
                </form>
              </div>
            )}
          </section>
        )}

        {/* Reason */}
        <section className="mb-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-2">
            What happened? <span className="text-red-400">*</span>
          </h2>
          <div className="grid grid-cols-4 gap-2">
            {REASONS.map((r) => (
              <button
                key={r.key}
                onClick={() => setReason(r.key)}
                className={`py-3 rounded-xl text-xs font-medium border transition-colors ${
                  reason === r.key
                    ? "bg-accent-500 border-accent-500 text-white"
                    : "bg-slate-900 border-slate-800 text-slate-300"
                }`}
              >
                <span className="block text-xl mb-1">{r.icon}</span>
                {r.label}
              </button>
            ))}
          </div>
        </section>

        {/* Severity */}
        <section className="mb-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-2">How bad?</h2>
          <div className="grid grid-cols-3 gap-2">
            {SEVERITIES.map((s) => (
              <button
                key={s.key}
                onClick={() => setSeverity(s.key)}
                className={`py-3 rounded-xl border text-sm font-medium transition-colors ${
                  severity === s.key
                    ? "bg-accent-500 border-accent-500 text-white"
                    : "bg-slate-900 border-slate-800 text-slate-300"
                }`}
              >
                {s.label}
                <span className="block text-[10px] opacity-70 mt-0.5">{s.hint}</span>
              </button>
            ))}
          </div>
        </section>

        {/* Stage */}
        <section className="mb-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-2">
            When did it happen? <span className="text-slate-500 font-normal">(optional)</span>
          </h2>
          <div className="flex flex-wrap gap-2">
            {STAGES.map((s) => (
              <button
                key={s.key}
                onClick={() => setStage(stage === s.key ? "" : s.key)}
                className={`px-3 py-2 rounded-full text-xs border transition-colors ${
                  stage === s.key
                    ? "bg-accent-500 border-accent-500 text-white"
                    : "bg-slate-900 border-slate-800 text-slate-300"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </section>

        {/* Quantity + write-off */}
        {bundle && (
          <section className="mb-5 bg-slate-900 border border-slate-800 rounded-2xl p-4">
            <label className="block text-sm font-semibold text-slate-300 mb-2">
              How many {bundle.unit}s affected?
            </label>
            <input
              type="number"
              inputMode="decimal"
              min={0}
              max={Number(bundle.qtyRemaining)}
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              placeholder="0"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 text-white text-lg focus:outline-none focus:border-accent-500"
            />
            <label className="flex items-start gap-3 mt-3 cursor-pointer">
              <input
                type="checkbox"
                checked={writeOff}
                onChange={(e) => setWriteOff(e.target.checked)}
                className="mt-1 w-5 h-5 accent-accent-500"
              />
              <span className="text-sm text-slate-300">
                Remove from inventory now
                <span className="block text-xs text-slate-500">
                  Deducts the quantity above from this {terms.unit}.
                </span>
              </span>
            </label>
          </section>
        )}

        {/* Job */}
        {jobs.length > 0 && (
          <section className="mb-5">
            <label className="block text-sm font-semibold text-slate-300 mb-2">
              Related job <span className="text-slate-500 font-normal">(optional)</span>
            </label>
            <select
              value={jobId}
              onChange={(e) => setJobId(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 text-white text-sm focus:outline-none focus:border-accent-500"
            >
              <option value="">None</option>
              {jobs.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.code} — {j.customerName}
                </option>
              ))}
            </select>
          </section>
        )}

        {/* Location + notes */}
        <section className="mb-5 space-y-3">
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">
              Yard location <span className="text-slate-500 font-normal">(optional)</span>
            </label>
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Row C, Bay 4"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 text-white text-sm focus:outline-none focus:border-accent-500"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-300 mb-2">
              Notes <span className="text-slate-500 font-normal">(optional)</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Anything the photo doesn't show"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 text-white text-sm focus:outline-none focus:border-accent-500"
            />
          </div>
        </section>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-4">
            {error}
          </div>
        )}
      </main>

      {/* Sticky submit */}
      <div className="fixed bottom-0 left-0 right-0 bg-slate-950/95 backdrop-blur border-t border-slate-800 px-4 py-3 pb-[max(env(safe-area-inset-bottom),0.75rem)] sm:static sm:bg-transparent sm:border-0">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={submit}
            disabled={!canSubmit || step === "saving"}
            className="w-full bg-accent-500 hover:bg-accent-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl text-lg transition-colors"
          >
            {step === "saving" ? "Filing report…" : "File damage report"}
          </button>
          {!reason && photos.length > 0 && (
            <p className="text-center text-slate-500 text-xs mt-2">Pick what happened</p>
          )}
        </div>
      </div>
    </div>
  );
}
