"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { NavBar } from "@/components/NavBar";
import { CameraCapture, PhotoThumb } from "@/components/CameraCapture";
import { getGeo, type CapturedPhoto, type CaptureGeo } from "@/lib/camera";
import { uploadPhoto } from "@/lib/photo-upload";
import { LabelPrintSheet } from "@/components/LabelPrintSheet";
import { tenant, terms, measureLabel } from "@/lib/tenant";

// Offered measures come from the tenant, so a drum yard never sees "board ft".
const UNITS = terms.measures;

type Step = "camera" | "details" | "saving" | "done";

interface CreatedBundle {
  id: string;
  code: string;
  productId: string;
  productName: string | null;
  qtyReceived: number;
  unit: string;
}

/**
 * Camera-first intake for material that isn't in the catalogue yet.
 *
 * Flow: photograph the item → name it → say how many → done. The photo becomes
 * the product's picture, bundles are created, and labels are ready to print,
 * all without going back to a desk.
 */
export default function IntakePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const [step, setStep] = useState<Step>("camera");
  const [photo, setPhoto] = useState<CapturedPhoto | null>(null);
  const [geo, setGeo] = useState<CaptureGeo | null>(null);

  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [category, setCategory] = useState("");
  const [unit, setUnit] = useState<string>(terms.defaultMeasure);
  const [qtyPerBundle, setQtyPerBundle] = useState(terms.groupsItems ? "" : "1");
  const [bundleCount, setBundleCount] = useState("1");
  const [location, setLocation] = useState("");
  const [reorderThreshold, setReorderThreshold] = useState("");

  // The photo is uploaded as soon as it's taken, not at submit: the vision
  // guess needs it server-side, and it makes the save at the end fast.
  const [photoId, setPhotoId] = useState<string | null>(null);
  const [guessing, setGuessing] = useState(false);
  const [guessed, setGuessed] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState<CreatedBundle[]>([]);
  const [createdName, setCreatedName] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/intake");
    else if (!loading && user && user.role !== "admin") router.replace("/");
  }, [user, loading, router]);

  useEffect(() => {
    if (user) void getGeo().then(setGeo);
  }, [user]);

  const totalPieces =
    (Number(qtyPerBundle) || 0) * (Number(bundleCount) || 0);

  const canSubmit =
    !!photo && name.trim().length > 0 && Number(qtyPerBundle) > 0 && Number(bundleCount) >= 1;

  /**
   * Upload the photo, then ask the model what it is. Both are best-effort: a
   * failure here costs the crew a bit of typing, nothing more, so it never
   * surfaces an error or blocks the form.
   */
  const identify = async (captured: CapturedPhoto) => {
    setGuessing(true);
    try {
      const id = await uploadPhoto(captured, { subjectType: "product", geo });
      setPhotoId(id);

      const res = await fetch("/api/vision/identify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ photoId: id }),
      });
      if (!res.ok) return;

      const data = await res.json();
      if (!data.name) return;

      // Never overwrite something the crew already typed.
      setName((prev) => prev || data.name);
      setCategory((prev) => prev || data.category || "");
      setGuessed(true);
    } catch {
      // Silent: the manual path still works.
    } finally {
      setGuessing(false);
    }
  };

  const submit = async () => {
    if (!canSubmit || !photo) return;
    setStep("saving");
    setError("");

    try {
      // Normally already uploaded when the photo was taken; re-upload only if
      // that failed (bad signal at the moment of capture).
      const finalPhotoId =
        photoId ?? (await uploadPhoto(photo, { subjectType: "product", geo }));

      const res = await fetch("/api/products/quick", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          sku: sku.trim() || undefined,
          category: category.trim() || undefined,
          baseUnit: unit,
          photoId: finalPhotoId,
          qtyPerBundle: Number(qtyPerBundle),
          bundleCount: Number(bundleCount),
          location: location.trim() || undefined,
          reorderThreshold: reorderThreshold ? Number(reorderThreshold) : undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not create the item");
        setStep("details");
        return;
      }

      setCreatedName(data.product.name);
      setCreated(
        data.bundles.map((b: { id: string; code: string }) => ({
          id: b.id,
          code: b.code,
          productId: data.product.id,
          productName: data.product.name,
          qtyReceived: Number(qtyPerBundle),
          unit,
        }))
      );
      setStep("done");
    } catch {
      setError("Network problem. Check your signal and try again.");
      setStep("details");
    }
  };

  const reset = () => {
    if (photo) URL.revokeObjectURL(photo.previewUrl);
    setPhoto(null);
    setPhotoId(null);
    setGuessed(false);
    setName("");
    setSku("");
    setCategory("");
    setQtyPerBundle("");
    setBundleCount("1");
    setLocation("");
    setReorderThreshold("");
    setCreated([]);
    setError("");
    setStep("camera");
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  if (step === "camera") {
    return (
      <CameraCapture
        prompt="Photograph the item"
        onCapture={(p) => {
          setPhoto(p);
          setStep("details");
          void identify(p);
        }}
        onCancel={() => router.push("/")}
      />
    );
  }

  if (step === "done") {
    return (
      <div className="min-h-screen bg-slate-950">
        <NavBar />
        <main className="max-w-3xl mx-auto px-4 py-6 pb-24 sm:pb-6">
          <div className="bg-slate-900 border border-green-500/30 rounded-2xl p-6 text-center mb-6">
            <div className="text-5xl mb-3">✅</div>
            <h1 className="text-xl font-bold text-white mb-1">{createdName} added</h1>
            <p className="text-slate-400 text-sm">
              {created.length} {created.length === 1 ? terms.unit : terms.unitPlural} in stock — print the
              labels below and tag them.
            </p>
            <div className="flex gap-2 mt-5">
              <button
                onClick={reset}
                className="flex-1 bg-accent-500 hover:bg-accent-600 text-white font-bold py-3 rounded-xl"
              >
                Add another
              </button>
              <button
                onClick={() => router.push("/")}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-3 rounded-xl"
              >
                Done
              </button>
            </div>
          </div>

          <LabelPrintSheet bundles={created} />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-2xl mx-auto px-4 py-6 pb-32 sm:pb-6">
        <h1 className="text-2xl font-bold text-white mb-1">New item</h1>
        <p className="text-slate-400 text-sm mb-5">
          The photo becomes this item&rsquo;s picture in the catalogue.
        </p>

        {/* Photo */}
        <section className="mb-5">
          <div className="grid grid-cols-3 gap-2">
            {photo ? (
              <PhotoThumb
                photo={photo}
                onRemove={() => {
                  URL.revokeObjectURL(photo.previewUrl);
                  setPhoto(null);
                  setStep("camera");
                }}
              />
            ) : (
              <button
                onClick={() => setStep("camera")}
                className="h-28 rounded-xl border-2 border-dashed border-slate-700 text-slate-400 text-sm hover:border-accent-500"
              >
                + Photo
              </button>
            )}
          </div>
        </section>

        {/* Name */}
        <section className="mb-5">
          <label className="block text-sm font-semibold text-slate-300 mb-2">
            What is it? <span className="text-red-400">*</span>
          </label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="6ft Cedar Privacy Picket"
            autoFocus
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3.5 text-white text-base focus:outline-none focus:border-accent-500"
          />
          {guessing && (
            <p className="text-xs text-slate-500 mt-1.5 animate-pulse">
              Looking at the photo…
            </p>
          )}
          {guessed && !guessing && (
            <p className="text-xs text-accent-400 mt-1.5">
              Filled in from the photo — fix it if it&rsquo;s wrong.
            </p>
          )}
        </section>

        {/* Count — the big one */}
        <section className="mb-5 bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <h2 className="text-sm font-semibold text-slate-300 mb-3">Count</h2>

          {terms.groupsItems && (
            <>
              <label className="block text-xs text-slate-400 mb-1">
                How many in each {terms.unit}? <span className="text-red-400">*</span>
              </label>
              <div className="flex items-center gap-2 mb-4">
                <button
                  onClick={() =>
                    setQtyPerBundle(String(Math.max(0, (Number(qtyPerBundle) || 0) - 10)))
                  }
                  className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
                  aria-label="Decrease by ten"
                >
                  −
                </button>
                <input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  value={qtyPerBundle}
                  onChange={(e) => setQtyPerBundle(e.target.value)}
                  placeholder="0"
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-3.5 text-white text-2xl text-center font-bold focus:outline-none focus:border-accent-500"
                />
                <button
                  onClick={() => setQtyPerBundle(String((Number(qtyPerBundle) || 0) + 10))}
                  className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
                  aria-label="Increase by ten"
                >
                  +
                </button>
              </div>
            </>
          )}

          <label className="block text-xs text-slate-400 mb-1">
            {terms.groupsItems
              ? `How many ${terms.unitPlural}?`
              : `How many are you adding?`}
          </label>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setBundleCount(String(Math.max(1, (Number(bundleCount) || 1) - 1)))}
              className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
              aria-label={`One fewer ${terms.unit}`}
            >
              −
            </button>
            <input
              type="number"
              inputMode="numeric"
              min={1}
              value={bundleCount}
              onChange={(e) => setBundleCount(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-3.5 text-white text-2xl text-center font-bold focus:outline-none focus:border-accent-500"
            />
            <button
              onClick={() => setBundleCount(String((Number(bundleCount) || 0) + 1))}
              className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
              aria-label={`One more ${terms.unit}`}
            >
              +
            </button>
          </div>

          {/* Most furniture is a single piece, so the multi-item box is an
              optional extra rather than a question every sofa has to answer. */}
          {!terms.groupsItems && terms.perPackLabel && (
            <div className="mt-4">
              <label className="block text-xs text-slate-400 mb-1">
                {terms.perPackLabel}{" "}
                <span className="text-slate-500">(leave at 1 for a single piece)</span>
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    setQtyPerBundle(String(Math.max(1, (Number(qtyPerBundle) || 1) - 1)))
                  }
                  className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
                  aria-label="One fewer per box"
                >
                  −
                </button>
                <input
                  type="number"
                  inputMode="numeric"
                  min={1}
                  value={qtyPerBundle}
                  onChange={(e) => setQtyPerBundle(e.target.value)}
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-3.5 text-white text-2xl text-center font-bold focus:outline-none focus:border-accent-500"
                />
                <button
                  onClick={() => setQtyPerBundle(String((Number(qtyPerBundle) || 1) + 1))}
                  className="w-14 h-14 rounded-xl bg-slate-800 text-white text-2xl font-bold active:scale-95"
                  aria-label="One more per box"
                >
                  +
                </button>
              </div>
            </div>
          )}

          {totalPieces > 0 && (
            <p className="text-center text-accent-400 text-sm mt-3 font-medium">
              {terms.groupsItems || Number(qtyPerBundle) > 1
                ? `${totalPieces.toLocaleString()} ${measureLabel(unit)} total · `
                : ""}
              {bundleCount} label{Number(bundleCount) === 1 ? "" : "s"}
            </p>
          )}
        </section>

        {/* Unit */}
        <section className="mb-5">
          <h2 className="text-sm font-semibold text-slate-300 mb-2">Unit</h2>
          <div className="grid grid-cols-4 gap-2">
            {UNITS.map((u) => (
              <button
                key={u}
                onClick={() => setUnit(u)}
                className={`py-2.5 rounded-xl text-xs font-medium border transition-colors ${
                  unit === u
                    ? "bg-accent-500 border-accent-500 text-white"
                    : "bg-slate-900 border-slate-800 text-slate-300"
                }`}
              >
                {measureLabel(u)}
              </button>
            ))}
          </div>
        </section>

        {/* Optional details */}
        <details className="mb-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <summary className="px-4 py-3 text-sm font-semibold text-slate-300 cursor-pointer select-none">
            More details (optional)
          </summary>
          <div className="px-4 pb-4 space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">SKU</label>
              <input
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="Leave blank to generate one"
                autoCapitalize="characters"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-accent-500"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Category</label>
              <input
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Fencing"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-accent-500"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Yard location</label>
              <input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Row C, Bay 4"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-accent-500"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Reorder threshold</label>
              <input
                type="number"
                inputMode="numeric"
                value={reorderThreshold}
                onChange={(e) => setReorderThreshold(e.target.value)}
                placeholder="Alert when stock drops below"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-accent-500"
              />
            </div>
          </div>
        </details>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-4">
            {error}
          </div>
        )}
      </main>

      <div className="fixed bottom-0 left-0 right-0 bg-slate-950/95 backdrop-blur border-t border-slate-800 px-4 py-3 pb-[max(env(safe-area-inset-bottom),0.75rem)] sm:static sm:bg-transparent sm:border-0">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={submit}
            disabled={!canSubmit || step === "saving"}
            className="w-full bg-accent-500 hover:bg-accent-600 disabled:opacity-40 text-white font-bold py-4 rounded-xl text-lg transition-colors"
          >
            {step === "saving" ? "Adding…" : "Add to inventory"}
          </button>
        </div>
      </div>
    </div>
  );
}
