"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { v4 as uuidv4 } from "uuid";
import { useAuth } from "@/hooks/useAuth";
import { NavBar } from "@/components/NavBar";
import { getGeo } from "@/lib/camera";
import { generateDeviceId } from "@/lib/offline-queue";
import {
  CHECK_ITEMS,
  CHECK_STATUS_LABEL,
  FUEL_LEVELS,
  isCheckComplete,
  rollupCheckStatus,
  type CheckResult,
  type CheckStatus,
} from "@/lib/fleet";
import { tenant } from "@/lib/tenant";

interface VehicleRow {
  id: string;
  name: string;
  plate: string | null;
  description: string | null;
  checkedToday: boolean;
  lastCheck: {
    checkDate: string;
    status: CheckStatus;
    checkedAt: string;
    odometer: number | null;
    userName: string;
  } | null;
}

const RESULT_STYLE: Record<CheckResult, { label: string; on: string; off: string }> = {
  ok: { label: "OK", on: "bg-green-500 text-white border-green-500", off: "border-slate-700 text-slate-300" },
  watch: { label: "Watch", on: "bg-amber-500 text-black border-amber-500", off: "border-slate-700 text-slate-300" },
  bad: { label: "Bad", on: "bg-red-500 text-white border-red-500", off: "border-slate-700 text-slate-300" },
};

const STATUS_STYLE: Record<CheckStatus, string> = {
  ok: "bg-green-500/10 border-green-500/30 text-green-300",
  attention: "bg-amber-500/10 border-amber-500/30 text-amber-300",
  needs_repair: "bg-red-500/10 border-red-500/30 text-red-300",
};

/**
 * The morning once-over. Pick a truck, tap through eleven items in walk-round
 * order, read the odometer, go. Every item needs an answer — the point of the
 * checklist is that "I looked" is recorded per thing, not as one tick.
 */
export default function TruckCheckPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const [vehicles, setVehicles] = useState<VehicleRow[] | null>(null);
  const [vehicleId, setVehicleId] = useState<string | null>(null);
  const [items, setItems] = useState<Partial<Record<string, CheckResult>>>({});
  const [odometer, setOdometer] = useState("");
  const [fuel, setFuel] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<CheckStatus | null>(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/login?next=/truck-check");
  }, [user, loading, router]);

  const loadVehicles = useCallback(async () => {
    try {
      const res = await fetch("/api/vehicles");
      const d = await res.json();
      setVehicles(d.vehicles ?? []);
    } catch {
      setVehicles([]);
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void loadVehicles();
  }, [user, loadVehicles]);

  const vehicle = useMemo(() => vehicles?.find((v) => v.id === vehicleId) ?? null, [vehicles, vehicleId]);
  const complete = isCheckComplete(items);
  const preview = rollupCheckStatus(items);
  const badItems = CHECK_ITEMS.filter((i) => items[i.key] === "bad");

  const reset = () => {
    setVehicleId(null);
    setItems({});
    setOdometer("");
    setFuel(null);
    setNotes("");
    setDone(null);
    setError("");
  };

  const submit = async () => {
    if (!vehicleId || !complete) return;
    setSubmitting(true);
    setError("");
    try {
      const geo = await getGeo(5000);
      const res = await fetch("/api/vehicle-checks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientUuid: uuidv4(),
          vehicleId,
          items,
          odometer: odometer.trim() ? Number(odometer.replace(/[^\d]/g, "")) : null,
          fuelLevel: fuel,
          notes,
          latitude: geo.latitude,
          longitude: geo.longitude,
          deviceId: generateDeviceId(),
          deviceTime: new Date().toISOString(),
        }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Could not save the check");
      setDone((d.check?.status as CheckStatus) ?? preview);
      void loadVehicles();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save the check");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  // ── Done ──────────────────────────────────────────────────────────────────
  if (done) {
    return (
      <div className="min-h-screen bg-slate-950">
        <NavBar />
        <main className="max-w-lg mx-auto px-4 py-6 pb-28 sm:pb-8 space-y-4">
          <div className={`rounded-2xl border px-5 py-6 text-center ${STATUS_STYLE[done]}`}>
            <div className="text-5xl mb-2">{done === "ok" ? "✅" : done === "attention" ? "⚠️" : "🛑"}</div>
            <div className="text-xl font-bold">{CHECK_STATUS_LABEL[done]}</div>
            <div className="text-sm opacity-80 mt-1">
              {vehicle?.name} · checked {new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
            </div>
            {done === "needs_repair" && (
              <p className="text-sm mt-3 opacity-90">
                Don&rsquo;t take this truck out. Tell the office and use another one.
              </p>
            )}
            {done === "attention" && (
              <p className="text-sm mt-3 opacity-90">
                Safe to drive today. The office has been flagged to get it looked at.
              </p>
            )}
          </div>
          <button onClick={reset} className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 text-white font-semibold">
            Check another truck
          </button>
          <Link href="/clock-in" className="block w-full text-center text-slate-400 text-sm py-2">
            Back to my shift
          </Link>
        </main>
      </div>
    );
  }

  // ── Pick a truck ──────────────────────────────────────────────────────────
  if (!vehicle) {
    return (
      <div className="min-h-screen bg-slate-950">
        <NavBar />
        <main className="max-w-lg mx-auto px-4 py-6 pb-28 sm:pb-8">
          <h1 className="text-2xl font-bold text-white mb-1">Morning truck check</h1>
          <p className="text-slate-400 text-sm mb-6">Which truck are you taking out?</p>

          {vehicles === null ? (
            <div className="text-slate-500 animate-pulse">Loading trucks…</div>
          ) : vehicles.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl px-4 py-4 text-slate-400 text-sm">
              No trucks set up yet. Ask the office to add them under Admin → Fleet.
            </div>
          ) : (
            <div className="space-y-2">
              {vehicles.map((v) => (
                <button
                  key={v.id}
                  onClick={() => setVehicleId(v.id)}
                  className="w-full bg-slate-900 border border-slate-800 hover:border-slate-600 rounded-xl px-4 py-4 flex items-center gap-4 text-left"
                >
                  <span className="text-3xl">🛻</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-semibold">{v.name}</div>
                    <div className="text-slate-400 text-xs truncate">
                      {[v.plate, v.description].filter(Boolean).join(" · ") || "—"}
                    </div>
                  </div>
                  <div className="text-right">
                    {v.checkedToday ? (
                      <span className={`text-xs px-2 py-1 rounded-full border ${STATUS_STYLE[v.lastCheck!.status]}`}>
                        Done today
                      </span>
                    ) : (
                      <span className="text-xs px-2 py-1 rounded-full bg-slate-800 text-slate-300">Not yet</span>
                    )}
                    {v.lastCheck && !v.checkedToday && (
                      <div className="text-[10px] text-slate-500 mt-1">last {v.lastCheck.checkDate}</div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </main>
      </div>
    );
  }

  // ── Checklist ─────────────────────────────────────────────────────────────
  const answered = CHECK_ITEMS.filter((i) => items[i.key]).length;

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-lg mx-auto px-4 py-6 pb-40 sm:pb-8">
        <div className="flex items-center justify-between mb-1">
          <h1 className="text-2xl font-bold text-white">{vehicle.name}</h1>
          <button onClick={() => setVehicleId(null)} className="text-slate-400 text-sm">Change truck</button>
        </div>
        <p className="text-slate-400 text-sm mb-4">
          {vehicle.checkedToday
            ? `Already checked today by ${vehicle.lastCheck?.userName}. Checking again is fine.`
            : "Walk it front to back. Tap one answer per line."}
        </p>

        <div className="mb-4 flex gap-2">
          <button
            onClick={() => setItems(Object.fromEntries(CHECK_ITEMS.map((i) => [i.key, "ok" as const])))}
            className="text-xs px-3 py-1.5 rounded-full bg-slate-800 text-slate-300 hover:bg-slate-700"
          >
            Everything looks OK
          </button>
          <span className="text-xs text-slate-500 self-center">{answered}/{CHECK_ITEMS.length} answered</span>
        </div>

        <div className="space-y-2">
          {CHECK_ITEMS.map((item) => {
            const r = items[item.key];
            return (
              <div key={item.key} className={`bg-slate-900 border rounded-xl px-4 py-3 ${r === "bad" ? "border-red-500/40" : r === "watch" ? "border-amber-500/40" : "border-slate-800"}`}>
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-white font-medium text-sm">
                      {item.label}
                      {item.critical && <span className="text-slate-500 text-xs ml-1.5">safety</span>}
                    </div>
                    <div className="text-slate-500 text-xs mt-0.5">{item.hint}</div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    {(Object.keys(RESULT_STYLE) as CheckResult[]).map((v) => (
                      <button
                        key={v}
                        onClick={() => setItems((prev) => ({ ...prev, [item.key]: v }))}
                        className={`min-w-[52px] px-2 py-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                          r === v ? RESULT_STYLE[v].on : RESULT_STYLE[v].off
                        }`}
                      >
                        {RESULT_STYLE[v].label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Odometer</label>
            <input
              inputMode="numeric"
              value={odometer}
              onChange={(e) => setOdometer(e.target.value)}
              placeholder={vehicle.lastCheck?.odometer ? `last ${vehicle.lastCheck.odometer.toLocaleString()}` : "miles"}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-accent-500"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Fuel</label>
            <div className="flex gap-1">
              {FUEL_LEVELS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFuel(f)}
                  className={`flex-1 py-3 rounded-lg border text-xs font-semibold ${
                    fuel === f ? "bg-accent-500 border-accent-500 text-white" : "border-slate-700 text-slate-300"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-xs text-slate-400 mb-1.5">
            Notes {badItems.length > 0 && <span className="text-red-400">— say what&rsquo;s wrong with {badItems.map((b) => b.label.toLowerCase()).join(", ")}</span>}
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            placeholder="Anything the office should know"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-accent-500"
          />
        </div>

        {error && (
          <div className="mt-4 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-300 text-sm">{error}</div>
        )}

        {/* Sticky submit */}
        <div className="fixed bottom-16 sm:bottom-0 inset-x-0 z-40 bg-slate-950/95 backdrop-blur border-t border-slate-800 px-4 py-3">
          <div className="max-w-lg mx-auto flex items-center gap-3">
            <div className={`text-xs px-2.5 py-1.5 rounded-lg border ${complete ? STATUS_STYLE[preview] : "border-slate-800 text-slate-500"}`}>
              {complete ? CHECK_STATUS_LABEL[preview] : `${CHECK_ITEMS.length - answered} left`}
            </div>
            <button
              onClick={submit}
              disabled={!complete || submitting}
              className="flex-1 bg-accent-500 hover:bg-accent-600 disabled:opacity-40 text-white font-bold py-3 rounded-xl"
            >
              {submitting ? "Saving…" : "Submit check"}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
