import { NextRequest, NextResponse } from "next/server";
import { db, itineraries } from "@/db";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { DATE_KEY_RE } from "@/lib/fleet";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const { id } = await params;
    const body = await req.json().catch(() => ({}));

    const patch: Partial<typeof itineraries.$inferInsert> = { updatedAt: new Date() };
    if (body.title !== undefined) {
      const title = String(body.title).trim();
      if (!title || title.length > 200) {
        return NextResponse.json({ error: "Title must be 1–200 characters" }, { status: 400 });
      }
      patch.title = title;
    }
    if (body.body !== undefined) {
      patch.body = typeof body.body === "string" && body.body.trim() ? body.body.trim().slice(0, 5000) : null;
    }
    if (body.forDate !== undefined) {
      if (!DATE_KEY_RE.test(String(body.forDate))) {
        return NextResponse.json({ error: "forDate must be YYYY-MM-DD" }, { status: 400 });
      }
      patch.forDate = String(body.forDate);
    }
    if (body.assigneeId !== undefined) patch.assigneeId = body.assigneeId ? String(body.assigneeId) : null;
    if (body.priority !== undefined) patch.priority = body.priority === "high" ? "high" : "normal";
    if (body.active !== undefined) patch.active = Boolean(body.active);

    const [row] = await db.update(itineraries).set(patch).where(eq(itineraries.id, id)).returning();
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ itinerary: row });
  } catch (err) {
    console.error("Update itinerary error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

/** Soft delete — acks reference it, and "what did I tell them" should survive. */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const { id } = await params;
    await db.update(itineraries).set({ active: false, updatedAt: new Date() }).where(eq(itineraries.id, id));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Delete itinerary error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
