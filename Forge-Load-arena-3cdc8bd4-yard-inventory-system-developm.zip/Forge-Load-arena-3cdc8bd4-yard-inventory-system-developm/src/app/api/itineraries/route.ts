import { NextRequest, NextResponse } from "next/server";
import { db, itineraries, itineraryAcks, users } from "@/db";
import { and, asc, desc, eq, gte, isNull, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { getSession } from "@/lib/auth";
import { DATE_KEY_RE, localDateKey } from "@/lib/fleet";

/**
 * The office writes tomorrow's orders here. Anyone with an admin login can —
 * that's Earl Jr. today and whoever's running the desk tomorrow.
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const body = await req.json().catch(() => ({}));
    const forDate = String(body.forDate || "").trim();
    const title = String(body.title || "").trim();

    if (!DATE_KEY_RE.test(forDate)) {
      return NextResponse.json({ error: "Pick a day (YYYY-MM-DD)" }, { status: 400 });
    }
    if (!title) {
      return NextResponse.json({ error: "Write what needs doing" }, { status: 400 });
    }
    if (title.length > 200) {
      return NextResponse.json({ error: "Keep the title under 200 characters — put the detail in the notes" }, { status: 400 });
    }
    if (body.assigneeId) {
      const [u] = await db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.id, String(body.assigneeId)), eq(users.active, true)))
        .limit(1);
      if (!u) return NextResponse.json({ error: "That person isn't an active user" }, { status: 400 });
    }

    const [row] = await db
      .insert(itineraries)
      .values({
        forDate,
        title,
        body: typeof body.body === "string" && body.body.trim() ? body.body.trim().slice(0, 5000) : null,
        assigneeId: body.assigneeId ? String(body.assigneeId) : null,
        priority: body.priority === "high" ? "high" : "normal",
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ itinerary: row }, { status: 201 });
  } catch (err) {
    console.error("Create itinerary error:", err);
    return NextResponse.json({ error: "Could not save" }, { status: 500 });
  }
}

/**
 * Read orders.
 *
 *   ?date=YYYY-MM-DD   one day (admin: all of them, with who has seen each;
 *                      crew: only theirs + the whole-crew ones)
 *   ?upcoming=1        today onward (the office's planning view)
 *   ?mine=1            crew: today's orders for me, without marking delivered
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { searchParams } = new URL(req.url);
    const date = searchParams.get("date");
    const upcoming = searchParams.get("upcoming") === "1";
    const isAdmin = session.role === "admin";
    const today = localDateKey();

    if (date && !DATE_KEY_RE.test(date)) {
      return NextResponse.json({ error: "date must be YYYY-MM-DD" }, { status: 400 });
    }

    const conditions = [eq(itineraries.active, true)];
    if (date) conditions.push(eq(itineraries.forDate, date));
    else if (upcoming && isAdmin) conditions.push(gte(itineraries.forDate, today));
    else conditions.push(eq(itineraries.forDate, today));

    if (!isAdmin) {
      conditions.push(or(isNull(itineraries.assigneeId), eq(itineraries.assigneeId, session.id))!);
    }

    const assignee = alias(users, "assignee");
    const author = alias(users, "author");

    const rows = await db
      .select({
        id: itineraries.id,
        forDate: itineraries.forDate,
        title: itineraries.title,
        body: itineraries.body,
        priority: itineraries.priority,
        assigneeId: itineraries.assigneeId,
        assigneeName: assignee.fullName,
        createdByName: author.fullName,
        createdAt: itineraries.createdAt,
        ackCount: sql<number>`(select count(*)::int from ${itineraryAcks} a where a.itinerary_id = ${itineraries.id})`,
      })
      .from(itineraries)
      .leftJoin(assignee, eq(assignee.id, itineraries.assigneeId))
      .leftJoin(author, eq(author.id, itineraries.createdBy))
      .where(and(...conditions))
      .orderBy(asc(itineraries.forDate), desc(itineraries.priority), asc(itineraries.createdAt))
      .limit(500);

    if (!isAdmin) {
      return NextResponse.json({ today, itineraries: rows });
    }

    // Who's seen what — the office wants names, not a count.
    const ids = rows.map((r) => r.id);
    const acks = ids.length
      ? await db
          .select({
            itineraryId: itineraryAcks.itineraryId,
            userName: users.fullName,
            deliveredAt: itineraryAcks.deliveredAt,
          })
          .from(itineraryAcks)
          .innerJoin(users, eq(users.id, itineraryAcks.userId))
          .where(sql`${itineraryAcks.itineraryId} in ${ids}`)
      : [];

    const acksById = new Map<string, { userName: string; deliveredAt: Date }[]>();
    for (const a of acks) {
      const list = acksById.get(a.itineraryId) ?? [];
      list.push({ userName: a.userName, deliveredAt: a.deliveredAt });
      acksById.set(a.itineraryId, list);
    }

    return NextResponse.json({
      today,
      itineraries: rows.map((r) => ({ ...r, acks: acksById.get(r.id) ?? [] })),
    });
  } catch (err) {
    console.error("List itineraries error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
