import { NextRequest, NextResponse } from "next/server";
import { db, vehicles, vehicleChecks, users } from "@/db";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { localDateKey } from "@/lib/fleet";

/**
 * The fleet, each truck with its most recent check. The crew see this on the
 * truck-check screen ("Truck 2 hasn't been checked today"), the office sees
 * it on the fleet tab.
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { searchParams } = new URL(req.url);
    const includeInactive = searchParams.get("all") === "1" && session.role === "admin";

    const rows = await db
      .select()
      .from(vehicles)
      .where(includeInactive ? undefined : eq(vehicles.active, true))
      .orderBy(asc(vehicles.name));

    // Latest check per vehicle in one query rather than N.
    const latest = await db
      .select({
        vehicleId: vehicleChecks.vehicleId,
        id: vehicleChecks.id,
        checkDate: vehicleChecks.checkDate,
        status: vehicleChecks.status,
        checkedAt: vehicleChecks.checkedAt,
        odometer: vehicleChecks.odometer,
        fuelLevel: vehicleChecks.fuelLevel,
        userName: users.fullName,
        rn: sql<number>`row_number() over (partition by ${vehicleChecks.vehicleId} order by ${vehicleChecks.checkedAt} desc)`.as("rn"),
      })
      .from(vehicleChecks)
      .innerJoin(users, eq(users.id, vehicleChecks.userId))
      .orderBy(desc(vehicleChecks.checkedAt))
      .limit(rows.length * 5 + 50);

    const latestByVehicle = new Map<string, (typeof latest)[number]>();
    for (const c of latest) {
      if (!latestByVehicle.has(c.vehicleId)) latestByVehicle.set(c.vehicleId, c);
    }

    const today = localDateKey();
    return NextResponse.json({
      today,
      vehicles: rows.map((v) => {
        const last = latestByVehicle.get(v.id);
        return {
          ...v,
          lastCheck: last
            ? {
                id: last.id,
                checkDate: last.checkDate,
                status: last.status,
                checkedAt: last.checkedAt,
                odometer: last.odometer,
                fuelLevel: last.fuelLevel,
                userName: last.userName,
              }
            : null,
          checkedToday: last?.checkDate === today,
        };
      }),
    });
  } catch (err) {
    console.error("List vehicles error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const body = await req.json();
    const name = String(body.name || "").trim();
    if (!name) {
      return NextResponse.json({ error: "Give the truck a name" }, { status: 400 });
    }
    const [vehicle] = await db
      .insert(vehicles)
      .values({
        name,
        plate: body.plate ? String(body.plate).trim().toUpperCase() : null,
        description: body.description ? String(body.description).trim() : null,
      })
      .returning();
    return NextResponse.json({ vehicle }, { status: 201 });
  } catch (err) {
    console.error("Create vehicle error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const body = await req.json();
    if (!body.id) return NextResponse.json({ error: "id required" }, { status: 400 });

    const patch: Partial<typeof vehicles.$inferInsert> = {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return NextResponse.json({ error: "Name can't be empty" }, { status: 400 });
      patch.name = name;
    }
    if (body.plate !== undefined) patch.plate = body.plate ? String(body.plate).trim().toUpperCase() : null;
    if (body.description !== undefined) patch.description = body.description ? String(body.description).trim() : null;
    if (body.active !== undefined) patch.active = Boolean(body.active);

    const [vehicle] = await db
      .update(vehicles)
      .set(patch)
      .where(and(eq(vehicles.id, String(body.id))))
      .returning();
    if (!vehicle) return NextResponse.json({ error: "Truck not found" }, { status: 404 });
    return NextResponse.json({ vehicle });
  } catch (err) {
    console.error("Update vehicle error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
