import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { loadPhotoBytes } from "@/lib/photos";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Serve photo bytes. Behind auth — yard photos can show customer sites, damage
 * claims, and license plates, so they're not public URLs.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    if (!UUID_RE.test(id)) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const photo = await loadPhotoBytes(id);
    if (!photo) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const body = new Uint8Array(photo.data);

    return new NextResponse(body, {
      status: 200,
      headers: {
        "Content-Type": photo.contentType,
        "Content-Length": String(body.byteLength),
        // Photo bytes never change once written, so let the device keep them.
        // Private: this is authenticated content and must not sit in a CDN.
        "Cache-Control": "private, max-age=31536000, immutable",
        "Content-Disposition": "inline",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    console.error("Photo fetch error:", err);
    return NextResponse.json({ error: "Could not load the photo" }, { status: 500 });
  }
}
