import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import {
  storePhoto,
  listPhotosForSubject,
  sniffImageType,
  optionalNumber,
  MAX_PHOTO_BYTES,
  PHOTO_SUBJECTS,
  ALLOWED_CONTENT_TYPES,
  type PhotoSubject,
} from "@/lib/photos";

/** Guards the subjectId before it reaches Postgres, which errors on a bad uuid. */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Photo upload. Multipart rather than base64 JSON — base64 inflates the payload
 * by ~33%, which is real money on a phone in a yard with one bar.
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No photo uploaded" }, { status: 400 });
    }

    if (file.size === 0) {
      return NextResponse.json({ error: "The photo was empty" }, { status: 400 });
    }

    if (file.size > MAX_PHOTO_BYTES) {
      return NextResponse.json(
        { error: "That photo is too large. Try again from the app camera." },
        { status: 413 }
      );
    }

    const subjectType = String(form.get("subjectType") || "");
    if (!PHOTO_SUBJECTS.has(subjectType)) {
      return NextResponse.json({ error: "Invalid photo subject" }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());

    // Trust the bytes, not the header.
    const sniffed = sniffImageType(buffer);
    if (!sniffed || !ALLOWED_CONTENT_TYPES.has(sniffed)) {
      return NextResponse.json(
        { error: "That file doesn't look like a photo (JPEG, PNG or WebP only)." },
        { status: 415 }
      );
    }

    const subjectIdRaw = form.get("subjectId");
    const subjectId = subjectIdRaw ? String(subjectIdRaw).trim() || null : null;

    const deviceTimeRaw = form.get("deviceTime");
    const deviceTime = deviceTimeRaw ? new Date(String(deviceTimeRaw)) : new Date();

    const photo = await storePhoto({
      subjectType: subjectType as PhotoSubject,
      subjectId,
      data: buffer,
      contentType: sniffed,
      width: optionalNumber(form.get("width")),
      height: optionalNumber(form.get("height")),
      takenBy: session.id, // always the session, never a client-supplied id
      deviceId: form.get("deviceId") ? String(form.get("deviceId")) : null,
      deviceTime: Number.isNaN(deviceTime.getTime()) ? new Date() : deviceTime,
      latitude: optionalNumber(form.get("latitude")),
      longitude: optionalNumber(form.get("longitude")),
      accuracyM: optionalNumber(form.get("accuracyM")),
      caption: form.get("caption") ? String(form.get("caption")).trim() : null,
    });

    return NextResponse.json({ photo }, { status: 201 });
  } catch (err) {
    console.error("Photo upload error:", err);
    return NextResponse.json({ error: "Could not save the photo" }, { status: 500 });
  }
}

/**
 * List photo metadata for one subject (never the bytes — those come from
 * /api/photos/[id], one request per image, so the browser can cache them
 * individually).
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const subjectType = String(searchParams.get("subjectType") || "");
    const subjectId = String(searchParams.get("subjectId") || "").trim();

    if (!PHOTO_SUBJECTS.has(subjectType)) {
      return NextResponse.json({ error: "Invalid photo subject" }, { status: 400 });
    }
    if (!UUID_RE.test(subjectId)) {
      return NextResponse.json({ error: "A subjectId is required" }, { status: 400 });
    }

    return NextResponse.json({ photos: await listPhotosForSubject(subjectType, subjectId) });
  } catch (err) {
    console.error("Photo list error:", err);
    return NextResponse.json({ error: "Could not load photos" }, { status: 500 });
  }
}
