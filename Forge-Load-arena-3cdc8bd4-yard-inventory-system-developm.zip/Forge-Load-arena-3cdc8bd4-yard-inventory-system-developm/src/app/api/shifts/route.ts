import { NextRequest, NextResponse } from "next/server";
import { db, shifts, sites, users, itineraries, itineraryAcks } from "@/db";
import { and, desc, eq, gte, isNull, lte, or, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isUniqueViolation } from "@/lib/db-errors";
import {
  haversineMeters,
  isValidLatLng,
  localDateKey,
  parseSiteToken,
} from "@/lib/fleet";

/**
 * Clock in.
 *
 * The phone sends the token it scanned (or none, for a manual clock-in), its
 * position if it has one, and a client UUID so an offline retry can't open two
 * shifts. Everything else — who, when, how far from the shop — is worked out
 * here, never trusted from the body.
 *
 * Returns the shift plus the day's itinerary for this person, so the screen
 * that appears after the scan is "you're in, here's what the office wants".
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json().catch(() => ({}));
    const {
      clientUuid,
      token,
      latitude,
      longitude,
      accuracyM,
      deviceId,
    } = body as {
      clientUuid?: string;
      token?: string | null;
      latitude?: unknown;
      longitude?: unknown;
      accuracyM?: unknown;
      deviceId?: string;
    };

    if (!clientUuid || typeof clientUuid !== "string") {
      return NextResponse.json({ error: "clientUuid is required" }, { status: 400 });
    }

    // Already clocked in? Return the open shift rather than erroring, so a
    // second scan (or a retry) is a no-op from the crew's point of view.
    const [open] = await db
      .select()
      .from(shifts)
      .where(and(eq(shifts.userId, session.id), eq(shifts.status, "active")))
      .limit(1);

    if (open) {
      return NextResponse.json({
        shift: open,
        alreadyActive: true,
        itinerary: await deliverItinerary(session.id, open.id),
      });
    }

    let site: typeof sites.$inferSelect | undefined;
    let method: "qr" | "manual" = "manual";

    if (token) {
      const parsed = parseSiteToken(String(token));
      if (!parsed) {
        return NextResponse.json({ error: "That code isn't a clock-in code" }, { status: 400 });
      }
      [site] = await db
        .select()
        .from(sites)
        .where(and(eq(sites.token, parsed), eq(sites.active, true)))
        .limit(1);
      if (!site) {
        return NextResponse.json(
          { error: "Unknown clock-in code. Ask the office to reprint the poster." },
          { status: 404 }
        );
      }
      method = "qr";
    }

    const hasFix = isValidLatLng(latitude, longitude);
    const lat = hasFix ? (latitude as number) : null;
    const lng = hasFix ? (longitude as number) : null;
    const acc = typeof accuracyM === "number" && Number.isFinite(accuracyM) ? accuracyM : null;

    const distanceM =
      hasFix && site && site.latitude != null && site.longitude != null
        ? haversineMeters(lat!, lng!, site.latitude, site.longitude)
        : null;

    let shift: typeof shifts.$inferSelect;
    try {
      [shift] = await db
        .insert(shifts)
        .values({
          clientUuid,
          userId: session.id,
          siteId: site?.id ?? null,
          method,
          clockInLat: lat,
          clockInLng: lng,
          clockInAccuracyM: acc,
          clockInDistanceM: distanceM,
          clockInDeviceId: typeof deviceId === "string" ? deviceId.slice(0, 64) : null,
          lastLat: lat,
          lastLng: lng,
          lastAccuracyM: acc,
          lastPingAt: hasFix ? new Date() : null,
        })
        .returning();
    } catch (err) {
      if (isUniqueViolation(err)) {
        // Lost the race with ourselves (double-tap, or a retried request that
        // did land). Whichever row won is the shift.
        const [existing] = await db
          .select()
          .from(shifts)
          .where(
            or(
              eq(shifts.clientUuid, clientUuid),
              and(eq(shifts.userId, session.id), eq(shifts.status, "active"))
            )
          )
          .orderBy(desc(shifts.clockInAt))
          .limit(1);
        if (existing) {
          return NextResponse.json({
            shift: existing,
            alreadyActive: true,
            itinerary: await deliverItinerary(session.id, existing.id),
          });
        }
      }
      throw err;
    }

    return NextResponse.json(
      {
        shift,
        site: site ? { id: site.id, name: site.name, radiusM: site.radiusM } : null,
        itinerary: await deliverItinerary(session.id, shift.id),
      },
      { status: 201 }
    );
  } catch (err) {
    console.error("Clock-in error:", err);
    return NextResponse.json({ error: "Could not clock in" }, { status: 500 });
  }
}

/**
 * Today's orders for one person: everything addressed to them plus everything
 * addressed to the whole crew. Marks each as delivered (first delivery wins,
 * so the timestamp is the *first* time their phone showed it).
 */
async function deliverItinerary(userId: string, shiftId: string) {
  const today = localDateKey();

  const rows = await db
    .select({
      id: itineraries.id,
      forDate: itineraries.forDate,
      title: itineraries.title,
      body: itineraries.body,
      priority: itineraries.priority,
      assigneeId: itineraries.assigneeId,
      createdByName: users.fullName,
      createdAt: itineraries.createdAt,
    })
    .from(itineraries)
    .leftJoin(users, eq(users.id, itineraries.createdBy))
    .where(
      and(
        eq(itineraries.forDate, today),
        eq(itineraries.active, true),
        or(isNull(itineraries.assigneeId), eq(itineraries.assigneeId, userId))
      )
    )
    .orderBy(desc(itineraries.priority), itineraries.createdAt);

  if (rows.length > 0) {
    await db
      .insert(itineraryAcks)
      .values(rows.map((r) => ({ itineraryId: r.id, userId, shiftId })))
      .onConflictDoNothing();
  }

  return rows;
}

/**
 * List shifts.
 *
 *   ?mine=1            the caller's own (crew use: "am I clocked in?")
 *   ?active=1          every open shift with last-known position (the live map)
 *   ?date=YYYY-MM-DD   everything that touched that day (the timesheet)
 *
 * Anything other than `mine` is admin-only: where the crew are is the owner's
 * information, not each other's.
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const mine = searchParams.get("mine") === "1";
    const activeOnly = searchParams.get("active") === "1";
    const date = searchParams.get("date");

    if (!mine && session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const conditions = [];
    if (mine) conditions.push(eq(shifts.userId, session.id));
    if (activeOnly) conditions.push(eq(shifts.status, "active"));
    if (date) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return NextResponse.json({ error: "date must be YYYY-MM-DD" }, { status: 400 });
      }
      // Anything that overlaps the calendar day in the shop's zone.
      const start = sql`(${date}::date::timestamp AT TIME ZONE 'America/Chicago')`;
      const end = sql`((${date}::date + 1)::timestamp AT TIME ZONE 'America/Chicago')`;
      conditions.push(
        and(
          lte(shifts.clockInAt, end),
          or(isNull(shifts.clockOutAt), gte(shifts.clockOutAt, start))
        )!
      );
    }

    const limit = Math.min(Number(searchParams.get("limit") || 200), 500);

    const rows = await db
      .select({
        id: shifts.id,
        userId: shifts.userId,
        userName: users.fullName,
        siteId: shifts.siteId,
        siteName: sites.name,
        status: shifts.status,
        method: shifts.method,
        clockInAt: shifts.clockInAt,
        clockInDistanceM: shifts.clockInDistanceM,
        clockInAccuracyM: shifts.clockInAccuracyM,
        clockOutAt: shifts.clockOutAt,
        lastLat: shifts.lastLat,
        lastLng: shifts.lastLng,
        lastAccuracyM: shifts.lastAccuracyM,
        lastSpeedMps: shifts.lastSpeedMps,
        lastPingAt: shifts.lastPingAt,
        pingCount: shifts.pingCount,
      })
      .from(shifts)
      .innerJoin(users, eq(users.id, shifts.userId))
      .leftJoin(sites, eq(sites.id, shifts.siteId))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(shifts.clockInAt))
      .limit(limit);

    return NextResponse.json({ shifts: rows });
  } catch (err) {
    console.error("List shifts error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
