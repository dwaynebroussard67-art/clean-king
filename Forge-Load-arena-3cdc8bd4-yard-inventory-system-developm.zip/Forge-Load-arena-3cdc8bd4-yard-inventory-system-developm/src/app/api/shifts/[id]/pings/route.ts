import { NextRequest, NextResponse } from "next/server";
import { db, shifts, locationPings } from "@/db";
import { and, eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isValidLatLng } from "@/lib/fleet";

const MAX_BATCH = 200;

interface IncomingPing {
  latitude: unknown;
  longitude: unknown;
  accuracyM?: unknown;
  speedMps?: unknown;
  heading?: unknown;
  recordedAt?: unknown;
}

/**
 * Breadcrumbs from the phone. Batched, because the truck spends a lot of its
 * day in places with one bar and the phone buffers fixes until it can flush.
 *
 * Only the shift's own user may write to it, and only while it's open — a
 * ping arriving for a closed shift is dropped with 200 (the phone just hasn't
 * heard yet that the shift ended, and retrying would never succeed).
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { id } = await params;

    const [shift] = await db
      .select({ id: shifts.id, userId: shifts.userId, status: shifts.status })
      .from(shifts)
      .where(eq(shifts.id, id))
      .limit(1);

    if (!shift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 });
    }
    if (shift.userId !== session.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    if (shift.status !== "active") {
      return NextResponse.json({ accepted: 0, shiftClosed: true });
    }

    const body = await req.json().catch(() => ({}));
    const raw: IncomingPing[] = Array.isArray(body.pings) ? body.pings : [];
    if (raw.length === 0) {
      return NextResponse.json({ error: "No pings" }, { status: 400 });
    }

    const now = Date.now();
    const rows = raw
      .slice(0, MAX_BATCH)
      .filter((p) => isValidLatLng(p.latitude, p.longitude))
      .map((p) => {
        const t = typeof p.recordedAt === "string" ? Date.parse(p.recordedAt) : NaN;
        // A phone clock a week off shouldn't put a breadcrumb in the future;
        // clamp to "now" and let received_at tell the truth.
        const recordedAt = Number.isFinite(t) && t <= now + 60_000 ? new Date(t) : new Date(now);
        const num = (v: unknown) =>
          typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : null;
        return {
          shiftId: shift.id,
          userId: session.id,
          latitude: p.latitude as number,
          longitude: p.longitude as number,
          accuracyM: num(p.accuracyM),
          speedMps: num(p.speedMps),
          heading: num(p.heading),
          recordedAt,
        };
      })
      .sort((a, b) => a.recordedAt.getTime() - b.recordedAt.getTime());

    if (rows.length === 0) {
      return NextResponse.json({ error: "No valid positions" }, { status: 400 });
    }

    const latest = rows[rows.length - 1];

    await db.transaction(async (tx) => {
      await tx.insert(locationPings).values(rows);
      // The counter always advances. The last-known position only advances
      // when this batch is newer than what's there — batches can arrive out
      // of order after an offline stretch, and the map must never jump back.
      const newer = sql`(${shifts.lastPingAt} IS NULL OR ${shifts.lastPingAt} <= ${latest.recordedAt.toISOString()}::timestamptz)`;
      await tx
        .update(shifts)
        .set({
          pingCount: sql`${shifts.pingCount} + ${rows.length}`,
          lastLat: sql`CASE WHEN ${newer} THEN ${latest.latitude}::double precision ELSE ${shifts.lastLat} END`,
          lastLng: sql`CASE WHEN ${newer} THEN ${latest.longitude}::double precision ELSE ${shifts.lastLng} END`,
          lastAccuracyM: sql`CASE WHEN ${newer} THEN ${latest.accuracyM}::double precision ELSE ${shifts.lastAccuracyM} END`,
          lastSpeedMps: sql`CASE WHEN ${newer} THEN ${latest.speedMps}::double precision ELSE ${shifts.lastSpeedMps} END`,
          lastPingAt: sql`CASE WHEN ${newer} THEN ${latest.recordedAt.toISOString()}::timestamptz ELSE ${shifts.lastPingAt} END`,
        })
        .where(eq(shifts.id, shift.id));
    });

    return NextResponse.json({ accepted: rows.length });
  } catch (err) {
    console.error("Ping error:", err);
    return NextResponse.json({ error: "Could not record location" }, { status: 500 });
  }
}
