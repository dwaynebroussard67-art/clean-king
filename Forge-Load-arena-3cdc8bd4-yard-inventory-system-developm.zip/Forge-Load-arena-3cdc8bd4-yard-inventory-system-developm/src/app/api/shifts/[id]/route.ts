import { NextRequest, NextResponse } from "next/server";
import { db, shifts, locationPings, users, sites } from "@/db";
import { and, asc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isValidLatLng } from "@/lib/fleet";

/**
 * One shift with its breadcrumb trail. The crew can read their own; the
 * office can read anyone's.
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { id } = await params;

    const [shift] = await db
      .select({
        id: shifts.id,
        userId: shifts.userId,
        userName: users.fullName,
        siteName: sites.name,
        status: shifts.status,
        method: shifts.method,
        clockInAt: shifts.clockInAt,
        clockInLat: shifts.clockInLat,
        clockInLng: shifts.clockInLng,
        clockInDistanceM: shifts.clockInDistanceM,
        clockOutAt: shifts.clockOutAt,
        clockOutLat: shifts.clockOutLat,
        clockOutLng: shifts.clockOutLng,
        lastLat: shifts.lastLat,
        lastLng: shifts.lastLng,
        lastPingAt: shifts.lastPingAt,
        pingCount: shifts.pingCount,
      })
      .from(shifts)
      .innerJoin(users, eq(users.id, shifts.userId))
      .leftJoin(sites, eq(sites.id, shifts.siteId))
      .where(eq(shifts.id, id))
      .limit(1);

    if (!shift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 });
    }
    if (session.role !== "admin" && shift.userId !== session.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const trail = await db
      .select({
        latitude: locationPings.latitude,
        longitude: locationPings.longitude,
        accuracyM: locationPings.accuracyM,
        speedMps: locationPings.speedMps,
        recordedAt: locationPings.recordedAt,
      })
      .from(locationPings)
      .where(eq(locationPings.shiftId, id))
      .orderBy(asc(locationPings.recordedAt))
      .limit(5000);

    return NextResponse.json({ shift, trail });
  } catch (err) {
    console.error("Get shift error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

/**
 * Clock out. `{ action: "clock_out" }` plus an optional final position.
 *
 * The crew close their own shift; an admin can close anyone's (the phone
 * died, they forgot, they went home). Closing an already-closed shift is
 * idempotent so an offline retry doesn't error.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { id } = await params;
    const body = await req.json().catch(() => ({}));

    if (body.action !== "clock_out") {
      return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
    }

    const [shift] = await db.select().from(shifts).where(eq(shifts.id, id)).limit(1);
    if (!shift) {
      return NextResponse.json({ error: "Shift not found" }, { status: 404 });
    }
    if (session.role !== "admin" && shift.userId !== session.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    if (shift.status === "closed") {
      return NextResponse.json({ shift, idempotent: true });
    }

    const hasFix = isValidLatLng(body.latitude, body.longitude);

    const [updated] = await db
      .update(shifts)
      .set({
        status: "closed",
        clockOutAt: new Date(),
        clockOutLat: hasFix ? body.latitude : null,
        clockOutLng: hasFix ? body.longitude : null,
        clockOutAccuracyM:
          typeof body.accuracyM === "number" && Number.isFinite(body.accuracyM)
            ? body.accuracyM
            : null,
        clockOutBy: session.id,
      })
      // Guard on status so two simultaneous clock-outs can't both "win" and
      // stamp different times.
      .where(and(eq(shifts.id, id), eq(shifts.status, "active")))
      .returning();

    if (!updated) {
      const [now] = await db.select().from(shifts).where(eq(shifts.id, id)).limit(1);
      return NextResponse.json({ shift: now, idempotent: true });
    }

    return NextResponse.json({ shift: updated });
  } catch (err) {
    console.error("Clock-out error:", err);
    return NextResponse.json({ error: "Could not clock out" }, { status: 500 });
  }
}
