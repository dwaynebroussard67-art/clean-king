import { NextRequest, NextResponse } from "next/server";
import { db, products, bundles } from "@/db";
import { eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { terms, Unit } from "@/lib/tenant";
import { isForeignKeyViolation, isUniqueViolation } from "@/lib/db-errors";

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const { id } = await params;
    const body = await req.json();
    const { sku, name, category, baseUnit, piecesPerBundle, reorderThreshold } = body;

    await db.update(products).set({
      sku: sku?.trim().toUpperCase(),
      name: name?.trim(),
      category: category?.trim() || null,
      baseUnit: baseUnit || "piece",
      piecesPerBundle: piecesPerBundle ? String(piecesPerBundle) : null,
      reorderThreshold: reorderThreshold ? String(reorderThreshold) : null,
    }).where(eq(products.id, id));

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (isUniqueViolation(err)) {
      return NextResponse.json({ error: "SKU already exists" }, { status: 409 });
    }
    console.error("Update product error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const { id } = await params;

    // Retire rather than delete. A hard delete used to throw a foreign-key
    // violation (surfaced as a bare "Internal server error") for any product
    // that had ever been received, which is most of them.
    const [{ count: bundleCount }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(bundles)
      .where(eq(bundles.productId, id));

    if (bundleCount > 0) {
      await db.update(products).set({ active: false }).where(eq(products.id, id));
      return NextResponse.json({
        ok: true,
        retired: true,
        message: `Product retired — ${bundleCount} ${bundleCount === 1 ? terms.unit : terms.unitPlural} reference it, so its history is preserved.`,
      });
    }

    // Never received against: safe to remove outright.
    await db.delete(products).where(eq(products.id, id));
    return NextResponse.json({ ok: true, retired: false });
  } catch (err) {
    if (isForeignKeyViolation(err)) {
      await db
        .update(products)
        .set({ active: false })
        .where(eq(products.id, (await params).id));
      return NextResponse.json({ ok: true, retired: true });
    }
    console.error("Delete product error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
