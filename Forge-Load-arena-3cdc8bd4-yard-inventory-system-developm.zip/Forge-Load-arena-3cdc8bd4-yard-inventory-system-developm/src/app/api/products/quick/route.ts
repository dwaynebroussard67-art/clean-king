import { NextRequest, NextResponse } from "next/server";
import { db, products, bundles, movements, photos } from "@/db";
import { eq, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isUniqueViolation } from "@/lib/db-errors";
import { nextBundleCodes } from "@/lib/codes";
import { terms, Unit } from "@/lib/tenant";
import { v4 as uuidv4 } from "uuid";

/**
 * Camera-first intake: create a product from a photo and immediately stock it,
 * in one request.
 *
 * The normal receiving flow assumes the product already exists in the
 * catalogue. This is for the case the yard actually hits — a truck shows up
 * with something that's never been in the system, and someone needs it counted
 * in without going to a desk. Photo, name, count, done.
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const body = await req.json();
    const {
      name,
      sku,
      category,
      baseUnit = "piece",
      photoId,
      bundleCount = 1,
      qtyPerBundle,
      location,
      reorderThreshold,
    } = body;

    if (!name || !String(name).trim()) {
      return NextResponse.json({ error: "Give the item a name" }, { status: 400 });
    }

    const qty = Number(qtyPerBundle);
    if (!Number.isFinite(qty) || qty <= 0) {
      return NextResponse.json(
        { error: `Enter how many are in each ${terms.unit}` },
        { status: 400 }
      );
    }

    const count = Number(bundleCount);
    if (!Number.isInteger(count) || count < 1 || count > 200) {
      return NextResponse.json(
        { error: `${Unit} count must be between 1 and 200` },
        { status: 400 }
      );
    }

    // Auto-generate a SKU when the crew doesn't supply one. They're standing in
    // the yard; making up a SKU scheme is not their job.
    const finalSku = String(sku || "").trim().toUpperCase() || (await autoSku(String(name)));

    const result = await db.transaction(async (tx) => {
      const [product] = await tx
        .insert(products)
        .values({
          sku: finalSku,
          name: String(name).trim(),
          category: category ? String(category).trim() : null,
          baseUnit: baseUnit || "piece",
          piecesPerBundle: String(qty),
          reorderThreshold: reorderThreshold ? String(reorderThreshold) : null,
          primaryPhotoId: photoId || null,
        })
        .returning();

      // Bind the photo to the new product.
      if (photoId) {
        await tx
          .update(photos)
          .set({ subjectType: "product", subjectId: product.id })
          .where(eq(photos.id, photoId));
      }

      const codes = await nextBundleCodes(count, tx);

      const bundleRows = await tx
        .insert(bundles)
        .values(
          codes.map((code) => ({
            code,
            productId: product.id,
            unit: baseUnit || "piece",
            qtyReceived: String(qty),
            qtyRemaining: String(qty),
            status: "active",
            location: location ? String(location).trim() : null,
            receivedBy: session.id,
          }))
        )
        .returning({ id: bundles.id, code: bundles.code });

      await tx.insert(movements).values(
        bundleRows.map((b) => ({
          clientUuid: uuidv4(),
          bundleId: b.id,
          productId: product.id,
          type: "receive",
          qtyDelta: String(qty),
          unit: baseUnit || "piece",
          employeeId: session.id,
          deviceTime: new Date(),
          note: "Quick intake from camera",
        }))
      );

      return { product, bundles: bundleRows };
    });

    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    if (isUniqueViolation(err)) {
      return NextResponse.json(
        { error: "That SKU already exists — pick a different one." },
        { status: 409 }
      );
    }
    console.error("Quick intake error:", err);
    return NextResponse.json({ error: "Could not create the item" }, { status: 500 });
  }
}

/** Derive a readable, unique-ish SKU from the item name. */
async function autoSku(name: string): Promise<string> {
  const base =
    name
      .toUpperCase()
      .replace(/[^A-Z0-9\s]/g, "")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 3)
      .map((w) => w.slice(0, 4))
      .join("-") || "ITEM";

  const { rows } = await db.execute(
    sql`SELECT COUNT(*)::int AS c FROM products WHERE sku LIKE ${base + "%"}`
  );
  const n = Number((rows[0] as { c: number }).c);
  return n === 0 ? base : `${base}-${n + 1}`;
}
