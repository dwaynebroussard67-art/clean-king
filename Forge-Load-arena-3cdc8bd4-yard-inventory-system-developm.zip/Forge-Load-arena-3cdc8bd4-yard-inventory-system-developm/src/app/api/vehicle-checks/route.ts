import { NextRequest, NextResponse } from "next/server";
import { db, vehicleChecks, vehicles, users, shifts } from "@/db";
import { and, desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isUniqueViolation } from "@/lib/db-errors";
import {
  CHECK_KEYS,
  FUEL_LEVELS,
  isValidLatLng,
  localDateKey,
  rollupCheckStatus,
  type CheckResult,
} from "@/lib/fleet";

const RESULTS = new Set<CheckResult>(["ok", "watch", "bad"]);

/**
 * File the morning check.
 *
 * The phone sends the truck, the per-item results, and whatever it read off
 * the dash. The status (good / attention / do-not-drive) is computed here from
 * the items, not accepted from the client, so a checklist with a bad brake
 * result can't be submitted as "good to go".
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const body = await req.json().catch(() => ({}));
    const { clientUuid, vehicleId, items, odometer, fuelLevel, notes, latitude, longitude, deviceId, deviceTime } = body;

    if (!clientUuid || typeof clientUuid !== "string") {
      return NextResponse.json({ error: "clientUuid is required" }, { status: 400 });
    }
    if (!vehicleId || typeof vehicleId !== "string") {
      return NextResponse.json({ error: "Pick a truck" }, { status: 400 });
    }
    if (!items || typeof items !== "object" || Array.isArray(items)) {
      return NextResponse.json({ error: "Checklist results are required" }, { status: 400 });
    }

    // Keep only known keys with known values. Unknown keys are dropped rather
    // than rejected so an older phone build can't be locked out by a new item.
    const clean: Record<string, CheckResult> = {};
    for (const [k, v] of Object.entries(items as Record<string, unknown>)) {
      if (CHECK_KEYS.has(k) && typeof v === "string" && RESULTS.has(v as CheckResult)) {
        clean[k] = v as CheckResult;
      }
    }
    if (Object.keys(clean).length === 0) {
      return NextResponse.json({ error: "Nothing was checked" }, { status: 400 });
    }

    const [vehicle] = await db
      .select({ id: vehicles.id, active: vehicles.active })
      .from(vehicles)
      .where(eq(vehicles.id, vehicleId))
      .limit(1);
    if (!vehicle) {
      return NextResponse.json({ error: "Truck not found" }, { status: 404 });
    }

    const odo = odometer === undefined || odometer === null || odometer === "" ? null : Number(odometer);
    if (odo !== null && (!Number.isInteger(odo) || odo < 0 || odo > 5_000_000)) {
      return NextResponse.json({ error: "Odometer must be a whole number" }, { status: 400 });
    }
    const fuel =
      typeof fuelLevel === "string" && (FUEL_LEVELS as readonly string[]).includes(fuelLevel)
        ? fuelLevel
        : null;

    // Tie the check to the open shift, if there is one, so the timesheet can
    // show "clocked in 7:02, checked Truck 1 at 7:09".
    const [open] = await db
      .select({ id: shifts.id })
      .from(shifts)
      .where(and(eq(shifts.userId, session.id), eq(shifts.status, "active")))
      .limit(1);

    const hasFix = isValidLatLng(latitude, longitude);
    const status = rollupCheckStatus(clean);

    try {
      const [check] = await db
        .insert(vehicleChecks)
        .values({
          clientUuid,
          vehicleId,
          userId: session.id,
          shiftId: open?.id ?? null,
          checkDate: localDateKey(),
          items: clean,
          status,
          odometer: odo,
          fuelLevel: fuel,
          notes: typeof notes === "string" && notes.trim() ? notes.trim().slice(0, 2000) : null,
          latitude: hasFix ? latitude : null,
          longitude: hasFix ? longitude : null,
          deviceId: typeof deviceId === "string" ? deviceId.slice(0, 64) : null,
          deviceTime: deviceTime ? new Date(deviceTime) : new Date(),
        })
        .returning();
      return NextResponse.json({ check }, { status: 201 });
    } catch (err) {
      if (isUniqueViolation(err)) {
        return NextResponse.json({ ok: true, idempotent: true });
      }
      throw err;
    }
  } catch (err) {
    console.error("Vehicle check error:", err);
    return NextResponse.json({ error: "Could not save the check" }, { status: 500 });
  }
}

/**
 * History. `?vehicleId=` for one truck, `?date=` for one morning, `?status=`
 * to find what needs fixing. Crew may read (the truck's history helps the
 * person checking it); nothing here is sensitive.
 */
export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const { searchParams } = new URL(req.url);
    const vehicleId = searchParams.get("vehicleId");
    const date = searchParams.get("date");
    const status = searchParams.get("status");
    const limit = Math.min(Number(searchParams.get("limit") || 50), 500);

    const conditions = [];
    if (vehicleId) conditions.push(eq(vehicleChecks.vehicleId, vehicleId));
    if (date) conditions.push(eq(vehicleChecks.checkDate, date));
    if (status) conditions.push(eq(vehicleChecks.status, status));

    const rows = await db
      .select({
        id: vehicleChecks.id,
        vehicleId: vehicleChecks.vehicleId,
        vehicleName: vehicles.name,
        userName: users.fullName,
        checkDate: vehicleChecks.checkDate,
        items: vehicleChecks.items,
        status: vehicleChecks.status,
        odometer: vehicleChecks.odometer,
        fuelLevel: vehicleChecks.fuelLevel,
        notes: vehicleChecks.notes,
        checkedAt: vehicleChecks.checkedAt,
      })
      .from(vehicleChecks)
      .innerJoin(vehicles, eq(vehicles.id, vehicleChecks.vehicleId))
      .innerJoin(users, eq(users.id, vehicleChecks.userId))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(vehicleChecks.checkedAt))
      .limit(limit);

    return NextResponse.json({ checks: rows });
  } catch (err) {
    console.error("List vehicle checks error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
