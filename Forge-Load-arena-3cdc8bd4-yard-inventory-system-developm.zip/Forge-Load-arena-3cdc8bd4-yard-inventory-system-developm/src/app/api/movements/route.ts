import { NextRequest, NextResponse } from "next/server";
import { db, movements, bundles, products } from "@/db";
import { eq, desc, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth"
import { terms, Unit } from "@/lib/tenant";
import { isUniqueViolation } from "@/lib/db-errors";

/** Thrown inside the transaction to force a rollback when the atomic UPDATE
 *  matches no rows (concurrent pull, or the delta would go negative). */
class InsufficientQuantityError extends Error {
  constructor() {
    super("Insufficient quantity");
    this.name = "InsufficientQuantityError";
  }
}

const VALID_TYPES = new Set([
  "receive",
  "pull",
  "return",
  "adjust",
  "count_correction",
]);

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      clientUuid,
      bundleId,
      productId,
      type,
      qtyDelta,
      unit,
      jobId,
      deviceId,
      deviceTime,
      note,
    } = body;

    if (!clientUuid || !bundleId || !productId || !type || qtyDelta === undefined) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    if (!VALID_TYPES.has(type)) {
      return NextResponse.json({ error: `Invalid movement type: ${type}` }, { status: 400 });
    }

    const delta = Number(qtyDelta);
    if (!Number.isFinite(delta)) {
      return NextResponse.json({ error: "qtyDelta must be a number" }, { status: 400 });
    }

    // The whole point of this system is a trustworthy record of who moved what,
    // so attribution always comes from the session cookie — never from the
    // request body, which the client controls.
    const employeeId = session.id;

    // Everything below runs in one transaction so the ledger row and the bundle
    // balance can never disagree. Previously a crash between the two left the
    // bundle permanently out of sync with its own movement history.
    const result = await db.transaction(async (tx) => {
      const [bundle] = await tx
        .select()
        .from(bundles)
        .where(eq(bundles.id, bundleId))
        .limit(1);

      if (!bundle) return { error: `${Unit} not found`, status: 404 as const };
      if (bundle.status === "retired") {
        return {
          error: `${Unit} is retired; no further movements allowed`,
          status: 422 as const,
        };
      }

      // Insert the ledger row first. The unique index on client_uuid is what
      // makes offline replay safe: a retried movement collides here and we bail
      // out before touching the balance a second time.
      try {
        await tx.insert(movements).values({
          clientUuid,
          bundleId,
          productId,
          type,
          qtyDelta: String(delta),
          unit: unit || bundle.unit,
          jobId: jobId || null,
          employeeId,
          deviceId: deviceId || null,
          deviceTime: deviceTime ? new Date(deviceTime) : new Date(),
          note: note || null,
        });
      } catch (err) {
        if (isUniqueViolation(err)) {
          return { idempotent: true as const, status: 200 as const };
        }
        throw err;
      }

      // Apply the delta atomically. Doing the bounds check inside the UPDATE
      // (rather than reading, checking, then writing) is what prevents two crew
      // members pulling from the same bundle at once from overselling it —
      // the second UPDATE simply matches zero rows.
      const updated = await tx
        .update(bundles)
        .set({
          qtyRemaining: sql`${bundles.qtyRemaining} + ${String(delta)}::numeric`,
          status: sql`CASE
            WHEN ${bundles.qtyRemaining} + ${String(delta)}::numeric <= 0 THEN 'retired'
            ELSE ${bundles.status}
          END`,
        })
        .where(
          sql`${bundles.id} = ${bundleId}
              AND ${bundles.status} <> 'retired'
              AND ${bundles.qtyRemaining} + ${String(delta)}::numeric >= 0`
        )
        .returning({
          qtyRemaining: bundles.qtyRemaining,
          status: bundles.status,
        });

      if (updated.length === 0) {
        // Someone else got there first, or the delta would go negative. Throwing
        // unwinds the transaction so the ledger insert above is rolled back too.
        throw new InsufficientQuantityError();
      }

      return { bundle: updated[0], status: 200 as const };
    }).catch((err) => {
      if (err instanceof InsufficientQuantityError) {
        return { error: "conflict" as const, status: 409 as const };
      }
      throw err;
    });

    if ("error" in result && result.error === "conflict") {
      return NextResponse.json(
        {
          error:
            `Not enough remaining on this ${terms.unit} — someone else may have just pulled from it. Refresh and try again.`,
        },
        { status: 409 }
      );
    }

    if ("error" in result) {
      return NextResponse.json({ error: result.error }, { status: result.status });
    }

    if ("idempotent" in result) {
      return NextResponse.json({ ok: true, idempotent: true });
    }

    return NextResponse.json({ ok: true, bundle: result.bundle });
  } catch (err) {
    console.error("Movement error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const parsedLimit = parseInt(searchParams.get("limit") || "50", 10);
    const limit = Math.min(Math.max(Number.isNaN(parsedLimit) ? 50 : parsedLimit, 1), 200);

    const rows = await db
      .select({
        id: movements.id,
        clientUuid: movements.clientUuid,
        type: movements.type,
        qtyDelta: movements.qtyDelta,
        unit: movements.unit,
        deviceTime: movements.deviceTime,
        serverTime: movements.serverTime,
        note: movements.note,
        bundleCode: bundles.code,
        productName: products.name,
      })
      .from(movements)
      .leftJoin(bundles, eq(movements.bundleId, bundles.id))
      .leftJoin(products, eq(movements.productId, products.id))
      .orderBy(desc(movements.serverTime))
      .limit(limit);

    return NextResponse.json({ movements: rows });
  } catch (err) {
    console.error("Get movements error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
