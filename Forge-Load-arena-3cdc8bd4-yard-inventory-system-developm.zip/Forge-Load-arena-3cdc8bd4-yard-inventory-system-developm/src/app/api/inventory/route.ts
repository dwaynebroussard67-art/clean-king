import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // The dashboard only shows three numbers, but was pulling every product
    // row to compute them client-side. On a real catalogue that's a slow
    // request on a phone, over yard wifi, on every home screen visit.
    const summaryOnly = new URL(req.url).searchParams.get("summary") === "1";

    if (summaryOnly) {
      const [totals] = (
        await db.execute(sql`
          WITH per_product AS (
            SELECT
              p.id,
              p.reorder_threshold,
              COALESCE(SUM(b.qty_remaining) FILTER (WHERE b.status = 'active'), 0) AS qty_on_hand,
              COUNT(b.id) FILTER (WHERE b.status = 'active') AS active_bundles
            FROM products p
            LEFT JOIN bundles b ON b.product_id = p.id
            GROUP BY p.id, p.reorder_threshold
          )
          SELECT
            COUNT(*)::int AS total_products,
            COALESCE(SUM(active_bundles), 0)::int AS active_bundles,
            COUNT(*) FILTER (
              WHERE reorder_threshold IS NOT NULL
                AND qty_on_hand <= reorder_threshold
            )::int AS low_stock_count
          FROM per_product
        `)
      ).rows as unknown as {
        total_products: number;
        active_bundles: number;
        low_stock_count: number;
      }[];

      return NextResponse.json({
        totalProducts: totals?.total_products ?? 0,
        activeBundles: totals?.active_bundles ?? 0,
        lowStockCount: totals?.low_stock_count ?? 0,
      });
    }

    // On-hand summary per product
    const onHand = await db.execute(sql`
      SELECT 
        p.id as product_id,
        p.sku,
        p.name,
        p.category,
        p.base_unit,
        p.reorder_threshold,
        COALESCE(SUM(b.qty_remaining) FILTER (WHERE b.status = 'active'), 0) as qty_on_hand,
        COUNT(b.id) FILTER (WHERE b.status = 'active') as active_bundles
      FROM products p
      LEFT JOIN bundles b ON b.product_id = p.id
      GROUP BY p.id, p.sku, p.name, p.category, p.base_unit, p.reorder_threshold
      ORDER BY p.name
    `);

    // Low stock
    const lowStock = onHand.rows.filter(
      (row: Record<string, unknown>) =>
        row.reorder_threshold !== null &&
        Number(row.qty_on_hand) <= Number(row.reorder_threshold)
    );

    return NextResponse.json({ onHand: onHand.rows, lowStock });
  } catch (err) {
    console.error("Inventory error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
