import { NextRequest, NextResponse } from "next/server";
import { db, sites } from "@/db";
import { asc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { isUniqueViolation } from "@/lib/db-errors";
import { generateSiteToken, isValidLatLng } from "@/lib/fleet";

/**
 * Clock-in sites. Everyone can list them (the clock-in screen needs the
 * names); only admins create them and only admins see the tokens, since the
 * token is what the QR poster encodes.
 */
export async function GET() {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const rows = await db.select().from(sites).orderBy(asc(sites.name));
    const isAdmin = session.role === "admin";
    return NextResponse.json({
      sites: rows.map((s) => ({
        id: s.id,
        name: s.name,
        address: s.address,
        latitude: s.latitude,
        longitude: s.longitude,
        radiusM: s.radiusM,
        active: s.active,
        token: isAdmin ? s.token : undefined,
      })),
    });
  } catch (err) {
    console.error("List sites error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const body = await req.json();
    const name = String(body.name || "").trim();
    if (!name) {
      return NextResponse.json({ error: "Give the site a name" }, { status: 400 });
    }
    const hasFix = isValidLatLng(body.latitude, body.longitude);
    const radiusM = Number(body.radiusM);

    // Retry on the (astronomically unlikely) token collision rather than
    // surfacing it.
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const [site] = await db
          .insert(sites)
          .values({
            name,
            address: body.address ? String(body.address).trim() : null,
            token: generateSiteToken(),
            latitude: hasFix ? body.latitude : null,
            longitude: hasFix ? body.longitude : null,
            radiusM: Number.isFinite(radiusM) && radiusM > 0 ? Math.min(radiusM, 5000) : 250,
          })
          .returning();
        return NextResponse.json({ site }, { status: 201 });
      } catch (err) {
        if (!isUniqueViolation(err) || attempt === 2) throw err;
      }
    }
    return NextResponse.json({ error: "Could not create site" }, { status: 500 });
  } catch (err) {
    console.error("Create site error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
