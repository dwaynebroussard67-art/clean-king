import { NextRequest, NextResponse } from "next/server";
import { db, sites } from "@/db";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { generateSiteToken, isValidLatLng } from "@/lib/fleet";

/**
 * Edit a site. `{ rotateToken: true }` issues a fresh token — do that when a
 * poster walks off, then reprint. Old posters stop working immediately.
 */
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }
    const { id } = await params;
    const body = await req.json();

    const patch: Partial<typeof sites.$inferInsert> = {};
    if (body.name !== undefined) {
      const name = String(body.name).trim();
      if (!name) return NextResponse.json({ error: "Name can't be empty" }, { status: 400 });
      patch.name = name;
    }
    if (body.address !== undefined) patch.address = body.address ? String(body.address).trim() : null;
    if (body.latitude !== undefined || body.longitude !== undefined) {
      if (body.latitude === null || body.longitude === null) {
        patch.latitude = null;
        patch.longitude = null;
      } else if (isValidLatLng(body.latitude, body.longitude)) {
        patch.latitude = body.latitude;
        patch.longitude = body.longitude;
      } else {
        return NextResponse.json({ error: "Invalid coordinates" }, { status: 400 });
      }
    }
    if (body.radiusM !== undefined) {
      const r = Number(body.radiusM);
      if (!Number.isFinite(r) || r <= 0 || r > 5000) {
        return NextResponse.json({ error: "Radius must be 1–5000 m" }, { status: 400 });
      }
      patch.radiusM = Math.round(r);
    }
    if (body.active !== undefined) patch.active = Boolean(body.active);
    if (body.rotateToken) patch.token = generateSiteToken();

    if (Object.keys(patch).length === 0) {
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
    }

    const [site] = await db.update(sites).set(patch).where(eq(sites.id, id)).returning();
    if (!site) return NextResponse.json({ error: "Site not found" }, { status: 404 });
    return NextResponse.json({ site });
  } catch (err) {
    console.error("Update site error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
