import { NextRequest, NextResponse } from "next/server";
import { db, receipts, receiptLines, bundles, products, movements } from "@/db";
import { eq, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { terms, Unit } from "@/lib/tenant";
import { nextBundleCodes, nextReceiptCode } from "@/lib/codes";
import { v4 as uuidv4 } from "uuid";

/** Thrown inside the receipt transaction to abort and roll back cleanly. */
class ReceiptValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ReceiptValidationError";
  }
}

export async function GET() {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const rows = await db
      .select()
      .from(receipts)
      .orderBy(desc(receipts.createdAt))
      .limit(100);

    return NextResponse.json({ receipts: rows });
  } catch (err) {
    console.error("Get receipts error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const body = await req.json();
    const { supplier, poNumber, notes, lines } = body;
    // lines: [{ productId, qtyPerBundle, bundleCount, unit }]

    if (!lines || lines.length === 0) {
      return NextResponse.json({ error: "At least one line required" }, { status: 400 });
    }

    // Validate everything before writing anything, so a bad line can't leave a
    // half-built receipt behind.
    const MAX_BUNDLES_PER_RECEIPT = 500;
    let totalBundles = 0;

    for (const line of lines) {
      const qty = Number(line.qtyPerBundle);
      const count = Number(line.bundleCount);

      if (!line.productId) {
        return NextResponse.json({ error: "Each line needs a product" }, { status: 400 });
      }
      if (!Number.isFinite(qty) || qty <= 0) {
        return NextResponse.json(
          { error: `Quantity per ${terms.unit} must be greater than zero` },
          { status: 400 }
        );
      }
      if (!Number.isInteger(count) || count <= 0) {
        return NextResponse.json(
          { error: `${Unit} count must be a whole number greater than zero` },
          { status: 400 }
        );
      }
      totalBundles += count;
    }

    if (totalBundles > MAX_BUNDLES_PER_RECEIPT) {
      return NextResponse.json(
        {
          error: `That receipt would create ${totalBundles} ${totalBundles === 1 ? terms.unit : terms.unitPlural} (limit ${MAX_BUNDLES_PER_RECEIPT}). Split it into multiple receipts.`,
        },
        { status: 422 }
      );
    }

    const code = await nextReceiptCode();

    // One transaction for the whole receipt. Previously this looped with
    // individual inserts, so a failure partway through left a committed receipt
    // with orphaned bundles and no way to resume or roll back.
    const { receipt, generatedBundles } = await db.transaction(async (tx) => {
      const [receipt] = await tx
        .insert(receipts)
        .values({
          code,
          supplier: supplier?.trim() || null,
          poNumber: poNumber?.trim() || null,
          notes: notes?.trim() || null,
          status: "received",
          createdBy: session.id,
        })
        .returning();

      const generatedBundles: {
        id: string;
        code: string;
        productId: string;
        productName: string | null;
        qtyReceived: number;
        unit: string;
      }[] = [];

      for (const line of lines) {
        const { productId, qtyPerBundle, bundleCount } = line;

        const [product] = await tx
          .select()
          .from(products)
          .where(eq(products.id, productId))
          .limit(1);

        if (!product) {
          throw new ReceiptValidationError(`Product not found: ${productId}`);
        }

        const unit = line.unit || product.baseUnit || "piece";
        const count = Number(bundleCount);

        await tx.insert(receiptLines).values({
          receiptId: receipt.id,
          productId,
          qtyPerBundle: String(qtyPerBundle),
          bundleCount: count,
          unit,
        });

        // Reserve the whole block of codes in one round-trip instead of calling
        // nextval() once per bundle — a 50-bundle receipt was 50 extra queries.
        const codes = await nextBundleCodes(count, tx);

        const bundleRows = await tx
          .insert(bundles)
          .values(
            codes.map((bundleCode) => ({
              code: bundleCode,
              productId,
              unit,
              qtyReceived: String(qtyPerBundle),
              qtyRemaining: String(qtyPerBundle),
              status: "active",
              receiptId: receipt.id,
              receivedBy: session.id,
            }))
          )
          .returning({ id: bundles.id, code: bundles.code });

        await tx.insert(movements).values(
          bundleRows.map((bundle) => ({
            clientUuid: uuidv4(),
            bundleId: bundle.id,
            productId,
            type: "receive",
            qtyDelta: String(qtyPerBundle),
            unit,
            employeeId: session.id,
            deviceTime: new Date(),
            note: `Receipt ${code}`,
          }))
        );

        for (const bundle of bundleRows) {
          generatedBundles.push({
            id: bundle.id,
            code: bundle.code,
            productId,
            productName: product.name,
            qtyReceived: Number(qtyPerBundle),
            unit,
          });
        }
      }

      return { receipt, generatedBundles };
    });

    return NextResponse.json({ receipt, bundles: generatedBundles }, { status: 201 });
  } catch (err) {
    if (err instanceof ReceiptValidationError) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    console.error("Create receipt error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
