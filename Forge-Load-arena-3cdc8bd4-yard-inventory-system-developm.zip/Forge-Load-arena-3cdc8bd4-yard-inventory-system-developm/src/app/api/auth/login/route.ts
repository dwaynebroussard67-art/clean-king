import { NextRequest, NextResponse } from "next/server";
import { db, users } from "@/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { createToken, SessionUser } from "@/lib/auth";
import { rateLimitAsync, resetRateLimitAsync, clientIp } from "@/lib/rate-limit";
import { SESSION_COOKIE } from "@/lib/tenant";
import { sessionCookieOptions } from "@/lib/session-cookie";

// Two windows: a tight per-account limit so one user can't be brute-forced,
// and a looser per-IP limit so a single host can't spray many accounts.
const PER_ACCOUNT = { limit: 5, windowMs: 15 * 60 * 1000 };
const PER_IP = { limit: 30, windowMs: 15 * 60 * 1000 };

function tooMany(retryAfter: number) {
  const minutes = Math.ceil(retryAfter / 60);
  return NextResponse.json(
    {
      error: `Too many sign-in attempts. Try again in ${minutes} minute${
        minutes === 1 ? "" : "s"
      }.`,
    },
    { status: 429, headers: { "Retry-After": String(retryAfter) } }
  );
}

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 });
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const ip = clientIp(req);

    const ipLimit = await rateLimitAsync(`login:ip:${ip}`, PER_IP);
    if (!ipLimit.ok) return tooMany(ipLimit.retryAfter);

    const accountLimit = await rateLimitAsync(`login:acct:${normalizedEmail}`, PER_ACCOUNT);
    if (!accountLimit.ok) return tooMany(accountLimit.retryAfter);

    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, normalizedEmail))
      .limit(1);

    // Compare against a dummy hash when the user doesn't exist so the response
    // time doesn't reveal which emails are registered.
    const hash =
      user?.passwordHash ??
      "$2b$12$0000000000000000000000000000000000000000000000000000";
    const valid = await bcrypt.compare(password, hash);

    if (!user || !user.active || !valid) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    await resetRateLimitAsync(`login:acct:${normalizedEmail}`);

    const sessionUser: SessionUser = {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role as "admin" | "crew",
    };
    const token = await createToken(sessionUser);

    const response = NextResponse.json({ user: sessionUser });
    response.cookies.set(SESSION_COOKIE, token, sessionCookieOptions);
    return response;
  } catch (err) {
    console.error("Login error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
