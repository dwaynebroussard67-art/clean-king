import { NextRequest, NextResponse } from "next/server";
import { db, damageReports, bundles, products, jobs, users, photos, movements } from "@/db";
import { eq, desc, sql, and } from "drizzle-orm";
import { getSession } from "@/lib/auth"
import { terms, Unit } from "@/lib/tenant";
import { isUniqueViolation } from "@/lib/db-errors";
import { v4 as uuidv4 } from "uuid";

const REASONS = new Set([
  "forklift",
  "strapping",
  "weather",
  "defect",
  "transit",
  "handling",
  "unknown",
  "other",
]);
const SEVERITIES = new Set(["minor", "major", "total"]);
const SUBJECTS = new Set(["material", "property", "equipment", "vehicle"]);
const STAGES = new Set(["receiving", "storage", "loading", "delivery", "return"]);

async function nextDamageCode(executor: {
  execute: (q: ReturnType<typeof sql>) => Promise<{ rows: unknown[] }>;
}): Promise<string> {
  const result = await executor.execute(sql`SELECT nextval('damage_code_seq') AS n`);
  const n = String((result.rows[0] as { n: string | number }).n).padStart(4, "0");
  return `DMG-${new Date().getFullYear()}-${n}`;
}

/**
 * File a damage report.
 *
 * The crew supplies: a photo (already uploaded), a reason, and optionally a
 * scanned bundle and a quantity. Everything else — who, when, where, which
 * product, which job, which customer — is derived server-side. That's the
 * entire point: point, shoot, tap a reason, done.
 */
export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      clientUuid,
      bundleId,
      productId,
      subject = "material",
      reason,
      severity = "minor",
      stage,
      qtyAffected,
      unit,
      location,
      latitude,
      longitude,
      jobId,
      notes,
      photoIds,
      writeOff = false,
      deviceId,
      deviceTime,
    } = body;

    if (!reason || !REASONS.has(reason)) {
      return NextResponse.json({ error: "Pick a reason for the damage" }, { status: 400 });
    }
    if (!SEVERITIES.has(severity)) {
      return NextResponse.json({ error: "Invalid severity" }, { status: 400 });
    }
    if (!SUBJECTS.has(subject)) {
      return NextResponse.json({ error: "Invalid subject" }, { status: 400 });
    }
    if (stage && !STAGES.has(stage)) {
      return NextResponse.json({ error: "Invalid stage" }, { status: 400 });
    }
    if (!Array.isArray(photoIds) || photoIds.length === 0) {
      return NextResponse.json(
        { error: "A photo is required — that's the evidence for the report." },
        { status: 400 }
      );
    }

    const qty = qtyAffected === undefined || qtyAffected === null || qtyAffected === ""
      ? null
      : Number(qtyAffected);
    if (qty !== null && (!Number.isFinite(qty) || qty < 0)) {
      return NextResponse.json({ error: "Quantity must be a positive number" }, { status: 400 });
    }

    const result = await db.transaction(async (tx) => {
      // Derive context from the scanned bundle so the crew never types it.
      let resolvedProductId: string | null = productId ?? null;
      let resolvedUnit: string | null = unit ?? null;
      let bundleRow: typeof bundles.$inferSelect | undefined;

      if (bundleId) {
        [bundleRow] = await tx
          .select()
          .from(bundles)
          .where(eq(bundles.id, bundleId))
          .limit(1);

        if (!bundleRow) {
          return { error: `${Unit} not found`, status: 404 as const };
        }
        resolvedProductId = bundleRow.productId;
        resolvedUnit = resolvedUnit ?? bundleRow.unit;
      }

      // Derive the customer from the job, when one was selected.
      let customerId: string | null = null;
      if (jobId) {
        const [job] = await tx
          .select({ customerId: jobs.customerId })
          .from(jobs)
          .where(eq(jobs.id, jobId))
          .limit(1);
        customerId = job?.customerId ?? null;
      }

      // Writing off damaged stock removes it from inventory, using the same
      // atomic guard as a normal pull so it can't drive the bundle negative.
      let movementId: string | null = null;
      if (writeOff && bundleRow && qty && qty > 0) {
        const [movement] = await tx
          .insert(movements)
          .values({
            clientUuid: uuidv4(),
            bundleId: bundleRow.id,
            productId: bundleRow.productId,
            type: "adjust",
            qtyDelta: String(-Math.abs(qty)),
            unit: resolvedUnit || bundleRow.unit,
            employeeId: session.id,
            deviceTime: deviceTime ? new Date(deviceTime) : new Date(),
            deviceId: deviceId || null,
            note: `Damage write-off (${reason})`,
          })
          .returning({ id: movements.id });

        const updated = await tx
          .update(bundles)
          .set({
            qtyRemaining: sql`${bundles.qtyRemaining} - ${String(Math.abs(qty))}::numeric`,
            status: sql`CASE
              WHEN ${bundles.qtyRemaining} - ${String(Math.abs(qty))}::numeric <= 0 THEN 'retired'
              ELSE ${bundles.status} END`,
          })
          .where(
            sql`${bundles.id} = ${bundleRow.id}
                AND ${bundles.qtyRemaining} - ${String(Math.abs(qty))}::numeric >= 0`
          )
          .returning({ id: bundles.id });

        if (updated.length === 0) {
          return {
            error: `Can't write off ${qty} — the ${terms.unit} only has ${bundleRow.qtyRemaining} left.`,
            status: 409 as const,
          };
        }
        movementId = movement.id;
      }

      const code = await nextDamageCode(tx);

      const [report] = await tx
        .insert(damageReports)
        .values({
          code,
          clientUuid: clientUuid || null,
          bundleId: bundleRow?.id ?? null,
          productId: resolvedProductId,
          subject,
          reason,
          severity,
          stage: stage || null,
          qtyAffected: qty === null ? null : String(qty),
          unit: resolvedUnit,
          location: location?.trim() || null,
          latitude: typeof latitude === "number" ? latitude : null,
          longitude: typeof longitude === "number" ? longitude : null,
          jobId: jobId || null,
          customerId,
          movementId,
          writeOff: Boolean(movementId),
          notes: notes?.trim() || null,
          // WHO and WHEN are never taken from the request body.
          reportedBy: session.id,
          deviceId: deviceId || null,
          deviceTime: deviceTime ? new Date(deviceTime) : new Date(),
        })
        .returning();

      // Bind the already-uploaded photos to this report.
      for (const photoId of photoIds.slice(0, 10)) {
        await tx
          .update(photos)
          .set({ subjectType: "damage", subjectId: report.id })
          .where(eq(photos.id, photoId));
      }

      return { report, status: 201 as const };
    });

    if ("error" in result) {
      return NextResponse.json({ error: result.error }, { status: result.status });
    }

    return NextResponse.json({ report: result.report }, { status: 201 });
  } catch (err) {
    if (isUniqueViolation(err)) {
      // Offline replay of a report we already accepted.
      return NextResponse.json({ ok: true, idempotent: true });
    }
    console.error("Damage report error:", err);
    return NextResponse.json({ error: "Could not file the report" }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const parsedLimit = parseInt(searchParams.get("limit") || "50", 10);
    const limit = Math.min(Math.max(Number.isNaN(parsedLimit) ? 50 : parsedLimit, 1), 200);

    const conditions = [];
    if (status) conditions.push(eq(damageReports.status, status));

    const query = db
      .select({
        id: damageReports.id,
        code: damageReports.code,
        subject: damageReports.subject,
        reason: damageReports.reason,
        severity: damageReports.severity,
        stage: damageReports.stage,
        qtyAffected: damageReports.qtyAffected,
        unit: damageReports.unit,
        location: damageReports.location,
        latitude: damageReports.latitude,
        longitude: damageReports.longitude,
        notes: damageReports.notes,
        status: damageReports.status,
        writeOff: damageReports.writeOff,
        createdAt: damageReports.createdAt,
        deviceTime: damageReports.deviceTime,
        bundleCode: bundles.code,
        productName: products.name,
        productSku: products.sku,
        jobCode: jobs.code,
        reportedByName: users.fullName,
        photoId: sql<string | null>`(
          SELECT p.id FROM photos p
          WHERE p.subject_type = 'damage' AND p.subject_id = ${damageReports.id}
          ORDER BY p.created_at LIMIT 1
        )`,
        photoCount: sql<number>`(
          SELECT COUNT(*)::int FROM photos p
          WHERE p.subject_type = 'damage' AND p.subject_id = ${damageReports.id}
        )`,
      })
      .from(damageReports)
      .leftJoin(bundles, eq(damageReports.bundleId, bundles.id))
      .leftJoin(products, eq(damageReports.productId, products.id))
      .leftJoin(jobs, eq(damageReports.jobId, jobs.id))
      .leftJoin(users, eq(damageReports.reportedBy, users.id))
      .$dynamic();

    const rows = await (conditions.length ? query.where(and(...conditions)) : query)
      .orderBy(desc(damageReports.createdAt))
      .limit(limit);

    return NextResponse.json({ reports: rows });
  } catch (err) {
    console.error("Get damage reports error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
