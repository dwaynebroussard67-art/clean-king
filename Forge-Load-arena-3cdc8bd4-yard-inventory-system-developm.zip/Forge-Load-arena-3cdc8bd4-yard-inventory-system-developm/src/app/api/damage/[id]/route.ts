import { NextRequest, NextResponse } from "next/server";
import { db, damageReports, photos } from "@/db";
import { and, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const STATUSES = new Set(["open", "reviewed", "resolved", "written_off"]);

/** One report with every photo attached — the view used to settle a claim. */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const byCode = !UUID_RE.test(id);

    const [report] = await db
      .select()
      .from(damageReports)
      .where(byCode ? eq(damageReports.code, id.toUpperCase()) : eq(damageReports.id, id))
      .limit(1);

    if (!report) {
      return NextResponse.json({ error: "Damage report not found" }, { status: 404 });
    }

    const evidence = await db
      .select({
        id: photos.id,
        caption: photos.caption,
        latitude: photos.latitude,
        longitude: photos.longitude,
        deviceTime: photos.deviceTime,
        createdAt: photos.createdAt,
      })
      .from(photos)
      .where(and(eq(photos.subjectType, "damage"), eq(photos.subjectId, report.id)))
      .orderBy(photos.createdAt);

    return NextResponse.json({ report, photos: evidence });
  } catch (err) {
    console.error("Get damage report error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

/**
 * Review a report. Only the status and reviewer notes can change — the facts
 * the crew captured (who, what, when, where, why) are the evidence and stay
 * exactly as filed.
 */
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    const { id } = await params;
    if (!UUID_RE.test(id)) {
      return NextResponse.json({ error: "Damage report not found" }, { status: 404 });
    }

    const { status } = await req.json();
    if (!STATUSES.has(status)) {
      return NextResponse.json({ error: "Invalid status" }, { status: 400 });
    }

    const [updated] = await db
      .update(damageReports)
      .set({
        status,
        reviewedBy: session.id,
        reviewedAt: new Date(),
      })
      .where(eq(damageReports.id, id))
      .returning({
        id: damageReports.id,
        code: damageReports.code,
        status: damageReports.status,
        reviewedAt: damageReports.reviewedAt,
      });

    if (!updated) {
      return NextResponse.json({ error: "Damage report not found" }, { status: 404 });
    }

    return NextResponse.json({ report: updated });
  } catch (err) {
    console.error("Update damage report error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
