import { NextRequest, NextResponse } from "next/server";
import { db, bundles, products } from "@/db";
import { eq, and, desc, ilike, or } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const search = searchParams.get("search")?.trim();
    const parsedLimit = parseInt(searchParams.get("limit") || "200", 10);
    const limit = Math.min(Math.max(Number.isNaN(parsedLimit) ? 200 : parsedLimit, 1), 500);

    const conditions = [];
    if (status) {
      conditions.push(eq(bundles.status, status));
    }

    // Filter in SQL, not in JS. The previous version fetched the newest 200 rows
    // and filtered them in memory, so searching for anything older than those
    // 200 confidently reported "not found" — on a busy yard that's a few days.
    if (search) {
      const term = `%${search.replace(/[%_]/g, (c) => `\\${c}`)}%`;
      conditions.push(
        or(
          ilike(bundles.code, term),
          ilike(products.name, term),
          ilike(products.sku, term),
          ilike(bundles.location, term)
        )!
      );
    }

    const query = db
      .select({
        id: bundles.id,
        code: bundles.code,
        unit: bundles.unit,
        qtyReceived: bundles.qtyReceived,
        qtyRemaining: bundles.qtyRemaining,
        location: bundles.location,
        status: bundles.status,
        receivedAt: bundles.receivedAt,
        productId: bundles.productId,
        productName: products.name,
        productSku: products.sku,
        productCategory: products.category,
      })
      .from(bundles)
      .leftJoin(products, eq(bundles.productId, products.id))
      .$dynamic();

    const rows = await (conditions.length > 0
      ? query.where(and(...conditions))
      : query
    )
      .orderBy(desc(bundles.createdAt))
      .limit(limit);

    return NextResponse.json({ bundles: rows });
  } catch (err) {
    console.error("Get bundles error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
