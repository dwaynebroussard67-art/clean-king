import Anthropic from "@anthropic-ai/sdk";
import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { loadPhotoBytes } from "@/lib/photos";
import { tenant } from "@/lib/tenant";

/**
 * Guess an item's name and category from its photo.
 *
 * Ported from an earlier branch that had the right instinct: the crew already
 * took a photo, so making them type "6ft Cedar Privacy Picket" afterwards is
 * asking for information the picture already contains.
 *
 * This is strictly a suggestion. It pre-fills the intake form, the crew can
 * overwrite it, and nothing is saved from here. If the key is missing or the
 * model is wrong, the flow still works — it just doesn't save the typing.
 */

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const PROMPT = `This is a photo of a physical item in a ${tenant.domain} yard.
Reply with ONLY a JSON object, no prose, no markdown fences:
{ "name": string, "category": string|null }
"name" should be a short, specific product name a yard worker would recognise
(e.g. "6ft Cedar Privacy Picket", "55gal Steel Drum").
"category" should be one short word or phrase (e.g. "Fencing", "Drums") or null if unclear.`;

export async function POST(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "admin") {
      return NextResponse.json({ error: "Admin only" }, { status: 403 });
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      // Not an error the crew needs to see — the form just stays blank.
      return NextResponse.json({ error: "AI not configured" }, { status: 503 });
    }

    const { photoId } = await req.json();
    if (!photoId || typeof photoId !== "string") {
      return NextResponse.json({ error: "photoId is required" }, { status: 400 });
    }

    const photo = await loadPhotoBytes(photoId);
    if (!photo) {
      return NextResponse.json({ error: "Photo not found" }, { status: 404 });
    }

    const res = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 200,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: {
                type: "base64",
                media_type: photo.contentType as
                  | "image/jpeg"
                  | "image/png"
                  | "image/webp",
                data: Buffer.from(photo.data).toString("base64"),
              },
            },
            { type: "text", text: PROMPT },
          ],
        },
      ],
    });

    const raw = res.content
      .filter((b): b is Anthropic.TextBlock => b.type === "text")
      .map((b) => b.text)
      .join("");

    // The model occasionally wraps JSON in fences despite being told not to.
    let parsed: { name?: unknown; category?: unknown };
    try {
      parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {
      return NextResponse.json({ name: "", category: null });
    }

    return NextResponse.json({
      name: String(parsed.name || "").trim().slice(0, 120),
      category: parsed.category ? String(parsed.category).trim().slice(0, 60) : null,
    });
  } catch (err) {
    console.error("Vision identify error:", err);
    // A guess failing must never block intake.
    return NextResponse.json({ name: "", category: null });
  }
}
