"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { NavBar } from "@/components/NavBar";
import { useAuth } from "@/hooks/useAuth";
import {
  getRejectedMovements,
  getRejectedDamage,
  discardMovement,
  discardDamage,
  syncQueue,
  syncDamageQueue,
  getPendingMovements,
  getPendingDamage,
  type QueuedMovement,
  type QueuedDamage,
} from "@/lib/offline-queue";
import { tenant, terms, capitalize, measureLabel, withArticle } from "@/lib/tenant";

/**
 * The queue review screen.
 *
 * Everything here is work a crew member already did in the yard that the
 * server wouldn't take. Without somewhere to see it, a rejected movement is
 * just silently missing stock -- the count on screen disagrees with the count
 * on the ground and nobody knows why. This is the "why".
 *
 * Deliberately blunt about the fact that discarding does not fix inventory.
 */
export default function QueuePage() {
  const router = useRouter();
  const { user, loading } = useAuth();

  const [rejected, setRejected] = useState<QueuedMovement[]>([]);
  const [rejectedDamage, setRejectedDamage] = useState<QueuedDamage[]>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [user, loading, router]);

  const load = useCallback(async () => {
    try {
      const [rm, rd, pm, pd] = await Promise.all([
        getRejectedMovements(),
        getRejectedDamage(),
        getPendingMovements(),
        getPendingDamage(),
      ]);
      setRejected(rm);
      setRejectedDamage(rd);
      setPendingCount(pm.length + pd.length);
    } catch {}
  }, []);

  useEffect(() => {
    if (!user) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void load();
  }, [user, load]);

  const retryAll = async () => {
    setBusy(true);
    try {
      await syncQueue();
      await syncDamageQueue();
      await load();
    } finally {
      setBusy(false);
    }
  };

  const dropMovement = async (clientUuid: string) => {
    await discardMovement(clientUuid);
    await load();
  };

  const dropDamage = async (clientUuid: string) => {
    await discardDamage(clientUuid);
    await load();
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  const nothingWrong = rejected.length === 0 && rejectedDamage.length === 0;

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />
      <main className="max-w-2xl mx-auto px-4 py-6 pb-24 sm:pb-6">
        <h1 className="text-2xl font-bold text-white mb-1">Sync queue</h1>
        <p className="text-slate-400 text-sm mb-6">
          Work saved on this phone that the yard hasn&rsquo;t accepted.
        </p>

        {pendingCount > 0 && (
          <div className="bg-accent-500/10 border border-accent-500/30 rounded-2xl px-4 py-3 mb-4 flex items-center gap-3">
            <span className="text-accent-400 text-lg">↑</span>
            <p className="text-accent-300 text-sm flex-1">
              {pendingCount} item{pendingCount === 1 ? "" : "s"} still waiting to send.
            </p>
            <button
              onClick={retryAll}
              disabled={busy}
              className="bg-accent-500 hover:bg-accent-600 text-white text-xs font-bold px-3 py-2 rounded-lg disabled:opacity-50"
            >
              {busy ? "Sending…" : "Send now"}
            </button>
          </div>
        )}

        {nothingWrong ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center">
            <div className="text-5xl mb-3">✅</div>
            <p className="text-white font-semibold mb-1">Nothing stuck</p>
            <p className="text-slate-400 text-sm">
              Everything you&rsquo;ve recorded made it to the yard.
            </p>
          </div>
        ) : (
          <>
            <div className="bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3 mb-4">
              <p className="text-red-300 text-sm font-semibold mb-1">
                These were refused and won&rsquo;t be retried
              </p>
              <p className="text-red-400/80 text-xs">
                Discarding one only clears it from this phone. If the stock really moved,
                re-scan the {terms.unit} and record it again so the count matches the ground.
              </p>
            </div>

            {rejected.map((m) => (
              <div
                key={m.clientUuid}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-white font-semibold text-sm">
                      {m.type} · {Math.abs(Number(m.qtyDelta))} {measureLabel(m.unit)}
                    </p>
                    <p className="text-slate-500 text-xs mt-0.5 font-mono truncate">
                      {capitalize(terms.unit)} {m.bundleId.slice(0, 8)}
                    </p>
                    <p className="text-red-400 text-xs mt-1.5">{m.errorMessage}</p>
                    <p className="text-slate-500 text-xs mt-1">
                      Recorded {new Date(m.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => dropMovement(m.clientUuid)}
                    className="shrink-0 bg-slate-800 hover:bg-red-500/20 hover:text-red-300 text-slate-300 text-xs px-3 py-2 rounded-lg"
                  >
                    Discard
                  </button>
                </div>
              </div>
            ))}

            {rejectedDamage.map((d) => (
              <div
                key={d.clientUuid}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-white font-semibold text-sm">
                      Damage report · {String(d.payload.reason ?? "unknown")}
                    </p>
                    <p className="text-slate-500 text-xs mt-0.5">
                      {d.photos.length} photo{d.photos.length === 1 ? "" : "s"} held on this phone
                    </p>
                    <p className="text-red-400 text-xs mt-1.5">{d.errorMessage}</p>
                    <p className="text-slate-500 text-xs mt-1">
                      Recorded {new Date(d.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => dropDamage(d.clientUuid)}
                    className="shrink-0 bg-slate-800 hover:bg-red-500/20 hover:text-red-300 text-slate-300 text-xs px-3 py-2 rounded-lg"
                  >
                    Discard
                  </button>
                </div>
              </div>
            ))}
          </>
        )}

        <Link
          href="/scan"
          className="block w-full bg-accent-500 hover:bg-accent-600 text-white font-bold py-4 rounded-xl text-center mt-6"
        >
          📷 Scan {withArticle(terms.unit)}
        </Link>
      </main>
    </div>
  );
}
