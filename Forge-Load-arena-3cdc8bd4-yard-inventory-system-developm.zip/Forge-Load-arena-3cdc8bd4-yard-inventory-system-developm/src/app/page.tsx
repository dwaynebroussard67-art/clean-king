"use client";

import { useEffect, useState, useCallback, useSyncExternalStore } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/hooks/useAuth";
import { NavBar } from "@/components/NavBar";
import {
  getPendingCount,
  getRejectedCount,
  syncQueue,
  getPendingDamageCount,
  syncDamageQueue,
} from "@/lib/offline-queue";
import { tenant, UnitPlural, Unit, terms } from "@/lib/tenant";
import { useShift } from "@/hooks/useShift";
import { formatDuration } from "@/lib/fleet";

interface RecentMovement {
  id: string;
  type: string;
  qtyDelta: string;
  unit: string;
  serverTime: string;
  bundleCode: string | null;
  productName: string | null;
}

/**
 * Subscribe to connectivity instead of mirroring it into state from an effect.
 * navigator.onLine is only a link-layer signal — it says nothing about whether
 * the server is actually reachable — so the sync retry loop below runs on a
 * timer regardless.
 */
function useOnlineStatus(): boolean {
  return useSyncExternalStore(
    (onChange) => {
      window.addEventListener("online", onChange);
      window.addEventListener("offline", onChange);
      return () => {
        window.removeEventListener("online", onChange);
        window.removeEventListener("offline", onChange);
      };
    },
    () => navigator.onLine,
    () => true // assume online during SSR
  );
}

export default function HomePage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [pendingCount, setPendingCount] = useState(0);
  const [rejectedCount, setRejectedCount] = useState(0);
  const isOnline = useOnlineStatus();
  const [syncing, setSyncing] = useState(false);
  const [recentMovements, setRecentMovements] = useState<RecentMovement[]>([]);
  const [lowStockCount, setLowStockCount] = useState(0);
  const [pendingDamageCount, setPendingDamageCount] = useState(0);
  const [totalProducts, setTotalProducts] = useState(0);
  const [activeBundles, setActiveBundles] = useState(0);
  // The crew member's own shift; also resumes GPS tracking after a reload.
  const { shift, tracker, loading: shiftLoading } = useShift();
  const [onClockCount, setOnClockCount] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/login");
    }
  }, [user, loading, router]);

  const checkPending = useCallback(async () => {
    try {
      const [pending, rejected, pendingDamage] = await Promise.all([
        getPendingCount(),
        getRejectedCount(),
        getPendingDamageCount(),
      ]);
      setPendingCount(pending);
      setRejectedCount(rejected);
      setPendingDamageCount(pendingDamage);
    } catch {}
  }, []);

  const doSync = useCallback(async () => {
    if (!user || !isOnline || syncing) return;
    setSyncing(true);
    try {
      // Movements first: they're small and they're what the stock counts
      // depend on. Damage reports carry photos and can take a while on a
      // weak signal, so they shouldn't hold up inventory accuracy.
      await syncQueue();
      await syncDamageQueue();
      await checkPending();
    } finally {
      setSyncing(false);
    }
  }, [user, isOnline, syncing, checkPending]);

  useEffect(() => {
    if (!user) return;

    // Reading IndexedDB is genuinely asynchronous, so the setState lands on a
    // later tick rather than cascading during this render. The rule can't see
    // through the useCallback wrapper (the plain fetch().then() calls in the
    // effect below are the same pattern and aren't flagged).
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void checkPending();

    const handleOnline = () => void doSync();
    window.addEventListener("online", handleOnline);

    // Retry the queue periodically: the yard has spots where the radio says
    // "online" but nothing actually gets through.
    const interval = setInterval(() => {
      if (navigator.onLine) void doSync();
    }, 30000);

    return () => {
      window.removeEventListener("online", handleOnline);
      clearInterval(interval);
    };
  }, [user, checkPending, doSync]);

  useEffect(() => {
    if (!user) return;
    // Fetch recent movements
    fetch("/api/movements?limit=5")
      .then((r) => r.json())
      .then((d) => setRecentMovements(d.movements || []))
      .catch(() => {});

    if (user.role === "admin") {
      fetch("/api/shifts?active=1")
        .then((r) => r.json())
        .then((d) => setOnClockCount((d.shifts || []).length))
        .catch(() => {});
    }

    // Fetch inventory stats
    // Counts only — the dashboard shows three numbers and has no use for the
    // rows themselves.
    fetch("/api/inventory?summary=1")
      .then((r) => r.json())
      .then((d) => {
        setLowStockCount(d.lowStockCount || 0);
        setTotalProducts(d.totalProducts || 0);
        setActiveBundles(d.activeBundles || 0);
      })
      .catch(() => {});
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-accent-500 text-4xl animate-pulse">{tenant.mark}</div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-950">
      <NavBar />

      <main className="max-w-5xl mx-auto px-4 py-6 pb-24 sm:pb-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">
              Hey, {user.fullName.split(" ")[0]} 👋
            </h1>
            <p className="text-slate-400 text-sm mt-1">
              {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
            </p>
          </div>

          {/* Online/Offline + sync */}
          <div className="flex items-center gap-2">
            {pendingCount + pendingDamageCount > 0 && (
              <button
                onClick={doSync}
                disabled={syncing || !isOnline}
                className="flex items-center gap-1.5 bg-accent-500/20 border border-accent-500/40 text-accent-400 text-xs px-3 py-1.5 rounded-full hover:bg-accent-500/30 transition-colors disabled:opacity-50"
              >
                {syncing ? (
                  <span className="animate-spin">↻</span>
                ) : (
                  <span>↑</span>
                )}
                {pendingCount + pendingDamageCount} pending
              </button>
            )}
            <div className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full ${
              isOnline ? "bg-green-500/10 text-green-400" : "bg-red-500/10 text-red-400"
            }`}>
              <span className={`w-2 h-2 rounded-full ${isOnline ? "bg-green-400" : "bg-red-400"}`} />
              {isOnline ? "Online" : "Offline"}
            </div>
          </div>
        </div>

        {/* Movements the yard refused — these need a human, so they can't be
            left to rot silently in the queue. */}
        {rejectedCount > 0 && (
          <Link
            href="/queue"
            className="bg-red-500/10 border border-red-500/30 rounded-2xl px-4 py-3 mb-4 flex items-start gap-3 hover:bg-red-500/15 transition-colors"
          >
            <span className="text-red-400 text-lg leading-none mt-0.5">⚠</span>
            <div className="flex-1 min-w-0">
              <p className="text-red-300 text-sm font-semibold">
                {rejectedCount} movement{rejectedCount === 1 ? "" : "s"} couldn&rsquo;t be saved
              </p>
              <p className="text-red-400/80 text-xs mt-0.5">
                Usually means the {terms.unit} ran out or was retired while you were offline.
                Tap to review what the yard refused.
              </p>
            </div>
            <span className="text-red-400 text-lg leading-none mt-0.5">›</span>
          </Link>
        )}

        {/* Shift: the first thing on the screen, because it's the first thing
            in the day. Not clocked in -> one big button. Clocked in -> the
            running clock and whether the phone is reporting. */}
        {!shiftLoading && !shift && (
          <Link
            href="/clock-in"
            className="block w-full bg-accent-500 hover:bg-accent-600 active:scale-95 text-white font-bold text-xl rounded-2xl py-8 text-center transition-all shadow-lg shadow-accent-500/20 mb-3"
          >
            <div className="text-4xl mb-2">🕒</div>
            Scan to clock in
          </Link>
        )}
        {shift && (
          <Link
            href="/clock-in"
            className="block w-full bg-slate-900 border border-green-500/30 rounded-2xl px-5 py-4 mb-3 hover:border-green-500/50 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-green-400 uppercase tracking-wide">On the clock</div>
                <div className="text-2xl font-bold text-white tabular-nums mt-0.5">
                  {formatDuration(now - Date.parse(shift.clockInAt))}
                </div>
                <div className="text-slate-400 text-xs mt-0.5">
                  since {new Date(shift.clockInAt).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}
                  {shift.siteName ? ` · ${shift.siteName}` : ""}
                </div>
              </div>
              <div className="text-right">
                <div className={`flex items-center gap-1.5 text-xs justify-end ${tracker.running && tracker.permission === "granted" ? "text-green-400" : "text-amber-400"}`}>
                  <span className={`w-2 h-2 rounded-full ${tracker.running && tracker.permission === "granted" ? "bg-green-400 animate-pulse" : "bg-amber-400"}`} />
                  {tracker.running && tracker.permission === "granted" ? "GPS on" : "GPS off"}
                </div>
                <div className="text-slate-500 text-[11px] mt-1">tap for today&rsquo;s orders</div>
              </div>
            </div>
          </Link>
        )}

        {user.role === "admin" && onClockCount !== null && (
          <Link
            href="/admin?tab=crew"
            className="flex items-center justify-between bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl px-5 py-3 mb-6 transition-colors"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">📍</span>
              <div>
                <div className="text-white font-semibold text-sm">
                  {onClockCount === 0 ? "Nobody on the clock" : `${onClockCount} on the clock right now`}
                </div>
                <div className="text-slate-400 text-xs">See where the trucks are</div>
              </div>
            </div>
            <span className="text-slate-500">›</span>
          </Link>
        )}

        {/* Scan */}
        <Link
          href="/scan"
          className="block w-full bg-slate-900 border border-slate-800 hover:border-slate-700 text-white py-5 font-bold text-lg rounded-2xl text-center transition-all mb-6"
        >
          <span className="text-2xl mr-2 align-middle">📷</span>
          <span className="align-middle">Scan {Unit}</span>
        </Link>

        {/* Stats grid */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white">{totalProducts}</div>
            <div className="text-xs text-slate-400 mt-1">Products</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white">{activeBundles}</div>
            <div className="text-xs text-slate-400 mt-1">{UnitPlural}</div>
          </div>
          <div className={`border rounded-xl p-4 text-center ${
            lowStockCount > 0
              ? "bg-red-500/10 border-red-500/30"
              : "bg-slate-900 border-slate-800"
          }`}>
            <div className={`text-2xl font-bold ${lowStockCount > 0 ? "text-red-400" : "text-white"}`}>
              {lowStockCount}
            </div>
            <div className={`text-xs mt-1 ${lowStockCount > 0 ? "text-red-400" : "text-slate-400"}`}>
              Low Stock
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Link
            href="/truck-check"
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-center gap-3 transition-colors"
          >
            <span className="text-2xl">🛻</span>
            <div>
              <div className="font-semibold text-white text-sm">Morning truck check</div>
              <div className="text-xs text-slate-400">Oil, brakes, lights, once-over</div>
            </div>
          </Link>
          {user.role === "admin" && (
            <Link
              href="/admin?tab=orders"
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-center gap-3 transition-colors"
            >
              <span className="text-2xl">📝</span>
              <div>
                <div className="font-semibold text-white text-sm">Tomorrow&rsquo;s orders</div>
                <div className="text-xs text-slate-400">Delivered at clock-in</div>
              </div>
            </Link>
          )}
          {user.role === "admin" && (
            <Link
              href="/receiving"
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-center gap-3 transition-colors"
            >
              <span className="text-2xl">📦</span>
              <div>
                <div className="font-semibold text-white text-sm">Receive Stock</div>
                <div className="text-xs text-slate-400">Create receipt + labels</div>
              </div>
            </Link>
          )}
          <Link
            href="/jobs"
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-center gap-3 transition-colors"
          >
            <span className="text-2xl">📋</span>
            <div>
              <div className="font-semibold text-white text-sm">Jobs</div>
              <div className="text-xs text-slate-400">View packing lists</div>
            </div>
          </Link>
          {user.role === "admin" && (
            <Link
              href="/admin"
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl p-4 flex items-center gap-3 transition-colors"
            >
              <span className="text-2xl">⚙️</span>
              <div>
                <div className="font-semibold text-white text-sm">Admin</div>
                <div className="text-xs text-slate-400">Products, users, reports</div>
              </div>
            </Link>
          )}
        </div>

        {/* Recent activity */}
        {recentMovements.length > 0 && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800">
              <h2 className="font-semibold text-white text-sm">Recent Activity</h2>
            </div>
            <div className="divide-y divide-slate-800">
              {recentMovements.map((m) => (
                <div key={m.id} className="px-4 py-3 flex items-center justify-between">
                  <div>
                    <div className="text-sm text-white font-medium">
                      {m.productName || "Unknown"}
                    </div>
                    <div className="text-xs text-slate-400">
                      {m.bundleCode} · {m.type}
                    </div>
                  </div>
                  <div className={`text-sm font-semibold ${
                    Number(m.qtyDelta) < 0 ? "text-red-400" : "text-green-400"
                  }`}>
                    {Number(m.qtyDelta) > 0 ? "+" : ""}{m.qtyDelta} {m.unit}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
