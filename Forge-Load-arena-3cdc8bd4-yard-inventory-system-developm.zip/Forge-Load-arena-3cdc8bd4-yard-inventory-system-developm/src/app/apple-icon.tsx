import { ImageResponse } from "next/og";
import { tenant } from "@/lib/tenant";

/**
 * iOS home-screen icon. Same generation as icon.tsx, but iOS masks corners
 * itself and shows the icon larger, so this one is square-filled and sized to
 * the 180px Apple expects.
 */
export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#0f172a",
          // No border radius: iOS applies its own mask, and rounding it here
          // leaves dark corners inside the mask.
          borderBottom: `12px solid ${tenant.theme.accentHex}`,
          fontSize: 88,
          fontWeight: 700,
          color: "#f8fafc",
          letterSpacing: -2,
        }}
      >
        {tenant.monogram}
      </div>
    ),
    size
  );
}
