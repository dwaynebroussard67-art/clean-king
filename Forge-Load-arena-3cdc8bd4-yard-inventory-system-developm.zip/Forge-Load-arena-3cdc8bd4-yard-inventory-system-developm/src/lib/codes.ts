import { db } from "@/db";
import { sql } from "drizzle-orm";
import { tenant } from "@/lib/tenant";

/**
 * Human-readable code generation, backed by Postgres sequences.
 *
 * The sequences (bundle_code_seq, job_code_seq, receipt_code_seq) are created by
 * the initial migration. They used to be created as a side effect of the public
 * /api/setup route, which meant any deploy that never called it would throw here
 * on the very first bundle.
 */

/** Anything with a .execute() — the root db or a transaction handle. */
type Executor = Pick<typeof db, "execute">;

async function nextval(seq: string, executor: Executor): Promise<number> {
  const result = await executor.execute(sql`SELECT nextval(${seq}) AS n`);
  return Number((result.rows[0] as { n: string | number }).n);
}

/**
 * Reserve `count` sequence values in a single round-trip.
 * Sequences are transaction-safe and never reuse values, so the block is ours
 * even if the surrounding transaction later rolls back (we just lose the range).
 */
async function nextvals(
  seq: string,
  count: number,
  executor: Executor
): Promise<number[]> {
  const result = await executor.execute(
    sql`SELECT nextval(${seq}) AS n FROM generate_series(1, ${count})`
  );
  return result.rows.map((row) => Number((row as { n: string | number }).n));
}

const pad = (n: number, width: number) => String(n).padStart(width, "0");

/**
 * Bundle/item code prefix.
 *
 * The sequence `bundle_code_seq` is storage — the prefix is the only visible
 * part, so it must read as the customer's stock (BND- for Forge Load, ITM-
 * for furniture, KIT- for Clean King's kits). It comes from the tenant
 * config so a new customer is still a config change, not a code edit.
 * part, so it must read as the customer's stock (BND- for Forge Load, ITM-
 * for furniture, KIT- for Clean King's kits). It comes from the tenant
 * config so a new customer is still a config change, not a code edit.
 */
function bundlePrefix(): string {
  return tenant.codePrefix;
}

export async function nextBundleCode(executor: Executor = db): Promise<string> {
  const n = await nextval("bundle_code_seq", executor);
  return `${bundlePrefix()}-${new Date().getFullYear()}-${pad(n, 6)}`;
}

/** Batch variant used when receiving, where one receipt can mint many bundles. */
export async function nextBundleCodes(
  count: number,
  executor: Executor = db
): Promise<string[]> {
  if (count <= 0) return [];
  const year = new Date().getFullYear();
  const values = await nextvals("bundle_code_seq", count, executor);
  const prefix = bundlePrefix();
  return values.map((n) => `${prefix}-${year}-${pad(n, 6)}`);
}

export async function nextJobCode(executor: Executor = db): Promise<string> {
  const n = await nextval("job_code_seq", executor);
  return `JOB-${new Date().getFullYear()}-${pad(n, 4)}`;
}

export async function nextReceiptCode(executor: Executor = db): Promise<string> {
  const n = await nextval("receipt_code_seq", executor);
  return `RCP-${new Date().getFullYear()}-${pad(n, 4)}`;
}
