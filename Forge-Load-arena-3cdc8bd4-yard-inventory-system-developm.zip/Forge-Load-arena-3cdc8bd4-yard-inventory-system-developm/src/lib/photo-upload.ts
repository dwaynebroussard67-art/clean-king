"use client";

import type { CapturedPhoto, CaptureGeo } from "@/lib/camera";
import { generateDeviceId } from "@/lib/offline-queue";

/**
 * Upload a captured photo and return its stored id.
 *
 * Kept separate from the camera component so every feature (new product,
 * damage, bundle condition) uploads the same way and records the same
 * provenance without repeating itself.
 */
export async function uploadPhoto(
  photo: CapturedPhoto,
  opts: {
    subjectType: "product" | "bundle" | "damage" | "delivery" | "load";
    subjectId?: string | null;
    geo?: CaptureGeo | null;
    caption?: string | null;
  }
): Promise<string> {
  const form = new FormData();
  form.append("file", photo.blob, "photo.jpg");
  form.append("subjectType", opts.subjectType);
  if (opts.subjectId) form.append("subjectId", opts.subjectId);
  form.append("width", String(photo.width));
  form.append("height", String(photo.height));
  form.append("deviceId", generateDeviceId());
  form.append("deviceTime", new Date().toISOString());
  if (opts.caption) form.append("caption", opts.caption);

  if (opts.geo?.latitude != null) {
    form.append("latitude", String(opts.geo.latitude));
    form.append("longitude", String(opts.geo.longitude));
    if (opts.geo.accuracyM != null) form.append("accuracyM", String(opts.geo.accuracyM));
  }

  const res = await fetch("/api/photos", { method: "POST", body: form });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}) as { error?: string });
    throw new Error(body.error || "Photo upload failed");
  }

  const { photo: stored } = await res.json();
  return stored.id as string;
}

export async function uploadPhotos(
  items: CapturedPhoto[],
  opts: Parameters<typeof uploadPhoto>[1]
): Promise<string[]> {
  // Sequential on purpose: several parallel multipart uploads on a weak yard
  // connection tend to time each other out.
  const ids: string[] = [];
  for (const photo of items) {
    ids.push(await uploadPhoto(photo, opts));
  }
  return ids;
}
