/**
 * Pure validation helpers for photo uploads.
 *
 * Deliberately free of any database import: these rules are what the upload
 * route rejects on, and they should be testable (and reusable) without a live
 * connection string. `src/lib/photos.ts` re-exports them so callers still have
 * one obvious place to look.
 */

/** Hard ceiling on a stored image. Must match the `photos_byte_size_sane` CHECK. */
export const MAX_PHOTO_BYTES = 12 * 1024 * 1024;

export const ALLOWED_CONTENT_TYPES: ReadonlySet<string> = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
]);

export type PhotoSubject =
  | "product"
  | "bundle"
  | "damage"
  | "delivery"
  /** Loaded onto the customer's truck in the yard — the common case. */
  | "load";

/** Must match the `photos_subject_type_valid` CHECK. */
export const PHOTO_SUBJECTS: ReadonlySet<string> = new Set([
  "product",
  "bundle",
  "damage",
  "delivery",
  "load",
]);

/**
 * Verify the bytes actually are the image type claimed. A client could send any
 * content-type header; sniffing the magic numbers keeps us from storing (and
 * later serving) something unexpected.
 */
export function sniffImageType(buf: Buffer): string | null {
  // Each signature checks its own length. A single `< 12` gate up front would
  // also reject a valid 8-byte JPEG/PNG header, which matters because the
  // route treats "unrecognised" as a hard 415.

  // JPEG: FF D8 FF
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return "image/jpeg";
  }

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buf.length >= 8 &&
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a
  ) {
    return "image/png";
  }

  // WEBP: "RIFF" .... "WEBP"
  if (
    buf.length >= 12 &&
    buf.toString("ascii", 0, 4) === "RIFF" &&
    buf.toString("ascii", 8, 12) === "WEBP"
  ) {
    return "image/webp";
  }

  return null;
}

/** Parse a numeric form field that may be absent or empty. */
export function optionalNumber(value: FormDataEntryValue | null): number | null {
  if (value === null) return null;
  const str = String(value).trim();
  if (!str) return null;
  const n = Number(str);
  return Number.isFinite(n) ? n : null;
}
