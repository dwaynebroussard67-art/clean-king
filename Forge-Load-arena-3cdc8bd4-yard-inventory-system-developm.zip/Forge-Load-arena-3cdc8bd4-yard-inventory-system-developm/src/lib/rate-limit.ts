/**
 * Rate limiter for the login endpoint.
 *
 * Two backends. By default it's a fixed-window counter in module memory:
 * enough to stop credential stuffing against a single-yard deployment, with no
 * infrastructure to run. Set UPSTASH_REDIS_REST_URL and
 * UPSTASH_REDIS_REST_TOKEN and the async path shares state across instances
 * instead, which matters once the app is behind more than one server -- with
 * per-instance memory the effective limit multiplies by the instance count.
 *
 * The in-memory limiter also resets on deploy. Acceptable for one yard,
 * not for a serverless deployment that may cold-start constantly.
 */

import { redisConfigured, incrementWindow, clearWindow } from "./rate-limit-redis";

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

// Bound the map so a flood of unique keys can't grow it without limit.
const MAX_TRACKED_KEYS = 10_000;

function sweep(now: number) {
  if (buckets.size < MAX_TRACKED_KEYS) return;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
  // Still oversized (all windows live) — drop the oldest entries.
  if (buckets.size >= MAX_TRACKED_KEYS) {
    const excess = buckets.size - MAX_TRACKED_KEYS + 1;
    let removed = 0;
    for (const key of buckets.keys()) {
      buckets.delete(key);
      if (++removed >= excess) break;
    }
  }
}

export interface RateLimitResult {
  ok: boolean;
  remaining: number;
  /** Seconds until the window resets. */
  retryAfter: number;
}

export function rateLimit(
  key: string,
  { limit, windowMs }: { limit: number; windowMs: number }
): RateLimitResult {
  const now = Date.now();
  sweep(now);

  const existing = buckets.get(key);

  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: limit - 1, retryAfter: 0 };
  }

  existing.count += 1;
  const retryAfter = Math.max(1, Math.ceil((existing.resetAt - now) / 1000));

  if (existing.count > limit) {
    return { ok: false, remaining: 0, retryAfter };
  }

  return { ok: true, remaining: limit - existing.count, retryAfter };
}

/** Clear a bucket after a successful login, so one typo doesn't linger. */
export function resetRateLimit(key: string): void {
  buckets.delete(key);
}

/**
 * Shared-state rate limit when Redis is configured, in-memory otherwise.
 *
 * If Redis is configured but unreachable, this falls back to the in-memory
 * limiter rather than failing the request. A rate limiter that hard-fails
 * takes down login for the whole yard when the cache has a bad minute, which
 * is a worse outcome than briefly limiting per instance.
 */
export async function rateLimitAsync(
  key: string,
  { limit, windowMs }: { limit: number; windowMs: number }
): Promise<RateLimitResult> {
  if (!redisConfigured()) return rateLimit(key, { limit, windowMs });

  try {
    const { count, ttl } = await incrementWindow(key, windowMs);
    const retryAfter = Math.max(1, ttl);
    if (count > limit) return { ok: false, remaining: 0, retryAfter };
    return { ok: true, remaining: Math.max(0, limit - count), retryAfter: 0 };
  } catch (err) {
    console.error("[rate-limit] Redis unavailable, falling back to memory:", err);
    return rateLimit(key, { limit, windowMs });
  }
}

/** Clear a bucket in whichever backend is active. */
export async function resetRateLimitAsync(key: string): Promise<void> {
  resetRateLimit(key);
  if (!redisConfigured()) return;
  try {
    await clearWindow(key);
  } catch {
    // The window expires on its own; a failed reset just means the next login
    // attempt still counts against it.
  }
}

/**
 * Best-effort client IP. Behind Vercel/Fly/nginx the socket address is the
 * proxy, so prefer the forwarding headers.
 */
export function clientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return (
    req.headers.get("x-real-ip") ||
    req.headers.get("cf-connecting-ip") ||
    "unknown"
  );
}
