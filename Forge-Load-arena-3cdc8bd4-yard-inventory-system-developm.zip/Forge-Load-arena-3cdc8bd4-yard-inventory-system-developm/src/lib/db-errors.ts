/**
 * Postgres error helpers.
 *
 * These used to be string matches like `err.message.includes("unique")`, which
 * worked by accident with the current driver's message format and would turn
 * every duplicate key into an opaque 500 the moment that wording changed.
 * Checking SQLSTATE codes is stable across driver versions.
 */

/** https://www.postgresql.org/docs/current/errcodes-appendix.html */
export const PG_ERROR = {
  UNIQUE_VIOLATION: "23505",
  FOREIGN_KEY_VIOLATION: "23503",
  NOT_NULL_VIOLATION: "23502",
  CHECK_VIOLATION: "23514",
} as const;

function errorCode(err: unknown): string | undefined {
  if (typeof err !== "object" || err === null) return undefined;

  // node-postgres puts `code` on the error; drizzle sometimes wraps it in `cause`.
  const direct = (err as { code?: unknown }).code;
  if (typeof direct === "string") return direct;

  const cause = (err as { cause?: unknown }).cause;
  if (cause && cause !== err) return errorCode(cause);

  return undefined;
}

export function isUniqueViolation(err: unknown): boolean {
  return errorCode(err) === PG_ERROR.UNIQUE_VIOLATION;
}

export function isForeignKeyViolation(err: unknown): boolean {
  return errorCode(err) === PG_ERROR.FOREIGN_KEY_VIOLATION;
}

/** The constraint name that was violated, when the driver reports it. */
export function violatedConstraint(err: unknown): string | undefined {
  if (typeof err !== "object" || err === null) return undefined;
  const direct = (err as { constraint?: unknown }).constraint;
  if (typeof direct === "string") return direct;
  const cause = (err as { cause?: unknown }).cause;
  if (cause && cause !== err) return violatedConstraint(cause);
  return undefined;
}
