import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db, users } from "@/db";
import { eq } from "drizzle-orm";
import { SESSION_COOKIE } from "./tenant";
import { SESSION_TTL_SECONDS } from "./session-cookie";

// The signing secret must come from the environment. A hardcoded fallback would
// mean anyone who can read this source can forge an admin session, so in
// production we refuse to start without it. In development we allow an
// ephemeral random secret (sessions won't survive a restart, which is fine).
function resolveJwtSecret(): Uint8Array {
  const fromEnv = process.env.JWT_SECRET;

  if (fromEnv && fromEnv.length >= 32) {
    return new TextEncoder().encode(fromEnv);
  }

  if (process.env.NODE_ENV === "production") {
    throw new Error(
      fromEnv
        ? "JWT_SECRET must be at least 32 characters. Generate one with: openssl rand -base64 48"
        : "JWT_SECRET is required in production. Generate one with: openssl rand -base64 48"
    );
  }

  if (fromEnv) return new TextEncoder().encode(fromEnv.padEnd(32, "0"));

  console.warn(
    "[auth] JWT_SECRET is not set — using an ephemeral development secret. " +
      "Sessions will be invalidated on restart. Set JWT_SECRET in .env to persist them."
  );
  return crypto.getRandomValues(new Uint8Array(48));
}

const JWT_SECRET = resolveJwtSecret();

export interface SessionUser {
  id: string;
  email: string;
  fullName: string;
  role: "admin" | "crew";
}

export async function createToken(user: SessionUser): Promise<string> {
  return await new SignJWT({ ...user })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<SessionUser | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as SessionUser;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifyToken(token);
}

export async function requireSession(): Promise<SessionUser> {
  const session = await getSession();
  if (!session) {
    throw new Error("Unauthorized");
  }
  return session;
}

export async function requireAdmin(): Promise<SessionUser> {
  const session = await requireSession();
  if (session.role !== "admin") {
    throw new Error("Forbidden: admin only");
  }
  return session;
}

export async function getUserById(id: string) {
  const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return user;
}
