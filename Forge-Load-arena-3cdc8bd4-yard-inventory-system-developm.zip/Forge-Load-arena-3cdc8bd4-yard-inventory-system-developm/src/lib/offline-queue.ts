"use client";

import { openDB, DBSchema, IDBPDatabase } from "idb";
import { v4 as uuidv4 } from "uuid";
import { OFFLINE_DB_NAME } from "./tenant";

export interface QueuedMovement {
  clientUuid: string;
  bundleId: string;
  productId: string;
  type: "receive" | "pull" | "return" | "adjust" | "count_correction";
  qtyDelta: number;
  unit: string;
  jobId?: string;
  employeeId: string;
  deviceId: string;
  deviceTime: string;
  note?: string;
  createdAt: string;
  /**
   * pending  — waiting to be sent (or waiting for signal)
   * syncing  — in flight right now
   * synced   — accepted by the server
   * error    — transient failure, will be retried
   * rejected — server said no permanently; needs a human to look at it
   */
  syncStatus: "pending" | "syncing" | "synced" | "error" | "rejected";
  errorMessage?: string;
  retryCount: number;
}

export const MAX_RETRIES = 5;

/**
 * Statuses that mean "the server made a decision and retrying won't change it".
 * These get parked as `rejected` so the queue doesn't spin forever, and so the
 * crew can actually see what the yard disagreed about.
 *
 * 409 = the bundle didn't have enough left (someone else pulled it first).
 * 422 = bundle retired, or the movement would go negative.
 * 400/404 = malformed or the bundle/product no longer exists.
 */
export const PERMANENT_REJECTIONS = new Set([400, 404, 409, 422]);

/**
 * What to do with a queued item after the server answered.
 *
 * Pulled out as a pure function because it's the part of syncing that's easy
 * to get subtly wrong -- retrying a permanent refusal forever, or giving up on
 * a blip -- and the only part testable without a browser.
 *
 * `retryCount` is the count *before* this attempt.
 */
export function nextSyncState(
  status: number,
  retryCount: number
): "synced" | "pending" | "rejected" {
  if (status >= 200 && status < 300) return "synced";
  // Session expired: not the item's fault, so don't consume a retry.
  if (status === 401) return "pending";
  if (PERMANENT_REJECTIONS.has(status)) return "rejected";
  return retryCount + 1 >= MAX_RETRIES ? "rejected" : "pending";
}

/**
 * A damage report captured with no signal.
 *
 * Photos are held as Blobs in IndexedDB rather than uploaded, because the
 * upload is exactly what can't happen yet. This is the whole reason damage
 * needed its own queue: a movement is a few hundred bytes of JSON, but a
 * damage report is worthless without its evidence, so the bytes have to
 * survive in the browser until there's signal to send them.
 */
export interface QueuedDamage {
  clientUuid: string;
  /** Same shape the /api/damage route accepts, minus photoIds. */
  payload: Record<string, unknown>;
  photos: Blob[];
  createdAt: string;
  syncStatus: "pending" | "syncing" | "synced" | "error" | "rejected";
  errorMessage?: string;
  retryCount: number;
}

interface OfflineDB extends DBSchema {
  movementQueue: {
    key: string;
    value: QueuedMovement;
    indexes: { "by-sync-status": string; "by-created-at": string };
  };
  damageQueue: {
    key: string;
    value: QueuedDamage;
    indexes: { "by-sync-status": string };
  };
}

let dbPromise: Promise<IDBPDatabase<OfflineDB>> | null = null;

function getDB(): Promise<IDBPDatabase<OfflineDB>> {
  if (!dbPromise) {
    // v2 adds damageQueue. The upgrade is written cumulatively so a phone
    // that's been offline since v1 gets both stores without losing its queue.
    dbPromise = openDB<OfflineDB>(OFFLINE_DB_NAME, 2, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          const store = db.createObjectStore("movementQueue", { keyPath: "clientUuid" });
          store.createIndex("by-sync-status", "syncStatus");
          store.createIndex("by-created-at", "createdAt");
        }
        if (oldVersion < 2) {
          const damage = db.createObjectStore("damageQueue", { keyPath: "clientUuid" });
          damage.createIndex("by-sync-status", "syncStatus");
        }
      },
    });
  }
  return dbPromise;
}

/** Mutate one queue entry in place. */
async function updateEntry(
  clientUuid: string,
  mutate: (entry: QueuedMovement) => void
): Promise<void> {
  const db = await getDB();
  const entry = await db.get("movementQueue", clientUuid);
  if (!entry) return;
  mutate(entry);
  await db.put("movementQueue", entry);
}

export async function enqueueMovement(
  movement: Omit<QueuedMovement, "clientUuid" | "createdAt" | "syncStatus" | "retryCount">
): Promise<string> {
  const db = await getDB();
  const clientUuid = uuidv4();
  const entry: QueuedMovement = {
    ...movement,
    clientUuid,
    createdAt: new Date().toISOString(),
    syncStatus: "pending",
    retryCount: 0,
  };
  await db.put("movementQueue", entry);
  return clientUuid;
}

export async function getPendingMovements(): Promise<QueuedMovement[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex("movementQueue", "by-sync-status", "pending");
  return all.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function getPendingCount(): Promise<number> {
  const pending = await getPendingMovements();
  return pending.length;
}

/** Movements the server refused permanently — surfaced to the crew for review. */
export async function getRejectedMovements(): Promise<QueuedMovement[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex("movementQueue", "by-sync-status", "rejected");
  return all.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function getRejectedCount(): Promise<number> {
  return (await getRejectedMovements()).length;
}

export async function markSynced(clientUuid: string): Promise<void> {
  await updateEntry(clientUuid, (entry) => {
    entry.syncStatus = "synced";
    entry.errorMessage = undefined;
  });
}

/** Return an entry to the queue without consuming a retry (offline / 401). */
export async function markPending(clientUuid: string): Promise<void> {
  await updateEntry(clientUuid, (entry) => {
    entry.syncStatus = "pending";
  });
}

/** Transient failure — retried until MAX_RETRIES, then parked as rejected. */
export async function markError(clientUuid: string, errorMessage: string): Promise<void> {
  await updateEntry(clientUuid, (entry) => {
    entry.errorMessage = errorMessage;
    entry.retryCount = (entry.retryCount || 0) + 1;
    entry.syncStatus = entry.retryCount >= MAX_RETRIES ? "rejected" : "pending";
  });
}

/** Permanent refusal from the server. Never retried. */
export async function markRejected(clientUuid: string, errorMessage: string): Promise<void> {
  await updateEntry(clientUuid, (entry) => {
    entry.syncStatus = "rejected";
    entry.errorMessage = errorMessage;
  });
}

/** Let the crew clear a rejected movement once they've reconciled it by hand. */
export async function discardMovement(clientUuid: string): Promise<void> {
  const db = await getDB();
  await db.delete("movementQueue", clientUuid);
}

export async function markSyncing(clientUuid: string): Promise<void> {
  await updateEntry(clientUuid, (entry) => {
    entry.syncStatus = "syncing";
  });
}

export async function syncQueue(): Promise<{
  synced: number;
  errors: number;
  rejected: number;
}> {
  const pending = await getPendingMovements();
  let synced = 0;
  let errors = 0;
  let rejected = 0;

  for (const movement of pending) {
    try {
      await markSyncing(movement.clientUuid);
      const response = await fetch("/api/movements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(movement),
      });

      if (response.ok) {
        // Covers both a fresh write and the idempotent replay of one we'd
        // already sent — the server returns 200 for both.
        await markSynced(movement.clientUuid);
        synced++;
        continue;
      }

      // 401 means the session expired. Everything still queued will fail the
      // same way, so stop here and leave it pending for after the next login.
      if (response.status === 401) {
        await markPending(movement.clientUuid);
        break;
      }

      const body = await response.json().catch(() => ({}) as { error?: string });
      const message = body.error || `Server returned ${response.status}`;

      if (nextSyncState(response.status, movement.retryCount || 0) === "rejected") {
        await markRejected(movement.clientUuid, message);
        rejected++;
      } else {
        await markError(movement.clientUuid, message);
        errors++;
      }
    } catch (err) {
      // Network-level failure: still offline. Keep it pending, don't burn a retry.
      await markPending(movement.clientUuid);
      errors++;
    }
  }

  return { synced, errors, rejected };
}

export function generateDeviceId(): string {
  if (typeof window === "undefined") return "server";
  let deviceId = localStorage.getItem("forge_device_id");
  if (!deviceId) {
    deviceId = `dev-${uuidv4().slice(0, 8)}`;
    localStorage.setItem("forge_device_id", deviceId);
  }
  return deviceId;
}

// ── Damage queue ─────────────────────────────────────────────────────────────

/**
 * Hold a damage report until there's signal.
 *
 * The photo Blobs are stored as-is. They're already compressed to ~150-350KB
 * by the camera module, so a handful of reports is a few megabytes — well
 * inside what IndexedDB allows, and the alternative (losing the report) is
 * worse than the storage.
 */
export async function enqueueDamage(
  payload: Record<string, unknown>,
  photos: Blob[]
): Promise<string> {
  const db = await getDB();
  const clientUuid = (payload.clientUuid as string) || uuidv4();
  await db.put("damageQueue", {
    clientUuid,
    payload: { ...payload, clientUuid },
    photos,
    createdAt: new Date().toISOString(),
    syncStatus: "pending",
    retryCount: 0,
  });
  return clientUuid;
}

export async function getPendingDamage(): Promise<QueuedDamage[]> {
  const db = await getDB();
  const all = await db.getAllFromIndex("damageQueue", "by-sync-status", "pending");
  return all.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function getPendingDamageCount(): Promise<number> {
  return (await getPendingDamage()).length;
}

export async function getRejectedDamage(): Promise<QueuedDamage[]> {
  const db = await getDB();
  return db.getAllFromIndex("damageQueue", "by-sync-status", "rejected");
}

export async function discardDamage(clientUuid: string): Promise<void> {
  const db = await getDB();
  await db.delete("damageQueue", clientUuid);
}

async function updateDamage(
  clientUuid: string,
  mutate: (entry: QueuedDamage) => void
): Promise<void> {
  const db = await getDB();
  const entry = await db.get("damageQueue", clientUuid);
  if (!entry) return;
  mutate(entry);
  await db.put("damageQueue", entry);
}

/**
 * Push queued damage reports.
 *
 * Order matters: photos upload first, then the report referencing them. If the
 * signal dies between the two, the photos are orphaned but the report is
 * retried whole — and the server's clientUuid uniqueness means a replay after
 * a partial success is idempotent rather than a duplicate claim.
 */
export async function syncDamageQueue(): Promise<{
  synced: number;
  errors: number;
  rejected: number;
}> {
  const pending = await getPendingDamage();
  let synced = 0;
  let errors = 0;
  let rejected = 0;

  for (const entry of pending) {
    try {
      await updateDamage(entry.clientUuid, (e) => {
        e.syncStatus = "syncing";
      });

      const photoIds: string[] = [];
      for (const blob of entry.photos) {
        const form = new FormData();
        form.append("file", blob, "photo.jpg");
        form.append("subjectType", "damage");
        const res = await fetch("/api/photos", { method: "POST", body: form });
        if (!res.ok) throw new Error(`Photo upload failed (${res.status})`);
        const { photo } = await res.json();
        photoIds.push(photo.id);
      }

      const res = await fetch("/api/damage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...entry.payload, photoIds }),
      });

      if (res.ok) {
        // Drop it outright rather than keeping a synced row: unlike movements,
        // there's nothing to reconcile afterwards, and the Blobs are the
        // largest thing in the database.
        await discardDamage(entry.clientUuid);
        synced++;
        continue;
      }

      if (res.status === 401) {
        await updateDamage(entry.clientUuid, (e) => {
          e.syncStatus = "pending";
        });
        break;
      }

      const body = await res.json().catch(() => ({}) as { error?: string });
      const message = body.error || `Server returned ${res.status}`;

      if (nextSyncState(res.status, entry.retryCount || 0) === "rejected") {
        await updateDamage(entry.clientUuid, (e) => {
          e.syncStatus = "rejected";
          e.errorMessage = message;
        });
        rejected++;
      } else {
        await updateDamage(entry.clientUuid, (e) => {
          e.errorMessage = message;
          e.retryCount = (e.retryCount || 0) + 1;
          e.syncStatus = "pending";
        });
        errors++;
      }
    } catch {
      // Still offline, or the photo upload failed mid-way. Keep it pending and
      // don't burn a retry — the whole report will be re-sent.
      await updateDamage(entry.clientUuid, (e) => {
        e.syncStatus = "pending";
      });
      errors++;
    }
  }

  return { synced, errors, rejected };
}
