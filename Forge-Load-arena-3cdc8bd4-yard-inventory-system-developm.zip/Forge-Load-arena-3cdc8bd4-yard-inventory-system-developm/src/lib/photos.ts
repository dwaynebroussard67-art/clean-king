import { db, photos } from "@/db";
import { and, eq } from "drizzle-orm";
import type { PhotoSubject } from "./photo-validation";

// Validation rules live in a db-free module so they can be tested and reused
// without a connection string; re-exported here so callers have one import.
export {
  MAX_PHOTO_BYTES,
  ALLOWED_CONTENT_TYPES,
  PHOTO_SUBJECTS,
  sniffImageType,
  optionalNumber,
  type PhotoSubject,
} from "./photo-validation";

/**
 * The only module that touches the photo bytes column. If photo storage ever
 * moves to object storage (S3/R2), this is the single file that changes.
 */

export interface StorePhotoInput {
  subjectType: PhotoSubject;
  subjectId?: string | null;
  data: Buffer;
  contentType: string;
  width?: number | null;
  height?: number | null;
  takenBy: string;
  deviceId?: string | null;
  deviceTime?: Date | null;
  latitude?: number | null;
  longitude?: number | null;
  accuracyM?: number | null;
  caption?: string | null;
}

export async function storePhoto(input: StorePhotoInput) {
  const [row] = await db
    .insert(photos)
    .values({
      subjectType: input.subjectType,
      subjectId: input.subjectId ?? null,
      data: input.data,
      contentType: input.contentType,
      byteSize: input.data.length,
      width: input.width ?? null,
      height: input.height ?? null,
      takenBy: input.takenBy,
      deviceId: input.deviceId ?? null,
      deviceTime: input.deviceTime ?? new Date(),
      latitude: input.latitude ?? null,
      longitude: input.longitude ?? null,
      accuracyM: input.accuracyM ?? null,
      caption: input.caption ?? null,
    })
    .returning({
      id: photos.id,
      subjectType: photos.subjectType,
      subjectId: photos.subjectId,
      byteSize: photos.byteSize,
      createdAt: photos.createdAt,
    });

  return row;
}

/** Fetch the bytes for serving. Returns null when the id doesn't exist. */
export async function loadPhotoBytes(id: string) {
  const [row] = await db
    .select({
      data: photos.data,
      contentType: photos.contentType,
      byteSize: photos.byteSize,
    })
    .from(photos)
    .where(eq(photos.id, id))
    .limit(1);

  return row ?? null;
}

/**
 * Metadata for every photo attached to a subject, newest last so a delivery
 * gallery reads in the order the crew shot it. Never selects `data` — the
 * bytes are served one image at a time so each can be cached on its own.
 */
export async function listPhotosForSubject(subjectType: string, subjectId: string) {
  return db
    .select({
      id: photos.id,
      contentType: photos.contentType,
      byteSize: photos.byteSize,
      width: photos.width,
      height: photos.height,
      caption: photos.caption,
      latitude: photos.latitude,
      longitude: photos.longitude,
      deviceTime: photos.deviceTime,
      createdAt: photos.createdAt,
    })
    .from(photos)
    .where(and(eq(photos.subjectType, subjectType), eq(photos.subjectId, subjectId)))
    .orderBy(photos.createdAt);
}
