/**
 * Shared vocabulary for shifts, tracking, truck checks and itineraries.
 *
 * Deliberately free of database and browser imports: this file is read by
 * API routes, React pages and the test suite alike, and the rules in it (what
 * counts as "at the shop", which checklist item makes a truck unsafe) are the
 * kind of thing that must agree everywhere or the office and the phone will
 * disagree about the same morning.
 */

// ── Geography ────────────────────────────────────────────────────────────────

/** Great-circle distance in metres. Good to well under 0.5% at these scales. */
export function haversineMeters(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6_371_000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function isValidLatLng(lat: unknown, lng: unknown): lat is number {
  return (
    typeof lat === "number" &&
    typeof lng === "number" &&
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    Math.abs(lat) <= 90 &&
    Math.abs(lng) <= 180
  );
}

/** "0.3 mi" / "850 ft" — the crew and the owner think in miles, not metres. */
export function formatDistance(meters: number | null | undefined): string {
  if (meters == null || !Number.isFinite(meters)) return "—";
  const feet = meters * 3.28084;
  if (feet < 1000) return `${Math.round(feet)} ft`;
  const miles = feet / 5280;
  return `${miles < 10 ? miles.toFixed(1) : Math.round(miles)} mi`;
}

/** Metres/second from the GPS -> "23 mph". Null when the phone had no speed. */
export function formatSpeed(mps: number | null | undefined): string | null {
  if (mps == null || !Number.isFinite(mps) || mps < 0) return null;
  return `${Math.round(mps * 2.23694)} mph`;
}

// ── Time ─────────────────────────────────────────────────────────────────────

/** The shop's time zone. Abbeville, LA. */
export const SITE_TIME_ZONE = "America/Chicago";

/**
 * YYYY-MM-DD for a moment, in the shop's zone. Itineraries and truck checks
 * are keyed by calendar day, and a server in UTC would otherwise roll the day
 * over at 7 pm Louisiana time — which is exactly when the office is typing
 * tomorrow's orders.
 */
export function localDateKey(d: Date = new Date(), timeZone = SITE_TIME_ZONE): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

/** Tomorrow's key — the default when the office opens the itinerary form. */
export function nextDateKey(from: Date = new Date(), timeZone = SITE_TIME_ZONE): string {
  return localDateKey(new Date(from.getTime() + 24 * 60 * 60 * 1000), timeZone);
}

export const DATE_KEY_RE = /^\d{4}-\d{2}-\d{2}$/;

/** "Tuesday, September 5" from a date key. Parsed as local midnight on purpose. */
export function formatDateKey(key: string, opts: Intl.DateTimeFormatOptions = {}): string {
  if (!DATE_KEY_RE.test(key)) return key;
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    ...opts,
  });
}

/** "6h 42m" for the shift card. */
export function formatDuration(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return "—";
  const totalMinutes = Math.floor(ms / 60_000);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return h > 0 ? `${h}h ${m.toString().padStart(2, "0")}m` : `${m}m`;
}

/** "just now" / "4 min ago" / "2 h ago" — for the last-ping column. */
export function formatAgo(iso: string | Date | null | undefined, now = Date.now()): string {
  if (!iso) return "never";
  const t = typeof iso === "string" ? Date.parse(iso) : iso.getTime();
  if (!Number.isFinite(t)) return "—";
  const s = Math.max(0, Math.round((now - t) / 1000));
  if (s < 45) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  return `${Math.round(h / 24)} d ago`;
}

// ── Truck check ──────────────────────────────────────────────────────────────

export type CheckResult = "ok" | "watch" | "bad";
export type CheckStatus = "ok" | "attention" | "needs_repair";

export interface CheckItem {
  key: string;
  label: string;
  hint: string;
  /**
   * A "bad" on a critical item grounds the truck; on a non-critical one it's
   * flagged for the shop but the truck can still roll.
   */
  critical: boolean;
}

/**
 * The morning once-over, in the order you'd walk it: start at the hood, walk
 * round the outside, climb in. Earl's words were "check the oil, look at the
 * engine, give the truck a once-over" — these are the specifics of that.
 */
export const CHECK_ITEMS: readonly CheckItem[] = [
  { key: "oil", label: "Engine oil", hint: "Pull the dipstick. Between the marks, not black.", critical: true },
  { key: "coolant", label: "Coolant", hint: "Reservoir between MIN and MAX. Never open it hot.", critical: true },
  { key: "belts_hoses", label: "Belts & hoses", hint: "No cracks, fraying, or wet spots under the truck.", critical: false },
  { key: "brakes", label: "Brakes", hint: "Pedal firm, no grinding, parking brake holds.", critical: true },
  { key: "tires", label: "Tires", hint: "Pressure looks right, tread OK, no cords or bulges. Check the lugs.", critical: true },
  { key: "lights", label: "Lights & signals", hint: "Headlights, brake lights, turn signals, reverse lights.", critical: true },
  { key: "mirrors_glass", label: "Mirrors & glass", hint: "Clean, adjusted, no cracks in the windshield line of sight.", critical: false },
  { key: "liftgate", label: "Lift gate & straps", hint: "Gate cycles, latches hold, straps and blankets aboard.", critical: true },
  { key: "leaks", label: "Leaks", hint: "Look under the truck where it sat overnight.", critical: false },
  { key: "cab", label: "Cab & horn", hint: "Horn, wipers, washer fluid, seatbelt, no warning lights.", critical: false },
  { key: "body", label: "Body & box", hint: "New dents or damage since yesterday? Door seals OK?", critical: false },
] as const;

export const CHECK_KEYS: ReadonlySet<string> = new Set(CHECK_ITEMS.map((i) => i.key));

export const FUEL_LEVELS = ["E", "1/4", "1/2", "3/4", "F"] as const;
export type FuelLevel = (typeof FUEL_LEVELS)[number];

/**
 * Roll the individual results up into one word the office can filter on.
 * Any critical "bad" grounds the truck. Anything else that isn't clean needs
 * attention. Missing items are treated as not checked -> attention, so a
 * half-finished checklist can't come out looking spotless.
 */
export function rollupCheckStatus(
  items: Partial<Record<string, CheckResult>>
): CheckStatus {
  let attention = false;
  for (const item of CHECK_ITEMS) {
    const r = items[item.key];
    if (r === "bad" && item.critical) return "needs_repair";
    if (r !== "ok") attention = true;
  }
  return attention ? "attention" : "ok";
}

/** True when every item has a result — the checklist is complete. */
export function isCheckComplete(items: Partial<Record<string, CheckResult>>): boolean {
  return CHECK_ITEMS.every((i) => items[i.key] !== undefined);
}

export const CHECK_STATUS_LABEL: Record<CheckStatus, string> = {
  ok: "Good to go",
  attention: "Needs attention",
  needs_repair: "Do not drive",
};

// ── Shifts ───────────────────────────────────────────────────────────────────

/**
 * How stale a position can be before the map shows it as "signal lost". The
 * phone pings every ~15 s while moving; a couple of missed minutes means the
 * app got backgrounded, the phone died, or the truck is somewhere with no
 * service.
 */
export const STALE_PING_MS = 3 * 60 * 1000;

/**
 * Was this clock-in physically at the site? Compares the phone's distance
 * against the site radius plus the phone's own accuracy — a fix that's ±80 m
 * under a metal roof shouldn't read as "off site" when the shop is 250 m wide.
 */
export function isOnSite(
  distanceM: number | null | undefined,
  radiusM: number,
  accuracyM: number | null | undefined
): boolean | null {
  if (distanceM == null || !Number.isFinite(distanceM)) return null;
  const slack = Math.min(accuracyM ?? 0, 200);
  return distanceM <= radiusM + slack;
}

/** A shift older than this with no clock-out was almost certainly forgotten. */
export const FORGOTTEN_SHIFT_MS = 14 * 60 * 60 * 1000;

// ── Site tokens ──────────────────────────────────────────────────────────────

export const SITE_TOKEN_RE = /^[A-Z0-9]{6,32}$/;

/**
 * Pull a site token out of whatever the scanner read. The poster encodes a
 * full URL (so a phone camera app opens the right page), but a typed code or
 * an older bare-token poster should work too.
 */
export function parseSiteToken(raw: string): string | null {
  const trimmed = raw.trim();
  const fromUrl = trimmed.match(/\/clock-in\/([^/?#]+)/i)?.[1];
  const candidate = (fromUrl ? decodeURIComponent(fromUrl) : trimmed).toUpperCase();
  return SITE_TOKEN_RE.test(candidate) ? candidate : null;
}

/** Unambiguous alphabet: no 0/O or 1/I to misread off a faded poster. */
const TOKEN_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateSiteToken(random: () => number = Math.random, length = 10): string {
  let out = "";
  for (let i = 0; i < length; i++) {
    out += TOKEN_ALPHABET[Math.floor(random() * TOKEN_ALPHABET.length)];
  }
  return out;
}
