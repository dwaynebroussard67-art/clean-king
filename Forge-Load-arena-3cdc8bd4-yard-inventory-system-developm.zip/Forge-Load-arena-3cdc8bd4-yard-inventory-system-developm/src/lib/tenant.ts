/**
 * Tenant (white-label) configuration.
 *
 * The goal: standing up the same app for a new customer is a config change,
 * not a fork. Every customer-visible name, colour, and word lives here and
 * nowhere else, so "swap the name and nothing else changes" is literally true.
 *
 * Selected by the TENANT environment variable at build/run time. Unknown or
 * missing values fall back to the default tenant rather than crashing, because
 * a typo in an env var should not take a yard offline.
 *
 * ── Adding a customer ────────────────────────────────────────────────────────
 *   1. Add an entry to TENANTS below.
 *   2. Drop their icons in public/ (or reuse the defaults).
 *   3. Deploy with TENANT=<key>.
 * That's the whole process. No code changes.
 *
 * This file is imported by both server and client code, so it must stay free
 * of any Node-only imports.
 */

export interface TenantTheme {
  /** Tailwind colour family used for primary actions, e.g. "orange". */
  accent: string;
  /** Hex used in non-Tailwind contexts: PWA manifest, focus rings, QR labels. */
  accentHex: string;
  accentHexDark: string;
  /**
   * Lighter tint used where the accent is *text* on the near-black chrome.
   *
   * The fill and the text can't be the same colour once a tenant picks a dark
   * brand shade. Earl's hunter green is right for a button (white on it reads
   * fine) and unreadable as label text on slate-950 -- about 2:1, which is a
   * problem on a phone in daylight, which is where this app lives.
   *
   * Optional: when a brand colour is already light enough to do both jobs, the
   * accent is used for text as well and nothing changes.
   */
  accentHexTint?: string;
  /** Page background + chrome. Kept a slate scale so contrast stays predictable. */
  surface: string;
}

/**
 * What this customer calls the things on their yard.
 *
 * The database says `bundle` everywhere and always will — renaming columns per
 * customer would be madness. This is purely the words a crew reads on screen.
 * A lumber yard says "bundle", a drum yard says "drum", a furniture warehouse
 * says "lot". Same table underneath.
 */
export interface TenantTerms {
  /** A tracked, labelled group of stock. Lowercase; the UI capitalises. */
  unit: string;
  unitPlural: string;
  /** The countable thing inside one unit ("piece", "drum", "item"). */
  item: string;
  itemPlural: string;
  /** Default measure for new products, must exist in UNIT_OPTIONS below. */
  defaultMeasure: string;
  /** Measures offered when creating a product. */
  measures: readonly string[];
  /**
   * Does this yard group stock into multi-item units at all?
   *
   * A lumber yard receives a bundle of 200 boards, so intake has to ask two
   * numbers: how many per bundle, and how many bundles. Earl's moves furniture
   * -- mostly a single sofa. Occasionally a box holds three tables, but there
   * is no such thing as a "bundle", and asking a driver to enter 1 and then 1
   * again for every sofa is a tax on the common case.
   *
   * When false, intake asks one question ("how many are you adding?") and each
   * item is its own tracked unit. The database shape does not change -- these
   * are still bundles of one -- so nothing downstream needs to know.
   */
  groupsItems: boolean;
  /**
   * Label for the optional "this box holds more than one" field, shown only
   * when groupsItems is false. Null hides the field entirely.
   */
  perPackLabel: string | null;
  /**
   * Other words this yard uses for the same thing, interchangeably.
   *
   * Earl's crews say item, piece and unit and mean one object either way. The
   * UI still picks one word and sticks to it -- switching vocabulary
   * mid-screen reads like a bug -- but the assistant is told the synonyms so
   * "how many units of the grey sofa" isn't misread as a different concept.
   *
   * Not used for matching product names; purely vocabulary.
   */
  synonyms?: readonly string[];
}

const YARD_TERMS: TenantTerms = {
  unit: "bundle",
  unitPlural: "bundles",
  item: "piece",
  itemPlural: "pieces",
  defaultMeasure: "piece",
  measures: ["piece", "linear_ft", "board_ft", "bundle"],
  groupsItems: true,
  perPackLabel: null,
};

export interface TenantConfig {
  /** Stable key. Used in the session cookie name and the IndexedDB name. */
  key: string;
  /** Full legal/marketing name: login screen, PWA install prompt, page title. */
  name: string;
  /** Compact name for the navbar and app icon label. */
  shortName: string;
  /** One-liner under the logo and in the manifest/meta description. */
  tagline: string;
  /** Emoji or single glyph used as the in-app mark. Cheap, and it prints. */
  mark: string;
  /**
   * 1-2 letter monogram for the generated app icon.
   *
   * Deliberately not the emoji: rendering an emoji into a PNG makes the build
   * fetch an SVG from a public CDN, which fails in air-gapped CI and quietly
   * couples every deploy to a third-party host. Letters use the bundled font
   * and need no network at all.
   */
  monogram: string;
  /** What this yard actually sells. Feeds the AI assistant's system prompt. */
  domain: string;
  /**
   * Prefix for generated stock codes (e.g. "ITM-2026-000123").
   *
   * The database sequence is shared storage; the prefix is the only visible
   * part, so it must read as the customer's stock. Lives here rather than in
   * codes.ts so a new tenant is still a config change and nothing else.
   */
  codePrefix: string;
  /** What this customer calls a tracked group of stock. */
  terms: TenantTerms;
  theme: TenantTheme;
}

const DEFAULT_THEME: TenantTheme = {
  accent: "orange",
  accentHex: "#f97316",
  accentHexDark: "#ea580c",
  surface: "slate",
};

export const TENANTS: Record<string, TenantConfig> = {
  "forge-load": {
    key: "forge-load",
    name: "Forge Load",
    shortName: "Forge Load",
    tagline: "Crew, trucks and stock — from one QR code",
    mark: "🔥",
    monogram: "FL",
    domain: "building materials and fencing",
    codePrefix: "BND",
    terms: YARD_TERMS,
    theme: DEFAULT_THEME,
  },

  "clean-king": {
    key: "clean-king",
    name: "Clean King",
    shortName: "Clean King",
    tagline: "PortLoad: crew, supplies and jobs — from one QR code",
    mark: "👑",
    monogram: "CK",
    domain: "cleaning supplies, equipment and franchise operations",
    codePrefix: "KIT",
    terms: {
      // Clean King franchises track cleaning kits: a caddy of bottles and
      // tools that moves as one labelled unit between the shop, the van and
      // the job site. A kit genuinely holds several bottles, so intake asks
      // how many bottles per kit and how many kits — same shape as a lumber
      // bundle, different words.
      unit: "kit",
      unitPlural: "kits",
      item: "bottle",
      itemPlural: "bottles",
      defaultMeasure: "bottle",
      measures: ["bottle", "case", "kit", "gallon"],
      groupsItems: true,
      perPackLabel: null,
      // Crews say caddy and pack for the same thing.
      synonyms: ["caddy", "pack"],
    },
    theme: {
      accent: "amber",
      // Clean King's burgundy. White on this fill is ~10:1, comfortably past
      // the 4.5:1 line, and the darker shade below is the hover state.
      accentHex: "#7f1d1d",
      accentHexDark: "#5c1414",
      // Burgundy as *text* on slate-950 is ~1.5:1 — illegible on a phone.
      // The brand gold is 11:1+ and still reads as the same brand.
      accentHexTint: "#fbbf24",
      surface: "slate",
    },
  },

  "earls-furniture": {
    key: "earls-furniture",
    name: "Earl's Furniture",
    shortName: "Earl's",
    tagline: "Clock in, trucks, and deliveries",
    mark: "🪑",
    monogram: "EF",
    domain: "furniture and home furnishings",
    codePrefix: "ITM",
    terms: {
      // Earl's tracks individual pieces of furniture, not groups. A sofa is
      // one item with one label. A matching sofa and loveseat is a "set", and
      // a boxed set of three tables uses the per-box count -- but there is no
      // bundle, so the UI never asks about one.
      unit: "item",
      unitPlural: "items",
      item: "piece",
      itemPlural: "pieces",
      defaultMeasure: "item",
      measures: ["item", "set", "box"],
      groupsItems: false,
      perPackLabel: "How many in the box?",
      // Earl's uses these interchangeably in speech.
      synonyms: ["piece", "unit"],
    },
    theme: {
      accent: "green",
      // Deep forest / hunter green. Verified against the slate chrome rather
      // than eyeballed: white on this fill is 5.02:1, comfortably past the
      // 4.5:1 line, and the darker shade below is 7.13:1 for hover.
      accentHex: "#15803d",
      accentHexDark: "#166534",
      // The same green as *text* on slate-950 is only 2.21:1 -- illegible on a
      // phone in a warehouse doorway. This tint is 11.58:1 and still reads as
      // the same brand green.
      accentHexTint: "#4ade80",
      surface: "slate",
    },
  },
};

export const DEFAULT_TENANT_KEY = "forge-load";

/**
 * Resolve the active tenant.
 *
 * NEXT_PUBLIC_TENANT is read rather than TENANT because this runs in the
 * browser too, and Next only inlines NEXT_PUBLIC_* into client bundles. TENANT
 * is accepted as a server-side alias so deploy configs can use either.
 */
export function getTenant(): TenantConfig {
  const key =
    (typeof process !== "undefined" &&
      (process.env.NEXT_PUBLIC_TENANT || process.env.TENANT)) ||
    DEFAULT_TENANT_KEY;

  return TENANTS[key] ?? TENANTS[DEFAULT_TENANT_KEY];
}

/** The active tenant, resolved once. */
export const tenant = getTenant();

/**
 * Session cookie name, namespaced per tenant.
 *
 * Two tenants served from different subdomains of one parent domain would
 * otherwise overwrite each other's session cookie, silently logging people out
 * of the other yard.
 */
export const SESSION_COOKIE = `${tenant.key}_session`;

/** IndexedDB name for the offline queue, namespaced for the same reason. */
export const OFFLINE_DB_NAME = `${tenant.key}-v1`;

/** Shorthand for the active tenant's vocabulary. */
export const terms = tenant.terms;

/** "bundle" -> "Bundle". Used for headings and labels. */
export function capitalize(word: string): string {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

/** The tracked-stock noun, capitalised: "Bundle" / "Pallet" / "Lot". */
export const Unit = capitalize(terms.unit);
export const UnitPlural = capitalize(terms.unitPlural);

/**
 * Human-readable measure label. Stored values are snake_case for the database;
 * crews should never see an underscore.
 */
/**
 * "a bundle" / "an item". Tenant vocabulary is configuration, so the article
 * can't be hardcoded in the copy -- Earl's unit is "item" and "Scan a item"
 * reads like a bug to the crew using it every day.
 *
 * Vowel-letter test, not a pronunciation dictionary. It's right for every unit
 * word in use and for the realistic candidates (item, order, box, pallet);
 * words like "unit" would need a real dictionary, so if one ever comes up the
 * fix is an explicit article field on the tenant rather than more heuristics.
 */
export function withArticle(noun: string): string {
  return `${/^[aeiou]/i.test(noun) ? "an" : "a"} ${noun}`;
}

export function measureLabel(measure: string): string {
  return measure.replace(/_/g, " ");
}
