/**
 * Session cookie/token constants, kept free of any database import so the Edge
 * proxy can use them. `@/lib/auth` pulls in Drizzle and can't run on the Edge.
 */

/** How long a session token is valid for. */
export const SESSION_TTL_SECONDS = 7 * 24 * 60 * 60;

/**
 * Refresh the token once it has less than this left.
 *
 * The yard runs on shared phones that stay logged in for weeks. With a hard
 * 7-day expiry, a crew member gets bounced to a login screen mid-shift --
 * usually while holding something, often out of signal range, and the offline
 * queue can't drain until they get back in. Re-issuing on activity means an
 * in-use phone never expires, while one left in a drawer still goes cold in a
 * week.
 */
export const SESSION_REFRESH_THRESHOLD_SECONDS = 3 * 24 * 60 * 60;

export const sessionCookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax",
  maxAge: SESSION_TTL_SECONDS,
  path: "/",
} as const;

/**
 * Should a token with this `exp` (seconds since epoch) be re-issued?
 *
 * Split out as a pure function so the boundaries are testable without minting
 * real JWTs: an already-expired token must not be refreshed (that would let a
 * dead session resurrect itself indefinitely).
 */
export function shouldRefreshSession(
  exp: number | undefined,
  nowSeconds: number = Math.floor(Date.now() / 1000)
): boolean {
  if (!exp) return false;
  const remaining = exp - nowSeconds;
  if (remaining <= 0) return false;
  return remaining < SESSION_REFRESH_THRESHOLD_SECONDS;
}
