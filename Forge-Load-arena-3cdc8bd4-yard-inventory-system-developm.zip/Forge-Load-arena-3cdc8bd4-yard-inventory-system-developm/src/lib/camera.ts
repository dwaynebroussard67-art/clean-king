"use client";

/**
 * Camera capture helpers shared by every photo feature in the app.
 *
 * Design constraints from the yard:
 *  - Phones are a mix of iPhone and Android, so nothing here may depend on a
 *    Chrome-only API.
 *  - Photos are shot on cellular, often on a weak signal. A raw 12MP JPEG is
 *    3-5MB; we downscale and re-encode to roughly 150-350KB before upload.
 *  - Gloves and sunlight. Capture has to be one big tap, no fiddling.
 */

export interface CapturedPhoto {
  /** JPEG bytes, already downscaled and compressed. */
  blob: Blob;
  /** Object URL for preview. Caller must revokeObjectURL when done. */
  previewUrl: string;
  width: number;
  height: number;
  byteSize: number;
}

export interface CaptureGeo {
  latitude: number | null;
  longitude: number | null;
  accuracyM: number | null;
}

const MAX_EDGE = 1600; // plenty to read a label or show a crack
const JPEG_QUALITY = 0.72;
const TARGET_MAX_BYTES = 400 * 1024;

/**
 * Downscale + compress an image to something sensible to upload over cellular.
 * Falls back to progressively lower quality if the first pass is still large.
 */
export async function compressImage(source: Blob | HTMLVideoElement): Promise<CapturedPhoto> {
  const { canvas, width, height } = await drawToCanvas(source);

  let quality = JPEG_QUALITY;
  let blob = await canvasToBlob(canvas, quality);

  // A busy yard photo (lots of texture) can stay big; step the quality down
  // rather than shipping a multi-megabyte upload over a weak connection.
  while (blob.size > TARGET_MAX_BYTES && quality > 0.4) {
    quality -= 0.12;
    blob = await canvasToBlob(canvas, quality);
  }

  return {
    blob,
    previewUrl: URL.createObjectURL(blob),
    width,
    height,
    byteSize: blob.size,
  };
}

async function drawToCanvas(
  source: Blob | HTMLVideoElement
): Promise<{ canvas: HTMLCanvasElement; width: number; height: number }> {
  let sourceWidth: number;
  let sourceHeight: number;
  let drawable: CanvasImageSource;
  let cleanup: (() => void) | undefined;

  if (source instanceof HTMLVideoElement) {
    sourceWidth = source.videoWidth;
    sourceHeight = source.videoHeight;
    drawable = source;
  } else {
    // createImageBitmap handles EXIF orientation on modern browsers, which
    // matters — otherwise iPhone photos come out sideways.
    const bitmap = await createImageBitmap(source);
    sourceWidth = bitmap.width;
    sourceHeight = bitmap.height;
    drawable = bitmap;
    cleanup = () => bitmap.close();
  }

  const scale = Math.min(1, MAX_EDGE / Math.max(sourceWidth, sourceHeight));
  const width = Math.round(sourceWidth * scale);
  const height = Math.round(sourceHeight * scale);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not process the image on this device.");
  ctx.drawImage(drawable, 0, 0, width, height);
  cleanup?.();

  return { canvas, width, height };
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Image encoding failed"))),
      "image/jpeg",
      quality
    );
  });
}

/** Open the rear camera as a live stream. */
export async function openCameraStream(): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("This browser can't open the camera. Use the photo library instead.");
  }
  return navigator.mediaDevices.getUserMedia({
    video: {
      facingMode: { ideal: "environment" },
      width: { ideal: 1920 },
      height: { ideal: 1080 },
    },
    audio: false,
  });
}

/**
 * Best-effort location. Never blocks capture: if the crew denies permission or
 * GPS is slow under a metal roof, we take the photo anyway and record nulls.
 */
export function getGeo(timeoutMs = 6000): Promise<CaptureGeo> {
  const empty: CaptureGeo = { latitude: null, longitude: null, accuracyM: null };

  return new Promise((resolve) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      resolve(empty);
      return;
    }

    let settled = false;
    const done = (value: CaptureGeo) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };

    const timer = setTimeout(() => done(empty), timeoutMs);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        clearTimeout(timer);
        done({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracyM: pos.coords.accuracy ?? null,
        });
      },
      () => {
        clearTimeout(timer);
        done(empty);
      },
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 30_000 }
    );
  });
}

/** Grab a still frame from a running preview. */
export async function captureFrame(video: HTMLVideoElement): Promise<CapturedPhoto> {
  if (!video.videoWidth) throw new Error("Camera isn't ready yet.");
  return compressImage(video);
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
