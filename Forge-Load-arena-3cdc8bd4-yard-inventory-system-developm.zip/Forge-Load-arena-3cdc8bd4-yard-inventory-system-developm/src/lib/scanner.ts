"use client";

/**
 * Cross-platform QR scanning for a mixed iPhone / Android fleet.
 *
 * Android Chrome ships the native `BarcodeDetector` API, which is fast and
 * battery-cheap. iOS Safari does not implement it at all — the previous version
 * of this app checked for it and then silently did nothing, so on every iPhone
 * the camera turned on and simply never scanned, with no error shown.
 *
 * This module picks the best available engine:
 *   1. native BarcodeDetector  (Android Chrome, Edge, some desktop)
 *   2. ZXing WASM/JS fallback  (iOS Safari, Firefox, anything else)
 *
 * Both paths expose the same start/stop interface so the UI doesn't care which
 * one it got — but it can report the engine, which matters when debugging a
 * scanning complaint from the yard.
 */

export type ScanEngine = "native" | "zxing";

export interface ScannerHandle {
  engine: ScanEngine;
  stop: () => void;
}

export interface StartScannerOptions {
  video: HTMLVideoElement;
  onResult: (value: string) => void;
  onError?: (message: string) => void;
  /** Called once the engine is chosen, for diagnostics in the UI. */
  onEngine?: (engine: ScanEngine) => void;
}

interface NativeBarcodeDetector {
  detect: (source: CanvasImageSource) => Promise<Array<{ rawValue: string }>>;
}

type BarcodeDetectorCtor = new (opts: { formats: string[] }) => NativeBarcodeDetector;

function getNativeDetectorCtor(): BarcodeDetectorCtor | null {
  if (typeof window === "undefined") return null;
  const ctor = (window as unknown as { BarcodeDetector?: BarcodeDetectorCtor })
    .BarcodeDetector;
  return typeof ctor === "function" ? ctor : null;
}

/**
 * Is a camera even reachable? getUserMedia is only exposed on secure origins,
 * which is a very common cause of "the scanner is broken" reports — an iPhone
 * hitting the app over plain http on the yard LAN gets no camera at all.
 */
export function cameraAvailability(): {
  ok: boolean;
  reason?: string;
} {
  if (typeof window === "undefined") return { ok: false, reason: "server" };

  const isSecure =
    window.isSecureContext ||
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1";

  if (!isSecure) {
    return {
      ok: false,
      reason:
        "Camera needs a secure connection (https). Open this app over https, or use manual entry below.",
    };
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    return {
      ok: false,
      reason: "This browser doesn't support camera access. Use manual entry below.",
    };
  }

  return { ok: true };
}

/** Human-readable engine label for the scanner UI. */
export function describeEngine(engine: ScanEngine): string {
  return engine === "native" ? "fast scanner" : "compatibility scanner";
}

/**
 * A QR payload may be a full label URL (https://yard.example/bundle/BND-2026-000123)
 * or a bare code. Normalise both to the code the API expects.
 */
export function normalizeScannedValue(raw: string): string {
  const trimmed = raw.trim();
  const match = trimmed.match(/\/bundle\/([^/?#]+)/i);
  const value = match ? decodeURIComponent(match[1]) : trimmed;
  return value.toUpperCase();
}

/**
 * Start scanning into the given <video>. The caller owns the element; we attach
 * a stream to it and drive detection until `stop()` is called.
 */
export async function startScanner({
  video,
  onResult,
  onError,
  onEngine,
}: StartScannerOptions): Promise<ScannerHandle> {
  const availability = cameraAvailability();
  if (!availability.ok) {
    throw new Error(availability.reason || "Camera unavailable");
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    video: {
      facingMode: { ideal: "environment" },
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
    audio: false,
  });

  // iOS Safari will refuse to autoplay inline video unless these are set on the
  // element itself before play() — React's attributes aren't always enough when
  // the element is reused across scans.
  video.setAttribute("playsinline", "true");
  video.setAttribute("muted", "true");
  video.muted = true;
  video.srcObject = stream;

  try {
    await video.play();
  } catch {
    // Some browsers reject play() if the element is still laying out; the
    // loadedmetadata handler below will retry.
  }

  let stopped = false;
  const stopStream = () => {
    stream.getTracks().forEach((t) => t.stop());
    if (video.srcObject) video.srcObject = null;
  };

  const nativeCtor = getNativeDetectorCtor();

  // ── Path 1: native BarcodeDetector (Android) ──────────────────────────────
  if (nativeCtor) {
    onEngine?.("native");
    let detector: NativeBarcodeDetector;
    try {
      detector = new nativeCtor({ formats: ["qr_code"] });
    } catch {
      // Constructed but unusable (rare). Fall through to ZXing.
      return startZxing({ video, stream, stopStream, onResult, onError, onEngine });
    }

    let frame = 0;
    const tick = async () => {
      if (stopped) return;
      // Throttle to roughly every other frame — detection is the expensive part
      // and phones in a hot yard throttle hard when pegged.
      if (video.readyState >= 2 && frame++ % 2 === 0) {
        try {
          const codes = await detector.detect(video);
          if (codes.length > 0 && codes[0].rawValue) {
            stopped = true;
            stopStream();
            onResult(normalizeScannedValue(codes[0].rawValue));
            return;
          }
        } catch {
          // Transient decode errors are normal; keep going.
        }
      }
      if (!stopped) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);

    return {
      engine: "native",
      stop: () => {
        stopped = true;
        stopStream();
      },
    };
  }

  // ── Path 2: ZXing fallback (iOS Safari and everything else) ───────────────
  return startZxing({ video, stream, stopStream, onResult, onError, onEngine });
}

async function startZxing({
  video,
  stopStream,
  onResult,
  onError,
  onEngine,
}: {
  video: HTMLVideoElement;
  stream: MediaStream;
  stopStream: () => void;
  onResult: (value: string) => void;
  onError?: (message: string) => void;
  onEngine?: (engine: ScanEngine) => void;
}): Promise<ScannerHandle> {
  onEngine?.("zxing");

  // Loaded lazily so Android devices never download the decoder they don't need.
  const { BrowserQRCodeReader } = await import("@zxing/browser");

  const reader = new BrowserQRCodeReader(undefined, {
    delayBetweenScanAttempts: 120,
    delayBetweenScanSuccess: 400,
  });

  let stopped = false;
  let controls: { stop: () => void } | undefined;

  try {
    // Decode from the stream we already opened, so permission is only ever
    // requested once and the same track is reused.
    controls = await reader.decodeFromVideoElement(video, (result, err) => {
      if (stopped) return;
      if (result) {
        stopped = true;
        try {
          controls?.stop();
        } catch {
          /* already stopped */
        }
        stopStream();
        onResult(normalizeScannedValue(result.getText()));
      } else if (err && err.name !== "NotFoundException") {
        // NotFoundException fires constantly on every frame without a code.
        // Anything else is worth surfacing.
        onError?.(err.message);
      }
    });
  } catch (err) {
    stopStream();
    throw err instanceof Error ? err : new Error("Scanner failed to start");
  }

  return {
    engine: "zxing",
    stop: () => {
      stopped = true;
      try {
        controls?.stop();
      } catch {
        /* already stopped */
      }
      stopStream();
    },
  };
}
