/**
 * Optional Redis backing for the login rate limiter, via the Upstash REST API.
 *
 * Uses plain fetch rather than an SDK on purpose: it's one HTTP call, it works
 * on the Edge runtime, and it avoids adding a dependency for something this
 * small. Any Upstash-compatible REST endpoint works.
 *
 * Unconfigured, everything here is inert and the in-memory limiter is used
 * instead. That keeps a single-yard deployment zero-infrastructure while
 * letting a multi-instance one share state.
 */

const REST_URL = process.env.UPSTASH_REDIS_REST_URL;
const REST_TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;

export function redisConfigured(): boolean {
  return Boolean(REST_URL && REST_TOKEN);
}

/** How long to wait before giving up and letting the in-memory limiter decide. */
const TIMEOUT_MS = 1000;

async function command(args: (string | number)[]): Promise<unknown> {
  const res = await fetch(`${REST_URL}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${REST_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(args),
    signal: AbortSignal.timeout(TIMEOUT_MS),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Redis returned ${res.status}`);
  const body = (await res.json()) as { result?: unknown; error?: string };
  if (body.error) throw new Error(body.error);
  return body.result;
}

export interface RedisRateLimitResult {
  count: number;
  /** Seconds until the window resets. */
  ttl: number;
}

/**
 * Increment the counter for `key` and return the new count plus the window's
 * remaining TTL.
 *
 * INCR then EXPIRE-if-new: the first caller in a window sets the expiry, so the
 * window is fixed from first request rather than sliding forward on every hit
 * (which would let a steady trickle keep a bucket alive forever).
 *
 * Not atomic across the two commands. A crash between them could leave a key
 * without a TTL, so the second call repairs any key found without one.
 */
export async function incrementWindow(
  key: string,
  windowMs: number
): Promise<RedisRateLimitResult> {
  const count = Number(await command(["INCR", key]));
  const seconds = Math.ceil(windowMs / 1000);

  if (count === 1) {
    await command(["EXPIRE", key, seconds]);
    return { count, ttl: seconds };
  }

  const ttl = Number(await command(["TTL", key]));
  // -1 means the key exists with no expiry: repair it rather than leaking a
  // counter that never resets and locks someone out permanently.
  if (ttl < 0) {
    await command(["EXPIRE", key, seconds]);
    return { count, ttl: seconds };
  }

  return { count, ttl };
}

export async function clearWindow(key: string): Promise<void> {
  await command(["DEL", key]);
}
