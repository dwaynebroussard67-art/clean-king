"use client";

/**
 * On-shift location tracker.
 *
 * Starts when the crew member clocks in and stops when they clock out. Runs
 * `watchPosition` in the browser, buffers fixes, and flushes them to the
 * shift's ping endpoint in batches — every ~15 s while moving, or when the
 * buffer fills, or when the app is about to be backgrounded.
 *
 * These are Earl's trucks. The trail is meant to be a line-by-line of where
 * the vehicle went for the whole shift: dense enough that a two-hour detour
 * cannot hide between pings. Keep the phone in the truck mount with the app
 * open (install to the home screen; wake lock while the screen is on).
 */

import { generateDeviceId } from "./offline-queue";

export interface TrackerState {
  shiftId: string | null;
  running: boolean;
  /** "granted" | "denied" | "prompt" | "unsupported" | "unknown" */
  permission: string;
  lastFix: { latitude: number; longitude: number; accuracyM: number | null; at: number } | null;
  buffered: number;
  sent: number;
  lastFlushAt: number | null;
  lastError: string | null;
}

interface BufferedPing {
  latitude: number;
  longitude: number;
  accuracyM: number | null;
  speedMps: number | null;
  heading: number | null;
  recordedAt: string;
}

const STORAGE_KEY = "forge_active_shift";
const FLUSH_INTERVAL_MS = 15_000;
const FLUSH_AT_BUFFER = 12;
/** Ignore fixes worse than this; a 2 km circle tells the owner nothing. */
const MAX_ACCURACY_M = 500;
/** Ignore fixes closer than this to the last one unless time has passed.
 * Tight on purpose: Earl's wants the actual line the truck drove, not a
 * connect-the-dots of parking lots. */
const MIN_MOVE_M = 8;
const MIN_INTERVAL_MS = 5_000;

let state: TrackerState = {
  shiftId: null,
  running: false,
  permission: "unknown",
  lastFix: null,
  buffered: 0,
  sent: 0,
  lastFlushAt: null,
  lastError: null,
};

const listeners = new Set<() => void>();
let buffer: BufferedPing[] = [];
let watchId: number | null = null;
let flushTimer: ReturnType<typeof setInterval> | null = null;
let wakeLock: { release: () => Promise<void> } | null = null;
let flushing = false;

function emit(patch: Partial<TrackerState>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function subscribeTracker(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getTrackerState(): TrackerState {
  return state;
}

const SERVER_STATE: TrackerState = { ...state };
export function getTrackerServerState(): TrackerState {
  return SERVER_STATE;
}

/** The shift this phone believes is open, surviving reloads. */
export function rememberedShiftId(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(STORAGE_KEY);
}

function distanceM(a: { latitude: number; longitude: number }, b: { latitude: number; longitude: number }) {
  const R = 6_371_000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.latitude - a.latitude);
  const dLng = toRad(b.longitude - a.longitude);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(x)));
}

async function readPermission(): Promise<string> {
  if (typeof navigator === "undefined" || !navigator.geolocation) return "unsupported";
  try {
    const status = await navigator.permissions?.query({ name: "geolocation" });
    return status?.state ?? "prompt";
  } catch {
    return "prompt";
  }
}

/**
 * Ask for location once, up front, with a real position result. Called from
 * the clock-in screen *before* the scan so the permission prompt appears in
 * context ("Forge Load needs your location while you're on shift"), not as a
 * surprise afterwards.
 */
export function requestPosition(timeoutMs = 10_000): Promise<GeolocationPosition | null> {
  return new Promise((resolve) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      emit({ permission: "unsupported" });
      resolve(null);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        emit({
          permission: "granted",
          lastFix: {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracyM: pos.coords.accuracy ?? null,
            at: Date.now(),
          },
          lastError: null,
        });
        resolve(pos);
      },
      async (err) => {
        emit({
          permission: err.code === err.PERMISSION_DENIED ? "denied" : await readPermission(),
          lastError: describeGeoError(err),
        });
        resolve(null);
      },
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 15_000 }
    );
  });
}

export function describeGeoError(err: GeolocationPositionError): string {
  switch (err.code) {
    case err.PERMISSION_DENIED:
      return "Location is turned off for this app. Turn it on in your phone's settings to clock in.";
    case err.POSITION_UNAVAILABLE:
      return "Couldn't get a GPS fix. Step outside or near a window and try again.";
    case err.TIMEOUT:
      return "GPS is taking too long. Try again in a moment.";
    default:
      return err.message || "Location error";
  }
}

async function acquireWakeLock() {
  try {
    const nav = navigator as Navigator & {
      wakeLock?: { request: (type: "screen") => Promise<{ release: () => Promise<void> }> };
    };
    if (nav.wakeLock && document.visibilityState === "visible") {
      wakeLock = await nav.wakeLock.request("screen");
    }
  } catch {
    // Not supported or refused; tracking still works while the tab is alive.
  }
}

function onVisibility() {
  if (document.visibilityState === "hidden") {
    // Last chance before iOS freezes us — push what we have, keepalive so the
    // request outlives the tab.
    void flush(true);
  } else if (state.running) {
    void acquireWakeLock();
  }
}

/** Begin tracking for a shift. Idempotent for the same shift. */
export async function startTracking(shiftId: string): Promise<void> {
  if (typeof window === "undefined") return;
  if (state.running && state.shiftId === shiftId) return;
  if (state.running) stopTracking({ flushFirst: true, forget: false });

  localStorage.setItem(STORAGE_KEY, shiftId);
  emit({ shiftId, running: true, lastError: null, permission: await readPermission() });

  if (!navigator.geolocation) {
    emit({ permission: "unsupported", lastError: "This phone's browser has no location support." });
    return;
  }

  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const { latitude, longitude, accuracy, speed, heading } = pos.coords;
      if (accuracy != null && accuracy > MAX_ACCURACY_M) return;

      const now = Date.now();
      const last = state.lastFix;
      if (last) {
        const moved = distanceM(last, { latitude, longitude });
        const elapsed = now - last.at;
        if (moved < MIN_MOVE_M && elapsed < FLUSH_INTERVAL_MS) return;
        if (elapsed < MIN_INTERVAL_MS) return;
      }

      buffer.push({
        latitude,
        longitude,
        accuracyM: accuracy ?? null,
        speedMps: speed != null && speed >= 0 ? speed : null,
        heading: heading != null && Number.isFinite(heading) ? heading : null,
        recordedAt: new Date(pos.timestamp || now).toISOString(),
      });
      emit({
        permission: "granted",
        lastFix: { latitude, longitude, accuracyM: accuracy ?? null, at: now },
        buffered: buffer.length,
        lastError: null,
      });
      if (buffer.length >= FLUSH_AT_BUFFER) void flush();
    },
    (err) => {
      emit({
        permission: err.code === err.PERMISSION_DENIED ? "denied" : state.permission,
        lastError: describeGeoError(err),
      });
    },
    { enableHighAccuracy: true, maximumAge: 5_000, timeout: 30_000 }
  );

  flushTimer = setInterval(() => void flush(), FLUSH_INTERVAL_MS);
  document.addEventListener("visibilitychange", onVisibility);
  window.addEventListener("pagehide", onPageHide);
  await acquireWakeLock();
}

function onPageHide() {
  void flush(true);
}

/**
 * Stop. `forget` clears the remembered shift (clock-out); leaving it set
 * means a reload will resume tracking the same shift.
 */
export function stopTracking({ flushFirst = true, forget = true } = {}): Promise<void> {
  const pending = flushFirst ? flush(true) : Promise.resolve();

  if (watchId != null && typeof navigator !== "undefined") {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  if (flushTimer) {
    clearInterval(flushTimer);
    flushTimer = null;
  }
  if (typeof document !== "undefined") {
    document.removeEventListener("visibilitychange", onVisibility);
    window.removeEventListener("pagehide", onPageHide);
  }
  void wakeLock?.release().catch(() => {});
  wakeLock = null;
  if (forget && typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);

  emit({ running: false, shiftId: forget ? null : state.shiftId });
  return pending;
}

/** Send buffered fixes. Safe to call any time; no-op when there's nothing. */
export async function flush(keepalive = false): Promise<void> {
  if (flushing || buffer.length === 0 || !state.shiftId) return;
  flushing = true;
  const batch = buffer;
  buffer = [];
  try {
    const res = await fetch(`/api/shifts/${state.shiftId}/pings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pings: batch, deviceId: generateDeviceId() }),
      keepalive,
    });
    if (res.ok) {
      const data = (await res.json().catch(() => ({}))) as { accepted?: number; shiftClosed?: boolean };
      emit({
        sent: state.sent + (data.accepted ?? batch.length),
        buffered: buffer.length,
        lastFlushAt: Date.now(),
        lastError: null,
      });
      if (data.shiftClosed) {
        // The office clocked us out. Stop quietly; the UI will notice on its
        // next poll.
        void stopTracking({ flushFirst: false, forget: true });
      }
    } else if (res.status === 401 || res.status === 403 || res.status === 404) {
      // Not recoverable by retrying — drop the batch and stop.
      emit({ lastError: "Tracking stopped: this shift is no longer open on the server." });
      void stopTracking({ flushFirst: false, forget: true });
    } else {
      buffer = batch.concat(buffer).slice(-500);
      emit({ buffered: buffer.length, lastError: `Server said ${res.status}; will retry.` });
    }
  } catch {
    // Offline. Keep the fixes (bounded) and try again on the next tick.
    buffer = batch.concat(buffer).slice(-500);
    emit({ buffered: buffer.length, lastError: "No signal — holding positions until it's back." });
  } finally {
    flushing = false;
  }
}
