"use client";

import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import {
  getTrackerServerState,
  getTrackerState,
  rememberedShiftId,
  requestPosition,
  startTracking,
  stopTracking,
  subscribeTracker,
  type TrackerState,
} from "@/lib/tracker";
import { generateDeviceId } from "@/lib/offline-queue";
import { v4 as uuidv4 } from "uuid";

export interface ShiftSummary {
  id: string;
  status: "active" | "closed";
  method: "qr" | "manual";
  siteName: string | null;
  clockInAt: string;
  clockInDistanceM: number | null;
  clockOutAt: string | null;
  lastPingAt: string | null;
  pingCount: number;
}

export interface ItineraryItem {
  id: string;
  forDate: string;
  title: string;
  body: string | null;
  priority: "normal" | "high";
  assigneeId: string | null;
  createdByName: string | null;
  createdAt: string;
}

/**
 * The crew member's own shift: are they clocked in, and is the phone
 * reporting? Owns the "resume tracking after a reload" behaviour, so a driver
 * who reopens the app mid-route picks up where they left off without doing
 * anything.
 */
export function useShift() {
  const tracker = useSyncExternalStore<TrackerState>(
    subscribeTracker,
    getTrackerState,
    getTrackerServerState
  );
  const [shift, setShift] = useState<ShiftSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/shifts?mine=1&active=1&limit=1");
      if (!res.ok) throw new Error("Could not load shift");
      const data = await res.json();
      const open: ShiftSummary | null = data.shifts?.[0] ?? null;
      setShift(open);

      // Reconcile the phone with the server. Server says open -> make sure
      // we're tracking. Server says closed -> stop and forget.
      if (open && open.status === "active") {
        void startTracking(open.id);
      } else if (rememberedShiftId()) {
        void stopTracking({ flushFirst: false, forget: true });
      }
      return open;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load shift");
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Async network read on mount; the setState lands on a later tick.
    // eslint-disable-next-line react-hooks/set-state-in-effect -- async load-on-mount
    void refresh();
  }, [refresh]);

  const clockIn = useCallback(
    async (token: string | null): Promise<{ shift: ShiftSummary; itinerary: ItineraryItem[]; alreadyActive: boolean; site: { name: string } | null }> => {
      setError(null);
      const pos = await requestPosition();
      const res = await fetch("/api/shifts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientUuid: uuidv4(),
          token,
          latitude: pos?.coords.latitude ?? null,
          longitude: pos?.coords.longitude ?? null,
          accuracyM: pos?.coords.accuracy ?? null,
          deviceId: generateDeviceId(),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.error || "Could not clock in");
      }
      const opened: ShiftSummary = { ...data.shift, siteName: data.site?.name ?? null };
      setShift(opened);
      void startTracking(opened.id);
      return {
        shift: opened,
        itinerary: data.itinerary ?? [],
        alreadyActive: Boolean(data.alreadyActive),
        site: data.site ?? null,
      };
    },
    []
  );

  const clockOut = useCallback(async () => {
    if (!shift) return;
    setError(null);
    const pos = await requestPosition(6_000);
    await stopTracking({ flushFirst: true, forget: true });
    const res = await fetch(`/api/shifts/${shift.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "clock_out",
        latitude: pos?.coords.latitude ?? null,
        longitude: pos?.coords.longitude ?? null,
        accuracyM: pos?.coords.accuracy ?? null,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      // Clock-out failed — resume tracking so the trail doesn't have a hole.
      void startTracking(shift.id);
      throw new Error(data.error || "Could not clock out");
    }
    setShift(null);
  }, [shift]);

  return { shift, tracker, loading, error, refresh, clockIn, clockOut };
}
