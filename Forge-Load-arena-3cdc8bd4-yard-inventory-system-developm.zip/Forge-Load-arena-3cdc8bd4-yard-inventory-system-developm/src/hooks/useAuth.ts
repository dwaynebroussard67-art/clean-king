"use client";

import { useState, useEffect, useCallback, useSyncExternalStore } from "react";

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: "admin" | "crew";
}

type AuthState = {
  user: AuthUser | null;
  status: "unknown" | "loading" | "ready";
};

/**
 * Module-level auth store shared by every component that calls useAuth, so a
 * page with several consumers still only fetches /api/auth/me once.
 *
 * This is wired through useSyncExternalStore rather than an effect that calls
 * setState on mount — the previous version triggered a cascading render on
 * every page load and tripped react-hooks/set-state-in-effect.
 */
let state: AuthState = { user: null, status: "unknown" };
let inFlight: Promise<void> | null = null;
const listeners = new Set<() => void>();

function setState(next: AuthState) {
  // Keep the snapshot referentially stable when nothing actually changed,
  // otherwise useSyncExternalStore will loop.
  if (next.user === state.user && next.status === state.status) return;
  state = next;
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot(): AuthState {
  return state;
}

// The server has no session context here; render as still-loading so markup
// matches the client's first paint.
const SERVER_SNAPSHOT: AuthState = { user: null, status: "loading" };
function getServerSnapshot(): AuthState {
  return SERVER_SNAPSHOT;
}

function fetchSession(): Promise<void> {
  if (inFlight) return inFlight;

  setState({ user: state.user, status: "loading" });

  inFlight = fetch("/api/auth/me")
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      setState({ user: data?.user ?? null, status: "ready" });
    })
    .catch(() => {
      setState({ user: null, status: "ready" });
    })
    .finally(() => {
      inFlight = null;
    });

  return inFlight;
}

export function useAuth() {
  const snapshot = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  useEffect(() => {
    // Only ever kicks off a network call; never sets state synchronously.
    if (state.status === "unknown") void fetchSession();
  }, []);

  const logout = useCallback(async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      setState({ user: null, status: "ready" });
    }
  }, []);

  const login = useCallback((user: AuthUser) => {
    setState({ user, status: "ready" });
  }, []);

  const refresh = useCallback(() => fetchSession(), []);

  return {
    user: snapshot.user,
    loading: snapshot.status !== "ready",
    logout,
    login,
    refresh,
  };
}

/** Test/HMR escape hatch. */
export function __resetAuthStore() {
  state = { user: null, status: "unknown" };
  inFlight = null;
  listeners.clear();
}
