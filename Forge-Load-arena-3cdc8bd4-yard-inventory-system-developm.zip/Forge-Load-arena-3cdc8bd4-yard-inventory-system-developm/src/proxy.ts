import { NextRequest, NextResponse } from "next/server";
import { jwtVerify, SignJWT } from "jose";
import { SESSION_COOKIE } from "@/lib/tenant";
import {
  shouldRefreshSession,
  sessionCookieOptions,
  SESSION_TTL_SECONDS,
} from "@/lib/session-cookie";

/**
 * Server-side route protection (Next.js `proxy` convention, formerly `middleware`).
 *
 * Without this, /admin returned a 200 with the full admin shell to anonymous
 * visitors — the APIs behind it were protected so no data leaked, but the crew
 * saw a flash of admin chrome before the client-side check bounced them.
 *
 * This runs on the Edge runtime, so it only does cheap JWT verification. It
 * deliberately does not hit the database; routes still enforce their own
 * authorization, and this is a first line of defence rather than the only one.
 */

// /intake creates catalogue entries, so it's admin-only alongside receiving.
const ADMIN_PREFIXES = ["/admin", "/receiving", "/intake"];
// /damage is crew-reachable — anyone who can break something can report it.
const PROTECTED_PREFIXES = [
  "/",
  "/scan",
  "/jobs",
  "/bundle",
  "/damage",
  "/queue",
  // Shift + fleet. /clock-in/<token> is what the poster links to, and it must
  // bounce through login preserving the token so the scan still counts.
  "/clock-in",
  "/truck-check",
  ...ADMIN_PREFIXES,
];

// Paths that must stay reachable while logged out.
const PUBLIC_PATHS = new Set(["/login", "/offline"]);

function isPublicAsset(pathname: string): boolean {
  return (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") || // routes do their own auth and return JSON
    pathname === "/sw.js" ||
    pathname === "/manifest.json" ||
    pathname === "/favicon.ico" ||
    /\.(png|jpg|jpeg|svg|ico|webmanifest|txt|woff2?)$/.test(pathname)
  );
}

function matchesPrefix(pathname: string, prefixes: string[]): boolean {
  return prefixes.some((prefix) =>
    prefix === "/" ? pathname === "/" : pathname === prefix || pathname.startsWith(`${prefix}/`)
  );
}

/**
 * Re-issue the session cookie when it's close to expiring, preserving the
 * original claims. Signed here rather than by calling an API route so it costs
 * nothing extra and works on whatever request the crew happened to make.
 */
async function withRefreshedSession(
  res: NextResponse,
  session: { id?: string; role?: string; exp?: number },
  secret: string
): Promise<NextResponse> {
  if (!shouldRefreshSession(session.exp)) return res;

  // Drop the claims jose manages itself, so the new token gets fresh ones
  // rather than inheriting the old expiry.
  const { exp: _exp, ...claims } = session as Record<string, unknown> & { exp?: number };
  void _exp;
  delete (claims as { iat?: number }).iat;

  try {
    const token = await new SignJWT(claims)
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
      .sign(new TextEncoder().encode(secret));
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions);
  } catch {
    // A failed refresh must never break the request -- the existing cookie is
    // still valid, so the crew just keeps working on it.
  }
  return res;
}

async function readSession(token: string | undefined) {
  if (!token) return null;
  const secret = process.env.JWT_SECRET;
  // In development the app may be running with an ephemeral in-memory secret,
  // which this Edge context can't see. Fall back to letting the page-level
  // check handle it rather than locking the developer out.
  if (!secret || secret.length < 32) return undefined;

  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret));
    return payload as { id?: string; role?: string; exp?: number };
  } catch {
    return null;
  }
}

export async function proxy(req: NextRequest) {
  const { pathname, search } = req.nextUrl;

  if (isPublicAsset(pathname)) return NextResponse.next();

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const session = await readSession(token);

  // Secret unavailable to the Edge runtime — defer to the client/page checks.
  if (session === undefined) return NextResponse.next();

  const isAuthed = Boolean(session?.id);

  if (PUBLIC_PATHS.has(pathname)) {
    // Already signed in and heading to /login? Send them where they were going.
    if (pathname === "/login" && isAuthed) {
      const next = req.nextUrl.searchParams.get("next");
      const target =
        next && next.startsWith("/") && !next.startsWith("//") ? next : "/";
      return NextResponse.redirect(new URL(target, req.url));
    }
    return NextResponse.next();
  }

  if (!isAuthed && matchesPrefix(pathname, PROTECTED_PREFIXES)) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("next", `${pathname}${search}`);
    return NextResponse.redirect(loginUrl);
  }

  if (matchesPrefix(pathname, ADMIN_PREFIXES) && session?.role !== "admin") {
    return NextResponse.redirect(new URL("/", req.url));
  }

  const res = NextResponse.next();
  if (isAuthed && session) {
    const secret = process.env.JWT_SECRET;
    if (secret && secret.length >= 32) {
      return withRefreshedSession(res, session, secret);
    }
  }
  return res;
}

export const config = {
  matcher: [
    // Everything except Next internals and static files; the callback above
    // does the finer-grained filtering.
    "/((?!_next/static|_next/image).*)",
  ],
};
