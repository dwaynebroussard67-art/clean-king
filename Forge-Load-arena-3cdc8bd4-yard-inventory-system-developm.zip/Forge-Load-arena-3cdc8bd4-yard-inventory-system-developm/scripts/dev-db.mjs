/**
 * Local Postgres for development and manual testing, with no Docker or system
 * install required. PGlite is the real Postgres engine compiled to WASM, served
 * over the wire protocol so `pg` (and therefore drizzle) can connect normally.
 *
 *   node scripts/dev-db.mjs
 *   DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5433/postgres
 *
 * Data lives in .pglite/ and is gitignored. Not for production.
 */
import { PGlite } from "@electric-sql/pglite";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";

const port = Number(process.env.DEV_DB_PORT || 5433);
const db = await PGlite.create({ dataDir: process.env.DEV_DB_DIR || "./.pglite" });

const server = new PGLiteSocketServer({ db, port, host: "127.0.0.1" });
await server.start();
console.log(`dev database listening on postgresql://postgres:postgres@127.0.0.1:${port}/postgres`);

const shutdown = async () => {
  await server.stop();
  await db.close();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
