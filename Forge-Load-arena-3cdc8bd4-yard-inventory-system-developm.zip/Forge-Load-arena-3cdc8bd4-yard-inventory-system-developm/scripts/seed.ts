/**
 * One-shot seed script. Replaces the old public /api/setup route, which was an
 * unauthenticated endpoint that created a hardcoded admin (admin123).
 *
 * Run with:  npm run db:seed
 *
 * Safe to re-run: it will not create a second admin, and it refuses to run at
 * all if an admin already exists unless you pass --force.
 */
import "dotenv/config";
import { Pool } from "pg";
import bcrypt from "bcryptjs";
import { randomBytes } from "node:crypto";

const FORCE = process.argv.includes("--force");
const WITH_DEMO = process.argv.includes("--demo");

function fail(message: string): never {
  console.error(`\n✖ ${message}\n`);
  process.exit(1);
}

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) fail("DATABASE_URL is not set. Copy .env.example to .env first.");

  const pool = new Pool({ connectionString: databaseUrl });

  try {
    // ── Sequences the code-generation helpers depend on ──────────────────────
    // These used to be created by the setup route, which meant a fresh deploy
    // that never called it would throw on the first bundle/job/receipt.
    await pool.query("CREATE SEQUENCE IF NOT EXISTS bundle_code_seq START 1");
    await pool.query("CREATE SEQUENCE IF NOT EXISTS job_code_seq START 1");
    await pool.query("CREATE SEQUENCE IF NOT EXISTS receipt_code_seq START 1");
    console.log("✓ Code sequences ready");

    // ── Admin user ───────────────────────────────────────────────────────────
    const { rows: adminRows } = await pool.query(
      "SELECT id, email FROM users WHERE role = 'admin' LIMIT 1"
    );

    if (adminRows.length > 0 && !FORCE) {
      console.log(`✓ Admin already exists (${adminRows[0].email}) — skipping.`);
      console.log("  Pass --force to create another admin.");
    } else {
      const email = process.env.SEED_ADMIN_EMAIL?.trim().toLowerCase();
      const fullName = process.env.SEED_ADMIN_NAME?.trim() || "Admin User";

      if (!email) {
        fail(
          "SEED_ADMIN_EMAIL is not set.\n" +
            "  Set SEED_ADMIN_EMAIL (and optionally SEED_ADMIN_PASSWORD) in .env and re-run."
        );
      }

      // If no password was supplied, generate a strong one and print it once.
      const supplied = process.env.SEED_ADMIN_PASSWORD;
      const generated = !supplied;
      const password = supplied || randomBytes(12).toString("base64url");

      if (supplied && supplied.length < 12) {
        fail("SEED_ADMIN_PASSWORD must be at least 12 characters.");
      }

      const passwordHash = await bcrypt.hash(password, 12);

      await pool.query(
        `INSERT INTO users (email, password_hash, full_name, role)
         VALUES ($1, $2, $3, 'admin')
         ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = 'admin'`,
        [email, passwordHash, fullName]
      );

      console.log(`✓ Admin user ready: ${email}`);
      if (generated) {
        console.log("\n  ┌──────────────────────────────────────────────────┐");
        console.log("  │  GENERATED PASSWORD — shown once, save it now    │");
        console.log("  └──────────────────────────────────────────────────┘");
        console.log(`  ${password}\n`);
      }
    }

    // ── Optional demo catalogue ──────────────────────────────────────────────
    if (WITH_DEMO) {
      const tenantKey =
        process.env.NEXT_PUBLIC_TENANT || process.env.TENANT || "forge-load";
      const { rows: pc } = await pool.query("SELECT COUNT(*)::int AS c FROM products");
      if (pc[0].c === 0) {
        if (tenantKey === "earls-furniture") {
          await pool.query(`
            INSERT INTO products (sku, name, category, base_unit, pieces_per_bundle, reorder_threshold)
            VALUES
              ('SOF-3C-OAK',  'Oak Frame 3-Cushion Sofa',        'Living Room', 'item', 1, 5),
              ('REC-LTH-BRN', 'Brown Leather Recliner',          'Chairs',      'item', 1, 3),
              ('TBL-DR-6P',   '6-Person Dining Table',           'Dining',      'item', 1, 2),
              ('NST-PINE-2D', '2-Drawer Solid Pine Nightstand',   'Bedroom',     'item', 1, 8)
          `);
        } else {
          await pool.query(`
            INSERT INTO products (sku, name, category, base_unit, pieces_per_bundle, reorder_threshold)
            VALUES
              ('CED-6FT-PRI', '6ft Cedar Privacy Picket', 'Fencing', 'piece', 200, 500),
              ('PT-4X4-8',    '4x4x8 Pressure Treated Post', 'Posts', 'piece', 50, 100),
              ('CED-2X4-8',   '2x4x8 Cedar Rail', 'Rails', 'piece', 100, 200),
              ('SCRW-1.5-GV', '1.5" Galvanized Screw (box)', 'Hardware', 'bundle', 1, 10)
          `);
        }
        console.log("✓ Demo products seeded");
      }

      const { rows: cc } = await pool.query("SELECT COUNT(*)::int AS c FROM customers");
      if (cc[0].c === 0) {
        await pool.query(`
          INSERT INTO customers (name, ref, phone)
          VALUES ('Acme Construction', 'ACME-001', '555-0100'),
                 ('Green Valley Homes', 'GVH-042', '555-0142')
        `);
        console.log("✓ Demo customers seeded");
      }
    }

    console.log("\n✓ Seed complete.\n");
  } finally {
    await pool.end();
  }
}

main().catch((err) => {
  console.error("\n✖ Seed failed:", err instanceof Error ? err.message : err, "\n");
  process.exit(1);
});
