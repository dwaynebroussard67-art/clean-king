# CI configuration

`github-actions-ci.yml` is the CI pipeline for this repo. It isn't at
`.github/workflows/` because the integration that pushed this branch doesn't
hold GitHub's `workflows` permission, so it can't create workflow files.

To enable it:

```bash
mkdir -p .github/workflows
git mv ci/github-actions-ci.yml .github/workflows/ci.yml
git commit -m "Enable CI"
git push
```

It runs on every push and pull request:

- **verify** — typecheck, lint, tests, and a production build
- **secret-scan** — fails the build if a connection string with an embedded
  password is ever committed again
