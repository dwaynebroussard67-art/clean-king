# Forge Load

One QR code runs the yard. The crew scan it to **clock in**, which turns on
**GPS for the length of their shift** so the office can watch the trucks; it
hands them **the day's orders** the office typed the night before; and it
sends them to the **morning truck check** before they roll. Underneath that
sits the license-plate **inventory** — every bundle gets a QR label and its own
running balance, every pull, return and adjustment is written to an
append-only ledger, so you can always answer *who took what, for which job,
and when*.

Built for phones in a yard: works on iPhone and Android, keeps working when
the signal drops, and syncs when it comes back.

## What the crew see

| Screen | What it does |
| --- | --- |
| **Clock in** (`/clock-in`) | Asks for location first, then scans the poster by the door. Records who, when, and how far from the shop. Starts GPS tracking. Shows the office's orders for today. Clock out stops tracking. |
| **Truck check** (`/truck-check`) | Eleven-item walk-round (oil, coolant, belts, brakes, tires, lights, mirrors, lift gate, leaks, cab, body), odometer, fuel, notes. Safety items that fail ground the truck. |
| **Scan / Jobs / Damage** | The inventory features, unchanged. |

## What the office sees (Admin)

| Tab | What it does |
| --- | --- |
| **Crew** | Live map of everyone on the clock (moving / stopped / signal lost), tap a name to follow, tap *Route* for the day's breadcrumb trail. Flags manual clock-ins and clock-ins far from the shop. Timesheet by day. Clock someone out who forgot. |
| **Fleet** | Every truck, whether it's had its morning check, and the history with what was flagged. |
| **Orders** | Type tomorrow's itinerary — for everyone or one person, normal or important. See who has had it delivered to their phone, and when. |
| **Posters** | Create the clock-in site, pin its location, print the QR poster. Rotate the code if a poster walks off. |

### About location tracking

Tracking is on **only between clock-in and clock-out**, and the clock-in
screen says so before the browser asks. This is a web app, so the phone
reports while the browser tab is alive; iOS in particular suspends background
tabs after a minute or two. In practice: install it to the home screen (much
more generous), keep the phone in the truck mount with the app open. If that
proves insufficient, a native shell (Capacitor) is the upgrade path and the
server side doesn't change. The map shows *signal lost* after 3 minutes of
silence rather than pretending.

The poster's token is not a secret — a photo of it works from anywhere. That's
why every clock-in also records the phone's distance from the site, and a
manual clock-in is labelled as one. "Scanned the shop code, 30 ft from the
door" is a normal morning; "manual, 3 miles away" is a conversation.

---

## Quick start

```bash
npm install
cp .env.example .env      # then fill in the values (see below)

npm run dev:db            # local Postgres, no Docker needed (separate terminal)
npm run db:migrate        # create the schema
npm run db:seed -- --demo # create your admin user + demo catalogue

npm run dev               # http://localhost:3000
```

The seed prints the admin password if you didn't set `SEED_ADMIN_PASSWORD`.
It's shown **once** — save it.

Then sign in and, under **Admin**: add the shop on the **Posters** tab (stand
at the door and tap *Use my location*), print the poster, and add the trucks
on the **Fleet** tab. Everything else the crew need appears on their phones.

### Environment

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | yes | Postgres connection string. The app refuses to boot without it. |
| `JWT_SECRET` | yes in prod | Signs session cookies. Must be ≥32 chars. `openssl rand -base64 48` |
| `NEXT_PUBLIC_APP_URL` | before printing labels | Canonical URL baked into QR labels. See the warning below. |
| `SEED_ADMIN_EMAIL` | for seeding | First admin account. |
| `SEED_ADMIN_PASSWORD` | optional | Generated and printed if omitted. Min 12 chars. |
| `ANTHROPIC_API_KEY` | optional | Enables the yard assistant + photo extraction. Both degrade gracefully without it. |

> **Printing labels:** set `NEXT_PUBLIC_APP_URL` to the real production host
> *before* you print a batch. Labels are physical and long-lived — a batch printed
> from `localhost` or a preview URL encodes that host permanently, and you cannot
> fix it without reprinting and re-tagging every bundle.

---

## Multi-tenant (white-label)

One codebase, many customers. Everything customer-visible — name, logo mark,
accent colour, PWA manifest, session cookie namespace, and the AI assistant's
domain wording — comes from a single config, selected by one environment
variable:

```bash
NEXT_PUBLIC_TENANT=earls-furniture npm run build   # or omit for Forge Load (default)
```

Registered customers live in `src/lib/tenant.ts`. **Adding one is a config
change, not a fork:**

1. Add an entry to `TENANTS`.
2. Drop their icons in `public/` (or reuse the defaults).
3. Deploy with `NEXT_PUBLIC_TENANT=<key>`.

Two implementation notes, because they're the parts that break silently if
someone "simplifies" them:

- **Colours go through `accent-*`, never a literal Tailwind colour.** Tailwind
  can only see class names at build time, so `bg-accent-500` is a static class
  whose *value* is a CSS variable the tenant sets. Hardcoding `bg-orange-500`
  anywhere re-breaks the swap for every other customer.
- **The session cookie and the offline IndexedDB are namespaced per tenant.**
  Two customers on sibling subdomains of one parent domain would otherwise
  share a cookie and silently log each other out.

An unknown tenant key falls back to the default rather than failing to boot —
a typo in an env var shouldn't take a yard offline.

---

## How it works

**Bundles are the unit of truth.** Receiving a shipment mints one bundle per
physical bundle, each with a code (`BND-2026-000123`) and a QR label. A bundle
carries `qty_received` and `qty_remaining`; when it hits zero it retires
automatically and stops accepting movements.

**Movements are an append-only ledger.** Nothing is ever edited in place. The
bundle balance and the sum of its movement deltas must always agree — there's a
test that asserts exactly that.

**Every movement carries a client-generated UUID.** That's what makes offline
sync safe: a phone that loses signal mid-write can retry as many times as it
likes, and the unique index on `client_uuid` guarantees it applies once.

**The camera is the point.** Three flows are photo-first, so the crew types as
little as possible:

- **`/intake`** — photograph a new item, name it, tap the count. The photo
  becomes the product image, bundles are minted, labels print. Admin only.
- **`/damage`** — the camera opens first. Taking the picture files the report,
  and who/when/where/what/why are filled in from the session, the clock, GPS,
  the scanned bundle, and a grid of buttons. Optionally writes the damaged
  quantity out of stock through the same guarded decrement a pull uses.
- **Job pages** — proof the material left the yard, in two flavours.
  **Load-out** is the common case (most orders are picked up on the customer's
  own truck, so the claim to refute is "you never loaded it"); **delivery**
  covers the rest. The load-out camera also appears right after a pull, when
  the crew is still standing at the truck.

Photos are stored in Postgres as `bytea`. The deploy target is serverless,
where the filesystem is ephemeral, and keeping the image beside the record
makes backups atomic. `src/lib/photos.ts` is the *only* module that reads or
writes the bytes, so moving to S3/R2 later is a one-file change.

### Roles

- **crew** — scan, pull, return, view jobs, report damage, delivery photos
- **admin** — everything, plus receiving, new-item intake, damage review,
  products, customers, users, the assistant

Enforced in three places: `src/proxy.ts` (page routes), each API route, and the
nav. The API check is the one that actually matters.

---

## Commands

| Command | What it does |
| --- | --- |
| `npm run dev` | Dev server |
| `npm run dev:db` | Local Postgres (PGlite over the wire protocol) |
| `npm run build` / `start` | Production build / serve |
| `npm run verify` | typecheck + lint + tests — run before pushing |
| `npm test` | Vitest suite |
| `npm run db:generate` | Generate a migration after editing `src/db/schema.ts` |
| `npm run db:migrate` | Apply pending migrations (`0003_shifts_fleet_itineraries` adds the clock-in, tracking, fleet and itinerary tables) |
| `npm run db:seed` | Create the admin user (`--demo` adds sample catalogue, `--force` adds another admin) |
| `npm run db:studio` | Drizzle Studio |

---

## Testing

```bash
npm test
```

Tests run against **real Postgres** (PGlite — the actual engine compiled to
WASM), not mocks. That matters because the things most worth testing here are
concurrency and constraint enforcement, which mocks can't reproduce.

The suite covers the movement ledger (including a test that fires ten
simultaneous pulls at one bundle and asserts exactly five succeed), offline
replay idempotency, error classification, code normalisation, and rate limiting.

---

## Deploying

1. Provision Postgres and set `DATABASE_URL`.
2. Set `JWT_SECRET` (≥32 chars) and `NEXT_PUBLIC_APP_URL`.
3. `npm run db:migrate`
4. `npm run db:seed` — save the printed password, then sign in and change it.
5. `npm run build && npm start`

**Serve over HTTPS.** Camera access requires a secure context; over plain HTTP
the scanner cannot start on any modern browser. The app detects this and tells
the crew to use manual entry, but you lose scanning entirely.

`GET /api/health` returns `{"status":"ok"}` and checks database connectivity —
point your uptime monitor at it.

---

## Notes for whoever works on this next

- **Camera:** Android Chrome uses the native `BarcodeDetector`; iOS Safari
  doesn't implement it, so `src/lib/scanner.ts` falls back to ZXing. The engine
  in use is shown under the viewfinder, which is the first thing to check when
  someone says "scanning is broken on my phone."
- **The offline queue** (`src/lib/offline-queue.ts`) is the trickiest part. A
  movement is `pending → syncing → synced`, or parked as `rejected` if the server
  refuses it permanently (bundle ran out while you were offline). Rejected
  movements surface on the dashboard because they need a human.
- **Never trust `employeeId` from the request body.** Attribution comes from the
  session, always. The audit trail is the whole product.
- **Quantity changes must stay atomic.** The bounds check lives *inside* the
  `UPDATE` in `src/app/api/movements/route.ts`. Splitting it back into a read,
  a check, and a write reintroduces the oversell race.
- **Rate limiting** is in-process, which is fine for one yard on one instance.
  Move it to Redis before scaling horizontally.
- **Photo uploads trust the bytes, not the headers.** `sniffImageType` checks
  magic numbers and the claimed content-type is discarded, so a text file
  renamed `.jpg` is refused. Serving is auth-gated and `Cache-Control: private`
  — these images show customer sites and damage claims, so they must never sit
  in a shared CDN.
- **Uploads are multipart, not base64 JSON.** Base64 costs ~33% more bytes,
  which matters on a phone with one bar.
- **Damage reports require a photo.** That's deliberate: the photo is the
  evidence, and a report without one is worth very little in a claim.

- **Shifts: one open per person, enforced by a partial unique index.** A
  double-tap or an offline retry hits 23505 and the API returns the existing
  shift as `alreadyActive`. Don't "fix" that by checking first — the check is
  the race.
- **Location pings are insert-only and the last-known position never moves
  backwards.** Batches arrive out of order after a dead spot; the `UPDATE`
  only advances `last_*` when the batch is newer. The counter always advances.
- **The truck-check status is computed on the server** from the items
  (`rollupCheckStatus` in `src/lib/fleet.ts`), never accepted from the phone.
  A bad brake result cannot be submitted as "good to go".
- **Calendar days are in `America/Chicago`.** Itineraries and checks are keyed
  by `YYYY-MM-DD` in the shop's zone (`localDateKey`). A UTC server would roll
  the day at 7 pm Louisiana time — exactly when the office is typing
  tomorrow's orders.
- **Itinerary acks are the proof of delivery.** First delivery wins
  (`ON CONFLICT DO NOTHING`), so the timestamp is the first time their phone
  showed it.
- **The map is Leaflet + OpenStreetMap.** No API key, no per-load billing.
  OSM's tile policy is fine for one shop's traffic; switch the tile URL to a
  paid provider before this is serving hundreds of concurrent dashboards.

See `LAUNCH_READINESS.md` for the full audit and what's still outstanding.
